# Eternal Realms — Live Gameplay/Backend Integration Pass

## Applied in this pass

- Server-approved NPC dialogue, merchant-open and quest-turn-in interactions now emit durable backend interaction events in production mode.
- NPC identity is derived deterministically from the single world ID and NPC name, so event records refer to the same logical NPC across server restarts.
- Quest turn-in interaction approval is recorded as `turn_in_interaction_validated`; it is intentionally not recorded as completed and does not grant rewards.
- World boss spawn and defeat states are written through the existing world-entity persistence API. The server reads the region entity revision before updating to avoid blindly reusing revision zero.
- Boss persistence is server-only and uses the same `eternal-realms-one-world` identity.

## Important boundaries

This pass connects durable event/state recording to existing gameplay hooks. It does **not** yet make all NPC/quest/merchant rewards fully authoritative. In particular:

- Quest objective progress must be checked against server-owned objective events before a completion transaction can grant rewards.
- The existing StationPanel shop buy/sell flow still contains local PlayerData mutations and is not production-safe as a final MMO transaction flow.
- Merchant stock purchase needs to be invoked through a server-side range/stock/price validation path and the backend merchant stock must be provisioned.
- Boss state is written, but startup restoration/reconciliation of alive/defeated boss records and population migration state remains outstanding.
- Existing monster AI remains server-simulated in the current authoritative process; distributed region ownership and durable population reconciliation are not complete.

## Production configuration

The persistence hooks execute only when `WorldDeploymentGuard.production_mode` is enabled and `CentralBackend` is configured with an HTTPS backend URL and server service token. Local/offline play retains existing behavior.

## Verification

Static source checks and archive integrity are performed for this pass. Godot 4.7 headless parsing, a live PostgreSQL migration, two-client interaction tests, boss restart/recovery tests and load tests require the actual Godot/Docker/PostgreSQL runtime and are not claimed unless executed.
