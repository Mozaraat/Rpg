# Eternal Realms — Regional Pricing, Village Logistics & Overhead Readability

## Implemented

### Overhead text readability
- NPC nameplates, speech bubbles and quest markers now render without scene-light shading.
- Set explicit high-contrast pale text and a near-black outline so overhead dialogue and markers remain legible over bright sky, dark interiors and foliage.
- Existing screen-space interaction prompt styling remains intact: dark translucent panel with warm light text.

### Server-authoritative regional merchant pricing
- The internal merchant purchase endpoint now resolves the merchant's region and calculates a scarcity multiplier from the combined stock of that item across merchants in the same region.
- The regional price calculation is serialized with a PostgreSQL transaction-scoped advisory lock for each region/item pair.
- The effective unit price is used for the currency debit, regional economy ledger, territory tax calculation and committed transaction result.
- Price multiplier is bounded from 0.65x to 2.25x. Merchant catalog `unit_price` remains the base price; the effective price is recalculated from live regional stock at purchase time.
- Added migration `backend/postgres/005_regional_dynamic_merchant_pricing.sql` with indexes for the regional stock lookup. Apply migrations 001–005 in order.
- Existing Godot purchase request shape is unchanged; clients do not submit a price.

### Physical village goods delivery
- NPCs can accept a delivery job, visibly carry a crate, walk to a merchant stall and transfer the goods into that merchant's local business stock only after reaching the destination.
- NPC job processing is restricted to the multiplayer authority.
- Active delivery destinations are retained when the initial movement timer expires, rather than being replaced with a random wander target.

### Caravan reservation correction
- Active caravan records now retain the shipment ID returned by the reservation flow, allowing arrival/ambush resolution to address the correct reserved shipment.

## Important remaining work
- The village delivery receipt currently updates `LivingWorldSystem` local persisted business state. It is not yet connected to a central backend merchant-restock transaction, so it is not yet a globally shared multiplayer stock transfer.
- Caravans still need authoritative network spawn/state replication, late-join snapshots, and reconnect/restart recovery of their visuals.
- Hunter snare carcasses still need a complete recovery, processing and settlement-store delivery chain.
- Predator packs still need visible cross-region migration driven by prey depletion.
- Regional pricing is active for the internal merchant-purchase endpoint. Existing merchants must be provisioned in `merchant_catalog` with the correct region for regional pricing; if a merchant has no catalog region, the endpoint safely falls back to its base price.

## Validation
- Python backend syntax compilation: run with `python3 -m py_compile backend/app/main.py`.
- Static GDScript delimiter/resource-path checks and ZIP integrity are checked during packaging.
- Godot 4.7 runtime/editor executable is not available in this environment; no engine parse, launch, multiplayer playtest or in-game visual verification is claimed.
