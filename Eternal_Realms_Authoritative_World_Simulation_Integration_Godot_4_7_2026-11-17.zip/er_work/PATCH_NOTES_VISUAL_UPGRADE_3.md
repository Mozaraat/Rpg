# Eternal Realms — Dungeon & Monster Visual Upgrade 3

## Dungeon environment
- Added repeated ceiling ribs and layered stone caps to make the underground roof feel architectural.
- Added glowing floor rune inlays across selected rooms.
- Added wall-side rubble clusters for age, damage and environmental storytelling.
- Added a more imposing stone arch at the descent/boss approach.
- Added subtle drifting dust motes tinted to each floor's palette.
- Preserved the 100-floor maze layout, floor palettes, collision foundation and underground ceiling.

## Monsters
- Added species-specific visual dressing: wolf dorsal spines and brow plates, crawler shell plates and claws, bone rib details, imp horns and ember cores, void orbit shards, wisp rings, and armored humanoid pauldrons/crests.
- Details use per-species materials to improve silhouette and material contrast while preserving existing combat and loot logic.

## Validation
- ZIP archive integrity checked after packaging.
- Godot runtime/parser validation was not available in the build environment; open the project in Godot 4.6 and run the main scene to verify rendering and inspect the Output panel.
