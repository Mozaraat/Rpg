# Authoritative world replication and recovery baseline — 2026-11-17

## Base archive
`Eternal_Realms_Central_World_State_Persistence_Godot_4_7_2026-11-17.zip`

## Implemented
- Added a single revisioned shared-world snapshot replication path to `MMORPGWorldState`.
- Server-side world commits now mark the snapshot dirty and coalesce changes for a 0.5-second replication window instead of broadcasting on every individual key write.
- Authenticated peers receive the current shared-world snapshot after character identity is accepted.
- The server broadcasts committed snapshots to authenticated peers using reliable authority-only RPC; clients reject stale revisions and cannot originate this state update.
- Added an explicit `flush_central_writes()` drain method for deployment shutdown orchestration, while preserving queued retry behavior for transient PostgreSQL failures.
- Existing feature-specific replication (NPC society, wildlife, underwater, monsters, player characters) remains intact and can keep using optimized payloads. The generic snapshot is the common recovery baseline, not a replacement for those runtime representations.

## Important boundary
This is still not a certification of a production-ready MMORPG. The central PostgreSQL world-entity adapter remains the durable production path; local JSON remains development/offline only. A deployment supervisor must call and await `MMORPGWorldState.flush_central_writes()` before graceful process termination. A hard process kill cannot run a shutdown hook. The project still needs engine-level Godot 4.7 parsing/import, two-peer synchronization tests, PostgreSQL restart/hydration tests, and load/concurrency testing.
