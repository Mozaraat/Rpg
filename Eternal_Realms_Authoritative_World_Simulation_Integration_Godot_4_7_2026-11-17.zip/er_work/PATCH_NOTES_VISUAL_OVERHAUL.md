# Eternal Realms — Visual Overhaul Pass

## Scope
A procedural-only visual pass across terrain, vegetation, buildings, atmosphere and
time-of-day. No external textures, models or plugins were added; every surface is
still generated from code and shaders at load time.

## Validation
- Validated with Godot 4.6 stable (Forward+ / Vulkan).
- Headless boot of `res://scenes/main.tscn` completes with no parser, script or
  shader errors.
- Windowed QA captures reviewed at dawn, noon, dusk and night.
- Temporary screenshot autoload used for QA was removed before packaging.

## Terrain and ground
- Rewrote `shaders/terrain.gdshader` around layered procedural noise: macro biome
  patchiness, field-scale variation, clump detail and micro grain.
- Grass now has sun-bleached patches, darker clover patches, dry edges and
  distance-faded blade speckle instead of one flat green sheet.
- Reworked dirt paths and cobbled paving: smaller irregular setts, darker and
  warmer stone, low-contrast mortar, per-stone mineral variation and moss in the
  joints. The plaza no longer reads as a single bright white slab.
- Rock/cliff strata use broader, less stripey bands and darker base tones.
- Snow is no longer pure white. It mixes cold shadow tones with warm lit faces,
  breaks up with noise, exposes rock on wind-scoured ridges and receives stronger
  normal detail. This removes the "melted white blob" look on distant peaks.
- Cobble, snow and shoreline materials keep distinct roughness/specular response.

## Vegetation
- Rebuilt tree silhouettes in `systems/vegetation_kit.gd` with smaller opaque
  canopy cores for occlusion plus alpha-tested procedural leaf/needle cards for
  the actual silhouette.
- Added `shaders/leaf_card.gdshader` and procedural leaf/needle textures; cards
  receive wind, tint variation and translucency.
- Broadleaf, pine, redwood, willow, baobab, cherry and jungle trees now use
  crossed card clusters; conifers use radial needle sprays.
- Added procedural fern, reed, fallen log, stump and pebble meshes to the ground
  detail pass.
- Denser, thinner grass tufts with a natural green range instead of lime spikes.
- Added finer ground scatter and raised chunk detail resolution for closer
  ground cover.

## Bark and buildings
- Added `shaders/bark.gdshader`: brown fissured bark with ridges, plates and moss
  instead of the previous white-striped detail texture.
- Building shader stone/cobble patterns use lighter mortar, narrower seams and
  softer ambient occlusion; stone and cobble palettes were neutralised to remove
  blue casts.
- Roof, plaster, plank and thatch patterns keep metre-authored UVs so scale stays
  believable on every building size.

## Sky, water and lighting
- Rewrote the atmospheric sky shader (gradient, sun glow, clouds, stars).
- Reworked water shading with depth tint, Fresnel, ripples and shoreline foam.
- Retuned day/night exposure, fog colour and density per time of day; weather no
  longer stomps the cycle's fog settings.
- Added a cool `TwilightFill` directional light and reduced purple ambient so
  dusk reads as warm sunset light rather than a uniform magenta wash.
- Added a subtle character rim light.
- SSAO, SSR and SSIL remain gated behind the Cinematic quality tier (F10 cycles
  Low / Medium / High / Cinematic).

## World layout
- Reduced oversized tree scales across settlement and streamed chunks.
- Giant/hero trees are excluded from the immediate village sightline so bare
  trunks no longer dominate the sky above the plaza.
- Village shade trees were reduced to a believable size.
- Biome palette tuned toward muted, natural greens and earth tones.

## Controls
Unchanged. `F10` cycles graphics quality; `H` hides the HUD for clean captures.
