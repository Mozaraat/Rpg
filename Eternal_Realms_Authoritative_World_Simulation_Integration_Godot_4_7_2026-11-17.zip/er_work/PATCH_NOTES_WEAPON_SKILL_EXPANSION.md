# Weapon & Skill Expansion

- Added weapon mastery tracks for axes, daggers, spears, blunt weapons, archery, elemental magic and dual wielding.
- Added new active abilities unlocked by using each weapon family. The R ability queue now selects an ability matching the currently equipped weapon family.
- Added copper/iron/dungeon-tier axes, spears, hammers, bows, staves and paired daggers.
- Added per-family damage scaling, weapon-specific attack speeds, reach, ranged targeting for bows/staves and clearer weapon tooltips.
- Added forge/alchemy recipes for starter and advanced weapons, plus rare dungeon-boss drop chances for select relic weapons.
- Added local SVG inventory artwork for every newly introduced weapon.
- Existing saves remain compatible: missing skill values are initialized by the skill system when loading older skill dictionaries.

Godot runtime/parser testing was not available in this environment; please import and test in Godot 4.6.
