# Eternal Realms — Autonomous Dungeon Warfare (2026)

## Implemented
- Rival civilization patrols now spawn on each generated floor, using a different civilization profile from the local district defenders.
- Dungeon monsters periodically scan for nearby opposing-faction units on the same floor, pursue them, and exchange attacks with line-of-sight checks. Rescued expedition allies participate in the same combat loop against dungeon hostiles.
- Faction commanders call two reserve guards once their health falls below 48%, with a one-use-per-commander limit.
- Rescuing a prisoner now recruits a temporary allied fighter on the current floor rather than only awarding a narrative reward.
- Quartermasters now have a finite three-item stock and sell goods through the player's gold balance.
- Claiming a faction shrine records the floor's room owner as the player's expedition and changes the encounter's ownership state.

## Integration
The additions extend the existing Monster, DungeonSystem and DungeonFactionEncounter scripts. Existing dungeon generation, faction profiles, floor progression, bosses, exploration content and reward systems are retained.

## Verification limits
Static checks and archive integrity are run for this package. Godot 4.6 is not installed in this environment, so engine parsing, navigation/physics behaviour, runtime combat balance, persistence across reloads and UI interaction cannot be confirmed here. Faction combat currently uses proximity and line-of-sight rather than a full pathfinding squad-command system; it is a foundation for the next deeper warfare pass.
