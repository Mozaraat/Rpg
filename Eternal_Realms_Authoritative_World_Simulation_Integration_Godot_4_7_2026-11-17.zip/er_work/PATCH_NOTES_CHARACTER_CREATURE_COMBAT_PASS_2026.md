# Eternal Realms — Character, Creature & Combat Reliability Pass

## Combat input and hit resolution
- Added a physics-frame input polling path for the configured `attack` action. This catches clicks consumed by full-screen HUD Controls while still respecting `GameManager.input_locked` for menus and dialogue.
- Kept `_unhandled_input` as the normal gameplay path; the `can_attack` gate prevents duplicate input handling in the same frame.
- Added a generation-guarded attack-impact watchdog. If an animation impact signal is interrupted or missed, the attack resolves once through the existing combat pipeline; late animation signals cannot deal duplicate damage.
- Moved melee obstruction checks to torso height so low creatures such as slimes are not accidentally shielded by terrain contact at their feet.
- Increased baseline sword reach slightly while preserving individual weapon definitions and longer spear/ranged reach.
- Existing enemy groups, health components, damage pipeline, loot, quest progression and online server-authoritative request path are retained.

## Character and equipment presentation
- Added layered leather harness, belt pouch, trim seams, bracers and metal wrist cuffs to the procedural humanoid model.
- Added a narrow blade highlight, guard collar and pommel detail to the procedural sword visual.
- Because player and NPCs share `CharacterModel`, the detail pass improves both without changing their identity palettes, roles, schedules or dialogue.

## Existing six-part visual milestone
The project already contains procedural species-specific monster silhouettes, creature movement/combat animation, civilization-aware building materials and district generation, and extensive dungeon architecture and lighting. This pass preserves those systems. It is a foundation pass, not a claim that all six visual categories are finished or that bespoke AAA character/creature assets have been imported.

## Validation
- ZIP integrity and static resource-reference checks performed after packaging.
- Godot 4.7 executable is unavailable in this environment; editor import, GDScript parse, shader compile and in-game combat verification remain required.
