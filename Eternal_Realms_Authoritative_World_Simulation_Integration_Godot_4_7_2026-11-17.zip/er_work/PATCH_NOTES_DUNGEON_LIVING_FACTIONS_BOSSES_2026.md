# Eternal Realms — Living Dungeon Factions & Boss Counterplay (2026)

## Implemented
- Faction vanguard captains now receive a three-point patrol route inside their district; idle patrol movement follows those waypoints while normal aggro/combat behaviour remains in control during encounters.
- Every floor can generate a claimable faction-control shrine plus a side-branch encounter: a prisoner rescue, faction quartermaster, hidden leader's treaty cache, or rival-border skirmish event.
- Faction encounters use the existing interaction system, award floor-scaled supplies/relics/gold and skill training, and record discovery flags so resolved encounters do not respawn on a rebuilt floor.
- Raid guardians summon faction reinforcements when entering later phases (two at Phase III, three at the final phase), inheriting the guardian's faction and resistance profile.
- A player who avoids a raid guardian's telegraphed signature strike creates a four-second recovery window; attacks during that window deal 1.6x damage.
- Existing ten-civilization combat identities, dungeon architecture, secrets, traps, 100-floor progression and save fields are retained.

## Validation
- Static source scan: delimiter balance and duplicate top-level function checks passed.
- Literal `res://` reference scan found one existing dynamic-format path (`ui/ui_kit.gd`: `res://assets/items/%s.svg`), not a missing fixed asset reference.
- ZIP integrity checked after packaging.
- Godot 4.6 runtime is not installed in this environment; parser/import, gameplay, physics, AI and save/load runtime tests could not be performed.
