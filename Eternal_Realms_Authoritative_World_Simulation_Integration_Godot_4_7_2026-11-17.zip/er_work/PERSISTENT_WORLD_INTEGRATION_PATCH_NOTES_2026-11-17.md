# Eternal Realms — Persistent World Integration Repair Pass

Target: Godot 4.7 / FastAPI / PostgreSQL 16  
Baseline: `Eternal_Realms_Underwater_Persistent_World_Godot_4_7_2026-11-17.zip`

## Implemented in this pass

### 1. Central persistence interface and retry safety
- Extended `CentralBackend.server_save_world_entity()` with an automatic deterministic idempotency key (or an explicit key supplied by the caller).
- Added `server_load_world_entities(entity_kind, region_id)` so systems can hydrate shared records through one authenticated API interface.
- Added a service-authenticated backend listing endpoint for world entities, optionally filtered by entity kind and/or region.
- Added PostgreSQL idempotency records for generic world-entity mutations. Writes serialize duplicate idempotency keys and concurrent writes to the same entity with transaction-scoped advisory locks.
- Existing revision checks remain optimistic and per entity. New entities must start at revision zero; successful updates increment the revision.

### 2. Underwater hydration and revision repair
- Underwater sites now hydrate from PostgreSQL before the production server generates nearby sites.
- If production hydration fails or the backend is not configured, procedural site generation is blocked rather than risking replacement of persistent discoveries.
- Each underwater site now tracks its own database revision. The previous shared revision counter is retained only for legacy local-save compatibility and is no longer sent to the server.
- Resource depletion, treasure claims, boss defeat state and aquatic population state are stored together in the site entity snapshot.
- Per-site writes are serialized, queued while a write is in flight, and retried after failure. The exact failed payload is retained so retry idempotency keys remain stable.
- Underwater state snapshots are synchronized to connected clients and sent to newly joining peers.

### 3. Dungeon progression
- Dungeon floor-clear writes now use the revision loaded for that individual floor/boss record instead of always sending revision zero.
- Dungeon discovery flags now hydrate from and save to a shared-world entity. Discovery snapshots are synchronized to joining peers.
- Failed discovery saves remain queued and retry after a delay.

### 4. Character progression hydration
- Skill, technique-discovery, trait-discovery and practice data are no longer stripped from the authoritative character snapshot before saving.
- The server sends the character's authoritative quest snapshot after successful join-ticket validation, alongside the existing character and inventory restoration flow.
- Inventory, equipment and currency continue to use their transactional backend endpoints rather than being copied into the character snapshot.

### 5. Database deployment
- Docker Compose now mounts the underwater migration, regional merchant pricing migration and new world-entity idempotency migration for fresh PostgreSQL volumes.
- Backend documentation now lists the migration sequence and explicitly warns operators to apply only missing migrations to existing databases.

## Files changed

- `autoload/central_backend.gd`
- `autoload/mmorpg_network.gd`
- `systems/underwater_exploration.gd`
- `systems/dungeon_system.gd`
- `backend/app/main.py`
- `backend/deploy/docker-compose.yml`
- `backend/README.md`
- `backend/postgres/006_world_entity_idempotency.sql`

## Existing connected systems retained

- NPC society/families/businesses use the existing shared `npc_society` world entity and revision path.
- Regional wildlife populations and territory state use the existing dedicated bulk APIs and restore paths.
- Hydrology and regional ecology use the existing world-entity load/save paths.
- Boss encounters and dungeon clears use the existing boss encounter persistence tables.
- Merchant stock, player inventory, equipment, quests and currency continue to use the existing transactional APIs.

## Validation performed

- Python backend source compiled with `python -m py_compile`.
- Backend source parsed successfully with Python AST.
- Docker Compose YAML parsed successfully.
- ZIP archive integrity checked successfully (`unzip -t`).
- Comment-aware delimiter/string scan completed with zero findings across GDScript files.
- Duplicate GDScript function-name scan completed with zero duplicate declarations.
- Resource path scan found only `res://captures/...` output paths referenced by capture/validation tooling; these are generated output destinations, not missing runtime assets.

## Not verified in this environment

- Godot 4.7 executable/editor was not installed; no actual Godot import, parser run, scene launch or playtest was possible.
- Docker was not installed and the Python environment lacked `psycopg`; PostgreSQL migrations were not applied and no live database transaction, restart, backup/restore or multiplayer round-trip test was performed.
- The generic entity API and persistence changes require deployment of migration `006_world_entity_idempotency.sql` before the new entity-save calls can succeed on an existing database.
- Skill progression is now persisted but skill-value anti-cheat validation remains a separate server-authority hardening task.
- The underwater site data is persisted in `world_entities`; the dedicated underwater claims/population tables remain available schema foundations but are not yet independently written by the current Godot adapter.
- Full network-latency, concurrent-player race, long-duration ecology and crash-recovery testing remains outstanding.
