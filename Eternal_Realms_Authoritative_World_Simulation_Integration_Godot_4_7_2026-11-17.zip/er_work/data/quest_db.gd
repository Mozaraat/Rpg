# QuestDB - static quest definitions.
# Objective types: kill (target = enemy kind), collect (item id), craft (item id),
#                  talk (npc name), visit (zone name)
class_name QuestDB
extends RefCounted

const QUESTS: Dictionary = {
	"q_arrival": {
		"title": "A Strange Arrival", "giver": "Old Man Thoren", "turn_in": "Elara", "prereq": [],
		"summary": "Thoren senses something odd about you. Speak with Elara in the plaza.",
		"objectives": [{"type": "talk", "target": "Elara", "count": 1, "text": "Speak with Elara"}],
		"offer": ["You arrived under strange stars, little one...", "Go and speak with Elara in the plaza. She will help you find your feet."],
		"progress": ["Elara waits in the plaza, near the fountain."],
		"complete": ["Thoren sent you? He always did have a feel for these things.", "Take this. A traveller should never walk empty-handed."],
		"rewards": {"gold": 30, "items": [{"id": "healing_potion", "count": 2}], "skills": {"exploration": 0.5}},
	},
	"q_slimes": {
		"title": "Slime Trouble", "giver": "Elara", "turn_in": "Elara", "prereq": ["q_arrival"],
		"summary": "Slimes are creeping into the fields. Defeat 3 of them.",
		"objectives": [{"type": "kill", "target": "slime", "count": 3, "text": "Defeat slimes"}],
		"offer": ["The slimes keep trampling the fields.", "Could you thin them out? Three should do. Take care, they bite!"],
		"progress": ["Three slimes, remember. Mind their wind-up before they strike."],
		"complete": ["You did it! The fields are safe, for now.", "Here, you've earned this."],
		"rewards": {"gold": 45, "items": [{"id": "healing_potion", "count": 1}], "skills": {"swordsmanship": 0.8, "precision": 0.4}, "title": "Slime Slayer", "reputation": {"elyndor": 5}},
	},
	"q_ore": {
		"title": "Ore for the Forge", "giver": "Gorrim the Smith", "turn_in": "Gorrim the Smith", "prereq": ["q_arrival"],
		"summary": "Gorrim needs iron ore. Mine 4 pieces from the rocky outcrops in the hills.",
		"objectives": [{"type": "collect", "target": "iron_ore", "count": 4, "text": "Collect Iron Ore"}],
		"offer": ["Hah, a new face! I'm Gorrim. My stock of ore ran dry weeks ago.", "Find me four pieces of iron ore. Look for rust-streaked rocks in the hills and mountains."],
		"progress": ["Four pieces of iron ore. The rust-streaked rocks in the hills are your best bet."],
		"complete": ["Fine ore! You've got an eye for it.", "Keep the ore if you like. I'll teach you to use it."],
		"rewards": {"gold": 35, "items": [], "skills": {"mining": 1.0}, "keep_items": true, "reputation": {"elyndor": 4}},
	},
	"q_blade": {
		"title": "Forge Your Blade", "giver": "Gorrim the Smith", "turn_in": "Gorrim the Smith", "prereq": ["q_ore"],
		"summary": "Smelt 3 iron ingots and forge your own Iron Sword at Gorrim's forge.",
		"objectives": [
			{"type": "craft", "target": "iron_ingot", "count": 3, "text": "Smelt Iron Ingots"},
			{"type": "craft", "target": "iron_sword", "count": 1, "text": "Forge an Iron Sword"},
		],
		"offer": ["Now the real work. Two ore make an ingot; three ingots and a log make a sword.", "Use my forge. Each try teaches you, even the failures. Maybe you'll roll something rare."],
		"progress": ["Smelt three ingots, then forge the sword. You need a wood log too."],
		"complete": ["Your first blade! Rough, but it's yours.", "Every great smith started exactly here."],
		"rewards": {"gold": 60, "items": [], "skills": {"smithing": 2.0}, "title": "Apprentice Smith", "reputation": {"elyndor": 4}},
	},
	"q_herbs": {
		"title": "Herbal Remedy", "giver": "Elara", "turn_in": "Elara", "prereq": ["q_slimes"],
		"summary": "Gather 4 Moonpetal and brew 2 Healing Potions at the alchemy table.",
		"objectives": [
			{"type": "collect", "target": "moonpetal", "count": 4, "text": "Gather Moonpetal"},
			{"type": "craft", "target": "healing_potion", "count": 2, "text": "Brew Healing Potions"},
		],
		"offer": ["Moonpetal glows at night, in the meadows and woods.", "Bring me four, and brew potions at the alchemy table by the well. Slime gel helps bind them."],
		"progress": ["Moonpetal glows after dark. Slime gel binds the brew."],
		"complete": ["Lovely work! Potions like these save lives.", "Take this for your trouble."],
		"rewards": {"gold": 55, "items": [], "skills": {"alchemy": 2.0, "herbalism": 1.0}, "title": "Herb Gatherer", "reputation": {"elyndor": 4}},
	},
	"q_timber": {
		"title": "Timber for Borin", "giver": "Borin", "turn_in": "Borin", "prereq": [],
		"summary": "Chop 5 wood logs from the trees in the woods.",
		"objectives": [{"type": "collect", "target": "wood_log", "count": 5, "text": "Collect Wood Logs"}],
		"offer": ["My fence needs mending and my axe is lost somewhere in the barley.", "Five good logs from the woods, and I'll make it worth your while."],
		"progress": ["Five logs. The woods west of the village are thick with trees."],
		"complete": ["Fine logs! Fence will be good as new.", "Here, for the trouble."],
		"rewards": {"gold": 40, "items": [], "skills": {"woodcutting": 1.5}},
	},
	"q_spire": {
		"title": "The Spire's Invitation", "giver": "Old Man Thoren", "turn_in": "Archmage Lira", "prereq": ["q_slimes"],
		"summary": "Make the long journey to the remote Frostveil crossing and find Archmage Lira at the Arcane Spire.",
		"objectives": [
			{"type": "visit", "target": "Arcane Spire", "count": 1, "text": "Reach the Arcane Spire"},
			{"type": "talk", "target": "Archmage Lira", "count": 1, "text": "Speak with Archmage Lira"},
		],
		"offer": ["You handle yourself well now. The Spire has noticed.", "The Spire lies far beyond the western wilds, past the old mountain road and the narrow Frostveil causeway. Archmage Lira will want to meet you."],
		"progress": ["Keep to the old road where you can. The mountain passes and the Frostveil crossing are not safe after dark."],
		"complete": ["So you're the one the Spire whispered about.", "Welcome. You will find our door open to you."],
		"rewards": {"gold": 90, "items": [], "skills": {"exploration": 3.0}, "title": "Spire Initiate", "reputation": {"arcane_spire": 8}},
	},

	"q_king_slime": {
		"title": "The Gelatin King", "giver": "Elara", "turn_in": "Elara", "prereq": ["q_slimes"],
		"summary": "A King Slime has been sighted. Defeat it.",
		"objectives": [{"type": "kill", "target": "king_slime", "count": 1, "text": "Defeat the King Slime"}],
		"offer": ["Travellers speak of a vast slime near the eastern flats.", "If it reaches the fields, we are lost. Bring it down, and Elyndor will remember you."],
		"progress": ["Seek the King Slime in the wilds east of the village."],
		"complete": ["The King has fallen! The meadows breathe again.", "Take this — and our thanks."],
		"rewards": {"gold": 100, "items": [{"id": "royal_slime_gel", "count": 1}], "skills": {"swordsmanship": 1.5}, "title": "Slime Slayer"},
	},
	"q_alpha_wolf": {
		"title": "Hunt the Alpha", "giver": "Old Man Thoren", "turn_in": "Old Man Thoren", "prereq": ["q_king_slime"],
		"summary": "An Alpha Wolf claims the woods. End its reign.",
		"objectives": [{"type": "kill", "target": "alpha_wolf", "count": 1, "text": "Defeat the Alpha Wolf"}],
		"offer": ["Something older than common wolves howls at dusk.", "Find the Alpha. Bring peace to the treeline."],
		"progress": ["The Alpha hunts in the woods beyond Elyndor."],
		"complete": ["So the Alpha falls... The woods will quiet for a time.", "You walk a hard path, child."],
		"rewards": {"gold": 130, "items": [{"id": "alpha_fang", "count": 1}], "skills": {"swordsmanship": 1.2, "exploration": 0.8}},
	},
	"q_warlord": {
		"title": "Warlord of the Road", "giver": "Gorrim the Smith", "turn_in": "Gorrim the Smith", "prereq": ["q_alpha_wolf"],
		"summary": "Defeat the Bandit Warlord threatening the Old Road.",
		"objectives": [{"type": "kill", "target": "bandit_warlord", "count": 1, "text": "Defeat the Bandit Warlord"}],
		"offer": ["Caravans won't move while that warlord lives.", "Put him down. Bring his badge if you can."],
		"progress": ["The Warlord rides the Old Road. Stay sharp."],
		"complete": ["Ha! The road is open again. You're tougher than you look."],
		"rewards": {"gold": 160, "items": [{"id": "captain_badge", "count": 1}], "skills": {"smithing": 1.0, "swordsmanship": 1.5}, "title": "Unyielding", "reputation": {"elyndor": 12, "bandits": -8}},
	},
	"q_cores": {
		"title": "Cores of Power", "giver": "Archmage Lira", "turn_in": "Archmage Lira", "prereq": ["q_spire"],
		"summary": "Bring Lira 2 Slime Cores. Strong slimes sometimes carry them.",
		"objectives": [{"type": "collect", "target": "slime_core", "count": 2, "text": "Collect Slime Cores"}],
		"offer": ["Slime cores hold raw arcane energy. I need two for an experiment.", "Defeat slimes in the wilds. A core drops now and then. In return, I will enchant a blade for you."],
		"progress": ["Two slime cores. Slimes in the wilds carry them now and then."],
		"complete": ["Marvellous! The energy in these is extraordinary.", "As promised: a blade worth carrying."],
		"rewards": {"gold": 120, "items": [{"id": "iron_sword", "count": 1, "grade": 3}], "skills": {"swordsmanship": 2.0}, "title": "Core Hunter", "reputation": {"arcane_spire": 6}},
	},
	"q_mountain_wake": {
		"title": "The Mountain's Wake", "giver": "Gorrim the Smith", "turn_in": "Gorrim the Smith", "prereq": ["q_ore"],
		"summary": "Stone crawlers are breaking loose from the Ironback slopes. Defeat 3 and bring back their chitin.",
		"objectives": [
			{"type": "kill", "target": "stone_crawler", "count": 3, "text": "Defeat Stone Crawlers"},
			{"type": "collect", "target": "chitin", "count": 2, "text": "Recover crawler chitin"},
		],
		"offer": ["The Ironback slopes have started to rumble. Stone crawlers are coming down toward the ore paths.", "Thin their numbers and bring me two pieces of chitin. I want to see what makes their shells so hard."],
		"progress": ["Stone crawlers favour the rocky slopes north-west of the village. Watch for their plated backs."],
		"complete": ["Solid stuff. This will make excellent reinforcement for armour.", "Take your pay. You have done the mountain folk a service."],
		"rewards": {"gold": 110, "items": [{"id": "iron_ore", "count": 3}], "skills": {"mining": 1.5, "exploration": 1.0}},
	},

	"q_heartlands_provisions": {
		"title": "Provisions for the Heartlands", "giver": "Elara", "turn_in": "Elara", "prereq": ["q_arrival"],
		"summary": "Help the village prepare for the changing season by gathering fish and timber, then craft a healing potion.",
		"objectives": [
			{"type": "collect", "target": "fish_trout", "count": 2, "text": "Bring in two river trout"},
			{"type": "collect", "target": "wood_log", "count": 3, "text": "Gather three sound logs"},
			{"type": "craft", "target": "healing_potion", "count": 1, "text": "Prepare a healing potion"}
		],
		"offer": ["The village stores are running thin, and the river has been generous this week.", "Bring two trout and three good logs, then prepare a healing potion for the field wardens. It will teach you how the village depends on the land."],
		"progress": ["Two trout, three logs, and one healing potion. The market and the alchemy table can help you prepare."],
		"complete": ["Just what we needed. The fish will feed the workers, the timber will mend the storehouse, and the potion will go to the patrol.", "You are beginning to understand what keeps a settlement alive."],
		"rewards": {"gold": 85, "items": [{"id": "healing_potion", "count": 1}], "skills": {"fishing": 0.8, "woodcutting": 0.8, "alchemy": 0.8}, "reputation": {"elyndor": 7}}
	},
	"q_heartlands_wayfarer": {
		"title": "The Heartlands Wayfarer", "giver": "Old Man Thoren", "turn_in": "Old Man Thoren", "prereq": ["q_spire"],
		"summary": "Visit the Whispering Woods, Mirrorwater Basin, and Ironback Range to record their old paths.",
		"objectives": [
			{"type": "visit", "target": "Whispering Woods", "count": 1, "text": "Explore the Whispering Woods"},
			{"type": "visit", "target": "Mirrorwater Basin", "count": 1, "text": "Explore Mirrorwater Basin"},
			{"type": "visit", "target": "Ironback Range", "count": 1, "text": "Explore the Ironback Range"}
		],
		"offer": ["The old roads are more than paths. They are the memory of this land.", "Walk the woods, follow the water, and climb the Ironback foothills. Let the land teach you its shape."],
		"progress": ["The woods, the basin, and the Ironback foothills each hold a piece of Elyndor's story."],
		"complete": ["You have seen the Heartlands with your own eyes. That knowledge will serve you better than any map bought in a market.", "Take this field compass. The deeper roads are waiting."],
		"rewards": {"gold": 120, "items": [{"id": "mana_crystal", "count": 1}], "skills": {"exploration": 2.0, "knowledge": 1.0}, "title": "Pathfinder", "reputation": {"elyndor": 8}}
	},
	"q_expedition_supplies": {
		"title": "Supplies for the Descent", "giver": "Gorrim the Smith", "turn_in": "Gorrim the Smith", "prereq": ["q_heartlands_wayfarer"],
		"summary": "Prepare three iron ingots and two healing potions before attempting the dungeon depths.",
		"objectives": [
			{"type": "craft", "target": "iron_ingot", "count": 3, "text": "Smelt three iron ingots"},
			{"type": "craft", "target": "healing_potion", "count": 2, "text": "Prepare two healing potions"}
		],
		"offer": ["The dungeon takes more than courage. It takes sound steel and enough medicine to bring you home.", "Smelt three ingots and prepare two healing potions. I will check your kit before you take the descent."],
		"progress": ["Three iron ingots and two healing potions. Do not mistake a quick trip below for a safe one."],
		"complete": ["Good. You have the beginnings of a proper expedition kit.", "The dungeon entrance is no place for an unprepared traveller."],
		"rewards": {"gold": 150, "items": [{"id": "iron_ingot", "count": 2}], "skills": {"smithing": 1.5, "alchemy": 1.0}, "reputation": {"elyndor": 10}}
	},

	"q_tide_below": {
		"title": "The Tide Below", "giver": "Elara", "turn_in": "Elara", "prereq": ["q_spire"],
		"summary": "Investigate the strange high tides and defeat the Tide Serpent.",
		"objectives": [
			{"type": "visit", "target": "Mirror Pond", "count": 1, "text": "Investigate Mirror Pond"},
			{"type": "kill", "target": "tide_serpent", "count": 1, "text": "Defeat the Tide Serpent"},
		],
		"offer": ["The water has been rising without rain. Fisherfolk say something enormous circles below the surface.", "Go to Mirror Pond and find the source. Do not underestimate anything that can command the tide."],
		"progress": ["Follow the shore and watch the water. The serpent is drawn to the high tide."],
		"complete": ["The water has settled. The fishers can return to their boats.", "You have our thanks — and a little something from the stores."],
		"rewards": {"gold": 180, "items": [{"id": "serpent_scale", "count": 2}], "skills": {"fishing": 1.5, "exploration": 1.5}, "title": "Tidewalker", "reputation": {"elyndor": 10, "wilderness": 4}},
	},
}

const TITLES: Dictionary = {
	"Slime Slayer": {"desc": "+8% damage", "dmg": 0.08},
	"Apprentice Smith": {"desc": "Better crafting grade odds", "grade": 6.0},
	"Herb Gatherer": {"desc": "+10% gathering success", "gather": 0.10},
	"Spire Initiate": {"desc": "+10 max health", "hp": 10.0},
	"Core Hunter": {"desc": "+5% critical chance", "crit": 0.05},
	"Tidewalker": {"desc": "+8% fishing yield", "fishing": 0.08},
	"Pathfinder": {"desc": "+6% movement speed", "speed": 0.06},
	"Overgeared": {"desc": "+12% damage, +10 max health", "dmg": 0.12, "hp": 10.0},
	"Unyielding": {"desc": "+20 max health", "hp": 20.0},

}

const ZONES: Array = [
	{"name": "Elyndor Village", "pos": Vector2(-25, -30), "radius": 38.0},
	{"name": "Arcane Spire", "pos": Vector2(-250, -200), "radius": 30.0},
	{"name": "Sunlit Meadows", "pos": Vector2(12, -25), "radius": 22.0},
	{"name": "Whispering Woods", "pos": Vector2(-62, -12), "radius": 26.0},
	{"name": "Mirror Pond", "pos": Vector2(47, -9), "radius": 14.0},
	{"name": "Ironback Mountains", "pos": Vector2(-55, -98), "radius": 34.0},
	{"name": "Lonely Lake", "pos": Vector2(2, -93), "radius": 16.0},
]
