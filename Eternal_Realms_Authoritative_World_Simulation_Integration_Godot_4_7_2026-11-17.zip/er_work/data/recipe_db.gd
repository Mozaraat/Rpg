# RecipeDB - crafting recipes per station.
# Success chance rises with skill; failures still teach a little (Entropia-style) but cost materials.
class_name RecipeDB
extends RefCounted

const RECIPES: Dictionary = {
	"smelt_iron": {"name": "Smelt Iron Ingot", "station": "forge", "skill": "smithing", "min": 0.0,
		"inputs": {"iron_ore": 2}, "output": "iron_ingot", "count": 1, "base": 0.90, "gain": 0.30},
	"forge_iron_sword": {"name": "Forge Iron Sword", "station": "forge", "skill": "smithing", "min": 1.0,
		"inputs": {"iron_ingot": 3, "wood_log": 1}, "output": "iron_sword", "count": 1, "base": 0.62, "gain": 0.80},
	"forge_iron_chestplate": {"name": "Forge Iron Chestplate", "station": "forge", "skill": "smithing", "min": 4.0,
		"inputs": {"iron_ingot": 6, "wood_log": 1}, "output": "iron_chestplate", "count": 1, "base": 0.50, "gain": 1.10},
	"brew_healing": {"name": "Brew Healing Potion", "station": "alchemy", "skill": "alchemy", "min": 0.0,
		"inputs": {"moonpetal": 2, "slime_gel": 1}, "output": "healing_potion", "count": 2, "base": 0.80, "gain": 0.40},
	"smelt_copper": {"name": "Smelt Copper Ingot", "station": "forge", "skill": "smithing", "min": 0.0,
		"inputs": {"copper_ore": 2}, "output": "copper_ingot", "count": 1, "base": 0.92, "gain": 0.25},
	"smelt_silver": {"name": "Refine Silver Ingot", "station": "forge", "skill": "smithing", "min": 5.0, "inputs": {"silver_ore": 2}, "output": "silver_ingot", "count": 1, "base": 0.72, "gain": 0.65},
	"smelt_gold": {"name": "Refine Gold Ingot", "station": "forge", "skill": "smithing", "min": 8.0, "inputs": {"gold_ore": 2}, "output": "gold_ingot", "count": 1, "base": 0.58, "gain": 0.85},
	"craft_redwood_longbow": {"name": "Craft Elder Redwood Longbow", "station": "forge", "skill": "smithing", "min": 8.0, "inputs": {"redwood_heartwood": 3, "silver_ingot": 2, "leather_strip": 2}, "output": "redwood_longbow", "count": 1, "base": 0.52, "gain": 1.0},
	"brew_glowcap_tonic": {"name": "Brew Glowcap Tonic", "station": "alchemy", "skill": "alchemy", "min": 2.0, "inputs": {"glowcap": 2, "wild_berries": 2, "moonpetal": 1}, "output": "healing_potion", "count": 2, "base": 0.72, "gain": 0.6},
	"leather_strip": {"name": "Cut Leather Strips", "station": "forge", "skill": "smithing", "min": 0.0,
		"inputs": {"wolf_pelt": 1}, "output": "leather_strip", "count": 2, "base": 0.88, "gain": 0.20},
	"fang_dagger": {"name": "Fang Dagger", "station": "forge", "skill": "smithing", "min": 2.0,
		"inputs": {"wolf_fang": 3, "leather_strip": 1}, "output": "fang_dagger", "count": 1, "base": 0.65, "gain": 0.70},
	"wolf_leather": {"name": "Wolf Leather Armor", "station": "forge", "skill": "smithing", "min": 3.0,
		"inputs": {"wolf_pelt": 4, "leather_strip": 2}, "output": "wolf_leather", "count": 1, "base": 0.55, "gain": 0.90},
	"make_rod": {"name": "Craft Fishing Rod", "station": "forge", "skill": "smithing", "min": 0.0,
		"inputs": {"wood_log": 2, "leather_strip": 1}, "output": "fishing_rod", "count": 1, "base": 0.85, "gain": 0.35},
	"cook_trout": {"name": "Cook Trout", "station": "campfire", "skill": "cooking", "min": 0.0,
		"inputs": {"fish_trout": 1, "moonpetal": 1}, "output": "cooked_trout", "count": 1, "base": 0.85, "gain": 0.30},
	"cook_bass": {"name": "Cook Bass", "station": "campfire", "skill": "cooking", "min": 0.5,
		"inputs": {"fish_bass": 1, "moonpetal": 1}, "output": "cooked_bass", "count": 1, "base": 0.80, "gain": 0.35},
	"fish_stew": {"name": "Fish Stew", "station": "campfire", "skill": "cooking", "min": 1.5,
		"inputs": {"fish_trout": 1, "fish_bass": 1, "seaweed": 1}, "output": "fish_stew", "count": 1, "base": 0.70, "gain": 0.55},
	"royal_potion": {"name": "Royal Slime Tonic", "station": "alchemy", "skill": "alchemy", "min": 5.0,
		"inputs": {"royal_slime_gel": 1, "slime_core": 1, "moonpetal": 2}, "output": "healing_potion", "count": 5, "base": 0.60, "gain": 1.20},
	"enchant_blade": {"name": "Mana-Edge Rune", "station": "alchemy", "skill": "enchanting", "min": 3.0,
		"inputs": {"mana_crystal": 2, "ectoplasm": 1, "iron_ingot": 1}, "output": "iron_sword", "count": 1, "base": 0.45, "gain": 1.0},

	"forge_copper_axe": {"name": "Forge Copper Hatchet", "station": "forge", "skill": "smithing", "min": 0.5, "inputs": {"copper_ingot": 2, "wood_log": 1}, "output": "copper_axe", "count": 1, "base": 0.78, "gain": 0.45},
	"forge_ash_spear": {"name": "Forge Ashwood Spear", "station": "forge", "skill": "smithing", "min": 0.5, "inputs": {"iron_ingot": 1, "wood_log": 2}, "output": "ash_spear", "count": 1, "base": 0.76, "gain": 0.5},
	"forge_stone_maul": {"name": "Forge Stone Maul", "station": "forge", "skill": "smithing", "min": 1.0, "inputs": {"iron_ore": 3, "wood_log": 2}, "output": "stone_maul", "count": 1, "base": 0.7, "gain": 0.55},
	"craft_shortbow": {"name": "Craft Hunter's Shortbow", "station": "forge", "skill": "smithing", "min": 1.0, "inputs": {"wood_log": 3, "leather_strip": 2}, "output": "shortbow", "count": 1, "base": 0.72, "gain": 0.55},
	"craft_apprentice_staff": {"name": "Craft Apprentice Staff", "station": "forge", "skill": "smithing", "min": 1.5, "inputs": {"wood_log": 2, "mana_crystal": 1}, "output": "apprentice_staff", "count": 1, "base": 0.68, "gain": 0.65},
	"forge_iron_battleaxe": {"name": "Forge Iron Battleaxe", "station": "forge", "skill": "smithing", "min": 4.0, "inputs": {"iron_ingot": 5, "wood_log": 2, "leather_strip": 1}, "output": "iron_battleaxe", "count": 1, "base": 0.55, "gain": 0.9},
	"forge_iron_lance": {"name": "Forge Iron Lance", "station": "forge", "skill": "smithing", "min": 4.0, "inputs": {"iron_ingot": 3, "wood_log": 2}, "output": "iron_lance", "count": 1, "base": 0.58, "gain": 0.85},
	"forge_iron_warhammer": {"name": "Forge Iron Warhammer", "station": "forge", "skill": "smithing", "min": 5.0, "inputs": {"iron_ingot": 6, "wood_log": 2}, "output": "iron_warhammer", "count": 1, "base": 0.5, "gain": 1.0},
	"forge_paired_fangs": {"name": "Forge Paired Fang Daggers", "station": "forge", "skill": "smithing", "min": 4.0, "inputs": {"wolf_fang": 5, "leather_strip": 2, "iron_ingot": 1}, "output": "paired_fang_daggers", "count": 1, "base": 0.56, "gain": 0.9},
	"forge_deepforged_cleaver": {"name": "Forge Deepforged Cleaver", "station": "forge", "skill": "smithing", "min": 18.0, "inputs": {"moonstone_ore": 4, "dragonbone": 1, "iron_ingot": 5}, "output": "deepforged_cleaver", "count": 1, "base": 0.32, "gain": 1.8},
	"forge_tidecaller_trident": {"name": "Forge Tidecaller Trident", "station": "forge", "skill": "smithing", "min": 18.0, "inputs": {"ancient_scale": 2, "tide_fang": 2, "iron_ingot": 4}, "output": "tidecaller_trident", "count": 1, "base": 0.34, "gain": 1.8},
	"forge_catacomb_breaker": {"name": "Forge Catacomb Breaker", "station": "forge", "skill": "smithing", "min": 22.0, "inputs": {"dragonbone": 2, "abyssal_chitin": 4, "moonstone_ore": 3}, "output": "catacomb_breaker", "count": 1, "base": 0.28, "gain": 2.0},
	"enchant_voidweaver_staff": {"name": "Shape Voidweaver Staff", "station": "alchemy", "skill": "enchanting", "min": 20.0, "inputs": {"heart_of_depths": 1, "runebound_core": 2, "voidsilk": 3}, "output": "voidweaver_staff", "count": 1, "base": 0.3, "gain": 2.2},
	"craft_prism_longbow": {"name": "Craft Prism Longbow", "station": "forge", "skill": "smithing", "min": 20.0, "inputs": {"prism_shard": 5, "moonstone_ore": 3, "voidsilk": 2}, "output": "prism_longbow", "count": 1, "base": 0.3, "gain": 2.0},
	"enchant_rune_wand": {"name": "Shape Runescribe Wand", "station": "alchemy", "skill": "enchanting", "min": 6.0, "inputs": {"mana_crystal": 3, "rune_fragment": 2, "wood_log": 1}, "output": "rune_wand", "count": 1, "base": 0.58, "gain": 1.1},
	"forge_ember_staff": {"name": "Forge Emberstaff", "station": "alchemy", "skill": "enchanting", "min": 8.0, "inputs": {"cinder_core": 3, "mana_crystal": 3, "wood_log": 2}, "output": "ember_staff", "count": 1, "base": 0.5, "gain": 1.3},
}


static func for_station(station: String) -> Array:
	var out: Array = []
	for id in RECIPES.keys():
		if RECIPES[id]["station"] == station:
			out.append(id)
	return out

static func success_chance(recipe_id: String, skill_value: float) -> float:
	var r: Dictionary = RECIPES[recipe_id]
	return clampf(float(r["base"]) + (skill_value - float(r["min"])) * 0.02, 0.10, 0.98)
