# Simple data for NPCs in the starting area
class_name NPCData
extends Resource

@export var npc_name: String = "Villager"
@export var role: String = "villager"  # villager, farmer, mage, elder
@export var dialogue: PackedStringArray = []
@export var can_give_quest: bool = false
