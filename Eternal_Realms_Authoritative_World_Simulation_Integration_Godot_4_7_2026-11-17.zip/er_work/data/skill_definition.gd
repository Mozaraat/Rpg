# Data definition for a skill
class_name SkillDefinition
extends Resource

@export var id: String = ""
@export var display_name: String = ""
@export var description: String = ""
@export var max_level: int = 50
@export var base_xp_to_level: float = 100.0
@export var xp_growth: float = 1.35  # multiplier per level
