# ItemDB - static item definitions + helpers.
# Item *instances* are plain Dictionaries: {"id", "count", "grade", "dur"}.
# Grades (Normal -> Legendary) multiply an item's stats - the "Grid" of this game.
class_name ItemDB
extends RefCounted

const GRADES: Array = [
	{"name": "Normal", "color": Color(0.82, 0.82, 0.84), "mult": 1.0},
	{"name": "Fine", "color": Color(0.45, 0.88, 0.50), "mult": 1.15},
	{"name": "Rare", "color": Color(0.42, 0.68, 1.00), "mult": 1.35},
	{"name": "Unique", "color": Color(0.78, 0.48, 1.00), "mult": 1.70},
	{"name": "Epic", "color": Color(1.00, 0.66, 0.22), "mult": 2.20},
	{"name": "Legendary", "color": Color(1.00, 0.32, 0.28), "mult": 3.00},
]

const TYPE_COLORS: Dictionary = {
	"material": Color(0.35, 0.42, 0.52),
	"weapon": Color(0.55, 0.30, 0.30),
	"armor": Color(0.30, 0.42, 0.58),
	"consumable": Color(0.30, 0.52, 0.36),
}

const ITEMS: Dictionary = {
	# --- Materials ---
	"iron_ore": {"name": "Iron Ore", "type": "material", "value": 6, "stack": 99, "glyph": "Fe",
		"desc": "Heavy, rust-flecked ore. Smelt it at a forge."},
	"iron_ingot": {"name": "Iron Ingot", "type": "material", "value": 15, "stack": 99, "glyph": "In",
		"desc": "A bar of smelted iron. The start of every good blade."},
	"wood_log": {"name": "Wood Log", "type": "material", "value": 4, "stack": 99, "glyph": "Wd",
		"desc": "A sturdy log. Handles, hafts and fuel."},
	"moonpetal": {"name": "Moonpetal", "type": "material", "value": 8, "stack": 99, "glyph": "Mp",
		"desc": "A pale flower that glows softly at night. Alchemists prize it."},
	"peat": {"name": "Peat Moss", "type": "material", "value": 5, "stack": 99, "glyph": "Pt", "desc": "Dense marsh fuel and soil amendment."},
	"cactus_fiber": {"name": "Cactus Fiber", "type": "material", "value": 9, "stack": 99, "glyph": "Cf", "desc": "Tough desert fiber used for bindings."},
	"obsidian_shard": {"name": "Obsidian Shard", "type": "material", "value": 22, "stack": 99, "glyph": "Ob", "desc": "Sharp volcanic glass."},
	"rare_orchid": {"name": "Marsh Orchid", "type": "material", "value": 32, "stack": 30, "glyph": "Or", "desc": "A rare flower from deep wetlands."},
	"amber_resin": {"name": "Amber Resin", "type": "material", "value": 18, "stack": 99, "glyph": "Ar", "desc": "Golden resin gathered from ancient trees."},
	"moonberry_preserve": {"name": "Moonberry Preserve", "type": "consumable", "value": 28, "stack": 20, "glyph": "Mb", "heal": 32.0, "desc": "A sweet preserve discovered through cooking experiments."},
	"slime_gel": {"name": "Slime Gel", "type": "material", "value": 3, "stack": 99, "glyph": "Gl",
		"desc": "Sticky, faintly warm. Good alchemical binder."},
	"slime_core": {"name": "Slime Core", "type": "material", "value": 40, "stack": 99, "glyph": "Co",
		"desc": "A dense glowing core. Arcane scholars pay well for these."},
	# --- Farming, husbandry and settlement production ---
	"wheat_seed": {"name": "Wheat Seeds", "type": "material", "value": 2, "stack": 99, "glyph": "Ws", "desc": "Plant in prepared soil. Water and tend until ripe."},
	"carrot_seed": {"name": "Carrot Seeds", "type": "material", "value": 3, "stack": 99, "glyph": "Cs", "desc": "A hardy root crop for kitchen gardens."},
	"berry_seed": {"name": "Berry Seeds", "type": "material", "value": 4, "stack": 99, "glyph": "Bs", "desc": "Plant a berry bush and prune it as it grows."},
	"hay": {"name": "Hay Bundle", "type": "material", "value": 3, "stack": 99, "glyph": "Hy", "desc": "Feed for penned livestock."},
	"wheat": {"name": "Wheat", "type": "material", "value": 5, "stack": 99, "glyph": "Wh", "desc": "Harvested grain for flour and feed."},
	"carrot": {"name": "Carrot", "type": "material", "value": 6, "stack": 99, "glyph": "Cr", "desc": "A fresh garden root."},
	"farm_berries": {"name": "Cultivated Berries", "type": "material", "value": 8, "stack": 99, "glyph": "Cb", "desc": "Sweet berries from a tended bush."},
	"egg": {"name": "Fresh Egg", "type": "material", "value": 7, "stack": 99, "glyph": "Eg", "desc": "Collected from a well-cared-for hen."},
	"milk": {"name": "Fresh Milk", "type": "material", "value": 10, "stack": 99, "glyph": "Mi", "desc": "Fresh milk from a healthy cow."},
	"wool": {"name": "Raw Wool", "type": "material", "value": 9, "stack": 99, "glyph": "Wo", "desc": "A fleece ready for spinning."},
	"animal_fur": {"name": "Soft Animal Fur", "type": "material", "value": 6, "stack": 99, "glyph": "Af", "desc": "Collected during seasonal grooming."},
	"flour": {"name": "Stoneground Flour", "type": "material", "value": 7, "stack": 99, "glyph": "Fl", "desc": "Ground grain ready for baking."},
	"bread": {"name": "Country Bread", "type": "consumable", "value": 16, "stack": 20, "glyph": "Br", "heal": 18.0, "desc": "Fresh bread made from player-grown grain."},
	"wood_plank": {"name": "Cut Wood Plank", "type": "material", "value": 7, "stack": 99, "glyph": "Wp", "desc": "Seasoned lumber prepared by a carpenter."},
	"cheese": {"name": "Farmstead Cheese", "type": "consumable", "value": 22, "stack": 20, "glyph": "Ch", "heal": 24.0, "desc": "Aged cheese from a small dairy."},
	# --- Weapons ---
	"rusty_sword": {"name": "Rusty Sword", "type": "weapon", "value": 4, "stack": 1, "glyph": "Sw",
		"damage": 10.0, "durability": 50.0, "weapon_class": "sword", "desc": "Seen better days. Better than nothing."},
	"iron_sword": {"name": "Iron Sword", "type": "weapon", "value": 70, "stack": 1, "glyph": "Is",
		"damage": 18.0, "durability": 120.0, "weapon_class": "sword", "desc": "A properly forged blade."},
	# --- Armor ---
	"cloth_tunic": {"name": "Cloth Tunic", "type": "armor", "value": 3, "stack": 1, "glyph": "Ct",
		"armor": 1.0, "durability": 80.0, "desc": "Patched, but warm."},
	"iron_chestplate": {"name": "Iron Chestplate", "type": "armor", "value": 110, "stack": 1, "glyph": "Ic",
		"armor": 5.0, "durability": 200.0, "desc": "Heavy plate. It will turn a few blows."},
	# --- Consumables ---
	"healing_potion": {"name": "Healing Potion", "type": "consumable", "value": 20, "stack": 20, "glyph": "Hp",
		"heal": 45.0, "desc": "Restores 45 health. Press Q to drink."},
	# --- Monster / boss materials ---
	"wolf_pelt": {"name": "Wolf Pelt", "type": "material", "value": 12, "stack": 99, "glyph": "Wp",
		"desc": "Thick grey fur from wild wolves."},
	"wolf_fang": {"name": "Wolf Fang", "type": "material", "value": 10, "stack": 99, "glyph": "Wf",
		"desc": "Sharp fang. Trophy and craft material."},
	"alpha_fang": {"name": "Alpha Fang", "type": "material", "value": 55, "stack": 20, "glyph": "Af",
		"desc": "Massive fang from an Alpha Wolf."},
	"bone": {"name": "Bone", "type": "material", "value": 4, "stack": 99, "glyph": "Bn",
		"desc": "Creature bone."},
	"beast_hide": {"name": "Beast Hide", "type": "material", "value": 16, "stack": 99, "glyph": "Bh",
		"desc": "Tough hide from a large beast."},
	"bandit_coin": {"name": "Worn Coin", "type": "material", "value": 5, "stack": 99, "glyph": "Bc",
		"desc": "Looted currency."},
	"captain_badge": {"name": "Captain Badge", "type": "material", "value": 35, "stack": 20, "glyph": "Cb",
		"desc": "Proof of a warlord's fall."},
	"chitin": {"name": "Chitin", "type": "material", "value": 11, "stack": 99, "glyph": "Ch",
		"desc": "Hard plate from crawlers."},
	"ectoplasm": {"name": "Ectoplasm", "type": "material", "value": 18, "stack": 99, "glyph": "Ec",
		"desc": "Wispy residue of night wisps."},
	"mana_crystal": {"name": "Mana Crystal", "type": "material", "value": 28, "stack": 99, "glyph": "Mc",
		"desc": "Condensed magic."},
	"royal_slime_gel": {"name": "Royal Slime Gel", "type": "material", "value": 60, "stack": 20, "glyph": "Rg",
		"desc": "Gel from the King Slime. Rare reagent."},
	"serpent_scale": {"name": "Serpent Scale", "type": "material", "value": 22, "stack": 99, "glyph": "Ss",
		"desc": "Iridescent scale of the Tide Serpent."},
	"pearl": {"name": "Pearl", "type": "material", "value": 40, "stack": 50, "glyph": "Pr",
		"desc": "Smooth ocean pearl."},
	"coral_fragment": {"name": "Coral Fragment", "type": "material", "value": 14, "stack": 99, "glyph": "Cf",
		"desc": "Hard reef piece."},
	"tide_fang": {"name": "Tide Fang", "type": "material", "value": 70, "stack": 10, "glyph": "Tf",
		"desc": "A fang torn from the Tide Serpent."},
	"warlord_blade": {"name": "Warlord Blade", "type": "weapon", "value": 160, "stack": 1, "glyph": "Wb",
		"damage": 26.0, "durability": 160.0, "weapon_class": "sword", "desc": "Heavy curved blade of the Bandit Warlord."},

	"fish_minnow": {"name": "Minnow", "type": "material", "value": 3, "stack": 99, "glyph": "Mn", "desc": "Tiny freshwater fish."},
	"fish_trout": {"name": "River Trout", "type": "material", "value": 8, "stack": 99, "glyph": "Tr", "desc": "Common river fish. Good eating."},
	"fish_bass": {"name": "Bass", "type": "material", "value": 12, "stack": 99, "glyph": "Bs", "desc": "Meaty freshwater catch."},
	"fish_mackerel": {"name": "Mackerel", "type": "material", "value": 14, "stack": 99, "glyph": "Mk", "desc": "Oily sea fish."},
	"fish_glowfin": {"name": "Glowfin", "type": "material", "value": 55, "stack": 20, "glyph": "Gf", "desc": "Rare luminescent fish."},
	"fish_koi": {"name": "Moonlit Koi", "type": "material", "value": 28, "stack": 40, "glyph": "Koi", "desc": "A colourful freshwater fish found in quiet lakes."},
	"fish_sunfish": {"name": "Sunfish", "type": "material", "value": 32, "stack": 40, "glyph": "Sun", "desc": "A deep-bodied fish that drifts through warm coastal waters."},
	"fish_parrotfish": {"name": "Parrotfish", "type": "material", "value": 38, "stack": 40, "glyph": "Prt", "desc": "A reef grazer with vivid scales and a beak-like mouth."},
	"fish_angler": {"name": "Abyss Angler", "type": "material", "value": 72, "stack": 20, "glyph": "Ang", "desc": "A rare deep-water fish with a luminous lure."},
	"fish_swordfish": {"name": "Swordfish", "type": "material", "value": 64, "stack": 20, "glyph": "Swf", "desc": "A powerful pelagic fish with a long pointed bill."},
	"fish_puffer": {"name": "Pufferfish", "type": "material", "value": 24, "stack": 40, "glyph": "Puf", "desc": "A round reef fish covered in defensive spines."},
	"seaweed": {"name": "Seaweed", "type": "material", "value": 3, "stack": 99, "glyph": "Sw", "desc": "Edible marine plant."},
	"scale_shard": {"name": "Scale Shard", "type": "material", "value": 9, "stack": 99, "glyph": "Sc", "desc": "Shiny fish scale."},
	"fishing_rod": {"name": "Fishing Rod", "type": "material", "value": 30, "stack": 1, "glyph": "Rd", "desc": "Cast near water (F)."},
	"leather_strip": {"name": "Leather Strip", "type": "material", "value": 8, "stack": 99, "glyph": "Ls", "desc": "Cut from pelts."},
	"cooked_trout": {"name": "Cooked Trout", "type": "consumable", "value": 18, "stack": 20, "glyph": "Ct", "heal": 25.0, "desc": "Restores 25 health."},
	"cooked_bass": {"name": "Cooked Bass", "type": "consumable", "value": 24, "stack": 20, "glyph": "Cb", "heal": 40.0, "desc": "Restores 40 health."},
	"cooked_mackerel": {"name": "Grilled Mackerel", "type": "consumable", "value": 28, "stack": 20, "glyph": "Cm", "heal": 34.0, "desc": "A smoky sea meal. Restores 34 health."},
	"fish_stew": {"name": "Fish Stew", "type": "consumable", "value": 35, "stack": 20, "glyph": "Fs", "heal": 60.0, "desc": "Hearty meal. Restores 60 health."},
	"copper_ore": {"name": "Copper Ore", "type": "material", "value": 5, "stack": 99, "glyph": "Cu", "desc": "Soft metal ore."},
	"copper_ingot": {"name": "Copper Ingot", "type": "material", "value": 12, "stack": 99, "glyph": "Ci", "desc": "Smelted copper."},
	"silver_ore": {"name": "Silver Ore", "type": "material", "value": 22, "stack": 99, "glyph": "Ag", "desc": "Pale precious ore used for fine alloys and charms."},
	"gold_ore": {"name": "Gold Ore", "type": "material", "value": 38, "stack": 99, "glyph": "Au", "desc": "Rare gold-bearing stone from high mountain seams."},
	"sulfur": {"name": "Sulfur", "type": "material", "value": 9, "stack": 99, "glyph": "Su", "desc": "Sharp-smelling mineral used in alchemy and explosives."},
	"glowcap": {"name": "Glowcap Mushroom", "type": "material", "value": 11, "stack": 99, "glyph": "Gc", "desc": "A luminous mushroom found in damp forest shade."},
	"wild_berries": {"name": "Wild Berries", "type": "material", "value": 5, "stack": 99, "glyph": "Wb", "desc": "Sweet seasonal berries gathered from thorny shrubs."},
	"salt_crystal": {"name": "Salt Crystal", "type": "material", "value": 7, "stack": 99, "glyph": "Na", "desc": "Mineral salt gathered from coastal flats."},
	"redwood_heartwood": {"name": "Redwood Heartwood", "type": "material", "value": 28, "stack": 99, "glyph": "Rh", "desc": "Dense, ancient timber from monumental redwoods."},
	"silver_ingot": {"name": "Silver Ingot", "type": "material", "value": 48, "stack": 99, "glyph": "Ag", "desc": "Refined silver for fine weapons, fittings and jewellery."},
	"gold_ingot": {"name": "Gold Ingot", "type": "material", "value": 82, "stack": 99, "glyph": "Au", "desc": "Refined gold prized by merchants and master artisans."},
	"redwood_longbow": {"name": "Elder Redwood Longbow", "type": "weapon", "value": 185, "stack": 1, "glyph": "Rb", "damage": 25.0, "durability": 180.0, "weapon_class": "bow", "desc": "A powerful longbow carved from ancient heartwood."},
	"willow_bark": {"name": "Silver Willow Bark", "type": "material", "value": 10, "stack": 99, "glyph": "Wb", "desc": "Flexible bark prized by herbalists and bowyers."},
	"baobab_fiber": {"name": "Baobab Fibre", "type": "material", "value": 16, "stack": 99, "glyph": "Bf", "desc": "Strong fibrous material from giant dryland trees."},
	"cherrywood": {"name": "Cherrywood", "type": "material", "value": 18, "stack": 99, "glyph": "Cw", "desc": "Fine-grained timber with a warm rose colour."},
	"jungle_hardwood": {"name": "Jungle Hardwood", "type": "material", "value": 23, "stack": 99, "glyph": "Jh", "desc": "Heavy tropical timber used for durable tools and structures."},
	"fang_dagger": {"name": "Fang Dagger", "type": "weapon", "value": 55, "stack": 1, "glyph": "Fd", "damage": 14.0, "durability": 90.0, "weapon_class": "dagger", "desc": "Crafted from wolf fangs."},
	"wolf_leather": {"name": "Wolf Leather Armor", "type": "armor", "value": 85, "stack": 1, "glyph": "Wl", "armor": 3.5, "durability": 140.0, "desc": "Light armor from wolf pelts."},
	"guardian_blade": {"name": "Guardian Blade", "type": "weapon", "value": 200, "stack": 1, "glyph": "Gb",
		"damage": 28.0, "durability": 180.0, "weapon_class": "sword", "set": "guardian", "desc": "Depths unique. Set: Guardian."},
	"guardian_plate": {"name": "Guardian Plate", "type": "armor", "value": 180, "stack": 1, "glyph": "Gp",
		"armor": 7.0, "durability": 220.0, "set": "guardian", "desc": "Depths unique. Set: Guardian."},
	"packlord_fang": {"name": "Packlord Fang", "type": "weapon", "value": 210, "stack": 1, "glyph": "Pf",
		"damage": 30.0, "durability": 170.0, "weapon_class": "dagger", "set": "packlord", "desc": "Alpha unique. Set: Packlord."},
	"packlord_cloak": {"name": "Packlord Cloak", "type": "armor", "value": 190, "stack": 1, "glyph": "Pc",
		"armor": 5.5, "durability": 160.0, "set": "packlord", "desc": "Alpha unique. Set: Packlord."},


	"moonstone_ore": {"name": "Moonstone Ore", "type": "material", "value": 95, "stack": 30, "glyph": "Mo", "desc": "A pale ore found only in the deepest crystal seams."},
	"voidsilk": {"name": "Voidsilk", "type": "material", "value": 130, "stack": 20, "glyph": "Vs", "desc": "Silk spun by abyssal cave hunters. Used for rare armour linings."},
	"dragonbone": {"name": "Dragonbone", "type": "material", "value": 220, "stack": 10, "glyph": "Db", "desc": "A dense bone fragment from an ancient subterranean wyrm."},
	"ancient_scale": {"name": "Ancient Scale", "type": "material", "value": 260, "stack": 10, "glyph": "As", "desc": "A scale shed by a rare elder beast deep below the world."},
	"heart_of_depths": {"name": "Heart of the Depths", "type": "material", "value": 600, "stack": 3, "glyph": "Hd", "desc": "A living mineral heart carried by the rarest dungeon guardians."},
	"forgotten_essence": {"name": "Forgotten Essence", "type": "material", "value": 180, "stack": 10, "glyph": "Fe", "desc": "A relic left by a rare dungeon predator."},
	"runebound_core": {"name": "Runebound Core", "type": "material", "value": 240, "stack": 10, "glyph": "Rc", "desc": "A core pulsing with ancient runic power."},
	"abyssal_relic": {"name": "Abyssal Relic", "type": "material", "value": 350, "stack": 5, "glyph": "Ar", "desc": "A relic from a creature touched by the abyss."},
	"eclipse_edge": {"name": "Eclipse Edge", "type": "weapon", "value": 950, "stack": 1, "glyph": "Ee", "damage": 46.0, "durability": 320.0, "weapon_class": "sword", "desc": "Legendary blade. Its strikes resonate with the abyss."},
	"warden_heartplate": {"name": "Warden Heartplate", "type": "armor", "value": 900, "stack": 1, "glyph": "Wh", "armor": 13.0, "durability": 380.0, "desc": "Legendary armour forged around a living core."},
	"spore_sac": {"name": "Spore Sac", "type": "material", "value": 16, "stack": 99, "glyph": "Sp", "desc": "A glowing sac harvested from fungal stalkers."},
	"field_notes": {"name": "Field Notes", "type": "material", "value": 12, "stack": 99, "glyph": "Fn", "desc": "Observations and sketches collected while exploring the living world."},
	"bronze_charter": {"name": "Bronze Charter", "type": "material", "value": 320, "stack": 5, "glyph": "Bc", "desc": "The Gilded Concord's founding oath, engraved on a surviving bronze leaf."},
	"choir_seed": {"name": "Choir Seed", "type": "material", "value": 350, "stack": 5, "glyph": "Cs", "desc": "A living seed that remembers the songs of the Verdant Choir."},
	"prism_heart": {"name": "Prism Heart", "type": "material", "value": 390, "stack": 5, "glyph": "Ph", "desc": "A resonant crystal holding a memory from the Prism Enclave."},
	"king_signet": {"name": "Sepulchral Signet", "type": "material", "value": 420, "stack": 5, "glyph": "Ks", "desc": "The seal of the last monarch of the Sepulchral Court."},
	"ember_insignia": {"name": "Cinder Insignia", "type": "material", "value": 450, "stack": 5, "glyph": "Ei", "desc": "A forge-mark granted to the smith-priests of the Cinder Dominion."},
	"glacier_scripture": {"name": "Glacier Scripture", "type": "material", "value": 480, "stack": 5, "glyph": "Gs", "desc": "A page preserved in perfect ice by the Glacial Monastery."},
	"drowned_signet": {"name": "Thalassian Signet", "type": "material", "value": 520, "stack": 5, "glyph": "Ts", "desc": "The insignia of the rulers of the drowned ports."},
	"worldroot_sapling": {"name": "Worldroot Sapling", "type": "material", "value": 570, "stack": 5, "glyph": "Ws", "desc": "A living offshoot carrying the memory of the Worldroot Communion."},
	"starless_crown": {"name": "Starless Crown", "type": "material", "value": 640, "stack": 5, "glyph": "Sc", "desc": "A dark circlet forged by the Starless Court."},
	"celestial_codex": {"name": "Celestial Codex", "type": "material", "value": 750, "stack": 5, "glyph": "Cc", "desc": "A star-map and archive of all ten subterranean civilizations."},
	"void_essence": {"name": "Void Essence", "type": "material", "value": 175, "stack": 30, "glyph": "Ve", "desc": "A cold residue left by abyssal organisms."},
	"astral_dust": {"name": "Astral Dust", "type": "material", "value": 210, "stack": 30, "glyph": "Ad", "desc": "A luminous powder shed by the Archive's star-bound guardians."},

	"prism_shard": {"name": "Prism Shard", "type": "material", "value": 34, "stack": 99, "glyph": "Ps", "desc": "A resonant shard from a crystal mimic."},
	"cinder_core": {"name": "Cinder Core", "type": "material", "value": 28, "stack": 99, "glyph": "Cc", "desc": "A smouldering core from a cinder hound."},
	"drowned_sigil": {"name": "Drowned Sigil", "type": "material", "value": 32, "stack": 99, "glyph": "Ds", "desc": "A waterlogged rune carried by drowned guards."},
	"rune_fragment": {"name": "Rune Fragment", "type": "material", "value": 38, "stack": 99, "glyph": "Rf", "desc": "A fragment of ancient labyrinth magic."},
	"abyssal_chitin": {"name": "Abyssal Chitin", "type": "material", "value": 42, "stack": 99, "glyph": "Ac", "desc": "Dense armour plate from an abyss mantis."},


	# --- Expanded weapon families ---
	"copper_axe": {"name": "Copper Hatchet", "type": "weapon", "value": 48, "stack": 1, "glyph": "Ha", "damage": 13.0, "durability": 95.0, "weapon_class": "axe", "attack_speed": 0.92, "desc": "A practical chopping axe that doubles as a weapon."},
	"iron_battleaxe": {"name": "Iron Battleaxe", "type": "weapon", "value": 145, "stack": 1, "glyph": "Ba", "damage": 25.0, "durability": 175.0, "weapon_class": "axe", "attack_speed": 0.78, "desc": "A broad, heavy axe built to split shields and armour."},
	"deepforged_cleaver": {"name": "Deepforged Cleaver", "type": "weapon", "value": 520, "stack": 1, "glyph": "Dc", "damage": 39.0, "durability": 290.0, "weapon_class": "axe", "attack_speed": 0.74, "desc": "A dungeon-forged executioner's axe with a mineral-dark edge."},
	"ash_spear": {"name": "Ashwood Spear", "type": "weapon", "value": 52, "stack": 1, "glyph": "As", "damage": 13.5, "durability": 105.0, "weapon_class": "spear", "attack_speed": 1.08, "reach": 3.8, "desc": "A balanced spear with a hardened ashwood shaft."},
	"iron_lance": {"name": "Iron Lance", "type": "weapon", "value": 155, "stack": 1, "glyph": "Il", "damage": 24.0, "durability": 185.0, "weapon_class": "spear", "attack_speed": 0.98, "reach": 4.2, "desc": "A long thrusting weapon made for controlling narrow passages."},
	"tidecaller_trident": {"name": "Tidecaller Trident", "type": "weapon", "value": 480, "stack": 1, "glyph": "Tt", "damage": 36.0, "durability": 260.0, "weapon_class": "spear", "attack_speed": 0.95, "reach": 4.5, "desc": "A three-pronged relic recovered from drowned ruins."},
	"stone_maul": {"name": "Stone Maul", "type": "weapon", "value": 60, "stack": 1, "glyph": "Sm", "damage": 16.0, "durability": 125.0, "weapon_class": "blunt", "attack_speed": 0.78, "desc": "A crude but devastating two-handed hammer."},
	"iron_warhammer": {"name": "Iron Warhammer", "type": "weapon", "value": 170, "stack": 1, "glyph": "Iw", "damage": 27.0, "durability": 210.0, "weapon_class": "blunt", "attack_speed": 0.72, "desc": "A heavy hammer designed to stagger armoured enemies."},
	"catacomb_breaker": {"name": "Catacomb Breaker", "type": "weapon", "value": 560, "stack": 1, "glyph": "Cb", "damage": 41.0, "durability": 310.0, "weapon_class": "blunt", "attack_speed": 0.68, "desc": "A massive relic hammer that carries the weight of the deep."},
	"shortbow": {"name": "Hunter's Shortbow", "type": "weapon", "value": 65, "stack": 1, "glyph": "Sb", "damage": 12.0, "durability": 100.0, "weapon_class": "bow", "attack_speed": 1.12, "reach": 15.0, "desc": "A compact bow suited to quick shots in tight tunnels."},
	"longbow": {"name": "Recurve Longbow", "type": "weapon", "value": 185, "stack": 1, "glyph": "Lb", "damage": 23.0, "durability": 175.0, "weapon_class": "bow", "attack_speed": 0.92, "reach": 20.0, "desc": "A powerful bow for accurate shots across large caverns."},
	"prism_longbow": {"name": "Prism Longbow", "type": "weapon", "value": 590, "stack": 1, "glyph": "Pl", "damage": 37.0, "durability": 280.0, "weapon_class": "bow", "attack_speed": 0.9, "reach": 23.0, "desc": "A crystal-limbed bow that focuses light into piercing arrows."},
	"apprentice_staff": {"name": "Apprentice Staff", "type": "weapon", "value": 72, "stack": 1, "glyph": "St", "damage": 14.0, "durability": 115.0, "weapon_class": "staff", "attack_speed": 0.96, "reach": 13.0, "desc": "A simple focus for shaping elemental energy."},
	"ember_staff": {"name": "Emberstaff", "type": "weapon", "value": 210, "stack": 1, "glyph": "Es", "damage": 26.0, "durability": 190.0, "weapon_class": "staff", "attack_speed": 0.9, "reach": 16.0, "element": "fire", "desc": "A fire-attuned staff that burns with a contained ember."},
	"voidweaver_staff": {"name": "Voidweaver Staff", "type": "weapon", "value": 650, "stack": 1, "glyph": "Vs", "damage": 40.0, "durability": 300.0, "weapon_class": "staff", "attack_speed": 0.88, "reach": 18.0, "element": "void", "desc": "A rare staff woven around a fragment of abyssal crystal."},
	"rune_wand": {"name": "Runescribe Wand", "type": "weapon", "value": 165, "stack": 1, "glyph": "Rw", "damage": 21.0, "durability": 150.0, "weapon_class": "wand", "attack_speed": 1.08, "reach": 12.0, "desc": "A compact arcane focus for precise ranged spell strikes."},
	"paired_fang_daggers": {"name": "Paired Fang Daggers", "type": "weapon", "value": 190, "stack": 1, "glyph": "Fd", "damage": 22.0, "durability": 155.0, "weapon_class": "dagger", "attack_speed": 1.28, "desc": "Twin blades made for fast close-range combinations."},
	"moonshadow_stilettos": {"name": "Moonshadow Stilettos", "type": "weapon", "value": 620, "stack": 1, "glyph": "Ms", "damage": 35.0, "durability": 265.0, "weapon_class": "dagger", "attack_speed": 1.34, "desc": "Rare dungeon daggers that reward precision and timing."},

}


static func has_item(id: String) -> bool:
	return ITEMS.has(id)

static func def(id: String) -> Dictionary:
	return ITEMS.get(id, {})

static func is_gear(id: String) -> bool:
	var t: String = ITEMS.get(id, {}).get("type", "")
	return t == "weapon" or t == "armor"

static func max_stack(id: String) -> int:
	return int(ITEMS.get(id, {}).get("stack", 1))

static func grade_info(g: int) -> Dictionary:
	return GRADES[clampi(g, 0, GRADES.size() - 1)]

static func grade_color(g: int) -> Color:
	return grade_info(g)["color"]

static func grade_mult(g: int) -> float:
	return grade_info(g)["mult"]

## Create an item instance.
static func make(id: String, count: int = 1, grade: int = 0, dur: float = -1.0) -> Dictionary:
	var d: Dictionary = def(id)
	var inst: Dictionary = {"id": id, "count": count, "grade": grade, "dur": 0.0}
	if is_gear(id):
		inst["count"] = 1
		inst["dur"] = dur if dur >= 0.0 else float(d.get("durability", 1.0))
	return inst

static func max_durability(inst: Dictionary) -> float:
	return float(def(inst.get("id", "")).get("durability", 0.0))

static func display_name(inst: Dictionary) -> String:
	var n: String = def(inst["id"]).get("name", inst["id"])
	if is_gear(inst["id"]) and int(inst.get("grade", 0)) > 0:
		return "%s %s" % [grade_info(inst["grade"])["name"], n]
	return n

## Stat value after grade and wear (broken gear is nearly useless).
static func weapon_damage(inst: Dictionary) -> float:
	if inst.is_empty():
		return 4.0   # bare hands
	var base: float = float(def(inst["id"]).get("damage", 4.0)) * grade_mult(inst.get("grade", 0))
	return base * (0.35 if float(inst.get("dur", 1.0)) <= 0.0 else 1.0)

static func armor_value(inst: Dictionary) -> float:
	if inst.is_empty():
		return 0.0
	var base: float = float(def(inst["id"]).get("armor", 0.0)) * grade_mult(inst.get("grade", 0))
	return base * (0.3 if float(inst.get("dur", 1.0)) <= 0.0 else 1.0)

static func sell_value(inst: Dictionary) -> int:
	var v: float = float(def(inst["id"]).get("value", 1))
	if is_gear(inst["id"]):
		v *= grade_mult(inst.get("grade", 0)) * grade_mult(inst.get("grade", 0))
		var mx: float = max_durability(inst)
		if mx > 0.0:
			v *= 0.4 + 0.6 * clampf(float(inst.get("dur", mx)) / mx, 0.0, 1.0)
	return maxi(int(round(v * 0.5)), 1)

static func buy_value(id: String) -> int:
	return maxi(int(ITEMS.get(id, {}).get("value", 1)), 1)

## Grade weights for crafted gear. Higher skill shifts odds upward (rare "Epic" rolls are the dream).
static func grade_weights(skill_value: float) -> Array[float]:
	var w: Array[float] = [
		100.0,
		22.0 + skill_value * 0.5,
		5.0 + skill_value * 0.3,
		1.0 + skill_value * 0.12,
		0.2 + skill_value * 0.04,
		0.02 + skill_value * 0.006,
	]
	return w

static func grade_odds(skill_value: float) -> Array[float]:
	var w: Array[float] = grade_weights(skill_value)
	var total: float = 0.0
	for x in w:
		total += x
	var out: Array[float] = []
	for x in w:
		out.append(x / total)
	return out

static func roll_grade(skill_value: float, rng: RandomNumberGenerator) -> int:
	var odds: Array[float] = grade_odds(skill_value)
	var r: float = rng.randf()
	for i in range(odds.size()):
		r -= odds[i]
		if r <= 0.0:
			return i
	return 0

static func tooltip(inst: Dictionary) -> String:
	var d: Dictionary = def(inst["id"])
	var lines: Array[String] = []
	var t: String = d.get("type", "")
	if t == "weapon":
		lines.append("Damage: %.1f" % (float(d.get("damage", 0.0)) * grade_mult(inst.get("grade", 0))))
		var family: String = str(d.get("weapon_class", "sword")).capitalize()
		lines.append("Weapon style: %s" % family)
		if d.has("reach"):
			lines.append("Reach: %.1fm" % float(d["reach"]))
		if d.has("attack_speed"):
			lines.append("Attack speed: %s" % ("Fast" if float(d["attack_speed"]) > 1.05 else ("Heavy" if float(d["attack_speed"]) < 0.82 else "Balanced")))
	elif t == "armor":
		lines.append("Armor: %.1f" % (float(d.get("armor", 0.0)) * grade_mult(inst.get("grade", 0))))
	elif t == "consumable":
		lines.append("Heals: %d" % int(d.get("heal", 0.0)))
	if is_gear(inst["id"]):
		lines.append("Durability: %d / %d" % [int(inst.get("dur", 0.0)), int(max_durability(inst))])
	lines.append("Value: %d gold" % sell_value(inst))
	lines.append("")
	lines.append(d.get("desc", ""))
	return "\n".join(lines)
