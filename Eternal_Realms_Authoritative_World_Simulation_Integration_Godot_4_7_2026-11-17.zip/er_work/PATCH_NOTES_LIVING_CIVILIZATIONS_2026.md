# Eternal Realms — Living Civilizations & World Simulation Milestone

## Build scope

This milestone continues the existing Eternal Realms Godot 4.6 project. It retains the existing world, dungeon, cultivation, magic, stealth, settlement, faction-war and one-world multiplayer foundations. It adds a persistent simulation layer and connects its state to player activity and shared-world networking.

## 1. Cultivation sects and relationships

- Added persistent population, influence, territory, recruitment pressure, victories, defeats and rivalry state for six cultivation sects.
- Sect membership is recorded against persistent character identity, preventing repeated joins from counting as additional disciples and handling a character changing sect.
- Rival sects can escalate into regional clashes, losing disciples and influence while reducing local settlement supply.
- Existing masters, elders, recruitment trials and lessons now expose the multi-floor inheritance path to sworn disciples.

## 2. Living monster territories

- Ten world regions maintain local species populations and renewable resource reserves.
- Population renewal is species-aware; predator growth depends on local prey availability.
- Overfull populations can migrate to neighbouring regions.
- Player kills reduce the matching regional population; gathering depletes the relevant regional reserve.
- Region entry can seed visible wildlife groups based on the region's population report.
- Territorial Hunt events now spawn opposing wildlife packs. The packs autonomously target and fight one another; casualties feed back into the region population count.

## 3. Regional apex bosses

- Added region-specific apex profiles with individual names, health/damage values, visual tint, signature raid pattern and guaranteed legendary reward.
- Nine signature patterns are wired into boss telegraphs and resolution: ash cone, astral orbit, bronze lance, frost ring, grave pulse, root snare, spore cloud, tide surge and void fold.
- Apex events remain active until their boss is defeated; defeating the apex clears the threat and increases regional settlement supply.
- Bosses and their profiles are replicated as shared world entities in online sessions.

## 4. Ancient libraries and multi-floor inheritances

- Added six sect-specific legacy expeditions, each with two archive fragments and a guardian floor.
- Archives appear as optional dungeon discoveries on selected floors and can be transcribed once per character.
- The guardian and fragment requirements must both be satisfied before the rare technique is sealed for later understanding.
- Discoveries, floor visits, boss-floor completions, quest progress and rewards are stored in player progression data.

## 5. Dynamic regional events

- Added beast migrations, territorial hunts, spirit blooms, bandit raids, sect tournaments, resource booms, blights and apex awakenings.
- Events affect species populations, resource reserves, settlement supply, sect influence and recruitment.
- Regional history and the latest regional change are persisted and displayed through the Field Journal / regional report.
- The simulation performs bounded offline catch-up so the world can change between visits without executing an unbounded backlog.

## Shared-world networking

- The server remains authoritative for the persistent ecology/sect simulation and world boss spawning.
- Versioned world simulation snapshots are sent to peers on join and after committed changes.
- Player gather, region-entry and sect-membership requests are validated against the server's registered character and accepted position.
- Dynamically spawned world monsters carry stable entity IDs, are replicated to connected/new peers, and are despawned across peers when defeated.
- Client-side monster AI and damage are not locally authoritative; combat remains server-resolved.

## Validation boundary

This archive has undergone static project checks and ZIP integrity verification. The build environment did not contain the Godot 4.6 executable, so engine import/parse, project launch, physics, visual behavior, multiplayer session testing, save/load round trips and encounter balancing have **not** been runtime-tested here. Those tests remain required in Godot before treating the milestone as release-ready.
