# Eternal Realms — Appraisal, Traversable Landmarks & Chat

## Implemented
- Added Appraisal to Wisdom & Knowledge and an Appraiser profession weighting.
- Press P to appraise the creature you're aiming at or a nearby resource/landmark. Detail quality improves with Appraisal practice; creature health, resource yield and additional clues unlock at higher proficiency.
- Added a local Realm Chat panel (T to open/close). Enter sends a message; it responds contextually to nearby NPCs and common world topics. `/help`, `/where` and `/appraise` are supported. This is local single-player chat, not a networked multiplayer channel.
- Added three traversable cave destinations with distinct underground palettes, rock formations, crystal growths, glowcap fungi, underground pools and return markers. E enters/exits when near the marked entrance/exit.
- Added two climbable giant-tree landmarks with large trunks, buttress roots, branch crowns, visible spiral footholds and elevated exploration platforms. E advances between climbing stages and returns to ground at the top route.
- Added a waterfall, plunge pool, river section and particle splash. The pool/river area activates the existing swimming movement mode.
- Added three breakable environmental objects. E damages nearby objects; destruction yields materials.
- Creature movement uses species-specific gait frequencies, while existing limb pivots continue idle/locomotion/attack motion. Death now includes a species-sensitive fall and collapse animation. Colossal footfalls and impact reactions already present remain active.
- Save version incremented to 6; appraisal is stored with the existing skill data and appraisal activity count is stored in PlayerData stats.

## Controls
- P: Appraise target / nearby subject.
- T: Open or close Realm Chat.
- Enter: Send chat message.
- E: Enter/exit cave, climb giant tree, or damage nearby breakable object; otherwise uses normal interaction.

## Limitations
- The chat is an offline contextual conversation layer; it does not connect to other players or a server.
- Creature animation is procedural on the existing generated creature meshes, not imported production skeletal rigs with authored animation clips.
- Cave chambers are separate explorable landmark spaces rather than a fully continuous cave network carved into terrain. More chambers and interconnections can be added in a later world-generation pass.
- Water is a visual waterfall/river surface with a swimming zone; it is not yet a full fluid simulation with physically simulated currents.
- The tree climbing route uses visible footholds and staged traversal points, not a fully freeform climbing controller.
- Godot 4.6 was unavailable in the build environment; run an engine import/parse and gameplay pass before release.
