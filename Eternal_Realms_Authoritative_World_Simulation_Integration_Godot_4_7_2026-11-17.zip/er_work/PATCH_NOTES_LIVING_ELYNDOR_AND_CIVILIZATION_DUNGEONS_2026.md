# Living Elyndor & Civilization Dungeon Pass — Godot 4.7

## Implemented

- Added lightweight occupation animation poses to the shared character rig: tending, smithing, trading and tracking. Movement clears the work pose so it does not fight locomotion or combat animation.
- Connected merchant and smith work cycles to the persistent living-business stock data through an authority-checked restock method. Stock remains capped and emits the existing business-changed signal.
- Added a hunter field routine: hunters have a wider working range and periodically move toward nearby wildlife tracks instead of remaining only in the settlement.
- Wildlife now flees nearby hostile creatures and hunter NPCs as well as the player. Existing habitat leashes, species visuals and spawn director remain intact.
- Added a distinct architectural focal artifact to each of the ten dungeon civilization bands (Concord, Choir, Prism, Sepulchral, Cinder, Glacial, Thalassian, Worldroot, Starless and Astral). Existing maze generation, room collision, routes, hazards, combat profiles, and faction remnants are preserved.

## Preserved

- Existing NPC schedules, free-will/social behaviour, dialogue, quests and shop interfaces.
- Existing persistent business state and production authority checks.
- Existing wildlife population director and region simulation.
- Existing ten-band dungeon layout and floor progression.
- Existing multiplayer world and combat authority boundaries.
- Cultivation remains a later discovery layer; these additions are ordinary-world life and dungeon-civilization dressing.

## Validation

- Archive integrity and resource-path scan performed after packaging.
- Godot 4.7 executable was not available in the build environment. Editor import, GDScript parser, scene runtime and multiplayer runtime testing remain required; no engine-level pass is claimed.
