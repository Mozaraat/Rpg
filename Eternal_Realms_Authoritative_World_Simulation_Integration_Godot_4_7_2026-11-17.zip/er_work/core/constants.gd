# Global constants - keep magic numbers out of logic
class_name Constants
extends Object

# Player
const PLAYER_WALK_SPEED: float = 4.5
const PLAYER_RUN_SPEED: float = 7.5
const PLAYER_JUMP_VELOCITY: float = 5.5
const PLAYER_GRAVITY: float = 9.80665

# Aging
const STARTING_AGE: float = 5.0
const AGE_UP_THRESHOLD: float = 1.0  # Every full year triggers events

# Combat
const BASE_MELEE_DAMAGE: float = 12.0
const ATTACK_COOLDOWN: float = 0.65
const ATTACK_RANGE: float = 2.6

# World
const CHUNK_SIZE: int = 64
const CHUNK_RES: int = 40         # quads per chunk side (1.6 m per quad)
const RENDER_DISTANCE: int = 4     # chunks in each direction
const WATER_LEVEL: float = 0.0

# Where a new game starts (south edge of Elyndor village, looking north at the plaza)
const SPAWN_XZ: Vector2 = Vector2(-25.0, -12.0)

# Physics layers
const LAYER_WORLD: int = 1
const LAYER_PLAYER: int = 2
const LAYER_NPC: int = 4
const LAYER_CREATURE: int = 8
