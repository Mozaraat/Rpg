# Reusable Health Component
# Real Coder: Composition over inheritance where it makes sense
class_name HealthComponent
extends Node

signal health_changed(current: float, maximum: float)
signal died(source: Node)

@export var max_health: float = 100.0
@export var current_health: float = 100.0

var is_dead: bool = false

func _ready() -> void:
	current_health = max_health
	health_changed.emit(current_health, max_health)

func take_damage(amount: float, source: Node = null) -> void:
	if is_dead or amount <= 0:
		return

	current_health = max(current_health - amount, 0.0)
	health_changed.emit(current_health, max_health)

	if current_health <= 0:
		is_dead = true
		died.emit(source)

func heal(amount: float) -> void:
	if is_dead or amount <= 0:
		return
	current_health = min(current_health + amount, max_health)
	health_changed.emit(current_health, max_health)

func get_health_percent() -> float:
	if max_health <= 0:
		return 0.0
	return current_health / max_health
