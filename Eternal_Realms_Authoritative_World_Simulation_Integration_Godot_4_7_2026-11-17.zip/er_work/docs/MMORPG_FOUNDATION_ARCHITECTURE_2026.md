# Eternal Realms — MMORPG Foundation Architecture (Milestone 1)

## Purpose

Move the existing Godot 4.7.2 project toward a persistent, server-authoritative cultivation MMORPG without discarding its existing single-player systems. This milestone introduces a multiplayer test harness and an explicit persistence boundary. It is **not** a production MMO backend and does not yet make every gameplay system authoritative.

## Architecture direction

```mermaid
flowchart TD
    C1[Godot Client A\nExisting player + local prediction] <-->|ENet / RPC| S[Authoritative World Server\nGodot headless process]
    C2[Godot Client B\nExisting player + local prediction] <-->|ENet / RPC| S
    S --> NS[MMORPGNetwork\nSession + peer presence]
    S --> WA[World Authority\nValidation + world mutations]
    WA --> AD[Persistence Adapter\nCurrent prototype: JSON files]
    AD -. production replacement .-> DB[(Transactional database)]
    S --> SIM[Existing world simulation\nCultivation / sects / dungeons / warfare]
```

### Decisions in this milestone

- Godot 4.7.2 remains the client and initial dedicated-server runtime.
- ENet is used for the first real-time networking slice.
- The server is the authority for peer presence and accepted remote transforms.
- Clients send transform proposals; the server applies a basic speed/distance sanity check and relays accepted state.
- Remote players are currently lightweight visual proxy avatars. The local player remains the existing fully featured player scene.
- Shared world state has a versioned persistence interface. The current JSON adapter is for local development and test worlds only.
- The offline path remains the default. Multiplayer starts only when a player hosts/joins or the process is launched with server/connect arguments.

## Implemented scope

1. `MMORPGNetwork` autoload: host, join, disconnect, dedicated-server startup, peer lifecycle, remote avatar spawning, transform proposals and server relay.
2. In-game network panel: host or join an ENet session, enter address/port, inspect status and remote avatar count. Toggle with F2.
3. Existing local player publishes its transform only while connected; no multiplayer traffic is generated in offline mode.
4. `MMORPGWorldState` autoload: versioned world JSON, revision counter, shared-state reads/writes, character snapshot file boundary, and server-only commit guard during online sessions.
5. CLI launch support: `-- --server` and `-- --connect=ADDRESS` (default UDP port 24560).

## How to test the prototype

1. Run one game instance and press **Host** in the network panel.
2. Run a second instance of the same project and press **Join**, using `127.0.0.1` and UDP port `24560` for a same-machine test.
3. Move each player. The other instance should show a labelled remote proxy avatar following the accepted transform.
4. Disconnect one instance and confirm its proxy disappears from the other.
5. For a headless test server, launch the project with `-- --server`; clients can connect using `-- --connect=127.0.0.1`.

The host port must be reachable through the host firewall/router for tests across machines. The default port is UDP 24560.

## Migration roadmap

### M0 — Multiplayer readiness (this milestone)
- [x] Network session and peer lifecycle.
- [x] Remote player presence prototype.
- [x] Server-side movement sanity validation.
- [x] Versioned world-state persistence boundary.
- [ ] Runtime validation with two Godot instances and a headless server.
- [ ] Formal account identity and authentication.

### M1 — Character and identity authority
- Define immutable account IDs, character IDs and world/shard IDs.
- Add authenticated session tickets; never treat an ENet peer ID as a persistent identity.
- Move character creation, inventory, cultivation realm, techniques, equipment, position and progression writes behind server commands.
- Add server-side validation for all combat, gathering, crafting, trading and cultivation breakthroughs.
- Add schema migrations and durable transactional database storage.

### M2 — Shared region simulation
- Split the world into server-owned region instances with explicit enter/leave handoff.
- Add interest management so clients receive only nearby players, NPCs, combat actors and relevant world events.
- Move NPC AI, monster spawning, resource depletion, settlement growth and world clocks to server simulation ticks.
- Define deterministic IDs for NPCs, buildings, drops, territory and world events.

### M3 — Persistent social world
- Migrate sect membership, rank, permissions, shared storage, diplomacy, territory ownership and war state to server transactions.
- Add chat channels, party/group membership, friend/block lists, mail and moderation tools.
- Add economy ledger and transactional trading to prevent duplicated currency/items.

### M4 — Production-scale operation
- Separate login/session services from region simulation servers.
- Add PostgreSQL or equivalent transactional storage, cache/queue where justified, metrics, structured logs, backups and restore drills.
- Add rate limiting, packet validation, anti-cheat telemetry, deployment automation and rolling updates.
- Load-test concurrency and region handoff before committing to player-capacity targets.

## Existing systems migration map

| Existing project system | Multiplayer migration requirement |
|---|---|
| Player / PlayerData / SaveSystem | Server-owned character state and authenticated character snapshots |
| SkillSystem / cultivation | Server-validated progression, technique use, breakthrough and cooldowns |
| DungeonCampaign / CivilizationSocieties | World-shard state with transactional territory and diplomacy updates |
| SectSimulation / FactionConflictSystem | Server-tick simulation, deterministic faction IDs and event history |
| DungeonSiegeDirector / battlefield | Server-authoritative siege phase, gate integrity, combat outcomes and replication events |
| GuildSystem / PartySystem | Persistent identity, permissions, membership and chat integration |
| PlayerBusinessSystem / professions / farming | Server-owned inventories, resource claims and atomic economic transactions |
| World generation / region systems | Shared world seed and versioned region generation, then region instance ownership |

## Important limitations and security boundaries

- This milestone is a prototype network slice, not a production MMO service.
- Player transforms are basic proposals with a movement sanity check; movement is not yet fully server-simulated or reconciled.
- Existing damage, skill, loot, inventory, crafting, cultivation and NPC AI are not yet server-authoritative. Do not expose this build as a competitive/public MMO server.
- The JSON persistence adapter is not safe for multiple server processes writing the same world and is not a replacement for a transactional database.
- There is no account login, encryption/session ticket service, anti-cheat system, region handoff, matchmaking, shard scaling or production moderation system yet.
- The current remote avatar is a visual proxy, not a replicated full player character with animations, equipment, health or combat state.

## Acceptance criteria for this milestone

- Project imports without missing references.
- Offline single-player remains the default when no network command or button is used.
- Host/join/disconnect lifecycle is wired into the project.
- Remote avatars are created for other peers and removed on disconnect.
- Client movement proposals are routed through the server before remote presentation.
- Non-server clients cannot commit shared JSON world state through the new persistence API.
- Full project archive passes ZIP integrity and static reference checks.
- Two-client runtime testing remains a required follow-up if Godot runtime is unavailable in the build environment.
