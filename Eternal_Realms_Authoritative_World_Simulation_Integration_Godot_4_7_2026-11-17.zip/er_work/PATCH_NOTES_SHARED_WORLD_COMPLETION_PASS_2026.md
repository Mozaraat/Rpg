# Shared-World Completion Pass — Godot 4.7

This pass extends the previous central backend/PostgreSQL build while retaining the existing Eternal Realms project and the fixed world identity `eternal-realms-one-world`.

## Implemented in this pass

- Added an Online Account / Character Select entry to the boot menu.
- Added a registration/sign-in and character-selection portal using the central HTTPS backend.
- Added character creation to the Godot backend client and short-lived join-ticket preparation before connecting to the configured authoritative world server.
- Added authenticated transactional inventory consumption.
- Added server-defined crafting recipes; the client supplies only recipe ID and quantity, while the backend determines inputs and outputs.
- Added authenticated quest-state retrieval.
- Added server-only merchant purchase settlement: stock decrement, currency ledger debit, item grant and idempotency record share one database transaction.
- Added server-only NPC interaction event recording.
- Added revision-checked persistence endpoints for generic world entities, regional monster populations and world-boss encounters.
- Added persistent NPC state, merchant stock, trade-session, monster-population, boss-encounter, backup-catalog and service-heartbeat tables.
- Added a daily PostgreSQL logical-backup sidecar with SHA-256 checksums and configurable local retention.
- Added service-authenticated metrics and an operational backup/restore/monitoring/load-test runbook.

## Important integration boundaries

- Player-to-player trade settlement is not yet implemented. The database has trade-session records, but escrow, both-party confirmation and atomic item/currency transfer still need API and gameplay integration.
- NPC dialogue/quest choices are not yet wired end-to-end from every existing NPC scene. The server event endpoint is available, but server-side dialogue rules and reward authorization still need connecting.
- Persistent monster-population and boss APIs/schema are available but existing live simulation managers are not yet fully migrated to load/save every population and encounter through them.
- Guild/sect/territory tables from the existing schema remain, but player organization actions, territory claims and economic settlement are not yet fully transactional end-to-end.
- The backup sidecar stores backups in a local Docker volume. Production disaster recovery still requires encrypted off-host copies, WAL/PITR, restore drills and monitoring of backup freshness.
- The account portal requires `ER_BACKEND_URL` to be an HTTPS URL and the configured world host to point to the one authoritative server. The world server must have its private service token; never ship that token in a client build.

## World integrity

Every new operation uses `eternal-realms-one-world`. No shard, channel, realm selector or duplicate player population has been introduced. Distributed services must use the same PostgreSQL authority and world lease.
