# Immersive World Pass

## Environmental atmosphere
- Added an ImmersionDirector to the main world scene.
- Biome-aware local atmosphere particles now shift between forest pollen, coastal sea mist, mountain dust, night motes and dungeon ash.
- Particles follow the player so the detail remains local and inexpensive instead of filling the entire streamed world.
- Distant, spatialized wildlife calls play intermittently outdoors, with storm and dungeon conditions suppressing them.

## Player presence
- Added procedural, spatialized footstep audio with different pitch/volume character for dungeon stone, village paths, coastal ground and wilderness.
- Added subtle movement camera bob that responds to walking and running and settles while stationary.
- Existing movement, combat, swimming, and input bindings are preserved.

## Validation
- Main scene references the new immersion script and its load-step count was updated.
- Static resource-reference and delimiter checks are included in the packaging pass.
- Godot runtime launch is not available in this environment; in-engine behaviour still needs play-testing.
