# Eternal Realms — Living Sect Wars & Expeditions

## Implemented

- Added `systems/sect_war_battlefield.gd` and connected it to the main world scene.
- Active persistent sect wars now create a physical encounter in the overworld near the player's current position, with opposing colour-coded squads, marching movement, target selection, melee attack timing, hit reactions and casualty visibility.
- Added a fortified outpost with defensive towers as a siege encounter landmark.
- Battlefield coordinates are written into the active war record so the world-map front marker matches the physical encounter.
- The world map now displays active battlefronts, master expedition destinations and owned sect territories with distinct symbols and colours.
- Master expedition records now produce visible travelling master figures that move across the overworld toward their recorded destination and return route.
- Completed battle reports include their front coordinates. Nearby settlements within the configured regional radius suffer population loss, reduced development progress and increased war unrest.
- All persistent state continues to use the existing `PlayerData.stats.sect_state` and `SectSimulation` data; no parallel faction state manager was introduced.

## Integration

- `scenes/main.tscn`: registers the battlefield/expedition presentation node.
- `systems/sect_war_battlefield.gd`: physical battle and travelling master presentation.
- `ui/world_map.gd`: war, expedition and territory markers.
- `systems/sect_simulation.gd`: records battlefront coordinates with persistent battle reports.
- `systems/settlement_growth.gd`: applies nearby settlement consequences once per battle report.

## Validation and limitations

- ZIP integrity and source-level structural checks should be run after packaging.
- Godot 4.6 executable is not available in this environment, so engine import, parser, rendering, navigation and runtime behaviour have not been verified here.
- The battlefield squads use lightweight procedural capsule characters and simple steering/melee behaviour. This is a functional first battlefield layer, not final character animation, advanced formation tactics, siege weaponry, destructible fortifications or full player command controls.
- Master expedition figures use procedural low-poly visuals and seeded world routes; they are presentation actors linked to the existing persistent expedition records.

## Living Warfare Upgrade — Siege, Commanders & Civilian Relief

- Battlefield soldiers now carry visible metal weapons and perform timed weapon-swing attack animations with matching body reactions.
- Siege encounters now deploy visible battering-ram and catapult-style engines. Repeated siege impacts damage the outpost gate, animate the engines and finally destroy/open the gate.
- Each side fields a visible sect commander. The Azure/Sword Formation commander grants nearby allies an offensive tempo and blade-intent damage rally; the opposing Phoenix commander restores nearby allies and accelerates their attack rhythm.
- Four civilian evacuees appear around an active battlefield. The player can approach and press `E` to escort each civilian to safety; completing all four records the rescue and triggers regional relief.
- Settlement recovery now runs after conflict: war unrest gradually declines and development progress returns. Completing the evacuation provides an additional population, unrest and development recovery boost.
- The upgrade reuses the existing `sect_state`, battlefield node, settlement-growth manager and save-backed `PlayerData.stats`; it does not introduce a separate war database.

## Validation status
- Static source checks and archive integrity are performed on this package.
- Godot 4.6 editor/runtime validation remains outstanding because the engine executable is not installed in this build environment. In-engine animation, collision, navigation and save/load behaviour must still be tested.
- Fortifications are built from separate wall sections rather than one monolithic block; siege impacts can collapse individual wall sections as well as destroy the gate.
