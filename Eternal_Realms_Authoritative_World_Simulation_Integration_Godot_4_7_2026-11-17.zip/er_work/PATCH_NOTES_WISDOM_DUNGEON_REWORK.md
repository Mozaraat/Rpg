# Wisdom, Knowledge & Dungeon Rework

## Character growth
- Added Wisdom, Knowledge, Observation and Ancient Lore as learn-by-doing skills.
- Ancient runic puzzles, shrines, hidden caches and dungeon exploration now train these skills.
- Intellect and Wisdom attributes now reflect study, interpretation and insight.
- Knowledge, Ancient Lore and Wisdom improve the chance of finding valuable dungeon loot without guaranteeing rare drops.

## Dungeon atmosphere
- Dungeon entry, floor descents and exit now use dedicated loading/transition screens.
- The dungeon replaces the overworld environment while inside: the sun/day-night cycle no longer controls dungeon lighting.
- Each ten-floor biome has its own ambient colour, fog density, local light colour and atmospheric particles (dust, spores, crystal mist, ash, embers, frost haze, underground rain, pollen, void vapour and arcane motes).
- Added local braziers and floor-specific lighting anchors.
- The overworld environment and sun are restored on exit.

## Dungeon map
- Press N inside the dungeon to open the current-floor labyrinth map; N or Escape closes it.
- Map shows the generated passages, entrance, boss gate and current player position.
- M remains the overworld map.

## Loot progression
- Forgotten caches now use floor-band reward pools, so deeper regions produce materials appropriate to their biome.
- Wisdom, Knowledge and Ancient Lore improve rare cache discovery odds.
- Floor bosses now award a biome-appropriate material and train lore/insight skills.
