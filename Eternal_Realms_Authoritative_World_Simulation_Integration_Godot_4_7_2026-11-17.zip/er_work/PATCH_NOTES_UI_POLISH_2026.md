# Eternal Realms — HUD Clutter & UI Text Overflow Fix

## Player HUD cleanup
- Reworked the always-visible status panel to use a compact layout with shorter guard, spirit, cultivation and elemental summaries.
- Reduced the permanent controls reminder to one short line and shortened its initial display to nine seconds; `H` still toggles it.
- Moved the minimap to the top-right corner and placed the quest tracker below it to prevent the two elements overlapping.
- Limited the on-screen tracker to two quests and two objective rows per quest; longer objective names wrap within the panel.
- Reduced the activity feed to four short, clipped messages and the toast stack to two messages.
- Reduced log and toast type sizes and constrained the interaction, gather, boss, zone-banner and notification text to the viewport.
- Added a viewport resize handler to scale HUD panel widths and minimap size for compact screens.

## Shared UI text safety
- Shared `UIKit.label()` labels now trim long text with an ellipsis and clip their drawing to the label bounds.
- Dynamic HUD labels use word wrapping where preserving the full text is useful, and single-line clipping for compact status values.

## Gameplay preservation
- No combat, cultivation, quest, inventory, simulation, persistence or multiplayer rules were changed.
- No existing HUD information systems were deleted; verbose status details are shortened on the persistent HUD and remain available through the existing game systems / menus.

## Validation
- 120 GDScript files and 13 scene files present.
- 66 global class declarations; no duplicate class names found.
- No duplicate top-level function names found.
- Literal resource references checked; no missing literal project paths found.
- Modified scripts passed static delimiter and declaration checks.
- ZIP integrity check passed after packaging.
- Godot 4.6 runtime parse and visual testing could not be performed because the Godot executable is not installed in this build environment. Please open the project in Godot 4.6 to confirm final layout at the target display resolution.
