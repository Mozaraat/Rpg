# Eternal Realms — Stealth, Cultivation Paths & World Navigation

## Player stealth
- Added a toggleable quiet-movement stance on `V`.
- Stealth reduces movement speed and enemy acquisition distance; running and attacking break concealment.
- Stealth improves gradually through sustained quiet movement, rather than being a free permanent stat bonus.
- Enemies already pursuing the player can lose detection when the player successfully breaks contact.

## Cultivation breadth
- Added seven distinct cultivation disciplines: Body Refinement, Sword Intent, Elemental Core, Spirit Sense, Shadow Step, Nature Harmony and Flowing Water.
- Added six elemental affinities (fire, water, wind, earth, lightning and ice) as independent trainable skills.
- Added six affinity-oriented cultivation traditions: Crimson Flame, Azure Tide, Gale, Mountain Root, Storm Vein and Frost Lotus.
- Path progress is derived from actual practice across its component skills. The system does not force a fixed character class.

## World map navigation
- Added scroll-wheel zoom (1× to 3.5×) and click-drag panning to the existing seeded world atlas.
- The sampled terrain, region labels, settlement/landmark pins and player marker share the zoom/pan transform.
- The map returns to its full-atlas framing when zoomed back to 1×.

## Verification
- Static scan: 99 GDScript files present; no duplicate function declarations detected.
- Existing archive contents retained, including the 100-floor dungeon and world systems.
- Godot runtime/parser verification remains outstanding because the Godot executable is not available in this environment. This archive is not represented as engine-tested.
