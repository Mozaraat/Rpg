# Eternal Realms — Visible Dungeon Campaign Warfare (2026)

## Implemented in this milestone

### Visible faction headquarters
- Added a procedural occupied stronghold on the first floor of each ten-floor civilization band, giving all ten civilizations a recognizable physical headquarters.
- Each stronghold contains a gatehouse, flanking towers, raised platform, faction banner, spiked barricades, commander figure, four bodyguards, faction lighting and readable overhead labels.
- Strongholds rebuild when their floor is regenerated and read persistent campaign room ownership. Expedition-held headquarters change to an expedition command outpost presentation; rival-held territory is visibly marked as occupied.

### Moving armies and siege presence
- Connected the existing autonomous faction patrol captain's route to the stronghold so its squad physically patrols between the district route and headquarters.
- Retained the existing rival patrols, pack alert behaviour, faction-vs-faction target selection, reinforcement flow and combat AI; the new stronghold does not replace those combatants with decorative actors.
- Added visible gate and barricade geometry to communicate a defended/siege-ready location.

### Commander diplomacy
- Added an interactable parley point at each stronghold.
- Players can offer aid to improve faction standing. At +8 reputation, the commander can accept a temporary ceasefire.
- Ceasefires are timestamped in campaign state, recorded in faction history and prevent the faction's offline territory simulation from reclaiming expedition-held rooms until expiry.

### Campaign and territory interface
- Added the in-game campaign ledger, opened with `J`.
- Lists all ten civilizations with strength and morale; selected faction detail shows victories, defeats, leader status, bodyguard count, controlled rooms, player reputation, ceasefire state and recent history.
- Added direct aid and ceasefire actions from the interface.

## Existing systems preserved
- Existing dungeon generation, patrol encounters, faction combat, boss encounters, discovery content, save compatibility and persistent campaign ledger remain in place.
- New setpieces are grouped as dungeon discoveries so they are removed and rebuilt cleanly when a floor is regenerated.

## Validation and limitations
- Checked archive integrity before editing and after packaging.
- Static checks cover GDScript delimiter balance, duplicate top-level functions/classes and literal `res://` resource references.
- Godot 4.6 is not installed in this environment. The project has not been launched; runtime parser validation, visuals, collision interaction, AI navigation and combat behaviour still require an in-engine playtest.
