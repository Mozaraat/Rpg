# Elyndor Environment Art Upgrade — Godot 4.7

## Design direction
Elyndor remains a conventional fantasy-RPG starting region. Forests, settlements, roads, rivers, wildlife and dungeons communicate a grounded exploration game first. Cultivation remains a rare discovery that gains visual importance only when the player encounters its masters, inheritances and trials.

## Streaming terrain and biome dressing
- Added deterministic chunk-local ground-detail passes for the Elyndor exploration ring.
- Increased meadow flower variation, forest fern/fungal undergrowth, and scattered stone dressing without replacing the existing MultiMesh vegetation pipeline.
- Added reed and rounded-stone dressing along the authored riverbanks; these details stream and unload with their owning terrain chunks.
- Added small verge stones beside the existing shader-painted road network so paths visually integrate with the terrain.
- All new placement is derived from the existing world seed, terrain height, slope, settlement mask, path mask and biome classifier. It does not create a second terrain coordinate system.

## Elyndor settlement life
- Expanded the village with an inn frontage, additional market/storage props, an enclosed stable yard, feed and orchard trees.
- Added a stablehand NPC using the existing NPC schedule/dialogue path.
- Added a timber river bridge at the crossing of the existing eastern trade road and the authored river. The deck has a StaticBody3D collision shape; decorative rails and piers are visual-only.

## Ten regional identities
- Added ten distinct regional entrance monuments using the existing TerrainNoise.REGIONS catalogue.
- Each monument receives a region-specific material palette and a distinct crest silhouette.
- These are regional landmarks/waymarkers, not complete civilization capitals. Full city districts, local populations and faction-specific building sets remain a later regional content pass.

## Preserved systems
- ChunkManager streaming, terrain collision and height sampling.
- Existing seed determinism and biome/region classification.
- Existing settlement, NPC schedule, crafting, resource, road, exploration and wildlife systems.
- Existing dungeon floor generation, civilization districts, dungeon lighting and multiplayer/world-state systems were not replaced or modified.

## Validation
- Archive integrity checked after packaging.
- Modified GDScript delimiter balance and duplicate function declarations checked.
- Resource-path scan performed against the packaged project.
- Godot 4.7 editor import, parser, physics, visual and multiplayer runtime tests still require execution in the Godot editor; no engine runtime was available in this environment.
