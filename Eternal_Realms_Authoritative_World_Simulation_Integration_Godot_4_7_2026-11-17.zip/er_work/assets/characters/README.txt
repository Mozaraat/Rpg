Optional character art assets belong in this folder.
The game remains runnable with its procedural fallback character visuals when this folder is empty.
