Optional creature art assets belong in this folder.
The game remains runnable with its procedural fallback creature visuals when this folder is empty.
