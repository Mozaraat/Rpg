// Soft volumetric-looking waystone/portal beacon. Additive, unshaded and
// faded at both ends so the column never ends in a hard cut against the sky.
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, shadows_disabled;

uniform vec3 beam_color : source_color = vec3(0.48, 0.30, 0.92);
uniform float strength = 1.0;

varying vec2 v_uv;

void vertex() {
	v_uv = UV;
}

void fragment() {
	// Cylinder UV.y runs from base to tip.
	float foot = smoothstep(0.0, 0.10, v_uv.y);
	float head = 1.0 - smoothstep(0.55, 1.0, v_uv.y);
	float edge_soft = foot * head;

	float rings = 0.62 + 0.38 * sin(v_uv.y * 36.0 - TIME * 1.8 + v_uv.x * TAU * 2.0);
	float strands = 0.72 + 0.28 * sin(v_uv.x * TAU * 3.0 + v_uv.y * 7.0 + TIME * 0.7);
	float flicker = 0.88 + 0.12 * sin(TIME * 2.1 + v_uv.y * 11.0);

	float alpha = edge_soft * rings * strands * flicker * 0.115 * strength;
	ALBEDO = beam_color * (1.35 + 0.35 * rings);
	ALPHA = clamp(alpha, 0.0, 0.30);
}
