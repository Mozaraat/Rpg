shader_type spatial;
render_mode cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform vec4 base_tint : source_color = vec4(0.32, 0.30, 0.28, 1.0);
uniform float detail_scale = 0.42;
uniform float grain_scale = 5.5;

varying vec3 world_position;
varying vec3 world_normal;

float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

float noise3(vec3 p) {
	vec3 i = floor(p);
	vec3 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float n000 = hash31(i + vec3(0.0, 0.0, 0.0));
	float n100 = hash31(i + vec3(1.0, 0.0, 0.0));
	float n010 = hash31(i + vec3(0.0, 1.0, 0.0));
	float n110 = hash31(i + vec3(1.0, 1.0, 0.0));
	float n001 = hash31(i + vec3(0.0, 0.0, 1.0));
	float n101 = hash31(i + vec3(1.0, 0.0, 1.0));
	float n011 = hash31(i + vec3(0.0, 1.0, 1.0));
	float n111 = hash31(i + vec3(1.0, 1.0, 1.0));
	float x00 = mix(n000, n100, f.x);
	float x10 = mix(n010, n110, f.x);
	float x01 = mix(n001, n101, f.x);
	float x11 = mix(n011, n111, f.x);
	return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
}

float fbm3(vec3 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) {
		v += noise3(p) * a;
		p = p * 2.03 + vec3(11.7, 4.3, 8.1);
		a *= 0.5;
	}
	return v;
}

void vertex() {
	world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	world_normal = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec3 n = abs(normalize(world_normal));
	vec3 weights = pow(n, vec3(4.0));
	weights /= max(weights.x + weights.y + weights.z, 0.0001);
	vec3 p = world_position * detail_scale;
	float nx = fbm3(p.yzx);
	float ny = fbm3(p.xzy + vec3(7.1, 2.4, 1.8));
	float nz = fbm3(p.xyz + vec3(3.2, 8.4, 5.7));
	float broad = nx * weights.x + ny * weights.y + nz * weights.z;
	float grain = noise3(world_position * grain_scale);
	float strata = sin((world_position.y + broad * 1.8) * 3.4) * 0.5 + 0.5;
	float mineral = smoothstep(0.66, 0.9, grain + broad * 0.22);
	vec3 rock = base_tint.rgb * mix(0.66, 1.24, broad);
	rock *= mix(0.92, 1.08, grain);
	rock = mix(rock, rock * vec3(0.72, 0.78, 0.82), mineral * 0.22);
	rock *= mix(0.92, 1.06, strata * 0.35);
	ALBEDO = rock;
	ROUGHNESS = mix(0.94, 0.78, mineral * 0.25);
	SPECULAR = 0.18;
}
