// Foliage / grass / flowers / rocks.
// Vertex COLOR.rgb = base colour (sRGB), COLOR.a = strength of the per-instance tint.
// INSTANCE_CUSTOM.rgb = per-instance tint (set by Chunk/VegetationKit multi-meshes).
//
// The shader adds wind, leaf-scale mottling, micro normal relief, a cheap canopy
// ambient-occlusion gradient and wrapped translucency. Those three things do most of
// the work of turning faceted low-poly canopies into convincing masses of leaves.
shader_type spatial;
render_mode cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform float sway_amount = 0.05;
uniform float sway_height = 3.0;
uniform float wind_speed = 1.3;
uniform float roughness_value = 0.85;
uniform float translucency = 0.25;
uniform bool use_instance_tint = true;
uniform float detail_amount = 1.0;   // 0 = no leaf mottling (rocks), 1 = foliage
uniform float leaf_scale = 3.4;      // world-space clump frequency
uniform float ao_strength = 0.85;
uniform float normal_strength = 0.55;

varying vec3 v_color;
varying vec3 v_world;
varying float v_height01;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	float a = hash12(i);
	float b = hash12(i + vec2(1.0, 0.0));
	float c = hash12(i + vec2(0.0, 1.0));
	float d = hash12(i + vec2(1.0, 1.0));
	return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm2(vec2 p) {
	return vnoise(p) * 0.55 + vnoise(p * 2.07 + 4.3) * 0.30 + vnoise(p * 4.31 + 9.7) * 0.15;
}

void vertex() {
	vec3 inst_pos = MODEL_MATRIX[3].xyz;
	float t = TIME * wind_speed;
	// Wind is coherent across the world, with a per-instance phase and a second
	// faster ripple so a whole canopy never moves as a rigid block.
	float phase = dot(inst_pos.xz, vec2(0.21, 0.17));
	float gust = sin(t + phase) * 0.62 + sin(t * 2.3 + phase * 1.7) * 0.24;
	float flutter = sin(t * 4.1 + VERTEX.y * 2.3 + phase * 3.1) * 0.12;
	float h = clamp(VERTEX.y / max(sway_height, 0.001), 0.0, 1.0);
	float k = sway_amount * h * h;
	VERTEX.x += (gust + flutter) * k;
	VERTEX.z += cos(t * 0.8 + phase * 0.85) * 0.42 * k;

	vec3 base = pow(COLOR.rgb, vec3(2.2));
	vec3 tint_raw = INSTANCE_CUSTOM.rgb;
	// Plain MeshInstance3D leaves INSTANCE_CUSTOM at (0,0,0); treat ~black as "no tint".
	vec3 tint = use_instance_tint && dot(tint_raw, tint_raw) > 0.0025 ? tint_raw : vec3(1.0);
	v_color = base * mix(vec3(1.0), tint, COLOR.a);
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	v_height01 = h;
}

void fragment() {
	vec3 col = v_color;
	float is_leaf = step(0.015, translucency) * detail_amount;
	float is_rock = (1.0 - step(0.015, translucency)) * detail_amount;
	float dist = length(v_world - CAMERA_POSITION_WORLD);
	float fade = exp(-dist * 0.010);

	// ---- leaf-scale mottling ---------------------------------------------
	// Two frequencies: broad light/shade clumps plus tiny leaf flecks. The
	// flickering is suppressed with distance so canopies stay clean at range.
	float clump = fbm2(v_world.xz * leaf_scale * 0.55 + v_world.y * 1.35);
	float fleck = vnoise(v_world.xz * leaf_scale * 3.2 + v_world.y * 4.1);
	float mott = mix(0.5, 1.0, clump);
	col *= mix(1.0, mix(0.62, 1.30, clump) * mix(0.86, 1.14, fleck), is_leaf * (0.45 + 0.55 * fade));
	// A second, coarser leaf-mass break-up keeps big canopies from reading as one
	// smooth shaded sphere.
	float masses = fbm2(v_world.xz * leaf_scale * 0.19 + v_world.y * 0.55 + 13.7);
	col *= mix(1.0, mix(0.78, 1.14, masses), is_leaf * (0.30 + 0.45 * fade));
	// Leaves catch a little more light at their top edge.
	col *= mix(1.0, 1.0 + 0.18 * v_height01, is_leaf * fade);

	// ---- rock lichen / weathering ----------------------------------------
	float lichen = smoothstep(0.64, 0.94, fbm2(v_world.xz * 2.1 + v_world.y * 2.7));
	col = mix(col, col * vec3(0.74, 0.86, 0.60), lichen * is_rock * 0.45);
	col *= mix(1.0, mix(0.80, 1.16, fbm2(v_world.xz * 5.3 + v_world.y * 3.1)), is_rock * 0.7);

	ALBEDO = col;
	ROUGHNESS = mix(roughness_value, 0.68, is_leaf * 0.35);
	SPECULAR = mix(0.18, 0.30, is_leaf);
	// Wrapped translucency: light glowing through leaf edges.
	BACKLIGHT = col * translucency * (0.72 + 0.38 * clump);
	// Cheap canopy AO: deep interior and undersides read darker.
	float ao_h = smoothstep(0.0, 0.62, v_height01);
	AO = mix(1.0, mix(0.55, 1.0, ao_h), ao_strength * clamp(is_leaf + is_rock * 0.25, 0.0, 1.0));

	// ---- micro relief -----------------------------------------------------
	vec3 world_n = normalize((INV_VIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
	float e = 0.09;
	float h0 = fbm2(v_world.xz * leaf_scale * 2.2 + v_world.y * 2.6);
	float hx = fbm2((v_world.xz + vec2(e, 0.0)) * leaf_scale * 2.2 + v_world.y * 2.6);
	float hz = fbm2((v_world.xz + vec2(0.0, e)) * leaf_scale * 2.2 + v_world.y * 2.6);
	vec2 grad = vec2(hx - h0, hz - h0) / e;
	float relief = (is_leaf + is_rock * 0.6) * normal_strength * fade;
	vec3 n_pert = normalize(world_n + vec3(-grad.x, 0.0, -grad.y) * relief * 0.06);
	NORMAL = normalize((VIEW_MATRIX * vec4(n_pert, 0.0)).xyz);
}
