// Water - refraction, depth absorption, animated normals, shoreline foam and
// sun glitter. The scene colour is sampled through the screen texture, which
// gives the shallows their see-through quality without any extra render pass.
shader_type spatial;
render_mode blend_mix, depth_draw_always, cull_back, diffuse_burley, specular_schlick_ggx;

uniform vec3 shallow_color : source_color = vec3(0.12, 0.48, 0.47);
uniform vec3 deep_color : source_color = vec3(0.012, 0.085, 0.17);
uniform float depth_scale = 0.42;
uniform float wave_strength = 0.48;
uniform float foam_width = 1.25;
uniform vec3 foam_color : source_color = vec3(0.96, 0.99, 1.0);
uniform float day_light = 1.0;
uniform vec3 sun_dir = vec3(0.0, 1.0, 0.0);
uniform vec3 sun_color : source_color = vec3(1.0, 0.94, 0.82);
uniform float sun_energy = 1.0;
uniform float clarity = 1.0;
// Ocean tide only reaches deep beds; inland streams and lakes stay at base level.
uniform float tide_offset = 0.0;
uniform float map_extent = 1400.0;
uniform sampler2D height_map : repeat_disable, filter_linear;

uniform sampler2D depth_tex : hint_depth_texture, repeat_disable, filter_nearest;
uniform sampler2D screen_tex : hint_screen_texture, repeat_disable, filter_linear_mipmap;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}

float height_at(vec2 p, float t) {
	float h = 0.0;
	h += vnoise(p * 0.45 + vec2(t * 0.30, t * 0.17)) * 0.55;
	h += vnoise(p * 1.05 + vec2(-t * 0.41, t * 0.29)) * 0.27;
	h += vnoise(p * 2.60 + vec2(t * 0.63, -t * 0.51)) * 0.12;
	h += vnoise(p * 6.10 + vec2(-t * 0.90, t * 0.72)) * 0.06;
	return h;
}

varying vec3 v_world;

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec2 muv = (wp.xz + vec2(map_extent)) / (2.0 * map_extent);
	float bed = texture(height_map, muv).r;
	float tide_f = 1.0 - smoothstep(-2.4, -1.4, bed);
	VERTEX.y += tide_offset * tide_f;
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 p = v_world.xz;
	float t = TIME;

	// ---- surface normal from layered wind waves --------------------------
	float e = 0.10;
	float h0 = height_at(p, t);
	float hx = height_at(p + vec2(e, 0.0), t);
	float hz = height_at(p + vec2(0.0, e), t);
	vec3 nw = normalize(vec3(-(hx - h0) / e * wave_strength, 1.0, -(hz - h0) / e * wave_strength));
	float view_dist = length(v_world - CAMERA_POSITION_WORLD);
	// Calm the high-frequency ripples far from the lens so open water never turns
	// into a sheet of shimmering static.
	nw = normalize(mix(nw, vec3(0.0, 1.0, 0.0), smoothstep(90.0, 280.0, view_dist) * 0.62));
	vec3 nview = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);

	// ---- depth / thickness ------------------------------------------------
	float depth = texture(depth_tex, SCREEN_UV).x;
	vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, depth);
	vec4 vpos = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	vpos.xyz /= vpos.w;
	float thickness = max(VERTEX.z - vpos.z, 0.0);
	float dk = 1.0 - exp(-thickness * depth_scale * mix(0.55, 1.5, clarity));

	// ---- refraction --------------------------------------------------------
	vec2 offs = nview.xz * 0.045 * clamp(thickness * 0.55, 0.0, 1.0);
	vec3 refr = textureLod(screen_tex, SCREEN_UV + offs, 0.0).rgb;
	// Slight colour shift/absorption through the water body.
	vec3 absorb = exp(-thickness * vec3(0.65, 0.22, 0.16) * clarity);
	refr *= mix(vec3(1.0), absorb, clamp(thickness * 0.22, 0.0, 0.75));

	// ---- water body -------------------------------------------------------
	vec3 water_col = mix(shallow_color, deep_color, clamp(dk * 1.15, 0.0, 1.0));
	float night_water = 1.0 - smoothstep(0.04, 0.45, day_light);
	// Moonlit water keeps a cool lift instead of collapsing to black.
	water_col = mix(water_col, vec3(0.035, 0.060, 0.115), night_water * 0.42);
	water_col *= mix(0.24, 1.0, day_light);
	vec3 col = mix(refr, water_col, clamp(dk * 1.05 + 0.10, 0.0, 0.96));

	// Fresnel brightening toward grazing angles (sky light scattering).
	vec3 view_dir = normalize(CAMERA_POSITION_WORLD - v_world);
	float fresnel = pow(1.0 - clamp(dot(nview, normalize((VIEW_MATRIX * vec4(view_dir, 0.0)).xyz)), 0.0, 1.0), 4.0);
	col = mix(col, mix(water_col, vec3(0.55, 0.70, 0.86) * mix(0.18, 1.0, day_light), 0.55), fresnel * 0.35);

	// ---- sun / moon glitter ----------------------------------------------
	// At night the sun is below the horizon; mirror its direction to the moon so
	// the water still carries a bright path toward the light.
	vec3 light_dir = normalize(sun_dir);
	float sun_above = smoothstep(-0.04, 0.16, light_dir.y);
	if (light_dir.y < 0.0) {
		light_dir = -light_dir;
	}
	vec3 hvec = normalize(view_dir + light_dir);
	float glitter = pow(max(dot(nw, hvec), 0.0), 420.0);
	float sparkle = smoothstep(0.35, 0.9, vnoise(p * 11.0 + vec2(t * 1.7, -t * 1.3)));
	vec3 glint_col = mix(vec3(0.62, 0.76, 1.0), sun_color, sun_above);
	float glint_energy = max(sun_energy, (1.0 - sun_above) * 0.55);
	col += glint_col * glitter * sparkle * glint_energy * mix(0.4, 1.8, day_light);
	// Broad moon sheen on the wave faces, subtle enough to keep the night dark.
	col += vec3(0.16, 0.22, 0.36) * pow(max(dot(nw, light_dir), 0.0), 24.0) * night_water * 0.35;

	// ---- foam --------------------------------------------------------------
	float crest_noise = vnoise(p * 2.1 + vec2(t * 0.23, -t * 0.19)) * 0.62
		+ vnoise(p * 5.6 - vec2(t * 0.37, t * 0.11)) * 0.38;
	float shore = 1.0 - smoothstep(0.0, foam_width, thickness + (crest_noise - 0.5) * 0.6);
	// thin second ring of retreating foam
	float ring = 1.0 - smoothstep(0.0, foam_width * 0.55, abs(thickness - foam_width * 0.55) + (crest_noise - 0.5) * 0.3);
	float pulse = 0.55 + 0.45 * sin(t * 1.15 + p.x * 0.27 + p.y * 0.19);
	// Shore foam only where the water is genuinely shallow (banks, beaches);
	// a uniformly ~0.5 m stream channel stays blue with foam hugging its edges.
	float depth_gate = 1.0 - smoothstep(0.30, 0.70, thickness);
	float foam = max(shore * pulse, ring * 0.35) * depth_gate * smoothstep(0.22, 0.62, crest_noise + shore * 0.4);
	// wave crests in open water
	float crest = smoothstep(0.72, 0.96, h0 + nw.x * 0.04 + nw.z * 0.03) * (1.0 - smoothstep(0.4, 1.0, thickness));
	foam = max(foam, crest * 0.35);
	col = mix(col, foam_color * mix(0.32, 1.05, day_light), clamp(foam, 0.0, 1.0));

	ALBEDO = col;
	ROUGHNESS = mix(0.035, 0.55, foam);
	SPECULAR = 0.72;
	METALLIC = 0.0;
	NORMAL = nview;
	// Soft edge so water melts into the beach instead of ending in a hard line.
	ALPHA = clamp(thickness * 4.0, 0.0, 1.0);
}
