// Title-screen backdrop: dusk sky, layered ridgelines, moon glow, slow mist.
// Drawn as a full-rect CanvasItem so the boot screen needs no art assets.
shader_type canvas_item;

uniform vec3 sky_top : source_color = vec3(0.030, 0.040, 0.080);
uniform vec3 sky_mid : source_color = vec3(0.11, 0.115, 0.185);
uniform vec3 sky_horizon : source_color = vec3(0.52, 0.27, 0.19);
uniform vec3 glow_color : source_color = vec3(1.0, 0.62, 0.36);
uniform vec3 ridge_far : source_color = vec3(0.115, 0.135, 0.180);
uniform vec3 ridge_mid : source_color = vec3(0.070, 0.088, 0.122);
uniform vec3 ridge_near : source_color = vec3(0.030, 0.042, 0.062);
uniform float mist_strength = 0.10;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x),
	           mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x), u.y);
}

float fbm(vec2 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 5; i++) {
		v += a * vnoise(p);
		p = p * 2.07 + vec2(7.3, 3.1);
		a *= 0.5;
	}
	return v;
}

// Sharp-ish ridgeline built from layered value noise.
float ridge_height(float x, float base, float amp, float freq, float seed) {
	float n = fbm(vec2(x * freq + seed, seed * 1.7));
	float ridged = 1.0 - abs(n * 2.0 - 1.0);
	return base - amp * ridged;
}

void fragment() {
	vec2 uv = UV;

	// ---- sky gradient -----------------------------------------------------
	vec3 col = mix(sky_top, sky_mid, smoothstep(0.0, 0.62, uv.y));
	col = mix(col, sky_horizon, smoothstep(0.52, 1.0, uv.y) * 0.85);

	// Warm dusk bloom low on the horizon, slightly left of centre.
	vec2 hp = vec2(0.62, 0.74);
	float hd = distance(vec2(uv.x, uv.y * 1.35), vec2(hp.x, hp.y * 1.35));
	col += glow_color * exp(-hd * 4.2) * 0.22;

	// ---- moon -------------------------------------------------------------
	// Correct for the 16:9 viewport so the disc stays circular.
	vec2 mp = vec2(0.815, 0.205);
	vec2 mq = vec2((uv.x - mp.x) * 1.7778, uv.y - mp.y);
	float md = length(mq);
	col += vec3(0.48, 0.56, 0.78) * exp(-md * 5.4) * 0.20;
	col += vec3(0.85, 0.89, 1.0) * smoothstep(0.0105, 0.0085, md) * 0.85;
	col += vec3(0.85, 0.89, 1.0) * exp(-max(md - 0.010, 0.0) * 90.0) * 0.12;

	// ---- stars ------------------------------------------------------------
	vec2 sp = uv * vec2(220.0, 130.0);
	vec2 cell = floor(sp);
	float h = hash12(cell);
	float star = step(0.9945, h);
	float tw = 0.55 + 0.45 * sin(TIME * (0.8 + h * 3.0) + h * 57.0);
	float star_fade = smoothstep(0.0, 0.34, uv.y) * (1.0 - smoothstep(0.48, 0.72, uv.y));
	float dd = distance(fract(sp), vec2(0.5));
	col += vec3(0.72, 0.80, 1.0) * star * tw * star_fade * smoothstep(0.42, 0.0, dd) * 0.55;

	// ---- drifting high cloud bands ---------------------------------------
	float cloud = fbm(vec2(uv.x * 3.1 + TIME * 0.008, uv.y * 5.0 - TIME * 0.002));
	cloud = smoothstep(0.56, 0.82, cloud) * (1.0 - smoothstep(0.30, 0.62, uv.y));
	col = mix(col, mix(sky_mid, glow_color * 0.85, 0.25), cloud * 0.16);

	// ---- ridgelines -------------------------------------------------------
	float far_h = ridge_height(uv.x, 0.585, 0.085, 2.1, 2.7);
	float mid_h = ridge_height(uv.x, 0.700, 0.115, 1.45, 9.4);
	float near_h = ridge_height(uv.x, 0.840, 0.095, 3.0, 4.1);

	// Haze lift just above each ridge line keeps the layers separated.
	col = mix(col, ridge_far, smoothstep(far_h - 0.002, far_h + 0.001, uv.y));
	col += glow_color * smoothstep(0.014, 0.0, abs(uv.y - far_h)) * 0.055;
	col = mix(col, ridge_mid, smoothstep(mid_h - 0.002, mid_h + 0.001, uv.y));
	col += glow_color * smoothstep(0.010, 0.0, abs(uv.y - mid_h)) * 0.035;
	col = mix(col, ridge_near, smoothstep(near_h - 0.002, near_h + 0.001, uv.y));

	// ---- valley mist ------------------------------------------------------
	float mist_band = smoothstep(0.60, 0.72, uv.y) * (1.0 - smoothstep(0.74, 0.90, uv.y));
	float mist = fbm(vec2(uv.x * 2.2 + TIME * 0.004, uv.y * 7.0));
	col += vec3(0.58, 0.52, 0.52) * mist_band * mist * mist_strength;

	// ---- vignette + subtle grain -----------------------------------------
	vec2 vc = uv - 0.5;
	float vig = smoothstep(0.86, 0.24, length(vc * vec2(1.05, 0.95)));
	col *= mix(0.72, 1.0, vig);
	col += (hash12(uv * 917.0 + vec2(TIME * 0.7)) - 0.5) * 0.012;

	COLOR = vec4(col, 1.0);
}
