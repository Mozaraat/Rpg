// Energy barrier that seals a dungeon floor: the "wall of light" that keeps a
// floor suspended. Used for the perimeter walls; the ceiling itself is opaque
// and lives in dungeon_ceiling.gdshader.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, shadows_disabled, blend_mix;

uniform vec3 barrier_color : source_color = vec3(0.42, 0.62, 0.95);
uniform float strength = 1.0;
uniform float grid_scale = 1.6;
uniform float strand_speed = 0.35;
uniform int barrier_mode = 0; // 0 = vertical wall strands

varying vec2 v_uv;

void vertex() {
	v_uv = UV;
}

void fragment() {
	// Perimeter wall: slow vertical strands with a bright travelling band.
	float strands = 0.68 + 0.32 * sin(v_uv.x * grid_scale * 42.0 + TIME * strand_speed);
	float band = smoothstep(0.0, 0.35, v_uv.y) * (1.0 - smoothstep(0.55, 1.0, v_uv.y));
	float pulse = 0.80 + 0.20 * sin(TIME * 1.1 + v_uv.y * 6.0);
	float alpha = strands * band * 0.14 * pulse * strength;
	vec3 tint = barrier_color * (1.0 + strands * 0.25);
	ALBEDO = tint * (1.25 + 0.35 * strands);
	ALPHA = clamp(alpha, 0.0, 0.26);
}
