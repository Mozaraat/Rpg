// Terrain - physically grounded, procedural grass / dirt path / sand / rock / snow.
//
// The vertex colour carries the biome tint and the painted path mask in alpha.
// Everything else is world-space noise, so chunks tile seamlessly and no textures
// are required. Detail fades with distance to keep the image stable (no shimmer).
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

uniform float water_level = 0.0;
uniform float tide_offset = 0.0;
uniform float snow_height = 68.0;
uniform float detail_strength = 1.0;
uniform float cobble_scale = 5.8;
uniform float grass_detail = 1.0;

varying vec3 v_world;
varying vec3 v_nrm;
varying vec4 v_col;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.xx + p3.yz) * p3.zy);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	float a = hash12(i);
	float b = hash12(i + vec2(1.0, 0.0));
	float c = hash12(i + vec2(0.0, 1.0));
	float d = hash12(i + vec2(1.0, 1.0));
	return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm2(vec2 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) {
		v += a * vnoise(p);
		p = p * 2.03 + vec2(17.3, 9.1);
		a *= 0.5;
	}
	return v;
}

float fbm2_fast(vec2 p) {
	return vnoise(p) * 0.55 + vnoise(p * 2.07 + 4.3) * 0.30 + vnoise(p * 4.31 + 9.7) * 0.15;
}

void vertex() {
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	v_nrm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	// Vertex colours are authored in sRGB; work in linear space from here on.
	v_col = vec4(pow(COLOR.rgb, vec3(2.2)), COLOR.a);
}

void fragment() {
	vec3 wp = v_world;
	vec2 xz = wp.xz;
	float slope = 1.0 - clamp(v_nrm.y, 0.0, 1.0);
	float dist = length(wp - CAMERA_POSITION_WORLD);
	float detail_fade = exp(-dist * 0.0085) * detail_strength;
	// Large-scale relief stays visible much farther out than grain. Without it the
	// distant mountain walls read as smooth painted clay against the sky.
	float far_relief = smoothstep(60.0, 190.0, dist) * (1.0 - smoothstep(340.0, 620.0, dist));

	// ---- noise layers -----------------------------------------------------
	float n_macro = fbm2_fast(xz * 0.020);           // biome-scale patchiness
	float n_large = fbm2_fast(xz * 0.085 + 3.7);     // field-scale variation
	float n_mid    = fbm2_fast(xz * 0.42 + 11.3);    // clump-scale
	float n_fine   = vnoise(xz * 3.7);               // grain
	float n_grain  = vnoise(xz * 17.0 + 7.1);        // micro grain

	// ---- grass ------------------------------------------------------------
	vec3 base = v_col.rgb;
	vec3 grass = base * mix(0.66, 1.24, n_macro);
	grass *= mix(0.80, 1.16, n_large);
	grass *= mix(0.88, 1.10, n_mid);
	// Natural meadows are not one flat green: warm dry patches, darker clover
	// patches and a little yellow-green sun bleaching break up the sheet.
	float patch = smoothstep(0.40, 0.78, fbm2(xz * 0.16 + 23.1));
	grass = mix(grass, grass * vec3(1.13, 1.02, 0.72), patch * 0.34);
	float dark_patch = smoothstep(0.58, 0.92, fbm2(xz * 0.31 + 7.7));
	grass = mix(grass, grass * vec3(0.82, 0.94, 0.88), dark_patch * 0.28);
	// sun-bleached tips and dry patches
	vec3 dry = vec3(0.30, 0.28, 0.11) * mix(0.8, 1.2, n_large);
	float dry_w = smoothstep(0.50, 0.86, n_large + n_mid * 0.30) * smoothstep(0.0, 0.35, slope);
	grass = mix(grass, dry, dry_w * 0.50);
	// a little blade-level speckle (fades out with distance)
	float blades = vnoise(xz * 34.0 + vec2(0.0, xz.x * 1.7));
	grass *= mix(1.0, mix(0.76, 1.22, blades), detail_fade * 0.9);
	grass *= mix(1.0, 0.90 + 0.18 * n_grain, detail_fade * 0.7);

	// ---- rock / cliff -----------------------------------------------------
	// Broad bedding planes, not tight stripes: the old 0.48 vertical frequency
	// painted hard horizontal bands across every snowfield.
	float strata = fbm2(vec2((xz.x + xz.y) * 0.042, wp.y * 0.19));
	float mineral = smoothstep(0.62, 0.92, fbm2(xz * 0.9 + wp.yy * 0.6));
	// A second, much larger rock formation mask gives mountains real ribs and
	// buttresses instead of one continuous white scoop.
	float crag = smoothstep(0.52, 0.84, fbm2(xz * 0.032 + 27.4) + slope * 0.42);
	vec3 rock_dark = vec3(0.105, 0.098, 0.090);
	vec3 rock_light = vec3(0.385, 0.350, 0.300);
	vec3 rock = mix(rock_dark, rock_light, strata);
	rock *= mix(0.78, 1.14, n_mid);
	rock *= mix(1.0, 0.88, mineral * 0.55);
	// damp, mossy seams on gentler rock faces
	float moss = smoothstep(0.55, 0.95, fbm2(xz * 1.8 + wp.yy * 0.9)) * (1.0 - smoothstep(0.35, 0.7, slope));
	rock = mix(rock, vec3(0.09, 0.17, 0.055), moss * 0.35);

	// ---- sand / shore -----------------------------------------------------
	vec3 sand = mix(vec3(0.52, 0.41, 0.24), vec3(0.78, 0.67, 0.45), n_fine);
	sand *= mix(0.9, 1.08, n_mid);
	float pebbles = smoothstep(0.72, 0.94, vnoise(xz * 8.5));
	sand = mix(sand, sand * vec3(0.62, 0.60, 0.57), pebbles * 0.55);

	// ---- dirt path + cobbles ---------------------------------------------
	vec3 dirt = mix(vec3(0.115, 0.072, 0.040), vec3(0.26, 0.17, 0.095), n_mid);
	dirt *= mix(0.86, 1.12, n_grain);

	// small, irregular setts with mortar and moss in the joints
	vec2 cp = xz * cobble_scale;
	vec2 cip = floor(cp);
	vec2 cfp = fract(cp);
	float cd1 = 8.0;
	float cd2 = 8.0;
	vec2 cid = vec2(0.0);
	for (int j = -1; j <= 1; j++) {
		for (int i = -1; i <= 1; i++) {
			vec2 g = vec2(float(i), float(j));
			vec2 o = hash22(cip + g);
			vec2 r = g + o * 0.78 + 0.11 - cfp;
			float d = dot(r, r);
			if (d < cd1) { cd2 = cd1; cd1 = d; cid = cip + g; }
			else if (d < cd2) { cd2 = d; }
		}
	}
	float edge = sqrt(cd2) - sqrt(cd1);
	float cm = smoothstep(0.018, 0.095, edge);
	float stone_rnd = hash12(cid);
	vec3 stone = mix(vec3(0.145, 0.135, 0.122), vec3(0.295, 0.278, 0.250), stone_rnd);
	stone *= mix(0.82, 1.12, vnoise(cid * 3.1 + xz * 1.6));
	stone *= mix(0.90, 1.06, n_grain);
	// subtle warm/cool per-stone mineral variation keeps the paving from reading as one flat white sheet
	stone *= mix(vec3(1.0), vec3(1.06, 1.0, 0.90), hash12(cid + 7.3));
	vec3 mortar = vec3(0.075, 0.070, 0.062) * mix(0.9, 1.1, n_grain);
	vec3 cobble = mix(mortar, stone, cm);
	cobble = mix(cobble, cobble * vec3(0.80, 0.93, 0.66), (1.0 - cm) * 0.20);
	// Distant paving becomes a calm gravel tone instead of a field of shimmering
	// one-pixel setts. The transition starts well beyond conversational range.
	float path_far = smoothstep(40.0, 95.0, dist);
	vec3 cobble_far = mix(vec3(0.205, 0.188, 0.158), vec3(0.310, 0.282, 0.236), n_large);
	cobble = mix(cobble, cobble_far, path_far);

	// ---- blend masks ------------------------------------------------------
	// Shoreline bands follow the tide only where the bed is deep ocean water.
	float wl = water_level + tide_offset * (1.0 - smoothstep(-2.4, -1.4, wp.y));
	float rock_w = smoothstep(0.20, 0.38, slope + (n_mid - 0.5) * 0.20);
	float sand_w = 1.0 - smoothstep(0.55, 1.9, wp.y - wl + (n_large - 0.5) * 1.2);
	float snow_w = smoothstep(snow_height - 1.5, snow_height + 2.5, wp.y + (n_large - 0.5) * 5.0);
	snow_w *= 1.0 - smoothstep(0.32, 0.58, slope);
	// Snow lingers in hollows and on shaded faces, exposing rock on wind-scoured ridges.
	snow_w *= mix(0.55, 1.15, n_mid);
	float path_w = smoothstep(0.38, 0.72, v_col.a + (n_mid - 0.5) * 0.28);

	vec3 col = grass;
	col = mix(col, sand, sand_w);
	col = mix(col, dirt, path_w * (1.0 - sand_w * 0.65));
	col = mix(col, cobble, smoothstep(0.58, 0.92, v_col.a) * (1.0 - sand_w * 0.5));
	col = mix(col, rock, rock_w);
	// Wind-scoured ridges and steep faces keep their rock even above the snow line.
	// Use the broad crag mask for this, otherwise high peaks get speckled with
	// high-frequency grey flecks that look like television static at distance.
	float bare_ridge = crag * mix(0.45, 1.0, smoothstep(0.30, 0.72, slope));
	float snow_ribs = smoothstep(0.48, 0.78, fbm2(xz * 0.075 + wp.y * 0.26 + 8.3));
	bare_ridge = max(bare_ridge, snow_ribs * smoothstep(0.48, 0.80, slope) * 0.55);
	col = mix(col, rock, snow_w * bare_ridge * 0.82);
	// Snow is never pure white: it picks up cold sky bounce in shadow and warm sun on lit faces.
	vec3 snow = mix(vec3(0.30, 0.36, 0.46), vec3(0.58, 0.62, 0.68), smoothstep(0.25, 0.82, n_mid * 0.55 + strata * 0.45));
	snow *= mix(0.88, 1.03, fbm2(xz * 0.16 + wp.yy * 0.25));
	snow = mix(snow, snow * vec3(0.86, 0.96, 1.10), smoothstep(0.55, 0.95, slope) * 0.55);
	// Wind-scoured sastrugi in the lee of ridges: faint, low-frequency, and only
	// near the camera so it never shimmers on distant peaks.
	snow *= mix(1.0, 0.94 + 0.12 * vnoise(xz * 0.9 + wp.yy * 0.5), detail_fade * 0.55);
	col = mix(col, snow, snow_w);

	// ---- wet shoreline ----------------------------------------------------
	float wet = 1.0 - smoothstep(0.0, 0.55, wp.y - wl);
	col *= mix(1.0, 0.62, wet);
	// Underwater ground reads cold and dim, never black.
	float under = smoothstep(wl, wl - 3.5, wp.y);
	col = mix(col, col * vec3(0.34, 0.52, 0.56) + vec3(0.01, 0.03, 0.045), under);

	// A touch of aerial desaturation with distance helps the fog feel real.
	col = mix(col, col * vec3(0.93, 0.97, 1.02), smoothstep(90.0, 280.0, dist) * 0.5);

	ALBEDO = col;
	ROUGHNESS = mix(0.96, 0.42, snow_w * 0.7);
	ROUGHNESS = mix(ROUGHNESS, 0.34, wet * 0.65);
	SPECULAR = mix(0.18, 0.36, wet + snow_w * 0.4);
	METALLIC = 0.0;
	// Soft ambient occlusion in the creases of the land.
	AO = mix(1.0, 0.82, smoothstep(0.25, 0.65, slope));
	AO *= mix(1.0, 0.9, (1.0 - cm) * smoothstep(0.55, 0.9, v_col.a));
	BACKLIGHT = grass * (0.08 + 0.09 * n_mid) * grass_detail * (1.0 - rock_w);

	// ---- micro relief -----------------------------------------------------
	// Two-scale normal perturbation, faded with distance so it never aliases.
	float e = 0.22;
	float h0 = fbm2_fast(xz * 1.35);
	float hx = fbm2_fast((xz + vec2(e, 0.0)) * 1.35);
	float hz = fbm2_fast((xz + vec2(0.0, e)) * 1.35);
	float fine_e = 0.11;
	float g0 = vnoise(xz * 9.0);
	float gx = vnoise((xz + vec2(fine_e, 0.0)) * 9.0);
	float gz = vnoise((xz + vec2(0.0, fine_e)) * 9.0);
	vec2 grad = vec2((hx - h0), (hz - h0)) / e;
	grad += vec2((gx - g0), (gz - g0)) / fine_e * 0.35;
	float bump = mix(0.32, 1.35, max(rock_w, snow_w * 0.62));
	// A broad, non-aliasing relief term for distant crags and mountain folds.
	float ef = 2.0;
	float f0 = fbm2_fast(xz * 0.052);
	float fx = fbm2_fast((xz + vec2(ef, 0.0)) * 0.052);
	float fz = fbm2_fast((xz + vec2(0.0, ef)) * 0.052);
	vec2 fgrad = vec2(fx - f0, fz - f0) / ef;
	vec3 nt = normalize(v_nrm
		+ vec3(-grad.x, 0.0, -grad.y) * bump * detail_fade * 0.16
		+ vec3(-fgrad.x, 0.0, -fgrad.y) * far_relief * 1.55);
	NORMAL = normalize((VIEW_MATRIX * vec4(nt, 0.0)).xyz);
}
