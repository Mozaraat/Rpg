// Procedural building materials in a single shader (stone, planks, plaster, tiles,
// thatch, cobble, cloth). UVs are authored in METERS by MeshKit, so every pattern
// keeps a believable real-world scale on buildings of any size.
shader_type spatial;
render_mode cull_back, diffuse_burley, specular_schlick_ggx;

uniform int pattern = 0;  // 0 stone, 1 planks, 2 plaster, 3 tiles, 4 thatch, 5 cobble, 6 stripes
uniform vec3 color_a : source_color = vec3(0.55, 0.52, 0.48);
uniform vec3 color_b : source_color = vec3(0.40, 0.38, 0.35);
uniform vec3 color_c : source_color = vec3(0.18, 0.17, 0.16);
uniform float bump_strength = 1.0;
uniform float rough = 0.88;
uniform float weathering = 1.0;

varying vec3 v_world;
varying vec3 v_world_n;

float hash11(float p) {
	p = fract(p * 0.1031);
	p *= p + 33.33;
	p *= p + p;
	return fract(p);
}
float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
vec2 hash22(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.xx + p3.yz) * p3.zy);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
	return vnoise(p) * 0.55 + vnoise(p * 2.1 + 7.7) * 0.30 + vnoise(p * 4.3 + 3.1) * 0.15;
}

void vertex() {
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	v_world_n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

// Returns albedo in xyz, height in w.
vec4 eval_pattern(vec2 uv) {
	vec3 col = color_a;
	float h = 0.0;
	if (pattern == 0) {            // ---- stone blocks
		float rh = 0.34;
		float row = floor(uv.y / rh);
		float bl = 0.55 + 0.35 * hash11(row * 3.7);
		float x = uv.x / bl + hash11(row) * 4.0;
		float cell = floor(x);
		vec2 f = vec2(fract(x), fract(uv.y / rh));
		float edge = min(min(f.x, 1.0 - f.x) * bl, min(f.y, 1.0 - f.y) * rh);
		float m = smoothstep(0.0, 0.032, edge);
		float rnd = hash12(vec2(cell, row));
		vec3 st = mix(color_a, color_b, rnd) * (0.76 + 0.42 * fbm(uv * 8.0));
		// weathered top bevel catches the light
		st *= mix(0.86, 1.06, smoothstep(0.0, 0.08, min(f.y, 1.0 - f.y)));
		col = mix(color_c, st, m);
		h = m * (0.55 + 0.45 * fbm(uv * 12.0)) + smoothstep(0.0, 0.1, edge) * 0.2;
	} else if (pattern == 1) {     // ---- vertical planks
		float pw = 0.21;
		float cell = floor(uv.x / pw);
		float fx = fract(uv.x / pw);
		float rnd = hash11(cell);
		float grain = fbm(vec2(uv.x * 22.0, uv.y * 1.6 + rnd * 40.0));
		float knot = smoothstep(0.86, 0.98, vnoise(vec2(uv.x * 7.0 + rnd * 9.0, uv.y * 0.9 + rnd * 20.0)));
		float seam = smoothstep(0.0, 0.06, min(fx, 1.0 - fx));
		float jlen = 0.9 + rnd * 0.9;
		float jy = fract(uv.y / jlen + rnd * 5.0);
		float joint = smoothstep(0.0, 0.012, min(jy, 1.0 - jy) * jlen);
		col = mix(color_a, color_b, grain) * (0.85 + 0.3 * rnd);
		col = mix(col, col * color_c * 2.2, knot * 0.55);
		col = mix(color_c, col, seam * joint);
		h = seam * joint * 0.6 + grain * 0.2 + knot * 0.25;
	} else if (pattern == 2) {     // ---- plaster
		float n = fbm(uv * 2.6);
		float crack = smoothstep(0.86, 0.98, vnoise(vec2(uv.x * 5.0 + uv.y * 1.3, uv.y * 6.0 - uv.x * 0.7)));
		col = mix(color_a, color_b, n) * (0.94 + 0.12 * vnoise(uv * 38.0));
		col = mix(col, color_c, crack * 0.18);
		h = fbm(uv * 20.0) * 0.5 - crack * 0.35;
	} else if (pattern == 3) {     // ---- roof tiles (rows run along v = slope direction)
		float rh = 0.30;
		float row = floor(uv.y / rh);
		float fy = fract(uv.y / rh);
		float x = uv.x / 0.26 + mod(row, 2.0) * 0.5;
		float cell = floor(x);
		float fx = fract(x);
		float rnd = hash12(vec2(cell, row));
		float side = smoothstep(0.0, 0.07, min(fx, 1.0 - fx));
		float shade = mix(0.5, 1.0, smoothstep(0.0, 0.45, fy));
		col = mix(color_a, color_b, rnd) * shade * mix(0.65, 1.0, side) * (0.9 + 0.2 * vnoise(uv * 9.0));
		h = smoothstep(0.0, 0.55, fy) * mix(0.5, 1.0, side);
	} else if (pattern == 4) {     // ---- thatch
		float s = fbm(vec2(uv.x * 26.0, uv.y * 2.2));
		float band = smoothstep(0.0, 0.08, abs(fract(uv.y / 0.5) - 0.5) * 2.0);
		col = mix(color_a, color_b, s) * (0.8 + 0.4 * hash12(floor(vec2(uv.x * 26.0, uv.y * 3.0)))) * mix(0.7, 1.0, band);
		h = s * 0.8 + band * 0.2;
	} else if (pattern == 5) {     // ---- cobblestones (voronoi)
		vec2 p = uv * 2.4;
		vec2 ip = floor(p);
		vec2 fp = fract(p);
		float d1 = 8.0;
		float d2 = 8.0;
		vec2 id = vec2(0.0);
		for (int j = -1; j <= 1; j++) {
			for (int i = -1; i <= 1; i++) {
				vec2 g = vec2(float(i), float(j));
				vec2 o = hash22(ip + g);
				vec2 r = g + o * 0.8 + 0.1 - fp;
				float d = dot(r, r);
				if (d < d1) { d2 = d1; d1 = d; id = ip + g; }
				else if (d < d2) { d2 = d; }
			}
		}
		float edge = sqrt(d2) - sqrt(d1);
		float m = smoothstep(0.0, 0.10, edge);
		float rnd = hash12(id);
		col = mix(color_c, mix(color_a, color_b, rnd) * (0.85 + 0.3 * vnoise(uv * 10.0)), m);
		h = m * 0.8 + vnoise(uv * 14.0) * 0.2;
	} else {                       // ---- awning stripes
		float s = step(0.5, fract(uv.x / 0.7));
		col = mix(color_a, color_b, s) * (0.92 + 0.1 * vnoise(uv * 30.0));
		h = vnoise(uv * 40.0) * 0.3;
	}
	return vec4(col, h);
}

void fragment() {
	vec2 uv = UV;
	vec4 p0 = eval_pattern(uv);
	float e = 0.012;
	float hx = eval_pattern(uv + vec2(e, 0.0)).w;
	float hy = eval_pattern(uv + vec2(0.0, e)).w;
	vec2 grad = vec2(hx - p0.w, hy - p0.w) / e;

	vec3 col = p0.rgb * pow(COLOR.rgb, vec3(2.2));

	// ---- weathering ------------------------------------------------------
	// Vertical rain streaks, grime gathering low on the wall, and moss in damp
	// crevices. This is what stops procedural materials reading as flat paint.
	float grime = fbm(vec2(uv.x * 1.4, uv.y * 0.35 + 3.1));
	float streaks = fbm(vec2(uv.x * 5.5 + grime * 1.5, uv.y * 0.28));
	col *= mix(1.0, mix(0.78, 1.06, grime), weathering * 0.55);
	col *= mix(1.0, mix(0.86, 1.02, streaks), weathering * 0.35);
	// Damp, dirty base on walls (UV.y runs up the wall for box geometry).
	float base_damp = 1.0 - smoothstep(0.0, 1.15, uv.y);
	col *= mix(1.0, 0.78, base_damp * weathering * 0.55);

	vec3 n_world = normalize(v_world_n);
	float moss_mask = smoothstep(0.58, 0.92, fbm(vec2(uv.x * 3.1, uv.y * 1.4) + n_world.xz * 2.0));
	moss_mask *= (1.0 - smoothstep(0.35, 0.85, n_world.y)) * weathering;
	col = mix(col, vec3(0.14, 0.19, 0.08) * mix(0.7, 1.05, grime), moss_mask * 0.32);

	ALBEDO = col;
	ROUGHNESS = clamp(rough + (grime - 0.5) * 0.12, 0.05, 1.0);
	SPECULAR = 0.32;
	// Mortar and crevices are darker: cheap, effective cavity AO.
	AO = mix(0.80, 1.0, smoothstep(0.0, 0.55, p0.w));

	// ---- perturb the geometric normal -----------------------------------
	// Build a world-space tangent frame from screen derivatives so the bump
	// works on arbitrary meshes (boxes, cylinders, roofs...).
	vec3 dpdx = dFdx(v_world);
	vec3 dpdy = dFdy(v_world);
	vec3 tangent = normalize(cross(dpdy, n_world));
	vec3 bitangent = normalize(cross(n_world, tangent));
	vec3 n_pert = normalize(n_world + (tangent * grad.x + bitangent * grad.y) * bump_strength * 0.0045);
	NORMAL = normalize((VIEW_MATRIX * vec4(n_pert, 0.0)).xyz);
}
