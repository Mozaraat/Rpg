// Authored Heartlands waterfall: layered downward flow, broken rivulets,
// soft edge transparency and bright turbulence where water meets the pool.
shader_type spatial;
render_mode blend_mix, depth_prepass_alpha, cull_disabled, diffuse_burley, specular_schlick_ggx;

uniform vec3 water_tint : source_color = vec3(0.16, 0.48, 0.60);
uniform vec3 foam_tint : source_color = vec3(0.72, 0.91, 0.98);
uniform float flow_speed = 1.85;
uniform float stream_phase = 0.0;
uniform float opacity_scale = 1.0;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

void fragment() {
    vec2 uv = UV;
    float t = TIME;
    float edge_fade = smoothstep(0.0, 0.055, uv.x) * (1.0 - smoothstep(0.945, 1.0, uv.x));
    float flow_a = uv.y * 36.0 + t * flow_speed + sin(uv.x * 15.0 + t * 0.65 + stream_phase) * 0.85;
    float flow_b = uv.y * 79.0 + t * (flow_speed * 1.42) - uv.x * 11.0 + stream_phase;
    float ribbons = pow(max(sin(flow_a), 0.0), 7.0) * 0.72 + pow(max(sin(flow_b), 0.0), 15.0) * 0.28;
    float turbulence = noise2(vec2(uv.x * 8.5 + stream_phase, uv.y * 6.0 - t * 1.1));
    float broken_flow = smoothstep(0.20, 0.82, ribbons * 0.72 + turbulence * 0.48);
    float micro_glints = pow(max(sin(flow_b * 1.75 + turbulence * 3.0), 0.0), 19.0);
    float top_foam = smoothstep(0.90, 0.995, uv.y) * smoothstep(0.15, 0.72, turbulence);
    float plunge_foam = (1.0 - smoothstep(0.015, 0.12, uv.y)) * (0.55 + 0.45 * noise2(vec2(uv.x * 19.0, t * 1.8)));
    float foam = clamp(max(top_foam, plunge_foam), 0.0, 1.0);

    vec3 body = water_tint * mix(0.78, 1.20, turbulence);
    body = mix(body, foam_tint, broken_flow * 0.52);
    body = mix(body, foam_tint * 1.10, foam * 0.82);
    body += vec3(0.20, 0.29, 0.34) * micro_glints * 0.28;

    float alpha = edge_fade * (0.38 + broken_flow * 0.31 + micro_glints * 0.12 + foam * 0.22);
    alpha *= opacity_scale;
    ALBEDO = body;
    ROUGHNESS = mix(0.22, 0.075, micro_glints + foam * 0.35);
    SPECULAR = 0.88;
    METALLIC = 0.0;
    EMISSION = body * (0.035 + foam * 0.055);
    ALPHA = clamp(alpha, 0.0, 0.92);
}
