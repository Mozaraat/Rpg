// Sky - layered atmospheric gradient, sun/moon, stars and drifting clouds.
// DayNightCycle drives every colour uniform each frame, so dawn, noon, dusk and
// night all read distinctly without any baked sky textures.
shader_type sky;

uniform vec3 top_color : source_color = vec3(0.16, 0.37, 0.80);
uniform vec3 horizon_color : source_color = vec3(0.64, 0.78, 0.93);
uniform vec3 ground_color : source_color = vec3(0.35, 0.40, 0.45);
uniform vec3 sun_dir = vec3(0.0, 1.0, 0.0);       // direction toward the sun
uniform vec3 sun_color : source_color = vec3(1.0, 0.92, 0.75);
uniform float sun_strength = 1.0;
uniform vec3 twilight_color : source_color = vec3(1.0, 0.45, 0.2);
uniform float twilight_amount = 0.0;
uniform float night_amount = 0.0;
uniform float cloud_cover = 0.52;
uniform vec3 cloud_lit : source_color = vec3(1.0);
uniform vec3 cloud_dark : source_color = vec3(0.55, 0.62, 0.75);
uniform float cloud_speed = 0.006;
uniform float haze = 0.35;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float hash13(vec3 p3) {
	p3 = fract(p3 * 0.1031);
	p3 += dot(p3, p3.zyx + 31.32);
	return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 5; i++) {
		v += a * vnoise(p);
		p = p * 2.07 + vec2(11.7, 5.3);
		a *= 0.5;
	}
	return v;
}
float fbm3(vec2 p) {
	return vnoise(p) * 0.58 + vnoise(p * 2.11 + 5.1) * 0.28 + vnoise(p * 4.37 + 9.4) * 0.14;
}

void sky() {
	vec3 dir = normalize(EYEDIR);
	float up = dir.y;

	// ---- base atmosphere --------------------------------------------------
	vec3 col;
	if (up >= 0.0) {
		// three-step gradient keeps the zenith rich without a hard band
		col = mix(horizon_color, top_color, pow(clamp(up, 0.0, 1.0), 0.48));
		col = mix(col, top_color * 0.92, smoothstep(0.55, 1.0, up) * 0.35);
	} else {
		col = mix(horizon_color, ground_color, smoothstep(0.0, 0.30, -up));
	}

	float sd = max(dot(dir, normalize(sun_dir)), 0.0);
	float horizon_band = exp(-abs(up) * 4.6);

	// Broad forward scattering around the sun, strongest near the horizon.
	col += sun_color * pow(sd, 8.0) * 0.16 * sun_strength;
	col += sun_color * pow(sd, 64.0) * 0.22 * sun_strength;

	// Dusk/dawn warm band hugging the horizon on the sun side.
	col += twilight_color * twilight_amount * horizon_band * (pow(sd, 2.5) * 1.25 + 0.28);
	// Cool anti-solar side at twilight.
	col += vec3(0.16, 0.19, 0.30) * twilight_amount * horizon_band * (1.0 - pow(sd, 2.0)) * 0.55;

	// ---- stars + milky way ------------------------------------------------
	float star_fade = smoothstep(0.02, 0.30, up) * night_amount;
	if (star_fade > 0.001) {
		vec3 sp = dir * 260.0;
		float h = hash13(floor(sp));
		float star = step(0.9970, h);
		float tw = 0.62 + 0.38 * sin(TIME * (1.4 + h * 7.0) + h * 40.0);
		// Slightly different colour temperature for bright stars.
		vec3 sc = mix(vec3(1.0, 0.90, 0.78), vec3(0.78, 0.88, 1.0), hash13(floor(sp) + 7.3));
		col += sc * star * tw * star_fade * 1.5;
		// Faint galactic band.
		float band = exp(-pow((dir.y + dir.x * 0.55 + 0.12) * 3.4, 2.0));
		col += vec3(0.30, 0.34, 0.48) * band * star_fade * 0.055;
	}

	// ---- sun --------------------------------------------------------------
	col += sun_color * pow(sd, 48.0) * 0.55 * sun_strength;
	col += sun_color * pow(sd, 420.0) * 1.4 * sun_strength;
	col += sun_color * smoothstep(0.99955, 0.99988, sd) * 16.0 * sun_strength;

	// ---- moon -------------------------------------------------------------
	vec3 moon_dir = -normalize(sun_dir);
	float md = max(dot(dir, moon_dir), 0.0);
	float moon_disc = smoothstep(0.99935, 0.99965, md);
	float moon_craters = 1.0 - smoothstep(0.0, 0.5, abs(hash13(floor(dir * 900.0)) - 0.5));
	col += vec3(0.80, 0.86, 1.0) * moon_disc * (2.0 + moon_craters * 0.35) * night_amount;
	col += vec3(0.30, 0.38, 0.62) * pow(md, 150.0) * 0.35 * night_amount;

	// ---- clouds -----------------------------------------------------------
	if (up > 0.012) {
		vec2 cuv = dir.xz / (up + 0.16);
		vec2 drift = vec2(TIME * cloud_speed, TIME * cloud_speed * 0.42);
		// two layers: broken cumulus + high wispy cirrus
		float c = fbm(cuv * 0.85 + drift);
		float c2 = fbm(cuv * 0.85 + drift + normalize(sun_dir.xz + vec2(0.001)) * 0.065);
		float cirrus = fbm3(cuv * 2.2 + drift * 1.8 + vec2(31.0, 7.0));
		float thresh = 1.0 - cloud_cover;
		float density = smoothstep(thresh, thresh + 0.20, c);
		float wisps = smoothstep(0.62, 0.86, cirrus) * 0.26 * (1.0 - density);
		float lit = clamp(0.54 + (c - c2) * 5.4, 0.0, 1.0);
		// tops are brighter, bases darker
		lit = mix(lit, 1.0, smoothstep(0.45, 0.9, c) * 0.35);
		vec3 ccol = mix(cloud_dark, cloud_lit, lit);
		ccol += twilight_color * twilight_amount * 0.55 * pow(sd, 2.0);
		float edge = clamp(density * (1.0 - density) * 4.0, 0.0, 1.0);
		ccol += sun_color * edge * pow(sd, 6.0) * 0.55 * sun_strength;
		// cloud self-shadowing on the anti-sun side
		ccol *= 1.0 - smoothstep(0.0, 0.6, -sd) * 0.15;
		float fade = smoothstep(0.012, 0.22, up);
		col = mix(col, mix(horizon_color, ccol, fade), density * 0.93);
		col = mix(col, mix(horizon_color, ccol * 1.04, fade), wisps);
	}

	// ---- horizon haze ----------------------------------------------------
	// A thin bright band just above the horizon sells aerial perspective.
	float haze_band = exp(-abs(up + 0.01) * 22.0);
	col = mix(col, mix(horizon_color, sun_color, 0.12 * sun_strength), haze_band * haze * 0.32);

	COLOR = col;
}
