// Alpha-tested leaf / needle cards.
//
// The tree meshes keep their cheap blob cores for occlusion and shadow mass, but
// the silhouette is broken up by crossed cards carrying a procedural leaf-cluster
// texture. That removes the "smooth broccoli" look at close and mid range while
// staying fully procedural (no imported assets).
shader_type spatial;
render_mode cull_disabled, depth_prepass_alpha, diffuse_burley, specular_schlick_ggx;

uniform sampler2D leaf_texture : source_color, filter_linear_mipmap, repeat_disable;
uniform vec3 tint_a : source_color = vec3(0.16, 0.30, 0.10);
uniform vec3 tint_b : source_color = vec3(0.36, 0.55, 0.19);
uniform float alpha_cut = 0.36;
uniform float sway_amount = 0.06;
uniform float sway_height = 5.0;
uniform float wind_speed = 1.3;
uniform float translucency = 0.55;
uniform float roughness_value = 0.82;
uniform bool use_instance_tint = true;

varying vec3 v_tint;
varying float v_height01;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

void vertex() {
	vec3 inst_pos = MODEL_MATRIX[3].xyz;
	float t = TIME * wind_speed;
	float phase = dot(inst_pos.xz, vec2(0.21, 0.17));
	float gust = sin(t + phase) * 0.62 + sin(t * 2.3 + phase * 1.7) * 0.24;
	float flutter = sin(t * 4.1 + VERTEX.y * 2.3 + phase * 3.1) * 0.14;
	float h = clamp(VERTEX.y / max(sway_height, 0.001), 0.0, 1.0);
	float k = sway_amount * h * h;
	VERTEX.x += (gust + flutter) * k;
	VERTEX.z += cos(t * 0.8 + phase * 0.85) * 0.42 * k;
	v_height01 = h;

	// Per-instance colour variance is carried by the tint MultiMesh custom data.
	// Plain MeshInstance3D leaves INSTANCE_CUSTOM at (0,0,0); treat ~black as "no tint".
	vec3 inst_raw = INSTANCE_CUSTOM.rgb;
	vec3 inst = use_instance_tint && dot(inst_raw, inst_raw) > 0.0025 ? inst_raw : vec3(1.0);
	float v = clamp((inst.r + inst.g + inst.b) / 3.0, 0.82, 1.18);
	vec3 c = mix(tint_a, tint_b, clamp(v - 0.82, 0.0, 1.0) / 0.36);
	// A little per-card brightness variation so cards never read as a flat decal.
	float card_var = 0.90 + 0.20 * hash12(vec2(float(VERTEX.x + VERTEX.z) * 7.31, float(VERTEX.y) * 3.17));
	v_tint = c * inst * card_var;
}

void fragment() {
	vec4 tex = texture(leaf_texture, UV);
	if (tex.a < alpha_cut) {
		discard;
	}
	ALPHA = tex.a;
	ALPHA_SCISSOR_THRESHOLD = alpha_cut;

	vec3 col = tex.rgb * v_tint;
	// Soft top-lit gradient: cards low in the canopy sit in shade.
	float h = clamp(v_height01, 0.0, 1.0);
	col *= mix(0.80, 1.08, smoothstep(0.0, 0.75, h));

	ALBEDO = col;
	ROUGHNESS = roughness_value;
	SPECULAR = 0.28;
	BACKLIGHT = col * translucency;
	AO = mix(1.0, mix(0.72, 1.0, smoothstep(0.0, 0.7, h)), 0.30);
}
