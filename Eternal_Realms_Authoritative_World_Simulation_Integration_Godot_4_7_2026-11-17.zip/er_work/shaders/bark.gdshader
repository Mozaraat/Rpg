// Procedural bark. UVs on trunks/limbs are authored in metres by MeshKit, so the
// striations keep a constant physical size on trees of any scale. Vertex colour
// supplies the per-species base tone; this shader adds fissures, ridges and moss
// without any imported texture.
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

uniform vec3 bark_light : source_color = vec3(0.42, 0.30, 0.19);
uniform vec3 bark_dark : source_color = vec3(0.16, 0.115, 0.075);
uniform float fissure_scale = 9.0;
uniform float moss_amount = 0.22;

varying vec3 v_world_n;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
	return vnoise(p) * 0.55 + vnoise(p * 2.07 + 4.1) * 0.30 + vnoise(p * 4.11 + 9.3) * 0.15;
}

void vertex() {
	v_world_n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec2 uv = UV;
	// Long vertical fibres + deeper fissures. UV.x wraps around the trunk and
	// UV.y is in metres, so these bands stay the same physical size on every tree.
	float fibre = fbm(vec2(uv.x * 17.0, uv.y * 0.95));
	float ridge = 0.5 + 0.5 * sin(uv.x * 48.0 + fibre * 9.0 + uv.y * 0.11);
	float crevice = smoothstep(0.68, 0.95, fbm(vec2(uv.x * 24.0 + 4.3, uv.y * 1.6)));
	float knot = smoothstep(0.86, 0.99, vnoise(vec2(uv.x * 5.2 + 2.1, uv.y * 0.8)));

	vec3 bark = mix(bark_dark, bark_light, clamp(fibre * 0.82 + 0.18, 0.0, 1.0));
	bark *= mix(0.70, 1.18, ridge * fibre);
	bark *= 1.0 - crevice * 0.52;
	// Fine checkering in the furrows keeps close trunks from reading as smooth pipes.
	bark *= mix(0.88, 1.06, vnoise(vec2(uv.x * 46.0, uv.y * 3.4)));
	bark = mix(bark, bark * vec3(0.55, 0.42, 0.30), knot * 0.5);

	// Moss prefers the upper, damp side of roots and old trunks.
	float moss = smoothstep(0.45, 0.90, fbm(uv * 4.2 + 9.0)) * smoothstep(0.1, 0.8, v_world_n.y);
	bark = mix(bark, vec3(0.10, 0.18, 0.07), moss * moss_amount);

	// Vertex colour is the per-species bark tint (already authored in sRGB).
	vec3 tint = pow(clamp(COLOR.rgb, vec3(0.0), vec3(1.0)), vec3(2.2));
	ALBEDO = bark * mix(vec3(1.0), tint * 3.1, 0.72);
	ROUGHNESS = 0.94;
	SPECULAR = 0.14;
	AO = mix(0.62, 1.0, smoothstep(0.0, 0.55, ridge * fibre));
}
