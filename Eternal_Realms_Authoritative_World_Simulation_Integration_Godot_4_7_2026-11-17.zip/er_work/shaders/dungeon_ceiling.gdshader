shader_type spatial;
render_mode cull_disabled;

uniform vec3 barrier_color : source_color = vec3(0.42, 0.62, 0.95);
uniform vec3 stone_color : source_color = vec3(0.17, 0.165, 0.15);
uniform float coffer_scale = 52.0;

float hash21(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void fragment() {
	vec2 blocks = UV * coffer_scale;
	blocks.x += mod(floor(blocks.y), 2.0) * 0.5;
	vec2 cell = floor(blocks);
	vec2 f = fract(blocks);
	float edge = min(min(f.x, 1.0 - f.x), min(f.y, 1.0 - f.y));
	float mortar = smoothstep(0.006, 0.025, edge);
	float grain = hash21(floor(UV * 16000.0)) * 0.025;
	float tone = hash21(cell) * 0.03 - 0.015;
	ALBEDO = (stone_color + vec3(tone + grain)) * mix(0.35, 1.0, mortar);
	ROUGHNESS = 0.95;
	EMISSION = barrier_color * 0.008;
}
