# Underwater Exploration Expansion — 17 November 2026

## Implemented in this milestone

- Restored the underwater exploration system into the latest world/ecology project and registered it in `scenes/main.tscn`.
- Retained dive controls (Space to ascend, Ctrl to descend), oxygen depletion/refill, pressure damage, HUD depth/pressure readout, and streamed procedural sea sites.
- Expanded cave sites into three connected chambers with open swim passages, roof/side-wall silhouettes, crystal clusters, and multiple breathable air pockets.
- Added interactable underwater harvest nodes for coral fragments, seaweed, pearls, and abyssal relics.
- Added ancient cache interactables that grant a small randomized relic/pearl reward.
- Added deep trench lair architecture and an authoritative hostile abyssal leviathan / Drowned Sovereign encounter. The marine creature's health thresholds drive its multi-stage combat behavior.
- Restored the underwater-capable player movement and hostile marine creature combat implementation from the preceding underwater milestone.
- Added low-frequency, server-authoritative aquatic reproduction with a hard five-fish local population ceiling, plus gradual current-influenced home-range migration.

## Important implementation boundaries

- Underwater cave geometry is currently procedural visual geometry; passages are swim-through openings, but this milestone does not yet generate full navigable cave collision meshes or a dedicated cave interior scene.
- Aquatic breeding is a lightweight local population simulation, not a world-wide species genetics/food-web model. Migration follows local current vectors rather than a full seasonal ocean-current simulation.
- Treasure and resource claims are currently runtime interactions; durable cross-session / cross-server claim persistence still needs to be connected to the shared-world persistence backend.
- Boss encounters use the existing multi-phase marine creature combat implementation. Lair state and boss defeat are not yet durably persisted across server restarts.
- No downloaded art assets were introduced; structures and resources use procedural meshes/materials.

## Validation

- Checked the main scene's external-resource count and load-step declaration.
- Checked all newly referenced scene/preload paths exist.
- Checked modified scripts for duplicate function declarations.
- Godot 4.7 executable was not available in this environment, so an engine parser run and live multiplayer/runtime test were not performed.
