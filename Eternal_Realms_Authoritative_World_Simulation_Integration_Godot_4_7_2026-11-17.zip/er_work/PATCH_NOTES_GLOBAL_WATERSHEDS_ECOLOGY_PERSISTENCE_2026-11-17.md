# Global Watersheds, Regional Ecology and Persistence Pass — 2026-11-17

## Implemented

### World-wide drainage topology
- Added a deterministic drainage graph for the complete currently authored world footprint (cell coordinates -14 through +14 at 64 m resolution).
- Builds the graph independently of player position and caches it per world seed.
- Uses a priority-flood traversal seeded from ocean cells and world-edge outlets. This fills enclosed terrain depressions to their spill elevation for routing, preventing small heightfield pits from terminating every river.
- Stores downstream links and accumulates upstream contributing area from headwaters toward outlets.
- Active local hydrology now follows this global topology and uses its topological order, rather than recalculating an unrelated local downhill path.
- River discharge includes a coarse catchment rainfall yield for upstream terrain that is currently unloaded, plus groundwater-fed spring/baseflow contribution. River width scales with contributing area and flow.

### Water state and flow
- Added persisted water depth, horizontal velocity and momentum fields.
- Flow direction now follows the cached drainage link.
- These fields are a first-order shallow-flow approximation, not a validated shallow-water equation solver. It does not yet conserve water volume through a full two-dimensional flux scheme, resolve hydraulic jumps, or propagate a dynamically computed shoreline mesh.
- Flood visuals remain terrain-cell surfaces; they are not yet a physically solved floodplain.

### Unloaded wildlife populations
- Added per-authored-region coarse population counts for rabbits, deer, boars and wolves.
- Region populations reproduce, mature, experience climate/moisture-related carrying capacity and mortality, and seasonally disperse between regions without requiring loaded critter nodes.
- These are population-level records, not persistent individual animal agents or route-following herds.

### Durable terrain and central persistence
- Erosion now stores its exact accumulated height delta per hydrology cell rather than attempting to reconstruct terrain deformation from the normalized erosion index.
- Rebuild invalidation includes the affected chunk and its eight neighbours.
- Hydrology and regional ecology snapshots now optionally load/save as central world entities through the existing CentralBackend API when production mode, authority and backend configuration are all present.
- Local JSON snapshots remain the development/offline fallback.

## Explicit remaining work
- The drainage graph covers the current authored map bounds, not an unlimited planet. Expanding procedural continents requires extending or tiling the graph with stable basin boundary contracts.
- Priority-flood routing fills depressions for topology but does not yet create fully modelled lakes, wetlands, reservoirs or karst systems.
- Catchment discharge is a coarse upstream rainfall estimate. A proper distributed water budget must integrate spatially varying rainfall, infiltration, snowmelt, groundwater exchange and travel-time delays across every basin.
- Water depth/velocity/momentum are not yet a conservative 2D fluid solver; shoreline propagation, terrain-coupled floodplain flow and hydraulic structures remain future work.
- Regional migration is aggregate ecology; it does not yet persist individual animals, family groups, age structures or migration corridors.
- Central backend integration depends on the configured service and its existing world-entity endpoints. No live backend was available in this source-only pass, so remote read/write success was not tested.
- No PostgreSQL schema or database migration was created in this pass.

## Validation
- Source-level inspection and delimiter checks only.
- Godot 4.7 executable was not available in the environment; engine parser, import, scene boot, physics, multiplayer and backend integration tests have not been run.
