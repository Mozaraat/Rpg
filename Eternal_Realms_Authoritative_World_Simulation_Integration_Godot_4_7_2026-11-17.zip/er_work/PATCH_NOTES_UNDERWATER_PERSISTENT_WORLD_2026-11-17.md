# Eternal Realms — Underwater Persistent World Integration

Target: Godot 4.7 / Forward+  

## Implemented
- Added save version 11 `underwater_world` payload to the existing JSON save system. Existing save versions continue through the project's existing compatibility path.
- Underwater site snapshots now retain resource claims, permanent treasure claims, boss defeat records, aquatic population counts, juvenile counts, habitat health, simulation timestamps and revisions.
- Procedural site identity is deterministic from world-grid coordinates. Resource and treasure IDs are derived from the site ID and local placement, so reloading or revisiting a site resolves to the same claim key.
- Treasure claims remain permanently unavailable after reload. Harvestable deposits preserve their 90-second regrowth cooldown across reloads.
- Deep-sea boss death is recorded from the marine boss's death/exit lifecycle; defeated bosses are suppressed when the site is regenerated.
- Added bounded offline aquatic population catch-up with habitat carrying capacity, recruitment and juvenile population changes. Catch-up is capped to 24 hourly steps per simulation pass.
- Added an authoritative server persistence bridge using the existing shared `world_entities` endpoint. Client peers do not write shared state.
- Added PostgreSQL migration `backend/postgres/003_underwater_world_persistence.sql` for indexed underwater site snapshots, individual resource claims, boss encounter state and aquatic populations.

## Deployment
1. Apply migrations `001`, `002`, then `003` to the PostgreSQL world database.
2. Deploy the backend endpoint already used by `server_save_world_entity` and `server_load_region_entities`; underwater snapshots use entity kind `underwater_site`.
3. Ensure the dedicated server is configured for production mode and has its normal world lease before accepting writes.
4. Open the project in Godot 4.7, run a resource harvest, treasure claim and boss defeat, save, restart, and verify each state.

## Validation boundary
Static source inspection and resource-path checks can be run here, but the Godot 4.7 executable is not installed in this environment. Engine parsing, live database round-trips, multiplayer race testing, and restart testing remain required. The migration creates dedicated relational tables for normalized backend use; the current client bridge persists complete site snapshots through the existing world-entity endpoint, so backend handlers must map those snapshots into the normalized tables if those tables are to be populated.
