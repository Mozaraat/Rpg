# Combat Input and Targeting Repair — Godot 4.7

## Changes
- Left-click attack now recaptures the mouse and performs the attack on that same gameplay click instead of discarding it. UI-consumed clicks remain handled by UI because gameplay actions still run through `_unhandled_input`.
- Added `K` as an alternate attack binding in the `attack` input action.
- Slightly increased minimum sword/dagger reach to 3.0 metres and widened the melee facing tolerance so small camera/character alignment differences do not cause missed attacks.
- Adjusted melee line-of-sight sampling and tolerates minor ground lips/clutter immediately adjacent to the target, while retaining meaningful world-obstacle blocking.

## Preserved
- Enemy group and `take_damage` combat contract.
- Slime and Monster health/death/reward logic.
- Multiplayer clients still request authoritative combat resolution from the server.
- Weapon classes, stamina/energy costs, cooldowns, combos and animation impact timing.

## Validation
- Source-level checks and archive integrity performed. Godot 4.7 editor parsing and live combat testing require running the project in Godot; not claimed here.
