# Eternal Realms — Living World & Discovery Milestone

## Baseline

Built on `EternalRealms_Cultivation_Magic_Stealth_Dungeon_Milestone.zip`. Existing combat, elemental casting, cultivation realms/meridians, stealth, minimap/world map, settlement systems, and 100-floor dungeon structure are retained.

## Implemented in this milestone

### Living monster behaviour
- Added investigation behaviour: creatures can hear loud movement, remember the player's last known position, search after losing sight, and return to idle if the trail goes cold or the player leaves their territory.
- Packmates investigate an alerted creature's last known position before switching to a direct chase.
- Wolves, hounds, bandits and stalker archetypes use lateral flanking approaches.
- Certain non-boss enemies may break off and retreat when badly wounded.
- Investigation and retreat movement uses the creature locomotion pose, rather than remaining visually idle.

### Elemental resistances and bestiary discoveries
- Added species-specific fire, water, wind, earth, lightning and ice resistance/weakness values for a range of creatures.
- Resistance affects direct elemental damage, status strength, splash damage, fire/earth area effects and lightning chains.
- Meaningful resistance/weakness reactions are recorded once per creature/element in persistent player stats.
- Discoveries train Monster Lore and Observation and are displayed in the Field Journal.

### Cultivation masters and teachers
- Added Master Ren, a sword cultivation mentor, and Vein Reader Yun, a spiritual cultivation mentor, to the Arcane Spire courtyard with daily routines and dialogue.
- Connected their guidance to the existing Sword Intent and Spirit Sense cultivation paths.
- Existing teachers continue to teach weapon- and magic-specific forms when the character meets the practical requirements.

### Rare techniques as discovered knowledge
- Added persistent sealed technique records for Eclipse Counter, Starfall Burst, Dragon Piercer and Void Step.
- A player can recover an ancient technique record before meeting its mastery requirements. The record remains sealed until the required weapon, stealth or magic skills are actually practised.
- When the requirements are met, the technique is automatically understood and removed from the sealed list.
- Sealed records are saved inside cultivation state, compatible with older saves through default-state merging, and visible in the HUD and Field Journal.

### Spiritual landmarks and 100-floor discoveries
- Added interactive elemental spirit veins to every fifth dungeon floor (5, 10, 15 … 100), with a distinct landmark ID, element, lore text, visual structure and cultivation reward.
- Each spirit vein can preserve its floor band's rare technique as sealed knowledge.
- Dungeon shrines now provide band-specific elemental training and technique records.
- Each tenth-floor civilization memory trial preserves a rare form clue and writes a persistent civilization archive record.
- Existing per-floor caches, memory tablets, secrets, hazards and elites remain in the exploration generation flow.

### Field Journal
- Added a Bestiary section showing elemental reactions discovered for each creature.
- Added a 100-floor civilization archive section.
- Added landmark discovery totals and sealed technique names with their practical requirements.

## Persistence and compatibility

- New bestiary, landmark and civilization archive information uses the existing `PlayerData.stats` dictionary.
- Sealed techniques are stored in `SkillSystem.cultivation_state`, which already participates in the skill save payload.
- The save version was not bumped; older cultivation payloads merge with the new default `sealed_techniques` dictionary.

## Validation

- 102 GDScript files and 12 scenes inspected.
- 985 top-level function declarations scanned; no duplicate top-level function names found.
- 65 global `class_name` declarations scanned; no duplicates found.
- 98 literal `res://` references checked; no missing referenced resources found.
- Delimiter scan: 0 findings.
- Match-block layout scan: 76 match statements checked, 0 indentation findings.
- Modified-script leading-whitespace check: 0 findings.
- ZIP archive integrity checked after packaging.

## Runtime test limitation

This project targets Godot 4.6. A Godot executable is not installed in this environment, so engine parsing, project launch, animation, physics, save/load playtesting and actual combat balancing could not be run here. The checks above are static project checks, not a substitute for a Godot 4.6 runtime test.
