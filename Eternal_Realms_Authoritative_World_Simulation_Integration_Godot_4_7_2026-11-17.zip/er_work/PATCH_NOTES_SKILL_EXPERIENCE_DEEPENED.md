# Skill Experience Deepening

- Weapon techniques are discovered the first time the player earns and successfully performs them through a connected attack chain. Discovery is saved with the skill data and survives loading.
- Combat techniques remain contextual to the weapon actually equipped; no class lock or dedicated skill activation button is used.
- Added a deliberate dodge action on Left Ctrl. A dodge only trains Evasion when an incoming attack is actually avoided during its short timing window; taking a hit no longer grants Evasion experience.
- Dodge uses movement direction (or a short backward step when stationary), a brief invulnerability window and a cooldown, so positioning and timing matter.
- The skill menu now describes techniques as discovered and naturally performed rather than button-unlocked abilities.
- Existing saves remain compatible: old skill dictionaries load normally, while newly discovered techniques are stored in an additional reserved save key.

## Controls
- Left Ctrl: dodge / evade.
- Normal attack: build a successful hit chain; trained techniques flow automatically when their mastery and cooldown requirements are met.
