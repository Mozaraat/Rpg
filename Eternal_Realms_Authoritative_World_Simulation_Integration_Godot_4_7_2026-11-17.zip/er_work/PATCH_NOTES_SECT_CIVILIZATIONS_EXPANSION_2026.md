# Eternal Realms — Sect Civilizations Expansion (2026)

## Implemented in this build

### Physical sect campuses
- Added six distinct, explorable sect compounds to the streamed world approach around the Arcane Spire highlands.
- Each compound has a ceremonial hall, side buildings, courtyard furniture, a sect-coloured standard, a spirit altar/crystal, lanterns and a training yard with practice targets.
- Structures use the existing BuildingKit procedural architecture and terrain-height placement helper to reduce floating/sinking regressions.

### Living sect populations
- Every campus is populated by its named master and two disciples.
- Masters follow a daily route between the audience area, spirit altar and a nearby excursion point; disciples rotate between the training yard and courtyard.
- Sect masters and disciples have dedicated visual treatments and sect-aware dialogue choices.

### Recruitment and advancement
- Added a persistent four-stage recruitment examination: spirit-root assessment, endurance, combat discipline and formation trial.
- Passing all stages enrols the player as an Outer Disciple and establishes initial sect standing.
- Added rank advancement through Outer, Inner, Core, True Disciple, Elder and Sect Master, gated by sect standing and cultivation realm.
- Master lessons remain gated by cultivation realm and trusted standing.

### Faction simulation foundations
- Added persistent alliance formation, peace negotiation, war declaration, territory ownership, master encounter records and a compact sect-world report API.
- Existing rival tension simulation remains active and shares the same persistent sect state.

### Inheritance progression
- Exploration clue discovery now starts a three-stage inheritance trial rather than immediately granting the technique.
- The final stage grants the inherited technique through the existing discovery pipeline, subject to the original minimum-realm requirement.

## Integration and compatibility
- Uses the existing `SectSimulation` autoload, `PlayerData.stats` persistence, `NPC` interaction system, `SkillSystem`, `BuildingKit`, `TerrainNoise` and `SettlementBuilder`.
- Existing save data is retained; new sect-state keys are read with safe defaults.
- No new third-party dependencies or project configuration changes were introduced.

## Validation
- Checked all local `res://` references across scripts/scenes; the only unresolved reference is the pre-existing dynamic item icon template `assets/items/%s.svg` in `ui/ui_kit.gd`.
- The project was not runtime-launched in this environment because a Godot executable is not installed. A Godot 4 editor/runtime validation pass is still recommended before release.
