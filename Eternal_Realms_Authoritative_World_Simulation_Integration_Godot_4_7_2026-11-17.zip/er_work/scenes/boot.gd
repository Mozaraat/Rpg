extends Control

const MAIN_SCENE := "res://scenes/main.tscn"
const SAVE_PATH := "user://eternal_realms_save.json"

var _title: Label
var _subtitle: Label
var _status: Label
var _progress: ProgressBar
var _continue: Button
var _new_game: Button
var _online_account: Button
var _loading := false
var _load_save := false
var _tips := [
	"Press P to appraise creatures and resources. Press T to open realm chat.",
	"A good hunter studies tracks before drawing a weapon.",
	"Settlements remember your help. Their markets and people change with time.",
	"Feed and train companions to strengthen their bond before breeding them.",
	"Dungeon civilizations each preserve their own history, hazards and relics.",
	"Merchants restock as caravans arrive. A troubled road can empty a market."
]

func _ready() -> void:
	_build_screen()

func _build_screen() -> void:
	var backdrop := ColorRect.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/boot_backdrop.gdshader")
	backdrop.material = mat
	add_child(backdrop)

	# Soft scrim behind the menu column keeps text legible over the sky.
	var scrim := ColorRect.new()
	scrim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scrim.color = Color(0.008, 0.012, 0.028, 0.30)
	scrim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(scrim)

	var center := VBoxContainer.new()
	center.anchor_left = 0.12; center.anchor_right = 0.88
	center.anchor_top = 0.10; center.anchor_bottom = 0.90
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_theme_constant_override("separation", 14)
	center.modulate = Color(1, 1, 1, 0)
	add_child(center)

	var eyebrow := _label("A LIVING WORLD • A HUNDRED DEPTHS", 13, Color(0.80, 0.68, 0.45))
	_track(eyebrow, 3)
	center.add_child(eyebrow)

	_title = _label("ETERNAL REALMS", 52, Color(0.95, 0.92, 0.84))
	_track(_title, 7)
	_title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.55))
	_title.add_theme_constant_override("shadow_offset_x", 0)
	_title.add_theme_constant_override("shadow_offset_y", 2)
	_title.add_theme_constant_override("shadow_outline_size", 6)
	center.add_child(_title)

	_subtitle = _label("A W A K E N E D", 14, Color(0.74, 0.65, 0.48))
	center.add_child(_subtitle)

	var rule := ColorRect.new()
	rule.color = Color(0.80, 0.67, 0.42, 0.55)
	rule.custom_minimum_size = Vector2(132, 1)
	rule.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	center.add_child(rule)

	var spacer := Control.new(); spacer.custom_minimum_size.y = 22; center.add_child(spacer)

	_continue = _menu_button("CONTINUE JOURNEY", true)
	_continue.pressed.connect(_begin.bind(true))
	center.add_child(_continue)
	_online_account = _menu_button("ONLINE ACCOUNT / CHARACTER SELECT", false)
	_online_account.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/account_portal.tscn"))
	center.add_child(_online_account)
	_new_game = _menu_button("BEGIN NEW ADVENTURE", false)
	_new_game.pressed.connect(_begin.bind(false))
	center.add_child(_new_game)
	if not FileAccess.file_exists(SAVE_PATH):
		_continue.disabled = true
		_continue.text = "NO SAVE FOUND"

	var footer := _label("EXPLORE • BUILD • BOND • DISCOVER", 11, Color(0.60, 0.64, 0.70))
	_track(footer, 2)
	footer.size_flags_vertical = Control.SIZE_SHRINK_END
	center.add_child(footer)

	_status = _label("", 14, Color(0.88, 0.84, 0.72))
	_status.visible = false
	center.add_child(_status)
	_progress = ProgressBar.new()
	_progress.custom_minimum_size = Vector2(340, 8)
	_progress.max_value = 100
	_progress.visible = false
	center.add_child(_progress)

	var build := _label("REALM BUILD 1.0   •   GODOT 4.7", 10, Color(0.42, 0.45, 0.52))
	build.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	build.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	build.offset_left = -286
	build.offset_top = -34
	build.offset_right = -28
	build.offset_bottom = -14
	add_child(build)

	var fade := create_tween()
	fade.tween_property(center, "modulate:a", 1.0, 0.7).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l

func _track(label: Label, amount: int) -> void:
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.spacing_glyph = amount
	label.add_theme_font_override("font", fv)

func _menu_button(text: String, primary: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(340, 50)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_font_size_override("font_size", 15)
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.spacing_glyph = 2
	b.add_theme_font_override("font", fv)
	b.add_theme_color_override("font_color", Color(0.91, 0.89, 0.83))
	b.add_theme_color_override("font_hover_color", Color(1.0, 0.93, 0.74))
	b.add_theme_color_override("font_pressed_color", Color(0.98, 0.90, 0.70))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.94, 0.78))
	b.add_theme_color_override("font_disabled_color", Color(0.46, 0.46, 0.50))
	var base := Color(0.16, 0.125, 0.075, 0.92) if primary else Color(0.045, 0.058, 0.086, 0.82)
	var edge := Color(0.86, 0.72, 0.45, 0.72) if primary else Color(0.58, 0.52, 0.37, 0.38)
	b.add_theme_stylebox_override("normal", _box(base, edge, 1))
	b.add_theme_stylebox_override("hover", _box(base.lightened(0.16), Color(0.93, 0.80, 0.53, 0.95), 1))
	b.add_theme_stylebox_override("pressed", _box(base.darkened(0.12), Color(1.0, 0.86, 0.58, 1.0), 1))
	b.add_theme_stylebox_override("focus", _box(Color(0, 0, 0, 0), Color(0.95, 0.82, 0.55, 0.85), 1))
	b.add_theme_stylebox_override("disabled", _box(Color(0.035, 0.042, 0.058, 0.72), Color(0.34, 0.34, 0.38, 0.30), 1))
	return b

func _box(fill: Color, border: Color, width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.border_color = border
	s.set_border_width_all(width)
	s.set_corner_radius_all(3)
	s.content_margin_left = 22
	s.content_margin_right = 22
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s

func _begin(load_existing: bool) -> void:
	if _loading: return
	_loading = true
	_load_save = load_existing
	_continue.visible = false; _new_game.visible = false; _online_account.visible = false
	_status.visible = true; _progress.visible = true
	_status.text = "Preparing the world...\n" + str(_tips[randi() % _tips.size()])
	var err := ResourceLoader.load_threaded_request(MAIN_SCENE, "PackedScene")
	if err != OK:
		_restore_menu_after_load_error("Unable to prepare the world. Please try again.")

func _process(_delta: float) -> void:
	if not _loading: return
	var progress: Array = []
	var status := ResourceLoader.load_threaded_get_status(MAIN_SCENE, progress)
	if not progress.is_empty(): _progress.value = float(progress[0]) * 100.0
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		_progress.value = 100
		_status.text = "Entering Eternal Realms..."
		var packed := ResourceLoader.load_threaded_get(MAIN_SCENE) as PackedScene
		if packed != null:
			# Do not reset a new character until the destination scene is ready.
			# This keeps a failed threaded load from discarding the current session data.
			if not _load_save:
				PlayerData.reset_new_game()
			GameManager.pending_load_game = _load_save
			GameManager.pending_new_game_save = not _load_save
			var change_error := get_tree().change_scene_to_packed(packed)
			if change_error != OK:
				GameManager.pending_load_game = false
				GameManager.pending_new_game_save = false
				_restore_menu_after_load_error("The world could not be opened. Please try again.")
		else:
			_restore_menu_after_load_error("The world could not be loaded. Please try again.")
	elif status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		_restore_menu_after_load_error("World loading failed. Please try again.")

func _restore_menu_after_load_error(message: String) -> void:
	_loading = false
	_status.text = message
	_status.visible = true
	_progress.visible = false
	_continue.visible = true
	_new_game.visible = true
	_online_account.visible = true
	_continue.disabled = not FileAccess.file_exists(SAVE_PATH)
	if not _continue.disabled:
		_continue.text = "CONTINUE JOURNEY"

