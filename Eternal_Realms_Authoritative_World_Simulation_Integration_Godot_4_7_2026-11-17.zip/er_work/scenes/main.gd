# Main scene glue: puts the player on the ground at the village entrance.
extends Node3D

func _ready() -> void:
	MMORPGNetwork.set_world_root(self)
	var noise := TerrainNoise.new(GameManager.world_seed)
	var player: Node3D = get_node_or_null("Player")
	if MMORPGNetwork.dedicated_mode and is_instance_valid(player):
		player.queue_free()
		GameManager.player = null
		player = null
	if player:
		var sp: Vector2 = Constants.SPAWN_XZ
		player.global_position = Vector3(sp.x, noise.get_height(sp.x, sp.y) + 0.3, sp.y)
	if GameManager.pending_load_game:
		GameManager.pending_load_game = false
		SaveSystem.load_game()
	elif GameManager.pending_new_game_save:
		GameManager.pending_new_game_save = false
		SaveSystem.save_game()
