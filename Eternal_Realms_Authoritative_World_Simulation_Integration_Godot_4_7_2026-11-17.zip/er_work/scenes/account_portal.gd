extends Control

const MAIN_SCENE := "res://scenes/main.tscn"
var access_token := ""
var refresh_token := ""
var account_id := ""
var selected_character_id := ""
var email_input: LineEdit
var password_input: LineEdit
var name_input: LineEdit
var host_input: LineEdit
var status_label: Label
var character_list: VBoxContainer
var auth_box: VBoxContainer
var character_box: VBoxContainer

func _ready() -> void:
	_build_ui()
	if not CentralBackend.base_url.begins_with("https://"):
		_set_status("Configure ER_BACKEND_URL with your HTTPS backend address before using online accounts.")

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/boot_backdrop.gdshader")
	bg.material = mat
	add_child(bg)
	var shade := ColorRect.new()
	shade.color = Color(0.005, 0.008, 0.020, 0.66)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

	var root := CenterContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_box())
	root.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_right", 40)
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 28)
	panel.add_child(margin)

	var center := VBoxContainer.new()
	center.custom_minimum_size.x = 560
	center.add_theme_constant_override("separation", 10)
	margin.add_child(center)
	center.modulate = Color(1, 1, 1, 0)

	var eyebrow := Label.new()
	eyebrow.text = "SHARED WORLD  •  PERSISTENT CHARACTERS"
	eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	eyebrow.add_theme_font_size_override("font_size", 11)
	eyebrow.add_theme_color_override("font_color", Color(0.78, 0.66, 0.43))
	_track(eyebrow, 3)
	center.add_child(eyebrow)

	var title := Label.new()
	title.text = "ONE WORLD ACCOUNT"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 32)
	title.add_theme_color_override("font_color", Color(0.94, 0.91, 0.83))
	_track(title, 3)
	center.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "One account. One character identity. One shared Elyndor."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", Color(0.66, 0.70, 0.76))
	center.add_child(subtitle)

	var rule := ColorRect.new()
	rule.color = Color(0.80, 0.67, 0.42, 0.50)
	rule.custom_minimum_size = Vector2(120, 1)
	rule.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	center.add_child(rule)

	var gap := Control.new(); gap.custom_minimum_size.y = 8; center.add_child(gap)

	auth_box = VBoxContainer.new()
	auth_box.add_theme_constant_override("separation", 9)
	center.add_child(auth_box)
	email_input = LineEdit.new(); email_input.placeholder_text = "Email address"; email_input.custom_minimum_size.y = 42
	_style_field(email_input)
	auth_box.add_child(email_input)
	password_input = LineEdit.new(); password_input.placeholder_text = "Password (12+ characters)"; password_input.secret = true; password_input.custom_minimum_size.y = 42
	_style_field(password_input)
	auth_box.add_child(password_input)
	var auth_row := HBoxContainer.new()
	auth_row.add_theme_constant_override("separation", 10)
	var login_btn := _menu_button("SIGN IN", true); login_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL; login_btn.pressed.connect(_login)
	var register_btn := _menu_button("CREATE ACCOUNT", false); register_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL; register_btn.pressed.connect(_register)
	auth_row.add_child(login_btn); auth_row.add_child(register_btn); auth_box.add_child(auth_row)

	character_box = VBoxContainer.new(); character_box.visible = false; character_box.add_theme_constant_override("separation", 9)
	center.add_child(character_box)
	var char_title := Label.new(); char_title.text = "YOUR CHARACTERS IN ELYNDOR"; char_title.add_theme_font_size_override("font_size", 13); char_title.add_theme_color_override("font_color", Color(0.80, 0.73, 0.58)); character_box.add_child(char_title)
	character_list = VBoxContainer.new(); character_list.add_theme_constant_override("separation", 6); character_box.add_child(character_list)
	name_input = LineEdit.new(); name_input.placeholder_text = "New character name (3–24 characters)"; _style_field(name_input); character_box.add_child(name_input)
	var create_btn := _menu_button("CREATE CHARACTER", true); create_btn.pressed.connect(_create_character); character_box.add_child(create_btn)
	host_input = LineEdit.new(); host_input.placeholder_text = "World server address (e.g. play.example.com)"; host_input.text = OS.get_environment("ER_WORLD_HOST"); _style_field(host_input); character_box.add_child(host_input)
	var back_btn := _menu_button("SIGN OUT", false); back_btn.pressed.connect(_sign_out); character_box.add_child(back_btn)

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.custom_minimum_size.y = 44
	status_label.add_theme_font_size_override("font_size", 13)
	status_label.add_theme_color_override("font_color", Color(0.82, 0.76, 0.62))
	center.add_child(status_label)

	var local_btn := _menu_button("RETURN TO OFFLINE MENU", false)
	local_btn.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/boot.tscn"))
	center.add_child(local_btn)

	var fade := create_tween()
	fade.tween_property(center, "modulate:a", 1.0, 0.55).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func _panel_box() -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.020, 0.028, 0.044, 0.88)
	s.border_color = Color(0.62, 0.52, 0.33, 0.55)
	s.set_border_width_all(1)
	s.set_corner_radius_all(4)
	s.shadow_color = Color(0, 0, 0, 0.45)
	s.shadow_size = 18
	return s

func _track(label: Label, amount: int) -> void:
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.spacing_glyph = amount
	label.add_theme_font_override("font", fv)

func _style_field(field: LineEdit) -> void:
	field.add_theme_font_size_override("font_size", 14)
	field.add_theme_color_override("font_color", Color(0.92, 0.90, 0.84))
	field.add_theme_color_override("font_placeholder_color", Color(0.50, 0.52, 0.58))
	field.add_theme_color_override("caret_color", Color(0.95, 0.82, 0.55))
	field.add_theme_stylebox_override("normal", _box(Color(0.035, 0.045, 0.062, 0.92), Color(0.40, 0.38, 0.30, 0.45), 1))
	field.add_theme_stylebox_override("focus", _box(Color(0.045, 0.056, 0.076, 0.96), Color(0.88, 0.73, 0.45, 0.85), 1))

func _menu_button(text: String, primary: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 42)
	b.add_theme_font_size_override("font_size", 14)
	b.add_theme_color_override("font_color", Color(0.91, 0.89, 0.83))
	b.add_theme_color_override("font_hover_color", Color(1.0, 0.93, 0.74))
	b.add_theme_color_override("font_pressed_color", Color(0.98, 0.90, 0.70))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.94, 0.78))
	b.add_theme_color_override("font_disabled_color", Color(0.46, 0.46, 0.50))
	var base := Color(0.16, 0.125, 0.075, 0.92) if primary else Color(0.045, 0.058, 0.086, 0.82)
	var edge := Color(0.86, 0.72, 0.45, 0.72) if primary else Color(0.58, 0.52, 0.37, 0.38)
	b.add_theme_stylebox_override("normal", _box(base, edge, 1))
	b.add_theme_stylebox_override("hover", _box(base.lightened(0.16), Color(0.93, 0.80, 0.53, 0.95), 1))
	b.add_theme_stylebox_override("pressed", _box(base.darkened(0.12), Color(1.0, 0.86, 0.58, 1.0), 1))
	b.add_theme_stylebox_override("focus", _box(Color(0, 0, 0, 0), Color(0.95, 0.82, 0.55, 0.85), 1))
	return b

func _box(fill: Color, border: Color, width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.border_color = border
	s.set_border_width_all(width)
	s.set_corner_radius_all(3)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func _set_status(message: String) -> void:
	if is_instance_valid(status_label): status_label.text = message

func _login() -> void:
	await _authenticate(false)

func _register() -> void:
	await _authenticate(true)

func _authenticate(create: bool) -> void:
	if not CentralBackend.base_url.begins_with("https://"):
		_set_status("Online account service requires an HTTPS backend URL.")
		return
	var result: Dictionary
	if create:
		result = await CentralBackend.register_account(email_input.text.strip_edges(), password_input.text)
	else:
		result = await CentralBackend.login(email_input.text.strip_edges(), password_input.text)
	if not result.get("ok", false):
		_set_status(str(result.get("error", result.get("body", {}).get("detail", "Account request failed."))))
		return
	var body: Dictionary = result.get("body", {})
	access_token = str(body.get("access_token", "")); refresh_token = str(body.get("refresh_token", "")); account_id = str(body.get("account_id", ""))
	if access_token.is_empty():
		_set_status("The account service did not return a session.")
		return
	auth_box.visible = false; character_box.visible = true
	await _refresh_characters()

func _refresh_characters() -> void:
	for child in character_list.get_children(): child.queue_free()
	var result: Dictionary = await CentralBackend.list_characters(access_token)
	if not result.get("ok", false):
		_set_status("Unable to retrieve your characters.")
		return
	var rows: Array = result.get("body", {}).get("characters", [])
	if rows.is_empty(): _set_status("No characters yet. Create your first character below.")
	for row_variant in rows:
		var row: Dictionary = row_variant
		var btn := Button.new()
		btn.text = "%s  |  Level %s" % [str(row.get("display_name", "Wanderer")), str(row.get("level", 1))]
		btn.custom_minimum_size.y = 42
		btn.pressed.connect(_select_character.bind(str(row.get("character_id", ""))))
		character_list.add_child(btn)

func _create_character() -> void:
	var result: Dictionary = await CentralBackend.create_character(access_token, name_input.text.strip_edges())
	if not result.get("ok", false):
		_set_status(str(result.get("body", {}).get("detail", "Character creation failed.")))
		return
	name_input.clear()
	_set_status("Character created in the shared Elyndor world.")
	await _refresh_characters()

func _select_character(character_id: String) -> void:
	if host_input.text.strip_edges().is_empty():
		_set_status("Enter the address of the authoritative Elyndor world server.")
		return
	_set_status("Preparing secure character entry…")
	var prepared: Dictionary = await CentralBackend.prepare_character_connection(access_token, character_id)
	if not prepared.get("ok", false):
		_set_status(str(prepared.get("error", "Unable to prepare character connection.")))
		return
	var result: Error = MMORPGNetwork.join_server(host_input.text.strip_edges(), MMORPGNetwork.DEFAULT_PORT)
	if result != OK:
		_set_status("Could not start the world connection: %s" % error_string(result))
		return
	selected_character_id = character_id
	get_tree().change_scene_to_file(MAIN_SCENE)

func _sign_out() -> void:
	if not access_token.is_empty(): await CentralBackend.logout(access_token)
	access_token = ""; refresh_token = ""; account_id = ""; selected_character_id = ""
	character_box.visible = false; auth_box.visible = true
	_set_status("Signed out.")
