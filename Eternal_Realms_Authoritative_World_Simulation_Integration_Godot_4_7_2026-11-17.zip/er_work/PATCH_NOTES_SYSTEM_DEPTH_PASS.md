# Eternal Realms — System Depth Pass

## Regional guild commissions
- Added `GuildContracts` as a persistent autoload alongside the existing player guild and party systems.
- Four daily rotating commissions per region, deterministic by calendar day to prevent board refresh rerolling.
- Six contract families: hunting, gathering, crafting, exploration, fishing and dungeon delving.
- Accept/abandon/progress/complete states, tier-scaled objectives and rewards, persistent regional reputation, reputation ranks, and guild renown rewards for members.
- Added a regional commission board to the existing Guild / Party menu. Contracts are independent of guild membership.
- Added compatibility activity-event tracking and direct `record_progress(kind, amount, region_id)` API for precise integrations.

## Cultivation technique depth
- Added 18 additional long-term cultivation techniques across elemental paths, shadow cultivation, spirit perception and nature harmony.
- Higher forms require increased skill practice, path insight and later cultivation realms. Existing slow practice/unlock flow remains in place.

## Stealth and enemy perception
- Expanded enemy hearing beyond visual aggro range. Sprinting is louder and can draw investigation through corners; ordinary fast movement has a smaller sound radius; crouched stealth sharply reduces the audible radius.
- Hearing and visual detection remain separate: sound yields a last-known approximate position, not automatic visual target lock.

## Validation and limitations
- Static source checks, duplicate declaration scan, literal resource path scan and archive integrity checks performed.
- Godot 4.6 runtime/editor validation was not available in the build environment. UI layout, signal execution, combat perception and save/load still require in-engine testing.
