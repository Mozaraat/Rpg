# Eternal Realms — Biome Fauna Catalog

The regional ecology catalog assigns fauna to the same 17 biome IDs used by `TerrainNoise`. Species exist as persistent regional cohorts when their terrain is unloaded; only a capped subset becomes visible around players.

| Biome | Representative species |
|---|---|
| Ocean | Coastal seal, reef shark, trout |
| Beach | Shorebird, coastal seal |
| Plains | Rabbit, red deer, wild boar, red fox, shorebird |
| Forest | Rabbit, red deer, wild boar, red fox, grey wolf, brown bear, lynx, river otter |
| Hills | Red deer, wild boar, red fox, grey wolf, mountain goat, elk |
| Mountain | Mountain goat, snow leopard, grey wolf, brown bear |
| Snow / alpine | Arctic hare, snow fox, snow leopard, tundra muskox, mountain goat |
| Swamp | Marsh deer, marsh crocodile, marsh heron, river otter, wild boar, trout |
| Desert | Desert gazelle, sand cat, hyena, vulture |
| Autumn woodland | Red deer, rabbit, red fox, wild boar, brown bear |
| Volcanic | Ash goat, ember lizard, vulture |
| Rainforest | Tapir, jaguar, monkey, marsh heron, river otter, trout |
| Jungle | Tapir, jaguar, monkey, marsh crocodile, marsh heron, trout |
| Taiga | Elk, lynx, brown bear, grey wolf, snow fox, river otter |
| Tundra | Arctic hare, snow fox, tundra muskox, snow leopard |
| Savanna | Desert gazelle, hyena, savanna elephant, savanna lion, vulture |
| Mediterranean | Rabbit, red deer, red fox, wild boar, shorebird, trout |

## Ecological rules

- Births depend on adult population, breeding season, temperature, moisture and carrying capacity.
- Juveniles mature into adults; regional cohorts age, become stronger and eventually suffer age-related mortality.
- Predator populations consume compatible prey populations in the same region.
- Seasonal dispersal moves animals toward suitable neighbouring regions with available capacity.
- Hunting carcasses add pressure to the matching regional species cohort. Harvest pressure reduces adult counts on later worker ticks.
- High regional population pressure raises the local wildlife encounter cap. This creates visible ecological pressure while keeping loaded animal instances capped for performance.
- Aquatic cohorts continue in the regional model; capped `MarineFish` schools are spawned only in loaded water near players.

## Terrain logic

The current terrain field already creates long ridged uplifts and mountain massifs, with lower foothills and hills below the alpine zone. The biome classifier distinguishes hills, mountain terrain and high cold snow/ice peaks using elevation and temperature. Existing graded passes and trails are retained so the ranges can be crossed and explored.
