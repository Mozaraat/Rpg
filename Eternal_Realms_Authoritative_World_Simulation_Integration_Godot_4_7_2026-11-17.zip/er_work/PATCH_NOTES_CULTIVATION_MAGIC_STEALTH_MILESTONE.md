# Eternal Realms — Cultivation, Magic, Stealth & Dungeon Milestone

## Included systems

### Elemental spellcasting
- Six selectable affinities: Fire, Water, Wind, Earth, Lightning and Ice.
- Each element has its own projectile silhouette, colour, speed, impact behavior and enemy status effect.
- Fire adds burn damage and tiered splash damage; Water slows enemies and restores the caster on impact; Wind pushes targets and creates tiered area control; Earth creates stagger and impact damage; Lightning chains between nearby enemies; Ice slows and can freeze/stagger at higher mastery.
- Affinity skill progression changes the named spell form at Foundation, Adept and Master thresholds.
- Spiritual roots, cultivation realm, affinity mastery and learned techniques influence spell power and energy cost.

### Persistent minimap and world map
- The HUD includes a persistent local radar with player heading, distance rings, nearby enemies, NPCs and shrine/ruin points of interest.
- Spirit-Vein Sight expands the radar range from 48m to 72m.
- The existing world atlas remains available with zoom (1x–3.5x), mouse-drag panning and player/location markers.

### Cultivation progression
- Six cultivation realms, meridian opening requirements, spiritual-root awakening, persistent technique learning and multiple independent cultivation paths.
- Added active techniques: Unbroken Blade Intent, Living Root Communion and Flowing-Breath Swimming Art, alongside the elemental, shadow, body and spirit techniques.
- Technique effects are connected to actual gameplay: melee damage, gathering duration, swimming speed, spell efficiency/power, stealth detection and minimap range.
- Breakthroughs require sufficient cultivation, opened meridians and a high spirit reserve; attempts can fail without resetting the current realm.

### Stealth and enemy awareness
- V toggles a crouched stealth stance with a lower body pose, slower movement and reduced enemy detection.
- Running, attacking, casting or taking a hit breaks concealment.
- Enemies use visual contact, facing, line-of-sight, distance and player noise to build awareness before pursuing; they can lose the player again after breaking contact.
- A dagger strike from behind while concealed performs a dedicated quick thrust and a high-damage backstab.

### Dungeon identity and lore
- Dungeon floors receive additional civilization-specific remnants and architectural props.
- Optional memory tablets provide a readable floor/civilization record and reward Ancient Lore, Archaeology, Knowledge, Spiritual Sense and Cultivation practice.
- Memory discoveries are recorded per floor and persisted through the existing dungeon discovery state.

## Controls
- `Z`: cast the currently selected elemental form.
- `X`: cycle Fire / Water / Wind / Earth / Lightning / Ice.
- `C` (hold while still): cultivate and replenish spiritual energy.
- `O`: attempt a cultivation breakthrough while still and sufficiently prepared.
- `Y`: cycle through cultivation paths whose practical progress is sufficient.
- `V`: toggle crouched stealth.
- `M`: open/close the zoomable world map.
- `N`: dungeon map (existing control).
- `F5` / `F9`: save / load.

## Save compatibility
- Save version is now 10.
- Cultivation state is stored with the skill data. Older saves are still attempted, and missing cultivation fields are filled from defaults during loading.

## Validation performed
- Audited 101 GDScript files and 12 scene files.
- Checked literal `res://` references in scripts, scenes, resources and `project.godot`: no missing paths found.
- Checked duplicate top-level script functions and duplicate `class_name` declarations: none found.
- Checked balanced delimiters in all GDScript files: no bracket/parenthesis issues found.
- Checked `match` arm indentation across the GDScript files: no issues found.
- Checked the modified scripts for consistent leading-tab indentation.
- Checked the output archive with `unzip -t` after packaging.

## Runtime testing limitation

This environment does not have a Godot 4.6 executable installed, and the engine could not be installed from the available offline environment. As a result, the project has **not** been launched in Godot and no engine-level parse, physics, animation, save/load or playtest result is claimed. Run the project in Godot 4.6 and address any engine-reported issues before treating this milestone as runtime-verified.
