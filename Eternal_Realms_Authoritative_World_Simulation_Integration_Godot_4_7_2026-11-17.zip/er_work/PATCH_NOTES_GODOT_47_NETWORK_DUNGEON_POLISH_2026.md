# Eternal Realms — Godot 4.7 One-World Hardening Pass

## Engine target
- Project feature declaration targets Godot 4.7 / Forward Plus. The current stable 4.7 maintenance target is 4.7.2.

## Multiplayer state and snapshots
- Server-owned peer health and spiritual-energy values remain the source of truth when reconnect snapshots are written.
- The server now also overwrites the saved `cultivation` skill value from its own cultivation record, preventing the client snapshot from inflating that one numeric discipline.
- The server restores the same authoritative cultivation value during character registration.
- Remote-client healing consumables now request a bounded restore from the server using the item definition; remote regeneration respects the six-second post-damage delay and heals are rate-limited on both client and server.
- The character's broader cultivation realm/path/technique state is still included in the snapshot and has not yet been migrated to a server-owned progression ledger. Realm breakthroughs must not be described as cheat-proof.
- The online roster count now reports zero while a client is waiting for the server's authoritative roster, rather than briefly inventing a local player count.
- Host, join, disconnect, rejected identity and connection-loss feedback use EventBus toast notifications. Network panel stays hidden by default; F2 is named in the HUD hint.

## Interaction and gathering validation
- Remote quest turn-in, standard NPC shop opening and faction-quartermaster interactions now request server approval against the registered peer position, target type, range and permitted target identity.
- Regional gathering sends the actual ResourceNode path. The server resolves the node itself, checks that it is not depleted, validates the resource category and region from the server-side node, enforces a five-metre interaction radius, applies a per-peer request throttle and caps reserve depletion.
- These checks validate interaction intent and regional ecology, not the full economic transaction. Inventory, gold, most skills and quest progress remain client-led snapshots; authoritative trading and quest rewards require a future server-owned character economy/quest ledger.

## Dungeon visual consistency and performance
- Retains the ten civilization-band architectural identities, themed structures and existing floor progression.
- Sparse shadowless corridor fill lights, quality-scaled lantern range and cinematic-only shadow settings improve corridor readability without requiring high-end shadow rendering.
- Boss telegraphs use a high-contrast emissive silhouette.
- Chunk regeneration clears prior loaded vegetation chunks to avoid stale culling state between seeds.

## Packaging and validation
- Public ZIP excludes `.godot/`, `__pycache__/` and bytecode caches. Source `.import` metadata is retained.
- Static checks cover resource paths, duplicate class declarations and functions, delimiter balance and archive integrity.
- Godot 4.7.2 executable was not available in the build environment, so engine import/parser, visual, network-latency and in-game interaction tests remain outstanding.
