# Eternal Realms — Living Cavern & Creature Pass

## Dungeon world redesign
- Replaced the visual wall blocks with overlapping irregular rock formations while preserving solid collision barriers.
- Replaced the square checkerboard floor tiles with irregular worn stone plates.
- Replaced the flat ceiling appearance with a domed cavern roof and stalactites.
- Added a procedural triplanar cave-rock shader with mineral variation, strata and roughness breakup.
- Added biome dressing for the ten ten-floor regions: catacomb rubble, fungal growth, crystal/mineral spikes, ruined columns, ember formations, ice stalactites, drowned pools, giant roots, abyssal rock and ancient relic columns.
- Increased route loops, carved a broad central chamber, side chambers and a wider boss approach.
- Kept the existing 100-floor progression, spawn points, collision barriers, boss gates, loot, shrines, caches and save/discovery systems.

## Monster improvements
- Fixed `_add_box()` and `_add_cyl()` so they return their created `MeshInstance3D`, resolving the reported return-value and inferred-null errors. The sphere and capsule helpers now return nodes too.
- Rebuilt wolf proportions with rounded anatomical forms and articulated legs.
- Rebuilt crawler, serpent and rat silhouettes with more natural body forms and segmented parts.
- Added procedural limb swing while moving, idle breathing, wind-up lean and attack follow-through.
- Increased mesh tessellation for smoother creature surfaces.
- Increased boss model scale for stronger silhouettes; existing phase, combat and death systems remain.

## Verification notes
- ZIP structure and archive CRC integrity checked.
- GDScript delimiters checked for the modified scripts.
- Godot 4.6 executable was not available in this environment, so a Godot import/parser run and in-game visual test could not be performed. Please open the project in Godot 4.6 and test Floor 1, Floor 11, Floor 31, Floor 61, Floor 71 and Floor 100, plus wolf/crawler/boss combat.
