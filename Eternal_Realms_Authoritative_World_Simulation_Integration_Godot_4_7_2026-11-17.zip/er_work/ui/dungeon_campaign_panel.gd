extends CanvasLayer
## In-game campaign ledger. Press J to inspect territories, commanders, diplomacy and recent history.
var _panel: PanelContainer
var _detail: RichTextLabel
var _selected_id := ""

func _ready() -> void:
	layer = 8
	_build()
	visible = false

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_J:
		visible = not visible
		if visible:
			_refresh()
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		get_viewport().set_input_as_handled()

func _build() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.02, 0.035, 0.78)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(shade)
	_panel = PanelContainer.new()
	_panel.set_anchors_preset(Control.PRESET_CENTER)
	_panel.offset_left = -470
	_panel.offset_right = 470
	_panel.offset_top = -310
	_panel.offset_bottom = 310
	root.add_child(_panel)
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 14)
	_panel.add_child(columns)
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(330, 0)
	columns.add_child(left)
	var heading := Label.new()
	heading.text = "DUNGEON CAMPAIGN · TEN CIVILIZATIONS"
	heading.add_theme_font_size_override("font_size", 18)
	left.add_child(heading)
	var hint := Label.new()
	hint.text = "Select a faction to inspect its history and negotiate."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	left.add_child(hint)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(320, 470)
	left.add_child(scroll)
	var faction_list := VBoxContainer.new()
	faction_list.name = "FactionList"
	faction_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(faction_list)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(right)
	var detail_title := Label.new()
	detail_title.text = "FACTION RECORD"
	detail_title.add_theme_font_size_override("font_size", 18)
	right.add_child(detail_title)
	_detail = RichTextLabel.new()
	_detail.bbcode_enabled = true
	_detail.fit_content = false
	_detail.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail.custom_minimum_size = Vector2(450, 390)
	right.add_child(_detail)
	var aid := Button.new()
	aid.text = "Send aid · improve relations"
	aid.pressed.connect(_aid_selected)
	right.add_child(aid)
	var truce := Button.new()
	truce.text = "Negotiate temporary ceasefire"
	truce.pressed.connect(_truce_selected)
	right.add_child(truce)
	var close := Button.new()
	close.text = "Close  [J]"
	close.pressed.connect(_close_panel)
	right.add_child(close)

func _refresh() -> void:
	var list := _panel.find_child("FactionList", true, false) as VBoxContainer
	if list == null: return
	for child in list.get_children(): child.queue_free()
	for culture in CivilizationSocieties.CULTURES:
		var id := str(culture.get("id", ""))
		var status: Dictionary = DungeonCampaign.faction_status(id)
		var row := Button.new()
		row.text = "%s  ·  STR %d  ·  MORALE %d" % [str(culture.get("name", id)), int(status.get("strength", 0)), int(status.get("morale", 0))]
		row.alignment = HORIZONTAL_ALIGNMENT_LEFT
		row.pressed.connect(_select_faction.bind(id))
		list.add_child(row)
	if _selected_id == "" and not CivilizationSocieties.CULTURES.is_empty():
		_selected_id = str(CivilizationSocieties.CULTURES[0].get("id", ""))
	_show_detail()

func _select_faction(id: String) -> void:
	_selected_id = id
	_show_detail()

func _show_detail() -> void:
	if _selected_id == "": return
	var status: Dictionary = DungeonCampaign.faction_status(_selected_id)
	var rep := int(PlayerData.stats.get("culture_rep_" + _selected_id, 0))
	var truce_until := int(status.get("player_truce_until", 0))
	var truce_state := "Active until %s" % Time.get_datetime_string_from_unix_time(truce_until) if truce_until > int(Time.get_unix_time_from_system()) else "No active ceasefire"
	var rooms: Dictionary = DungeonCampaign.campaign.get("_meta", {}).get("rooms", {})
	var territory := 0
	for room in rooms.values():
		if str(room.get("owner", "")) == _selected_id: territory += 1
	var history: Array = status.get("history", [])
	var text := "[b]%s[/b]\n" % _selected_id.replace("_", " ").to_upper()
	text += "Strength: %d / 100\nMorale: %d / 100\nVictories: %d\nDefeats: %d\nLeader: %s\nBodyguards: %d\nControlled rooms: %d\nYour reputation: %d\nDiplomacy: %s\n\n[b]RECENT HISTORY[/b]\n" % [int(status.get("strength", 0)), int(status.get("morale", 0)), int(status.get("victories", 0)), int(status.get("defeats", 0)), "Alive" if bool(status.get("leader_alive", true)) else "Successor required", int(status.get("leader_guard", 0)), territory, rep, truce_state]
	for i in range(maxi(0, history.size() - 12), history.size()):
		var entry: Dictionary = history[i]
		text += "• %s\n" % str(entry.get("event", "Campaign event"))
	_detail.text = text

func _aid_selected() -> void:
	if _selected_id == "": return
	DungeonCampaign.player_action(_selected_id, "aid", 8)
	_refresh()
	EventBus.toast.emit("Aid sent. Faction morale and your standing improved.", "levelup")

func _truce_selected() -> void:
	if _selected_id == "": return
	if DungeonCampaign.negotiate_player_truce(_selected_id):
		EventBus.toast.emit("Temporary ceasefire negotiated.", "levelup")
	else:
		EventBus.toast.emit("The faction refuses. Improve reputation to +8 and try again.", "warning")
	_refresh()

func _close_panel() -> void:
	visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
