# Player HUD - health, gold, title, quest tracker, activity feed, prompts, zone banner,
# gather progress, toasts, crosshair, death screen. Built in code so the look lives in one place.
extends CanvasLayer
class_name PlayerHUD

var player: Player = null
var day_night: DayNightCycle = null

var health_bar: ProgressBar
var health_label: Label
var guard_bar: ProgressBar
var guard_label: Label
var spirit_bar: ProgressBar
var spirit_label: Label
var cultivation_status_label: Label
var element_status_label: Label
var age_label: Label
var time_label: Label
var tide_label: Label
var gold_label: Label
var title_label: Label
var prompt_panel: PanelContainer
var prompt_label: Label
var toast_box: VBoxContainer
var crosshair: Control
var hint_label: Label
var death_root: Control
var death_label: Label
var tracker_box: VBoxContainer
var log_box: VBoxContainer
var status_panel: PanelContainer
var zone_label: Label
var gather_panel: PanelContainer
var gather_bar: ProgressBar
var gather_label: Label
var boss_panel: PanelContainer
var boss_bar: ProgressBar
var boss_name: Label
var minimap: MinimapCanvas
var _boss_ui_raid_mode: bool = false

var _hint_time: float = 9.0
var _minimap_refresh_timer: float = 0.0
var _hud_root: Control
var _zone_tween: Tween

func _ready() -> void:
	layer = 5
	_build_ui()
	get_viewport().size_changed.connect(_apply_responsive_layout)
	_apply_responsive_layout()
	var campaign_ui_script: Script = load("res://ui/dungeon_campaign_panel.gd")
	if campaign_ui_script:
		var campaign_ui: CanvasLayer = campaign_ui_script.new()
		campaign_ui.name = "DungeonCampaignPanel"
		add_child(campaign_ui)
	await get_tree().process_frame
	_connect_to_player()
	day_night = get_tree().get_first_node_in_group("day_night")
	EventBus.interaction_available.connect(_on_interaction_available)
	EventBus.interaction_cleared.connect(func() -> void: prompt_panel.visible = false)
	EventBus.toast.connect(_show_toast)
	EventBus.activity.connect(_log_line)
	EventBus.zone_entered.connect(_on_zone_entered)
	EventBus.player_aged.connect(func(a: float, _o: float) -> void: age_label.text = "Age %.0f" % a)
	PlayerData.gold_changed.connect(func(g: int) -> void: gold_label.text = "%d gold" % g)
	PlayerData.quests_changed.connect(_update_tracker)
	PlayerData.title_changed.connect(_update_title)
	gold_label.text = "%d gold" % PlayerData.gold
	_update_tracker()
	_update_title()

func _label(text: String, size: int, color: Color = Color.WHITE) -> Label:
	var result: Label = UIKit.label(text, size, color, true)
	result.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	result.clip_text = true
	return result

func _fit_label(label: Label, wrap: bool = false) -> void:
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size.x = 0.0
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if wrap else TextServer.AUTOWRAP_OFF
	# Autowrap + clipping collapses the label's minimum height to 1 px in a
	# container. Wrapped labels therefore keep their natural height and only
	# single-line labels are allowed to ellipsize.
	if wrap:
		label.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
		label.clip_text = false
	else:
		label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		label.clip_text = true

func _apply_responsive_layout() -> void:
	if _hud_root == null:
		return
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var compact: bool = viewport_size.x < 1100.0
	var left_width: float = clampf(viewport_size.x * 0.25, 248.0, 310.0)
	var right_width: float = clampf(viewport_size.x * 0.245, 220.0, 300.0)
	var map_size: float = clampf(viewport_size.x * 0.115, 112.0, 146.0)
	if status_panel:
		status_panel.position = Vector2(16.0, 16.0)
		status_panel.custom_minimum_size.x = left_width
		status_panel.size.x = left_width
		var bar_width: float = maxf(180.0, left_width - 48.0)
		if health_bar:
			health_bar.custom_minimum_size.x = bar_width
		if guard_bar:
			guard_bar.custom_minimum_size.x = bar_width
		if spirit_bar:
			spirit_bar.custom_minimum_size.x = bar_width
	if minimap:
		minimap.offset_left = -map_size - 16.0
		minimap.offset_right = -16.0
		minimap.offset_top = 16.0
		minimap.offset_bottom = 16.0 + map_size
		minimap.custom_minimum_size = Vector2(map_size, map_size)
	if tracker_box:
		tracker_box.offset_left = -right_width
		tracker_box.offset_right = -16.0
		tracker_box.offset_top = map_size + 28.0
		tracker_box.offset_bottom = 0.0
		tracker_box.custom_minimum_size.x = right_width
	if log_box:
		var log_width: float = clampf(viewport_size.x * 0.24, 210.0, 300.0)
		log_box.offset_left = -log_width
		log_box.offset_right = -16.0
		log_box.offset_top = -124.0 if compact else -142.0
		log_box.offset_bottom = -14.0
	if hint_label:
		hint_label.position = Vector2(16.0, -34.0)
		hint_label.size = Vector2(maxf(180.0, viewport_size.x - (right_width + 52.0 if compact else 390.0)), 22.0)
	if prompt_panel and prompt_label:
		var prompt_width: float = maxf(180.0, minf(540.0, viewport_size.x - 80.0))
		prompt_label.custom_minimum_size.x = prompt_width
		prompt_panel.custom_minimum_size.x = prompt_width + 32.0
	if gather_panel and gather_bar:
		gather_bar.custom_minimum_size.x = maxf(180.0, minf(300.0, viewport_size.x - 80.0))
	if boss_panel and boss_bar:
		var desired_boss_width: float = 560.0 if _boss_ui_raid_mode else 400.0
		var boss_width: float = minf(desired_boss_width, viewport_size.x - 32.0)
		boss_panel.custom_minimum_size.x = boss_width
		boss_bar.custom_minimum_size.x = maxf(180.0, boss_width - 30.0)
	if zone_label:
		var zone_half_width: float = minf(500.0, (viewport_size.x - 32.0) * 0.5)
		zone_label.offset_left = -zone_half_width
		zone_label.offset_right = zone_half_width
	if toast_box:
		var toast_half_width: float = minf(270.0, (viewport_size.x - 32.0) * 0.5)
		toast_box.offset_left = -toast_half_width
		toast_box.offset_right = toast_half_width

func _build_ui() -> void:
	_hud_root = Control.new()
	_hud_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_hud_root)

	# --- Status panel (top-left) ---
	status_panel = UIKit.panel(Color(0.06, 0.07, 0.1, 0.74), Color(0.75, 0.6, 0.3, 0.8), 10, 1)
	status_panel.position = Vector2(16, 16)
	status_panel.custom_minimum_size = Vector2(285, 0)
	status_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(status_panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	status_panel.add_child(vb)

	health_bar = ProgressBar.new()
	health_bar.custom_minimum_size = Vector2(230, 20)
	health_bar.show_percentage = false
	health_bar.max_value = 100.0
	health_bar.value = 100.0
	health_bar.add_theme_stylebox_override("background", UIKit.style(Color(0.15, 0.05, 0.05, 0.9), Color(0, 0, 0, 0.6), 6, 1, 0, 0))
	health_bar.add_theme_stylebox_override("fill", UIKit.style(Color(0.82, 0.16, 0.18), Color(1.0, 0.45, 0.4, 0.6), 6, 1, 0, 0))
	vb.add_child(health_bar)
	health_label = _label("100 / 100", 14)
	health_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	health_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	health_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	health_bar.add_child(health_label)
	guard_bar = ProgressBar.new()
	guard_bar.custom_minimum_size = Vector2(230, 8)
	guard_bar.max_value = 100.0
	guard_bar.value = 100.0
	guard_bar.show_percentage = false
	guard_bar.add_theme_stylebox_override("background", UIKit.style(Color(0.08, 0.12, 0.18, 0.95), Color(0, 0, 0, 0.5), 4, 1, 0, 0))
	guard_bar.add_theme_stylebox_override("fill", UIKit.style(Color(0.25, 0.68, 0.88), Color(0.55, 0.88, 1.0, 0.65), 4, 1, 0, 0))
	vb.add_child(guard_bar)
	guard_label = _label("GUARD 100%", 10, Color(0.65, 0.82, 0.94))
	_fit_label(guard_label)
	vb.add_child(guard_label)
	spirit_bar = ProgressBar.new()
	spirit_bar.custom_minimum_size = Vector2(230, 8)
	spirit_bar.max_value = 30.0
	spirit_bar.value = 30.0
	spirit_bar.show_percentage = false
	spirit_bar.add_theme_stylebox_override("background", UIKit.style(Color(0.08, 0.07, 0.16, 0.95), Color(0, 0, 0, 0.5), 4, 1, 0, 0))
	spirit_bar.add_theme_stylebox_override("fill", UIKit.style(Color(0.48, 0.35, 0.88), Color(0.72, 0.62, 1.0, 0.7), 4, 1, 0, 0))
	vb.add_child(spirit_bar)
	spirit_label = _label("SPIRIT 30 / 30", 10, Color(0.78, 0.7, 1.0))
	_fit_label(spirit_label)
	vb.add_child(spirit_label)
	cultivation_status_label = _label("Mortal Foundation • Unawakened", 10, Color(0.86, 0.78, 1.0))
	_fit_label(cultivation_status_label)
	vb.add_child(cultivation_status_label)
	element_status_label = _label("Fire • Way of the Blade", 10, Color(1.0, 0.76, 0.5))
	_fit_label(element_status_label)
	vb.add_child(element_status_label)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	vb.add_child(row)
	age_label = _label("Age 5", 12, Color(1.0, 0.9, 0.6))
	time_label = _label("07:00", 12, Color(0.8, 0.9, 1.0))
	gold_label = _label("0 gold", 12, UIKit.GOLD)
	_fit_label(age_label)
	_fit_label(time_label)
	_fit_label(gold_label)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(age_label)
	row.add_child(time_label)
	row.add_child(gold_label)
	tide_label = _label("TIDE  RISING", 10, Color(0.48, 0.78, 0.91))
	_fit_label(tide_label)
	vb.add_child(tide_label)
	title_label = _label("", 11, Color(0.85, 0.75, 1.0))
	_fit_label(title_label)
	vb.add_child(title_label)

	# --- Quest tracker (top-right) ---
	tracker_box = VBoxContainer.new()
	tracker_box.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	tracker_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	tracker_box.offset_left = -290.0
	tracker_box.offset_right = -16.0
	tracker_box.offset_top = 190.0
	tracker_box.add_theme_constant_override("separation", 8)
	tracker_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(tracker_box)

	# --- Persistent local minimap ---
	minimap = MinimapCanvas.new()
	minimap.name = "PersistentMinimap"
	minimap.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	minimap.offset_left = -150.0
	minimap.offset_right = -16.0
	minimap.offset_top = 16.0
	minimap.offset_bottom = 150.0
	minimap.custom_minimum_size = Vector2(134.0, 134.0)
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(minimap)

	# --- Boss encounter header ---
	boss_panel = UIKit.panel(Color(0.055, 0.035, 0.045, 0.9), Color(0.72, 0.25, 0.2, 0.95), 12, 2)
	boss_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	boss_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	boss_panel.position = Vector2(0, 16)
	boss_panel.custom_minimum_size = Vector2(400, 0)
	boss_panel.visible = false
	boss_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(boss_panel)
	var boss_vb := VBoxContainer.new()
	boss_vb.add_theme_constant_override("separation", 3)
	boss_panel.add_child(boss_vb)
	boss_name = _label("BOSS", 16, Color(1.0, 0.78, 0.62))
	boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	boss_name.custom_minimum_size.x = 0.0
	_fit_label(boss_name, true)
	boss_vb.add_child(boss_name)
	boss_bar = UIKit.bar(Color(0.72, 0.12, 0.16), 13)
	boss_bar.custom_minimum_size = Vector2(370, 12)
	boss_bar.max_value = 100.0
	boss_bar.value = 100.0
	boss_vb.add_child(boss_bar)

	# --- Crosshair ---
	crosshair = Control.new()
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(crosshair)
	var dot := ColorRect.new()
	dot.color = Color(1, 1, 1, 0.55)
	dot.size = Vector2(4, 4)
	dot.position = Vector2(-2, -2)
	crosshair.add_child(dot)

	# --- Interaction prompt ---
	prompt_panel = UIKit.panel(Color(0.06, 0.07, 0.1, 0.82), Color(0.75, 0.6, 0.3, 0.9), 20, 2)
	prompt_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	prompt_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	prompt_panel.position = Vector2(0, -150)
	prompt_panel.visible = false
	prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(prompt_panel)
	prompt_label = _label("[E]  Interact", 17, Color(1.0, 0.95, 0.8))
	prompt_label.custom_minimum_size = Vector2(250, 0)
	_fit_label(prompt_label, true)
	prompt_panel.add_child(prompt_label)

	# --- Gather progress ---
	gather_panel = UIKit.panel(Color(0.06, 0.07, 0.1, 0.85), Color(0.5, 0.8, 0.5, 0.9), 12, 2)
	gather_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	gather_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	gather_panel.position = Vector2(0, -210)
	gather_panel.visible = false
	gather_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(gather_panel)
	var gv := VBoxContainer.new()
	gather_panel.add_child(gv)
	gather_label = _label("Gathering...", 15)
	_fit_label(gather_label, true)
	gather_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	gv.add_child(gather_label)
	gather_bar = UIKit.bar(Color(0.45, 0.85, 0.45), 14)
	gather_bar.custom_minimum_size = Vector2(240, 12)
	gv.add_child(gather_bar)

	# --- Zone banner ---
	zone_label = _label("", 34, Color(1.0, 0.93, 0.75))
	zone_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	zone_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	zone_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	zone_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	zone_label.position = Vector2(0, 152)
	zone_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	zone_label.modulate.a = 0.0
	zone_label.add_theme_constant_override("outline_size", 10)
	zone_label.custom_minimum_size.y = 52.0
	_hud_root.add_child(zone_label)

	# --- Toasts (top-centre) ---
	toast_box = VBoxContainer.new()
	toast_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_box.position = Vector2(0, 66)
	toast_box.offset_left = -270.0
	toast_box.offset_right = 270.0
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(toast_box)

	# --- Activity feed (bottom-right) ---
	log_box = VBoxContainer.new()
	log_box.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	log_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	log_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
	log_box.offset_right = -18.0
	log_box.offset_bottom = -18.0
	log_box.offset_left = -300.0
	log_box.offset_top = -142.0
	log_box.alignment = BoxContainer.ALIGNMENT_END
	log_box.add_theme_constant_override("separation", 1)
	log_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_root.add_child(log_box)

	# --- Controls hint (bottom-left) ---
	hint_label = _label("WASD Move  •  LMB Attack  •  E Interact  •  I Inventory  •  M Map  •  F2 Network  •  F10 Graphics", 10, Color(1, 1, 1, 0.72))
	hint_label.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	hint_label.position = Vector2(16, -34)
	_fit_label(hint_label)
	_hud_root.add_child(hint_label)

	# --- Death screen ---
	death_root = Control.new()
	death_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	death_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	death_root.visible = false
	_hud_root.add_child(death_root)
	var shade := ColorRect.new()
	shade.color = Color(0.25, 0.0, 0.02, 0.55)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	death_root.add_child(shade)
	death_label = _label("You have fallen...", 40, Color(1.0, 0.85, 0.8))
	death_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	death_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	death_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	death_root.add_child(death_label)

func _connect_to_player() -> void:
	player = GameManager.player as Player
	if player and player.has_node("HealthComponent"):
		var hc: HealthComponent = player.get_node("HealthComponent")
		hc.health_changed.connect(_on_health_changed)
		hc.died.connect(_on_player_died)
		_on_health_changed(hc.current_health, hc.max_health)
	if player:
		age_label.text = "Age %.0f" % player.current_age

func _on_health_changed(current: float, maximum: float) -> void:
	if current > 0.0 and death_root:
		death_root.visible = false
	health_bar.max_value = maximum
	health_bar.value = current
	health_label.text = "%d / %d" % [int(ceil(current - 0.01)), int(maximum)]

func _update_title() -> void:
	title_label.text = ("Title: %s" % PlayerData.active_title) if PlayerData.active_title != "" else ""
	title_label.visible = PlayerData.active_title != ""

func _on_interaction_available(target: Node) -> void:
	if prompt_label == null or prompt_panel == null:
		return
	var txt: String = ""
	if is_instance_valid(target) and target.has_method("get_prompt"):
		var prompt_value: Variant = target.call("get_prompt")
		if prompt_value != null:
			txt = str(prompt_value).strip_edges()
	if txt.is_empty():
		txt = _fallback_interaction_prompt(target)
	if txt.is_empty():
		txt = "Interact"
	prompt_label.text = "[E]  %s" % txt
	prompt_label.visible = true
	prompt_panel.visible = true

func _fallback_interaction_prompt(target: Node) -> String:
	if not is_instance_valid(target):
		return "Interact"
	if target is CraftingStation:
		var station: CraftingStation = target as CraftingStation
		match station.station_type:
			"forge": return "Use the Forge"
			"alchemy": return "Use the Alchemy Table"
			"campfire": return "Cook at the Campfire"
			_: return "Use %s Station" % station.station_type.replace("_", " ").capitalize()
	if target is NPC:
		var npc: NPC = target as NPC
		return "Talk to %s" % (npc.npc_name if not npc.npc_name.strip_edges().is_empty() else "Villager")
	var readable_name: String = target.name.strip_edges().replace("_", " ")
	if not readable_name.is_empty():
		return "Interact with %s" % readable_name
	return "Interact"

# ---------------------------------------------------------------------------
# Quest tracker
# ---------------------------------------------------------------------------
func _update_tracker() -> void:
	if tracker_box == null:
		return
	UIKit.clear(tracker_box)
	var ids: Array = PlayerData.active_quest_ids()
	var shown: int = 0
	for id in ids:
		if shown >= 2:
			break
		shown += 1
		var q: Dictionary = QuestDB.QUESTS[id]
		var ready: bool = PlayerData.is_ready(id)
		var p: PanelContainer = UIKit.panel(Color(0.06, 0.07, 0.1, 0.68), UIKit.GOOD if ready else Color(0.75, 0.6, 0.3, 0.7), 8, 1)
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 1)
		p.add_child(vb)
		var quest_title: Label = _label(q["title"], 13, UIKit.GOOD if ready else UIKit.GOLD)
		_fit_label(quest_title, true)
		vb.add_child(quest_title)
		if ready:
			var turn_in_label: Label = _label("Return to %s" % q["turn_in"], 11, UIKit.GOOD)
			_fit_label(turn_in_label, true)
			vb.add_child(turn_in_label)
		else:
			var objs: Array = q["objectives"]
			for i in range(mini(objs.size(), 2)):
				var prog: int = PlayerData.objective_progress(id, i)
				var need: int = int(objs[i]["count"])
				var objective_label: Label = _label("%s  %d/%d" % [objs[i]["text"], prog, need], 11, UIKit.GOOD if prog >= need else UIKit.TEXT)
				_fit_label(objective_label, true)
				vb.add_child(objective_label)
		tracker_box.add_child(p)

# ---------------------------------------------------------------------------
# Activity feed (loot, skills, quests...)
# ---------------------------------------------------------------------------
func _log_line(text: String, kind: String) -> void:
	if log_box == null:
		return
	var color: Color = UIKit.DIM
	match kind:
		"loot": color = Color(1.0, 0.85, 0.45)
		"skill": color = Color(0.55, 0.8, 1.0)
		"quest": color = Color(1.0, 0.93, 0.5)
		"combat": color = Color(1.0, 0.5, 0.45)
		_: color = Color(0.85, 0.85, 0.9)
	var l: Label = _label(text, 12, color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_fit_label(l, true)
	l.custom_minimum_size.x = 200.0
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	log_box.add_child(l)
	var tw: Tween = create_tween()
	tw.tween_interval(6.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.0)
	tw.tween_callback(l.queue_free)
	while log_box.get_child_count() > 4:
		var old: Node = log_box.get_child(0)
		log_box.remove_child(old)
		old.queue_free()

func _on_zone_entered(zone_name: String, first: bool) -> void:
	zone_label.text = zone_name
	if _zone_tween and _zone_tween.is_valid():
		_zone_tween.kill()
	_zone_tween = create_tween()
	_zone_tween.tween_property(zone_label, "modulate:a", 1.0, 0.6)
	_zone_tween.tween_interval(2.6 if first else 1.6)
	_zone_tween.tween_property(zone_label, "modulate:a", 0.0, 1.0)

func _show_toast(text: String, kind: String = "info") -> void:
	var p: PanelContainer = UIKit.panel(Color(0.06, 0.07, 0.1, 0.84), Color(0.75, 0.6, 0.3, 0.9), 14, 2)
	var fg: Color = Color.WHITE
	match kind:
		"levelup":
			p.add_theme_stylebox_override("panel", UIKit.style(Color(0.08, 0.07, 0.04, 0.88), Color(1.0, 0.85, 0.3), 14, 2, 16, 8))
			fg = Color(1.0, 0.92, 0.55)
		"xp":
			fg = Color(0.75, 0.9, 1.0)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.custom_minimum_size.x = minf(520.0, get_viewport().get_visible_rect().size.x - 40.0)
	var toast_label: Label = _label(text, 18 if kind == "levelup" else 15, fg)
	toast_label.custom_minimum_size.x = 240.0
	toast_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	toast_label.clip_text = false
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	p.add_child(toast_label)
	toast_box.add_child(p)
	p.modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.tween_property(p, "modulate:a", 1.0, 0.2)
	tw.tween_interval(2.8 if kind == "levelup" else 1.8)
	tw.tween_property(p, "modulate:a", 0.0, 0.5)
	tw.tween_callback(p.queue_free)
	while toast_box.get_child_count() > 2:
		var old: Node = toast_box.get_child(0)
		toast_box.remove_child(old)
		old.queue_free()

func _process(delta: float) -> void:
	if day_night and time_label:
		time_label.text = "%s %s" % [day_night.get_time_string(), "Day" if day_night.is_day else "Night"]
	if tide_label and is_instance_valid(TideSystem):
		tide_label.text = TideSystem.get_status_text()
	crosshair.visible = Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not GameManager.input_locked
	var active_boss: Monster = null
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	for candidate in get_tree().get_nodes_in_group("boss"):
		if not candidate is Monster or candidate.state == Monster.State.DEAD or not candidate.is_visible_in_tree():
			continue
		if not is_instance_valid(player) or candidate.global_position.distance_to(player.global_position) > 60.0:
			continue
		if candidate.has_meta("dungeon_floor") and (dungeon == null or not dungeon.inside or dungeon.current_floor != int(candidate.get_meta("dungeon_floor")) or not dungeon.has_discovery(dungeon.current_floor, "boss_chamber")):
			continue
		active_boss = candidate
		break
	boss_panel.visible = active_boss != null
	if toast_box:
		toast_box.position.y = 92.0 if boss_panel.visible else 48.0
	if active_boss != null and active_boss.health != null:
		var is_raid_boss: bool = bool(active_boss.get_meta("raid_boss", false))
		if is_raid_boss != _boss_ui_raid_mode:
			_boss_ui_raid_mode = is_raid_boss
			var available_boss_width: float = get_viewport().get_visible_rect().size.x - 32.0
			var raid_width: float = minf(560.0, available_boss_width)
			var normal_width: float = minf(400.0, available_boss_width)
			boss_panel.custom_minimum_size = Vector2(raid_width if is_raid_boss else normal_width, 0)
			boss_bar.custom_minimum_size = Vector2(maxf(180.0, (raid_width if is_raid_boss else normal_width) - 30.0), 14)
		if is_raid_boss:
			var phase_labels: Array[String] = ["I", "II", "III", "IV"]
			var phase_index: int = clampi(active_boss.get_boss_phase(), 0, phase_labels.size() - 1)
			var floor_number: int = int(active_boss.get_meta("raid_floor", 1))
			var guardian_name: String = active_boss.display_name.trim_prefix("Floor %d: " % floor_number)
			boss_name.text = "RAID GUARDIAN  •  FLOOR %02d / 100  •  PHASE %s\n✦  %s  ✦" % [floor_number, phase_labels[phase_index], guardian_name]
		else:
			boss_name.text = "✦  %s  ✦" % active_boss.display_name
		boss_bar.max_value = active_boss.health.max_health
		boss_bar.value = active_boss.health.current_health
	if player and is_instance_valid(player):
		guard_bar.value = player.guard_stamina
		guard_label.text = "GUARD %d%%" % int(player.guard_stamina)
		guard_label.modulate = Color(0.65, 0.9, 1.0) if player.guarding else Color(0.65, 0.82, 0.94)
		spirit_bar.max_value = maxf(player.max_spiritual_energy, 1.0)
		spirit_bar.value = player.spiritual_energy
		spirit_label.text = "SPIRIT %d / %d%s" % [int(player.spiritual_energy), int(player.max_spiritual_energy), " • ACTIVE" if player._cultivating else ""]
		spirit_label.modulate = Color(0.9, 0.82, 1.0) if player._cultivating else Color(0.72, 0.66, 0.9)
		cultivation_status_label.text = "%s • %s" % [player.skills.cultivation_realm_name(), str(player.skills.cultivation_state.get("spiritual_root", "Unawakened"))]
		element_status_label.text = "%s • %s" % [player.selected_element.capitalize(), player.skills.active_cultivation_path_name()]
		_minimap_refresh_timer -= delta
		if minimap and _minimap_refresh_timer <= 0.0:
			_minimap_refresh_timer = 0.16
			minimap.world_range = 72.0 if player.skills.is_cultivation_technique_active("spirit_sight") else 48.0
			var local_enemies: Array[Vector2] = []
			var local_npcs: Array[Vector2] = []
			var local_points: Array[Vector2] = []
			for enemy in get_tree().get_nodes_in_group("enemy"):
				if bool(enemy.get_meta("floor_boss", false)) and (dungeon == null or not dungeon.inside or not dungeon.has_discovery(dungeon.current_floor, "boss_chamber")):
					continue
				if enemy is Node3D and is_instance_valid(enemy) and enemy.is_visible_in_tree() and absf(enemy.global_position.y - player.global_position.y) < 8.0:
					var enemy_pos: Vector2 = Vector2(enemy.global_position.x, enemy.global_position.z)
					if enemy_pos.distance_to(Vector2(player.global_position.x, player.global_position.z)) <= minimap.world_range:
						local_enemies.append(enemy_pos)
			for npc in get_tree().get_nodes_in_group("npc"):
				if npc is Node3D and is_instance_valid(npc):
					var npc_pos: Vector2 = Vector2(npc.global_position.x, npc.global_position.z)
					if npc_pos.distance_to(Vector2(player.global_position.x, player.global_position.z)) <= minimap.world_range:
						local_npcs.append(npc_pos)
			for marker_group in ["poi_shrine", "poi_ruin"]:
				for marker in get_tree().get_nodes_in_group(marker_group):
					if marker is Node3D and is_instance_valid(marker):
						var marker_pos: Vector2 = Vector2(marker.global_position.x, marker.global_position.z)
						if marker_pos.distance_to(Vector2(player.global_position.x, player.global_position.z)) <= minimap.world_range:
							local_points.append(marker_pos)
			var player_forward: Vector3 = -player.global_transform.basis.z
			minimap.update_radar(Vector2(player.global_position.x, player.global_position.z), Vector2(player_forward.x, player_forward.z), local_enemies, local_npcs, local_points)
		var gr: float = player.gather_ratio
		gather_panel.visible = gr >= 0.0
		if gr >= 0.0:
			gather_bar.value = gr
			gather_label.text = player.gather_text
	# Defensive: an interaction prompt with no text used to leave an empty
	# rounded bar sitting over the middle of the screen.
	if prompt_panel and prompt_panel.visible and prompt_label and prompt_label.text.strip_edges().is_empty():
		prompt_panel.visible = false
	if _hint_time > 0.0:
		_hint_time -= delta
		hint_label.modulate.a = clampf(_hint_time / 2.0, 0.0, 1.0)
		if _hint_time <= 0.0:
			hint_label.visible = false

func _on_player_died(_source: Node) -> void:
	death_root.visible = true
	prompt_panel.visible = false
	var age: float = player.current_age if player else 5.0
	if str(PlayerData.stats.get("death_cause", "")) == "old_age":
		death_label.text = "Your mortal life has ended at age %.0f.\nCultivation can extend lifespan before it expires.\nThis character cannot be revived." % age
	else:
		death_label.text = "You have fallen...\nAge %.0f — your progress is retained\nDeath cost: 5%% carried gold and 10%% gear durability\n\nPress R to recover at Elyndor sanctuary" % age
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_H:
			_hint_time = 0.0
			hint_label.visible = not hint_label.visible
			hint_label.modulate.a = 1.0
		elif event.keycode == KEY_R and death_root.visible and player:
			player.respawn_at_sanctuary()
