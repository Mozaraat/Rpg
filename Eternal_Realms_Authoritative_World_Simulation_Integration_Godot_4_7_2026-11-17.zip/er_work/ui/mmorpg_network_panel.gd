extends CanvasLayer

var panel: PanelContainer
var status_label: Label
var peers_label: Label
var address_input: LineEdit
var port_input: SpinBox
var roster_label: Label
var party_label: Label
var peer_id_input: SpinBox
var trade_peer_input: SpinBox
var trade_id_input: LineEdit
var trade_gold_input: SpinBox
var trade_items_box: VBoxContainer
var trade_status_label: Label
var sect_org_input: LineEdit
var sect_territory_input: LineEdit
var sect_tax_input: SpinBox
var sect_economy_status: Label
var regional_id_input: LineEdit
var trade_item_checks: Dictionary = {}

func _ready() -> void:
	_build_ui()
	MMORPGNetwork.network_status_changed.connect(_on_status_changed)
	MMORPGNetwork.peer_count_changed.connect(_on_peer_count_changed)
	MMORPGNetwork.world_roster_changed.connect(_on_roster_changed)
	MMORPGNetwork.party_invite_received.connect(_on_party_invite_received)
	MMORPGNetwork.trade_invitation_received.connect(_on_trade_invitation_received)
	MMORPGNetwork.trade_status_changed.connect(_on_trade_status_changed)
	MMORPGNetwork.sect_economy_result_received.connect(_on_sect_economy_result)
	PlayerData.inventory_changed.connect(_refresh_trade_inventory)
	PartySystem.party_changed.connect(_on_party_changed)
	_on_status_changed(MMORPGNetwork.status_message)
	_on_peer_count_changed(MMORPGNetwork.get_online_player_count())

func _build_ui() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	panel = PanelContainer.new()
	panel.position = Vector2(18, 92)
	panel.custom_minimum_size = Vector2(390, 680)
	panel.size = Vector2(390, 680)
	panel.visible = false
	root.add_child(panel)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(370, 660)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	var column := VBoxContainer.new()
	column.custom_minimum_size = Vector2(350, 0)
	column.add_theme_constant_override("separation", 7)
	scroll.add_child(column)
	var title := Label.new()
	title.text = "ETERNAL REALMS  ·  WORLD NETWORK"
	title.add_theme_font_size_override("font_size", 14)
	column.add_child(title)
	status_label = Label.new()
	status_label.text = "Offline single-player"
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(status_label)
	peers_label = Label.new()
	peers_label.text = "Players: 0"
	column.add_child(peers_label)
	address_input = LineEdit.new()
	address_input.placeholder_text = "Server address (127.0.0.1 for local test)"
	address_input.text = "127.0.0.1"
	column.add_child(address_input)
	port_input = SpinBox.new()
	port_input.min_value = 1024
	port_input.max_value = 65535
	port_input.value = MMORPGNetwork.DEFAULT_PORT
	port_input.prefix = "UDP port "
	column.add_child(port_input)
	var buttons := HBoxContainer.new()
	column.add_child(buttons)
	var host_button := Button.new()
	host_button.text = "Host"
	host_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_button.pressed.connect(_host_pressed)
	buttons.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "Join"
	join_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_button.pressed.connect(_join_pressed)
	buttons.add_child(join_button)
	var disconnect_button := Button.new()
	disconnect_button.text = "Disconnect"
	disconnect_button.pressed.connect(MMORPGNetwork.stop_network)
	column.add_child(disconnect_button)
	var hint := Label.new()
	hint.text = "F2 toggles this panel. Everyone joins the same persistent world; there are no parallel world shards. For internet play, connect to the dedicated server address."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 11)
	column.add_child(hint)
	roster_label = Label.new()
	roster_label.text = MMORPGNetwork.get_world_roster_text()
	roster_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	roster_label.add_theme_font_size_override("font_size", 11)
	column.add_child(roster_label)
	var party_title := Label.new()
	party_title.text = "WORLD PARTY  ·  UP TO 5 CULTIVATORS"
	party_title.add_theme_font_size_override("font_size", 12)
	column.add_child(party_title)
	party_label = Label.new()
	party_label.text = "No active party"
	party_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(party_label)
	var party_create := Button.new()
	party_create.text = "Create Party"
	party_create.pressed.connect(func() -> void: PartySystem.create_online_party(MMORPGNetwork.local_character_name))
	column.add_child(party_create)
	var invite_row := HBoxContainer.new()
	column.add_child(invite_row)
	peer_id_input = SpinBox.new()
	peer_id_input.min_value = 2
	peer_id_input.max_value = 128
	peer_id_input.value = 2
	peer_id_input.prefix = "Peer #"
	peer_id_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	invite_row.add_child(peer_id_input)
	var invite_button := Button.new()
	invite_button.text = "Invite"
	invite_button.pressed.connect(func() -> void: PartySystem.invite_online_peer(int(peer_id_input.value)))
	invite_row.add_child(invite_button)
	var party_actions := HBoxContainer.new()
	column.add_child(party_actions)
	var accept_button := Button.new()
	accept_button.text = "Accept Invite"
	accept_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	accept_button.pressed.connect(func() -> void: PartySystem.accept_online_invite(MMORPGNetwork.pending_party_invite_id))
	party_actions.add_child(accept_button)
	var leave_button := Button.new()
	leave_button.text = "Leave"
	leave_button.pressed.connect(PartySystem.leave_online_party)
	party_actions.add_child(leave_button)

	var trade_title := Label.new()
	trade_title.text = "PLAYER TRADE  ·  SERVER VERIFIED"
	trade_title.add_theme_font_size_override("font_size", 12)
	column.add_child(trade_title)
	var trade_row := HBoxContainer.new()
	column.add_child(trade_row)
	trade_peer_input = SpinBox.new()
	trade_peer_input.min_value = 2
	trade_peer_input.max_value = 128
	trade_peer_input.value = 2
	trade_peer_input.prefix = "Peer #"
	trade_peer_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	trade_row.add_child(trade_peer_input)
	var trade_request_button := Button.new()
	trade_request_button.text = "Request Trade"
	trade_request_button.pressed.connect(func() -> void: MMORPGNetwork.request_player_trade(int(trade_peer_input.value)))
	trade_row.add_child(trade_request_button)
	trade_id_input = LineEdit.new()
	trade_id_input.placeholder_text = "Trade invitation / session ID"
	column.add_child(trade_id_input)
	var trade_actions := HBoxContainer.new()
	column.add_child(trade_actions)
	var accept_trade_button := Button.new()
	accept_trade_button.text = "Accept Invitation"
	accept_trade_button.pressed.connect(func() -> void: MMORPGNetwork.request_accept_trade(trade_id_input.text.strip_edges()))
	trade_actions.add_child(accept_trade_button)
	var refresh_trade_button := Button.new()
	refresh_trade_button.text = "Refresh Items"
	refresh_trade_button.pressed.connect(_refresh_trade_inventory)
	trade_actions.add_child(refresh_trade_button)
	trade_items_box = VBoxContainer.new()
	trade_items_box.custom_minimum_size = Vector2(250, 90)
	column.add_child(trade_items_box)
	trade_gold_input = SpinBox.new()
	trade_gold_input.min_value = 0
	trade_gold_input.max_value = 1000000000
	trade_gold_input.step = 1
	trade_gold_input.prefix = "Gold offered "
	column.add_child(trade_gold_input)
	var submit_offer_button := Button.new()
	submit_offer_button.text = "Submit Offer + Confirm"
	submit_offer_button.pressed.connect(_submit_trade_offer)
	column.add_child(submit_offer_button)
	trade_status_label = Label.new()
	trade_status_label.text = "Trade only works with a connected player within 6 metres."
	trade_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	trade_status_label.add_theme_font_size_override("font_size", 11)
	column.add_child(trade_status_label)

	var sect_economy_title := Label.new()
	sect_economy_title.text = "SECT ECONOMY  ·  TREASURY & TERRITORY TAX"
	sect_economy_title.add_theme_font_size_override("font_size", 12)
	column.add_child(sect_economy_title)
	sect_org_input = LineEdit.new()
	sect_org_input.placeholder_text = "Your registered sect organization UUID"
	column.add_child(sect_org_input)	
	sect_territory_input = LineEdit.new()
	sect_territory_input.placeholder_text = "Territory ID (must be owned by your sect)"
	column.add_child(sect_territory_input)
	sect_tax_input = SpinBox.new()
	sect_tax_input.min_value = 0
	sect_tax_input.max_value = 2500
	sect_tax_input.step = 25
	sect_tax_input.suffix = " bps (max 25%)"
	column.add_child(sect_tax_input)
	var sect_economy_actions := HBoxContainer.new()
	column.add_child(sect_economy_actions)
	var treasury_button := Button.new()
	treasury_button.text = "View Treasury"
	treasury_button.pressed.connect(func() -> void: MMORPGNetwork.request_sect_treasury(sect_org_input.text.strip_edges()))
	sect_economy_actions.add_child(treasury_button)
	var tax_button := Button.new()
	tax_button.text = "Set Territory Tax"
	tax_button.pressed.connect(func() -> void: MMORPGNetwork.request_set_sect_tax(sect_org_input.text.strip_edges(), sect_territory_input.text.strip_edges(), int(sect_tax_input.value), true))
	sect_economy_actions.add_child(tax_button)
	sect_economy_status = Label.new()
	sect_economy_status.text = "Available to registered player-founded sects with an owned territory."
	sect_economy_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sect_economy_status.add_theme_font_size_override("font_size", 11)
	column.add_child(sect_economy_status)
	var regional_row := HBoxContainer.new()
	column.add_child(regional_row)
	regional_id_input = LineEdit.new()
	regional_id_input.placeholder_text = "Region ID (e.g. elyndor)"
	regional_id_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	regional_row.add_child(regional_id_input)
	var regional_button := Button.new()
	regional_button.text = "View Market Flows"
	regional_button.pressed.connect(func() -> void: MMORPGNetwork.request_regional_economy(regional_id_input.text.strip_edges()))
	regional_row.add_child(regional_button)
	_refresh_player_sect_org_id()
	_refresh_trade_inventory()

func _process(_delta: float) -> void:
	# Player totals arrive from the authoritative world roster via peer_count_changed.
	pass

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F2:
		panel.visible = not panel.visible
		_refresh_player_sect_org_id()
		get_viewport().set_input_as_handled()

func _host_pressed() -> void:
	MMORPGNetwork.start_host(int(port_input.value))

func _join_pressed() -> void:
	MMORPGNetwork.join_server(address_input.text, int(port_input.value))

func _on_status_changed(message: String) -> void:
	if status_label:
		status_label.text = message

func _on_peer_count_changed(count: int) -> void:
	if peers_label:
		peers_label.text = "Players in One World: %d" % count

func _on_roster_changed(_roster: Dictionary) -> void:
	if roster_label:
		roster_label.text = MMORPGNetwork.get_world_roster_text()

func _on_party_changed(party: Dictionary) -> void:
	if not party_label:
		return
	if not bool(party.get("active", false)):
		party_label.text = "No active party"
		return
	var names: PackedStringArray = []
	for member in party.get("members", []):
		names.append(str(member.get("name", "Cultivator")))
	party_label.text = "Party: " + ", ".join(names)

func _on_party_invite_received(party_id: String, leader_name: String) -> void:
	if party_label:
		party_label.text = "Invite from %s — press Accept Invite" % leader_name


func _on_trade_invitation_received(trade_id: String, initiator_name: String) -> void:
	trade_id_input.text = trade_id
	trade_status_label.text = "Invitation from %s. Accept it to open the exchange." % initiator_name
	panel.visible = true

func _on_trade_status_changed(trade_id: String, message: String, success: bool) -> void:
	if trade_id_input and (trade_id_input.text.is_empty() or trade_id_input.text == trade_id):
		trade_id_input.text = trade_id
		trade_status_label.text = message
		trade_status_label.add_theme_color_override("font_color", Color(0.55, 0.88, 0.62) if success else Color(1.0, 0.48, 0.42))

func _refresh_trade_inventory() -> void:
	if not is_instance_valid(trade_items_box):
		return
	for child in trade_items_box.get_children():
		child.queue_free()
	trade_item_checks.clear()
	var title := Label.new()
	title.text = "Select items to offer (unequipped only)"
	trade_items_box.add_child(title)
	for slot_index in range(PlayerData.slots.size()):
		var item: Dictionary = PlayerData.item_at(slot_index)
		if item.is_empty():
			continue
		var instance_id := str(PlayerData.authoritative_item_instance_ids.get(slot_index, ""))
		var check := CheckBox.new()
		check.text = "%s ×%d" % [ItemDB.display_name(item), int(item.get("count", 1))]
		check.disabled = instance_id.is_empty()
		check.tooltip_text = "Server inventory ID unavailable; reconnect or refresh authoritative inventory." if instance_id.is_empty() else "Offer this item instance"
		trade_items_box.add_child(check)
		if not instance_id.is_empty():
			trade_item_checks[check] = instance_id

func _submit_trade_offer() -> void:
	var trade_id := trade_id_input.text.strip_edges()
	if trade_id.is_empty():
		trade_status_label.text = "Enter or accept a trade invitation first."
		return
	var item_ids: Array = []
	for check_variant in trade_item_checks.keys():
		var check: CheckBox = check_variant
		if check.button_pressed:
			item_ids.append(str(trade_item_checks[check]))
	if not WorldDeploymentGuard.is_production_session() or not MMORPGNetwork.is_online():
		trade_status_label.text = "Connect to the production world server to trade."
		return
	MMORPGNetwork.request_submit_trade_offer(trade_id, item_ids, int(trade_gold_input.value), true)
	trade_status_label.text = "Offer sent to the central inventory ledger. Waiting for the other player."


func _refresh_player_sect_org_id() -> void:
	if not is_instance_valid(sect_org_input): return
	var sect_state: Dictionary = PlayerData.stats.get("sect_state", {})
	var player_sect: Dictionary = sect_state.get("player_sect", {})
	var sect_id := str(player_sect.get("id", ""))
	if not sect_id.is_empty():
		sect_org_input.text = MMORPGNetwork._stable_world_uuid("sect-organization:%s" % sect_id)


func _on_sect_economy_result(payload: Dictionary, success: bool, error_message: String) -> void:
	if not is_instance_valid(sect_economy_status): return
	if not success:
		sect_economy_status.text = "Economy request failed: " + error_message
		return
	if payload.has("balance"):
		sect_economy_status.text = "Treasury balance: %s gold · %d recent ledger entries" % [str(payload.get("balance", 0)), payload.get("ledger", []).size()]
	elif payload.has("commodities"):
		var summaries: PackedStringArray = []
		for row in payload.get("commodities", []):
			if row is Dictionary:
				summaries.append("%s: net %s" % [str(row.get("commodity_id", "resource")), str(row.get("net_quantity", 0))])
		sect_economy_status.text = "Regional flows · " + (" · ".join(summaries) if not summaries.is_empty() else "No recorded market flows yet")
	else:
		sect_economy_status.text = "Territory tax policy updated successfully."
