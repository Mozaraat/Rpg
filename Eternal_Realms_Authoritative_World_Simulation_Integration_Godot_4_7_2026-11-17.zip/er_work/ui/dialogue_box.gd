# Dialogue UI - wide bottom panel, typed text, and a VERTICAL list of choice buttons.
# (The old version collapsed the text label to zero width, so text wrapped one word per line.)
extends CanvasLayer
class_name DialogueBox

signal dialogue_finished

var is_active: bool = false
var is_typing: bool = false

var _panel: PanelContainer
var _name_label: Label
var _text: RichTextLabel
var _choice_box: VBoxContainer
var _hint: Label
var _lines: Array = []
var _index: int = 0
var _chars: float = 0.0
var _choices: Array = []
var _on_choice: Callable = Callable()
var _choices_shown: bool = false
const CHARS_PER_SEC: float = 55.0

func _ready() -> void:
	add_to_group("dialogue_box")
	layer = 10
	visible = false
	_build()

func _build() -> void:
	_panel = UIKit.panel(Color(0.06, 0.07, 0.10, 0.94), UIKit.GOLD, 14, 2)
	_panel.anchor_left = 0.5
	_panel.anchor_right = 0.5
	_panel.anchor_top = 1.0
	_panel.anchor_bottom = 1.0
	_panel.offset_left = -430.0
	_panel.offset_right = 430.0
	_panel.offset_bottom = -26.0
	_panel.offset_top = -190.0
	_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_panel.custom_minimum_size = Vector2(860, 150)
	add_child(_panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	_panel.add_child(vb)

	_name_label = UIKit.label("Name", 22, UIKit.GOLD)
	vb.add_child(_name_label)

	_text = RichTextLabel.new()
	_text.bbcode_enabled = true
	_text.fit_content = true
	_text.scroll_active = false
	_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_text.custom_minimum_size = Vector2(820, 56)
	_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_text.add_theme_font_size_override("normal_font_size", 20)
	_text.add_theme_color_override("default_color", UIKit.TEXT)
	vb.add_child(_text)

	_choice_box = VBoxContainer.new()
	_choice_box.add_theme_constant_override("separation", 6)
	_choice_box.visible = false
	vb.add_child(_choice_box)

	_hint = UIKit.label("", 14, UIKit.DIM)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb.add_child(_hint)

## Simple one-way conversation (compat with the old API)
func start_dialogue(speaker_name: String, dialogue_lines: PackedStringArray) -> void:
	start_conversation(speaker_name, Array(dialogue_lines))

## lines: Array of String. choices: Array of {"id": String, "text": String}.
## on_choice(id) is called AFTER the box closes, so it may open another UI.
func start_conversation(speaker_name: String, lines: Array, choices: Array = [], on_choice: Callable = Callable()) -> void:
	if lines.is_empty() or is_active:
		return
	_lines = lines
	_index = 0
	_choices = choices
	_on_choice = on_choice
	_choices_shown = false
	is_active = true
	visible = true
	_name_label.text = speaker_name
	GameManager.push_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_show_line()

func _show_line() -> void:
	_text.text = _lines[_index]
	_text.visible_characters = 0
	_chars = 0.0
	is_typing = true
	_choice_box.visible = false
	_hint.text = ""

func _process(delta: float) -> void:
	if not is_active or not is_typing:
		return
	_chars += delta * CHARS_PER_SEC
	var total: int = _text.get_total_character_count()
	_text.visible_characters = int(_chars)
	if int(_chars) >= total:
		_finish_typing()

func _finish_typing() -> void:
	is_typing = false
	_text.visible_characters = -1
	var last: bool = _index >= _lines.size() - 1
	if last and not _choices.is_empty():
		_show_choices()
	else:
		_hint.text = "E / Click - Continue" if not last else "E / Click - Close"

func _show_choices() -> void:
	_choices_shown = true
	UIKit.clear(_choice_box)
	var n: int = 1
	for c in _choices:
		var b: Button = UIKit.button("%d.  %s" % [n, c["text"]], 18)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cid: String = c["id"]
		b.pressed.connect(func() -> void: _pick(cid))
		_choice_box.add_child(b)
		n += 1
	_choice_box.visible = true
	_hint.text = "Click, press 1-%d, or Esc to leave" % _choices.size()
	if _choice_box.get_child_count() > 0:
		(_choice_box.get_child(0) as Button).grab_focus()

func _pick(choice_id: String) -> void:
	var cb: Callable = _on_choice
	_close()
	if cb.is_valid():
		cb.call(choice_id)

func _input(event: InputEvent) -> void:
	if not is_active:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			get_viewport().set_input_as_handled()
			_close()
			return
		if _choices_shown and event.keycode >= KEY_1 and event.keycode <= KEY_9:
			var idx: int = int(event.keycode) - int(KEY_1)
			if idx < _choices.size():
				get_viewport().set_input_as_handled()
				_pick(_choices[idx]["id"])
				return
	if _choices_shown:
		if event.is_action_pressed("interact"):
			var f: Control = get_viewport().gui_get_focus_owner()
			if f is Button:
				get_viewport().set_input_as_handled()
				(f as Button).pressed.emit()
		return   # buttons handle clicks / Enter themselves
	var advance: bool = false
	if event.is_action_pressed("interact"):
		advance = true
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		advance = true
	if advance:
		get_viewport().set_input_as_handled()   # don't also swing the sword / re-trigger the NPC
		if is_typing:
			_finish_typing()
		else:
			_next_line()

func _next_line() -> void:
	_index += 1
	if _index >= _lines.size():
		_close()
	else:
		_show_line()

func _close() -> void:
	if not is_active:
		return
	is_active = false
	is_typing = false
	_choices_shown = false
	visible = false
	GameManager.pop_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	dialogue_finished.emit()
