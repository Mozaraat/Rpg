# UIKit - shared look & feel for all code-built UI (one place to restyle everything).
class_name UIKit
extends RefCounted

const BG := Color(0.035, 0.045, 0.065, 0.965)
const BG_LIGHT := Color(0.075, 0.09, 0.125, 0.97)
const BG_RAISED := Color(0.11, 0.13, 0.17, 0.98)
const GOLD := Color(0.86, 0.70, 0.39)
const GOLD_BRIGHT := Color(1.0, 0.84, 0.52)
const TEXT := Color(0.94, 0.93, 0.89)
const DIM := Color(0.61, 0.65, 0.71)
const TEAL := Color(0.30, 0.72, 0.72)
const VIOLET := Color(0.62, 0.48, 0.86)
const GOOD := Color(0.50, 0.90, 0.55)
const BAD := Color(1.0, 0.45, 0.40)

static func style(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 8, border_w: int = 0, margin_h: int = 12, margin_v: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin_h
	s.content_margin_right = margin_h
	s.content_margin_top = margin_v
	s.content_margin_bottom = margin_v
	return s

static func panel(bg: Color = BG, border: Color = GOLD, radius: int = 12, border_w: int = 2) -> PanelContainer:
	var p := PanelContainer.new()
	var s: StyleBoxFlat = style(bg, border, radius, border_w, 18, 14)
	s.shadow_color = Color(0, 0, 0, 0.58)
	s.shadow_size = 14
	s.shadow_offset = Vector2(0, 5)
	s.anti_aliasing = true
	s.anti_aliasing_size = 1.0
	p.add_theme_stylebox_override("panel", s)
	return p

static func label(text: String, size: int = 16, color: Color = TEXT, outline: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	l.clip_text = true
	if outline:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		l.add_theme_constant_override("outline_size", 4)
	return l

static func button(text: String, size: int = 16, accent: Color = GOLD) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.add_theme_color_override("font_disabled_color", Color(0.45, 0.46, 0.5))
	b.add_theme_color_override("font_hover_color", GOLD_BRIGHT)
	b.add_theme_stylebox_override("normal", style(Color(0.095, 0.115, 0.15, 0.98), Color(accent.r, accent.g, accent.b, 0.38), 7, 1, 16, 10))
	b.add_theme_stylebox_override("hover", style(Color(0.16, 0.19, 0.24, 1.0), accent, 7, 2, 16, 10))
	b.add_theme_stylebox_override("pressed", style(Color(0.22, 0.19, 0.13, 1.0), accent, 7, 2, 16, 10))
	b.add_theme_stylebox_override("focus", style(Color(0.16, 0.19, 0.24, 1.0), accent, 7, 2, 16, 10))
	b.add_theme_stylebox_override("disabled", style(Color(0.065, 0.075, 0.095), Color(0.18, 0.19, 0.22), 7, 1, 16, 10))
	b.add_theme_constant_override("outline_size", 1)
	b.add_theme_color_override("font_outline_color", Color(0.015, 0.02, 0.03, 0.9))
	b.focus_mode = Control.FOCUS_ALL
	return b

static func bar(fill: Color, height: int = 10) -> ProgressBar:
	var p := ProgressBar.new()
	p.show_percentage = false
	p.max_value = 1.0
	p.custom_minimum_size = Vector2(0, height)
	var bg := style(Color(0.1, 0.1, 0.14), Color(0, 0, 0, 0.5), 4, 1, 0, 0)
	var fg := style(fill, Color(0, 0, 0, 0), 4, 0, 0, 0)
	p.add_theme_stylebox_override("background", bg)
	p.add_theme_stylebox_override("fill", fg)
	return p

## Square item icon: type-coloured tile, grade-coloured border, glyph + stack count.
static func item_icon(inst: Dictionary, size: int = 56) -> Control:
	var root := PanelContainer.new()
	root.custom_minimum_size = Vector2(size, size)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if inst.is_empty():
		root.add_theme_stylebox_override("panel", style(Color(0.1, 0.11, 0.14, 0.9), Color(0.2, 0.21, 0.26), 6, 1, 0, 0))
		return root
	var d: Dictionary = ItemDB.def(inst["id"])
	var base: Color = ItemDB.TYPE_COLORS.get(d.get("type", "material"), Color(0.3, 0.3, 0.3))
	var gcol: Color = ItemDB.grade_color(int(inst.get("grade", 0)))
	var sb: StyleBoxFlat = style(base.darkened(0.25), gcol, 6, 2, 0, 0)
	root.add_theme_stylebox_override("panel", sb)
	var icon_path: String = "res://assets/items/%s.svg" % str(inst.get("id", ""))
	if ResourceLoader.exists(icon_path):
		var art := TextureRect.new()
		art.texture = load(icon_path)
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		art.offset_left = 5.0
		art.offset_top = 5.0
		art.offset_right = -5.0
		art.offset_bottom = -5.0
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(art)
	else:
		var g := label(d.get("glyph", "?"), int(size * 0.36), gcol)
		g.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		g.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		g.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(g)
	if int(inst.get("count", 1)) > 1:
		var c := label(str(inst["count"]), 13, Color.WHITE, true)
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		c.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
		root.add_child(c)
	if ItemDB.is_gear(inst["id"]):
		var mx: float = ItemDB.max_durability(inst)
		if mx > 0.0 and float(inst.get("dur", mx)) < mx:
			var db := ProgressBar.new()
			db.show_percentage = false
			db.max_value = mx
			db.value = float(inst.get("dur", mx))
			db.custom_minimum_size = Vector2(0, 4)
			db.size_flags_vertical = Control.SIZE_SHRINK_END
			db.mouse_filter = Control.MOUSE_FILTER_IGNORE
			db.add_theme_stylebox_override("background", style(Color(0, 0, 0, 0.5), Color(0, 0, 0, 0), 2, 0, 0, 0))
			db.add_theme_stylebox_override("fill", style(Color(0.9, 0.7, 0.2) if db.value / mx > 0.25 else BAD, Color(0, 0, 0, 0), 2, 0, 0, 0))
			root.add_child(db)
	return root

static func clear(node: Node) -> void:
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()
