# GameMenu - one window with tabs: Inventory (I), Skills (K), Quests (J), Titles (T).
extends CanvasLayer
class_name GameMenu

enum Tab { INVENTORY, SKILLS, QUESTS, TITLES, GUILD, JOURNAL, CHARACTER, CULTIVATION }

var is_open: bool = false
var tab: int = Tab.INVENTORY
var skills: SkillSystem = null

var _root: Control
var _window: PanelContainer
var _content: Control
var _tab_nav: GridContainer
var _tab_buttons: Array[Button] = []
var _tab_values: Array[int] = []
var _gold_label: Label
var _dirty: bool = false
var _sel_slot: int = -1
var _sel_equip: String = ""

func _ready() -> void:
	add_to_group("game_menu")
	layer = 8
	visible = false
	_build()
	get_viewport().size_changed.connect(_apply_responsive_layout)
	_apply_responsive_layout()
	PlayerData.inventory_changed.connect(_mark_dirty)
	PlayerData.equipment_changed.connect(_mark_dirty)
	PlayerData.quests_changed.connect(_mark_dirty)
	PlayerData.title_changed.connect(_mark_dirty)
	PlayerData.gold_changed.connect(func(g: int) -> void: _gold_label.text = "%d gold" % g)
	GuildSystem.guild_changed.connect(func(_g: Dictionary) -> void: _mark_dirty())
	GuildSystem.membership_changed.connect(func(_id: String, _role: String) -> void: _mark_dirty())
	PartySystem.party_changed.connect(func(_p: Dictionary) -> void: _mark_dirty())
	_gold_label.text = "%d gold" % PlayerData.gold

func set_skill_system(s: SkillSystem) -> void:
	skills = s
	s.skill_changed.connect(func(_i: String, _v: float, _d: float) -> void: _mark_dirty())

func _mark_dirty() -> void:
	_dirty = true

func _build() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)

	var dim := ColorRect.new()
	dim.color = Color(0.015, 0.02, 0.035, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)

	_window = UIKit.panel(Color(0.055, 0.065, 0.09, 0.985), Color(0.72, 0.57, 0.29, 0.95), 14, 2)
	_window.set_anchors_preset(Control.PRESET_CENTER)
	_window.anchor_left = 0.5
	_window.anchor_right = 0.5
	_window.anchor_top = 0.5
	_window.anchor_bottom = 0.5
	_root.add_child(_window)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 9)
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_window.add_child(vb)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	vb.add_child(head)
	var heading_col := VBoxContainer.new()
	heading_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading_col.add_theme_constant_override("separation", 1)
	head.add_child(heading_col)
	var heading := UIKit.label("ADVENTURER'S CHRONICLE", 20, UIKit.GOLD)
	heading_col.add_child(heading)
	var subtitle := UIKit.label("Character, discoveries and progression", 11, UIKit.DIM)
	heading_col.add_child(subtitle)
	_gold_label = UIKit.label("0 gold", 16, UIKit.GOLD)
	_gold_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	head.add_child(_gold_label)
	var close: Button = UIKit.button("Close  ×", 14, UIKit.BAD)
	close.custom_minimum_size = Vector2(82, 36)
	close.pressed.connect(close_menu)
	head.add_child(close)

	_tab_nav = GridContainer.new()
	_tab_nav.columns = 4
	_tab_nav.add_theme_constant_override("h_separation", 7)
	_tab_nav.add_theme_constant_override("v_separation", 5)
	_tab_nav.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(_tab_nav)
	var cultivation_tab_name: String = "Cultivation" if CultivationDiscovery.is_cultivation_unlocked() else "Discoveries"
	var names: Array[String] = ["Inventory · I", "Character", "Skills · K", cultivation_tab_name, "Quests · J", "Titles · T", "Guild / Party · G", "Field Journal · L"]
	_tab_values = [Tab.INVENTORY, Tab.CHARACTER, Tab.SKILLS, Tab.CULTIVATION, Tab.QUESTS, Tab.TITLES, Tab.GUILD, Tab.JOURNAL]
	for i in range(names.size()):
		var b: Button = UIKit.button(names[i], 14)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(0, 35)
		var idx: int = _tab_values[i]
		b.pressed.connect(func() -> void: open_tab(idx))
		_tab_nav.add_child(b)
		_tab_buttons.append(b)

	_content = Control.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_content.custom_minimum_size = Vector2.ZERO
	vb.add_child(_content)

func _apply_responsive_layout() -> void:
	if _window == null or not is_instance_valid(_window):
		return
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var window_width: float = clampf(viewport_size.x - 28.0, 320.0, 1120.0)
	var window_height: float = clampf(viewport_size.y - 28.0, 320.0, 720.0)
	_window.offset_left = -window_width * 0.5
	_window.offset_right = window_width * 0.5
	_window.offset_top = -window_height * 0.5
	_window.offset_bottom = window_height * 0.5
	_window.custom_minimum_size = Vector2(window_width, window_height)
	if _content:
		_content.custom_minimum_size = Vector2.ZERO
	if _tab_nav:
		_tab_nav.columns = 2 if window_width < 700.0 else 4
	for button in _tab_buttons:
		button.add_theme_font_size_override("font_size", 12 if window_width < 700.0 else 14)
	if is_open:
		_dirty = true
	if window_width < 700.0:
		for button in _tab_buttons:
			button.custom_minimum_size.y = 32.0
	else:
		for button in _tab_buttons:
			button.custom_minimum_size.y = 35.0

func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var key: int = event.keycode
	var map: Dictionary = {KEY_I: Tab.INVENTORY, KEY_K: Tab.SKILLS, KEY_J: Tab.QUESTS, KEY_T: Tab.TITLES, KEY_G: Tab.GUILD, KEY_L: Tab.JOURNAL}
	if key == KEY_ESCAPE and is_open:
		get_viewport().set_input_as_handled()
		close_menu()
		return
	if map.has(key):
		if GameManager.current_state == GameManager.GameState.DEAD:
			return
		if is_open:
			get_viewport().set_input_as_handled()
			if tab == map[key]:
				close_menu()
			else:
				open_tab(map[key])
		elif not GameManager.input_locked:
			get_viewport().set_input_as_handled()
			open_tab(map[key])

func open_tab(t: int) -> void:
	tab = t
	if not is_open:
		is_open = true
		visible = true
		GameManager.push_ui_lock()
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()

func close_menu() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	GameManager.pop_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _process(_d: float) -> void:
	if _dirty and is_open:
		_dirty = false
		_refresh()

func _refresh() -> void:
	for i in range(_tab_buttons.size()):
		var selected: bool = _tab_values[i] == tab
		var button: Button = _tab_buttons[i]
		button.add_theme_stylebox_override("normal", UIKit.style(Color(0.24, 0.20, 0.12, 0.98) if selected else Color(0.12, 0.14, 0.19, 0.96), UIKit.GOLD if selected else Color(0.27, 0.30, 0.38), 7, 2 if selected else 1, 10, 7))
		button.add_theme_stylebox_override("hover", UIKit.style(Color(0.24, 0.25, 0.32), UIKit.GOLD, 7, 2, 10, 7))
		button.add_theme_color_override("font_color", UIKit.GOLD if selected else UIKit.TEXT)
	UIKit.clear(_content)
	match tab:
		Tab.INVENTORY: _build_inventory()
		Tab.SKILLS: _build_skills()
		Tab.QUESTS: _build_quests()
		Tab.TITLES: _build_titles()
		Tab.GUILD: _build_guild()
		Tab.JOURNAL: _build_field_journal()
		Tab.CHARACTER: _build_character()
		Tab.CULTIVATION: _build_cultivation()

func _scroll(parent: Control, min_w: float = 0.0) -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.custom_minimum_size = Vector2(min_w, 0.0)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	parent.add_child(sc)
	if not (parent is BoxContainer):
		sc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 9)
	sc.add_child(vb)
	return vb

func _section(parent: Control, heading: String, accent: Color = UIKit.GOLD) -> VBoxContainer:
	var card: PanelContainer = UIKit.panel(Color(0.105, 0.12, 0.16, 0.97), Color(accent.r, accent.g, accent.b, 0.52), 9, 1)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(card)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 7)
	card.add_child(body)
	if heading != "":
		var title: Label = UIKit.label(heading.to_upper(), 13, accent)
		body.add_child(title)
	return body

func _wrapped_label(value: String, size: int = 14, color: Color = UIKit.DIM) -> Label:
	var result: Label = UIKit.label(value, size, color)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result.custom_minimum_size.x = 0.0
	result.clip_text = false
	return result

func _value_row(parent: Control, key_text: String, value_text: String, value_color: Color = UIKit.TEXT) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(row)
	var key_label: Label = UIKit.label(key_text, 13, UIKit.DIM)
	key_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	key_label.size_flags_stretch_ratio = 1.0
	row.add_child(key_label)
	var value_label: Label = UIKit.label(value_text, 13, value_color)
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	value_label.size_flags_stretch_ratio = 1.0
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	value_label.custom_minimum_size.x = 0.0
	row.add_child(value_label)

func _stat_tile(parent: Control, heading: String, value: String, accent: Color = UIKit.GOLD) -> void:
	var tile: PanelContainer = UIKit.panel(Color(0.10, 0.115, 0.15, 0.98), Color(0.28, 0.31, 0.39, 0.9), 8, 1)
	tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(tile)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 2)
	tile.add_child(body)
	body.add_child(UIKit.label(heading.to_upper(), 10, UIKit.DIM))
	var value_label: Label = _wrapped_label(value, 16, accent)
	body.add_child(value_label)

# ---------------------------------------------------------------------------
# Inventory
# ---------------------------------------------------------------------------
func _build_inventory() -> void:
	var viewport_width: float = get_viewport().get_visible_rect().size.x
	var compact: bool = viewport_width < 850.0
	var hb: BoxContainer = VBoxContainer.new() if compact else HBoxContainer.new()
	hb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hb.add_theme_constant_override("separation", 10)
	_content.add_child(hb)

	var left_outer: PanelContainer = UIKit.panel(Color(0.085, 0.10, 0.135, 0.98), Color(0.30, 0.34, 0.42), 10, 1)
	left_outer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left_outer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hb.add_child(left_outer)
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 8)
	left_outer.add_child(left)
	var used_slots: int = PlayerData.SLOT_COUNT - PlayerData.free_slots()
	left.add_child(UIKit.label("BACKPACK  ·  %d / %d SLOTS" % [used_slots, PlayerData.SLOT_COUNT], 14, UIKit.GOLD))
	var grid := GridContainer.new()
	var desired_columns: int = clampi(int((viewport_width - 150.0) / 72.0), 3, 7)
	grid.columns = desired_columns
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(grid)
	for i in range(PlayerData.SLOT_COUNT):
		var it: Dictionary = PlayerData.item_at(i)
		var b := Button.new()
		b.custom_minimum_size = Vector2(62, 62)
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		b.flat = true
		b.focus_mode = Control.FOCUS_NONE
		var icon: Control = UIKit.item_icon(it, 62)
		icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		b.add_child(icon)
		if i == _sel_slot:
			var ring := Panel.new()
			ring.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
			ring.add_theme_stylebox_override("panel", UIKit.style(Color(1, 1, 1, 0.08), Color(1, 0.82, 0.42, 0.98), 6, 2, 0, 0))
			b.add_child(ring)
		var idx: int = i
		b.pressed.connect(func() -> void:
			_sel_slot = idx
			_sel_equip = ""
			_refresh())
		b.gui_input.connect(func(ev: InputEvent) -> void:
			if ev is InputEventMouseButton and ev.pressed and ev.double_click and ev.button_index == MOUSE_BUTTON_LEFT:
				_quick_action(idx))
		grid.add_child(b)

	var right_outer: PanelContainer = UIKit.panel(Color(0.085, 0.10, 0.135, 0.98), Color(0.30, 0.34, 0.42), 10, 1)
	right_outer.custom_minimum_size.x = 0.0 if compact else clampf(viewport_width * 0.28, 270.0, 330.0)
	right_outer.size_flags_horizontal = Control.SIZE_EXPAND_FILL if compact else Control.SIZE_SHRINK_END
	right_outer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hb.add_child(right_outer)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 9)
	right_outer.add_child(right)
	right.add_child(UIKit.label("EQUIPMENT", 14, UIKit.GOLD))
	var eq := HBoxContainer.new()
	eq.add_theme_constant_override("separation", 14)
	right.add_child(eq)
	for slot in ["weapon", "armor"]:
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		eq.add_child(col)
		col.add_child(UIKit.label(slot.capitalize(), 12, UIKit.DIM))
		var eb := Button.new()
		eb.custom_minimum_size = Vector2(68, 68)
		eb.flat = true
		eb.focus_mode = Control.FOCUS_NONE
		var ic: Control = UIKit.item_icon(PlayerData.equipment[slot], 68)
		ic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		eb.add_child(ic)
		if _sel_equip == slot:
			var ring2 := Panel.new()
			ring2.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			ring2.mouse_filter = Control.MOUSE_FILTER_IGNORE
			ring2.add_theme_stylebox_override("panel", UIKit.style(Color(1, 1, 1, 0.08), Color(1, 0.82, 0.42, 0.98), 6, 2, 0, 0))
			eb.add_child(ring2)
		var sl: String = slot
		eb.pressed.connect(func() -> void:
			_sel_equip = sl
			_sel_slot = -1
			_refresh())
		col.add_child(eb)
		var nm: Dictionary = PlayerData.equipment[slot]
		var info: Label = _wrapped_label(ItemDB.display_name(nm) if not nm.is_empty() else "(empty)", 12, ItemDB.grade_color(int(nm.get("grade", 0))) if not nm.is_empty() else UIKit.DIM)
		col.add_child(info)

	right.add_child(HSeparator.new())
	var sel: Dictionary = {}
	if _sel_slot >= 0:
		sel = PlayerData.item_at(_sel_slot)
	elif _sel_equip != "":
		sel = PlayerData.equipment[_sel_equip]
	if sel.is_empty():
		right.add_child(UIKit.label("ITEM DETAILS", 13, UIKit.GOLD))
		right.add_child(_wrapped_label("Select an item to view its properties. Double-click a weapon, armour piece or consumable for a quick action.", 13, UIKit.DIM))
	else:
		var gname: String = ItemDB.grade_info(int(sel.get("grade", 0)))["name"]
		right.add_child(_wrapped_label(ItemDB.display_name(sel), 18, ItemDB.grade_color(int(sel.get("grade", 0)))))
		right.add_child(_wrapped_label("%s  ·  %s" % [ItemDB.def(sel["id"]).get("type", "").capitalize(), gname], 12, UIKit.DIM))
		right.add_child(_wrapped_label(ItemDB.tooltip(sel), 13, UIKit.TEXT))
		var btns := HBoxContainer.new()
		btns.add_theme_constant_override("separation", 7)
		right.add_child(btns)
		var item_type: String = ItemDB.def(sel["id"]).get("type", "")
		if _sel_equip != "":
			var ub: Button = UIKit.button("Unequip", 13)
			var selected_slot: String = _sel_equip
			ub.pressed.connect(func() -> void:
				PlayerData.unequip(selected_slot)
				_sel_equip = "")
			btns.add_child(ub)
		else:
			if item_type == "weapon" or item_type == "armor":
				var eb2: Button = UIKit.button("Equip", 13)
				eb2.pressed.connect(func() -> void: PlayerData.equip_from_slot(_sel_slot))
				btns.add_child(eb2)
			elif item_type == "consumable":
				var use: Button = UIKit.button("Use", 13)
				use.pressed.connect(func() -> void: PlayerData.use_item(_sel_slot))
				btns.add_child(use)
			var dis: Button = UIKit.button("Discard", 13, UIKit.BAD)
			dis.pressed.connect(func() -> void:
				PlayerData.discard_slot(_sel_slot)
				_sel_slot = -1)
			btns.add_child(dis)

func _quick_action(i: int) -> void:
	var it: Dictionary = PlayerData.item_at(i)
	if it.is_empty():
		return
	var t: String = ItemDB.def(it["id"]).get("type", "")
	if t == "weapon" or t == "armor":
		PlayerData.equip_from_slot(i)
	elif t == "consumable":
		PlayerData.use_item(i)

# ---------------------------------------------------------------------------
# Guild and temporary party management (local foundation; online invitations later)
func _build_guild() -> void:
	var layout := HBoxContainer.new()
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layout.add_theme_constant_override("separation", 20)
	_content.add_child(layout)
	var guild_col := VBoxContainer.new()
	guild_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	guild_col.add_theme_constant_override("separation", 10)
	layout.add_child(guild_col)
	guild_col.add_child(UIKit.label("GUILDS", 22, UIKit.GOLD))
	var current: Dictionary = GuildSystem.current_guild()
	if current.is_empty():
		guild_col.add_child(UIKit.label("You are not currently in a guild.", 16, UIKit.DIM))
		var name_input := LineEdit.new()
		name_input.placeholder_text = "Guild name (3–24 characters)"
		guild_col.add_child(name_input)
		var desc_input := LineEdit.new()
		desc_input.placeholder_text = "Guild description (optional)"
		guild_col.add_child(desc_input)
		var create_btn := UIKit.button("Create Guild", 16)
		create_btn.pressed.connect(func() -> void:
			if GuildSystem.create_guild(name_input.text, desc_input.text):
				_refresh()
			else:
				EventBus.toast.emit("Guild name invalid or joining cooldown active", "warning"))
		guild_col.add_child(create_btn)
		if GuildSystem.is_join_locked():
			guild_col.add_child(UIKit.label("Guild joining locked: %d days %02d:%02d remaining" % [int(GuildSystem.cooldown_remaining_seconds() / 86400), int((GuildSystem.cooldown_remaining_seconds() % 86400) / 3600), int((GuildSystem.cooldown_remaining_seconds() % 3600) / 60)], 14, UIKit.BAD))
		else:
			guild_col.add_child(UIKit.label("Guild joining is available.", 14, UIKit.GOOD))
		var browse := UIKit.label("AVAILABLE GUILDS", 15, UIKit.GOLD)
		guild_col.add_child(browse)
		for gid in GuildSystem.guilds.keys():
			var g: Dictionary = GuildSystem.guilds[gid]
			var row := HBoxContainer.new()
			row.add_child(UIKit.label("%s  ·  Lv.%d  ·  %d members" % [str(g.get("name", "Guild")), int(g.get("level", 1)), g.get("members", {}).size()], 14))
			var req := UIKit.button("Request to Join", 13)
			var target_id: String = str(gid)
			req.disabled = GuildSystem.is_join_locked()
			req.pressed.connect(func() -> void:
				GuildSystem.request_to_join(target_id)
				EventBus.toast.emit("Guild application sent", "info"))
			row.add_child(req)
			guild_col.add_child(row)
	else:
		guild_col.add_child(UIKit.label("%s %s" % [str(current.get("emblem", "⚔")), str(current.get("name", "Guild"))], 22, UIKit.GOOD))
		guild_col.add_child(UIKit.label("Level %d   ·   Renown %d" % [int(current.get("level", 1)), int(current.get("renown", 0))], 15, UIKit.DIM))
		guild_col.add_child(UIKit.label(str(current.get("description", "")), 14, UIKit.DIM))
		guild_col.add_child(UIKit.label("MEMBERS (%d/50)" % current.get("members", {}).size(), 15, UIKit.GOLD))
		for member_name in current.get("members", {}).keys():
			var m: Dictionary = current.members[member_name]
			guild_col.add_child(UIKit.label("%s  —  %s" % [str(member_name), str(m.get("role", "member")).capitalize()], 15))
		if not current.get("requests", []).is_empty():
			guild_col.add_child(UIKit.label("JOIN REQUESTS", 15, UIKit.GOLD))
			for applicant in current.get("requests", []):
				var request_row := HBoxContainer.new()
				request_row.add_child(UIKit.label(str(applicant), 14))
				var accept := UIKit.button("Accept", 13)
				var applicant_name: String = str(applicant)
				var guild_id: String = str(current.get("id", ""))
				accept.pressed.connect(func() -> void:
					GuildSystem.accept_member(guild_id, applicant_name)
					_refresh())
				request_row.add_child(accept)
				guild_col.add_child(request_row)
		var leave := UIKit.button("Leave Guild (7-day joining cooldown)", 14, UIKit.BAD)
		leave.pressed.connect(func() -> void:
			GuildSystem.leave_guild()
			_refresh())
		guild_col.add_child(leave)
	# Independent regional commissions are available regardless of guild membership.
	guild_col.add_child(UIKit.label("REGIONAL GUILD COMMISSIONS · DAILY ROTATION", 16, UIKit.GOLD))
	var contract_region := "elyndor_heartlands"
	guild_col.add_child(UIKit.label("Elyndor Heartlands · %s reputation (%d)" % [GuildContracts.regional_rank(contract_region), GuildContracts.regional_reputation(contract_region)], 13, UIKit.DIM))
	for commission in GuildContracts.get_contracts(contract_region):
		var commission_row := HBoxContainer.new()
		commission_row.add_child(UIKit.label("%s · %d/%d · Tier %d" % [str(commission.title), int(commission.progress), int(commission.target), int(commission.tier)], 13))
		var commission_id := str(commission.id)
		var take := UIKit.button("Accept" if str(commission.status) == "available" else str(commission.status).capitalize(), 12)
		take.disabled = str(commission.status) != "available"
		take.pressed.connect(func() -> void:
			if GuildContracts.accept_contract(commission_id):
				_refresh())
		commission_row.add_child(take)
		guild_col.add_child(commission_row)
	var party_col := VBoxContainer.new()
	party_col.custom_minimum_size.x = 400
	party_col.add_theme_constant_override("separation", 10)
	layout.add_child(party_col)
	party_col.add_child(UIKit.label("HUNTING PARTY", 22, UIKit.GOLD))
	var party: Dictionary = PartySystem.get_snapshot()
	if not bool(party.get("active", false)):
		party_col.add_child(UIKit.label("Create a temporary party for dungeon hunting. Guild membership is not required.", 14, UIKit.DIM))
		var make_party := UIKit.button("Create Party", 16)
		make_party.pressed.connect(func() -> void:
			PartySystem.create_party()
			_refresh())
		party_col.add_child(make_party)
	else:
		party_col.add_child(UIKit.label("Party: %s" % str(party.get("party_id", "")), 14, UIKit.GOOD))
		for member in party.get("members", []):
			party_col.add_child(UIKit.label("%s — %s%s" % [str(member.get("name", "Adventurer")), str(member.get("role", "member")).capitalize(), " (Ready)" if bool(member.get("ready", false)) else ""], 14))
		var invite_id := LineEdit.new()
		invite_id.placeholder_text = "Future player ID"
		party_col.add_child(invite_id)
		var invite_name := LineEdit.new()
		invite_name.placeholder_text = "Adventurer name"
		party_col.add_child(invite_name)
		var invite := UIKit.button("Add Local Test Member", 14)
		invite.pressed.connect(func() -> void:
			if PartySystem.invite_local_member(invite_id.text, invite_name.text):
				_refresh())
		party_col.add_child(invite)
		var target := LineEdit.new()
		target.placeholder_text = "Hunt target / rare monster"
		target.text = str(party.get("hunting_target", ""))
		party_col.add_child(target)
		var set_target := UIKit.button("Set Hunting Target", 14)
		set_target.pressed.connect(func() -> void: PartySystem.set_hunting_target(target.text))
		party_col.add_child(set_target)
		var disband := UIKit.button("Disband Party", 14, UIKit.BAD)
		disband.pressed.connect(func() -> void:
			PartySystem.disband_party()
			_refresh())
		party_col.add_child(disband)
	party_col.add_child(UIKit.label("Online invites and peer synchronization will be enabled when networking is added.", 12, UIKit.DIM))

# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------
func _build_skills() -> void:
	if skills == null:
		_content.add_child(_wrapped_label("Skill data is not available yet.", 16, UIKit.DIM))
		return
	var viewport_width: float = get_viewport().get_visible_rect().size.x
	var compact: bool = viewport_width < 900.0
	var layout: BoxContainer = VBoxContainer.new() if compact else HBoxContainer.new()
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layout.add_theme_constant_override("separation", 10)
	_content.add_child(layout)

	var list: VBoxContainer = _scroll(layout)
	var list_scroll: ScrollContainer = list.get_parent() as ScrollContainer
	list_scroll.size_flags_stretch_ratio = 1.65 if not compact else 1.0
	list.add_child(_wrapped_label("Skills improve through real use. Your character develops according to the actions you practise.", 13, UIKit.DIM))
	for cat in SkillSystem.CATEGORY_ORDER:
		var section: VBoxContainer = _section(list, str(cat))
		for id in SkillSystem.SKILLS.keys():
			if SkillSystem.SKILLS[id]["cat"] != cat:
				continue
			var is_known: bool = skills.is_skill_discovered(str(id))
			var row := VBoxContainer.new()
			row.add_theme_constant_override("separation", 3)
			section.add_child(row)
			var top := HBoxContainer.new()
			top.add_theme_constant_override("separation", 8)
			row.add_child(top)
			var display_name: String = str(SkillSystem.SKILLS[id]["name"]) if is_known else "Unknown discipline"
			var name_label: Label = UIKit.label(display_name, 14, UIKit.TEXT if is_known else UIKit.DIM)
			name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			name_label.tooltip_text = str(SkillSystem.SKILLS[id].get("desc", "")) if is_known else "Discover this discipline through practice or instruction."
			top.add_child(name_label)
			top.add_child(UIKit.label(skills.get_rank_name(str(id)) if is_known else "Undiscovered", 11, UIKit.DIM))
			top.add_child(UIKit.label("%.1f" % skills.get_value(str(id)) if is_known else "—", 13, Color(1.0, 0.88, 0.5)))
			var pb: ProgressBar = UIKit.bar(Color(0.35, 0.62, 0.95), 6)
			pb.value = skills.rank_progress(str(id)) if is_known else 0.0
			row.add_child(pb)

	var side: VBoxContainer = _scroll(layout)
	var side_scroll: ScrollContainer = side.get_parent() as ScrollContainer
	side_scroll.size_flags_stretch_ratio = 1.0
	side.add_child(_wrapped_label("Your profession emerges from the skills you have trained most often.", 12, UIKit.DIM))
	var prof_section: VBoxContainer = _section(side, "Professions")
	var profession_names: Array = SkillSystem.PROFESSIONS.keys()
	profession_names.sort_custom(func(a: Variant, b: Variant) -> bool: return skills.profession_value(str(a)) > skills.profession_value(str(b)))
	for prof in profession_names:
		var value: float = skills.profession_value(str(prof))
		var r := VBoxContainer.new()
		r.add_theme_constant_override("separation", 2)
		prof_section.add_child(r)
		var t := HBoxContainer.new()
		r.add_child(t)
		var pn: Label = UIKit.label(str(prof), 13)
		pn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		t.add_child(pn)
		t.add_child(UIKit.label("%.1f" % value, 12, Color(1.0, 0.88, 0.5)))
		var pbar: ProgressBar = UIKit.bar(Color(0.85, 0.62, 0.25), 5)
		pbar.value = clampf(value / 50.0, 0.0, 1.0)
		r.add_child(pbar)

	var trait_section: VBoxContainer = _section(side, "Mastered traits", Color(0.55, 0.86, 0.72))
	var has_traits: bool = false
	for trait_id in SkillSystem.TRAITS.keys():
		if skills.has_trait(str(trait_id)):
			has_traits = true
			var trait_data: Dictionary = SkillSystem.TRAITS[trait_id]
			trait_section.add_child(UIKit.label(str(trait_data.name), 13, Color(0.55, 0.86, 0.72)))
			trait_section.add_child(_wrapped_label(str(trait_data.desc), 11, UIKit.DIM))
	if not has_traits:
		trait_section.add_child(_wrapped_label("Traits emerge when a related skill reaches mastery milestones. Practise the style you enjoy to shape your character.", 12, UIKit.DIM))

	var technique_section: VBoxContainer = _section(side, "Discovered techniques")
	var known_techniques: Array = skills.discovered_techniques.keys()
	known_techniques.sort()
	if known_techniques.is_empty():
		technique_section.add_child(_wrapped_label("No combat techniques discovered yet. Explore, study manuals and learn from skilled NPCs.", 12, UIKit.DIM))
	else:
		for technique_id in known_techniques:
			var technique_name: String = str(SkillSystem.TECHNIQUE_NAMES.get(str(technique_id), str(technique_id).replace("_", " ").capitalize()))
			var req: Dictionary = SkillSystem.TECHNIQUE_REQUIREMENTS.get(str(technique_id), {})
			var practice_count: int = skills.technique_practice_count(str(technique_id))
			technique_section.add_child(UIKit.label(technique_name, 13, Color(1.0, 0.86, 0.55)))
			technique_section.add_child(_wrapped_label("%s  ·  %d successful executions" % [str(req.get("description", "Learned technique")), practice_count], 11, UIKit.DIM))
	technique_section.add_child(UIKit.label("Knowledge: %d / %d" % [known_techniques.size(), SkillSystem.TECHNIQUE_REQUIREMENTS.size()], 11, UIKit.DIM))

# ---------------------------------------------------------------------------
# Quests
# ---------------------------------------------------------------------------
func _build_quests() -> void:
	var list: VBoxContainer = _scroll(_content)
	var active: Array = PlayerData.active_quest_ids()
	var completed: Array[String] = []
	for quest_id in PlayerData.quests.keys():
		if str(PlayerData.quests[quest_id].get("state", "")) == "done":
			completed.append(str(quest_id))
	var summary: PanelContainer = UIKit.panel(Color(0.11, 0.13, 0.17, 0.98), Color(0.42, 0.45, 0.52), 9, 1)
	list.add_child(summary)
	var summary_row := HBoxContainer.new()
	summary_row.add_theme_constant_override("separation", 20)
	summary.add_child(summary_row)
	var active_tile := VBoxContainer.new()
	active_tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	summary_row.add_child(active_tile)
	active_tile.add_child(UIKit.label("ACTIVE QUESTS", 10, UIKit.DIM))
	active_tile.add_child(UIKit.label(str(active.size()), 20, UIKit.GOLD))
	var completed_tile := VBoxContainer.new()
	completed_tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	summary_row.add_child(completed_tile)
	completed_tile.add_child(UIKit.label("COMPLETED", 10, UIKit.DIM))
	completed_tile.add_child(UIKit.label(str(completed.size()), 20, UIKit.GOOD))
	list.add_child(UIKit.label("QUEST LOG", 14, UIKit.GOLD))
	if active.is_empty():
		list.add_child(_wrapped_label("No active quests. Talk to villagers and look for a yellow ! above someone who needs help.", 14, UIKit.DIM))
	else:
		for id in active:
			list.add_child(_quest_card(str(id), false))
	if not completed.is_empty():
		list.add_child(UIKit.label("COMPLETED QUESTS", 14, UIKit.GOLD))
		for id in completed:
			list.add_child(_quest_card(id, true))

func _quest_card(id: String, done: bool) -> Control:
	var q: Dictionary = QuestDB.QUESTS.get(id, {})
	if q.is_empty():
		return Control.new()
	var accent: Color = Color(0.34, 0.38, 0.46) if done else UIKit.GOLD
	var p: PanelContainer = UIKit.panel(Color(0.105, 0.12, 0.16, 0.98), accent, 10, 1)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 5)
	p.add_child(vb)
	var ready: bool = PlayerData.is_ready(id)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	vb.add_child(head)
	var tl: Label = UIKit.label(str(q.get("title", "Quest")), 16, UIKit.DIM if done else (UIKit.GOOD if ready else UIKit.TEXT))
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	head.add_child(tl)
	var status_text: String = "Completed" if done else ("Return to %s" % str(q.get("turn_in", "quest giver")) if ready else "From %s" % str(q.get("giver", "unknown")))
	var status: Label = _wrapped_label(status_text, 11, UIKit.DIM)
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	status.custom_minimum_size.x = 100.0
	head.add_child(status)
	if not done:
		vb.add_child(_wrapped_label(str(q.get("summary", "")), 13, UIKit.DIM))
		var objectives: Array = q.get("objectives", [])
		for i in range(objectives.size()):
			var prog: int = PlayerData.objective_progress(id, i)
			var need: int = int(objectives[i].get("count", 1))
			var objective_text: String = str(objectives[i].get("text", "Objective"))
			vb.add_child(_wrapped_label("%s  ·  %d / %d" % [objective_text, prog, need], 12, UIKit.GOOD if prog >= need else UIKit.TEXT))
		vb.add_child(_wrapped_label("Reward: " + _reward_text(q.get("rewards", {})), 11, UIKit.GOLD))
	return p

static func _reward_text(r: Dictionary) -> String:
	var parts: Array[String] = []
	if r.get("gold", 0) > 0:
		parts.append("%d gold" % int(r["gold"]))
	for it in r.get("items", []):
		parts.append("%s%s" % [ItemDB.display_name(ItemDB.make(it["id"], 1, int(it.get("grade", 0)))), (" x%d" % int(it["count"])) if int(it.get("count", 1)) > 1 else ""])
	for sid in r.get("skills", {}).keys():
		parts.append("%s +%.1f" % [SkillSystem.SKILLS[sid]["name"], float(r["skills"][sid])])
	if r.has("title"):
		parts.append("Title: %s" % r["title"])
	return ", ".join(parts)


# ---------------------------------------------------------------------------
# Character sheet
# ---------------------------------------------------------------------------
func _build_character() -> void:
	if skills == null:
		_content.add_child(_wrapped_label("Character progression data is not available yet.", 15, UIKit.DIM))
		return
	var list: VBoxContainer = _scroll(_content)
	list.add_child(UIKit.label("CHARACTER PROFILE", 17, UIKit.GOLD))
	list.add_child(_wrapped_label("A record of the adventurer you have shaped through combat, exploration, crafting and cultivation.", 12, UIKit.DIM))

	var overview := GridContainer.new()
	overview.columns = 3 if get_viewport().get_visible_rect().size.x >= 850.0 else 2
	overview.add_theme_constant_override("h_separation", 8)
	overview.add_theme_constant_override("v_separation", 8)
	list.add_child(overview)
	if CultivationDiscovery.is_cultivation_unlocked():
		_stat_tile(overview, "Cultivation realm", skills.cultivation_realm_name(), Color(0.82, 0.72, 1.0))
		_stat_tile(overview, "Spiritual root", str(skills.cultivation_state.get("spiritual_root", "Unawakened")), Color(0.82, 0.72, 1.0))
		_stat_tile(overview, "Active path", skills.active_cultivation_path_name(), Color(0.82, 0.72, 1.0))
	else:
		_stat_tile(overview, "Current standing", "Mortal", UIKit.TEXT)
		_stat_tile(overview, "Hidden arts", "Not discovered", UIKit.DIM)
		_stat_tile(overview, "Cultivation path", "None", UIKit.DIM)
	_stat_tile(overview, "Equipped title", PlayerData.active_title if PlayerData.active_title != "" else "None", UIKit.GOLD)
	_stat_tile(overview, "Gold", "%d" % PlayerData.gold, UIKit.GOLD)
	var lifespan := skills.lifespan_years()
	_stat_tile(overview, "Natural lifespan", "Ageless" if is_inf(lifespan) else "%.0f years" % lifespan, UIKit.TEXT)
	_stat_tile(overview, "Regions discovered", str(PlayerData.zones.size()), UIKit.GOOD)

	var combat: VBoxContainer = _section(list, "Combat ratings", Color(0.88, 0.68, 0.38))
	var combat_grid := GridContainer.new()
	combat_grid.columns = 3 if get_viewport().get_visible_rect().size.x >= 850.0 else 2
	combat_grid.add_theme_constant_override("h_separation", 8)
	combat_grid.add_theme_constant_override("v_separation", 5)
	combat.add_child(combat_grid)
	_stat_tile(combat_grid, "Maximum health", "%d" % int(skills.max_health()), Color(1.0, 0.48, 0.48))
	_stat_tile(combat_grid, "Weapon damage", "%.1f" % PlayerData.weapon_damage(), UIKit.TEXT)
	_stat_tile(combat_grid, "Damage bonus", "+%d%%" % int((skills.damage_mult() - 1.0) * 100.0), UIKit.GOOD)
	_stat_tile(combat_grid, "Critical chance", "%d%%" % int(skills.crit_chance() * 100.0), UIKit.GOLD)
	_stat_tile(combat_grid, "Evasion mastery", "%.1f" % skills.get_value("evasion"), UIKit.TEXT)
	_stat_tile(combat_grid, "Armour", "%.1f" % PlayerData.armor_value(), UIKit.TEXT)
	_stat_tile(combat_grid, "Movement bonus", "+%d%%" % int((skills.speed_mult() - 1.0) * 100.0), UIKit.GOOD)

	var attributes: VBoxContainer = _section(list, "Attributes", Color(0.55, 0.78, 0.95))
	var attribute_grid := GridContainer.new()
	attribute_grid.columns = 3 if get_viewport().get_visible_rect().size.x >= 850.0 else 2
	attribute_grid.add_theme_constant_override("h_separation", 8)
	attribute_grid.add_theme_constant_override("v_separation", 6)
	attributes.add_child(attribute_grid)
	var attribute_values: Dictionary = skills.attribute_summary()
	for attribute_name in attribute_values.keys():
		_stat_tile(attribute_grid, str(attribute_name), "%.1f" % float(attribute_values[attribute_name]), Color(0.78, 0.88, 1.0))

	var gear: VBoxContainer = _section(list, "Equipped gear")
	var weapon_item: Dictionary = PlayerData.equipment.get("weapon", {})
	var armour_item: Dictionary = PlayerData.equipment.get("armor", {})
	_value_row(gear, "Weapon", ItemDB.display_name(weapon_item) if not weapon_item.is_empty() else "None")
	_value_row(gear, "Armour", ItemDB.display_name(armour_item) if not armour_item.is_empty() else "None")
	_value_row(gear, "Enemies defeated", str(int(PlayerData.stats.get("kills", 0))))
	_value_row(gear, "Items crafted", str(int(PlayerData.stats.get("crafted", 0))))
	_value_row(gear, "Resources gathered", str(int(PlayerData.stats.get("gathered", 0))))

	var traits: VBoxContainer = _section(list, "Mastered traits", Color(0.55, 0.86, 0.72))
	var trait_count: int = 0
	for trait_id in SkillSystem.TRAITS.keys():
		if skills.has_trait(str(trait_id)):
			trait_count += 1
			var trait_data: Dictionary = SkillSystem.TRAITS[trait_id]
			traits.add_child(UIKit.label(str(trait_data.name), 13, Color(0.55, 0.86, 0.72)))
			traits.add_child(_wrapped_label(str(trait_data.desc), 11, UIKit.DIM))
	if trait_count == 0:
		traits.add_child(_wrapped_label("No mastery traits unlocked yet. Traits emerge as your practical skills grow.", 12, UIKit.DIM))

# ---------------------------------------------------------------------------
# Cultivation and Dao paths
# ---------------------------------------------------------------------------
func _build_cultivation() -> void:
	if skills == null:
		_content.add_child(_wrapped_label("Cultivation data is not available yet.", 15, UIKit.DIM))
		return
	var list: VBoxContainer = _scroll(_content)
	if not CultivationDiscovery.is_cultivation_unlocked():
		var report: Dictionary = CultivationDiscovery.get_report()
		list.add_child(UIKit.label("FIELD NOTES  ·  UNUSUAL DISCOVERIES", 17, UIKit.GOLD))
		list.add_child(_wrapped_label("Most people live ordinary lives. Your travels have uncovered a few things that do not fit the histories taught in common schools. Their meaning is not yet clear.", 13, UIKit.DIM))
		var evidence: VBoxContainer = _section(list, "Recorded evidence", Color(0.68, 0.74, 0.82))
		_value_row(evidence, "Unusual clues", "%d / %d" % [int(report.get("clues_found", 0)), int(report.get("clues_required", 3))])
		_value_row(evidence, "Ancient knowledge", "%.1f" % skills.get_value("ancient_lore"))
		_value_row(evidence, "Observation", "%.1f" % skills.get_value("observation"))
		_value_row(evidence, "Knowledge", "%.1f" % skills.get_value("knowledge"))
		var guidance: VBoxContainer = _section(list, "What you can do", Color(0.55, 0.72, 0.68))
		guidance.add_child(_wrapped_label("Continue your ordinary adventures. Explore old places, read inscriptions, study forgotten histories and speak with people who know more than they reveal. Some discoveries may eventually attract the attention of someone who understands them.", 12, UIKit.TEXT))
		guidance.add_child(_wrapped_label("There is no guaranteed awakening, character-level reward or obligation to pursue these mysteries. Your mortal skills, professions, equipment, guild standing and influence continue to develop normally.", 12, UIKit.DIM))
		return
	list.add_child(UIKit.label("CULTIVATION AND DAO", 17, Color(0.82, 0.72, 1.0)))
	list.add_child(_wrapped_label("Cultivation begins only after discovering a legitimate method and earning recognition. Practice, circulation and breakthroughs then require preparation and risk.", 12, UIKit.DIM))

	var core: VBoxContainer = _section(list, "Current foundation", Color(0.82, 0.72, 1.0))
	_value_row(core, "Current realm", skills.cultivation_realm_name(), Color(0.88, 0.78, 1.0))
	var lifespan := skills.lifespan_years()
	_value_row(core, "Natural lifespan", "Ageless" if is_inf(lifespan) else "%.0f years" % lifespan, UIKit.TEXT)
	_value_row(core, "Spiritual root", str(skills.cultivation_state.get("spiritual_root", "Unawakened")))
	_value_row(core, "Active Dao path", skills.active_cultivation_path_name())
	_value_row(core, "Cultivation mastery", "%.1f" % skills.get_value("cultivation"))
	_value_row(core, "Open meridians", "%d / %d" % [skills.meridian_count(), SkillSystem.MERIDIAN_REQUIREMENTS.size()])
	_value_row(core, "Techniques understood", "%d" % skills.cultivation_technique_count())

	var realm_index: int = skills.cultivation_realm_index()
	if realm_index < SkillSystem.CULTIVATION_REALMS.size() - 1:
		var next_realm: Dictionary = SkillSystem.CULTIVATION_REALMS[realm_index + 1]
		var cultivation_needed: float = float(next_realm.get("cultivation", 0.0))
		var meridians_needed: int = int(next_realm.get("meridians", 0))
		var readiness: Dictionary = skills.breakthrough_requirement()
		var breakthrough: VBoxContainer = _section(list, "Next breakthrough", Color(0.90, 0.72, 0.43))
		breakthrough.add_child(UIKit.label(str(next_realm.get("name", "Unknown realm")), 15, UIKit.GOLD))
		breakthrough.add_child(UIKit.label("Cultivation  ·  %.1f / %.1f" % [skills.get_value("cultivation"), cultivation_needed], 12, UIKit.TEXT))
		var cultivation_bar: ProgressBar = UIKit.bar(Color(0.70, 0.48, 0.95), 8)
		cultivation_bar.value = clampf(skills.get_value("cultivation") / maxf(cultivation_needed, 0.01), 0.0, 1.0)
		breakthrough.add_child(cultivation_bar)
		breakthrough.add_child(UIKit.label("Meridians  ·  %d / %d" % [skills.meridian_count(), meridians_needed], 12, UIKit.TEXT))
		var meridian_bar: ProgressBar = UIKit.bar(Color(0.38, 0.78, 0.72), 8)
		meridian_bar.value = clampf(float(skills.meridian_count()) / maxf(float(meridians_needed), 1.0), 0.0, 1.0)
		breakthrough.add_child(meridian_bar)
		breakthrough.add_child(_wrapped_label(str(readiness.get("reason", "Requirements met. Remain still and press O to attempt a breakthrough.")) if not bool(readiness.get("available", false)) else "Preparation complete. Remain still and press O to attempt the breakthrough.", 12, UIKit.GOOD if bool(readiness.get("available", false)) else UIKit.DIM))
	else:
		var apex: VBoxContainer = _section(list, "Highest known realm", Color(0.90, 0.72, 0.43))
		apex.add_child(_wrapped_label("You have reached the highest realm currently recorded in this cultivation system.", 12, UIKit.DIM))

	var path_section: VBoxContainer = _section(list, "Dao paths", Color(0.82, 0.72, 1.0))
	path_section.add_child(_wrapped_label("Paths become selectable after you have developed at least 0.5 average mastery across their core practices. You may change your active path at any time.", 11, UIKit.DIM))
	var path_grid := GridContainer.new()
	path_grid.columns = 3 if get_viewport().get_visible_rect().size.x >= 1050.0 else 2
	path_grid.add_theme_constant_override("h_separation", 8)
	path_grid.add_theme_constant_override("v_separation", 8)
	path_section.add_child(path_grid)
	for path_id_variant in SkillSystem.CULTIVATION_PATHS.keys():
		var path_id: String = str(path_id_variant)
		var path_data: Dictionary = SkillSystem.CULTIVATION_PATHS[path_id]
		var progress: float = skills.cultivation_path_progress(path_id)
		var unlocked: bool = progress >= 0.5
		var is_active: bool = str(skills.cultivation_state.get("active_path", "")) == path_id
		var path_card: VBoxContainer = _section(path_grid, str(path_data.get("name", path_id)), Color(0.86, 0.75, 1.0) if is_active else (UIKit.GOLD if unlocked else UIKit.DIM))
		path_card.add_child(_wrapped_label(str(path_data.get("focus", "A cultivation tradition")), 11, UIKit.DIM))
		path_card.add_child(UIKit.label("Practice average  ·  %.2f" % progress, 10, UIKit.TEXT))
		var path_bar: ProgressBar = UIKit.bar(Color(0.62, 0.48, 0.88) if unlocked else Color(0.37, 0.42, 0.52), 5)
		path_bar.value = clampf(progress / 0.5, 0.0, 1.0) if not unlocked else clampf(progress / 25.0, 0.0, 1.0)
		path_card.add_child(path_bar)
		if unlocked:
			var choose: Button = UIKit.button("Active path" if is_active else "Choose path", 11, Color(0.82, 0.72, 1.0))
			choose.disabled = is_active
			var selected_path: String = path_id
			choose.pressed.connect(func() -> void:
				skills.set_active_cultivation_path(selected_path)
				_mark_dirty())
			path_card.add_child(choose)
		else:
			path_card.add_child(UIKit.label("Not yet discovered", 10, UIKit.DIM))

	var meridian_section: VBoxContainer = _section(list, "Meridian network", Color(0.40, 0.78, 0.74))
	var meridian_grid := GridContainer.new()
	meridian_grid.columns = 4 if get_viewport().get_visible_rect().size.x >= 1050.0 else 2
	meridian_grid.add_theme_constant_override("h_separation", 8)
	meridian_grid.add_theme_constant_override("v_separation", 5)
	meridian_section.add_child(meridian_grid)
	var opened_value: Variant = skills.cultivation_state.get("meridians", {})
	var opened: Dictionary = opened_value if opened_value is Dictionary else {}
	for meridian_id in SkillSystem.MERIDIAN_REQUIREMENTS.keys():
		var meridian_data: Dictionary = SkillSystem.MERIDIAN_REQUIREMENTS[meridian_id]
		var meridian_open: bool = bool(opened.get(meridian_id, false))
		_stat_tile(meridian_grid, str(meridian_data.get("name", meridian_id)), "Opened" if meridian_open else "Dormant", UIKit.GOOD if meridian_open else UIKit.DIM)

	var forms: VBoxContainer = _section(list, "Cultivation techniques", Color(0.82, 0.72, 1.0))
	var learned_value: Variant = skills.cultivation_state.get("techniques", {})
	var learned: Dictionary = learned_value if learned_value is Dictionary else {}
	var learned_ids: Array = learned.keys()
	learned_ids.sort()
	var learned_count: int = 0
	for technique_id in learned_ids:
		if not bool(learned[technique_id]):
			continue
		learned_count += 1
		var technique_data: Dictionary = SkillSystem.CULTIVATION_TECHNIQUES.get(str(technique_id), {})
		forms.add_child(UIKit.label(str(technique_data.get("name", str(technique_id).replace("_", " ").capitalize())), 12, Color(0.88, 0.80, 1.0)))
	if learned_count == 0:
		forms.add_child(_wrapped_label("No cultivation techniques understood yet. Continue training your root skills and exploring the world for instruction.", 12, UIKit.DIM))
	forms.add_child(UIKit.label("Ancient techniques still sealed: %d" % skills.sealed_technique_count(), 11, UIKit.GOLD))

# ---------------------------------------------------------------------------
# Elyndor field journal
# ---------------------------------------------------------------------------
func _build_field_journal() -> void:
	var list: VBoxContainer = _scroll(_content)
	list.add_child(UIKit.label("FIELD JOURNAL  ·  ELYNDOR HEARTLANDS", 22, UIKit.GOLD))
	list.add_child(UIKit.label("A record of what you have learned, gathered and survived. Progress is saved with your character.", 14, UIKit.DIM))
	var journal: Dictionary = ElyndorRegionLife.get_field_journal() if ElyndorRegionLife else {}
	var readiness: Dictionary = ElyndorRegionLife.get_expedition_readiness() if ElyndorRegionLife else {"score": 0, "out_of": 5, "recommended": false, "message": "Regional journal unavailable"}
	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 12)
	list.add_child(stats)
	for pair in [["Resources", "harvested"], ["Hunts", "hunted"], ["Fish", "fished"], ["Crafted", "crafted"], ["Regions", "regions_seen"], ["Deepest floor", "dungeon_floors"]]:
		var card := UIKit.panel(UIKit.BG_LIGHT, Color(0.38, 0.42, 0.5), 8, 1)
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var col := VBoxContainer.new()
		col.add_child(UIKit.label(str(pair[0]), 12, UIKit.DIM))
		col.add_child(UIKit.label(str(int(journal.get(str(pair[1]), 0))), 22, UIKit.TEXT))
		card.add_child(col)
		stats.add_child(card)
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("EXPEDITION READINESS  ·  %d / %d field milestones" % [int(readiness.get("score", 0)), int(readiness.get("out_of", 5))], 18, UIKit.GOLD))
	list.add_child(UIKit.label(str(readiness.get("message", "Explore the Heartlands to build your field record.")), 14, UIKit.DIM))
	var milestones: Dictionary = journal.get("milestones", {})
	var milestone_rows := [
		["field_hand", "Field Hand", "Gather 8 regional resources"],
		["stalker", "Heartlands Stalker", "Hunt 5 creatures or monsters"],
		["angler", "Waterside Regular", "Land 3 fish"],
		["artisan", "Practical Artisan", "Craft 5 items"],
		["wayfarer", "Elyndor Wayfarer", "Discover 4 regions"]
	]
	for row in milestone_rows:
		var earned: bool = bool(milestones.get(str(row[0]), false))
		list.add_child(UIKit.label("%s  %s  —  %s" % ["✓" if earned else "○", str(row[1]), str(row[2])], 15, UIKit.GOOD if earned else UIKit.TEXT))
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("RECENTLY RECORDED REGIONS", 16, UIKit.GOLD))
	var regions: Dictionary = journal.get("regions", {})
	if regions.is_empty():
		list.add_child(UIKit.label("No regions recorded yet. Follow the roads and landmarks beyond the village.", 14, UIKit.DIM))
	else:
		for region in regions.keys():
			list.add_child(UIKit.label("• " + str(region), 14, UIKit.TEXT))
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("LIVING WORLD  ·  REGIONAL SIMULATION", 16, UIKit.GOLD))
	var governance: Dictionary = WorldLifeSimulation.get_governance_report()
	list.add_child(UIKit.label("WORLD GOVERNANCE  |  " + str(governance.policy).capitalize(), 14, UIKit.GOLD))
	list.add_child(_wrapped_label("Regional governors choose one affordable response per cycle: provisioning, patrols, recovery or conservation. They cannot award loot, defeat bosses or change player progression.", 12, UIKit.DIM))
	if MMORPGNetwork.is_authority():
		var policy_picker := OptionButton.new()
		var policies: Array = WorldLifeSimulation.GOVERNANCE_POLICIES.keys()
		for policy in policies:
			policy_picker.add_item(str(policy).replace("_", " ").capitalize())
		policy_picker.select(maxi(0, policies.find(str(governance.policy))))
		policy_picker.item_selected.connect(func(index: int) -> void:
			WorldLifeSimulation.set_governance_policy(str(policies[index]))
			_mark_dirty()
		)
		list.add_child(policy_picker)
	var decisions: Array = governance.decisions
	for index in range(maxi(0, decisions.size() - 5), decisions.size()):
		var decision: Dictionary = decisions[index]
		list.add_child(_wrapped_label("%s: %s" % [str(decision.region), str(decision.reason)], 12, UIKit.TEXT))
	var world_summary: Dictionary = WorldLifeSimulation.get_world_summary()
	var active_events: Array = world_summary.get("active_events", [])
	if active_events.is_empty():
		list.add_child(UIKit.label("No major regional event is currently recorded. Migration, growth and faction activity continue between visits.", 13, UIKit.DIM))
	else:
		for event_entry in active_events:
			list.add_child(UIKit.label("◈ %s  ·  %s  ·  %d cycles" % [str(event_entry.get("event", "Regional event")), str(event_entry.get("region", "Unknown region")), int(event_entry.get("remaining", 0))], 13, UIKit.TEXT))
	var world_player: Node3D = GameManager.player
	var world_region_id: String = WorldLifeSimulation.region_id_at(world_player.global_position.x, world_player.global_position.z) if world_player else ""
	var region_report: Dictionary = WorldLifeSimulation.get_region_report(world_region_id) if world_region_id != "" else {}
	if not region_report.is_empty():
		var local_event: Dictionary = region_report.get("event", {})
		list.add_child(UIKit.label("CURRENT REGION  ·  %s" % str(region_report.get("name", world_region_id)), 14, UIKit.TEXT))
		if not local_event.is_empty():
			list.add_child(UIKit.label("Active: %s — %s" % [str(local_event.get("title", "Event")), str(local_event.get("detail", ""))], 13, UIKit.GOOD))
		else:
			list.add_child(UIKit.label(str(region_report.get("last_change", "The region follows its seasonal cycle.")), 13, UIKit.DIM))
		var populations: Dictionary = region_report.get("populations", {})
		var population_parts: Array[String] = []
		for species_id in populations.keys():
			population_parts.append("%s %d" % [str(species_id).replace("_", " ").capitalize(), int(populations[species_id])])
		list.add_child(UIKit.label("Wildlife stocks: " + "  ·  ".join(population_parts), 12, UIKit.DIM))
		var resource_stocks: Dictionary = region_report.get("resources", {})
		var resource_parts: Array[String] = []
		for resource_id in ["herbs", "timber", "ore", "fish", "spirit_motes"]:
			resource_parts.append("%s %d%%" % [str(resource_id).replace("_", " ").capitalize(), int(resource_stocks.get(resource_id, 0.0))])
		list.add_child(UIKit.label("Regional reserves: " + "  ·  ".join(resource_parts), 12, UIKit.DIM))
	var joined_sect: String = str(PlayerData.stats.get("sect_state", {}).get("joined", ""))
	if joined_sect != "":
		var global_sect: Dictionary = WorldLifeSimulation.get_sect_report(joined_sect)
		list.add_child(UIKit.label("YOUR SECT  ·  %s" % str(global_sect.get("name", joined_sect)), 14, UIKit.TEXT))
		list.add_child(UIKit.label("Members %d  ·  Influence %.0f  ·  Rivalry %.0f" % [int(global_sect.get("members", 0)), float(global_sect.get("influence", 0.0)), float(global_sect.get("rivalry", 0.0))], 12, UIKit.DIM))
	var legacy_report: Dictionary = AncientInheritanceSystem.active_quest_report()
	if not legacy_report.is_empty() and bool(legacy_report.get("started", false)):
		list.add_child(UIKit.label("ANCIENT INHERITANCE  ·  %s" % str(legacy_report.get("title", "Lost legacy")), 14, UIKit.GOLD))
		list.add_child(UIKit.label("Archive fragments %d / %d  ·  Guardian floor %d: %s" % [int(legacy_report.get("fragments_collected", 0)), int(legacy_report.get("fragments_required", 0)), int(legacy_report.get("guardian_floor", 0)), "defeated" if bool(legacy_report.get("guardian_defeated", false)) else "awaiting challenge"], 13, UIKit.TEXT))
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("FIELDCRAFT RECORD", 16, UIKit.GOLD))
	_add_journal_breakdown(list, "Gathered resources", journal.get("harvested_items", {}))
	_add_journal_breakdown(list, "Fish landed", journal.get("fish_caught", {}))
	_add_journal_breakdown(list, "Items crafted", journal.get("crafted_items", {}))
	_add_journal_breakdown(list, "Creatures hunted", journal.get("hunted_species", {}))
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("BESTIARY  ·  ELEMENTAL OBSERVATIONS", 16, UIKit.GOLD))
	var bestiary_value: Variant = PlayerData.stats.get("bestiary_elemental_notes", {})
	var bestiary: Dictionary = bestiary_value if bestiary_value is Dictionary else {}
	var species_ids: Array = bestiary.keys()
	species_ids.sort()
	if species_ids.is_empty():
		list.add_child(UIKit.label("No elemental traits recorded yet. Test different elements against creatures to learn their strengths and weaknesses.", 14, UIKit.DIM))
	else:
		for species_id in species_ids:
			var observations_value: Variant = bestiary[species_id]
			if not observations_value is Dictionary:
				continue
			var observations: Dictionary = observations_value
			var findings: Array[String] = []
			var elements: Array = observations.keys()
			elements.sort()
			for element in elements:
				var detail: Dictionary = observations[element]
				findings.append("%s %s (%d%%)" % [str(element).capitalize(), str(detail.get("finding", "reacts to")), int(round(float(detail.get("strength", 0.0)) * 100.0))])
			list.add_child(UIKit.label("%s  ·  %s" % [str(species_id).replace("_", " ").capitalize(), ", ".join(findings)], 14, UIKit.TEXT))
	list.add_child(HSeparator.new())
	list.add_child(UIKit.label("THE HUNDRED-FLOOR ARCHIVE", 16, UIKit.GOLD))
	var records_value: Variant = PlayerData.stats.get("dungeon_civilization_records", {})
	var records: Dictionary = records_value if records_value is Dictionary else {}
	list.add_child(UIKit.label("Civilization memories restored: %d / 10" % records.size(), 15, UIKit.TEXT))
	var record_keys: Array = records.keys()
	record_keys.sort()
	for record_key in record_keys:
		var record: Dictionary = records[record_key]
		list.add_child(UIKit.label("Floor %d  ·  %s" % [int(record.get("floor", 0)), str(record.get("civilization", "Unknown culture"))], 14, UIKit.TEXT))
	var landmark_value: Variant = PlayerData.stats.get("spiritual_landmark_discoveries", {})
	var landmark_records: Dictionary = landmark_value if landmark_value is Dictionary else {}
	var sealed_count: int = skills.sealed_technique_count() if skills != null else 0
	list.add_child(UIKit.label("Spiritual landmarks attuned: %d  ·  Rare techniques still sealed: %d" % [landmark_records.size(), sealed_count], 14, UIKit.DIM))
	list.add_child(UIKit.label("SEALED TECHNIQUE RECORDS", 15, UIKit.GOLD))
	var sealed_value: Variant = skills.cultivation_state.get("sealed_techniques", {}) if skills != null else {}
	var sealed: Dictionary = sealed_value if sealed_value is Dictionary else {}
	var sealed_ids: Array = sealed.keys()
	sealed_ids.sort()
	if sealed_ids.is_empty():
		list.add_child(UIKit.label("No rare forms are waiting to be understood.", 13, UIKit.DIM))
	else:
		for technique_id in sealed_ids:
			var requirement: Dictionary = SkillSystem.TECHNIQUE_REQUIREMENTS.get(str(technique_id), {})
			var technique_name: String = str(SkillSystem.TECHNIQUE_NAMES.get(str(technique_id), str(technique_id).capitalize()))
			var primary_id: String = str(requirement.get("skill", "practice"))
			var secondary_id: String = str(requirement.get("secondary_skill", ""))
			var requirement_text: String = "%s %.0f" % [primary_id.replace("_", " ").capitalize(), float(requirement.get("minimum", 0.0))]
			if secondary_id != "":
				requirement_text += "  +  %s %.0f" % [secondary_id.replace("_", " ").capitalize(), float(requirement.get("secondary_minimum", 0.0))]
			list.add_child(UIKit.label("◈ %s  ·  %s" % [technique_name, requirement_text], 13, UIKit.TEXT))

func _add_journal_breakdown(parent: VBoxContainer, heading: String, values: Variant) -> void:
	parent.add_child(UIKit.label(heading, 14, UIKit.DIM))
	if not (values is Dictionary) or values.is_empty():
		parent.add_child(UIKit.label("  —", 13, UIKit.DIM))
		return
	var entries: Array = values.keys()
	entries.sort()
	var parts: Array[String] = []
	for key in entries:
		parts.append("%s × %d" % [str(key).replace("_", " ").capitalize(), int(values[key])])
	parent.add_child(UIKit.label("  " + "   ·   ".join(parts), 13, UIKit.TEXT))


# ---------------------------------------------------------------------------
# Titles
# ---------------------------------------------------------------------------
func _build_titles() -> void:
	var list: VBoxContainer = _scroll(_content)
	list.add_child(UIKit.label("Titles are earned by deeds. Equip one for its bonus.", 15, UIKit.DIM))
	var st: Dictionary = PlayerData.stats
	list.add_child(UIKit.label("Slimes defeated: %d     Items crafted: %d     Resources gathered: %d     Places discovered: %d" % [
		int(st["kills"]), int(st["crafted"]), int(st["gathered"]), PlayerData.zones.size()], 15))
	for t in QuestDB.TITLES.keys():
		var owned: bool = PlayerData.titles.has(t)
		var row: PanelContainer = UIKit.panel(UIKit.BG_LIGHT, UIKit.GOLD if PlayerData.active_title == t else Color(0.3, 0.3, 0.38), 8, 1)
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var hb := HBoxContainer.new()
		row.add_child(hb)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(col)
		col.add_child(UIKit.label(t if owned else "???", 18, UIKit.TEXT if owned else UIKit.DIM))
		col.add_child(_wrapped_label(QuestDB.TITLES[t]["desc"] if owned else "Not yet earned", 12, UIKit.DIM))
		if owned:
			var tb: Button = UIKit.button("Equipped" if PlayerData.active_title == t else "Equip", 15)
			tb.disabled = PlayerData.active_title == t
			var tn: String = t
			tb.pressed.connect(func() -> void: PlayerData.set_title(tn))
			hb.add_child(tb)
		list.add_child(row)
