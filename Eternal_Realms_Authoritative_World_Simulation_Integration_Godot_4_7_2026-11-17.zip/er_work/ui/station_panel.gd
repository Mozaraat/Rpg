# StationPanel - crafting (forge / alchemy table), gear repair, and merchant shops.
extends CanvasLayer
class_name StationPanel

const SHOPS: Dictionary = {
	"Mira": ["healing_potion", "wood_log", "iron_ore", "iron_ingot", "cloth_tunic", "fish_mackerel", "leather_strip"],
	"Gorrim the Smith": ["iron_ore", "iron_ingot", "wood_log"],
	"Archmage Lira": ["healing_potion", "mana_potion"],
}
const REP_SHOPS: Dictionary = {
	"Mira": {
		20: ["copper_ore", "fishing_rod", "leather_strip"],
		50: ["mana_crystal", "healing_potion"],
	},
	"Gorrim the Smith": {
		20: ["iron_ingot", "copper_ingot"],
		50: ["iron_sword"],
	},
}

const STATION_TITLES: Dictionary = {"forge": "The Forge", "alchemy": "Alchemy Table", "campfire": "Campfire"}

var is_open: bool = false
var mode: String = "craft"
var station: String = "forge"
var shop_npc: String = ""
var shop_tab: String = "buy"
var skills: SkillSystem = null

var _root: Control
var _title: Label
var _gold: Label
var _content: Control
var _sel_recipe: String = ""
var _result: String = ""
var _result_color: Color = UIKit.TEXT
var _rng := RandomNumberGenerator.new()
var _dirty: bool = false
var _authoritative_stock: Dictionary = {}

func _ready() -> void:
	add_to_group("station_panel")
	layer = 9
	visible = false
	_rng.randomize()
	_build()
	PlayerData.inventory_changed.connect(func() -> void: _dirty = true)
	PlayerData.equipment_changed.connect(func() -> void: _dirty = true)
	PlayerData.gold_changed.connect(func(_g: int) -> void: _dirty = true)

func set_skill_system(s: SkillSystem) -> void:
	skills = s

func _build() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)
	var win: PanelContainer = UIKit.panel()
	win.anchor_left = 0.5
	win.anchor_right = 0.5
	win.anchor_top = 0.5
	win.anchor_bottom = 0.5
	win.offset_left = -470.0
	win.offset_right = 470.0
	win.offset_top = -290.0
	win.offset_bottom = 290.0
	win.custom_minimum_size = Vector2(940, 580)
	_root.add_child(win)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	win.add_child(vb)
	var head := HBoxContainer.new()
	vb.add_child(head)
	_title = UIKit.label("Station", 26, UIKit.GOLD)
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(_title)
	_gold = UIKit.label("0 gold", 20, UIKit.GOLD)
	head.add_child(_gold)
	var close: Button = UIKit.button("X", 18)
	close.pressed.connect(close_panel)
	head.add_child(close)
	_content = Control.new()
	_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_content.custom_minimum_size = Vector2(900, 500)
	vb.add_child(_content)

func open_station(kind: String) -> void:
	mode = "craft"
	station = kind
	_sel_recipe = ""
	_result = ""
	_open()

func open_shop(npc_name: String) -> void:
	mode = "shop"
	shop_npc = npc_name
	shop_tab = "buy"
	_open()
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.request_authoritative_merchant_stock(npc_name)

func _open() -> void:
	if is_open:
		return
	is_open = true
	visible = true
	GameManager.push_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()

func close_panel() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	GameManager.pop_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _input(event: InputEvent) -> void:
	if is_open and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		close_panel()

func _process(_d: float) -> void:
	if _dirty and is_open:
		_dirty = false
		_refresh()

func _refresh() -> void:
	_gold.text = "%d gold" % PlayerData.gold
	UIKit.clear(_content)
	if mode == "craft":
		_title.text = STATION_TITLES.get(station, "Workbench")
		_build_craft()
	else:
		_title.text = "%s's Wares" % shop_npc
		_build_shop()

# ---------------------------------------------------------------------------
# Crafting
# ---------------------------------------------------------------------------
func _build_craft() -> void:
	var hb := HBoxContainer.new()
	hb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hb.add_theme_constant_override("separation", 22)
	_content.add_child(hb)

	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(300, 0)
	left.add_theme_constant_override("separation", 8)
	hb.add_child(left)
	left.add_child(UIKit.label("Recipes", 18, UIKit.GOLD))
	var recipes: Array = RecipeDB.for_station(station)
	if _sel_recipe == "" and not recipes.is_empty():
		_sel_recipe = recipes[0]
	for rid in recipes:
		var r: Dictionary = RecipeDB.RECIPES[rid]
		var b: Button = UIKit.button(r["name"], 17)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.disabled = (rid == _sel_recipe)
		var rr: String = rid
		b.pressed.connect(func() -> void:
			_sel_recipe = rr
			_result = ""
			_refresh())
		left.add_child(b)

	if station == "forge":
		var repair_row := HBoxContainer.new()
		_content.add_child(repair_row)
		var rb1: Button = UIKit.button("Repair Weapon", 14)
		rb1.pressed.connect(func() -> void:
			var gu = get_tree().get_first_node_in_group("gear_upgrade")
			if gu: gu.repair_slot("weapon")
			_dirty = true
		)
		repair_row.add_child(rb1)
		var rb2: Button = UIKit.button("Repair Armor", 14)
		rb2.pressed.connect(func() -> void:
			var gu = get_tree().get_first_node_in_group("gear_upgrade")
			if gu: gu.repair_slot("armor")
			_dirty = true
		)
		repair_row.add_child(rb2)
		var ub: Button = UIKit.button("Upgrade Weapon", 14)
		ub.pressed.connect(func() -> void:
			var gu = get_tree().get_first_node_in_group("gear_upgrade")
			if gu: gu.upgrade_slot("weapon")
			_dirty = true
		)
		repair_row.add_child(ub)
		var ub2: Button = UIKit.button("Upgrade Armor", 14)
		ub2.pressed.connect(func() -> void:
			var gu = get_tree().get_first_node_in_group("gear_upgrade")
			if gu: gu.upgrade_slot("armor")
			_dirty = true
		)
		repair_row.add_child(ub2)
	if station == "forge" and false:

		left.add_child(HSeparator.new())
		left.add_child(UIKit.label("Repairs", 18, UIKit.GOLD))
		for slot in ["weapon", "armor"]:
			var it: Dictionary = PlayerData.equipment[slot]
			if it.is_empty():
				continue
			var mx: float = ItemDB.max_durability(it)
			var cost: int = _repair_cost(it)
			var rb: Button = UIKit.button("%s  %d/%d  -  %dg" % [ItemDB.display_name(it), int(it["dur"]), int(mx), cost] if cost > 0 else "%s  (perfect)" % ItemDB.display_name(it), 15)
			rb.disabled = cost <= 0 or PlayerData.gold < cost
			var sl: String = slot
			rb.pressed.connect(func() -> void: _repair(sl))
			left.add_child(rb)

	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 8)
	hb.add_child(right)
	if _sel_recipe == "":
		return
	var rec: Dictionary = RecipeDB.RECIPES[_sel_recipe]
	var sid: String = rec["skill"]
	var sv: float = skills.get_value(sid) if skills else 0.0
	var out_inst: Dictionary = ItemDB.make(rec["output"], int(rec["count"]))
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 12)
	right.add_child(top)
	top.add_child(UIKit.item_icon(out_inst, 64))
	var tcol := VBoxContainer.new()
	top.add_child(tcol)
	tcol.add_child(UIKit.label("%s%s" % [ItemDB.def(rec["output"])["name"], (" x%d" % int(rec["count"])) if int(rec["count"]) > 1 else ""], 24))
	var req_ok: bool = sv >= float(rec["min"])
	tcol.add_child(UIKit.label("Requires %s %.1f   (you: %.2f)" % [SkillSystem.SKILLS[sid]["name"], float(rec["min"]), sv], 15, UIKit.GOOD if req_ok else UIKit.BAD))
	var od: Label = UIKit.label(ItemDB.def(rec["output"]).get("desc", ""), 14, UIKit.DIM)
	od.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	od.custom_minimum_size = Vector2(480, 0)
	right.add_child(od)
	right.add_child(UIKit.label("Materials", 16, UIKit.GOLD))
	var can: bool = req_ok
	for iid in rec["inputs"].keys():
		var need: int = int(rec["inputs"][iid])
		var have: int = PlayerData.count_item(iid)
		if have < need:
			can = false
		right.add_child(UIKit.label("   %s    %d / %d" % [ItemDB.def(iid)["name"], have, need], 16, UIKit.GOOD if have >= need else UIKit.BAD))
	var chance: float = RecipeDB.success_chance(_sel_recipe, sv)
	if station == "forge":
		right.add_child(UIKit.label("Hands-on forging: land at least two accurate hammer strikes out of three.", 15))
	elif station == "alchemy":
		right.add_child(UIKit.label("Hands-on alchemy: alternate stirring directions to stabilise the mixture.", 15))
	else:
		right.add_child(UIKit.label("Success chance: %d%%" % int(chance * 100.0), 15))
	if ItemDB.is_gear(rec["output"]):
		var odds: Array[float] = ItemDB.grade_odds(sv + PlayerData.title_bonus("grade"))
		var txt: String = "Grade odds:  "
		for gi in range(odds.size()):
			if odds[gi] >= 0.0005:
				txt += "%s %.1f%%   " % [ItemDB.GRADES[gi]["name"], odds[gi] * 100.0]
		var ol: Label = UIKit.label(txt, 14, UIKit.DIM)
		ol.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ol.custom_minimum_size = Vector2(480, 0)
		right.add_child(ol)
	var action_label := "Craft"
	if station == "forge": action_label = "Begin forging"
	elif station == "alchemy": action_label = "Begin mixing"
	var cb: Button = UIKit.button(action_label, 22)
	cb.disabled = not can
	cb.custom_minimum_size = Vector2(0, 48)
	cb.pressed.connect(_do_craft)
	right.add_child(cb)
	var res: Label = UIKit.label(_result, 18, _result_color)
	res.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	res.custom_minimum_size = Vector2(480, 0)
	right.add_child(res)

func _do_craft() -> void:
	if _sel_recipe == "" or skills == null:
		return
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and station != "forge" and station != "alchemy":
		MMORPGNetwork.request_authoritative_craft(_sel_recipe)
		return
	if station == "forge" or station == "alchemy":
		var activity: Node = get_tree().get_first_node_in_group("interactive_professions")
		if activity and activity.has_method("begin_forging"):
			activity.begin_forging(_sel_recipe, skills)
		return
	var rec: Dictionary = RecipeDB.RECIPES[_sel_recipe]
	var sid: String = rec["skill"]
	var sv: float = skills.get_value(sid)
	if sv < float(rec["min"]):
		return
	for iid in rec["inputs"].keys():
		if PlayerData.count_item(iid) < int(rec["inputs"][iid]):
			return
	var ok: bool = _rng.randf() < RecipeDB.success_chance(_sel_recipe, sv)
	if ok:
		for iid in rec["inputs"].keys():
			PlayerData.remove_item(iid, int(rec["inputs"][iid]))
		var grade: int = 0
		if ItemDB.is_gear(rec["output"]):
			grade = ItemDB.roll_grade(sv + PlayerData.title_bonus("grade"), _rng)
		PlayerData.add_item(rec["output"], int(rec["count"]), grade)
		PlayerData.notify("craft", rec["output"], int(rec["count"]))
		if ElyndorRegionLife and ElyndorRegionLife.has_method("record_crafting"):
			ElyndorRegionLife.record_crafting(str(rec["output"]), int(rec["count"]))
		PlayerData.stats["crafted"] = int(PlayerData.stats["crafted"]) + 1
		skills.train(sid, float(rec["gain"]))
		var inst: Dictionary = ItemDB.make(rec["output"], 1, grade)
		_result = "Success!  You made %s." % ItemDB.display_name(inst)
		_result_color = ItemDB.grade_color(grade) if grade > 0 else UIKit.GOOD
		if grade >= 2:
			EventBus.toast.emit("%s forged!" % ItemDB.display_name(inst), "levelup")
		if grade >= 4:
			PlayerData.grant_title("Overgeared")
	else:
		for iid in rec["inputs"].keys():
			var lose: int = int(rec["inputs"][iid]) / 2
			if lose > 0:
				PlayerData.remove_item(iid, lose)
		skills.train(sid, float(rec["gain"]) * 0.4)
		_result = "It failed... some materials were lost. (You still learned a little.)"
		_result_color = UIKit.BAD
	_refresh()

func _repair_cost(it: Dictionary) -> int:
	var mx: float = ItemDB.max_durability(it)
	var missing: float = mx - float(it.get("dur", mx))
	if missing <= 0.5:
		return 0
	return int(ceil(missing / mx * float(ItemDB.def(it["id"]).get("value", 1)) * ItemDB.grade_mult(int(it.get("grade", 0))) * 0.6)) + 1

func _repair(slot: String) -> void:
	var it: Dictionary = PlayerData.equipment[slot]
	var cost: int = _repair_cost(it)
	if cost <= 0 or not PlayerData.spend_gold(cost):
		return
	it["dur"] = ItemDB.max_durability(it)
	if skills:
		skills.train("smithing", 0.15)
	EventBus.activity.emit("Repaired %s (-%d gold)" % [ItemDB.display_name(it), cost], "info")
	PlayerData.equipment_changed.emit()
	_refresh()

# ---------------------------------------------------------------------------
# Shop
# ---------------------------------------------------------------------------
func apply_authoritative_merchant_stock(stock_rows: Array) -> void:
	_authoritative_stock.clear()
	for row_variant in stock_rows:
		if row_variant is Dictionary:
			var row: Dictionary = row_variant
			_authoritative_stock[str(row.get("item_definition_id", ""))] = row.duplicate(true)
	if is_open and mode == "shop":
		_refresh()

func _build_shop() -> void:
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 10)
	_content.add_child(vb)
	var tabs := HBoxContainer.new()
	vb.add_child(tabs)
	for t in ["buy", "sell"]:
		var b: Button = UIKit.button(t.capitalize(), 18)
		b.disabled = (shop_tab == t)
		var tt: String = t
		b.pressed.connect(func() -> void:
			shop_tab = tt
			_refresh())
		tabs.add_child(b)
	var br: float = skills.barter_rate() if skills else 0.0
	tabs.add_child(UIKit.label("     Bartering bonus: %d%%" % int(br * 100.0), 14, UIKit.DIM))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	sc.add_child(list)

	if shop_tab == "buy":
		var stock: Array = SHOPS.get(shop_npc, []).duplicate()
		var business_id := LivingWorldSystem.business_id_for_owner(shop_npc)
		var business_stock: Dictionary = LivingWorldSystem.get_business_stock(business_id)
		if not business_id.is_empty():
			for item_id in business_stock.keys():
				if str(item_id) not in stock:
					stock.append(str(item_id))
		var rep = get_tree().get_first_node_in_group("reputation")
		var rep_v: int = 0
		if rep:
			if shop_npc in ["Mira", "Gorrim the Smith", "Elara"]:
				rep_v = rep.get_rep("elyndor")
			elif "Lira" in shop_npc:
				rep_v = rep.get_rep("arcane_spire")
		var rep_discount: float = 0.10 if rep_v >= 50 else (0.05 if rep_v >= 20 else 0.0)
		for threshold in REP_SHOPS.get(shop_npc, {}).keys():
			if rep_v >= int(threshold):
				for extra in REP_SHOPS[shop_npc][threshold]:
					if extra not in stock:
						stock.append(extra)
		var market_factor: float = LivingWorldSystem.get_price_multiplier(business_id)
		for iid in stock:
			var available: int = int(business_stock.get(iid, 99)) if business_id != "" else 99
			var price: int = maxi(int(ceil(float(ItemDB.buy_value(iid)) * 1.25 * market_factor * (1.0 - minf(br + rep_discount, 0.45)))), 1)
			if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
				var server_line: Dictionary = _authoritative_stock.get(str(iid), {})
				available = int(server_line.get("quantity", 0))
				price = int(server_line.get("unit_price", price))
			var row: PanelContainer = _shop_row(ItemDB.make(iid), price, "Buy", PlayerData.gold >= price and available > 0)
			if business_id != "":
				var details := (row.get_child(0) as HBoxContainer).get_child(1) as VBoxContainer
				details.add_child(UIKit.label("Stock: %d" % available, 13, UIKit.DIM))
			(row.get_meta("button") as Button).pressed.connect(func() -> void: _buy(iid, price))
			list.add_child(row)
	else:
		var any: bool = false
		for i in range(PlayerData.slots.size()):
			var it: Dictionary = PlayerData.slots[i]
			if it.is_empty():
				continue
			any = true
			var price2: int = maxi(int(ItemDB.sell_value(it)) if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() else int(ceil(float(ItemDB.sell_value(it)) * (1.0 + br))), 1)
			var row2: PanelContainer = _shop_row(it, price2, "Sell 1" if int(it["count"]) > 1 else "Sell", true)
			var idx: int = i
			(row2.get_meta("button") as Button).pressed.connect(func() -> void: _sell(idx, price2, 1))
			if int(it["count"]) > 1:
				var all: Button = UIKit.button("Sell all", 16)
				var cnt: int = int(it["count"])
				all.pressed.connect(func() -> void: _sell(idx, price2, cnt))
				(row2.get_child(0) as HBoxContainer).add_child(all)
			list.add_child(row2)
		if not any:
			list.add_child(UIKit.label("Your backpack is empty.", 18, UIKit.DIM))

func _shop_row(inst: Dictionary, price: int, btn_text: String, enabled: bool) -> PanelContainer:
	var row: PanelContainer = UIKit.panel(UIKit.BG_LIGHT, Color(0.3, 0.3, 0.38), 8, 1)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	row.add_child(hb)
	hb.add_child(UIKit.item_icon(inst, 48))
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(col)
	col.add_child(UIKit.label(ItemDB.display_name(inst) + ((" x%d" % int(inst["count"])) if int(inst.get("count", 1)) > 1 else ""), 18, ItemDB.grade_color(int(inst.get("grade", 0)))))
	col.add_child(UIKit.label(ItemDB.def(inst["id"]).get("desc", ""), 13, UIKit.DIM))
	hb.add_child(UIKit.label("%d gold" % price, 18, UIKit.GOLD))
	var b: Button = UIKit.button(btn_text, 16)
	b.disabled = not enabled
	hb.add_child(b)
	row.set_meta("button", b)
	return row

func _buy(iid: String, price: int) -> void:
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
		MMORPGNetwork.request_merchant_purchase(shop_npc, iid, 1)
		return
	var business_id := LivingWorldSystem.business_id_for_owner(shop_npc)
	if not LivingWorldSystem.has_stock(business_id, iid, 1):
		EventBus.toast.emit("That item is out of stock", "warning")
		_refresh()
		return
	if PlayerData.free_slots() <= 0 and ItemDB.max_stack(iid) <= 1:
		EventBus.toast.emit("Inventory full!", "info")
		return
	if not PlayerData.spend_gold(price):
		return
	if PlayerData.add_item(iid, 1) > 0:
		PlayerData.add_gold(price)   # refund
		return
	if business_id != "":
		LivingWorldSystem.record_purchase(business_id, iid, 1)
	if skills:
		skills.train("bartering", 0.10)
	_refresh()

func _sell(idx: int, unit_price: int, qty: int) -> void:
	var it: Dictionary = PlayerData.item_at(idx)
	if it.is_empty():
		return
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
		var instance_id := str(it.get("item_instance_id", ""))
		if instance_id.is_empty():
			EventBus.toast.emit("Server inventory is still synchronising. Try again shortly.", "warning")
			return
		MMORPGNetwork.request_merchant_sale(shop_npc, instance_id, qty)
		return
	var n: int = mini(qty, int(it["count"]))
	var total: int = unit_price * n
	if ItemDB.is_gear(it["id"]):
		PlayerData.discard_slot(idx)
	else:
		PlayerData.remove_item(it["id"], n)
	PlayerData.add_gold(total)
	if skills:
		skills.train("bartering", 0.10 + 0.01 * float(n))
	_refresh()
