# Persistent local radar map. Positions are supplied in world X/Z coordinates
# by PlayerHUD so this widget works both above ground and inside dungeon floors.
extends Control
class_name MinimapCanvas

var player_world_position: Vector2 = Vector2.ZERO
var player_forward: Vector2 = Vector2(0.0, -1.0)
var enemy_positions: Array[Vector2] = []
var npc_positions: Array[Vector2] = []
var point_positions: Array[Vector2] = []
var world_range: float = 48.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(160.0, 160.0)

func update_radar(player_position: Vector2, forward: Vector2, enemies: Array[Vector2], npcs: Array[Vector2], points: Array[Vector2]) -> void:
	player_world_position = player_position
	player_forward = forward.normalized() if forward.length_squared() > 0.01 else Vector2(0.0, -1.0)
	enemy_positions = enemies
	npc_positions = npcs
	point_positions = points
	queue_redraw()

func _draw() -> void:
	var side: float = minf(size.x, size.y)
	var center: Vector2 = size * 0.5
	var radius: float = side * 0.5 - 5.0
	draw_circle(center + Vector2(0.0, 2.0), radius + 2.0, Color(0.0, 0.0, 0.0, 0.52))
	draw_circle(center, radius, Color(0.025, 0.045, 0.065, 0.88))
	for ring_scale in [0.33, 0.66, 1.0]:
		draw_arc(center, radius * ring_scale, 0.0, TAU, 56, Color(0.44, 0.58, 0.62, 0.30), 1.0, true)
	draw_line(center + Vector2(-radius, 0), center + Vector2(radius, 0), Color(0.4, 0.58, 0.62, 0.22), 1.0)
	draw_line(center + Vector2(0, -radius), center + Vector2(0, radius), Color(0.4, 0.58, 0.62, 0.22), 1.0)

	for location in point_positions:
		_draw_world_marker(center, radius, location, Color(0.85, 0.72, 0.42), 3.0)
	for location in npc_positions:
		_draw_world_marker(center, radius, location, Color(0.35, 0.78, 0.92), 2.8)
	for location in enemy_positions:
		_draw_world_marker(center, radius, location, Color(0.96, 0.28, 0.22), 3.4)

	var heading: Vector2 = Vector2(player_forward.x, -player_forward.y).normalized()
	var tip: Vector2 = center + heading * 10.0
	var side_vector: Vector2 = Vector2(-heading.y, heading.x) * 5.5
	draw_colored_polygon(PackedVector2Array([tip, center - heading * 4.0 + side_vector, center - heading * 4.0 - side_vector]), Color(0.96, 0.92, 0.76))
	draw_arc(center, radius, 0.0, TAU, 72, Color(0.76, 0.68, 0.46, 0.94), 2.0, true)
	var font: Font = get_theme_default_font()
	if font:
		var ink := Color(0.80, 0.89, 0.90, 0.92)
		var shadow := Color(0.02, 0.04, 0.06, 0.72)
		var marks := [
			["N", Vector2(center.x - 3.5, 13.0)],
			["E", Vector2(size.x - 11.0, center.y + 3.5)],
			["S", Vector2(center.x - 3.5, size.y - 4.0)],
			["W", Vector2(5.5, center.y + 3.5)],
		]
		for mark in marks:
			draw_string(font, mark[1] + Vector2(0.7, 0.7), mark[0], HORIZONTAL_ALIGNMENT_LEFT, -1.0, 10, shadow)
			draw_string(font, mark[1], mark[0], HORIZONTAL_ALIGNMENT_LEFT, -1.0, 10, ink)

func _draw_world_marker(center: Vector2, radius: float, world_position: Vector2, color: Color, marker_size: float) -> void:
	var offset: Vector2 = world_position - player_world_position
	var radar_offset := Vector2(offset.x, -offset.y) * (radius / maxf(world_range, 1.0))
	if radar_offset.length() > radius - 7.0:
		return
	draw_circle(center + radar_offset, marker_size + 1.2, Color(0.0, 0.0, 0.0, 0.55))
	draw_circle(center + radar_offset, marker_size, color)
