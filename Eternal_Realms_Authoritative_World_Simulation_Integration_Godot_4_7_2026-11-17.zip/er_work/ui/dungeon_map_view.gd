extends Control

var maze_cells: Array = []
var maze_links: Dictionary = {}
var player_cell := Vector2i(6, 0)
var maze_grid := 13
var maze_start := Vector2i(6, 0)
var maze_goal := Vector2i(6, 12)
var _explored: Dictionary = {}
var _refresh_clock := 0.0

func _process(delta: float) -> void:
	_refresh_clock += delta
	if _refresh_clock < 0.18:
		return
	_refresh_clock = 0.0
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	if dungeon:
		player_cell = dungeon._player_maze_cell()
		_explored = dungeon.get_explored_cells()
		queue_redraw()

func _known(cell: Vector2i) -> bool:
	return _explored.has("%d,%d" % [cell.x, cell.y])

func _draw() -> void:
	var cell_size := minf(size.x, size.y) / float(maxi(maze_grid, 1))
	var map_size := Vector2.ONE * cell_size * maze_grid
	var origin := (size - map_size) * 0.5
	draw_rect(Rect2(origin, map_size), Color(0.025, 0.034, 0.041, 0.96))
	for value in maze_cells:
		var cell: Vector2i = value
		if not _known(cell):
			continue
		var top_left := origin + Vector2(cell) * cell_size
		var center := top_left + Vector2.ONE * cell_size * 0.5
		var color := Color(0.15, 0.17, 0.16)
		if DungeonSystem.CHAMBER_RECTS.back().has_point(cell):
			color = Color(0.28, 0.12, 0.09)
		draw_rect(Rect2(top_left + Vector2.ONE * 2.0, Vector2.ONE * (cell_size - 4.0)), color)
		for direction in [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP]:
			var next: Vector2i = cell + direction
			var edge_center := center + Vector2(direction) * cell_size * 0.5
			if _has_link(cell, next):
				if _known(next):
					draw_line(center, center + Vector2(direction) * cell_size, Color(0.35, 0.38, 0.31), 3.0)
				else:
					draw_circle(edge_center, 2.5, Color(0.85, 0.66, 0.3))
			else:
				var tangent := Vector2(-direction.y, direction.x) * (cell_size * 0.5 - 2.0)
				draw_line(edge_center - tangent, edge_center + tangent, Color(0.62, 0.53, 0.37), 2.0)
	if _known(maze_start):
		draw_circle(origin + (Vector2(maze_start) + Vector2.ONE * 0.5) * cell_size, 7.0, Color(0.33, 0.88, 0.59))
	if _known(maze_goal):
		draw_circle(origin + (Vector2(maze_goal) + Vector2.ONE * 0.5) * cell_size, 8.0, Color(0.98, 0.43, 0.22))
	var you := origin + (Vector2(player_cell) + Vector2.ONE * 0.5) * cell_size
	draw_circle(you, 6.0, Color(0.31, 0.72, 1.0))
	draw_arc(you, 10.0, 0.0, TAU, 24, Color(0.78, 0.91, 1.0), 2.0, true)

func _has_link(a: Vector2i, b: Vector2i) -> bool:
	return maze_links.has("%d,%d:%d,%d" % [a.x, a.y, b.x, b.y]) or maze_links.has("%d,%d:%d,%d" % [b.x, b.y, a.x, a.y])
