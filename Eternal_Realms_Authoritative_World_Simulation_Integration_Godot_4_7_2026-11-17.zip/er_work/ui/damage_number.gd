# Floating damage number
extends Label3D
class_name DamageNumber

var velocity: Vector3 = Vector3.ZERO
var lifetime: float = 0.95

func _ready() -> void:
	billboard = BaseMaterial3D.BILLBOARD_ENABLED
	no_depth_test = true
	fixed_size = false
	outline_size = 10
	outline_modulate = Color(0, 0, 0, 0.9)
	pixel_size = 0.006
	# Random slight horizontal drift
	velocity = Vector3(randf_range(-0.8, 0.8), 2.8, randf_range(-0.8, 0.8))
	modulate.a = 1.0

func setup(amount: float, is_critical: bool = false, is_player_hurt: bool = false) -> void:
	text = str(int(amount))
	if is_critical:
		font_size = 64
		modulate = Color(1.0, 0.85, 0.2)
	elif is_player_hurt:
		font_size = 52
		modulate = Color(1.0, 0.25, 0.2)
	else:
		font_size = 48
		modulate = Color(1.0, 0.95, 0.7)

func _process(delta: float) -> void:
	global_position += velocity * delta
	velocity.y -= 4.0 * delta  # gravity on the number
	lifetime -= delta
	modulate.a = clampf(lifetime / 0.4, 0.0, 1.0)
	if lifetime <= 0:
		queue_free()

func setup_text(t: String, color: Color) -> void:
	text = t
	font_size = 44
	modulate = color
