# World Map [M] — settlements, cities, zones, player position
extends CanvasLayer
class_name WorldMap

var is_open: bool = false
var _root: Control
var _canvas: MapCanvas
var _title: Label
var _legend: Label
var _list: VBoxContainer
var _world_min: Vector2 = Vector2(-700, -600)
var _world_max: Vector2 = Vector2(700, 600)

func _ready() -> void:
	add_to_group("world_map")
	layer = 14
	visible = false
	_build()
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg:
		if sg.has_signal("settlement_leveled"):
			sg.settlement_leveled.connect(func(_id, _lvl, _t): _refresh())
		if sg.has_signal("village_founded"):
			sg.village_founded.connect(func(_id, _n): _refresh())

func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.keycode == KEY_M:
		if GameManager.current_state == GameManager.GameState.DEAD:
			return
		if is_open:
			close_map()
		elif not GameManager.input_locked:
			open_map()
		get_viewport().set_input_as_handled()
	elif event.keycode == KEY_ESCAPE and is_open:
		close_map()
		get_viewport().set_input_as_handled()

func open_map() -> void:
	if is_open:
		return
	is_open = true
	visible = true
	GameManager.push_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()

func close_map() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	GameManager.pop_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)

	var win: PanelContainer = UIKit.panel()
	win.set_anchors_preset(Control.PRESET_CENTER)
	win.anchor_left = 0.5
	win.anchor_right = 0.5
	win.anchor_top = 0.5
	win.anchor_bottom = 0.5
	win.offset_left = -420.0
	win.offset_right = 420.0
	win.offset_top = -280.0
	win.offset_bottom = 280.0
	_root.add_child(win)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	win.add_child(vb)

	var head := HBoxContainer.new()
	vb.add_child(head)
	_title = UIKit.label("World Map  [M]", 22, UIKit.GOLD)
	head.add_child(_title)
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(sp)
	var close: Button = UIKit.button("X", 18)
	close.pressed.connect(close_map)
	head.add_child(close)

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	vb.add_child(body)

	_canvas = MapCanvas.new()
	_canvas.custom_minimum_size = Vector2(520, 420)
	_canvas.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	_canvas.world_min = _world_min
	_canvas.world_max = _world_max
	body.add_child(_canvas)

	var side := VBoxContainer.new()
	side.custom_minimum_size = Vector2(240, 0)
	side.add_theme_constant_override("separation", 6)
	body.add_child(side)
	side.add_child(UIKit.label("Settlements", 18, UIKit.GOLD))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(220, 280)
	side.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_list)
	_legend = UIKit.label("● You / dungeon entrance   ■ City   ◆ Town\n● Village  ○ Landmark   · Forest / hills / mountains\nScroll: zoom  •  Drag: pan", 13, UIKit.DIM)
	_legend.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	side.add_child(_legend)

func _refresh() -> void:
	var markers: Array = _collect_markers()
	_canvas.markers = markers
	_canvas.player_xz = _player_xz()
	_canvas.queue_redraw()
	for c in _list.get_children():
		c.queue_free()
	for m in markers:
		if str(m.get("kind", "")) == "zone":
			continue
		var row := HBoxContainer.new()
		var dot := UIKit.label("●", 16, m.get("color", UIKit.TEXT))
		row.add_child(dot)
		var lbl := UIKit.label("%s  (%s)" % [str(m.get("name", "?")), str(m.get("title", ""))], 14, UIKit.TEXT)
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(lbl)
		_list.add_child(row)
	if _list.get_child_count() > 0:
		_list.add_child(UIKit.label("— Regional territories —", 13, UIKit.GOLD))
	var atlas_noise := TerrainNoise.new(GameManager.world_seed)
	for region in atlas_noise.get_region_anchor_data():
		var region_row := HBoxContainer.new()
		var region_label := UIKit.label("◈  %s" % str(region["name"]), 12, UIKit.DIM)
		region_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		region_row.add_child(region_label)
		_list.add_child(region_row)
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg and "settlements" in sg:
		_title.text = "World Map  [M]   —  %d settlements" % sg.settlements.size()

func _player_xz() -> Vector2:
	# The overworld atlas pins the player at the dungeon entrance while they are
	# underground; the dungeon's own N-map handles the internal floor position.
	var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
	if dungeon and bool(dungeon.get("inside")) and dungeon.get("_entrance"):
		var entrance: Node3D = dungeon.get("_entrance")
		return Vector2(entrance.global_position.x, entrance.global_position.z)
	var p = GameManager.player
	if p and is_instance_valid(p):
		return Vector2(p.global_position.x, p.global_position.z)
	return TerrainNoise.VILLAGE_CENTER

func _collect_markers() -> Array:
	var out: Array = []
	var discovered: Dictionary = {}
	for zname in PlayerData.zones:
		discovered[str(zname)] = true
	discovered["Elyndor Village"] = true
	discovered["Elyndor"] = true
	# Caravans
	var car = get_tree().get_first_node_in_group("caravans")
	if car and car.has_method("get_map_markers"):
		for m in car.get_map_markers():
			out.append(m)
	# POIs
	var poi = get_tree().get_first_node_in_group("poi")
	if poi and poi.has_method("get_map_markers"):
		for m in poi.get_map_markers():
			var nm: String = str(m.get("name", ""))
			if discovered.has(nm) or PlayerData.zones.size() > 2:
				out.append(m)
			else:
				var hidden: Dictionary = m.duplicate()
				hidden["name"] = "???"
				hidden["title"] = "Unknown"
				out.append(hidden)
	# Quest zones / landmarks
	for z in QuestDB.ZONES:
		var zn: String = str(z["name"])
		var known: bool = discovered.has(zn)
		out.append({
			"name": zn if known else "???",
			"pos": z["pos"],
			"kind": "zone",
			"title": "Landmark" if known else "Unexplored",
			"color": Color(0.55, 0.7, 0.85) if known else Color(0.35, 0.35, 0.4),
		})
	# Living settlements — always show founded ones
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg and "settlements" in sg:
		for id in sg.settlements.keys():
			var s: Dictionary = sg.settlements[id]
			var lvl: int = int(s.get("level", 1))
			var title: String = "Village"
			if sg.has_method("get_level_title"):
				title = sg.get_level_title(id)
			elif lvl >= 4:
				title = "City"
			elif lvl == 3:
				title = "Town"
			elif lvl <= 1:
				title = "Hamlet"
			var col := Color(0.45, 0.85, 0.55)
			if lvl >= 4:
				col = Color(1.0, 0.75, 0.25)
			elif lvl == 3:
				col = Color(0.75, 0.55, 1.0)
			elif id == "arcane_spire":
				col = Color(0.45, 0.65, 1.0)
			out.append({
				"name": str(s.get("name", id)),
				"pos": s.get("center", Vector2.ZERO),
				"kind": "settlement",
				"level": lvl,
				"title": title,
				"color": col,
				"pop": int(s.get("population", 0)),
			})
	else:
		out.append({"name": "Elyndor", "pos": TerrainNoise.VILLAGE_CENTER, "kind": "settlement", "level": 2, "title": "Village", "color": Color(0.45, 0.85, 0.55)})
		out.append({"name": "Arcane Spire", "pos": TerrainNoise.SPIRE_CENTER, "kind": "settlement", "level": 1, "title": "Hamlet", "color": Color(0.45, 0.65, 1.0)})
	# Sect war fronts, controlled borderlands, and travelling masters.
	var sect_state: Dictionary = PlayerData.stats.get("sect_state", {})
	var wars: Array = sect_state.get("war_history", [])
	for war in wars:
		if str(war.get("status", "")) != "active":
			continue
		var war_key := str(war.get("a", "")) + "::" + str(war.get("b", ""))
		var wh: int = absi(hash(war_key))
		var fallback_x := float((wh % 280) - 140)
		var fallback_z := float(((wh / 17) % 240) - 120)
		var front: Vector2 = war.get("front_xz", Vector2(fallback_x, fallback_z))
		var wx := front.x
		var wz := front.y
		out.append({"name":"Battlefront: %s / %s" % [str(war.get("a", "")).replace("_", " "), str(war.get("b", "")).replace("_", " ")], "pos":Vector2(wx, wz), "kind":"sect_war", "title":"Active war", "color":Color(0.95, 0.22, 0.16)})
	var expeditions: Dictionary = sect_state.get("master_expeditions", {})
	var expedition_index := 0
	for sect_id in expeditions.keys():
		var journey: Dictionary = expeditions[sect_id]
		var seed_value: int = absi(hash(str(sect_id) + str(journey.get("destination", ""))))
		var ex := float((seed_value % 250) - 125)
		var ez := float(((seed_value / 19) % 220) - 110)
		var destination := str(journey.get("destination", "wilderness"))
		out.append({"name":"%s Master — %s" % [str(sect_id).replace("_", " ").capitalize(), destination], "pos":Vector2(ex, ez), "kind":"master_expedition", "title":str(journey.get("status", "travelling")).capitalize(), "color":Color(0.95, 0.78, 0.32)})
		expedition_index += 1
	# Ownership is shown as translucent regional control rings around each recorded borderland.
	var territories: Dictionary = sect_state.get("sect_territory", {})
	for territory_id in territories.keys():
		var th: int = absi(hash(str(territory_id)))
		var tx := float((th % 280) - 140)
		var tz := float(((th / 17) % 240) - 120)
		var owner_color := Color(0.35, 0.62, 0.96) if str(territories[territory_id]).contains("azure") else Color(0.92, 0.38, 0.28)
		out.append({"name":"%s (%s)" % [str(territory_id).replace("_", " "), str(territories[territory_id]).replace("_", " ")], "pos":Vector2(tx, tz), "kind":"sect_territory", "title":"Controlled territory", "color":owner_color})
	# Dungeon entrance marker
	var dung = get_tree().get_first_node_in_group("dungeon")
	if dung and dung.get("_entrance"):
		var en = dung._entrance
		out.append({
			"name": "Depths of Elyndor",
			"pos": Vector2(en.global_position.x, en.global_position.z),
			"kind": "poi",
			"title": "Dungeon",
			"color": Color(0.7, 0.3, 0.85),
		})
	return out


# Drawing surface for the map
class MapCanvas extends Control:
	var world_min: Vector2 = Vector2(-240, -210)
	var world_max: Vector2 = Vector2(270, 210)
	var markers: Array = []
	var player_xz: Vector2 = Vector2.ZERO
	var terrain_texture: Texture2D
	var region_data: Array = []
	var continent_data: Array = []
	var zoom: float = 1.0
	var pan: Vector2 = Vector2.ZERO
	var _dragging: bool = false
	var _last_mouse: Vector2 = Vector2.ZERO

	func _gui_input(event: InputEvent) -> void:
		if event is InputEventMouseButton:
			if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
				zoom = minf(zoom * 1.18, 3.5)
				queue_redraw()
				accept_event()
			elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
				zoom = maxf(zoom / 1.18, 1.0)
				if zoom <= 1.01:
					pan = Vector2.ZERO
				queue_redraw()
				accept_event()
			elif event.button_index == MOUSE_BUTTON_MIDDLE or event.button_index == MOUSE_BUTTON_LEFT:
				_dragging = event.pressed
				_last_mouse = event.position
				accept_event()
		elif event is InputEventMouseMotion and _dragging:
			pan += event.position - _last_mouse
			_last_mouse = event.position
			var limit: Vector2 = size * (zoom - 1.0) * 0.5
			pan.x = clampf(pan.x, -limit.x, limit.x)
			pan.y = clampf(pan.y, -limit.y, limit.y)
			queue_redraw()
			accept_event()

	func _ready() -> void:
		_build_terrain_texture()

	func _build_terrain_texture() -> void:
		# Sample the very same seeded terrain generator used by the playable chunks.
		# The atlas therefore aligns with real X/Z positions, settlements and POIs.
		var noise := TerrainNoise.new(GameManager.world_seed)
		region_data = noise.get_region_anchor_data()
		continent_data = noise.get_continent_data()
		var image := Image.create(192, 192, false, Image.FORMAT_RGBA8)
		var span: Vector2 = world_max - world_min
		for py in range(192):
			for px in range(192):
				var wx: float = world_min.x + (float(px) / 191.0) * span.x
				var wz: float = world_max.y - (float(py) / 191.0) * span.y
				var height: float = noise.get_height(wx, wz)
				var biome: int = noise.get_biome(wx, wz, height)
				var tint: Color = Color(0.10, 0.23, 0.34)
				match biome:
					TerrainNoise.Biome.OCEAN: tint = Color(0.08, 0.22, 0.34)
					TerrainNoise.Biome.BEACH: tint = Color(0.61, 0.55, 0.36)
					TerrainNoise.Biome.PLAINS: tint = Color(0.37, 0.48, 0.24)
					TerrainNoise.Biome.FOREST: tint = Color(0.16, 0.34, 0.19)
					TerrainNoise.Biome.HILLS: tint = Color(0.43, 0.40, 0.28)
					TerrainNoise.Biome.MOUNTAIN: tint = Color(0.42, 0.43, 0.43)
					TerrainNoise.Biome.SNOW: tint = Color(0.72, 0.76, 0.75)
					TerrainNoise.Biome.SWAMP: tint = Color(0.18, 0.29, 0.20)
					TerrainNoise.Biome.DESERT: tint = Color(0.72, 0.57, 0.32)
					TerrainNoise.Biome.AUTUMN_WOOD: tint = Color(0.63, 0.34, 0.15)
					TerrainNoise.Biome.VOLCANIC: tint = Color(0.22, 0.16, 0.15)
					TerrainNoise.Biome.RAINFOREST: tint = Color(0.07, 0.27, 0.13)
					TerrainNoise.Biome.JUNGLE: tint = Color(0.04, 0.20, 0.09)
					TerrainNoise.Biome.TAIGA: tint = Color(0.20, 0.32, 0.27)
					TerrainNoise.Biome.TUNDRA: tint = Color(0.52, 0.54, 0.47)
					TerrainNoise.Biome.SAVANNA: tint = Color(0.66, 0.57, 0.28)
					TerrainNoise.Biome.MEDITERRANEAN: tint = Color(0.45, 0.46, 0.26)
				if noise.get_path_amount(wx, wz) > 0.62:
					tint = tint.lerp(Color(0.68, 0.57, 0.36), 0.72)
				image.set_pixel(px, py, tint)
		terrain_texture = ImageTexture.create_from_image(image)

	func _draw() -> void:
		var r: Rect2 = Rect2(Vector2.ZERO, size)
		# This is a sampled atlas of the actual world seed, not a placeholder panel.
		draw_rect(r, Color(0.035, 0.09, 0.13))
		if terrain_texture:
			var map_origin: Vector2 = size * 0.5 + pan - size * 0.5 * zoom
			draw_texture_rect(terrain_texture, Rect2(map_origin, size * zoom), false)
		# subtle grid remains for navigation scale
		var steps: int = 8
		for i in range(steps + 1):
			var t: float = float(i) / float(steps)
			var x: float = r.position.x + t * r.size.x
			var y: float = r.position.y + t * r.size.y
			draw_line(Vector2(x, r.position.y), Vector2(x, r.end.y), Color(1, 1, 1, 0.06), 1.0)
			draw_line(Vector2(r.position.x, y), Vector2(r.end.x, y), Color(1, 1, 1, 0.06), 1.0)
		# Major rivers are drawn on the same X/Z coordinates as the terrain channels.
		var river_routes: Array = [
			[Vector2(42, -8), Vector2(42, 24), Vector2(42, 58), Vector2(42, 95)],
			[Vector2(-360, -230), Vector2(-230, -105), Vector2(-65, 8), Vector2(155, 185)],
			[Vector2(-310, 285), Vector2(-155, 180), Vector2(28, 52), Vector2(250, -110)]
		]
		for river_points in river_routes:
			for i in range(river_points.size() - 1):
				draw_line(_map_point(river_points[i]), _map_point(river_points[i + 1]), Color(0.24, 0.62, 0.82, 0.9), 2.2, true)
		# Hand-authored regional boundaries and names make the atlas readable as geography.
		var region_colors: Dictionary = {
			"Elyndor Heartlands": Color(0.88, 0.78, 0.46),
			"Whispering Woods": Color(0.42, 0.72, 0.43),
			"Mirrorwater Basin": Color(0.52, 0.78, 0.88),
			"Amberleaf Glade": Color(0.79, 0.57, 0.35),
			"Frostveil Continent": Color(0.78, 0.84, 0.91),
			"Cinderwake Continent": Color(0.88, 0.43, 0.31),
			"Ironback Range": Color(0.76, 0.78, 0.80),
			"Mirefen Wetlands": Color(0.50, 0.72, 0.58),
			"Sunscorch Expanse": Color(0.88, 0.69, 0.38),
			"Emberfall Reach": Color(0.88, 0.43, 0.31),
			"Greenveil Rainforest": Color(0.24, 0.58, 0.30),
			"Thornwild Jungle": Color(0.16, 0.46, 0.25),
		}
		var font: Font = ThemeDB.fallback_font
		for continent in continent_data:
			var continent_center: Vector2 = _map_point(continent["center"])
			if font:
				draw_string(font, continent_center + Vector2(-58, 20), str(continent["name"]).to_upper(), HORIZONTAL_ALIGNMENT_CENTER, 150, 13, Color(0.96, 0.91, 0.78, 0.74))
		for region in region_data:
			var center: Vector2 = _map_point(region["center"])
			var rx: float = float(region["rx"]) / (world_max.x - world_min.x) * size.x * zoom
			var rz: float = float(region["rz"]) / (world_max.y - world_min.y) * size.y * zoom
			var col: Color = region_colors.get(str(region["name"]), Color.WHITE)
			draw_set_transform(center, 0.0, Vector2(maxf(rx, 2.0), maxf(rz, 2.0)))
			draw_arc(Vector2.ZERO, 1.0, 0.0, TAU, 48, Color(col.r, col.g, col.b, 0.42), 1.2, true)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if font:
				draw_string(font, center + Vector2(-42, -8), str(region["name"]), HORIZONTAL_ALIGNMENT_CENTER, 110, 12, Color(0.98, 0.95, 0.84, 0.92))
		# markers
		for m in markers:
			var pos: Vector2 = _map_point(m.get("pos", Vector2.ZERO))
			var col: Color = m.get("color", Color.WHITE)
			var kind: String = str(m.get("kind", ""))
			var lvl: int = int(m.get("level", 1))
			if kind == "zone":
				draw_circle(pos, 4.0, Color(col.r, col.g, col.b, 0.35))
				draw_arc(pos, 5.0, 0, TAU, 12, col, 1.5)
			elif kind == "sect_war":
				draw_circle(pos, 13.0, Color(col.r, col.g, col.b, 0.16))
				draw_arc(pos, 13.0, 0, TAU, 24, col, 2.5)
				draw_line(pos + Vector2(-7, -7), pos + Vector2(7, 7), col, 2.5)
				draw_line(pos + Vector2(-7, 7), pos + Vector2(7, -7), col, 2.5)
			elif kind == "master_expedition":
				draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -8), pos + Vector2(7, 0), pos + Vector2(0, 8), pos + Vector2(-7, 0)]), col)
			elif kind == "sect_territory":
				draw_circle(pos, 15.0, Color(col.r, col.g, col.b, 0.08))
				draw_arc(pos, 15.0, 0, TAU, 32, Color(col.r, col.g, col.b, 0.8), 2.0)
			else:
				var rad: float = 6.0 + float(lvl) * 1.5
				draw_circle(pos, rad + 2.0, Color(0, 0, 0, 0.45))
				draw_circle(pos, rad, col)
				if lvl >= 4:
					# city ring
					draw_arc(pos, rad + 4.0, 0, TAU, 16, Color(1, 0.9, 0.5), 2.0)
				elif lvl == 3:
					draw_arc(pos, rad + 3.0, 0, TAU, 14, Color(0.8, 0.6, 1.0), 1.5)
			# label
			var settlement_font: Font = ThemeDB.fallback_font
			var fname: String = str(m.get("name", ""))
			if settlement_font:
				draw_string(settlement_font, pos + Vector2(8, 4), fname, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.95, 0.95, 0.9))
		# player
		var pp: Vector2 = _map_point(player_xz)
		draw_circle(pp, 7.0, Color(0, 0, 0, 0.5))
		draw_circle(pp, 5.5, Color(1.0, 0.35, 0.3))
		draw_circle(pp, 2.5, Color(1, 1, 1))
		var font2: Font = ThemeDB.fallback_font
		if font2:
			draw_string(font2, pp + Vector2(10, -6), "You", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1.0, 0.55, 0.45))

	func _map_point(world_xz: Vector2) -> Vector2:
		var span: Vector2 = world_max - world_min
		if absf(span.x) < 0.001:
			span.x = 1.0
		if absf(span.y) < 0.001:
			span.y = 1.0
		var nx: float = (world_xz.x - world_min.x) / span.x
		var nz: float = (world_xz.y - world_min.y) / span.y
		# z grows "south"; flip so north is up
		var base: Vector2 = Vector2(nx * size.x, (1.0 - nz) * size.y)
		return (base - size * 0.5) * zoom + size * 0.5 + pan
