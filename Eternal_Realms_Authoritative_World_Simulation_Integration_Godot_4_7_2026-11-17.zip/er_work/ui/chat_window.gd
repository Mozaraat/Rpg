# Local roleplay and world-chat panel. Designed to be replaced by a network transport later.
extends CanvasLayer

var panel: PanelContainer
var log: RichTextLabel
var entry: LineEdit
var open := false
var _lock_owned := false
var _history: Array[String] = []
var _history_index := 0

func _ready() -> void:
	_build()
	visible = true
	panel.visible = false
	EventBus.activity.connect(_on_activity)

func _build() -> void:
	panel = PanelContainer.new()
	panel.name = "ChatPanel"
	panel.position = Vector2(22, 360)
	panel.size = Vector2(440, 320)
	panel.custom_minimum_size = Vector2(440, 320)
	add_child(panel)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 7)
	panel.add_child(layout)
	var header := HBoxContainer.new()
	layout.add_child(header)
	var title := Label.new(); title.text = "REALM CHAT"; title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color(0.86, 0.75, 0.49)); header.add_child(title)
	var hint := Label.new(); hint.text = "T to close"; hint.add_theme_font_size_override("font_size", 11); header.add_child(hint)
	log = RichTextLabel.new()
	log.bbcode_enabled = true
	log.scroll_following = true
	log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log.custom_minimum_size.y = 220
	layout.add_child(log)
	entry = LineEdit.new()
	entry.placeholder_text = "Say something… (Enter to send)"
	entry.text_submitted.connect(_send_message)
	layout.add_child(entry)
	_append("[color=#c9b47b]System[/color]", "Local realm chat ready. Talk to nearby people or ask about the world.")

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_T and not entry.has_focus():
			_toggle()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_ESCAPE and open:
			_close()
			get_viewport().set_input_as_handled()

func _toggle() -> void:
	if open: _close()
	else:
		open = true; panel.visible = true
		if not _lock_owned: GameManager.push_ui_lock(); _lock_owned = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		entry.grab_focus()

func _close() -> void:
	open = false; panel.visible = false
	if _lock_owned: GameManager.pop_ui_lock(); _lock_owned = false
	entry.release_focus()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _send_message(message: String) -> void:
	var clean := message.strip_edges()
	if clean.is_empty(): return
	_history.append(clean); _history_index = _history.size()
	_append("[color=#9dc8e8]You[/color]", clean)
	entry.clear()
	var response := _respond(clean)
	_append("[color=#d8c28c]Realm[/color]", response)

func _respond(message: String) -> String:
	var lower := message.to_lower()
	if lower.begins_with("/help"):
		return "Local chat supports conversation, /help, /where and /appraise. It is not connected to other players."
	if lower.begins_with("/where"):
		var p: Node3D = GameManager.player
		return "Your current coordinates are %.1f, %.1f, %.1f." % [p.global_position.x, p.global_position.y, p.global_position.z] if p else "You are not in the world yet."
	if lower.begins_with("/appraise"):
		if GameManager.player: AppraisalSystem.appraise(GameManager.player)
		return "I have begun an appraisal of what you are facing."
	var npc := _nearest_npc()
	if npc:
		var npc_name := str((npc as NPC).npc_name) if npc is NPC else str(npc.name)
		if lower.contains("job") or lower.contains("work"):
			return "%s says: Work keeps this settlement alive. Ask around the market and workshops to find useful opportunities." % npc_name
		if lower.contains("rumour") or lower.contains("news") or lower.contains("heard"):
			return "%s says: Travellers speak of old paths, dangerous creatures and forgotten places beyond the safe roads." % npc_name
		if lower.contains("family") or lower.contains("home"):
			return "%s says: Family and neighbours are what make a settlement worth protecting." % npc_name
		return "%s says: I may not know your meaning, traveller, but the roads have been changing lately. What have you discovered?" % npc_name
	if lower.contains("mount") or lower.contains("animal"):
		return "Companions respond to care. Feed and train them regularly, and inspect compatible companions before breeding."
	if lower.contains("cave") or lower.contains("underground"):
		return "Look for marked cave mouths in the highlands. Bring a light source and watch for underground life."
	if lower.contains("dungeon"):
		return "The tower descends through a hundred floors. Each band preserves a different civilization and its dangers."
	if lower.contains("tree") or lower.contains("climb"):
		return "The oldest trunks hide routes upward. Find a climbable giant tree and use the interaction key at its roots."
	return "The realm listens, but no distant players are connected. Try speaking near a villager, or ask about creatures, caves, trade, trees or the dungeon."

func _nearest_npc() -> Node:
	var player: Node3D = GameManager.player
	if player == null: return null
	var best: Node = null; var best_d := 8.0
	for n in get_tree().get_nodes_in_group("npc"):
		if n is Node3D:
			var d: float = player.global_position.distance_to((n as Node3D).global_position)
			if d < best_d: best_d = d; best = n
	return best

func _append(speaker: String, message: String) -> void:
	log.append_text("%s: %s\n" % [speaker, message.c_escape()])

func _on_activity(message: String, _kind: String) -> void:
	if open: _append("[color=#a9b89b]World[/color]", message)
