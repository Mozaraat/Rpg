# Eternal Realms — Civilization, Marine Life & Activities Expansion

## Dungeon civilizations and 100-floor progression
- Added ten culture identities across the existing ten-floor biome bands, each with a short historical account, signature inhabitants, a named regional hazard and a unique relic.
- Added distinct architectural dressing: bronze civic pylons, fungal root arches, rotating crystal halos, royal sarcophagi, forge chimneys and slag channels, frost mirrors, tide columns and coral crowns, living root memory plates, void menhirs with orbiting shards, and astral orreries.
- Added ten regional creature species with dedicated visual detail layers and existing procedural animation hooks. Common enemy families unlock gradually with depth so later-civilization threats do not randomly appear on the opening floors.
- Added one physical environmental hazard to each floor. The warning ring and beacon pulse; entering the hazard area causes floor-scaled damage and trains Observation.
- Added a history/memory seal to each 10th floor. Each culture uses a different four-glyph ordering discipline. The runes visibly flash their pattern once, then the player must reproduce it from memory; leaving the seal cancels the attempt. Completing the trial records the discovery and awards the corresponding civilization relic, Field Notes, gold and Archaeology / Ancient Lore / Knowledge / Wisdom / Observation / Dungeon Delving experience.

## Creature animation and marine ecology
- Fish now have separate tail pivots and animated fins, with distinct body proportions for freshwater and ocean species.
- Added large observable marine wildlife: spinner dolphins, green sea turtles, blue reef rays, reef sharks, moon jellyfish and whale sharks. Tail, flipper and body motion run continuously; studying a creature trains Marine Lore, Observation, Knowledge and Swimming, with a chance to receive Field Notes.
- Marine creatures share the marine-life population cap with fish without being incorrectly considered catchable fish.

## New overworld activities
- Animal track study: repeatable field-notes and Tracking / Observation / Knowledge progression.
- Coastal tidepool gathering: seaweed, coral fragments, scale shards and rare pearls.
- Campfire cooking: consume one Wood Log and a caught fish to prepare a healing meal.
- Archaeological inscriptions: a proximity-aware four-glyph puzzle rewards Forgotten Essence, Field Notes, gold and intellectual skills.
- Leyline meditation: restores spiritual energy and trains Cultivation, Spiritual Sense, Arcane Attunement and Wisdom.
- Marine observation complements existing fishing; E interacts with wildlife and F casts near water.

## Integration and fixes
- Registered all new item definitions and skill IDs. Added Naturalist, Archaeologist and Spiritual Adept profession profiles so the activity skills contribute to distinct playstyles.
- Added `WorldActivitySystem` to the main scene.
- Updated the HUD controls hint for fishing and memory trials.
- Added safe-ground checks for generated activity placement so camps and inscriptions are not left underwater when their preferred position is submerged.
- Fixed marine fin variable naming, fish ellipsoid helper dispatch, and dynamically attached animation-script property writes.
- Puzzle input is ignored while game input is locked and resets when the player leaves the interaction area.

## Checks and limitations
- Verified all static `res://` load/preload paths in GDScript files resolve to existing project files.
- Verified new hard-coded item references exist in ItemDB and new training references exist in SkillSystem.
- Verified changed/new GDScript files contain no duplicate function declarations.
- Godot was not installed in the build environment. The archive has not been editor-imported or run in the Godot engine here; please open `project.godot` in Godot 4.6 for full parser and runtime validation.
