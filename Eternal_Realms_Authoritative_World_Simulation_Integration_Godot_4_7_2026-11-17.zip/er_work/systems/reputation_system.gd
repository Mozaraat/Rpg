# Faction reputation + named NPC affinity
class_name ReputationSystem
extends Node

signal reputation_changed(faction: String, value: int)

var factions: Dictionary = {
	"elyndor": 0,
	"arcane_spire": 0,
	"bandits": 0,
	"wilderness": 0,
}
var npc_affinity: Dictionary = {}

func _ready() -> void:
	add_to_group("reputation")

func get_rep(faction: String) -> int:
	return int(factions.get(faction, 0))

func add_rep(faction: String, amount: int) -> void:
	if not factions.has(faction):
		factions[faction] = 0
	var old: int = int(factions[faction])
	factions[faction] = clampi(old + amount, -100, 100)
	if int(factions[faction]) != old:
		reputation_changed.emit(faction, int(factions[faction]))
		EventBus.toast.emit("Reputation with %s %+d" % [faction.capitalize().replace("_", " "), amount], "info")

func get_affinity(npc_name: String) -> int:
	return int(npc_affinity.get(npc_name, 0))

func add_affinity(npc_name: String, amount: int) -> void:
	var old: int = int(npc_affinity.get(npc_name, 0))
	npc_affinity[npc_name] = clampi(old + amount, -100, 100)
	if int(npc_affinity[npc_name]) != old:
		EventBus.toast.emit("%s affinity %+d" % [npc_name, amount], "info")

func standing(faction: String) -> String:
	var v: int = get_rep(faction)
	if v >= 50: return "Honored"
	if v >= 20: return "Friendly"
	if v >= -19: return "Neutral"
	if v >= -49: return "Disliked"
	return "Hostile"

func to_save() -> Dictionary:
	return {"factions": factions.duplicate(), "npc_affinity": npc_affinity.duplicate()}

func from_save(data: Dictionary) -> void:
	var saved_factions: Variant = data.get("factions", {})
	if saved_factions is Dictionary:
		for faction in saved_factions.keys():
			factions[str(faction)] = clampi(int(saved_factions[faction]), -100, 100)
	var saved_affinity: Variant = data.get("npc_affinity", {})
	if saved_affinity is Dictionary:
		npc_affinity.clear()
		for npc_name in saved_affinity.keys():
			npc_affinity[str(npc_name)] = clampi(int(saved_affinity[npc_name]), -100, 100)
