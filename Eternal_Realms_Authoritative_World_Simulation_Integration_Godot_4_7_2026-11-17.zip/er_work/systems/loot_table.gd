# Shared loot tables — rolls into PlayerData and optional ground drops.
class_name LootTable
extends RefCounted

var entries: Array = []  # {id, chance, min, max}
var gold_min: int = 0
var gold_max: int = 0

func add(id: String, chance: float, min_c: int = 1, max_c: int = 1) -> LootTable:
	entries.append({"id": id, "chance": chance, "min": min_c, "max": max_c})
	return self

func set_gold(gmin: int, gmax: int) -> LootTable:
	gold_min = gmin
	gold_max = gmax
	return self

func roll(luck: float = 0.0) -> Array:
	var out: Array = []
	for e in entries:
		var ch: float = clampf(float(e["chance"]) + luck, 0.0, 1.0)
		if randf() <= ch:
			var c: int = randi_range(int(e["min"]), int(e["max"]))
			if ItemDB.has_item(str(e["id"])):
				out.append({"id": str(e["id"]), "count": c})
	return out

func roll_gold() -> int:
	if gold_max <= 0:
		return 0
	return randi_range(gold_min, gold_max)

# --- Presets ---
static func slime() -> LootTable:
	return LootTable.new().add("slime_gel", 0.65, 1, 2).add("slime_core", 0.18).add("moonpetal", 0.12).set_gold(2, 8)

static func wolf() -> LootTable:
	return LootTable.new().add("wolf_pelt", 0.7).add("wolf_fang", 0.45, 1, 2).add("bone", 0.35, 1, 2).set_gold(3, 12)

static func bandit() -> LootTable:
	return LootTable.new().add("bandit_coin", 0.8, 1, 3).add("healing_potion", 0.2).add("iron_ore", 0.2).set_gold(6, 18)

static func night_wisp() -> LootTable:
	return LootTable.new().add("ectoplasm", 0.7, 1, 2).add("mana_crystal", 0.25).set_gold(4, 14)

static func stone_crawler() -> LootTable:
	return LootTable.new().add("chitin", 0.7, 1, 2).add("iron_ore", 0.3, 1, 2).set_gold(8, 20)

static func king_slime() -> LootTable:
	return LootTable.new().add("slime_core", 1.0, 2, 4).add("slime_gel", 1.0, 3, 6).add("royal_slime_gel", 1.0).add("guardian_blade", 0.25).add("healing_potion", 0.8, 1, 2).set_gold(40, 80)

static func alpha_wolf() -> LootTable:
	return LootTable.new().add("wolf_pelt", 1.0, 2, 3).add("alpha_fang", 1.0).add("beast_hide", 0.8, 1, 2).add("packlord_fang", 0.22).add("packlord_cloak", 0.18).set_gold(50, 95)

static func bandit_warlord() -> LootTable:
	return LootTable.new().add("bandit_coin", 1.0, 5, 12).add("warlord_blade", 0.55).add("captain_badge", 1.0).add("guardian_plate", 0.2).add("iron_sword", 0.35).set_gold(70, 120)

static func tide_serpent() -> LootTable:
	return LootTable.new().add("serpent_scale", 1.0, 2, 4).add("pearl", 0.6, 1, 2).add("coral_fragment", 0.7, 1, 3).add("tide_fang", 0.4).set_gold(80, 140)

static func dungeon_trash() -> LootTable:
	return LootTable.new().add("bone", 0.5, 1, 2).add("chitin", 0.25).add("ectoplasm", 0.15).add("mana_crystal", 0.08).add("healing_potion", 0.04).set_gold(2, 10)

static func dungeon_boss() -> LootTable:
	return LootTable.new().add("mana_crystal", 0.55).add("slime_core", 0.3).add("beast_hide", 0.25).add("healing_potion", 0.4).add("guardian_blade", 0.08).add("packlord_fang", 0.06).add("deepforged_cleaver", 0.025).add("tidecaller_trident", 0.025).add("catacomb_breaker", 0.02).add("voidweaver_staff", 0.015).add("prism_longbow", 0.02).add("moonshadow_stilettos", 0.02).set_gold(25, 80)

static func dungeon_boss_for_floor(floor_i: int) -> LootTable:
	var band: int = clampi(int(floor_i / 10), 0, 9)
	var table := LootTable.new()
	var material_pools: Array = [
		["slime_core", "chitin", "ectoplasm"],
		["spore_sac", "moonpetal", "mana_crystal"],
		["prism_shard", "moonstone_ore", "rune_fragment"],
		["rune_fragment", "forgotten_essence", "runebound_core"],
		["cinder_core", "dragonbone", "forgotten_essence"],
		["moonstone_ore", "ancient_scale", "runebound_core"],
		["drowned_sigil", "serpent_scale", "pearl"],
		["voidsilk", "abyssal_chitin", "heart_of_depths"],
		["abyssal_relic", "runebound_core", "heart_of_depths"],
		["heart_of_depths", "ancient_scale", "abyssal_relic"]
	]
	for material_id in material_pools[band]:
		table.add(str(material_id), 0.58, 1, 2)
	var gear_by_band: Array = [
		["guardian_blade", "guardian_plate"],
		["packlord_fang", "packlord_cloak"],
		["iron_warhammer", "iron_lance"],
		["deepforged_cleaver", "catacomb_breaker"],
		["ember_staff", "iron_battleaxe"],
		["prism_longbow", "moonstone_ore"],
		["tidecaller_trident", "iron_lance"],
		["voidweaver_staff", "deepforged_cleaver"],
		["moonshadow_stilettos", "prism_longbow"],
		["eclipse_edge", "warden_heartplate"]
	]
	for gear_id in gear_by_band[band]:
		if ItemDB.has_item(str(gear_id)) and ItemDB.is_gear(str(gear_id)):
			table.add(str(gear_id), 0.035 if floor_i % 10 != 9 else 0.12)
	table.add("healing_potion", 0.32, 1, 2)
	return table.set_gold(30 + floor_i * 3, 65 + floor_i * 5)

static func for_monster(id: String) -> LootTable:
	match id:
		"grey_wolf": return wolf()
		"bandit": return bandit()
		"night_wisp": return night_wisp()
		"stone_crawler": return stone_crawler()
		"king_slime": return king_slime()
		"alpha_wolf": return alpha_wolf()
		"bandit_warlord": return bandit_warlord()
		"tide_serpent": return tide_serpent()
		"slime": return slime()
		"fungal_stalker": return LootTable.new().add("spore_sac", 0.72, 1, 2).add("moonpetal", 0.2).add("bone", 0.2).add("ash_spear", 0.025).set_gold(7, 18)
		"crystal_mimic": return LootTable.new().add("prism_shard", 0.65, 1, 2).add("mana_crystal", 0.25).add("prism_longbow", 0.025).set_gold(12, 28)
		"cinder_hound": return LootTable.new().add("cinder_core", 0.58).add("beast_hide", 0.5).set_gold(9, 22)
		"drowned_guard": return LootTable.new().add("drowned_sigil", 0.55).add("serpent_scale", 0.3).add("iron_lance", 0.035).set_gold(10, 24)
		"rune_stalker": return LootTable.new().add("rune_fragment", 0.62).add("mana_crystal", 0.2).set_gold(12, 27)
		"abyss_mantis": return LootTable.new().add("abyssal_chitin", 0.7, 1, 2).add("chitin", 0.4).add("moonshadow_stilettos", 0.018).set_gold(14, 30)
		"grave_knight": return LootTable.new().add("bone", 0.85, 2, 4).add("rune_fragment", 0.22).add("iron_ore", 0.3).add("iron_warhammer", 0.025).set_gold(14, 32)
		"ember_shaman": return LootTable.new().add("cinder_core", 0.5).add("mana_crystal", 0.3).add("healing_potion", 0.12).add("ember_staff", 0.03).set_gold(13, 29)
		"void_stalker": return LootTable.new().add("ectoplasm", 0.65, 1, 3).add("rune_fragment", 0.35).add("mana_crystal", 0.25).set_gold(15, 34)
		"dungeon_rat", "bone_skitter", "cave_slime", "shadow_bat", "ash_imp", "void_mite", "iron_golem_shard":
			return dungeon_trash()
		"boss_gel_guardian", "boss_packlord", "boss_depth_captain", "boss_void_wisp", "boss_depth_serpent", "boss_bone_tyrant", "boss_ash_duke", "boss_iron_warden", "boss_shadow_matron", "boss_void_herald", "boss_echo_king", "boss_final_abyss":
			return dungeon_boss()
		_: return LootTable.new().add("bone", 0.5).set_gold(1, 5)
