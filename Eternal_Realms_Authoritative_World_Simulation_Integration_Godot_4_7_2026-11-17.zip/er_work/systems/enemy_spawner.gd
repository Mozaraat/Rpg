# Keeps a handful of slimes roaming the countryside around Elyndor.
extends Node3D
class_name EnemySpawner

const SLIME_SCENE = preload("res://scenes/slime.tscn")

@export var max_enemies: int = 7
@export var respawn_delay: float = 22.0

var noise: TerrainNoise
var _alive: int = 0
const SETTLEMENT_SAFE_RADIUS := 78.0
var _colors: Array[Color] = [Color(0.32, 0.85, 0.42), Color(0.30, 0.78, 0.85), Color(0.85, 0.78, 0.30), Color(0.78, 0.45, 0.85)]

func _ready() -> void:
	add_to_group("enemy_spawner")
	noise = TerrainNoise.new(GameManager.world_seed)
	EventBus.entity_died.connect(_on_entity_died)
	for i in range(max_enemies):
		_spawn(i == 0)

func _spawn(near_player: bool = false) -> void:
	var c: Vector2 = TerrainNoise.VILLAGE_CENTER
	for attempt in range(40):
		var a: float = randf() * TAU
		var r: float = randf_range(SETTLEMENT_SAFE_RADIUS, 150.0)
		var p: Vector2 = c + Vector2(cos(a), sin(a)) * r
		# stay inside the area that is guaranteed to have collision when the game starts
		if p.x < -120.0 or p.x > 58.0 or p.y < -120.0 or p.y > 58.0:
			continue
		var h: float = noise.get_height(p.x, p.y)
		if h < 1.8 or h > 8.5 or noise.settlement_mask(p.x, p.y) > 0.01 or _near_any_settlement(p):
			continue
		var s: Slime = SLIME_SCENE.instantiate()
		s.slime_color = _colors[randi() % _colors.size()]
		s.position = Vector3(p.x, h + 0.6, p.y)
		add_child(s)
		_alive += 1
		return

func _near_any_settlement(point: Vector2) -> bool:
	return point.distance_to(TerrainNoise.VILLAGE_CENTER) < SETTLEMENT_SAFE_RADIUS or point.distance_to(TerrainNoise.SPIRE_CENTER) < SETTLEMENT_SAFE_RADIUS

func _on_entity_died(entity: Node) -> void:
	if entity is Slime:
		_alive -= 1
		get_tree().create_timer(respawn_delay).timeout.connect(func() -> void:
			if is_inside_tree() and _alive < max_enemies:
				_spawn())
