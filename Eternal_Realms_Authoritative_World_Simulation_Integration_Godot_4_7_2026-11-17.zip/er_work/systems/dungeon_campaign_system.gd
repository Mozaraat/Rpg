# Persistent campaign layer for the ten dungeon civilizations.
extends Node

signal campaign_event(message: String)
signal territory_changed(floor_number: int, owner_id: String)

const CAMPAIGN_VERSION := 1
const TICK_SECONDS := 90.0
const OFFLINE_CAP_SECONDS := 604800.0
var campaign: Dictionary = {}
var _tick := 0.0

func _ready() -> void:
	add_to_group("dungeon_campaign")
	_initialize_campaign()

func _initialize_campaign() -> void:
	if not campaign.is_empty(): return
	for culture in CivilizationSocieties.CULTURES:
		var id := str(culture.id)
		campaign[id] = {"strength": 60, "morale": 55, "defeats": 0, "victories": 0,
			"leader_alive": true, "leader_guard": 2, "alliance": "", "alliance_until": 0,
			"history": [], "controlled_floors": [], "player_truce_until": 0, "last_event": "The campaign begins"}
	campaign["_meta"] = {"rooms": {}, "last_simulated": int(Time.get_unix_time_from_system()), "player_actions": 0}

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING: return
	_tick += delta
	if _tick < TICK_SECONDS: return
	_tick = 0.0
	_simulate(1)

func _meta() -> Dictionary:
	if not campaign.has("_meta") or not (campaign["_meta"] is Dictionary): campaign["_meta"] = {"rooms": {}, "last_simulated": int(Time.get_unix_time_from_system()), "player_actions": 0}
	return campaign["_meta"]

func _record(id: String) -> Dictionary:
	if not campaign.has(id):
		campaign[id] = {"strength": 60, "morale": 55, "defeats": 0, "victories": 0, "leader_alive": true, "leader_guard": 2, "alliance": "", "alliance_until": 0, "history": [], "controlled_floors": [], "player_truce_until": 0, "last_event": "Returned to the campaign"}
	return campaign[id]

func culture_id_for_floor(floor_number: int) -> String:
	return str(CivilizationSocieties.culture_for_floor(maxi(1, floor_number)).get("id", "labyrinth"))

func record_battle(floor_number: int, winner_id: String, loser_id: String, outcome: String = "battle") -> void:
	var winner := _record(winner_id)
	var loser := _record(loser_id)
	winner["strength"] = clampi(int(winner.get("strength", 50)) + 5, 0, 100)
	winner["morale"] = clampi(int(winner.get("morale", 50)) + 9, 0, 100)
	winner["victories"] = int(winner.get("victories", 0)) + 1
	loser["strength"] = clampi(int(loser.get("strength", 50)) - 12, 0, 100)
	loser["morale"] = clampi(int(loser.get("morale", 50)) - 15, 0, 100)
	loser["defeats"] = int(loser.get("defeats", 0)) + 1
	if outcome == "leader_defeated":
		loser["leader_alive"] = false
		loser["leader_guard"] = 0
	_append_history(winner_id, "Won a %s on floor %d" % [outcome, floor_number])
	_append_history(loser_id, "Suffered a %s on floor %d" % [outcome, floor_number])
	_meta()["player_actions"] = int(_meta().get("player_actions", 0)) + 1

func claim_floor(floor_number: int, owner_id: String, previous_owner: String = "") -> void:
	var key := str(maxi(1, floor_number))
	var rooms: Dictionary = _meta().get("rooms", {}).duplicate(true)
	var old_owner := previous_owner
	if rooms.has(key): old_owner = str(rooms[key].get("owner", old_owner))
	rooms[key] = {"owner": owner_id, "captured_at": int(Time.get_unix_time_from_system()), "contested": false}
	_meta()["rooms"] = rooms
	if old_owner != "" and old_owner != owner_id and old_owner != "PLAYER_EXPEDITION":
		var loser := _record(old_owner)
		loser["strength"] = clampi(int(loser.get("strength", 50)) - 8, 0, 100)
		loser["morale"] = clampi(int(loser.get("morale", 50)) - 8, 0, 100)
		loser["defeats"] = int(loser.get("defeats", 0)) + 1
		_append_history(old_owner, "Lost floor %s to %s" % [key, owner_id])
	if owner_id != "PLAYER_EXPEDITION":
		var owner := _record(owner_id)
		var floors: Array = owner.get("controlled_floors", []).duplicate()
		if not floors.has(floor_number): floors.append(floor_number)
		owner["controlled_floors"] = floors
		owner["strength"] = clampi(int(owner.get("strength", 50)) + 3, 0, 100)
	_append_history(owner_id, "Secured floor %s" % key)
	territory_changed.emit(floor_number, owner_id)

func negotiate_alliance(faction_a: String, faction_b: String, duration_ticks: int = 8) -> bool:
	if faction_a == faction_b or faction_a == "PLAYER_EXPEDITION" or faction_b == "PLAYER_EXPEDITION": return false
	var a := _record(faction_a)
	var b := _record(faction_b)
	if int(a.get("morale", 0)) < 15 or int(b.get("morale", 0)) < 15: return false
	var expiry := int(Time.get_unix_time_from_system()) + maxi(1, duration_ticks) * int(TICK_SECONDS)
	a["alliance"] = faction_b; b["alliance"] = faction_a
	a["alliance_until"] = expiry; b["alliance_until"] = expiry
	_append_history(faction_a, "Formed a temporary alliance with %s" % faction_b)
	_append_history(faction_b, "Formed a temporary alliance with %s" % faction_a)
	campaign_event.emit("%s and %s have negotiated a temporary alliance" % [_culture_name(faction_a), _culture_name(faction_b)])
	EventBus.activity.emit("%s and %s formed a temporary dungeon alliance" % [_culture_name(faction_a), _culture_name(faction_b)], "world")
	return true

func negotiate_player_truce(faction_id: String, duration_ticks: int = 12) -> bool:
	var faction := _record(faction_id)
	var rep := int(PlayerData.stats.get("culture_rep_" + faction_id, 0))
	if rep < 8 or int(faction.get("morale", 0)) < 10:
		return false
	var expiry := int(Time.get_unix_time_from_system()) + maxi(1, duration_ticks) * int(TICK_SECONDS)
	faction["player_truce_until"] = expiry
	faction["morale"] = clampi(int(faction.get("morale", 50)) + 5, 0, 100)
	_append_history(faction_id, "Negotiated a temporary ceasefire with the player's expedition")
	campaign_event.emit("%s has agreed to a temporary ceasefire" % _culture_name(faction_id))
	EventBus.activity.emit("A temporary ceasefire was negotiated with %s" % _culture_name(faction_id), "world")
	return true

func player_action(faction_id: String, action: String, amount: int = 5) -> void:
	var faction := _record(faction_id)
	var rep := clampi(int(PlayerData.stats.get("culture_rep_" + faction_id, 0)) + amount, -100, 100)
	PlayerData.stats["culture_rep_" + faction_id] = rep
	var influence_key := "faction_influence_" + faction_id
	PlayerData.stats[influence_key] = clampi(int(PlayerData.stats.get(influence_key, 0)) + amount, -100, 100)
	_meta()["player_actions"] = int(_meta().get("player_actions", 0)) + 1
	if action == "aid":
		faction["morale"] = clampi(int(faction.get("morale", 50)) + 8, 0, 100)
		faction["strength"] = clampi(int(faction.get("strength", 50)) + 3, 0, 100)
	elif action == "attack":
		faction["morale"] = clampi(int(faction.get("morale", 50)) - 10, 0, 100)
		faction["strength"] = clampi(int(faction.get("strength", 50)) - 5, 0, 100)
	_append_history(faction_id, "Player action: %s (reputation %d)" % [action, rep])

func faction_status(faction_id: String) -> Dictionary:
	return _record(faction_id).duplicate(true)

func room_owner(floor_number: int) -> String:
	var rooms: Dictionary = _meta().get("rooms", {})
	return str(rooms.get(str(maxi(1, floor_number)), {}).get("owner", culture_id_for_floor(floor_number)))

func get_save_state() -> Dictionary:
	var snapshot := campaign.duplicate(true)
	snapshot["_meta"]["last_simulated"] = int(Time.get_unix_time_from_system())
	return {"version": CAMPAIGN_VERSION, "campaign": snapshot}

func restore_from_save(state: Dictionary) -> void:
	var saved: Variant = state.get("campaign", {})
	if saved is Dictionary:
		campaign = saved.duplicate(true)
	_initialize_campaign()
	var last := int(_meta().get("last_simulated", Time.get_unix_time_from_system()))
	var elapsed := clampi(int(Time.get_unix_time_from_system()) - last, 0, int(OFFLINE_CAP_SECONDS))
	var ticks := mini(96, floori(float(elapsed) / TICK_SECONDS))
	if ticks > 0: _simulate(ticks)
	_meta()["last_simulated"] = int(Time.get_unix_time_from_system())

func _simulate(ticks: int) -> void:
	var now := int(Time.get_unix_time_from_system())
	var rooms: Dictionary = _meta().get("rooms", {}).duplicate(true)
	for id in CivilizationSocieties.CULTURES.map(func(c): return str(c.id)):
		var faction := _record(str(id))
		var ally := str(faction.get("alliance", ""))
		if ally != "" and now >= int(faction.get("alliance_until", 0)):
			faction["alliance"] = ""; faction["alliance_until"] = 0
			_append_history(str(id), "Temporary alliance with %s expired" % ally)
		if ally == "" and int(faction.get("morale", 50)) < 28 and randf() < 0.025 * float(ticks):
			var candidate_ids: Array[String] = []
			for other_culture in CivilizationSocieties.CULTURES:
				var other_id := str(other_culture.id)
				if other_id != str(id) and str(_record(other_id).get("alliance", "")) == "": candidate_ids.append(other_id)
			if not candidate_ids.is_empty(): negotiate_alliance(str(id), candidate_ids[randi_range(0, candidate_ids.size() - 1)], 6)
		var strength := int(faction.get("strength", 50))
		var morale := int(faction.get("morale", 50))
		# Defeated factions recover gradually; high morale accelerates recruitment.
		faction["strength"] = clampi(strength + maxi(1, floori(float(ticks) / 3.0)) + (1 if morale > 65 else 0), 0, 100)
		faction["morale"] = clampi(morale + maxi(1, floori(float(ticks) / 5.0)), 0, 100)
		if not bool(faction.get("leader_alive", true)) and int(faction.get("strength", 0)) >= 35:
			faction["leader_alive"] = true
			faction["leader_guard"] = 2
			_append_history(str(id), "A successor emerged and rebuilt the leadership guard")
		# Leaders rebuild a protective retinue as the faction recovers.
		if bool(faction.get("leader_alive", true)):
			faction["leader_guard"] = mini(4, int(faction.get("leader_guard", 0)) + (1 if int(faction.get("strength", 0)) >= 65 and randf() < 0.08 * float(ticks) else 0))
		# Factions contest captured territory; hostile pressure can even retake an expedition room.
		for floor_key in rooms.keys():
			var room: Dictionary = rooms[floor_key]
			var owner_id := str(room.get("owner", ""))
			if owner_id == str(id): continue
			if owner_id != "" and owner_id != "PLAYER_EXPEDITION":
				var owner_state := _record(owner_id)
				if str(faction.get("alliance", "")) == owner_id: continue
				if int(faction.get("strength", 0)) > int(owner_state.get("strength", 0)) + 20 and randf() < 0.004 * float(ticks):
					room["owner"] = str(id); room["contested"] = false; rooms[floor_key] = room
					_append_history(str(id), "Retook floor %s from %s" % [floor_key, owner_id])
					_append_history(owner_id, "Lost floor %s to %s" % [floor_key, id])
					campaign_event.emit("%s retook a dungeon chamber from %s" % [_culture_name(str(id)), _culture_name(owner_id)])
					EventBus.activity.emit("%s retook a dungeon chamber from %s" % [_culture_name(str(id)), _culture_name(owner_id)], "world")
			elif owner_id == "PLAYER_EXPEDITION":
				if now < int(faction.get("player_truce_until", 0)):
					continue
				var rep := int(PlayerData.stats.get("culture_rep_" + str(id), 0))
				if int(faction.get("strength", 0)) >= 75 and rep < -20 and randf() < 0.0015 * float(ticks):
					room["owner"] = str(id); room["contested"] = false; rooms[floor_key] = room
					_append_history(str(id), "Retook expedition-held floor %s" % floor_key)
					campaign_event.emit("%s reclaimed a chamber from your expedition" % _culture_name(str(id)))
					EventBus.activity.emit("%s retook a chamber from your expedition" % _culture_name(str(id)), "world")
	_meta()["rooms"] = rooms
	_meta()["last_simulated"] = now

func record_siege_event(faction_id: String, floor_number: int, message: String) -> void:
	var faction := _record(faction_id)
	_append_history(faction_id, "Floor %d siege: %s" % [floor_number, message])
	faction["last_siege_floor"] = floor_number
	faction["last_siege_event"] = message

func record_siege_result(floor_number: int, faction_id: String, outcome: String) -> void:
	var faction := _record(faction_id)
	if outcome == "negotiated_truce":
		_append_history(faction_id, "Ended the siege through a negotiated truce on floor %d" % floor_number)
	elif outcome == "attacker_victory":
		faction["strength"] = clampi(int(faction.get("strength", 50)) - 10, 0, 100)
		faction["morale"] = clampi(int(faction.get("morale", 50)) - 14, 0, 100)
		faction["defeats"] = int(faction.get("defeats", 0)) + 1
		claim_floor(floor_number, "PLAYER_EXPEDITION", faction_id)
		player_action(faction_id, "attack", -5)
		_append_history(faction_id, "Lost fortress on floor %d to the player's siege" % floor_number)
	else:
		faction["strength"] = clampi(int(faction.get("strength", 50)) + 4, 0, 100)
		faction["morale"] = clampi(int(faction.get("morale", 50)) + 10, 0, 100)
		faction["victories"] = int(faction.get("victories", 0)) + 1
		_append_history(faction_id, "Defended fortress on floor %d against the player's siege" % floor_number)
	campaign_event.emit("Siege concluded: %s" % outcome.replace("_", " "))
	EventBus.activity.emit("A fortress siege concluded on floor %d" % floor_number, "world")

func _append_history(id: String, entry: String) -> void:
	var faction := _record(id)
	var history: Array = faction.get("history", []).duplicate()
	history.append({"time": int(Time.get_unix_time_from_system()), "event": entry})
	while history.size() > 30: history.pop_front()
	faction["history"] = history
	faction["last_event"] = entry

func _culture_name(id: String) -> String:
	for culture in CivilizationSocieties.CULTURES:
		if str(culture.id) == id: return str(culture.name)
	return id
