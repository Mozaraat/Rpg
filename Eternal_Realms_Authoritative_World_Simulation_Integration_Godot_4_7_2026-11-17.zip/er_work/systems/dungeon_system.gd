# Depths of Elyndor — multi-floor dungeon. Boss gate each floor. Spawns INSIDE rooms only.
extends Node3D
class_name DungeonSystem

const FLOORS: int = 100
const ROOM_SIZE: float = 20.0
# Each floor is a city-scale underground district, not a compact 9x9 maze.
const MAZE_GRID: int = 13
const MAZE_CELL: float = 16.0
const MAZE_CENTER: int = 6
const MAZE_HALF: float = float(MAZE_GRID) * MAZE_CELL * 0.5
const FLOOR_VERTICAL_SPACING: float = 36.0
const MAZE_START: Vector2i = Vector2i(MAZE_CENTER, 0)
const MAZE_GOAL: Vector2i = Vector2i(MAZE_CENTER, MAZE_GRID - 1)
var _maze_links: Dictionary = {}
var _maze_cells: Array[Vector2i] = []
const MONSTER_SCENE = preload("res://scenes/monster.tscn")
## Isolated pocket so overworld terrain/spawns never interfere
const DUNGEON_ORIGIN: Vector3 = Vector3(800.0, -500.0, 800.0)

# Chamber plan of every floor, in maze-cell coordinates. These blocks match the
# open plazas carved in the maze, so the city quarters, the forum and the raid
# sanctum each become a walled room with doors instead of open cave.
const CHAMBER_RECTS: Array = [
	Rect2i(1, 3, 2, 2),
	Rect2i(10, 3, 2, 2),
	Rect2i(1, 7, 2, 2),
	Rect2i(10, 7, 2, 2),
	Rect2i(5, 5, 3, 3),
	Rect2i(5, 10, 3, 3),
]
const CHAMBER_LABELS: Array = ["EXCHANGE", "RESIDENTIAL", "ARCHIVE", "TEMPLE", "FORUM", "SANCTUM"]

# Each lost civilization changes how its defenders fight, not just how its halls look.
const CIVILIZATION_COMBAT: Array[Dictionary] = [
	{"faction":"Concord Remnant","resist":{"earth":0.18,"lightning":-0.22},"pattern":"bronze_lance","tactic":"shield_line"},
	{"faction":"Mycelium Choir","resist":{"water":0.16,"fire":-0.28},"pattern":"spore_cloud","tactic":"ambush_flank"},
	{"faction":"Prism Enclave","resist":{"lightning":0.24,"wind":-0.18},"pattern":"prism_split","tactic":"focus_fire"},
	{"faction":"Sepulchral Court","resist":{"dark":0.22,"fire":-0.18},"pattern":"grave_pulse","tactic":"guarded_advance"},
	{"faction":"Cinder Dominion","resist":{"fire":0.28,"water":-0.30},"pattern":"ash_cone","tactic":"aggressive_push"},
	{"faction":"Winter Monastery","resist":{"ice":0.30,"fire":-0.30},"pattern":"frost_ring","tactic":"kite_and_trap"},
	{"faction":"Thalassian Court","resist":{"water":0.28,"lightning":-0.25},"pattern":"tide_surge","tactic":"encircle"},
	{"faction":"Root Communion","resist":{"earth":0.25,"fire":-0.30},"pattern":"root_snare","tactic":"protect_leader"},
	{"faction":"Starless Court","resist":{"dark":0.32,"lightning":-0.24},"pattern":"void_fold","tactic":"shadow_flank"},
	{"faction":"Eternal Archive","resist":{"lightning":0.22,"wind":0.18},"pattern":"astral_orbit","tactic":"rotating_guard"}
]

var current_floor: int = 0
var deepest_cleared: int = 0
var inside: bool = false
var _rooms: Dictionary = {}
var _entrance: Area3D
var _noise: TerrainNoise
var _boss_alive: bool = false
var _floor_boss: Node = null
var _return_pos: Vector3 = Vector3.ZERO
var _discovered_floors: Array[int] = []
var _discovery_flags: Dictionary = {}
var _explored_cells: Dictionary = {}
var _exploration_timer := 0.0
var _farming_slots: Dictionary = {}
var _farming_timer := 0.0
var _cleared_floors: Dictionary = {}
var _floor_clear_revisions: Dictionary = {}
var _discovery_backend_revision: int = 0
var _discovery_save_busy: bool = false
var _discovery_save_queued: bool = false
var _discovery_retry_timer: float = 0.0
var _peer_floors: Dictionary = {}
var _travel_times: Dictionary = {}
var _progress_ready := false
var _world_event_timer: float = 65.0
var _active_world_event: String = ""
var _cave_materials: Dictionary = {}
var _event_count: int = 0
var _checkpoint_floor: int = 1
var _checkpoint_position: Vector3 = Vector3.ZERO
var _world_environment: Environment
var _world_sun_energy: float = -1.0
var _world_moon_energy: float = -1.0
var _dungeon_map_layer: CanvasLayer
var _loading_layer: CanvasLayer
var _floor_weather: String = "still air"
var _floor_affix: String = ""

const TRASH: Array = [
	{"id": "dungeon_rat", "name": "Depth Rat", "hp": 35.0, "dmg": 8.0, "color": Color(0.35, 0.28, 0.22)},
	{"id": "bone_skitter", "name": "Bone Skitter", "hp": 45.0, "dmg": 10.0, "color": Color(0.75, 0.72, 0.65)},
	{"id": "cave_slime", "name": "Cave Slime", "hp": 55.0, "dmg": 11.0, "color": Color(0.25, 0.55, 0.35)},
	{"id": "shadow_bat", "name": "Shadow Bat", "hp": 40.0, "dmg": 12.0, "color": Color(0.2, 0.15, 0.3)},
	{"id": "stone_crawler", "name": "Stone Crawler", "hp": 70.0, "dmg": 14.0, "color": Color(0.4, 0.38, 0.35)},
	{"id": "grey_wolf", "name": "Depth Wolf", "hp": 65.0, "dmg": 13.0, "color": Color(0.35, 0.35, 0.4)},
	{"id": "ash_imp", "name": "Ash Imp", "hp": 50.0, "dmg": 15.0, "color": Color(0.7, 0.25, 0.15)},
	{"id": "void_mite", "name": "Void Mite", "hp": 48.0, "dmg": 16.0, "color": Color(0.35, 0.2, 0.55)},
	{"id": "iron_golem_shard", "name": "Iron Shard", "hp": 90.0, "dmg": 18.0, "color": Color(0.5, 0.52, 0.55)},
	{"id": "night_wisp", "name": "Depth Wisp", "hp": 55.0, "dmg": 17.0, "color": Color(0.4, 0.6, 1.0)},
	{"id": "fungal_stalker", "name": "Fungal Stalker", "hp": 82.0, "dmg": 17.0, "color": Color(0.38, 0.62, 0.28)},
	{"id": "crystal_mimic", "name": "Crystal Mimic", "hp": 105.0, "dmg": 21.0, "color": Color(0.25, 0.75, 0.9)},
	{"id": "cinder_hound", "name": "Cinder Hound", "hp": 92.0, "dmg": 23.0, "color": Color(0.78, 0.25, 0.12)},
	{"id": "drowned_guard", "name": "Drowned Guard", "hp": 118.0, "dmg": 22.0, "color": Color(0.18, 0.42, 0.58)},
	{"id": "rune_stalker", "name": "Rune Stalker", "hp": 100.0, "dmg": 26.0, "color": Color(0.52, 0.32, 0.82)},
	{"id": "abyss_mantis", "name": "Abyss Mantis", "hp": 125.0, "dmg": 28.0, "color": Color(0.32, 0.58, 0.42)},
	{"id": "grave_knight", "name": "Grave Knight", "hp": 145.0, "dmg": 29.0, "color": Color(0.48, 0.48, 0.55)},
	{"id": "ember_shaman", "name": "Ember Shaman", "hp": 110.0, "dmg": 31.0, "color": Color(0.92, 0.38, 0.12)},
	{"id": "void_stalker", "name": "Void Stalker", "hp": 135.0, "dmg": 33.0, "color": Color(0.28, 0.16, 0.48)},
	{"id": "bronze_sentinel", "name": "Bronze Sentinel", "hp": 86.0, "dmg": 13.0, "color": Color(0.68, 0.43, 0.19)},
	{"id": "spore_moth", "name": "Spore Moth", "hp": 74.0, "dmg": 15.0, "color": Color(0.45, 0.72, 0.38)},
	{"id": "prism_stalker", "name": "Prism Stalker", "hp": 112.0, "dmg": 21.0, "color": Color(0.28, 0.78, 0.92)},
	{"id": "grave_hound", "name": "Grave Hound", "hp": 148.0, "dmg": 27.0, "color": Color(0.48, 0.45, 0.42)},
	{"id": "ember_wyrm", "name": "Ember Wyrm", "hp": 162.0, "dmg": 30.0, "color": Color(0.92, 0.29, 0.1)},
	{"id": "frost_lynx", "name": "Frost Lynx", "hp": 175.0, "dmg": 31.0, "color": Color(0.64, 0.82, 0.96)},
	{"id": "reef_crab", "name": "Reef Crab", "hp": 190.0, "dmg": 32.0, "color": Color(0.2, 0.64, 0.68)},
	{"id": "rootbound_guardian", "name": "Rootbound Guardian", "hp": 215.0, "dmg": 34.0, "color": Color(0.35, 0.58, 0.25)},
	{"id": "void_jelly", "name": "Void Jelly", "hp": 225.0, "dmg": 36.0, "color": Color(0.55, 0.32, 0.84)},
	{"id": "astral_scribe", "name": "Astral Scribe", "hp": 250.0, "dmg": 38.0, "color": Color(0.84, 0.66, 0.94)},
]

const BOSSES: Array = [
	{"id": "boss_gel_guardian", "name": "Gel Guardian", "hp": 160.0, "dmg": 16.0, "color": Color(0.3, 0.85, 0.4)},
	{"id": "boss_packlord", "name": "Packlord", "hp": 180.0, "dmg": 18.0, "color": Color(0.45, 0.4, 0.5)},
	{"id": "boss_depth_captain", "name": "Depth Captain", "hp": 200.0, "dmg": 20.0, "color": Color(0.5, 0.25, 0.2)},
	{"id": "boss_void_wisp", "name": "Void Wisp Queen", "hp": 170.0, "dmg": 22.0, "color": Color(0.4, 0.5, 1.0)},
	{"id": "boss_depth_serpent", "name": "Depth Serpent", "hp": 220.0, "dmg": 24.0, "color": Color(0.2, 0.45, 0.55)},
	{"id": "boss_bone_tyrant", "name": "Bone Tyrant", "hp": 240.0, "dmg": 25.0, "color": Color(0.9, 0.88, 0.8)},
	{"id": "boss_ash_duke", "name": "Ash Duke", "hp": 260.0, "dmg": 27.0, "color": Color(0.85, 0.3, 0.1)},
	{"id": "boss_iron_warden", "name": "Iron Warden", "hp": 300.0, "dmg": 28.0, "color": Color(0.55, 0.58, 0.62)},
	{"id": "boss_shadow_matron", "name": "Shadow Matron", "hp": 280.0, "dmg": 30.0, "color": Color(0.15, 0.1, 0.25)},
	{"id": "boss_void_herald", "name": "Void Herald", "hp": 320.0, "dmg": 32.0, "color": Color(0.5, 0.2, 0.7)},
	{"id": "boss_echo_king", "name": "Echo King", "hp": 360.0, "dmg": 34.0, "color": Color(0.7, 0.6, 0.9)},
	{"id": "boss_final_abyss", "name": "Abyssal Throne", "hp": 420.0, "dmg": 38.0, "color": Color(0.1, 0.05, 0.15)},
]

# Every floor has its own named raid guardian. Each ten-floor band belongs to a different civilization.
const RAID_BOSS_TITLES: Array = [
	["The Oathbreaker Regent", "Bell-Tower Devourer", "The Gilded Executioner", "Marble-Eater Colossus", "The Crownless Marshal", "The Vaultheart Behemoth", "Keeper of the Last Ledger", "The Seven-Vow Revenant", "The Sunken Chancellor", "The Concord's War Sovereign"],
	["The Mycelium Matriarch", "The Thorn-Crowned Stag", "The Spore Choir Incarnate", "The Hollowroot Behemoth", "The Verdant Devourer", "The Blooming Ruin", "The Sleepless Forager", "The Eldercap Titan", "The Heartwood Warden", "The Choir's World-Eater"],
	["The First Prism", "The Refraction Engine", "The Shardbound Oracle", "The Thousand-Facet Hydra", "The Luminous Inquisitor", "The Glass Cathedral's Heart", "The Spectrum Tyrant", "The Mirror-Split Sovereign", "The Unmaking Lens", "The Enclave's Final Equation"],
	["The Crown-Buried King", "The Sepulchral Marshal", "The Pallbearer General", "The Epitaph Colossus", "The Queen Beneath the Steps", "The Ossuary Devourer", "The Grave-Bell Abbot", "The Bone-Throne Regent", "The Last Royal Hound", "The Court's Deathless Monarch"],
	["The First Furnace", "The Ashen Foundry Lord", "The Magma-Crowned Tyrant", "The Chainbreaker Forgemaster", "The Cinder Basilica's Heart", "The Crucible Devourer", "The Emberstorm Colossus", "The Iron-Priest of Ruin", "The World-Anvil Behemoth", "The Dominion's Infernal King"],
	["The Whiteout Abbot", "The Mirror-Ice Sentinel", "The Rimebound Huntress", "The Glacier-Tomb Warden", "The Winterglass Colossus", "The Stillness That Hunts", "The Frostbound Hierophant", "The Shiver-Crowned Monarch", "The Ninth Winter", "The Monastery's Unmelting One"],
	["The Drowned Admiral", "The Coral-Crowned Leviathan", "The Pressure-King", "The Saltbone Oracle", "The Abyssal Harbormaster", "The Undertow Matron", "The Sunken Bell Titan", "The Black-Tide Devourer", "The Crown Beneath the Waves", "The Thalassian Sea Sovereign"],
	["The Root-Twined Shepherd", "The Elderbark Warden", "The Sapheart Colossus", "The Thornwake Matriarch", "The Hollow Trunk Devourer", "The Verdant Oathkeeper", "The Rootmaze Sovereign", "The Sleeper in the Heartwood", "The Worldroot's Last Gardener", "The Communion's Ancient Crown"],
	["The Name-Eater", "The Unlit Regent", "The Folded-Palace Warden", "The Starless Harrower", "The Eclipse Devourer", "The Hollow Between Worlds", "The Black Meridian", "The Court of One Shadow", "The Silence Beyond the Seal", "The Starless Sovereign"],
	["The First Astronomer", "The Orrery Breaker", "The Celestial Archivist", "The Unwritten Constellation", "The Keeper of Lost Hours", "The Parallax Behemoth", "The Codex Devourer", "The Astral Meridian", "The Last Recorded King", "The Eternal Archive's Final Sovereign"]
]

# Short environmental records make each floor tell a different part of its civilization's collapse.
const CIVILIZATION_FLOOR_RECORDS: Array = [
	["The market ledgers list three days of food, then stop mid-sentence.", "A bronze receipt records a crown sold to pay the city guard.", "The bell keeper scratched a warning into the underside of the clapper.", "A child's chalk map marks every safe doorway in the ward.", "The guild closed its vaults before the first tremor.", "A watch roster shows every soldier assigned to the same sealed gate.", "The final tax was paid in heirlooms rather than coin.", "A broken oath-stone bears seven names and one erased face.", "The chancellor ordered the roads cleared, but never named a destination.", "The last inscription declares the Concord unbroken, though its halls are empty."],
	["The Choir's first song is carved into a root that still pulses.", "A nursery of empty spore pods was arranged like sleeping children.", "The foragers marked a safe path with pale mushrooms.", "A root bridge was severed to keep something from following.", "The harvest calendar ends during the season of red pollen.", "A chorus score has one voice scratched out on every page.", "The old gardeners left their tools standing upright in the soil.", "A fungal wall has grown around a sealed family chamber.", "The migration songs point deeper, not toward the surface.", "The final verse asks the roots to remember the names of the lost."],
	["A prism log records the first light split into seven colours.", "The lenswrights left a warning against looking into the central facet.", "An unfinished chart maps a star that no longer exists.", "A crystal nursery contains memories but no names.", "The beam array was turned away from the evacuation route.", "A scholar's notes insist the reflections began moving first.", "The observatory shutters were sealed from the inside.", "A fractured mirror repeats the same final minute.", "The Enclave's last equation has no equal sign.", "The archive records a light beyond the world, then goes dark."],
	["A funeral list names a monarch who was never born.", "The royal hounds were ordered to guard empty apartments.", "A procession route ends at a throne facing the wall.", "The grave bells rang thirteen times before the court fell silent.", "A royal portrait has been cut from every family crypt.", "The tomb doors show claw marks on the inner side.", "A servant's ledger records meals for a king long after his death.", "The marshal's final order was to protect the living, not the throne.", "The last epitaph asks forgiveness from the city above.", "The Court buried its crown with no body beneath it."],
	["The furnace roster records a shift that never came back.", "A smith left a blade half-quenched in the cooling channel.", "The forge-priests chained the fire vents shut.", "A warning bell was melted down to reinforce the gate.", "The anvil bears a name struck into it from beneath.", "The foundry workers built shelters between the furnaces.", "A pressure gauge is pinned beyond its final mark.", "The last weapon order was for a lock, not an army.", "The crucible contains ash shaped like a handprint.", "The Dominion's final hammer blow cracked the mountain above."],
	["The monks recorded the first winter as a blessing.", "A novice's mirror was turned to face the wall.", "The ice archive preserves a voice calling from outside.", "The watch bell was wrapped in cloth to keep it from ringing.", "A prayer wheel froze while still turning.", "The monastery stores warmth in jars marked with names.", "The mirror hall shows a procession with one extra shadow.", "The abbot ordered every door left open for the refugees.", "A frozen scripture describes a spring that never arrived.", "The last monk carved a path toward the deepest silence."],
	["The dock ledger lists ships that could not fit through the locks.", "A pressure engineer marked a crack with a child's handprint.", "The coral market was abandoned during a falling tide.", "A bell buoy still rings though the water is motionless.", "A tide chart has been scratched into the floor in reverse.", "The admiral's orders direct the fleet toward dry stone.", "A nursery pool holds tiny shells arranged like a crown.", "The pressure gates were opened to let the beasts escape.", "A lighthouse lens points down into the black water.", "The Crown's final signal is answered from below the seabed."],
	["The first gardener planted a seed in bare rock.", "A root ledger records the growth of every district.", "A tree-house door was sealed with living bark.", "The healers left their water bowls beneath a wounded root.", "A migration trail is marked with sap and bone charms.", "The elder tree has grown around a broken oath-stone.", "A hollow trunk shelters a room full of abandoned tools.", "The Communion's song has become a warning pulse.", "A branch points toward a chamber that is not on the map.", "The oldest root remembers a world before the continents."],
	["The Court's first law forbids speaking a star's true name.", "A scribe removed every name from the census.", "The palace corridor folds back upon its own entrance.", "A shadow seal is broken from the side facing inward.", "The eclipse calendar shows a night that lasted years.", "A messenger's final note contains only a blank space.", "The archive shelves are chained shut from the outside.", "A black mirror reflects a room that was never built.", "The court's last door opens toward a starless sky.", "The final record warns that silence is not the same as safety."],
	["The astronomers charted the first continent before it rose.", "A brass model shows a tenth civilization missing from the map.", "A clockwork scribe stopped at the moment the stars shifted.", "The observatory floor contains footprints leading into the ceiling.", "A sealed codex lists every guardian by a name not yet spoken.", "The orrery's outer ring moves against the turning of the world.", "A star map marks the dungeon entrance as its centre.", "The archivists left their lamps burning for the next reader.", "A final index page has been torn out and hidden nearby.", "The Eternal Archive records that the hundredth floor is a beginning, not an end."]
]

func _ready() -> void:
	add_to_group("dungeon")
	position = DUNGEON_ORIGIN
	_noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	_build_entrance()
	await _load_shared_clears()
	print("[Dungeon] Depths ready — %d floors (isolated pocket)" % FLOORS)


func _unhandled_input(event: InputEvent) -> void:
	if not inside or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.keycode == KEY_N:
		_toggle_dungeon_map()
		get_viewport().set_input_as_handled()
	elif event.keycode == KEY_ESCAPE and _dungeon_map_layer and is_instance_valid(_dungeon_map_layer):
		_toggle_dungeon_map()
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if _discovery_save_queued and not _discovery_save_busy and WorldDeploymentGuard.production_mode:
		_discovery_retry_timer -= delta
		if _discovery_retry_timer <= 0.0:
			_discovery_retry_timer = 10.0
			call_deferred("_persist_dungeon_discoveries")
	_farming_timer += delta
	if _farming_timer >= 2.0 and MMORPGNetwork.is_authority():
		_farming_timer = 0.0
		_tick_farming()
	if not inside:
		return
	_exploration_timer += delta
	if _exploration_timer >= 0.25:
		_exploration_timer = 0.0
		_reveal_player_cell()
	_suppress_overworld_lights()
	_world_event_timer -= delta
	if _world_event_timer <= 0.0:
		_world_event_timer = randf_range(75.0, 115.0)
		_start_dungeon_event()

func _start_dungeon_event() -> void:
	if not MMORPGNetwork.is_authority():
		return
	var events: Array[String] = ["HUNTING_HORDE", "ARCANE_SURGE", "TREASURE_ECHO", "CAVE_IN", "ELITE_PATROL", "SUPPLY_STASH", "SPIRIT_TIDE", "ANCIENT_WARDEN"]
	_active_world_event = events[randi_range(0, events.size() - 1)]
	match _active_world_event:
		"HUNTING_HORDE":
			EventBus.toast.emit("Dungeon event: A hunting pack is moving through this floor!", "warning")
			var horde_room: Node3D = _rooms.get(current_floor)
			if horde_room:
				var data: Dictionary = _random_floor_monster(current_floor)
				for i in range(3):
					var cell: Vector2i = _maze_cells[randi_range(1, maxi(1, _maze_cells.size() - 2))]
					_spawn_in_room(horde_room, current_floor, str(data.id), false, "Horde " + str(data.name), float(data.hp) * 0.8, float(data.dmg), data.color, _difficulty(current_floor), cell)
		"ARCANE_SURGE":
			EventBus.toast.emit("Dungeon event: Arcane surge! Shrine discoveries are empowered.", "levelup")
		"TREASURE_ECHO":
			EventBus.toast.emit("Dungeon event: Treasure echo detected. A bonus cache has appeared!", "loot")
			var treasure_room: Node3D = _rooms.get(current_floor)
			if treasure_room and _maze_cells.size() > 5:
				var cell: Vector2i = _maze_cells[randi_range(2, _maze_cells.size() - 2)]
				_add_dungeon_cache(treasure_room, cell, current_floor)
		"CAVE_IN":
			EventBus.toast.emit("CAVE-IN! Dust and falling stone shake the passage. Find cover!", "warning")
			var cave_room: Node3D = _rooms.get(current_floor)
			if cave_room:
				var player: Node3D = GameManager.player
				if player and player.global_position.distance_to(cave_room.global_position) < 80.0:
					VFX.burst(cave_room, player.global_position + Vector3(0, 2.0, 0), Color(0.55, 0.48, 0.38), 34, 5.0, 0.08)
					if player.has_method("take_damage"):
						player.take_damage(12.0 + float(current_floor) * 0.8, self)
		"ELITE_PATROL":
			EventBus.toast.emit("An elite patrol has found your trail!", "warning")
			var patrol_room: Node3D = _rooms.get(current_floor)
			if patrol_room and _maze_cells.size() > 3:
				var patrol: Dictionary = _random_floor_monster(current_floor)
				for i in range(2):
					var patrol_cell: Vector2i = _maze_cells[randi_range(1, _maze_cells.size() - 2)]
					_spawn_in_room(patrol_room, current_floor, str(patrol.id), false, "Patrol " + str(patrol.name), float(patrol.hp) * 1.45, float(patrol.dmg) * 1.25, patrol.color, _difficulty(current_floor) * 1.1, patrol_cell)
		"SUPPLY_STASH":
			EventBus.toast.emit("A lost expedition's supply stash has been discovered!", "loot")
			var expedition: Node = get_node_or_null("/root/DungeonExpedition")
			if expedition:
				expedition.restore_supplies(2)
		"SPIRIT_TIDE":
			_floor_affix = "Spirit Tide"
			EventBus.toast.emit("Spirit Tide floods this civilization's ley-lines. Cultivation feels unusually potent, but hostile techniques are intensified.", "levelup")
			var player: Node3D = GameManager.player
			if player:
				var spirit_value: Variant = player.get("spiritual_energy")
				var spirit_max: Variant = player.get("max_spiritual_energy")
				if spirit_value != null and spirit_max != null:
					player.set("spiritual_energy", minf(float(spirit_max), float(spirit_value) + 18.0))
		"ANCIENT_WARDEN":
			_floor_affix = "Ancient Warden"
			EventBus.toast.emit("An ancient warden has awakened to defend the lost district!", "warning")
			var warden_room: Node3D = _rooms.get(current_floor)
			if warden_room and _maze_cells.size() > 4:
				var warden_data: Dictionary = _random_floor_monster(current_floor)
				var warden_cell: Vector2i = _maze_cells[randi_range(2, _maze_cells.size() - 2)]
				var warden: Node = _spawn_in_room(warden_room, current_floor, str(warden_data.id), false, "Ancient Warden: " + str(warden_data.name), float(warden_data.hp) * 3.2, float(warden_data.dmg) * 1.7, Color(0.82,0.62,1.0), _difficulty(current_floor) * 1.6, warden_cell)
				if warden:
					warden.set_meta("dungeon_warden", true)
					warden.set_meta("rare_encounter", true)

func _build_entrance() -> void:
	# Entrance stays in the REAL overworld (child offset compensates for DUNGEON_ORIGIN)
	var c: Vector2 = Constants.SPAWN_XZ + Vector2(0.0, 11.0)
	var h: float = _noise.get_height(c.x, c.y)
	_entrance = Area3D.new()
	_entrance.name = "DungeonEntrance"
	_entrance.collision_layer = Constants.LAYER_WORLD
	_entrance.collision_mask = 0
	# World position desired: (c.x, h, c.y). Our node is at DUNGEON_ORIGIN, so local = world - origin
	_entrance.position = Vector3(c.x, h, c.y)
	_entrance.add_to_group("interactable")
	_entrance.set_meta("interact_range", 3.8)
	# Weathered stone portal embedded into the ground, not a floating doorway.
	var stone_mat := StandardMaterial3D.new()
	stone_mat.albedo_color = Color(0.19, 0.18, 0.21)
	stone_mat.roughness = 1.0
	for x in [-1.75, 1.75]:
		var jamb := MeshInstance3D.new()
		var jm := BoxMesh.new()
		jm.size = Vector3(0.65, 3.1, 0.8)
		jamb.mesh = jm
		jamb.material_override = stone_mat
		jamb.position = Vector3(x, 1.55, 0)
		_entrance.add_child(jamb)
	var lintel := MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(4.2, 0.75, 1.0)
	lintel.mesh = lm
	lintel.material_override = stone_mat
	lintel.position = Vector3(0, 3.05, 0)
	_entrance.add_child(lintel)
	var portal := MeshInstance3D.new()
	var portal_mesh := QuadMesh.new()
	portal_mesh.size = Vector2(2.75, 2.45)
	portal.mesh = portal_mesh
	var portal_mat := StandardMaterial3D.new()
	portal_mat.albedo_color = Color(0.025, 0.015, 0.045)
	portal_mat.emission_enabled = true
	portal_mat.emission = Color(0.22, 0.08, 0.38)
	portal_mat.emission_energy_multiplier = 1.4
	portal_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	portal.material_override = portal_mat
	portal.position = Vector3(0, 1.45, -0.12)
	_entrance.add_child(portal)
	var portal_light := OmniLight3D.new()
	portal_light.light_color = Color(0.42, 0.18, 0.8)
	portal_light.light_energy = 1.6
	portal_light.omni_range = 6.0
	portal_light.position = Vector3(0, 1.7, 1.0)
	_entrance.add_child(portal_light)
	var label := Label3D.new()
	label.text = "Depths of Elyndor (%d Floors)" % FLOORS
	label.font_size = 42
	label.position.y = 3.6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_entrance.add_child(label)
	_entrance.set_script(load("res://entities/dungeon_entrance.gd"))
	var world_root: Node = get_tree().current_scene
	if world_root == null:
		world_root = get_parent()
	world_root.add_child(_entrance)
	
	# A soft column and ground ring make the entrance easy to spot. The column is
	# additive and fades to nothing at the tip, so it reads as a magical updraft
	# rather than a solid purple blade in the landscape.
	var beacon := MeshInstance3D.new()
	var beacon_mesh := CylinderMesh.new()
	beacon_mesh.top_radius = 0.16
	beacon_mesh.bottom_radius = 0.62
	beacon_mesh.height = 10.5
	beacon_mesh.radial_segments = 14
	beacon.mesh = beacon_mesh
	var beacon_mat := ShaderMaterial.new()
	beacon_mat.shader = load("res://shaders/beacon.gdshader")
	beacon_mat.set_shader_parameter("beam_color", Color(0.50, 0.30, 0.95))
	beacon_mat.set_shader_parameter("strength", 0.78)
	beacon.material_override = beacon_mat
	beacon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beacon.position = Vector3(0, 5.4, 0.65)
	_entrance.add_child(beacon)
	# A faint inner core gives the column depth without another light source.
	var core := MeshInstance3D.new()
	var core_mesh := CylinderMesh.new()
	core_mesh.top_radius = 0.05
	core_mesh.bottom_radius = 0.19
	core_mesh.height = 8.5
	core_mesh.radial_segments = 10
	core.mesh = core_mesh
	core.material_override = beacon_mat
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	core.position = Vector3(0, 4.6, 0.65)
	_entrance.add_child(core)
	var ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 2.25
	ring_mesh.outer_radius = 2.55
	ring_mesh.rings = 32
	ring.mesh = ring_mesh
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color(0.58, 0.36, 0.92, 0.75)
	ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ring_mat.emission_enabled = true
	ring_mat.emission = Color(0.34, 0.14, 0.70)
	ring_mat.emission_energy_multiplier = 0.8
	ring.material_override = ring_mat
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ring.position.y = 0.12
	_entrance.add_child(ring)
	var trigger_shape := CollisionShape3D.new()
	var trigger := SphereShape3D.new()
	trigger.radius = 3.8
	trigger_shape.shape = trigger
	_entrance.add_child(trigger_shape)
	_entrance.set_meta("interact_range", 5.0)
	print("[Dungeon] Entrance placed at %s, near the starting path" % str(_entrance.global_position))

func _difficulty(f: int) -> float:
	return 1.0 + float(f) * 0.12 + pow(float(f) / float(maxi(FLOORS - 1, 1)), 1.6) * 4.0

func _central_hall_center() -> Vector3:
	return _maze_cell_position(Vector2i(MAZE_CENTER, MAZE_CENTER))

func _boss_arena_center() -> Vector3:
	return _maze_cell_position(Vector2i(MAZE_CENTER, MAZE_GRID - 2))

func _ensure_room(f: int) -> Node3D:
	if _rooms.has(f):
		_generate_maze(f)
		return _rooms[f]
	var room := Node3D.new()
	room.name = "Floor_%d" % (f + 1)
	room.set_meta("dungeon_floor", f)
	room.visible = false
	# Local to dungeon root (already at DUNGEON_ORIGIN)
	room.position = Vector3(0, -float(f) * FLOOR_VERTICAL_SPACING, 0)
	_build_room_mesh(room, f)
	add_child(room)
	_rooms[f] = room
	return room

func _floor_palette(floor_i: int) -> Dictionary:
	var band: int = int(floor_i / 10)
	var palettes: Array = [
		{"stone": Color(0.25, 0.24, 0.22), "trim": Color(0.42, 0.39, 0.34), "glow": Color(1.0, 0.62, 0.31), "accent": Color(0.42, 0.31, 0.22), "name": "The Ancient Labyrinth", "civilization": "The Gilded Concord", "history": "The Concord united the first surface kingdoms beneath a single crown. Its oath-halls became a refuge when the sky wars began.", "puzzle_hint": "The crown's four vows were spoken in sequence", "hazard": "Falling masonry", "hazard_text": "Hairline cracks race across the lintel before stone fragments fall.", "relic": "bronze_charter", "inhabitant": "bronze_sentinel"},
		{"stone": Color(0.15, 0.22, 0.17), "trim": Color(0.29, 0.38, 0.28), "glow": Color(0.52, 0.92, 0.43), "accent": Color(0.24, 0.48, 0.29), "name": "The Living Caverns", "civilization": "The Verdant Choir", "history": "The Choir learned to cultivate living stone and fungal memory. Their halls grew instead of being built, and their songs guided migrating beasts.", "puzzle_hint": "The roots remember the four notes of the first growth-song", "hazard": "Spore bloom", "hazard_text": "A luminous puff of spores bursts from a dormant pod.", "relic": "choir_seed", "inhabitant": "spore_moth"},
		{"stone": Color(0.15, 0.20, 0.25), "trim": Color(0.32, 0.43, 0.51), "glow": Color(0.28, 0.78, 1.0), "accent": Color(0.18, 0.48, 0.62), "name": "The Crystal Depths", "civilization": "The Prism Enclave", "history": "Prism scholars mapped the world's hidden light and stored memories inside resonant crystal. Their observatories could bend beams around corners.", "puzzle_hint": "Trace the four facets in the order their light was split", "hazard": "Prism backlash", "hazard_text": "A charged crystal refracts a beam through the chamber.", "relic": "prism_heart", "inhabitant": "prism_stalker"},
		{"stone": Color(0.27, 0.23, 0.19), "trim": Color(0.48, 0.40, 0.30), "glow": Color(0.88, 0.67, 0.36), "accent": Color(0.53, 0.38, 0.24), "name": "The Forgotten Kingdom", "civilization": "The Sepulchral Court", "history": "The Court buried its monarchs standing, each facing the throne they swore to protect. Their oath-bound hounds still patrol the royal roads.", "puzzle_hint": "Repeat the funeral procession's four bell-signals", "hazard": "Cursed epitaph", "hazard_text": "A royal epitaph flares and releases a pulse of grave energy.", "relic": "king_signet", "inhabitant": "grave_hound"},
		{"stone": Color(0.25, 0.13, 0.10), "trim": Color(0.48, 0.24, 0.16), "glow": Color(1.0, 0.32, 0.08), "accent": Color(0.64, 0.18, 0.07), "name": "The Ember Depths", "civilization": "The Cinder Dominion", "history": "The Dominion forged weapons in volcanic vents and cooled them in subterranean rivers. Its smith-priests bound fire spirits into their great engines.", "puzzle_hint": "Follow the four stages of the forge: spark, flame, white heat, quench", "hazard": "Magma vent", "hazard_text": "A pressure vent erupts after a deep metallic hiss.", "relic": "ember_insignia", "inhabitant": "ember_wyrm"},
		{"stone": Color(0.20, 0.24, 0.29), "trim": Color(0.42, 0.50, 0.58), "glow": Color(0.62, 0.84, 1.0), "accent": Color(0.35, 0.50, 0.65), "name": "The Frozen Hollow", "civilization": "The Glacial Monastery", "history": "Monks of the Hollow preserved memories in clear ice, believing a calm mind could outlast empires. Their mirror halls trained guardians to read movement before it began.", "puzzle_hint": "Recall the four reflections from the monastery's winter rite", "hazard": "Rime slick", "hazard_text": "A thin sheet of frost spreads across the flagstones.", "relic": "glacier_scripture", "inhabitant": "frost_lynx"},
		{"stone": Color(0.13, 0.19, 0.23), "trim": Color(0.28, 0.37, 0.43), "glow": Color(0.30, 0.72, 0.88), "accent": Color(0.16, 0.40, 0.52), "name": "The Drowned City", "civilization": "The Thalassian Crown", "history": "The Thalassian Crown ruled a chain of sunken ports. Tide engineers built pressure locks and coral towers, sharing the deep with great sea-beasts.", "puzzle_hint": "Turn the four tide markers from slack water to spring tide", "hazard": "Undertow channel", "hazard_text": "A sudden current surges through a cracked pressure conduit.", "relic": "drowned_signet", "inhabitant": "reef_crab"},
		{"stone": Color(0.17, 0.21, 0.15), "trim": Color(0.32, 0.40, 0.27), "glow": Color(0.65, 0.90, 0.42), "accent": Color(0.26, 0.45, 0.20), "name": "The Worldroot", "civilization": "The Worldroot Communion", "history": "The Communion tended the roots of the elder world-tree. They carved no stone; every hall was coaxed from living wood and protected by rootbound keepers.", "puzzle_hint": "Repeat the four seasons of the root's awakening", "hazard": "Thorn snare", "hazard_text": "A buried root tightens and snaps upward through the soil.", "relic": "worldroot_sapling", "inhabitant": "rootbound_guardian"},
		{"stone": Color(0.10, 0.09, 0.14), "trim": Color(0.24, 0.22, 0.31), "glow": Color(0.47, 0.36, 0.85), "accent": Color(0.27, 0.18, 0.46), "name": "The Abyss", "civilization": "The Starless Court", "history": "The Starless Court studied the spaces between stars and learned to hide entire palaces in folded shadow. Its chroniclers feared that names could attract the things beyond.", "puzzle_hint": "Remember the four phases of the eclipse that sealed the court", "hazard": "Void pulse", "hazard_text": "The darkness contracts, then releases a concussive wave.", "relic": "starless_crown", "inhabitant": "void_jelly"},
		{"stone": Color(0.16, 0.12, 0.19), "trim": Color(0.37, 0.26, 0.45), "glow": Color(0.95, 0.58, 0.92), "accent": Color(0.52, 0.30, 0.62), "name": "The Ancient Realm", "civilization": "The Astral Archive", "history": "The Archive gathered the knowledge of all nine earlier peoples. Its astronomer-kings recorded a map of the world before the continents settled.", "puzzle_hint": "Reconstruct the four constellations of the Archive's founding", "hazard": "Astral convergence", "hazard_text": "A star-marked seal collapses its orbit in a brief burst of energy.", "relic": "celestial_codex", "inhabitant": "astral_scribe"}
	]
	return palettes[mini(band, palettes.size() - 1)]

func _make_box(parent: Node, node_name: String, pos: Vector3, size: Vector3, color: Color, emission: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.88
	if emission:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 1.8
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _add_torch(parent: Node3D, pos: Vector3, glow: Color) -> void:
	_make_box(parent, "IronTorchBracket", pos, Vector3(0.18, 0.55, 0.18), Color(0.12, 0.11, 0.10))
	var flame := MeshInstance3D.new()
	var fm := SphereMesh.new()
	fm.radius = 0.22
	fm.height = 0.48
	flame.mesh = fm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = glow
	mat.emission_enabled = true
	mat.emission = glow
	mat.emission_energy_multiplier = 3.0
	flame.material_override = mat
	flame.position = pos + Vector3(0, 0.38, 0)
	parent.add_child(flame)
	var light := OmniLight3D.new()
	light.light_color = glow
	light.position = pos + Vector3(0, 0.55, 0)
	parent.add_child(light)
	_configure_dungeon_light(light, 2.2, 11.0, false)

func _configure_dungeon_light(light: OmniLight3D, base_energy: float, base_range: float, cinematic_shadow: bool = false) -> void:
	light.add_to_group("dungeon_quality_light")
	light.set_meta("quality_base_energy", base_energy)
	light.set_meta("quality_base_range", base_range)
	light.set_meta("quality_cinematic_shadow", cinematic_shadow)
	var cycle: Node = get_tree().get_first_node_in_group("day_night")
	var quality_level: int = clampi(int(cycle.get("quality")) if cycle else 2, 0, 3)
	var range_scales: Array[float] = [0.78, 0.90, 1.0, 1.0]
	light.light_energy = base_energy
	light.omni_range = base_range * range_scales[quality_level]
	light.shadow_enabled = cinematic_shadow and quality_level >= 3

func _add_corridor_fill_light(parent: Node3D, pos: Vector3, glow: Color) -> void:
	var light := OmniLight3D.new()
	light.name = "SoftCorridorFill"
	light.light_color = glow.lerp(Color(0.82, 0.88, 1.0), 0.18)
	light.position = pos
	parent.add_child(light)
	light.add_to_group("dungeon_corridor_fill_light")
	_configure_dungeon_light(light, 1.05, 15.0, false)
	var cycle: Node = get_tree().get_first_node_in_group("day_night")
	if cycle and int(cycle.get("quality")) == 0:
		light.visible = false

func _make_cylinder(parent: Node, node_name: String, pos: Vector3, top_radius: float, bottom_radius: float, height: float, color: Color, emission: bool = false, segments: int = 12) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = top_radius
	cylinder.bottom_radius = bottom_radius
	cylinder.height = height
	cylinder.radial_segments = segments
	instance.mesh = cylinder
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.78
	material.metallic = 0.18 if emission else 0.06
	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.15
	instance.material_override = material
	instance.position = pos
	parent.add_child(instance)
	return instance

func _add_dungeon_ring(parent: Node, node_name: String, pos: Vector3, inner_radius: float, outer_radius: float, color: Color, emission: bool = false) -> MeshInstance3D:
	var ring := MeshInstance3D.new()
	ring.name = node_name
	var torus := TorusMesh.new()
	torus.inner_radius = inner_radius
	torus.outer_radius = outer_radius
	torus.rings = 36
	torus.ring_segments = 10
	ring.mesh = torus
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.38
	material.metallic = 0.42
	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.2
	ring.material_override = material
	ring.position = pos
	parent.add_child(ring)
	return ring

func _add_pillar(parent: Node3D, pos: Vector3, stone: Color, trim: Color) -> void:
	# Octagonal, tapered column with separate mouldings instead of a stack of cubes.
	_make_cylinder(parent, "PillarFoot", pos + Vector3(0, 0.28, 0), 0.62, 0.78, 0.56, trim, false, 8)
	_make_cylinder(parent, "PillarPlinth", pos + Vector3(0, 0.72, 0), 0.52, 0.62, 0.32, stone.lightened(0.06), false, 8)
	_make_cylinder(parent, "CarvedPillarShaft", pos + Vector3(0, 2.16, 0), 0.37, 0.52, 2.62, stone, false, 8)
	_make_cylinder(parent, "PillarNeck", pos + Vector3(0, 3.55, 0), 0.53, 0.42, 0.24, trim, false, 8)
	_make_cylinder(parent, "PillarCapital", pos + Vector3(0, 3.82, 0), 0.76, 0.53, 0.34, trim.lightened(0.05), false, 8)
	_make_cylinder(parent, "PillarAbacus", pos + Vector3(0, 4.08, 0), 0.78, 0.78, 0.18, stone.lightened(0.08), false, 8)

func _add_crystal(parent: Node3D, pos: Vector3, glow: Color, scale_value: float) -> void:
	var crystal := MeshInstance3D.new()
	var mesh := PrismMesh.new()
	mesh.size = Vector3(0.55, 1.8, 0.55) * scale_value
	crystal.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = glow.darkened(0.2)
	mat.emission_enabled = true
	mat.emission = glow
	mat.emission_energy_multiplier = 2.2
	crystal.material_override = mat
	crystal.position = pos + Vector3(0, 0.9 * scale_value, 0)
	crystal.rotation.z = randf_range(-0.18, 0.18)
	parent.add_child(crystal)

func _maze_key(a: Vector2i, b: Vector2i) -> String:
	if a.x < b.x or (a.x == b.x and a.y < b.y):
		return "%d,%d:%d,%d" % [a.x, a.y, b.x, b.y]
	return "%d,%d:%d,%d" % [b.x, b.y, a.x, a.y]

func _maze_has_link(a: Vector2i, b: Vector2i) -> bool:
	return _maze_links.has(_maze_key(a, b))

func _open_maze_block(x_min: int, x_max: int, y_min: int, y_max: int) -> void:
	# Remove internal walls inside a civic plaza/district while retaining its perimeter.
	for y in range(y_min, y_max + 1):
		for x in range(x_min, x_max + 1):
			var cell := Vector2i(x, y)
			if x < x_max:
				_maze_links[_maze_key(cell, cell + Vector2i.RIGHT)] = true
			if y < y_max:
				_maze_links[_maze_key(cell, cell + Vector2i.DOWN)] = true

func _generate_maze(floor_i: int) -> void:
	_maze_links.clear()
	_maze_cells.clear()
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 7919
	var owners: Dictionary = {}
	var groups: Dictionary = {}
	for y in range(MAZE_GRID):
		for x in range(MAZE_GRID):
			var cell := Vector2i(x, y)
			var owner := cell
			for rect: Rect2i in CHAMBER_RECTS:
				if rect.has_point(cell):
					owner = rect.position
			owners[cell] = owner
			if not groups.has(owner):
				groups[owner] = []
			groups[owner].append(cell)
			_maze_cells.append(cell)
	for rect: Rect2i in CHAMBER_RECTS:
		_open_maze_block(rect.position.x, rect.end.x - 1, rect.position.y, rect.end.y - 1)
	var boss_rect: Rect2i = CHAMBER_RECTS.back()
	var visited: Dictionary = {owners[MAZE_START]: true}
	var stack: Array[Vector2i] = [owners[MAZE_START]]
	var dirs: Array[Vector2i] = [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.UP, Vector2i.DOWN]
	# Chambers are single graph vertices, so dressing cannot disconnect a generated route.
	while not stack.is_empty():
		var choices: Array = []
		for cell: Vector2i in groups[stack.back()]:
			for direction in dirs:
				var next := cell + direction
				if not owners.has(next) or boss_rect.has_point(next) or visited.has(owners[next]):
					continue
				choices.append([cell, next])
		if choices.is_empty():
			stack.pop_back()
		else:
			var edge: Array = choices[rng.randi_range(0, choices.size() - 1)]
			_maze_links[_maze_key(edge[0], edge[1])] = true
			visited[owners[edge[1]]] = true
			stack.append(owners[edge[1]])
	for i in range(8):
		var cell: Vector2i = _maze_cells[rng.randi_range(0, _maze_cells.size() - 1)]
		var next := cell + dirs[rng.randi_range(0, 3)]
		if owners.has(next) and not boss_rect.has_point(cell) and not boss_rect.has_point(next):
			_maze_links[_maze_key(cell, next)] = true
	var distances := _maze_distances(MAZE_START)
	var best_distance := -1
	var entrance := Vector2i.ZERO
	var approach := Vector2i.ZERO
	for cell: Vector2i in groups[boss_rect.position]:
		for direction in dirs:
			var next := cell + direction
			if int(distances.get(next, -1)) > best_distance and not boss_rect.has_point(next):
				best_distance = int(distances[next])
				entrance = cell
				approach = next
	_maze_links[_maze_key(entrance, approach)] = true

func _maze_distances(start: Vector2i) -> Dictionary:
	var distances: Dictionary = {start: 0}
	var queue: Array[Vector2i] = [start]
	var index := 0
	while index < queue.size():
		var cell := queue[index]
		index += 1
		for direction in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.UP, Vector2i.DOWN]:
			var next: Vector2i = cell + direction
			if not distances.has(next) and _maze_has_link(cell, next):
				distances[next] = int(distances[cell]) + 1
				queue.append(next)
	return distances

func _maze_cell_position(cell: Vector2i) -> Vector3:
	var half_grid: float = float(MAZE_GRID - 1) * 0.5
	return Vector3((float(cell.x) - half_grid) * MAZE_CELL, 0.0, (float(cell.y) - half_grid) * MAZE_CELL)

func _add_maze_wall(parent: Node3D, pos: Vector3, size: Vector3, stone: Color, trim: Color) -> void:
	# Purpose-built masonry replaces the old natural boulder blobs: continuous
	# collision core, dressed ashlar blocks, mortar seams and heavy stone piers.
	var body := StaticBody3D.new()
	body.name = "MasonryDungeonWall"
	body.collision_layer = Constants.LAYER_WORLD
	body.collision_mask = 0
	body.position = pos
	var core := MeshInstance3D.new()
	core.name = "SolidMasonryCore"
	var core_mesh := BoxMesh.new()
	core_mesh.size = size
	core.mesh = core_mesh
	core.material_override = _cave_material(stone.darkened(0.10))
	body.add_child(core)
	var along_x: bool = size.x > size.z
	var length: float = maxf(size.x, size.z) - 0.18
	var thickness: float = minf(size.x, size.z)
	var brick_len: float = 4.8
	var columns: int = maxi(1, int(ceil(length / brick_len)))
	var rows: int = 4 if size.y > 6.0 else 2
	for side in [-1.0, 1.0]:
		for row in range(rows):
			var y: float = -size.y * 0.5 + (float(row) + 0.5) * size.y / float(rows)
			var offset: float = brick_len * 0.5 if row % 2 == 1 else 0.0
			for col in range(columns):
				var along: float = -length * 0.5 + (float(col) + 0.5) * length / float(columns) + offset
				if absf(along) > length * 0.5:
					continue
				var block := MeshInstance3D.new()
				var bm := BoxMesh.new()
				var block_length: float = length / float(columns) - 0.045
				bm.size = Vector3(block_length, size.y / float(rows) - 0.045, 0.12) if along_x else Vector3(0.12, size.y / float(rows) - 0.045, block_length)
				block.mesh = bm
				var tint: Color = stone.lightened(randf_range(0.015, 0.09)) if randf() < 0.58 else stone.darkened(randf_range(0.02, 0.08))
				block.material_override = _cave_material(tint)
				block.position = Vector3(along, y, side * (thickness * 0.5 + 0.035)) if along_x else Vector3(side * (thickness * 0.5 + 0.035), y, along)
				body.add_child(block)
	# Raised stone pilasters break up long corridor walls and frame the masonry.
	for side in [-1.0, 1.0]:
		for pier_i in range(0, columns + 1, 4):
			var along: float = -length * 0.5 + float(pier_i) * length / float(columns)
			var pier := MeshInstance3D.new()
			var pm := BoxMesh.new()
			pm.size = Vector3(0.34, size.y + 0.12, 0.24) if along_x else Vector3(0.24, size.y + 0.12, 0.34)
			pier.mesh = pm
			pier.material_override = _cave_material(trim.darkened(0.06))
			pier.position = Vector3(along, 0, side * (thickness * 0.5 + 0.09)) if along_x else Vector3(side * (thickness * 0.5 + 0.09), 0, along)
			body.add_child(pier)
	var shape := CollisionShape3D.new()
	var collision := BoxShape3D.new()
	collision.size = size
	shape.shape = collision
	body.add_child(shape)
	parent.add_child(body)

func _cave_material(color: Color) -> ShaderMaterial:
	var key: String = color.to_html(false)
	if _cave_materials.has(key):
		return _cave_materials[key]
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/cave_rock.gdshader")
	mat.set_shader_parameter("base_tint", color)
	_cave_materials[key] = mat
	return mat

func _add_cave_rock(parent: Node3D, pos: Vector3, scale_v: Vector3, color: Color) -> void:
	var rock := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radial_segments = 10
	mesh.rings = 7
	rock.mesh = mesh
	rock.scale = scale_v
	rock.position = pos
	rock.rotation = Vector3(randf_range(-0.25, 0.25), randf_range(0.0, TAU), randf_range(-0.25, 0.25))
	rock.material_override = _cave_material(color)
	parent.add_child(rock)

func _add_stalagmite(parent: Node3D, pos: Vector3, height: float, color: Color, hanging: bool = false) -> void:
	var spike := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.025
	mesh.bottom_radius = 0.35 * height
	mesh.height = height
	mesh.radial_segments = 7
	spike.mesh = mesh
	spike.material_override = _cave_material(color)
	spike.position = pos + Vector3(0, -height * 0.5 if hanging else height * 0.5, 0)
	if hanging:
		spike.rotation.z = PI
	parent.add_child(spike)

func _add_cave_mushroom(parent: Node3D, pos: Vector3, glow: Color, size_v: float) -> void:
	var stem := MeshInstance3D.new()
	var stem_mesh := CylinderMesh.new()
	stem_mesh.top_radius = 0.075 * size_v
	stem_mesh.bottom_radius = 0.11 * size_v
	stem_mesh.height = 0.48 * size_v
	stem.mesh = stem_mesh
	var stem_mat := StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.48, 0.43, 0.32)
	stem_mat.roughness = 0.95
	stem.material_override = stem_mat
	stem.position = pos + Vector3(0, 0.24 * size_v, 0)
	parent.add_child(stem)
	var cap := MeshInstance3D.new()
	var cap_mesh := SphereMesh.new()
	cap_mesh.radial_segments = 14
	cap_mesh.rings = 8
	cap.mesh = cap_mesh
	cap.scale = Vector3(0.34, 0.18, 0.34) * size_v
	cap.position = pos + Vector3(0, 0.48 * size_v, 0)
	var cap_mat := StandardMaterial3D.new()
	cap_mat.albedo_color = glow.darkened(0.18)
	cap_mat.roughness = 0.7
	cap_mat.emission_enabled = true
	cap_mat.emission = glow
	cap_mat.emission_energy_multiplier = 0.55
	cap.material_override = cap_mat
	parent.add_child(cap)

func _add_broken_column(parent: Node3D, pos: Vector3, stone: Color, height: float) -> void:
	var shaft := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.34
	mesh.bottom_radius = 0.48
	mesh.height = height
	mesh.radial_segments = 10
	shaft.mesh = mesh
	shaft.material_override = _cave_material(stone)
	shaft.position = pos + Vector3(0, height * 0.5, 0)
	shaft.rotation.z = randf_range(-0.12, 0.12)
	parent.add_child(shaft)
	_add_cave_rock(parent, pos + Vector3(randf_range(-0.3, 0.3), height + 0.1, randf_range(-0.3, 0.3)), Vector3(0.65, 0.28, 0.62), stone.lightened(0.08))

func _add_root_cluster(parent: Node3D, pos: Vector3, color: Color) -> void:
	for i in range(3):
		var root := MeshInstance3D.new()
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.045
		mesh.bottom_radius = 0.20 + float(i) * 0.035
		mesh.height = randf_range(3.0, 5.0)
		mesh.radial_segments = 8
		root.mesh = mesh
		root.material_override = _cave_material(color)
		root.position = pos + Vector3(randf_range(-0.8, 0.8), 1.0, randf_range(-0.8, 0.8))
		root.rotation = Vector3(randf_range(-0.18, 0.18), randf_range(0.0, TAU), randf_range(-0.65, 0.65))
		parent.add_child(root)

func _add_water_pool(parent: Node3D, pos: Vector3, tint: Color) -> void:
	var water := MeshInstance3D.new()
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(3.8, 2.7)
	water.mesh = mesh
	water.position = pos + Vector3(0, 0.34, 0)
	water.rotation.y = randf_range(-0.4, 0.4)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(tint.r, tint.g, tint.b, 0.68)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.metallic = 0.18
	mat.roughness = 0.16
	mat.emission_enabled = true
	mat.emission = tint.darkened(0.45)
	mat.emission_energy_multiplier = 0.18
	water.material_override = mat
	parent.add_child(water)

func _add_biome_detail(room: Node3D, floor_i: int, cells: Array[Vector2i], glow: Color, stone: Color, accent: Color) -> void:
	var band: int = int(floor_i / 10)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 32771
	for cell in cells:
		if cell == MAZE_START or cell == MAZE_GOAL or rng.randf() > 0.34:
			continue
		var center := _maze_cell_position(cell)
		var side_pos := center
		var edge: int = rng.randi_range(0, 3)
		if edge == 0:
			side_pos += Vector3(-3.7, 0.0, rng.randf_range(-3.0, 3.0))
		elif edge == 1:
			side_pos += Vector3(3.7, 0.0, rng.randf_range(-3.0, 3.0))
		elif edge == 2:
			side_pos += Vector3(rng.randf_range(-3.0, 3.0), 0.0, -3.7)
		else:
			side_pos += Vector3(rng.randf_range(-3.0, 3.0), 0.0, 3.7)
		match band:
			0:
				if rng.randf() < 0.65:
					_add_cave_rock(room, side_pos, Vector3(rng.randf_range(0.5, 1.2), rng.randf_range(0.25, 0.65), rng.randf_range(0.45, 1.0)), stone.darkened(0.08))
			1:
				for i in range(rng.randi_range(2, 4)):
					_add_cave_mushroom(room, side_pos + Vector3(rng.randf_range(-1.2, 1.2), 0.0, rng.randf_range(-1.2, 1.2)), glow, rng.randf_range(0.65, 1.25))
				_add_cave_rock(room, side_pos + Vector3(0, 0.15, 0), Vector3(1.0, 0.22, 0.8), accent.darkened(0.2))
			7:
				_add_root_cluster(room, side_pos + Vector3(0, 0.0, 0), accent)
				_add_cave_mushroom(room, side_pos + Vector3(0.8, 0.0, 0.4), glow, rng.randf_range(0.8, 1.3))
			2, 4, 8:
				for i in range(rng.randi_range(1, 3)):
					_add_stalagmite(room, side_pos + Vector3(rng.randf_range(-1.1, 1.1), 0.0, rng.randf_range(-1.1, 1.1)), rng.randf_range(1.0, 2.6), glow.darkened(0.25))
			3:
				_add_broken_column(room, side_pos, stone.darkened(0.12), rng.randf_range(1.8, 3.2))
				_add_cave_rock(room, side_pos + Vector3(0, 0.15, 0), Vector3(1.1, 0.7, 0.9), stone.darkened(0.12))
			6:
				if rng.randf() < 0.82:
					_add_water_pool(room, side_pos, glow)
				_add_cave_rock(room, side_pos + Vector3(0, 0.12, 0), Vector3(1.0, 0.35, 0.8), stone)
			5:
				for i in range(rng.randi_range(1, 2)):
					_add_stalagmite(room, side_pos + Vector3(rng.randf_range(-1.0, 1.0), 0.0, rng.randf_range(-1.0, 1.0)), rng.randf_range(1.1, 2.2), Color(0.65, 0.8, 0.9), false)
				_add_cave_rock(room, side_pos, Vector3(0.8, 0.35, 0.8), stone)
			9:
				_add_broken_column(room, side_pos, accent.darkened(0.22), rng.randf_range(2.6, 4.0))
				_add_cave_rock(room, side_pos, Vector3(1.2, 0.5, 1.0), accent.darkened(0.25))
				if rng.randf() < 0.4:
					_add_stalagmite(room, side_pos + Vector3(0, 0.0, 0), rng.randf_range(1.5, 3.0), glow.darkened(0.2))

func _add_civilization_monument(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# A distinct focal artifact in every ten-floor civilization band. The geometry
	# is deliberately placed beside the central route, leaving maze navigation clear.
	var band := clampi(int(floor_i / 10), 0, 9)
	var center := _maze_cell_position(Vector2i(MAZE_CENTER, MAZE_CENTER)) + Vector3(-5.2, 0.0, -4.6)
	match band:
		0: # Gilded Concord: oath pillar and bronze foundation.
			_add_pillar(room, center, stone, trim)
			_make_box(room, "ConcordOathPlaque", center + Vector3(0, 2.0, -0.58), Vector3(0.72, 1.15, 0.10), accent.lightened(0.2), true)
		1: # Verdant Choir: living roots and fungal memory.
			_add_root_cluster(room, center, accent)
			_add_cave_mushroom(room, center + Vector3(1.0, 0.0, 0.8), glow, 1.4)
		2: # Prism Enclave: refractive crystal altar.
			_add_crystal(room, center, glow, 1.9)
			_add_crystal(room, center + Vector3(0.9, 0.0, 0.4), accent, 0.85)
		3: # Sepulchral Court: royal memorial slab.
			_make_box(room, "SepulchralMemorial", center + Vector3(0, 1.25, 0), Vector3(1.35, 2.5, 0.48), stone.lightened(0.12))
			_make_box(room, "CourtCrest", center + Vector3(0, 2.0, -0.27), Vector3(0.52, 0.52, 0.08), trim, true)
		4: # Cinder Dominion: broken forge column with ember core.
			_add_broken_column(room, center, stone, 3.6)
			_add_crystal(room, center + Vector3(0.0, 0.0, 0.7), glow, 0.8)
		5: # Glacial Monastery: hanging ice teeth and a frost marker.
			_add_stalagmite(room, center + Vector3(0, 5.0, 0), 2.7, glow, true)
			_add_crystal(room, center, accent, 1.15)
		6: # Thalassian Crown: tidal pool and coral marker.
			_add_water_pool(room, center, glow)
			_add_cave_mushroom(room, center + Vector3(1.1, 0.0, 0.5), accent, 1.0)
		7: # Worldroot Communion: grown rather than quarried architecture.
			_add_root_cluster(room, center, trim)
			_add_root_cluster(room, center + Vector3(1.4, 0.0, 0.4), accent)
		8: # Starless Court: dark monolith with a void-lit seal.
			_make_box(room, "StarlessObelisk", center + Vector3(0, 2.0, 0), Vector3(0.8, 4.0, 0.8), stone.darkened(0.35))
			_make_box(room, "VoidSeal", center + Vector3(0, 2.1, -0.43), Vector3(0.34, 1.2, 0.06), glow, true)
		9: # Astral Archive: small orrery and star markers.
			var orrery := MeshInstance3D.new()
			var ring := TorusMesh.new()
			ring.inner_radius = 0.72
			ring.outer_radius = 0.82
			orrery.mesh = ring
			var ring_mat := StandardMaterial3D.new()
			ring_mat.albedo_color = trim
			ring_mat.metallic = 0.78
			ring_mat.roughness = 0.24
			orrery.material_override = ring_mat
			orrery.position = center + Vector3(0, 2.0, 0)
			orrery.rotation.x = PI * 0.5
			room.add_child(orrery)
			_add_crystal(room, center, glow, 0.7)

func _build_room_mesh(room: Node3D, floor_i: int) -> void:
	var palette: Dictionary = _floor_palette(floor_i)
	var stone: Color = palette["stone"]
	var trim: Color = palette["trim"]
	var glow: Color = palette["glow"]
	var accent: Color = palette["accent"]
	_generate_maze(floor_i)
	var span: float = MAZE_GRID * MAZE_CELL
	# One continuous stone foundation beneath the sprawling 13x13 underground city.
	var floor_body := StaticBody3D.new()
	floor_body.name = "LabyrinthFloorCollision"
	floor_body.collision_layer = Constants.LAYER_WORLD
	floor_body.collision_mask = 0
	var floor_mesh := MeshInstance3D.new()
	var floor_box := BoxMesh.new()
	floor_box.size = Vector3(span, 0.6, span)
	floor_mesh.mesh = floor_box
	var floor_mat := StandardMaterial3D.new()
	floor_mat.albedo_color = stone.darkened(0.16)
	floor_mat.roughness = 1.0
	floor_mesh.material_override = floor_mat
	floor_body.add_child(floor_mesh)
	var floor_shape := CollisionShape3D.new()
	var floor_collision := BoxShape3D.new()
	floor_collision.size = Vector3(span, 0.6, span)
	floor_shape.shape = floor_collision
	floor_body.add_child(floor_shape)
	room.add_child(floor_body)
	# Uneven worn slabs sit in the natural stone floor; slight overlaps hide a
	# checkerboard grid and make the floor read as carved bedrock and old paving.
	var floor_rng := RandomNumberGenerator.new()
	floor_rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 19391
	for x in range(MAZE_GRID):
		for z in range(MAZE_GRID):
			var center := _maze_cell_position(Vector2i(x, z))
			# Four cut-stone pavers per cell, with visible joints and worn edges.
			for px in range(2):
				for pz in range(2):
					var slab := MeshInstance3D.new()
					var slab_mesh := BoxMesh.new()
					slab_mesh.size = Vector3(MAZE_CELL * 0.48, 0.10, MAZE_CELL * 0.48)
					slab.mesh = slab_mesh
					var slab_tint: Color = stone.lightened(floor_rng.randf_range(0.015, 0.07)) if floor_rng.randf() < 0.55 else stone.darkened(floor_rng.randf_range(0.015, 0.06))
					slab.material_override = _cave_material(slab_tint)
					slab.position = center + Vector3((float(px) - 0.5) * MAZE_CELL * 0.5, 0.30, (float(pz) - 0.5) * MAZE_CELL * 0.5)
					slab.rotation.y = floor_rng.randf_range(-0.015, 0.015)
					room.add_child(slab)
	# Build outer perimeter and every closed internal edge. Open DFS links become doorways.
	for z in range(MAZE_GRID):
		for x in range(MAZE_GRID):
			var c := Vector2i(x, z)
			var center := _maze_cell_position(c)
			# Emit each shared wall exactly once. The previous left/right and up/down
			# checks duplicated every sealed internal edge and stacked collision bodies.
			# Walls run tall enough to meet the sealed ceiling overhead.
			if x == 0:
				_add_maze_wall(room, center + Vector3(-MAZE_CELL * 0.5, 4.2, 0), Vector3(0.8, 8.4, MAZE_CELL + 0.8), stone, trim)
			if z == 0:
				_add_maze_wall(room, center + Vector3(0, 4.2, -MAZE_CELL * 0.5), Vector3(MAZE_CELL + 0.8, 8.4, 0.8), stone, trim)
			if x == MAZE_GRID - 1 or not _maze_has_link(c, c + Vector2i.RIGHT):
				_add_maze_wall(room, center + Vector3(MAZE_CELL * 0.5, 4.2, 0), Vector3(0.8, 8.4, MAZE_CELL + 0.8), stone, trim)
			if z == MAZE_GRID - 1 or not _maze_has_link(c, c + Vector2i.DOWN):
				_add_maze_wall(room, center + Vector3(0, 4.2, MAZE_CELL * 0.5), Vector3(MAZE_CELL + 0.8, 8.4, 0.8), stone, trim)
	# The floor is a slab of architecture suspended in open air: a lattice of
	# light seals it overhead, a curtain of light closes its rim, and a slow
	# cloud sea hides the drop below.
	DungeonFloorDressing.build_floor_envelope(room, span, stone, trim, glow)
	DungeonFloorDressing.build_cloud_sea(room, span, glow)
	# Walled chambers with working doors turn the open maze into a city.
	_build_chamber_doors(room, floor_i, stone, trim, glow)
	# Landmark chambers, columns, torches and crystals make navigation readable.
	for c in _maze_cells:
		var center := _maze_cell_position(c)
		if (c.x * 3 + c.y * 5 + floor_i) % 3 == 0:
			_add_torch(room, center + Vector3(-4.25, 2.0, 0), glow)
		# A small deterministic number of shadowless fill sources lift the outer
		# passages without turning the entire 13x13 floor into flat ambient light.
		if (c.x * 11 + c.y * 7 + floor_i * 3) % 10 == 0 and c != MAZE_START and c != MAZE_GOAL:
			_add_corridor_fill_light(room, center + Vector3(0, 2.6, 0), glow)
		if (c.x + c.y * 2 + floor_i) % 7 == 0 and c != MAZE_START and c != MAZE_GOAL:
			_add_crystal(room, center + Vector3(3.5, 0.3, 3.5), glow, 0.75)
	# Entrance and boss chamber receive distinctive stonework.
	for side in [-1.0, 1.0]:
		_add_pillar(room, _maze_cell_position(MAZE_START) + Vector3(side * 3.6, 0, 3.4), trim.darkened(0.15), trim)
		_add_pillar(room, _maze_cell_position(MAZE_GOAL) + Vector3(side * 4.4, 0, -6.2), trim.darkened(0.15), trim)
	_add_dungeon_archway(room, _maze_cell_position(MAZE_START) + Vector3(0, 0, 3.6), stone, trim, glow, "DESCENT")
	_add_dungeon_archway(room, _maze_cell_position(MAZE_GOAL) + Vector3(0, 0, -6.6), stone, trim, glow, "WARDEN GATE")
	_add_dungeon_archway(room, Vector3(0, 0, 0), stone.darkened(0.08), trim, glow, "LOST HALL")
	_add_civilization_monument(room, floor_i, stone, trim, glow, accent)
	# Every floor is lit by its own underground sources, never by the overworld sun.
	var ambient := OmniLight3D.new()
	ambient.name = "FloorAmbientGlow"
	ambient.light_color = glow
	ambient.position = Vector3(0, 3.8, 0)
	room.add_child(ambient)
	_configure_dungeon_light(ambient, 0.30, 24.0, true)
	_add_floor_weather(room, floor_i, glow, stone)
	# Natural formations and biome-specific life turn each ten-floor region into
	# a distinct underground ecosystem rather than a recoloured stone box.
	_add_biome_detail(room, floor_i, _maze_cells, glow, stone, accent)
	_add_corridor_dressing(room, floor_i, stone, trim, glow, accent)
	_add_civilization_architecture(room, floor_i, stone, trim, glow, accent)
	_add_civilization_remnants(room, floor_i, stone, trim, glow, accent)
	var central_hall := _central_hall_center()
	_add_boss_arena_dressing(room, floor_i, stone, trim, glow)
	# Vault ribs spring from the piers and meet the coffered ceiling overhead.
	for rib_i in range(3):
		var rib_offset: float = (float(rib_i) - 1.0) * 15.0
		_add_vault_arch(room, central_hall + Vector3(0, 0, rib_offset), 44.0, 4.4, 3.95, trim.lightened(0.08))
		_add_vault_arch(room, _boss_arena_center() + Vector3(0, 0, rib_offset), 44.0, 4.4, 3.95, trim.lightened(0.08))
	# A few deliberately placed civic frames punctuate longer corridors.
	var framed_passages: int = 0
	for cell in _maze_cells:
		if framed_passages >= 3:
			break
		for direction in [Vector2i.RIGHT, Vector2i.DOWN]:
			if not _maze_has_link(cell, cell + direction):
				continue
			if cell.x >= MAZE_CENTER - 2 and cell.x <= MAZE_CENTER + 2 and cell.y >= MAZE_CENTER - 2 and cell.y <= MAZE_CENTER + 2:
				continue
			if (cell.x * 13 + cell.y * 7 + floor_i) % 9 != 0:
				continue
			var passage_center: Vector3 = (_maze_cell_position(cell) + _maze_cell_position(cell + direction)) * 0.5
			_add_passage_frame(room, passage_center, PI * 0.5 if direction == Vector2i.RIGHT else 0.0, stone, trim, glow)
			framed_passages += 1
	# The floor is sealed by light overhead, so nothing hangs from a cavern roof
	# any more; the ceiling is the lattice itself.
	# Add engraved-looking borders and inset rune markers to selected flagstones.
	for c in _maze_cells:
		var center: Vector3 = _maze_cell_position(c)
		if (c.x * 7 + c.y * 3 + floor_i) % 6 == 0 and c != MAZE_START and c != MAZE_GOAL:
			var rune_mat := StandardMaterial3D.new()
			rune_mat.albedo_color = glow.darkened(0.25)
			rune_mat.emission_enabled = true
			rune_mat.emission = glow
			rune_mat.emission_energy_multiplier = 0.65
			_make_box(room, "FloorRune", center + Vector3(0, 0.326, 0), Vector3(1.0, 0.018, 0.12), glow.darkened(0.2), true)
			var rune_cross := _make_box(room, "FloorRuneCross", center + Vector3(0, 0.327, 0), Vector3(0.12, 0.02, 1.0), glow.darkened(0.2), true)
			rune_cross.material_override = rune_mat
		if (c.x * 11 + c.y * 5 + floor_i) % 8 == 0:
			# Low rubble clusters sit against the walls, outside the main walking line.
			for r in range(3):
				var debris := MeshInstance3D.new()
				var rock := SphereMesh.new()
				rock.radius = 0.22 + 0.08 * float(r)
				rock.height = rock.radius * 1.4
				debris.mesh = rock
				var rubble_mat := StandardMaterial3D.new()
				rubble_mat.albedo_color = stone.darkened(0.05 + 0.06 * float(r))
				rubble_mat.roughness = 1.0
				debris.material_override = rubble_mat
				debris.position = center + Vector3(4.05 + float(r) * 0.18, 0.48, -3.8 + float(r) * 0.2)
				debris.scale = Vector3(1.2, 0.65, 0.9)
				debris.rotation.y = randf_range(-0.8, 0.8)
				room.add_child(debris)
	# Massive gate-side arch imposts and carved bands distinguish the boss approach.
	for side in [-1.0, 1.0]:
		_make_box(room, "GateArchFoot", _maze_cell_position(MAZE_GOAL) + Vector3(side * 2.8, 0.42, -4.6), Vector3(0.7, 0.84, 0.9), trim)
		_make_box(room, "GateArchRise", _maze_cell_position(MAZE_GOAL) + Vector3(side * 2.8, 2.35, -4.6), Vector3(0.42, 3.2, 0.65), stone.lightened(0.08))
	_make_box(room, "GateArchLintel", _maze_cell_position(MAZE_GOAL) + Vector3(0, 4.05, -4.6), Vector3(6.0, 0.55, 0.85), trim)
	# Floor-specific atmospheric fog is local to the chamber, not the overworld.
	var dust := GPUParticles3D.new()
	dust.name = "FloatingDungeonDust"
	dust.amount = 90
	dust.lifetime = 8.0
	dust.position = Vector3(0, 2.4, 0)
	var particle_mesh := SphereMesh.new()
	particle_mesh.radius = 0.025
	particle_mesh.height = 0.05
	var particle_mat := StandardMaterial3D.new()
	particle_mat.albedo_color = glow.lightened(0.35)
	particle_mat.emission_enabled = true
	particle_mat.emission = glow
	particle_mat.emission_energy_multiplier = 0.35
	dust.draw_pass_1 = particle_mesh
	dust.material_override = particle_mat
	var process_mat := ParticleProcessMaterial.new()
	process_mat.direction = Vector3(0.1, 0.3, 0.0)
	process_mat.spread = 180.0
	process_mat.initial_velocity_min = 0.03
	process_mat.initial_velocity_max = 0.16
	process_mat.gravity = Vector3(0, 0.015, 0)
	process_mat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process_mat.emission_box_extents = Vector3(span * 0.47, 2.0, span * 0.47)
	dust.process_material = process_mat
	room.add_child(dust)
	# Floor title and descent gate are at the end of the maze, beside the boss.
	var sign := Label3D.new()
	sign.text = "FLOOR %03d  |  %s" % [floor_i + 1, str(palette["name"])]
	sign.font_size = 30
	sign.position = _maze_cell_position(MAZE_GOAL) + Vector3(0, 7.6, -8.0)
	sign.modulate = glow
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	room.add_child(sign)
	# The way down: a ramp climbs to a landing in front of the lit descent gate.
	var stair := DungeonFloorDressing.build_stair_chamber(room, _maze_cell_position(MAZE_GOAL) + Vector3(3.5, 0, 0.5), stone, trim, glow, "DESCENT  ·  FLOOR %03d" % (floor_i + 2))
	stair.rotation.y = PI * 0.5
	var pad := Area3D.new()
	pad.name = "FloorExit"
	pad.position = _maze_cell_position(MAZE_GOAL) + Vector3(-1.2, 2.92, 0.5)
	pad.add_to_group("interactable")
	pad.set_meta("interact_range", 3.4)
	pad.set_meta("floor", floor_i)
	var pm := MeshInstance3D.new()
	var pmesh := CylinderMesh.new()
	pmesh.top_radius = 1.35
	pmesh.bottom_radius = 1.35
	pmesh.height = 0.18
	pm.mesh = pmesh
	var pmat := StandardMaterial3D.new()
	pmat.albedo_color = glow
	pmat.emission_enabled = true
	pmat.emission = glow
	pmat.emission_energy_multiplier = 1.8
	pm.material_override = pmat
	pad.add_child(pm)
	var pl := Label3D.new()
	pl.text = "DESCENT GATE"
	pl.font_size = 28
	pl.position.y = 0.9
	pl.modulate = glow
	pl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	pad.add_child(pl)
	pad.set_script(load("res://entities/dungeon_pad.gd"))
	room.add_child(pad)
	# The guardian's core hangs over the raid arena and tracks the boss.
	DungeonFloorDressing.build_guardian_crystal(room, _boss_arena_center(), glow)

# --- Chamber doors ---------------------------------------------------------

func _build_chamber_doors(room: Node3D, _floor_i: int, stone: Color, trim: Color, glow: Color) -> void:
	var framed: Dictionary = {}
	for chamber_i in range(CHAMBER_RECTS.size()):
		var rect: Rect2i = CHAMBER_RECTS[chamber_i]
		for y in range(rect.position.y, rect.end.y):
			for x in range(rect.position.x, rect.end.x):
				var cell := Vector2i(x, y)
				for direction in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.UP, Vector2i.DOWN]:
					var neighbour: Vector2i = cell + direction
					var key := _maze_key(cell, neighbour)
					if rect.has_point(neighbour) or not _maze_has_link(cell, neighbour) or framed.has(key):
						continue
					framed[key] = true
					var center := (_maze_cell_position(cell) + _maze_cell_position(neighbour)) * 0.5
					_add_passage_frame(room, center, PI * 0.5 if direction.x != 0 else 0.0, stone, trim, glow)
		var label := Label3D.new()
		label.name = "ChamberLabel"
		label.text = str(CHAMBER_LABELS[chamber_i])
		label.font_size = 24
		label.position = (_maze_cell_position(rect.position) + _maze_cell_position(rect.end - Vector2i.ONE)) * 0.5 + Vector3(0, 7.4, 0)
		label.modulate = glow.lightened(0.25)
		label.outline_size = 6
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		room.add_child(label)

# --- Corridor dressing -----------------------------------------------------

func _add_corridor_dressing(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# Wall brackets, banners, supply crates and floor medallions give the
	# corridors a lived-in, built feel instead of bare stone corridors.
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 77261
	for cell in _maze_cells:
		var center: Vector3 = _maze_cell_position(cell)
		if cell == MAZE_START or cell == MAZE_GOAL:
			continue
		for direction in [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP]:
			var neighbour: Vector2i = cell + direction
			if neighbour.x >= 0 and neighbour.y >= 0 and neighbour.x < MAZE_GRID and neighbour.y < MAZE_GRID and _maze_has_link(cell, neighbour):
				continue
			var wall_point: Vector3 = center
			var inward: Vector3 = Vector3.ZERO
			var along_x: bool = false
			match direction:
				Vector2i.RIGHT:
					wall_point += Vector3(MAZE_CELL * 0.5, 0, 0)
					inward = Vector3(-1, 0, 0)
				Vector2i.LEFT:
					wall_point += Vector3(-MAZE_CELL * 0.5, 0, 0)
					inward = Vector3(1, 0, 0)
				Vector2i.DOWN:
					wall_point += Vector3(0, 0, MAZE_CELL * 0.5)
					inward = Vector3(0, 0, -1)
					along_x = true
				_:
					wall_point += Vector3(0, 0, -MAZE_CELL * 0.5)
					inward = Vector3(0, 0, 1)
					along_x = true
			if rng.randf() < 0.46:
				var slide: float = rng.randf_range(-3.4, 3.4)
				var sconce_pos: Vector3 = wall_point + inward * 0.5
				sconce_pos += Vector3(slide, 2.35, 0) if along_x else Vector3(0, 2.35, slide)
				DungeonFloorDressing.build_sconce(room, sconce_pos, -inward, glow)
			elif rng.randf() < 0.12:
				var banner_pos: Vector3 = wall_point + inward * 0.5
				DungeonFloorDressing.build_banner(room, banner_pos, -inward, accent, glow)
		if rng.randf() < 0.1:
			var crate_pos: Vector3 = center + Vector3(rng.randf_range(-4.4, 4.4), 0.0, rng.randf_range(-4.4, 4.4))
			DungeonFloorDressing.build_supply_crate(room, crate_pos, rng.randf_range(-PI, PI), trim.darkened(0.25))
	DungeonFloorDressing.build_floor_medallion(room, _central_hall_center(), glow, 7.6)
	DungeonFloorDressing.build_floor_medallion(room, _boss_arena_center(), glow, 6.4)
	DungeonFloorDressing.build_floor_medallion(room, _maze_cell_position(MAZE_START), glow, 4.2)

func _add_civilization_remnants(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# Small human-scale traces make the ruined districts feel inhabited before
	# their collapse: benches, archive cases, standards and devotional objects.
	var band: int = int(floor_i / 10)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 94727
	var candidates: Array[Vector2i] = []
	for cell in _maze_cells:
		if cell != MAZE_START and cell != MAZE_GOAL and cell.distance_to(MAZE_START) >= 2.0 and cell.distance_to(MAZE_GOAL) >= 2.0:
			candidates.append(cell)
	candidates.shuffle()
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.25, 0.17, 0.12) if band not in [2, 5, 8, 9] else trim.darkened(0.22)
	wood.roughness = 0.93
	for detail_i in range(mini(7, candidates.size())):
		var center: Vector3 = _maze_cell_position(candidates[detail_i])
		var side: float = -1.0 if detail_i % 2 == 0 else 1.0
		var pos: Vector3 = center + Vector3(side * rng.randf_range(3.2, 3.75), 0.0, rng.randf_range(-3.0, 3.0))
		match (band + detail_i) % 7:
			0:
				# Collapsed records desk and its scattered drawers.
				var desk := _make_box(room, "CollapsedScribeDesk", pos + Vector3(0, 0.48, 0), Vector3(1.7, 0.14, 0.86), wood.albedo_color)
				desk.rotation.y = rng.randf_range(-0.2, 0.2)
				for leg_side in [-1.0, 1.0]:
					_make_box(room, "ScribeDeskLeg", pos + Vector3(leg_side * 0.68, 0.22, 0.28), Vector3(0.12, 0.48, 0.12), wood.albedo_color.darkened(0.12))
				_make_box(room, "ScatteredLedgerStone", pos + Vector3(-0.45, 0.61, -0.2), Vector3(0.46, 0.035, 0.32), trim, true)
			1:
				# Broken standard with a hanging, culture-coloured cloth panel.
				var pole := _make_cylinder(room, "BrokenCivicStandard", pos + Vector3(0, 1.35, 0), 0.055, 0.075, 2.7, trim, false, 8)
				pole.rotation.z = rng.randf_range(-0.14, 0.14)
				var cloth := _make_box(room, "TatteredCultureBanner", pos + Vector3(0.34, 2.0, 0.02), Vector3(0.68, 1.0, 0.06), accent.darkened(0.18), false)
				cloth.rotation.z = rng.randf_range(-0.25, 0.25)
				_make_box(room, "BannerSigil", pos + Vector3(0.34, 2.05, -0.04), Vector3(0.20, 0.20, 0.08), glow, true)
			2:
				# A small votive bowl and a ring of offerings.
				_make_cylinder(room, "CivicOfferingBowl", pos + Vector3(0, 0.42, 0), 0.48, 0.62, 0.82, trim, false, 12)
				_add_dungeon_ring(room, "OfferingInlay", pos + Vector3(0, 0.05, 0), 0.72, 0.82, glow, true)
				for offering_i in range(3):
					var angle: float = float(offering_i) * TAU / 3.0
					_make_box(room, "StoneOffering", pos + Vector3(cos(angle) * 0.82, 0.12, sin(angle) * 0.82), Vector3(0.22, 0.18, 0.28), stone.lightened(0.18))
			3:
				# A toppled archive cabinet with intact shelves and a few sealed scrolls.
				var cabinet := _make_box(room, "FallenArchiveCabinet", pos + Vector3(0, 0.42, 0), Vector3(1.1, 0.72, 0.7), stone.darkened(0.12))
				cabinet.rotation.z = rng.randf_range(-0.16, 0.16)
				for shelf_i in range(2):
					_make_box(room, "ArchiveShelfLip", pos + Vector3(0, 0.25 + float(shelf_i) * 0.25, -0.37), Vector3(1.0, 0.055, 0.08), trim)
				for scroll_i in range(3):
					var scroll := _make_cylinder(room, "SealedStoneScroll", pos + Vector3(-0.3 + float(scroll_i) * 0.28, 0.86, -0.18), 0.055, 0.055, 0.36, glow.darkened(0.18), false, 8)
					scroll.rotation.z = PI * 0.5
			4:
				# A cracked relief panel, small enough to read as an artifact not a wall.
				var relief := _make_box(room, "BrokenAncestorRelief", pos + Vector3(0, 1.0, 0), Vector3(1.25, 1.8, 0.22), stone.lightened(0.12))
				relief.rotation.y = rng.randf_range(-0.35, 0.35)
				_make_box(room, "ReliefCentralGlyph", pos + Vector3(0, 1.1, -0.14), Vector3(0.34, 0.62, 0.08), glow, true)
			5:
				# Ancient mechanism: a broken gear housing and exposed turning rings.
				var housing := _make_box(room, "AncientGearHousing", pos + Vector3(0, 0.62, 0), Vector3(1.45, 1.15, 0.48), stone.darkened(0.18))
				housing.rotation.y = rng.randf_range(-0.3, 0.3)
				for gear_i in range(2):
					var gear := _make_cylinder(room, "ExposedClockworkGear", pos + Vector3(-0.38 + float(gear_i) * 0.76, 0.72, -0.29), 0.38, 0.38, 0.10, trim, false, 12)
					gear.rotation.x = PI * 0.5
					for tooth_i in range(6):
						var angle := float(tooth_i) * TAU / 6.0
						_make_box(room, "GearTooth", pos + Vector3(-0.38 + float(gear_i) * 0.76 + cos(angle) * 0.42, 0.72 + sin(angle) * 0.42, -0.30), Vector3(0.12, 0.12, 0.12), glow.darkened(0.12), true)
			6:
				# Fallen lintel stones and a snapped column suggest a real structural collapse.
				for rubble_i in range(5):
					var rubble := _make_box(room, "CollapsedMasonryBlock", pos + Vector3(rng.randf_range(-0.9, 0.9), rng.randf_range(0.12, 0.42), rng.randf_range(-0.55, 0.55)), Vector3(rng.randf_range(0.25, 0.62), rng.randf_range(0.18, 0.55), rng.randf_range(0.25, 0.62)), stone.lightened(rng.randf_range(-0.04, 0.08)))
					rubble.rotation = Vector3(rng.randf_range(-0.3, 0.3), rng.randf_range(-0.8, 0.8), rng.randf_range(-0.25, 0.25))

func get_floor_story(floor_i: int) -> Dictionary:
	var safe_floor: int = clampi(floor_i, 0, FLOORS - 1)
	var band: int = int(safe_floor / 10)
	var palette: Dictionary = _floor_palette(safe_floor)
	return {
		"culture":str(palette.get("civilization", "Forgotten Civilization")),
		"record":str(CIVILIZATION_FLOOR_RECORDS[band][safe_floor % 10])
	}

func _add_civilization_architecture(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# Distinct civic landmarks give each ten-floor culture its own architectural language.
	var band: int = int(floor_i / 10)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + (floor_i + 1) * 61193
	var candidates: Array[Vector2i] = []
	for cell in _maze_cells:
		if cell != MAZE_START and cell != MAZE_GOAL:
			candidates.append(cell)
	candidates.shuffle()
	var culture_mat := StandardMaterial3D.new()
	culture_mat.albedo_color = trim.lightened(0.12)
	culture_mat.roughness = 0.48
	culture_mat.metallic = 0.48 if band in [0, 2, 4, 8, 9] else 0.18
	var glow_mat := StandardMaterial3D.new()
	glow_mat.albedo_color = glow
	glow_mat.emission_enabled = true
	glow_mat.emission = glow
	glow_mat.emission_energy_multiplier = 1.1
	glow_mat.roughness = 0.28
	for i in range(mini(5, candidates.size())):
		var cell: Vector2i = candidates[i]
		var center: Vector3 = _maze_cell_position(cell)
		var side: float = -1.0 if i % 2 == 0 else 1.0
		var pos: Vector3 = center + Vector3(side * rng.randf_range(3.0, 3.65), 0.0, rng.randf_range(-3.0, 3.0))
		match band:
			0: # Bronze civic pylons and oath plaques.
				for flank in [-1.0, 1.0]:
					var p := MeshInstance3D.new()
					var m := CylinderMesh.new(); m.top_radius = 0.22; m.bottom_radius = 0.34; m.height = 3.0
					p.mesh = m; p.material_override = culture_mat; p.position = pos + Vector3(flank * 0.65, 1.5, 0); room.add_child(p)
				_make_box(room, "ConcordOathPlaque", pos + Vector3(0, 2.85, 0), Vector3(1.9, 0.38, 0.3), glow, true)
			1: # Living roots arch around fungal lanterns.
				for root_i in range(3):
					var root := MeshInstance3D.new()
					var m := CylinderMesh.new(); m.top_radius = 0.06; m.bottom_radius = 0.32; m.height = 3.4 + float(root_i) * 0.3
					root.mesh = m; root.material_override = _cave_material(accent); root.position = pos + Vector3((float(root_i) - 1.0) * 0.48, 1.55, 0); root.rotation.z = (float(root_i) - 1.0) * 0.28; room.add_child(root)
				_add_cave_mushroom(room, pos + Vector3(0, 0.0, 0.45), glow, 1.3)
			2: # Six-sided crystal pylons and a rotating halo.
				var pylon := MeshInstance3D.new(); var prism := PrismMesh.new(); prism.size = Vector3(1.0, 3.1, 0.9); pylon.mesh = prism; pylon.material_override = glow_mat; pylon.position = pos + Vector3(0, 1.55, 0); pylon.rotation.y = rng.randf_range(0.0, TAU); room.add_child(pylon)
				var halo_root := Node3D.new(); halo_root.position = pos + Vector3(0, 1.5, 0); halo_root.set_script(load("res://entities/animated_dungeon_prop.gd")); halo_root.set("spin_speed", 0.42); halo_root.set("bob_height", 0.025); room.add_child(halo_root)
				var halo := MeshInstance3D.new(); var ring := TorusMesh.new(); ring.inner_radius = 0.7; ring.outer_radius = 0.76; halo.mesh = ring; halo.material_override = glow_mat; halo.rotation.x = PI * 0.5; halo_root.add_child(halo)
			3: # Royal sarcophagi and grave seals.
				var tomb := _make_box(room, "CourtSarcophagus", pos + Vector3(0, 0.55, 0), Vector3(1.7, 0.8, 2.1), stone.lightened(0.1)); tomb.rotation.y = rng.randf_range(-0.25, 0.25)
				_make_box(room, "RoyalSeal", pos + Vector3(0, 1.02, 0), Vector3(0.75, 0.10, 0.3), glow, true)
			4: # Foundry chimneys and slag channels.
				var vent := MeshInstance3D.new(); var m := CylinderMesh.new(); m.top_radius = 0.32; m.bottom_radius = 0.5; m.height = 2.1; vent.mesh = m; vent.material_override = culture_mat; vent.position = pos + Vector3(0, 1.05, 0); room.add_child(vent)
				_make_box(room, "ForgeSlagRun", pos + Vector3(0, 0.38, 0.72), Vector3(1.3, 0.08, 0.25), glow, true)
				for flank in [-1.0, 1.0]:
					_make_box(room, "ForgeRivet", pos + Vector3(flank * 0.38, 1.1, 0.25), Vector3(0.16, 1.5, 0.2), trim)
			5: # Frost monastery mirror obelisks.
				var mirror := _make_box(room, "FrostMirror", pos + Vector3(0, 1.5, 0), Vector3(0.22, 3.0, 1.5), glow, true); mirror.rotation.y = 0.25 * side
				_make_box(room, "MirrorPedestal", pos + Vector3(0, 0.38, 0), Vector3(1.4, 0.7, 1.2), stone.lightened(0.14))
			6: # Tide columns and branching coral crowns.
				for flank in [-1.0, 1.0]:
					var column := MeshInstance3D.new(); var m := CylinderMesh.new(); m.top_radius = 0.26; m.bottom_radius = 0.42; m.height = 2.7; column.mesh = m; column.material_override = culture_mat; column.position = pos + Vector3(flank * 0.5, 1.35, 0); room.add_child(column)
				_add_cave_mushroom(room, pos + Vector3(0, 0.0, 0.5), glow, 1.1)
			7: # Great roots form a living canopy.
				_add_root_cluster(room, pos, accent)
				_make_box(room, "RootMemoryPlate", pos + Vector3(0, 1.5, 0.6), Vector3(1.2, 0.16, 0.55), glow, true)
			8: # Starless black-glass menhirs and orbiting shards.
				var monolith := _make_box(room, "VoidMenhir", pos + Vector3(0, 1.7, 0), Vector3(0.72, 3.4, 0.55), stone.darkened(0.5)); monolith.rotation.z = side * 0.08
				var orbit := Node3D.new(); orbit.position = pos + Vector3(0, 1.8, 0); orbit.set_script(load("res://entities/animated_dungeon_prop.gd")); orbit.set("spin_speed", 0.55); room.add_child(orbit)
				for shard_i in range(3):
					_make_box(orbit, "VoidShard", Vector3(cos(float(shard_i) * TAU / 3.0) * 0.8, 0, sin(float(shard_i) * TAU / 3.0) * 0.8), Vector3(0.16, 0.45, 0.16), glow, true)
			9: # Astral archive orreries and star-map pillars.
				_make_box(room, "ArchiveOrreryBase", pos + Vector3(0, 0.45, 0), Vector3(1.9, 0.8, 1.9), trim)
				var orrery := Node3D.new(); orrery.position = pos + Vector3(0, 1.65, 0); orrery.set_script(load("res://entities/animated_dungeon_prop.gd")); orrery.set("spin_speed", 0.24); orrery.set("bob_height", 0.04); room.add_child(orrery)
				for ring_i in range(3):
					var ring_node := MeshInstance3D.new(); var ring_mesh := TorusMesh.new(); ring_mesh.inner_radius = 0.65 + float(ring_i) * 0.18; ring_mesh.outer_radius = ring_mesh.inner_radius + 0.05; ring_node.mesh = ring_mesh; ring_node.material_override = glow_mat; ring_node.rotation = Vector3(0.5 + float(ring_i) * 0.6, float(ring_i) * 0.45, 0); orrery.add_child(ring_node)
				var star := MeshInstance3D.new(); var star_mesh := SphereMesh.new(); star_mesh.radius = 0.18; star_mesh.height = 0.36; star.mesh = star_mesh; star.material_override = glow_mat; star.position.y = 0.95; orrery.add_child(star)


func _add_district_label(room: Node3D, text_value: String, position_value: Vector3, glow: Color) -> void:
	var label_node := Label3D.new()
	label_node.name = "CivilizationDistrictSign"
	label_node.text = text_value.to_upper()
	label_node.font_size = 24
	label_node.position = position_value
	label_node.modulate = glow.lightened(0.25)
	label_node.outline_size = 6
	label_node.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	room.add_child(label_node)

func _add_civic_building(room: Node3D, center: Vector3, stone: Color, trim: Color, glow: Color, variation: int) -> void:
	# Ruined but legible civic shell: foundation, back/side walls, pitched roof and lit door.
	var base := _make_box(room, "CivicBuildingFoundation", center + Vector3(0, 0.28, 0), Vector3(7.2, 0.56, 6.6), trim)
	base.rotation.y = float(variation % 4) * PI * 0.5
	_make_box(room, "CivicBuildingRearWall", center + Vector3(0, 2.0, -2.9), Vector3(7.0, 3.5, 0.5), stone)
	_make_box(room, "CivicBuildingSideWall", center + Vector3(-3.25, 1.8, 0), Vector3(0.5, 3.0, 5.8), stone.darkened(0.08))
	_make_box(room, "CivicBuildingSideWall", center + Vector3(3.25, 1.8, 0), Vector3(0.5, 3.0, 5.8), stone.darkened(0.08))
	var roof_left := _make_box(room, "CivicBuildingRoofSlope", center + Vector3(-1.72, 3.78, 0), Vector3(3.8, 0.38, 7.1), trim)
	roof_left.rotation.z = -0.48
	var roof_right := _make_box(room, "CivicBuildingRoofSlope", center + Vector3(1.72, 3.78, 0), Vector3(3.8, 0.38, 7.1), trim)
	roof_right.rotation.z = 0.48
	for side in [-1.0, 1.0]:
		_make_box(room, "CivicDoorJamb", center + Vector3(side * 1.05, 1.35, 3.0), Vector3(0.25, 2.7, 0.35), trim)
	_make_box(room, "CivicDoorLintel", center + Vector3(0, 2.7, 3.0), Vector3(2.4, 0.3, 0.4), trim)
	_make_box(room, "CivicDoorLight", center + Vector3(0, 1.25, 3.08), Vector3(1.25, 1.9, 0.08), glow.darkened(0.15), true)
	if variation % 2 == 0:
		_make_box(room, "CivicWindowGlow", center + Vector3(-2.2, 2.0, 0.28), Vector3(0.9, 0.8, 0.1), glow, true)
		_make_box(room, "CivicWindowGlow", center + Vector3(2.2, 2.0, 0.28), Vector3(0.9, 0.8, 0.1), glow, true)

func _add_market_stall(room: Node3D, center: Vector3, stone: Color, trim: Color, glow: Color, variation: int) -> void:
	_make_box(room, "CivicMarketCounter", center + Vector3(0, 0.68, 0), Vector3(5.4, 1.1, 2.1), stone.lightened(0.08))
	_make_box(room, "MarketCounterTrim", center + Vector3(0, 1.22, 1.08), Vector3(5.5, 0.14, 0.16), trim)
	for side in [-1.0, 1.0]:
		_make_cylinder(room, "MarketCanopyPost", center + Vector3(side * 2.45, 2.0, -0.65), 0.12, 0.16, 3.0, trim, false, 8)
	var canopy := _make_box(room, "MarketCanopy", center + Vector3(0, 3.35, -0.65), Vector3(5.8, 0.28, 3.0), glow.darkened(0.22 if variation % 2 == 0 else 0.08), true)
	canopy.rotation.z = 0.025 * float(variation % 3 - 1)
	for crate_i in range(2):
		_make_box(room, "MarketCargoCrate", center + Vector3(-1.35 + float(crate_i) * 2.7, 0.55, 1.7), Vector3(1.0, 1.0, 0.9), trim.darkened(0.18))

func _add_abandoned_civic_ruin(room: Node3D, center: Vector3, stone: Color, trim: Color, glow: Color, variation: int) -> void:
	# Broken roofline and collapsed masonry communicate an abandoned quarter.
	_make_box(room, "RuinFoundation", center + Vector3(0, 0.22, 0), Vector3(8.0, 0.44, 7.0), stone.darkened(0.12))
	for side in [-1.0, 1.0]:
		var remnant := _make_box(room, "RuinWallRemnant", center + Vector3(side * 3.3, 1.4, -2.2), Vector3(0.55, 2.8 + float(variation % 3) * 0.55, 5.2), trim.darkened(0.1))
		remnant.rotation.z = side * 0.05
	for i in range(5):
		var rubble := _make_box(room, "CollapsedCivicMasonry", center + Vector3(-2.5 + float(i) * 1.15, 0.42, 2.1 + float(i % 2) * 0.45), Vector3(1.3, 0.72, 1.0), stone.lightened(0.04 * float(i % 2)))
		rubble.rotation.y = float(i) * 0.27
	_make_box(room, "RuinMemorySeal", center + Vector3(0, 1.2, -2.45), Vector3(1.8, 0.16, 0.18), glow, true)

func _add_civilization_districts(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# Four named city quarters plus a transit ward surround the central forum and raid sanctum.
	var band: int = int(floor_i / 10)
	var west_exchange := _maze_cell_position(Vector2i(2, 4))
	var east_residential := _maze_cell_position(Vector2i(10, 4))
	var west_archive := _maze_cell_position(Vector2i(2, 8))
	var east_temple := _maze_cell_position(Vector2i(10, 8))
	var entrance_ward := _maze_cell_position(Vector2i(MAZE_CENTER, 1))
	_add_district_label(room, "The Transit Ward", entrance_ward + Vector3(0, 6.8, -4.5), glow)
	_add_district_label(room, "The Exchange Quarter", west_exchange + Vector3(0, 6.4, -8.0), glow)
	_add_district_label(room, "The Residential Ward", east_residential + Vector3(0, 6.4, -8.0), glow)
	_add_district_label(room, "The Abandoned Archive", west_archive + Vector3(0, 6.4, -8.0), glow)
	_add_district_label(room, "The Sacred Precinct", east_temple + Vector3(0, 6.4, -8.0), glow)
	# Entrance ward: broad gate markers and expedition waystones.
	for side in [-1.0, 1.0]:
		_add_pillar(room, entrance_ward + Vector3(side * 11.0, 0, -3.0), stone.lightened(0.08), trim)
		_add_dungeon_ring(room, "TransitWardSeal", entrance_ward + Vector3(side * 11.0, 0.42, 4.0), 1.0, 1.25, glow, true)
	# Exchange quarter: two market rows flank an open trading square.
	_add_market_stall(room, west_exchange + Vector3(-8.0, 0, -8.0), stone, trim, glow, 0)
	_add_market_stall(room, west_exchange + Vector3(8.0, 0, -8.0), stone, trim, accent, 1)
	_add_civic_building(room, west_exchange + Vector3(-8.0, 0, 8.0), stone, trim, glow, 2)
	# Residential quarter: recognisable house fronts face onto a shared street.
	_add_civic_building(room, east_residential + Vector3(-8.0, 0, -8.0), stone, trim, glow, 3)
	_add_civic_building(room, east_residential + Vector3(8.0, 0, -8.0), stone, trim, glow, 4)
	_add_civic_building(room, east_residential + Vector3(-8.0, 0, 8.0), stone.darkened(0.08), trim, glow, 5)
	# Archive quarter is visibly abandoned, with collapsed facades and memory seals.
	_add_abandoned_civic_ruin(room, west_archive + Vector3(-8.0, 0, -8.0), stone, trim, glow, 1)
	_add_abandoned_civic_ruin(room, west_archive + Vector3(8.0, 0, -8.0), stone.darkened(0.05), trim, glow, 2)
	_add_broken_column(room, west_archive + Vector3(8.0, 0, 8.0), stone, 2.4)
	# Sacred precinct: four altar pylons and a culture-specific centrepiece.
	for side in [-1.0, 1.0]:
		for depth in [-1.0, 1.0]:
			var p := east_temple + Vector3(side * 10.0, 0.0, depth * 9.0)
			_add_pillar(room, p, stone, trim)
			_add_dungeon_ring(room, "PrecinctPylonSeal", p + Vector3(0, 0.40, 0), 1.1, 1.3, glow, true)
	match band:
		1, 7:
			_add_root_cluster(room, east_temple, accent)
			_add_cave_mushroom(room, east_temple + Vector3(0, 0, 5), glow, 1.8)
		2, 9:
			_add_crystal(room, east_temple + Vector3(0, 0.4, 0), glow, 2.0)
		4:
			_add_make_shifted_brazier(room, east_temple, glow, trim)
		6:
			_add_water_pool(room, east_temple + Vector3(0, 0, 0), glow)
		8:
			var void_marker := _make_box(room, "StarlessPrecinctMenhir", east_temple + Vector3(0, 2.6, 0), Vector3(1.4, 5.2, 1.0), stone.darkened(0.55))
			void_marker.rotation.z = -0.07
		_:
			_make_cylinder(room, "PrecinctAltar", east_temple + Vector3(0, 1.15, 0), 1.1, 1.55, 1.8, trim, false, 12)
	# Each floor records a short piece of the district's fate in-world.
	var memorial := Label3D.new()
	memorial.name = "CivilizationEnvironmentalStory"
	memorial.text = "FLOOR %03d  •  %s\n%s" % [floor_i + 1, str(_floor_palette(floor_i).get("civilization", "Forgotten Civilization")), str(CIVILIZATION_FLOOR_RECORDS[band][floor_i % 10])]
	memorial.font_size = 15
	memorial.position = west_archive + Vector3(0, 2.1, 5.4)
	memorial.modulate = trim.lightened(0.25)
	memorial.outline_size = 4
	memorial.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	room.add_child(memorial)

func _add_make_shifted_brazier(room: Node3D, center: Vector3, glow: Color, trim: Color) -> void:
	_make_box(room, "CinderPrecinctForge", center + Vector3(0, 0.9, 0), Vector3(4.0, 1.8, 4.0), trim.darkened(0.28))
	_add_torch(room, center + Vector3(0, 1.7, 0), glow)

func _add_arch_beam(parent: Node3D, start: Vector3, finish: Vector3, radius: float, material_color: Color) -> void:
	var direction := finish - start
	if direction.length_squared() < 0.0001:
		return
	var beam := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius * 0.88
	mesh.bottom_radius = radius
	mesh.height = direction.length() + 0.08
	mesh.radial_segments = 8
	beam.mesh = mesh
	beam.material_override = _cave_material(material_color)
	beam.position = (start + finish) * 0.5
	beam.quaternion = Quaternion(Vector3.UP, direction.normalized())
	parent.add_child(beam)

func _add_vault_arch(room: Node3D, center: Vector3, width: float, spring_height: float, rise: float, color: Color) -> void:
	# Segmented stone ribs frame the overhead space without narrowing the playable floor.
	var segments: int = 12
	for i in range(segments):
		var a0: float = PI - PI * float(i) / float(segments)
		var a1: float = PI - PI * float(i + 1) / float(segments)
		var p0 := center + Vector3(cos(a0) * width * 0.5, spring_height + sin(a0) * rise, 0)
		var p1 := center + Vector3(cos(a1) * width * 0.5, spring_height + sin(a1) * rise, 0)
		_add_arch_beam(room, p0, p1, 0.26, color)
	_make_box(room, "VaultCrownKeystone", center + Vector3(0, spring_height + rise + 0.12, 0), Vector3(0.72, 0.38, 0.52), color.lightened(0.12))

func _add_passage_frame(room: Node3D, center: Vector3, rotate_y: float, stone: Color, trim: Color, glow: Color) -> void:
	var frame := Node3D.new()
	frame.name = "CivilizationPassageFrame"
	frame.position = center
	frame.rotation.y = rotate_y
	room.add_child(frame)
	for side in [-1.0, 1.0]:
		_make_box(frame, "PassagePier", Vector3(side * 3.65, 2.05, 0), Vector3(0.68, 4.1, 0.92), stone)
		_make_box(frame, "PassageFoot", Vector3(side * 3.65, 0.36, 0), Vector3(1.02, 0.72, 1.28), trim)
		_make_box(frame, "PassageCapital", Vector3(side * 3.65, 4.02, 0), Vector3(1.0, 0.36, 1.24), trim)
	_make_box(frame, "PassageLintel", Vector3(0, 4.12, 0), Vector3(8.0, 0.64, 1.05), trim)
	_make_box(frame, "PassageKeystone", Vector3(0, 4.55, 0), Vector3(0.82, 0.22, 1.12), glow, true)
	var light := OmniLight3D.new()
	light.name = "PassageAccentLight"
	light.light_color = glow
	light.light_energy = 0.34
	light.omni_range = 7.0
	light.position = Vector3(0, 3.45, -0.35)
	frame.add_child(light)

func _add_civilization_heart(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color, accent: Color) -> void:
	# One memorable monument in the shared central hall gives each ten-floor culture a strong identity.
	var band: int = int(floor_i / 10)
	var hub := _central_hall_center()
	_add_dungeon_ring(room, "MemoryHallOuterInlay", hub + Vector3(0, 0.365, 0), 18.8, 19.2, trim, false)
	_add_dungeon_ring(room, "MemoryHallInnerInlay", hub + Vector3(0, 0.372, 0), 13.0, 13.4, glow, true)
	for i in range(8):
		var angle: float = TAU * float(i) / 8.0
		var marker := _make_box(room, "MemoryHallRadialMark", hub + Vector3(cos(angle) * 16.0, 0.39, sin(angle) * 16.0), Vector3(2.8, 0.055, 0.28), trim.lightened(0.08))
		marker.rotation.y = -angle
	var center_plinth := _make_cylinder(room, "CivilizationMemoryPlinth", hub + Vector3(0, 0.72, 0), 3.6, 4.2, 0.62, stone.lightened(0.12), false, 10)
	center_plinth.rotation.y = 0.2
	match band:
		0: # Gilded Concord: oath obelisk and bronze crown.
			_make_cylinder(room, "ConcordOathObelisk", hub + Vector3(0, 4.0, 0), 0.9, 1.25, 6.4, trim.lightened(0.18), false, 8)
			_add_dungeon_ring(room, "ConcordCrownRing", hub + Vector3(0, 5.9, 0), 1.7, 1.9, glow, true)
			for side in [-1.0, 1.0]:
				_make_box(room, "ConcordOathWing", hub + Vector3(side * 2.0, 2.5, 0), Vector3(0.3, 3.2, 0.9), trim)
		1: # Verdant Choir: living root heart and luminous caps.
			_add_root_cluster(room, hub + Vector3(0, 0.2, 0), accent)
			for i in range(5):
				var angle: float = TAU * float(i) / 5.0
				_add_cave_mushroom(room, hub + Vector3(cos(angle) * 1.9, 0.0, sin(angle) * 1.9), glow, 1.0 + 0.15 * float(i % 2))
		2: # Prism Enclave: crystal spires and a suspended halo.
			for i in range(5):
				var angle: float = TAU * float(i) / 5.0
				_add_crystal(room, hub + Vector3(cos(angle) * 1.45, 0.38, sin(angle) * 1.45), glow.lightened(0.08), 0.78 if i % 2 == 0 else 1.08)
			_add_dungeon_ring(room, "PrismMemoryHalo", hub + Vector3(0, 4.0, 0), 3.0, 3.2, glow, true)
		3: # Sepulchral Court: a royal sarcophagus and four grave seals.
			var tomb := _make_box(room, "SepulchralRoyalTomb", hub + Vector3(0, 0.95, 0), Vector3(2.5, 1.0, 3.4), stone.lightened(0.12))
			tomb.rotation.y = 0.18
			_make_box(room, "SepulchralTombSeal", hub + Vector3(0, 1.52, 0), Vector3(1.3, 0.12, 0.35), glow, true)
			for side in [-1.0, 1.0]:
				for depth in [-1.0, 1.0]:
					_make_box(room, "GraveVowMarker", hub + Vector3(side * 2.25, 0.72, depth * 2.25), Vector3(0.42, 1.15, 0.42), trim)
		4: # Cinder Dominion: forge core, vent stacks and slag channels.
			_make_cylinder(room, "CinderForgeCore", hub + Vector3(0, 1.28, 0), 1.0, 1.34, 1.8, stone.darkened(0.28), false, 10)
			_add_dungeon_ring(room, "CinderForgeRunicRing", hub + Vector3(0, 0.42, 0), 1.55, 1.72, glow, true)
			for i in range(4):
				var angle: float = TAU * float(i) / 4.0
				_make_cylinder(room, "ForgeExhaustStack", hub + Vector3(cos(angle) * 2.6, 1.15, sin(angle) * 2.6), 0.24, 0.42, 1.7, trim, false, 8)
		5: # Glacial Monastery: a mirror shrine with ice-like blades.
			for i in range(4):
				var angle: float = TAU * float(i) / 4.0
				var mirror := _make_box(room, "GlacialMemoryMirror", hub + Vector3(cos(angle) * 2.0, 1.65, sin(angle) * 2.0), Vector3(0.2, 2.9, 1.25), glow, true)
				mirror.rotation.y = -angle
			_add_dungeon_ring(room, "GlacialMirrorSeal", hub + Vector3(0, 0.4, 0), 1.35, 1.48, Color(0.62, 0.84, 1.0), true)
		6: # Thalassian Crown: tidal basin and coral pylons.
			for i in range(4):
				var angle: float = TAU * float(i) / 4.0
				_add_water_pool(room, hub + Vector3(cos(angle) * 2.6, 0.0, sin(angle) * 2.6), glow)
				_make_cylinder(room, "TideMemoryColumn", hub + Vector3(cos(angle) * 1.35, 1.25, sin(angle) * 1.35), 0.22, 0.4, 1.8, trim, false, 9)
		7: # Worldroot Communion: an elder root rising from the deep.
			_add_root_cluster(room, hub + Vector3(0, 0.1, 0), accent.lightened(0.1))
			_add_cave_mushroom(room, hub + Vector3(-1.6, 0, 1.2), glow, 1.35)
			_add_cave_mushroom(room, hub + Vector3(1.7, 0, -1.0), glow, 1.15)
		8: # Starless Court: black menhir and orbiting void shards.
			var menhir := _make_box(room, "StarlessMemoryMenhir", hub + Vector3(0, 1.8, 0), Vector3(0.82, 3.6, 0.68), stone.darkened(0.48))
			menhir.rotation.z = -0.08
			var orbit := Node3D.new()
			orbit.name = "StarlessOrbitingMemory"
			orbit.position = hub + Vector3(0, 1.8, 0)
			orbit.set_script(load("res://entities/animated_dungeon_prop.gd"))
			orbit.set("spin_speed", 0.32)
			room.add_child(orbit)
			for i in range(4):
				var angle: float = TAU * float(i) / 4.0
				var shard := _make_box(orbit, "VoidMemoryShard", Vector3(cos(angle) * 2.0, sin(angle * 2.0) * 0.38, sin(angle) * 2.0), Vector3(0.18, 0.8, 0.22), glow, true)
				shard.rotation.z = angle * 0.3
		9: # Astral Archive: a layered orrery above a star map.
			var orrery := Node3D.new()
			orrery.name = "AstralMemoryOrrery"
			orrery.position = hub + Vector3(0, 1.75, 0)
			orrery.set_script(load("res://entities/animated_dungeon_prop.gd"))
			orrery.set("spin_speed", 0.18)
			orrery.set("bob_height", 0.035)
			room.add_child(orrery)
			for i in range(3):
				var orbit_ring := _add_dungeon_ring(orrery, "AstralMemoryOrbit", Vector3.ZERO, 1.1 + float(i) * 0.48, 1.17 + float(i) * 0.48, glow.lightened(0.08), true)
				orbit_ring.rotation = Vector3(0.35 + float(i) * 0.42, float(i) * 0.52, 0.2)
			_make_cylinder(room, "AstralStarMapPedestal", hub + Vector3(0, 0.46, 0), 1.45, 1.62, 0.28, trim, false, 12)
	var culture_label := Label3D.new()
	culture_label.name = "CivilizationHeartTitle"
	culture_label.text = str(_floor_palette(floor_i).get("civilization", "Forgotten Civilization")).to_upper()
	culture_label.font_size = 17
	culture_label.position = hub + Vector3(0, 7.4, 0)
	culture_label.modulate = glow.lightened(0.2)
	culture_label.outline_size = 5
	culture_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	room.add_child(culture_label)

func _add_boss_arena_dressing(room: Node3D, floor_i: int, stone: Color, trim: Color, glow: Color) -> void:
	var center := _boss_arena_center()
	_add_dungeon_ring(room, "BossArenaOuterSeal", center + Vector3(0, 0.375, 0), 18.8, 19.3, trim, false)
	_add_dungeon_ring(room, "BossArenaInnerSeal", center + Vector3(0, 0.385, 0), 11.8, 12.2, glow, true)
	_add_dungeon_ring(room, "BossArenaCoreTrace", center + Vector3(0, 0.395, 0), 5.0, 5.25, glow.lightened(0.15), true)
	for i in range(16):
		var angle: float = TAU * float(i) / 16.0
		var mark := _make_box(room, "BossArenaRadialSigil", center + Vector3(cos(angle) * 15.0, 0.40, sin(angle) * 15.0), Vector3(2.0, 0.055, 0.22), glow.darkened(0.12), true)
		mark.rotation.y = -angle
	for side in [-1.0, 1.0]:
		for depth in [-1.0, 1.0]:
			var p := center + Vector3(side * 20.0, 0.0, depth * 20.0)
			_add_pillar(room, p, stone.lightened(0.04), trim)
			var plinth := _make_box(room, "RaidSanctumPylonBase", p + Vector3(0, 0.35, 0), Vector3(4.0, 0.7, 4.0), trim)
			plinth.rotation.y = PI * 0.25
			var light := OmniLight3D.new()
			light.name = "BossArenaPylonLight"
			light.light_color = glow
			light.light_energy = 0.82
			light.omni_range = 18.0
			light.position = p + Vector3(0, 5.0, 0)
			room.add_child(light)
	var center_light := OmniLight3D.new()
	center_light.name = "BossArenaKeyLight"
	center_light.light_color = glow.lightened(0.18)
	center_light.light_energy = 1.05
	center_light.omni_range = 34.0
	center_light.position = center + Vector3(0, 7.0, 0)
	room.add_child(center_light)
	# Monumental rear dais makes the guardian chamber read as a sanctum, not an oversized corridor.
	var dais := _make_box(room, "RaidBossDais", center + Vector3(0, 0.28, 20.0), Vector3(27.0, 0.55, 5.0), stone.lightened(0.08))
	dais.rotation.y = 0.0
	_add_dungeon_ring(room, "RaidBossDaisSeal", center + Vector3(0, 0.64, 15.0), 7.2, 7.6, glow, true)

func _add_dungeon_archway(room: Node3D, center: Vector3, stone: Color, trim: Color, glow: Color, inscription: String) -> void:
	# Heavy lintel-and-pier construction gives each passage a readable monumental scale.
	for side in [-1.0, 1.0]:
		_make_box(room, "ArchPier", center + Vector3(side * 3.5, 2.25, 0), Vector3(0.9, 4.5, 1.25), stone)
		_make_box(room, "ArchFoot", center + Vector3(side * 3.5, 0.35, 0), Vector3(1.35, 0.7, 1.65), trim)
		_make_box(room, "ArchCapital", center + Vector3(side * 3.5, 4.25, 0), Vector3(1.4, 0.45, 1.7), trim)
	_make_box(room, "ArchLintel", center + Vector3(0, 4.35, 0), Vector3(7.8, 0.8, 1.6), trim)
	_make_box(room, "ArchKeystone", center + Vector3(0, 4.85, 0), Vector3(1.1, 0.35, 1.72), glow.darkened(0.28), true)
	var glyph := Label3D.new()
	glyph.text = inscription
	glyph.font_size = 22
	glyph.position = center + Vector3(0, 3.2, -0.84)
	glyph.modulate = glow.lightened(0.25)
	glyph.outline_size = 4
	glyph.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	room.add_child(glyph)

func _add_floor_weather(room: Node3D, floor_i: int, glow: Color, stone: Color) -> void:
	var band: int = int(floor_i / 10)
	var weather_names: Array[String] = ["dust motes", "spore drift", "crystal mist", "forgotten ash", "emberfall", "frost haze", "underground rain", "root pollen", "void vapour", "star-like motes"]
	_floor_weather = weather_names[mini(band, weather_names.size() - 1)]
	var particles := CPUParticles3D.new()
	particles.name = "FloorAtmosphere_" + _floor_weather.replace(" ", "_")
	particles.amount = 110 if band in [1, 4, 5, 8] else 65
	particles.lifetime = 5.0
	particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	particles.emission_box_extents = Vector3(43, 5, 43)
	particles.direction = Vector3(0.12, -0.18 if band in [4, 5, 7] else 0.03, 0.08)
	particles.spread = 38.0
	particles.initial_velocity_min = 0.08
	particles.initial_velocity_max = 0.42 if band not in [4, 6] else 0.85
	particles.gravity = Vector3(0, -0.06 if band != 4 else -0.3, 0)
	particles.emitting = true
	var speck := SphereMesh.new()
	speck.radius = 0.035 if band not in [2, 8] else 0.055
	speck.height = speck.radius * 2.0
	particles.mesh = speck
	var particle_mat := StandardMaterial3D.new()
	particle_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	particle_mat.albedo_color = glow.lightened(0.18)
	particle_mat.emission_enabled = true
	particle_mat.emission = glow
	particle_mat.emission_energy_multiplier = 0.75
	particle_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	particles.material_override = particle_mat
	particles.position.y = 3.0
	room.add_child(particles)
	# Additional architectural light anchors make the space readable without a sky.
	for side in [-1.0, 1.0]:
		var brazier := _make_box(room, "AncientBrazier", Vector3(side * MAZE_GRID * MAZE_CELL * 0.36, 0.85, 0), Vector3(1.5, 2.1, 1.5), stone.lightened(0.12))
		var flame := OmniLight3D.new()
		flame.light_color = glow
		flame.light_energy = 1.15 if band in [0, 3, 4, 9] else 0.7
		flame.omni_range = 18.0
		flame.position = brazier.position + Vector3(0, 1.6, 0)
		flame.shadow_enabled = true
		room.add_child(flame)

func _resolve_world_environment() -> WorldEnvironment:
	var main_scene: Node = get_tree().current_scene
	if main_scene:
		var we: WorldEnvironment = main_scene.get_node_or_null("WorldEnvironment") as WorldEnvironment
		if we:
			return we
	if get_parent():
		var parent_we: WorldEnvironment = get_parent().get_node_or_null("WorldEnvironment") as WorldEnvironment
		if parent_we:
			return parent_we
	# The dungeon may be hosted under a different scene root (review harness,
	# hosted builds); fall back to any environment already in the tree.
	for candidate in get_tree().root.find_children("*", "WorldEnvironment", true, false):
		if candidate is WorldEnvironment:
			return candidate
	return null

func _resolve_day_night_cycle() -> Node:
	var main_scene: Node = get_tree().current_scene
	if main_scene:
		var cycle: Node = main_scene.get_node_or_null("DayNightCycle")
		if cycle:
			return cycle
	if get_parent():
		var parent_cycle: Node = get_parent().get_node_or_null("DayNightCycle")
		if parent_cycle:
			return parent_cycle
	for candidate in get_tree().root.find_children("*", "DayNightCycle", true, false):
		return candidate
	return null

func _apply_dungeon_environment(floor_i: int) -> void:
	var world_env_node: WorldEnvironment = _resolve_world_environment()
	if world_env_node == null:
		return
	if _world_environment == null:
		_world_environment = world_env_node.environment
	var palette: Dictionary = _floor_palette(floor_i)
	var band: int = int(floor_i / 10)
	var dungeon_env := Environment.new()
	dungeon_env.background_mode = Environment.BG_COLOR
	dungeon_env.background_color = Color(0.012, 0.016, 0.024) if band >= 8 else Color(0.025, 0.028, 0.032)
	dungeon_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	dungeon_env.ambient_light_color = palette.stone.lightened(0.16).lerp(palette.glow, 0.18)
	dungeon_env.ambient_light_energy = 1.30 if band in [0, 8, 9] else 1.42
	dungeon_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var cycle: Node = _resolve_day_night_cycle()
	var quality_level: int = clampi(int(cycle.get("quality")) if cycle else 1, 0, 3)
	dungeon_env.glow_enabled = quality_level >= 1
	dungeon_env.glow_intensity = 0.65 if quality_level < 3 else 0.82
	dungeon_env.fog_enabled = true
	dungeon_env.fog_light_color = palette.stone.lightened(0.12)
	dungeon_env.fog_density = 0.012 if band in [1, 5, 6, 8] else 0.006
	dungeon_env.fog_depth_begin = 12.0
	dungeon_env.fog_depth_end = 92.0 if band in [6, 8] else 125.0
	dungeon_env.volumetric_fog_enabled = quality_level >= 2
	dungeon_env.volumetric_fog_density = (0.012 if band in [1, 4, 6, 8] else 0.006) * (1.0 if quality_level >= 3 else 0.7)
	dungeon_env.volumetric_fog_length = 65.0
	world_env_node.environment = dungeon_env
	var sun: DirectionalLight3D = cycle.get_node_or_null("Sun") if cycle else null
	var moon: DirectionalLight3D = cycle.get_node_or_null("Moon") if cycle else null
	if sun and _world_sun_energy < 0.0:
		_world_sun_energy = sun.light_energy
	if moon and _world_moon_energy < 0.0:
		_world_moon_energy = moon.light_energy
	_suppress_overworld_lights()

func _suppress_overworld_lights() -> void:
	var cycle: Node = _resolve_day_night_cycle()
	if cycle == null:
		return
	var sun: DirectionalLight3D = cycle.get_node_or_null("Sun")
	var moon: DirectionalLight3D = cycle.get_node_or_null("Moon")
	if sun:
		sun.light_energy = 0.0
		sun.visible = false
	if moon:
		moon.light_energy = 0.0
		moon.visible = false

func _restore_overworld_environment() -> void:
	var world_env_node: WorldEnvironment = _resolve_world_environment()
	if world_env_node and _world_environment:
		world_env_node.environment = _world_environment
	var cycle: Node = _resolve_day_night_cycle()
	var sun: DirectionalLight3D = cycle.get_node_or_null("Sun") if cycle else null
	var moon: DirectionalLight3D = cycle.get_node_or_null("Moon") if cycle else null
	if sun and _world_sun_energy >= 0.0:
		sun.light_energy = _world_sun_energy
		sun.visible = true
	if moon and _world_moon_energy >= 0.0:
		moon.light_energy = _world_moon_energy
		moon.visible = true
	_world_sun_energy = -1.0
	_world_moon_energy = -1.0
	_world_environment = null

func _show_loading_screen(title: String, detail: String) -> void:
	if _loading_layer and is_instance_valid(_loading_layer):
		_loading_layer.queue_free()
	_loading_layer = CanvasLayer.new()
	_loading_layer.layer = 90
	var root := ColorRect.new()
	root.color = Color(0.008, 0.012, 0.02, 1.0)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_loading_layer.add_child(root)
	var panel := VBoxContainer.new()
	panel.anchor_left = 0.5; panel.anchor_right = 0.5
	panel.anchor_top = 0.5; panel.anchor_bottom = 0.5
	panel.offset_left = -280; panel.offset_right = 280
	panel.offset_top = -70; panel.offset_bottom = 70
	panel.alignment = BoxContainer.ALIGNMENT_CENTER
	root.add_child(panel)
	var heading := Label.new()
	heading.text = title
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 30)
	heading.add_theme_color_override("font_color", Color(0.82, 0.72, 0.48))
	panel.add_child(heading)
	var sub := Label.new()
	sub.text = detail
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 16)
	sub.add_theme_color_override("font_color", Color(0.68, 0.72, 0.78))
	panel.add_child(sub)
	var hint := Label.new()
	hint.text = "The depths remember every traveller."
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(0.42, 0.48, 0.56))
	panel.add_child(hint)
	get_tree().current_scene.add_child(_loading_layer)
	await get_tree().create_timer(0.65).timeout
	if _loading_layer and is_instance_valid(_loading_layer):
		_loading_layer.queue_free()
		_loading_layer = null

func _toggle_dungeon_map() -> void:
	if _dungeon_map_layer and is_instance_valid(_dungeon_map_layer):
		_dungeon_map_layer.queue_free()
		_dungeon_map_layer = null
		GameManager.pop_ui_lock()
		return
	_dungeon_map_layer = CanvasLayer.new()
	_dungeon_map_layer.layer = 45
	GameManager.push_ui_lock()
	var shade := ColorRect.new()
	shade.color = Color(0.0, 0.0, 0.0, 0.72)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_dungeon_map_layer.add_child(shade)
	var map_panel := PanelContainer.new()
	map_panel.anchor_left = 0.5; map_panel.anchor_right = 0.5
	map_panel.anchor_top = 0.5; map_panel.anchor_bottom = 0.5
	map_panel.offset_left = -350; map_panel.offset_right = 350
	map_panel.offset_top = -350; map_panel.offset_bottom = 350
	_dungeon_map_layer.add_child(map_panel)
	var box := VBoxContainer.new(); map_panel.add_child(box)
	var heading := Label.new(); heading.text = "DEPTHS OF ELYNDOR  •  FLOOR %d / %d  •  %s  •  RAID GUARDIAN" % [current_floor + 1, FLOORS, _floor_weather.capitalize()]
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 18)
	box.add_child(heading)
	var map_view := Control.new(); map_view.custom_minimum_size = Vector2(650, 620); box.add_child(map_view)
	map_view.set_script(load("res://ui/dungeon_map_view.gd"))
	map_view.set("maze_cells", _maze_cells.duplicate())
	map_view.set("maze_links", _maze_links.duplicate(true))
	map_view.set("player_cell", _player_maze_cell())
	map_view.set("maze_grid", MAZE_GRID)
	map_view.set("maze_start", MAZE_START)
	map_view.set("maze_goal", MAZE_GOAL)
	var foot := Label.new(); foot.text = "N / ESC: Close   |   Blue: You   Amber: Unexplored passage   Red: Discovered sanctum"
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; box.add_child(foot)
	get_tree().current_scene.add_child(_dungeon_map_layer)

func get_explored_cells() -> Dictionary:
	return _explored_cells.get(str(current_floor), {})

func _reveal_player_cell() -> void:
	var cell := _player_maze_cell()
	var key := str(current_floor)
	if not _explored_cells.has(key):
		_explored_cells[key] = {}
	_explored_cells[key]["%d,%d" % [cell.x, cell.y]] = true
	var sanctum: Rect2i = CHAMBER_RECTS.back()
	if sanctum.has_point(cell) and not has_discovery(current_floor, "boss_chamber"):
		mark_discovery(current_floor, "boss_chamber")
		EventBus.toast.emit("Boss chamber discovered! Rally a raid before challenging the guardian.", "discovery")

func _player_maze_cell() -> Vector2i:
	var player: Node3D = GameManager.player
	var room: Node3D = _rooms.get(current_floor)
	if player == null or room == null:
		return MAZE_START
	var local: Vector3 = player.global_position - room.global_position
	var best: Vector2i = MAZE_START
	var best_distance: float = INF
	for cell in _maze_cells:
		var distance: float = local.distance_to(_maze_cell_position(cell))
		if distance < best_distance:
			best_distance = distance
			best = cell
	return best

func _load_shared_clears() -> void:
	if not MMORPGNetwork.is_authority():
		return
	if WorldDeploymentGuard.production_mode:
		var result: Dictionary = await CentralBackend.server_load_bosses()
		if not bool(result.get("ok", false)):
			push_error("Dungeon progression unavailable; admission remains closed.")
			return
		for row: Dictionary in result.get("body", {}).get("bosses", []):
			if str(row.get("boss_definition_id", "")).begins_with("labyrinth_floor_"):
				var record: Dictionary = row.get("encounter_state", {})
				var f := int(record.get("floor", -1))
				if f >= 0 and f < FLOORS and record.has("cleared_at"):
					_cleared_floors[str(f)] = record
					_floor_clear_revisions[str(f)] = int(row.get("revision", 0))
		var discovery_result: Dictionary = await CentralBackend.server_load_region_entities("dungeon-progression")
		if bool(discovery_result.get("ok", false)):
			var expected_discovery_id := MMORPGNetwork._stable_world_uuid("%s:dungeon-discoveries:%d" % [MMORPGNetwork.SINGLE_WORLD_ID, GameManager.world_seed])
			for row_variant in discovery_result.get("body", {}).get("entities", []):
				if not row_variant is Dictionary or str(row_variant.get("entity_id", "")) != expected_discovery_id:
					continue
				var saved: Variant = row_variant.get("entity_state", {})
				if saved is Dictionary:
					_discovery_flags = saved.get("discovery_flags", {}).duplicate(true) if saved.get("discovery_flags", {}) is Dictionary else {}
					_discovery_backend_revision = int(row_variant.get("revision", 0))
	else:
		_cleared_floors = MMORPGWorldState.world_state.get("dungeon_clears", {}).duplicate(true)
	_progress_ready = true
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		for peer in MMORPGNetwork.peer_characters:
			synchronize_peer(int(peer))

func synchronize_peer(peer: int) -> void:
	if not _progress_ready or peer == 1:
		return
	rpc_id(peer, "receive_floor_clears", _cleared_floors)
	rpc_id(peer, "receive_dungeon_discoveries", _discovery_flags)
	_server_travel(peer, "resume")

@rpc("authority", "reliable")
func receive_dungeon_discoveries(records: Dictionary) -> void:
	if MMORPGNetwork.is_authority():
		return
	_discovery_flags = records.duplicate(true)

@rpc("authority", "reliable")
func receive_floor_clears(records: Dictionary) -> void:
	_cleared_floors = records.duplicate(true)
	_progress_ready = true
	for key in records:
		deepest_cleared = maxi(deepest_cleared, int(key) + 1)

func _request_travel(action: String) -> void:
	if multiplayer.is_server():
		_server_travel(1, action)
	else:
		rpc_id(1, "request_dungeon_travel", action)

@rpc("any_peer", "reliable")
func request_dungeon_travel(action: String) -> void:
	if multiplayer.is_server():
		_server_travel(multiplayer.get_remote_sender_id(), action)

func _server_travel(peer: int, action: String) -> void:
	if not _progress_ready or (peer != 1 and not MMORPGNetwork.peer_characters.has(peer)):
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_travel_times.get(peer, -10.0)) < 1.0:
		return
	_travel_times[peer] = now
	var position_value: Vector3 = MMORPGNetwork.accepted_positions.get(peer, Vector3.INF)
	if peer == 1 and is_instance_valid(GameManager.player):
		position_value = GameManager.player.global_position
	var from_floor := int(_peer_floors.get(peer, current_floor if peer == 1 and inside else -1))
	var target_floor := -1
	if action not in ["leave", "resume"]:
		var hp := float(MMORPGNetwork.peer_health.get(peer, {}).get("current", 0.0))
		if peer == 1 and is_instance_valid(GameManager.player):
			hp = GameManager.player.health.current_health
		if hp <= 0.0:
			return
	match action:
		"resume":
			var local_position := position_value - global_position
			var saved_floor := int(round(-local_position.y / FLOOR_VERTICAL_SPACING))
			if absf(local_position.x) > MAZE_HALF or absf(local_position.z) > MAZE_HALF or saved_floor < 0 or saved_floor >= FLOORS:
				return
			if absf(local_position.y + saved_floor * FLOOR_VERTICAL_SPACING) > 10.0:
				return
			if saved_floor > 0 and not _cleared_floors.has(str(saved_floor - 1)):
				return
			target_floor = saved_floor
		"enter":
			if from_floor >= 0 or not is_instance_valid(_entrance) or position_value.distance_to(_entrance.global_position) > 8.0:
				return
			target_floor = 0
		"advance":
			if from_floor < 0 or not _cleared_floors.has(str(from_floor)) or not _rooms.has(from_floor):
				return
			var gate: Vector3 = _rooms[from_floor].global_position + _maze_cell_position(MAZE_GOAL) + Vector3(-1.2, 2.92, 0.5)
			if position_value.distance_to(gate) > 6.0:
				return
			target_floor = from_floor + 1 if from_floor + 1 < FLOORS else -1
		"leave":
			if from_floor < 0:
				return
		_:
			return
	var destination := _entrance.global_position + Vector3(0, 0.4, 3)
	if target_floor >= 0:
		var previous_floor := current_floor
		var room := _ensure_room(target_floor)
		_spawn_floor_content(target_floor)
		if inside:
			_generate_maze(previous_floor)
		destination = room.global_position + _maze_cell_position(MAZE_START) + Vector3(0, 0.4, 0)
		_peer_floors[peer] = target_floor
	else:
		_peer_floors.erase(peer)
	MMORPGNetwork.accepted_positions[peer] = destination
	MMORPGNetwork.accepted_times[peer] = now
	if peer == 1:
		receive_dungeon_travel(target_floor, destination, _cleared_floors)
	else:
		rpc_id(peer, "receive_dungeon_travel", target_floor, destination, _cleared_floors)
		MMORPGNetwork.send_world_monsters_to_peer(peer)

@rpc("authority", "reliable")
func receive_dungeon_travel(f: int, destination: Vector3, records: Dictionary) -> void:
	receive_floor_clears(records)
	if _dungeon_map_layer and is_instance_valid(_dungeon_map_layer):
		_toggle_dungeon_map()
	inside = f >= 0
	if inside:
		_ensure_room(f)
		_show_floor(f)
		_apply_dungeon_environment(f)
		add_to_group("dungeon_active")
		DungeonExpedition.start_expedition([multiplayer.get_unique_id()])
		DungeonExpedition.on_floor_entered(f + 1)
	else:
		_restore_overworld_environment()
		remove_from_group("dungeon_active")
		for room: Node3D in _rooms.values():
			room.hide()
		DungeonExpedition.finish_expedition(false)
	if is_instance_valid(GameManager.player):
		GameManager.player.global_position = destination
		GameManager.player.velocity = Vector3.ZERO
	MMORPGNetwork.refresh_dungeon_replica_visibility()
	if inside:
		_reveal_player_cell()

func enter_dungeon() -> void:
	if MMORPGNetwork.is_online():
		_request_travel("enter")
		return
	if not _progress_ready:
		EventBus.toast.emit("Dungeon progression is unavailable. Try again after reconnecting.", "warning")
		return
	var player = GameManager.player
	if player == null:
		return
	# The first descent is the capstone of the Heartlands preparation chain.
	# Existing saves that have already completed the contract remain unaffected.
	var expedition_contract: Dictionary = PlayerData.quests.get("q_expedition_supplies", {})
	if str(expedition_contract.get("state", "")) != "done":
		EventBus.toast.emit("Gorrim must approve your expedition kit first. Complete 'Supplies for the Descent'.", "warning")
		return
	await _show_loading_screen("DESCENDING INTO THE DEPTHS", "Preparing the labyrinth • Floor 1")
	_return_pos = player.global_position
	inside = true
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition:
		expedition.start_expedition([multiplayer.get_unique_id()])
		expedition.on_floor_entered(1)
		if ElyndorRegionLife and ElyndorRegionLife.has_method("record_dungeon_floor"):
			ElyndorRegionLife.record_dungeon_floor(1)
	_world_event_timer = randf_range(65.0, 95.0)
	_active_world_event = ""
	current_floor = 0
	_boss_alive = true
	_floor_boss = null
	add_to_group("dungeon_active")
	var room: Node3D = _ensure_room(0)
	_apply_dungeon_environment(0)
	_show_floor(0)
	# Place player on the room floor (world space)
	player.global_position = room.global_position + _maze_cell_position(MAZE_START) + Vector3(0, 0.34, 0)
	player.velocity = Vector3.ZERO
	EventBus.toast.emit("Depths of Elyndor — Floor 1/%d: %s" % [FLOORS, _floor_palette(0)["name"]], "scene")
	EventBus.toast.emit("Underground conditions: %s. The overworld's day and night cannot reach this deep." % _floor_weather.capitalize(), "info")
	EventBus.activity.emit("Dungeon entered", "world")
	if is_instance_valid(GuildContracts):
		GuildContracts.record_progress("dungeon", 1)
	_spawn_floor_content(0)
	if player.get("skills") != null:
		player.skills.train("dungeon_delving", 1.0)
		player.skills.train("exploration", 0.45)
		player.skills.train("observation", 0.25)
		player.skills.train("knowledge", 0.12)
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg:
		sg.add_progress("elyndor", 2.0, "dungeon")

func secure_expedition_checkpoint(floor_number: int) -> void:
	_checkpoint_floor = clampi(floor_number, 1, FLOORS)
	var player: Node3D = GameManager.player
	if player:
		_checkpoint_position = player.global_position
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition:
		expedition.secure_checkpoint(_checkpoint_floor)

func _show_floor(f: int) -> void:
	_floor_affix = ""
	var floor_identity: Dictionary = _floor_palette(f)
	EventBus.activity.emit("You enter %s — Floor %d. The district's architecture and inhabitants reflect its lost civilization." % [str(floor_identity.get("name", "Forgotten District")), f + 1], "discovery")
	PlayerData.stats["deepest_dungeon_floor"] = maxi(int(PlayerData.stats.get("deepest_dungeon_floor", 0)), f + 1)
	for k in _rooms.keys():
		var cached_room: Node3D = _rooms[k]
		if is_instance_valid(cached_room):
			cached_room.visible = (int(k) == f)
	current_floor = f
	if not _discovered_floors.has(f):
		_discovered_floors.append(f)
	AncientInheritanceSystem.record_floor_entered(f + 1)
	MMORPGNetwork.refresh_dungeon_replica_visibility()
	_prune_distant_rooms(f)

func _prune_distant_rooms(keep_floor: int) -> void:
	# The floor geometry is deterministic, so old floor meshes can be rebuilt when revisited.
	# Keeping only the current and adjacent floor avoids retaining hundreds of thousands of nodes.
	for raw_key in _rooms.keys():
		var floor_key: int = int(raw_key)
		if abs(floor_key - keep_floor) > 1 and _floor_player_positions(floor_key).is_empty():
			_farming_slots.erase(floor_key)
			var stale_room: Node3D = _rooms[raw_key]
			if is_instance_valid(stale_room):
				for child in stale_room.get_children():
					if child.is_in_group("enemy"):
						MMORPGNetwork.broadcast_world_monster_despawn(child)
				stale_room.queue_free()
			_rooms.erase(raw_key)

func _clear_enemies_on_floor(f: int) -> void:
	var room: Node3D = _rooms.get(f)
	if room:
		for c in room.get_children():
			if c.is_in_group("enemy"):
				c.queue_free()
	for c in get_tree().get_nodes_in_group("enemy"):
		if c is Node3D and int(c.get_meta("dungeon_floor", -1)) == f:
			c.queue_free()

func _add_checkpoint(room: Node3D, floor_i: int) -> void:
	var checkpoint := Area3D.new()
	checkpoint.name = "ExpeditionSanctuary_Floor_%d" % (floor_i + 1)
	checkpoint.position = _maze_cell_position(MAZE_START) + Vector3(3.2, 0.6, 2.8)
	checkpoint.add_to_group("interactable")
	checkpoint.add_to_group("dungeon_discovery")
	checkpoint.set_meta("interact_range", 3.8)
	checkpoint.set_meta("floor_number", floor_i + 1)
	checkpoint.set_script(load("res://entities/dungeon_checkpoint.gd"))
	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 2.5
	shape.shape = sphere
	checkpoint.add_child(shape)
	var base := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 1.35
	cylinder.bottom_radius = 1.65
	cylinder.height = 0.28
	base.mesh = cylinder
	var stone := StandardMaterial3D.new()
	stone.albedo_color = Color(0.27, 0.29, 0.32)
	stone.roughness = 0.9
	base.material_override = stone
	checkpoint.add_child(base)
	var crystal := MeshInstance3D.new()
	var crystal_mesh := PrismMesh.new()
	crystal_mesh.size = Vector3(0.5, 1.5, 0.5)
	crystal.mesh = crystal_mesh
	crystal.position.y = 0.95
	var crystal_mat := StandardMaterial3D.new()
	crystal_mat.albedo_color = Color(0.18, 0.55, 0.85)
	crystal_mat.emission_enabled = true
	crystal_mat.emission = Color(0.12, 0.48, 1.0)
	crystal_mat.emission_energy_multiplier = 2.0
	crystal.material_override = crystal_mat
	checkpoint.add_child(crystal)
	var light := OmniLight3D.new()
	light.name = "SanctuaryLight"
	light.light_color = Color(0.22, 0.55, 1.0)
	light.light_energy = 1.7
	light.omni_range = 8.0
	light.position.y = 1.2
	checkpoint.add_child(light)
	var label := Label3D.new()
	label.text = "EXPEDITION SANCTUARY"
	label.position.y = 2.1
	label.font_size = 22
	label.modulate = Color(0.55, 0.78, 1.0)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	checkpoint.add_child(label)
	room.add_child(checkpoint)

func _add_trap(room: Node3D, floor_i: int, cell: Vector2i, trap_index: int) -> void:
	var trap := Area3D.new()
	trap.name = "DungeonTrap_%d_%d" % [floor_i + 1, trap_index]
	trap.position = _maze_cell_position(cell) + Vector3(0, 0.38, 0)
	trap.add_to_group("dungeon_discovery")
	trap.add_to_group("interactable")
	trap.set_meta("interact_range", 2.8)
	trap.collision_layer = 0
	trap.collision_mask = 2
	trap.set_script(load("res://entities/dungeon_trap.gd"))
	trap.damage = 12.0 + float(floor_i) * 1.25
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(3.8, 1.4, 3.8)
	shape.shape = box_shape
	trap.add_child(shape)
	var plate := MeshInstance3D.new()
	plate.name = "Plate"
	var plate_mesh := BoxMesh.new()
	plate_mesh.size = Vector3(3.5, 0.12, 3.5)
	plate.mesh = plate_mesh
	var metal := StandardMaterial3D.new()
	metal.albedo_color = Color(0.16, 0.17, 0.19)
	metal.metallic = 0.75
	metal.roughness = 0.6
	plate.material_override = metal
	trap.add_child(plate)
	var lamp := OmniLight3D.new()
	lamp.name = "TrapLight"
	lamp.light_color = Color(0.95, 0.38, 0.12)
	lamp.light_energy = 0.18
	lamp.omni_range = 2.8
	lamp.position.y = 0.5
	trap.add_child(lamp)
	room.add_child(trap)

func _spawn_floor_content(f: int) -> void:
	if not MMORPGNetwork.is_authority():
		return
	if _farming_slots.has(f):
		return
	_clear_enemies_on_floor(f)
	# Rebuild dynamic encounters cleanly when restoring a save; do not duplicate caches/shrines.
	var old_room: Node3D = _rooms.get(f)
	if old_room:
		for child in old_room.get_children():
			if child.is_in_group("dungeon_discovery"):
				child.queue_free()
	_boss_alive = true
	_floor_boss = null
	var room: Node3D = _ensure_room(f)
	var diff: float = _difficulty(f)
	var candidates: Array[Vector2i] = []
	for cell in _maze_cells:
		if cell.distance_to(MAZE_START) >= 2.0 and not CHAMBER_RECTS.back().has_point(cell):
			candidates.append(cell)
	var slots: Array[Dictionary] = []
	var pack_count := mini(24 + int(f / 10), candidates.size())
	for pack in range(pack_count):
		var cell := candidates[int(float(pack) * candidates.size() / pack_count)]
		for member in range(3):
			var slot := {"cell": cell, "monster": _random_floor_monster(f), "node": null, "ready_at": 0.0}
			_spawn_farming_slot(room, f, slot)
			slots.append(slot)
	_farming_slots[f] = slots
	# A faction patrol protects the district's routes. Its veteran captain rallies a small squad.
	var patrol_data: Dictionary = _random_floor_monster(f)
	var patrol_cell: Vector2i = _maze_cells[randi_range(2, maxi(2, _maze_cells.size() - 3))]
	var faction_profile: Dictionary = CIVILIZATION_COMBAT[clampi(int(f / 10), 0, 9)]
	var patrol_captain: Node = _spawn_in_room(room, f, str(patrol_data.id), false, str(faction_profile.faction) + " Vanguard", float(patrol_data.hp) * 1.7, float(patrol_data.dmg) * 1.25, patrol_data.color.lightened(0.18), diff * 1.12, patrol_cell)
	var patrol_pack_id: String = "faction_%d_%d" % [f, patrol_cell.x * 13 + patrol_cell.y]
	if patrol_captain:
		patrol_captain.set_meta("pack_role", "captain")
		patrol_captain.set_meta("pack_id", patrol_pack_id)
		patrol_captain.set_meta("faction_patrol", true)
		var route_cells: Array[Vector2i] = [patrol_cell, Vector2i(clampi(patrol_cell.x + 1, 1, MAZE_GRID - 2), patrol_cell.y), Vector2i(patrol_cell.x, clampi(patrol_cell.y + 1, 1, MAZE_GRID - 2))]
		var route_points: Array[Vector3] = []
		for route_cell in route_cells:
			route_points.append(room.to_global(_maze_cell_position(route_cell) + Vector3(0, 0.36, 0)))
		patrol_captain.set_meta("faction_patrol_route", route_points)
	for guard_i in range(2):
		var guard_data: Dictionary = _random_floor_monster(f)
		var guard_cell: Vector2i = _maze_cells[randi_range(1, maxi(1, _maze_cells.size() - 2))]
		var guard: Node = _spawn_in_room(room, f, str(guard_data.id), false, "Faction Guard", float(guard_data.hp) * 0.82, float(guard_data.dmg), guard_data.color, diff, guard_cell)
		if guard and patrol_captain:
			guard.set_meta("pack_id", patrol_pack_id)
			guard.set_meta("pack_leader_path", patrol_captain.get_path())
	# A rival civilization patrol creates real autonomous skirmishes on this floor.
	var rival_profile: Dictionary = CIVILIZATION_COMBAT[(int(f / 10) + 3) % CIVILIZATION_COMBAT.size()]
	var rival_pack_id := "rival_%d_%d" % [f, patrol_cell.x * 13 + patrol_cell.y]
	for rival_i in range(2):
		var rival_data: Dictionary = _random_floor_monster(f)
		var rival_cell: Vector2i = _maze_cells[randi_range(2, maxi(2, _maze_cells.size() - 3))]
		var rival: Node = _spawn_in_room(room, f, str(rival_data.id), false, str(rival_profile.faction) + " Rival", float(rival_data.hp) * 0.92, float(rival_data.dmg) * 1.05, rival_data.color.darkened(0.12), diff, rival_cell)
		if rival:
			rival.set_meta("dungeon_faction", str(rival_profile.faction))
			rival.set_meta("dungeon_faction_id", str(CivilizationSocieties.CULTURES[(int(f / 10) + 3) % CivilizationSocieties.CULTURES.size()].get("id", "kingdom")))
			rival.set_meta("dungeon_tactic", str(rival_profile.tactic))
			rival.set_meta("dungeon_resistances", rival_profile.resist)
			rival.set_meta("pack_id", rival_pack_id)
			rival.set_meta("pack_role", "guard")
	if patrol_captain:
		patrol_captain.set_meta("faction_commander", true)
	if f >= 5 and randf() < 0.35:
		var t2: Dictionary = _random_floor_monster(f)
		_spawn_in_room(room, f, str(t2["id"]), false, "Elite " + str(t2["name"]), float(t2["hp"]) * 1.8, float(t2["dmg"]) * 1.35, Color(1.0, 0.75, 0.2), diff)
	_spawn_floor_boss(f, room, diff)
	_spawn_exploration_content(f, room, diff)
	_spawn_civilization_content(f, room)
	# One fully occupied headquarters anchors each ten-floor civilization band.
	# The outpost is rebuilt from persistent ownership whenever this floor is revisited.
	if f % 10 == 0:
		var stronghold_cells: Array[Vector2i] = []
		for stronghold_cell in _maze_cells:
			if stronghold_cell != MAZE_START and stronghold_cell != MAZE_GOAL and stronghold_cell.distance_to(MAZE_START) >= 4.0 and stronghold_cell.distance_to(MAZE_GOAL) >= 3.0:
				stronghold_cells.append(stronghold_cell)
		if not stronghold_cells.is_empty():
			var stronghold_script: Script = load("res://entities/dungeon_campaign_stronghold.gd")
			if stronghold_script:
				var stronghold := Node3D.new()
				stronghold.set_script(stronghold_script)
				var band := clampi(int(f / 10), 0, 9)
				var culture: Dictionary = CivilizationSocieties.CULTURES[band]
				var profile: Dictionary = CIVILIZATION_COMBAT[band]
				stronghold.set("faction_name", str(profile.get("faction", culture.get("name", "Forgotten Faction"))))
				stronghold.set("faction_id", str(culture.get("id", "labyrinth")))
				stronghold.set("floor_number", f + 1)
				stronghold.set("faction_color", _floor_palette(f).get("glow", Color(0.55, 0.65, 0.82)))
				var stronghold_cell: Vector2i = stronghold_cells[int(stronghold_cells.size() / 2)]
				stronghold.position = _maze_cell_position(stronghold_cell)
				stronghold.name = "CampaignStronghold_Floor_%d" % (f + 1)
				room.add_child(stronghold)
				# The existing autonomous patrol squad now runs a route between its
				# district post and this headquarters, making faction movement visible.
				if patrol_captain and patrol_captain.has_meta("faction_patrol_route"):
					var army_route: Array = patrol_captain.get_meta("faction_patrol_route", []).duplicate()
					army_route.append(room.to_global(_maze_cell_position(stronghold_cell) + Vector3(0, 0.36, 0)))
					patrol_captain.set_meta("faction_patrol_route", army_route)
	if (f + 1) % 5 == 0:
		_add_checkpoint(room, f)
	# A few hidden pressure plates are placed off the direct route, never at spawn or boss cells.
	var trap_candidates: Array[Vector2i] = []
	for trap_cell in _maze_cells:
		if trap_cell != MAZE_START and trap_cell != MAZE_GOAL and trap_cell.distance_to(MAZE_START) >= 2.5 and trap_cell.distance_to(MAZE_GOAL) >= 2.0:
			trap_candidates.append(trap_cell)
	trap_candidates.shuffle()
	var trap_count: int = mini(1 + int(f / 25), 4)
	for trap_i in range(mini(trap_count, trap_candidates.size())):
		_add_trap(room, f, trap_candidates[trap_i], trap_i)
	# Rare encounters are tied to depth and world seed; not every visit guarantees one.
	if f >= 4 and (f + int(GameManager.world_seed)) % 7 == 0 and randf() < 0.42:
		var rare_cell: Vector2i = _maze_cells[randi_range(2, maxi(2, _maze_cells.size() - 3))]
		var rare_data: Dictionary = _random_floor_monster(f)
		var rare: Node = _spawn_in_room(room, f, str(rare_data.id), false, "Rare: " + str(rare_data.name), float(rare_data.hp) * 2.4, float(rare_data.dmg) * 1.65, Color(0.95, 0.72, 1.0), diff * 1.35, rare_cell)
		if rare:
			var rare_variants: Array[Dictionary] = [
				{"name": "Elder Moonfang", "tint": Color(0.55, 0.78, 1.0), "drop": "moonstone_ore"},
				{"name": "Abyss-Weaver", "tint": Color(0.68, 0.38, 0.82), "drop": "voidsilk"},
				{"name": "Gravebound Colossus", "tint": Color(0.72, 0.68, 0.55), "drop": "dragonbone"},
				{"name": "Prismback Stalker", "tint": Color(0.35, 0.88, 0.9), "drop": "ancient_scale"},
				{"name": "Abyssal Heartkeeper", "tint": Color(0.95, 0.35, 0.55), "drop": "heart_of_depths"}
			]
			var variant: Dictionary = rare_variants[mini(int(f / 20), rare_variants.size() - 1)]
			if rare.has_method("apply_rare_variant"):
				rare.apply_rare_variant(str(variant.name), variant.tint, str(variant.drop))
			else:
				rare.set_meta("rare_encounter", true)
				rare.set_meta("rare_variant_drop", str(variant.drop))
			EventBus.toast.emit("A rare %s stalks this floor..." % str(variant.name), "warning")

func _spawn_farming_slot(room: Node3D, f: int, slot: Dictionary) -> void:
	var data: Dictionary = slot.monster
	var monster := _spawn_in_room(room, f, str(data.id), false, str(data.name), float(data.hp), float(data.dmg), data.color, _difficulty(f), slot.cell)
	slot.node = monster
	slot.ready_at = 0.0
	monster.health.died.connect(func(_source: Node) -> void:
		slot.node = null
		slot.ready_at = Time.get_ticks_msec() / 1000.0 + 90.0
	, CONNECT_ONE_SHOT)

func _floor_player_positions(f: int) -> Array[Vector3]:
	var positions: Array[Vector3] = []
	if inside and current_floor == f and is_instance_valid(GameManager.player):
		positions.append(GameManager.player.global_position)
	for peer in _peer_floors:
		if int(_peer_floors[peer]) == f and MMORPGNetwork.accepted_positions.has(peer):
			positions.append(MMORPGNetwork.accepted_positions[peer])
	return positions

func _tick_farming() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	for f in _farming_slots:
		var positions := _floor_player_positions(int(f))
		if positions.is_empty() or not _rooms.has(f):
			continue
		var room: Node3D = _rooms[f]
		var spawned := 0
		for slot: Dictionary in _farming_slots[f]:
			if is_instance_valid(slot.node) or now < float(slot.ready_at):
				continue
			var spawn_position := room.global_position + _maze_cell_position(slot.cell)
			var occupied := false
			for player_position in positions:
				if spawn_position.distance_to(player_position) < 24.0:
					occupied = true
					break
			if not occupied:
				_spawn_farming_slot(room, int(f), slot)
				spawned += 1
			if spawned >= 6:
				break

func _monster_data(monster_id: String) -> Dictionary:
	for entry in TRASH:
		if str(entry["id"]) == monster_id:
			return entry
	return TRASH[0]

func _random_floor_monster(floor_i: int) -> Dictionary:
	# Legacy/common species unlock gradually with depth. The ten civilization
	# inhabitants are selected from the current region only, never from a later
	# culture at random on an early floor.
	var band := clampi(int(floor_i / 10), 0, 9)
	if randf() < 0.32:
		return _monster_data(str(_floor_palette(floor_i).get("inhabitant", "dungeon_rat")))
	var highest_common_index: int = mini(18, 4 + band * 2)
	return TRASH[randi_range(0, highest_common_index)]

func _spawn_civilization_content(f: int, room: Node3D) -> void:
	var candidates: Array[Vector2i] = []
	for cell in _maze_cells:
		if cell != MAZE_START and cell != MAZE_GOAL and cell.distance_to(MAZE_START) >= 3.0 and cell.distance_to(MAZE_GOAL) >= 2.0:
			candidates.append(cell)
	candidates.shuffle()
	if not candidates.is_empty():
		_add_dungeon_hazard(room, candidates[0], f)
	if (f + 1) % 10 == 0 and not has_discovery(f, "civilization") and candidates.size() > 1:
		_add_civilization_trial(room, candidates[1], f)
	# Every district contains a claimable faction heart; side branches may hold
	# prisoners, quartermasters, concealed leaders, or active border skirmishes.
	if candidates.size() > 2 and not has_discovery(f, "faction_control"):
		_add_faction_encounter(room, f, candidates.pop_back(), "control")
	if candidates.size() > 2:
		var encounter_roll: int = randi_range(0, 99)
		var encounter_type: String = "prisoner" if encounter_roll < 30 else ("merchant" if encounter_roll < 55 else ("skirmish" if encounter_roll < 82 else "leader"))
		var discovery_key: String = "faction_" + encounter_type
		if not has_discovery(f, discovery_key):
			_add_faction_encounter(room, f, candidates.pop_back(), encounter_type)

func _add_faction_encounter(room: Node3D, floor_i: int, cell: Vector2i, encounter_type: String) -> void:
	var encounter_script: Script = load("res://entities/dungeon_faction_encounter.gd")
	if encounter_script == null:
		return
	var encounter: Area3D = Area3D.new()
	encounter.set_script(encounter_script)
	var profile: Dictionary = CIVILIZATION_COMBAT[clampi(int(floor_i / 10), 0, 9)]
	encounter.set("encounter_type", encounter_type)
	encounter.set("faction_name", str(profile.get("faction", "Forgotten Faction")))
	encounter.set("floor_number", floor_i + 1)
	encounter.set("faction_id", str(CivilizationSocieties.culture_for_floor(floor_i + 1).get("id", "labyrinth")))
	encounter.position = _maze_cell_position(cell) + Vector3(0, 0.1, 0)
	room.add_child(encounter)

func _spawn_exploration_content(f: int, room: Node3D, diff: float) -> void:
	# Each floor has optional discoveries away from the entrance and boss route.
	var candidates: Array[Vector2i] = []
	for cell in _maze_cells:
		if cell != MAZE_START and cell != MAZE_GOAL and cell.distance_to(MAZE_START) >= 3.0 and cell.distance_to(MAZE_GOAL) >= 2.0:
			candidates.append(cell)
	candidates.shuffle()
	if candidates.is_empty():
		return
	var cache_cell: Vector2i = candidates.pop_back()
	if not has_discovery(f, "cache"):
		_add_dungeon_cache(room, cache_cell, f)
	if not candidates.is_empty() and not has_discovery(f, "secret"):
		_add_secret_puzzle(room, candidates.pop_back(), f)
	if f % 2 == 0 and not candidates.is_empty() and not has_discovery(f, "shrine"):
		_add_dungeon_shrine(room, candidates.pop_back(), f)
	if (f + 1) % 5 == 0 and not candidates.is_empty() and not has_discovery(f, "spirit_vein"):
		_add_dungeon_spirit_vein(room, candidates.pop_back(), f)
	if not candidates.is_empty() and not has_discovery(f, "memory"):
		_add_dungeon_memory_tablet(room, candidates.pop_back(), f)
	if not candidates.is_empty() and ((f + 1) % 10 == 5 or (f + 1) == FLOORS):
		var archive_id: String = "archive_%03d" % (f + 1)
		var found_archives: Dictionary = PlayerData.stats.get("ancient_archive_discoveries", {})
		if not found_archives.has(archive_id):
			_add_dungeon_library_archive(room, candidates.pop_back(), f)
	# A roaming elite guards a different branch on deeper floors.
	if f >= 3 and not candidates.is_empty() and randf() < 0.7:
		var elite: Dictionary = _random_floor_monster(f)
		_spawn_in_room(room, f, str(elite.id), false, "Wandering Elite " + str(elite.name), float(elite.hp) * 1.65, float(elite.dmg) * 1.3, Color(1.0, 0.72, 0.25), diff * 1.15, candidates.pop_back())


func _add_dungeon_library_archive(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var archive_script: Script = load("res://entities/dungeon_library_archive.gd")
	if archive_script == null:
		return
	var archive := Area3D.new()
	archive.set_script(archive_script)
	var floor_number: int = floor_i + 1
	var palette: Dictionary = _floor_palette(floor_i)
	archive.name = "AncientLibraryArchive_Floor_%d" % floor_number
	archive.set("floor_number", floor_number)
	archive.set("archive_id", "archive_%03d" % floor_number)
	archive.set("civilization_name", str(palette.get("civilization", "Forgotten Civilization")))
	archive.set("fragment_lore", "The archive preserves a broken account of %s. Its records describe lost cultivation practices, territorial oaths and the downfall of this civilization." % str(palette.get("civilization", "the forgotten people")))
	archive.position = _maze_cell_position(cell) + Vector3(0.0, 0.05, 0.0)
	archive.set_meta("dungeon_floor", floor_i)
	room.add_child(archive)


func _add_dungeon_spirit_vein(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var palette: Dictionary = _floor_palette(floor_i)
	var band: int = clampi(int(floor_i / 10), 0, 9)
	var elements: Array[String] = ["fire", "water", "lightning", "earth", "ice", "wind", "fire", "water", "lightning", "earth"]
	var element: String = elements[band]
	var rare_forms: Array[String] = ["eclipse_counter", "starfall_burst", "dragon_piercer", "void_step", "eclipse_counter", "dragon_piercer", "starfall_burst", "void_step", "eclipse_counter", "starfall_burst"]
	var colors: Dictionary = {
		"fire":Color(1.0, 0.34, 0.12), "water":Color(0.18, 0.62, 1.0),
		"wind":Color(0.44, 0.92, 0.74), "earth":Color(0.72, 0.52, 0.3),
		"lightning":Color(1.0, 0.88, 0.25), "ice":Color(0.62, 0.88, 1.0)
	}
	var landmark := SpiritualLandmark.new()
	landmark.name = "DungeonSpiritVein_Floor_%d" % (floor_i + 1)
	landmark.landmark_id = "dungeon_floor_%03d_spirit_vein" % (floor_i + 1)
	landmark.landmark_name = "%s Spirit Vein" % str(palette.get("civilization", "Ancient"))
	landmark.element = element
	landmark.rare_technique = rare_forms[band]
	landmark.glow_color = colors.get(element, palette.get("glow", Color(0.65, 0.55, 1.0)))
	landmark.lore = "A vein of %s energy runs beneath the floor. Its pulse carries a fragment of %s history." % [element, str(palette.get("civilization", "the lost civilization"))]
	landmark.position = _maze_cell_position(cell) + Vector3(0.0, 0.12, 0.0)
	landmark.set_meta("dungeon_floor", floor_i)
	room.add_child(landmark)

func _persist_dungeon_discoveries() -> void:
	if not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured():
		return
	if _discovery_save_busy:
		_discovery_save_queued = true
		return
	_discovery_save_busy = true
	while true:
		_discovery_save_queued = false
		var entity_id := MMORPGNetwork._stable_world_uuid("%s:dungeon-discoveries:%d" % [MMORPGNetwork.SINGLE_WORLD_ID, GameManager.world_seed])
		var payload := {"schema_version": 1, "discovery_flags": _discovery_flags.duplicate(true)}
		var result: Dictionary = await CentralBackend.server_save_world_entity(entity_id, "dungeon_discoveries", "dungeon-progression", _discovery_backend_revision, payload)
		if bool(result.get("ok", false)):
			_discovery_backend_revision = int(result.get("body", {}).get("revision", _discovery_backend_revision))
			if MMORPGNetwork.is_online():
				rpc("receive_dungeon_discoveries", _discovery_flags.duplicate(true))
		else:
			push_warning("Dungeon discovery persistence failed; local progress remains queued for retry: %s" % str(result.get("error", result.get("status", "unknown"))))
			_discovery_save_queued = true
			_discovery_retry_timer = 10.0
			break
		if not _discovery_save_queued:
			break
	_discovery_save_busy = false

func has_discovery(floor_i: int, kind: String) -> bool:
	return bool(_discovery_flags.get("%d:%s" % [floor_i, kind], false))

func mark_discovery(floor_i: int, kind: String) -> void:
	_discovery_flags["%d:%s" % [floor_i, kind]] = true
	if MMORPGNetwork.is_authority() and WorldDeploymentGuard.production_mode:
		call_deferred("_persist_dungeon_discoveries")
	var player: Node3D = GameManager.player
	if player and player.get("skills") != null:
		player.skills.train("knowledge", 0.65 if kind == "secret" else 0.28)
		player.skills.train("wisdom", 0.32 if kind == "secret" else 0.12)
		player.skills.train("observation", 0.4)
		if kind == "secret":
			player.skills.train("ancient_lore", 0.7)

func is_arcane_surge_active() -> bool:
	return inside and _active_world_event == "ARCANE_SURGE"

func _add_secret_puzzle(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var secret := Area3D.new()
	secret.name = "RunicSecretDoor_Floor_%d" % (floor_i + 1)
	secret.position = _maze_cell_position(cell) + Vector3(0, 1.1, 0)
	secret.add_to_group("interactable")
	secret.add_to_group("dungeon_discovery")
	secret.set_meta("interact_range", 3.0)
	secret.set_meta("floor", floor_i)
	secret.set_script(load("res://entities/dungeon_secret.gd"))
	var slab := MeshInstance3D.new()
	var bm := BoxMesh.new(); bm.size = Vector3(2.4, 2.2, 0.35); slab.mesh = bm
	var mat := StandardMaterial3D.new(); mat.albedo_color = Color(0.16, 0.13, 0.24); mat.emission_enabled = true; mat.emission = Color(0.24, 0.12, 0.5); mat.emission_energy_multiplier = 0.65
	slab.material_override = mat
	secret.add_child(slab)
	var glyph := Label3D.new(); glyph.text = "ᚱ ᚨ ᚾ"; glyph.position.y = 0.15; glyph.font_size = 42; glyph.modulate = Color(0.65, 0.45, 1.0); secret.add_child(glyph)
	# A sealed side-chamber is physically built behind the rune slab; solving the lock
	# reveals the chamber's relic plinth and a second, floor-scaled cache reward.
	var alcove := Node3D.new()
	alcove.name = "HiddenCivilizationAlcove"
	alcove.position = Vector3(0, -0.8, -5.0)
	alcove.visible = false
	secret.add_child(alcove)
	var alcove_floor := MeshInstance3D.new()
	var alcove_mesh := BoxMesh.new(); alcove_mesh.size = Vector3(5.5, 0.35, 5.0)
	alcove_floor.mesh = alcove_mesh
	var alcove_mat := StandardMaterial3D.new(); alcove_mat.albedo_color = Color(0.17, 0.16, 0.22); alcove_mat.roughness = 0.92
	alcove_floor.material_override = alcove_mat; alcove_floor.position = Vector3(0, -0.7, 0); alcove.add_child(alcove_floor)
	var relic := MeshInstance3D.new(); var relic_mesh := PrismMesh.new(); relic_mesh.size = Vector3(1.0, 1.5, 1.0); relic.mesh = relic_mesh
	var relic_mat := StandardMaterial3D.new(); relic_mat.albedo_color = Color(0.48, 0.32, 0.78); relic_mat.emission_enabled = true; relic_mat.emission = Color(0.34, 0.18, 0.8); relic_mat.emission_energy_multiplier = 1.5
	relic.material_override = relic_mat; relic.position.y = 0.45; alcove.add_child(relic)
	var relic_label := Label3D.new(); relic_label.text = "LOST RELIQUARY"; relic_label.position = Vector3(0, 1.5, 0); relic_label.font_size = 24; relic_label.modulate = Color(0.8, 0.68, 1.0); alcove.add_child(relic_label)
	secret.set_meta("hidden_alcove_node", alcove)
	room.add_child(secret)

func _add_dungeon_memory_tablet(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var tablet := Area3D.new()
	tablet.name = "CivilizationMemoryTablet_Floor_%03d" % (floor_i + 1)
	tablet.position = _maze_cell_position(cell) + Vector3(0, 0.85, 0)
	tablet.add_to_group("interactable")
	tablet.add_to_group("dungeon_discovery")
	tablet.set_meta("floor", floor_i)
	tablet.set_meta("interact_range", 3.2)
	tablet.set_script(load("res://entities/dungeon_memory_tablet.gd"))
	var palette: Dictionary = _floor_palette(floor_i)
	var stone: Color = palette.get("stone", Color(0.3, 0.3, 0.34))
	var glow: Color = palette.get("glow", Color(0.5, 0.7, 1.0))
	var pedestal := MeshInstance3D.new()
	var base_mesh := CylinderMesh.new()
	base_mesh.top_radius = 0.72
	base_mesh.bottom_radius = 0.9
	base_mesh.height = 0.72
	pedestal.mesh = base_mesh
	var base_mat := StandardMaterial3D.new()
	base_mat.albedo_color = stone.lightened(0.12)
	base_mat.roughness = 0.9
	pedestal.material_override = base_mat
	pedestal.position.y = -0.32
	tablet.add_child(pedestal)
	var slab := MeshInstance3D.new()
	var slab_mesh := BoxMesh.new()
	slab_mesh.size = Vector3(1.12, 1.42, 0.18)
	slab.mesh = slab_mesh
	var slab_mat := StandardMaterial3D.new()
	slab_mat.albedo_color = stone.darkened(0.08)
	slab_mat.roughness = 0.82
	slab.material_override = slab_mat
	slab.position = Vector3(0, 0.95, 0)
	tablet.add_child(slab)
	var glyph := MeshInstance3D.new()
	var glyph_mesh := BoxMesh.new()
	glyph_mesh.size = Vector3(0.36, 0.62, 0.06)
	glyph.mesh = glyph_mesh
	var glyph_mat := StandardMaterial3D.new()
	glyph_mat.albedo_color = glow
	glyph_mat.emission_enabled = true
	glyph_mat.emission = glow
	glyph_mat.emission_energy_multiplier = 1.35
	glyph.material_override = glyph_mat
	glyph.position = Vector3(0, 0.96, -0.13)
	tablet.add_child(glyph)
	var light := OmniLight3D.new()
	light.light_color = glow
	light.light_energy = 0.35
	light.omni_range = 3.4
	light.position = Vector3(0, 1.35, 0.1)
	tablet.add_child(light)
	room.add_child(tablet)

func _add_dungeon_cache(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var cache := Area3D.new()
	cache.name = "ForgottenCache_Floor_%d" % (floor_i + 1)
	cache.position = _maze_cell_position(cell) + Vector3(0, 0.8, 0)
	cache.add_to_group("interactable")
	cache.add_to_group("dungeon_discovery")
	cache.set_meta("dungeon_floor", floor_i)
	cache.set_meta("interact_range", 3.2)
	cache.set_script(load("res://entities/dungeon_cache.gd"))
	cache.set_meta("floor", floor_i)
	var body := StaticBody3D.new()
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new(); box.size = Vector3(1.5, 1.0, 1.0); mesh.mesh = box
	var mat := StandardMaterial3D.new(); mat.albedo_color = Color(0.32, 0.19, 0.08); mat.metallic = 0.55; mat.roughness = 0.45
	mesh.material_override = mat; body.add_child(mesh); cache.add_child(body)
	var lid := MeshInstance3D.new(); var lm := BoxMesh.new(); lm.size = Vector3(1.6, 0.18, 1.08); lid.mesh = lm; lid.position.y = 0.58
	var gold := StandardMaterial3D.new(); gold.albedo_color = Color(0.78, 0.53, 0.16); gold.metallic = 0.75; lid.material_override = gold; cache.add_child(lid)
	var light := OmniLight3D.new(); light.light_color = Color(1.0, 0.68, 0.24); light.light_energy = 0.7; light.omni_range = 4.5; light.position.y = 1.3; cache.add_child(light)
	room.add_child(cache)

func _add_dungeon_shrine(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var shrine := Area3D.new(); shrine.name = "AncientSkillShrine"; shrine.position = _maze_cell_position(cell) + Vector3(0, 0.4, 0)
	shrine.add_to_group("interactable"); shrine.add_to_group("dungeon_discovery"); shrine.set_meta("dungeon_floor", floor_i); shrine.set_meta("interact_range", 3.2); shrine.set_meta("floor", floor_i)
	shrine.set_script(load("res://entities/dungeon_shrine.gd"))
	var pillar := MeshInstance3D.new(); var pm := CylinderMesh.new(); pm.top_radius = 0.45; pm.bottom_radius = 0.7; pm.height = 1.5; pillar.mesh = pm
	var mat := StandardMaterial3D.new(); mat.albedo_color = Color(0.25, 0.34, 0.48); mat.emission_enabled = true; mat.emission = Color(0.16, 0.42, 0.9); mat.emission_energy_multiplier = 0.8; pillar.material_override = mat; shrine.add_child(pillar)
	var light := OmniLight3D.new(); light.light_color = Color(0.2, 0.55, 1.0); light.light_energy = 1.0; light.omni_range = 6.0; light.position.y = 1.4; shrine.add_child(light)
	room.add_child(shrine)

func _add_dungeon_hazard(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var palette: Dictionary = _floor_palette(floor_i)
	var hazard := Area3D.new()
	hazard.name = "FloorHazard_%d" % (floor_i + 1)
	hazard.position = _maze_cell_position(cell) + Vector3(0, 0.18, 0)
	hazard.add_to_group("dungeon_discovery")
	hazard.set_script(load("res://entities/dungeon_hazard.gd"))
	hazard.set("hazard_name", str(palette.get("hazard", "Unstable floor")))
	hazard.set("warning_text", str(palette.get("hazard_text", "An ancient danger flares.")))
	hazard.set("hazard_color", palette["glow"])
	hazard.set("damage", 5.5 + float(floor_i) * 0.24)
	hazard.set("cooldown", 4.5)
	var plate := MeshInstance3D.new(); plate.name = "HazardPlate"
	var disc := CylinderMesh.new(); disc.top_radius = 1.25; disc.bottom_radius = 1.45; disc.height = 0.12; disc.radial_segments = 12; plate.mesh = disc
	var mat := StandardMaterial3D.new(); mat.albedo_color = palette["glow"].darkened(0.25); mat.emission_enabled = true; mat.emission = palette["glow"]; mat.emission_energy_multiplier = 0.55; mat.roughness = 0.4
	plate.material_override = mat; hazard.add_child(plate)
	var ring := MeshInstance3D.new(); ring.name = "WarningRing"; var torus := TorusMesh.new(); torus.inner_radius = 1.05; torus.outer_radius = 1.15; ring.mesh = torus; ring.material_override = mat; ring.position.y = 0.22; ring.rotation.x = PI * 0.5; hazard.add_child(ring)
	var lamp := OmniLight3D.new(); lamp.name = "WarningLight"; lamp.light_color = palette["glow"]; lamp.light_energy = 0.55; lamp.omni_range = 3.5; lamp.position.y = 0.4; hazard.add_child(lamp)
	var collision := CollisionShape3D.new(); var shape := CylinderShape3D.new(); shape.radius = 1.55; shape.height = 1.1; collision.shape = shape; collision.position.y = 0.42; hazard.add_child(collision)
	room.add_child(hazard)

func _add_civilization_trial(room: Node3D, cell: Vector2i, floor_i: int) -> void:
	var palette: Dictionary = _floor_palette(floor_i)
	var trial := Area3D.new(); trial.name = "CivilizationMemory_%s" % str(palette["civilization"]).replace(" ", "")
	trial.position = _maze_cell_position(cell) + Vector3(0, 0.2, 0)
	trial.set_script(load("res://entities/dungeon_civilization_trial.gd"))
	trial.set("civilization_name", str(palette["civilization"])); trial.set("history", str(palette["history"])); trial.set("puzzle_hint", str(palette["puzzle_hint"])); trial.set("relic_id", str(palette["relic"])); trial.set("floor_index", floor_i); trial.set("glow_color", palette["glow"])
	var plinth := MeshInstance3D.new(); var plinth_mesh := BoxMesh.new(); plinth_mesh.size = Vector3(2.4, 0.8, 1.5); plinth.mesh = plinth_mesh; plinth.position.y = 0.42
	var stone_mat := StandardMaterial3D.new(); stone_mat.albedo_color = palette["stone"].lightened(0.12); stone_mat.roughness = 0.82; plinth.material_override = stone_mat; trial.add_child(plinth)
	var tablet := MeshInstance3D.new(); var tablet_mesh := BoxMesh.new(); tablet_mesh.size = Vector3(1.55, 1.75, 0.22); tablet.mesh = tablet_mesh; tablet.position = Vector3(0, 1.55, -0.45)
	var tablet_mat := StandardMaterial3D.new(); tablet_mat.albedo_color = palette["trim"]; tablet_mat.metallic = 0.3; tablet_mat.roughness = 0.55; tablet.material_override = tablet_mat; trial.add_child(tablet)
	var inscription := Label3D.new(); inscription.text = str(palette["civilization"]).to_upper() + "\nMEMORY SEAL"; inscription.font_size = 20; inscription.position = Vector3(0, 1.55, -0.59); inscription.modulate = palette["glow"]; inscription.outline_size = 4; trial.add_child(inscription)
	for rune_i in range(4):
		var rune := MeshInstance3D.new(); rune.name = "MemoryRune_%d" % (rune_i + 1); var rune_mesh := SphereMesh.new(); rune_mesh.radius = 0.13; rune_mesh.height = 0.26; rune.mesh = rune_mesh
		var rune_mat := StandardMaterial3D.new(); rune_mat.albedo_color = palette["glow"]; rune_mat.emission_enabled = true; rune_mat.emission = palette["glow"]; rune_mat.emission_energy_multiplier = 1.2; rune.material_override = rune_mat; rune.position = Vector3(-0.52 + float(rune_i) * 0.35, 1.2, -0.6); trial.add_child(rune)
	var light := OmniLight3D.new(); light.light_color = palette["glow"]; light.light_energy = 0.8; light.omni_range = 5.0; light.position.y = 1.9; trial.add_child(light)
	room.add_child(trial)

func _spawn_in_room(room: Node3D, f: int, id: String, boss: bool, display: String, base_hp: float, base_dmg: float, color: Color, diff: float, forced_cell: Vector2i = Vector2i(-1, -1)) -> Node:
	var m: Monster = MONSTER_SCENE.instantiate()
	m.monster_id = id
	m.is_boss = boss
	m.display_name = ("Floor %d: %s" % [f + 1, display]) if boss else display
	var raid_hp_scale: float = 2.6 + float(f) * 0.032 if boss else 1.0
	var raid_damage_scale: float = 1.12 + float(f) * 0.004 if boss else 1.0
	m.max_hp = base_hp * diff * raid_hp_scale
	m.damage = base_dmg * (0.85 + diff * 0.15) * raid_damage_scale
	m.body_color = color
	m.move_speed = (3.4 + mini(float(f) * 0.018, 1.0)) if boss else (3.2 + mini(float(f) * 0.02, 1.2))
	m.xp_train = 0.65 + float(f) * 0.035
	m.gold_min = int(12 + f * 1.1) if boss else int(3 + f * 0.8)
	m.gold_max = int(35 + f * 2.2) if boss else int(10 + f * 1.5)
	m.aggro_range = 22.0 if boss else 14.0
	m.attack_range = 3.5 if boss else 2.2
	m.leash_range = 22.0 if boss else 28.0
	# Local position inside room. Raid guardians occupy the centre of the wide sanctum.
	if boss:
		m.position = _boss_arena_center() + Vector3(0, 0.36, 0)
		m.scale = Vector3.ONE * (1.55 + minf(float(f) * 0.006, 0.55))
		m.set_meta("raid_boss", true)
		m.set_meta("raid_floor", f + 1)
		m.set_meta("raid_pattern_index", f % 4)
		m.set_meta("raid_civilization", str(_floor_palette(f).get("civilization", "Unknown")))
	else:
		var spawn_cell: Vector2i = forced_cell
		if spawn_cell.x < 0:
			var spawn_candidates: Array[Vector2i] = []
			for candidate in _maze_cells:
				if candidate == MAZE_START or candidate == MAZE_GOAL:
					continue
				if candidate.distance_to(MAZE_GOAL) < 3.5 or candidate.distance_to(MAZE_START) < 1.4:
					continue
				spawn_candidates.append(candidate)
			spawn_cell = spawn_candidates[randi_range(0, spawn_candidates.size() - 1)] if not spawn_candidates.is_empty() else MAZE_START
		m.position = _maze_cell_position(spawn_cell) + Vector3(randf_range(-3.0, 3.0), 0.36, randf_range(-3.0, 3.0))
	m.set_meta("dungeon_floor", f)
	m.set_meta("floor_boss", boss)
	var combat_profile: Dictionary = CIVILIZATION_COMBAT[clampi(int(f / 10), 0, 9)]
	m.set_meta("dungeon_faction", str(combat_profile.get("faction", "Depthless")))
	m.set_meta("dungeon_faction_id", str(CivilizationSocieties.culture_for_floor(f + 1).get("id", "labyrinth")))
	m.set_meta("dungeon_tactic", str(combat_profile.get("tactic", "hunt")))
	m.set_meta("dungeon_resistances", combat_profile.get("resist", {}))
	if boss:
		m.set_meta("dungeon_signature_pattern", str(combat_profile.get("pattern", "ring_slam")))
	else:
		var pack_number: int = int((m.position.x + MAZE_HALF) / 36.0) + int((m.position.z + MAZE_HALF) / 36.0) * 4
		m.set_meta("pack_id", "floor_%d_faction_%d" % [f, pack_number])
		m.set_meta("pack_role", "captain" if display.begins_with("Elite") or display.begins_with("Patrol") else ("flanker" if id in ["grey_wolf", "grave_hound", "frost_lynx", "fungal_stalker", "prism_stalker"] else "guard"))
	room.add_child(m)
	# After _ready, lock home to dungeon position so raid guardians cannot be dragged out of their sanctum.
	m.home = m.global_position
	MMORPGNetwork.broadcast_world_monster_spawn(m)
	if boss:
		_floor_boss = m
		_boss_alive = true
		if m.health:
			m.health.died.connect(_on_floor_boss_died.bind(f), CONNECT_ONE_SHOT)
	return m

func _spawn_floor_boss(f: int, room: Node3D, diff: float) -> void:
	var band: int = clampi(int(f / 10), 0, 9)
	var title: String = str(RAID_BOSS_TITLES[band][f % 10])
	var archetype_index: int = (f * 7 + band * 3) % (BOSSES.size() - 1)
	var b: Dictionary = BOSSES[archetype_index]
	# The tenth floor of every civilization is its greater raid guardian.
	if (f + 1) % 10 == 0:
		b = BOSSES[9 + (band % 3)]
	if f >= FLOORS - 1:
		b = BOSSES[BOSSES.size() - 1]
		title = "The Eternal Archive's Final Sovereign"
	if _cleared_floors.has(str(f)):
		return
	var milestone_scale: float = 1.22 if (f + 1) % 10 == 0 else 1.0
	if f >= FLOORS - 1:
		milestone_scale = 1.45
	var palette: Dictionary = _floor_palette(f)
	var base_boss_color: Color = b["color"]
	var culture_glow: Color = palette["glow"]
	var themed_boss_color: Color = base_boss_color.lerp(culture_glow, 0.28)
	_spawn_in_room(room, f, str(b["id"]), true, title, float(b["hp"]), float(b["dmg"]), themed_boss_color, diff * milestone_scale)

func _on_floor_boss_died(_source: Node, f: int) -> void:
	if not MMORPGNetwork.is_authority() or _cleared_floors.has(str(f)):
		return
	var record := {"floor": f, "cleared_at": Time.get_unix_time_from_system()}
	var committed := false
	if WorldDeploymentGuard.production_mode:
		var boss_id := "labyrinth_floor_%d" % f
		var stable_id := MMORPGNetwork._stable_world_uuid("%s:boss:%s" % [MMORPGNetwork.SINGLE_WORLD_ID, boss_id])
		var current_revision := int(_floor_clear_revisions.get(str(f), 0))
		var result: Dictionary = await CentralBackend.server_save_boss_encounter(stable_id, "elyndor", boss_id, current_revision, record)
		committed = bool(result.get("ok", false))
		if committed:
			_floor_clear_revisions[str(f)] = int(result.get("body", {}).get("revision", current_revision))
	else:
		committed = MMORPGWorldState.set_world_value("dungeon_clears", str(f), record)
	if not committed:
		EventBus.toast.emit("Floor victory could not be saved. The gate remains sealed; the guardian will return.", "warning")
		if _rooms.has(f):
			_spawn_floor_boss(f, _rooms[f], _difficulty(f))
		return
	_cleared_floors[str(f)] = record
	deepest_cleared = maxi(deepest_cleared, f + 1)
	if MMORPGNetwork.is_online():
		rpc("receive_floor_clears", _cleared_floors)
		MMORPGNetwork._broadcast_network_notice("Floor %d conquered! Floor %d is now open to the server." % [f + 1, mini(f + 2, FLOORS)], "levelup")
	if not inside or f != current_floor:
		return
	AncientInheritanceSystem.record_floor_boss_defeated(f + 1)
	_boss_alive = false
	_floor_boss = null
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition:
		expedition.floors_cleared = maxi(expedition.floors_cleared, f + 1)
		expedition.deepest_floor = maxi(expedition.deepest_floor, f + 1)
		expedition._emit_changed()
	if f + 1 > deepest_cleared:
		deepest_cleared = f + 1
	EventBus.toast.emit("Floor %d boss defeated! Gate open." % (f + 1), "levelup")
	PlayerData.add_gold(15 + f * 4)
	var boss_materials: Array = [
		["slime_core", "chitin", "ectoplasm"],
		["spore_sac", "moonpetal", "mana_crystal"],
		["prism_shard", "moonstone_ore", "rune_fragment"],
		["rune_fragment", "forgotten_essence", "runebound_core"],
		["cinder_core", "dragonbone", "forgotten_essence"],
		["moonstone_ore", "ancient_scale", "runebound_core"],
		["drowned_sigil", "serpent_scale", "pearl"],
		["voidsilk", "abyssal_chitin", "heart_of_depths"],
		["abyssal_relic", "runebound_core", "heart_of_depths"],
		["heart_of_depths", "ancient_scale", "abyssal_relic"]
	]
	var boss_band: int = mini(int(f / 10), boss_materials.size() - 1)
	var boss_drop: Array = boss_materials[boss_band]
	PlayerData.add_item(str(boss_drop[randi_range(0, boss_drop.size() - 1)]), 1)
	var boss_player: Node3D = GameManager.player
	if boss_player and boss_player.get("skills") != null:
		boss_player.skills.train("knowledge", 0.55)
		boss_player.skills.train("wisdom", 0.35)
		boss_player.skills.train("monster_lore", 0.8)
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg:
		sg.add_progress("elyndor", 3.0 + float(f) * 0.35, "floor boss")
	if (f + 1) % 10 == 0:
		PlayerData.add_item("mana_crystal", 1 + int((f + 1) / 20))
		EventBus.toast.emit("Milestone reward: mana crystal!", "levelup")

func is_boss_defeated() -> bool:
	return _cleared_floors.has(str(current_floor))

func try_advance_or_exit() -> void:
	if MMORPGNetwork.is_online():
		_request_travel("advance")
		return
	if not inside:
		return
	if not is_boss_defeated():
		EventBus.toast.emit("Defeat this floor's boss to open the gate!", "warning")
		return
	if current_floor >= FLOORS - 1:
		exit_dungeon(true)
		return
	var next_f: int = current_floor + 1
	await _show_loading_screen("DESCENDING TO FLOOR %d" % (next_f + 1), str(_floor_palette(next_f).name) + " • " + str(_floor_weather))
	# Create the room before switching visibility. A newly created room starts
	# hidden, so the old order made every first visit to a floor look empty.
	var room: Node3D = _ensure_room(next_f)
	_apply_dungeon_environment(next_f)
	_show_floor(next_f)
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition:
		expedition.on_floor_entered(next_f + 1)
		if ElyndorRegionLife and ElyndorRegionLife.has_method("record_dungeon_floor"):
			ElyndorRegionLife.record_dungeon_floor(next_f + 1)
	var player = GameManager.player
	if player:
		player.global_position = room.global_position + _maze_cell_position(MAZE_START) + Vector3(0, 0.34, 0)
		player.velocity = Vector3.ZERO
	EventBus.toast.emit("Floor %d / %d — %s" % [next_f + 1, FLOORS, _floor_palette(next_f)["name"]], "scene")
	EventBus.toast.emit("Floor conditions: %s" % _floor_weather.capitalize(), "info")
	_spawn_floor_content(next_f)
	if player and player.get("skills") != null:
		player.skills.train("dungeon_delving", 0.7 + float(next_f) * 0.015)
		player.skills.train("exploration", 0.3)
		player.skills.train("observation", 0.18)
		player.skills.train("knowledge", 0.08)

func get_save_state() -> Dictionary:
	return {
		"inside": inside,
		"current_floor": current_floor,
		"deepest_cleared": deepest_cleared,
		"discovered_floors": _discovered_floors.duplicate(),
		"discovery_flags": _discovery_flags.duplicate(true),
		"explored_cells": _explored_cells.duplicate(true),
		"expedition": get_node_or_null("/root/DungeonExpedition").get_snapshot() if get_node_or_null("/root/DungeonExpedition") else {},
		"checkpoint_floor": _checkpoint_floor,
		"checkpoint_position": {"x": _checkpoint_position.x, "y": _checkpoint_position.y, "z": _checkpoint_position.z},
		"return_position": {"x": _return_pos.x, "y": _return_pos.y, "z": _return_pos.z}
	}

func restore_from_save(state: Dictionary) -> void:
	_explored_cells = state.get("explored_cells", {}).duplicate(true)
	_discovery_flags = state.get("discovery_flags", {}).duplicate(true)
	deepest_cleared = clampi(int(state.get("deepest_cleared", 0)), 0, FLOORS)
	if MMORPGNetwork.is_online():
		_request_travel("resume")
		return
	var player = GameManager.player
	if not bool(state.get("inside", false)):
		inside = false
		remove_from_group("dungeon_active")
		for key in _rooms.keys():
			_rooms[key].visible = false
		return
	current_floor = clampi(int(state.get("current_floor", 0)), 0, FLOORS - 1)
	PlayerData.stats["deepest_dungeon_floor"] = maxi(int(PlayerData.stats.get("deepest_dungeon_floor", 0)), current_floor + 1)
	deepest_cleared = clampi(int(state.get("deepest_cleared", 0)), 0, FLOORS)
	_discovered_floors.clear()
	_discovery_flags = state.get("discovery_flags", {}).duplicate(true)
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition and state.get("expedition", {}) is Dictionary:
		expedition.restore_snapshot(state.get("expedition", {}))
	for discovered in state.get("discovered_floors", []):
		_discovered_floors.append(int(discovered))
	var rp: Dictionary = state.get("return_position", {})
	_return_pos = Vector3(float(rp.get("x", 0.0)), float(rp.get("y", 0.0)), float(rp.get("z", 0.0)))
	_checkpoint_floor = clampi(int(state.get("checkpoint_floor", 1)), 1, FLOORS)
	var cp: Dictionary = state.get("checkpoint_position", {})
	_checkpoint_position = Vector3(float(cp.get("x", 0.0)), float(cp.get("y", 0.0)), float(cp.get("z", 0.0)))
	inside = true
	if not is_in_group("dungeon_active"):
		add_to_group("dungeon_active")
	var room: Node3D = _ensure_room(current_floor)
	_apply_dungeon_environment(current_floor)
	_show_floor(current_floor)
	_spawn_floor_content(current_floor)
	if player:
		if _checkpoint_position != Vector3.ZERO and _checkpoint_floor == current_floor + 1:
			player.global_position = _checkpoint_position
		else:
			player.global_position = room.global_position + _maze_cell_position(MAZE_START) + Vector3(0, 0.34, 0)
		player.velocity = Vector3.ZERO

func exit_dungeon(cleared: bool = false) -> void:
	if MMORPGNetwork.is_online():
		_request_travel("leave")
		return
	await _show_loading_screen("RETURNING TO ELYNDOR", "Leaving the Depths of Elyndor")
	inside = false
	if _dungeon_map_layer and is_instance_valid(_dungeon_map_layer):
		_dungeon_map_layer.queue_free()
		_dungeon_map_layer = null
		GameManager.pop_ui_lock()
	_restore_overworld_environment()
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition and expedition.active:
		expedition.finish_expedition(cleared)
	remove_from_group("dungeon_active")
	for k in _rooms.keys():
		_rooms[k].visible = false
	var player = GameManager.player
	if player:
		if _entrance:
			player.global_position = _entrance.global_position + Vector3(0, 0.4, 3)
		elif _return_pos != Vector3.ZERO:
			player.global_position = _return_pos
		player.velocity = Vector3.ZERO
	if cleared:
		EventBus.toast.emit("You conquered all %d floors! Elyndor celebrates." % FLOORS, "levelup")
		PlayerData.grant_title("Unyielding")
		PlayerData.add_gold(200)
		PlayerData.add_item("mana_crystal", 5)
		var sg = get_tree().get_first_node_in_group("settlement_growth")
		if sg:
			sg.add_progress("elyndor", 40.0, "full clear")
	else:
		EventBus.toast.emit("Left the Depths (cleared up to floor %d)." % deepest_cleared, "info")
