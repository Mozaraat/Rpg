# Visible sect civilization layer: headquarters, resident disciples and travelling patrols.
# Presentation actors are deterministic on every client; strategic state remains owned by SectSimulation/MMORPGNetwork.
extends Node3D

const SECT_CAMPS: Array[Dictionary] = [
	{"id":"azure_sword_hall", "name":"Azure Sword Hall", "region":"Elyndor Heartlands", "center":Vector2(-25.0, -30.0), "tint":Color(0.22, 0.48, 0.92), "banner":"AZURE"},
	{"id":"crimson_pavilion", "name":"Crimson Phoenix Pavilion", "region":"Emberfall Reach", "center":Vector2(206.0, -8.0), "tint":Color(0.86, 0.22, 0.16), "banner":"PHOENIX"},
	{"id":"stillwater_monastery", "name":"Stillwater Monastery", "region":"Mirrorwater Basin", "center":Vector2(47.0, -9.0), "tint":Color(0.25, 0.72, 0.82), "banner":"STILLWATER"},
	{"id":"stormspire_order", "name":"Stormspire Order", "region":"Ironback Range", "center":Vector2(132.0, -104.0), "tint":Color(0.62, 0.65, 0.9), "banner":"STORMSPIRE"},
	{"id":"veiled_moon_covenant", "name":"Veiled Moon Covenant", "region":"Whispering Woods", "center":Vector2(-112.0, 12.0), "tint":Color(0.48, 0.35, 0.72), "banner":"VEILED MOON"},
	{"id":"rootbound_circle", "name":"Rootbound Circle", "region":"Amberleaf Glade", "center":Vector2(18.0, -112.0), "tint":Color(0.32, 0.65, 0.28), "banner":"ROOTBOUND"}
]
const ACTIVE_RADIUS := 155.0
const RESIDENT_COUNT := 4
const PATROL_COUNT := 5
const WALK_SPEED := 1.25
const SECT_ROUTES: Dictionary = {
	"azure_sword_hall": Vector2(-112.0, 12.0),
	"crimson_pavilion": Vector2(132.0, -104.0),
	"stillwater_monastery": Vector2(-25.0, -30.0),
	"stormspire_order": Vector2(18.0, -112.0),
	"veiled_moon_covenant": Vector2(-150.0, 112.0),
	"rootbound_circle": Vector2(47.0, -9.0)
}

var _terrain: TerrainNoise
var _camp_nodes: Dictionary = {}
var _last_player_position := Vector3(INF, INF, INF)
var _refresh_timer := 0.0
var _simulation_clock := 0.0

func _ready() -> void:
	add_to_group("sect_civilization_presence")
	_terrain = TerrainNoise.new(GameManager.world_seed)

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_simulation_clock += delta
	_refresh_timer += delta
	if _refresh_timer >= 2.0:
		_refresh_timer = 0.0
		_refresh_near_player()
	_step_patrols(delta)
	_step_residents(delta)

func _refresh_near_player() -> void:
	var player := GameManager.player as Node3D
	if not is_instance_valid(player):
		return
	if _last_player_position.distance_to(player.global_position) < 24.0:
		return
	_last_player_position = player.global_position
	for camp in SECT_CAMPS:
		var sect_id := str(camp.id)
		var center: Vector2 = camp.center
		var distance := Vector2(player.global_position.x, player.global_position.z).distance_to(center)
		if distance <= ACTIVE_RADIUS and not _camp_nodes.has(sect_id):
			_build_camp(camp)
		elif distance > ACTIVE_RADIUS * 1.35 and _camp_nodes.has(sect_id):
			_remove_camp(sect_id)

func _build_camp(camp: Dictionary) -> void:
	var sect_id := str(camp.id)
	var root := Node3D.new()
	root.name = "SectFrontierOutpost_" + sect_id
	add_child(root)
	# Several authored anchors sit on top of settlements or inside water. Resolve
	# them to the nearest flat, dry, open patch so outposts never bury the plaza
	# fountain or float in a lake.
	var center: Vector2 = _find_safe_center(camp.center)
	var safe_camp: Dictionary = camp.duplicate()
	safe_camp.center = center
	var ground := _terrain.get_height(center.x, center.y)
	root.position = Vector3(center.x, ground, center.y)
	_build_headquarters(root, safe_camp)
	var residents: Array[Dictionary] = []
	for i in range(RESIDENT_COUNT):
		var resident := _make_disciple(str(camp.name), camp.tint, i, false)
		root.add_child(resident)
		var offset := Vector3(float((i % 2) * 3 - 1), 0.0, float((i / 2) * 3 - 1))
		resident.position = offset
		residents.append({"node":resident, "phase":float(i) * 1.7, "home":offset})
	var patrols: Array[Dictionary] = []
	for i in range(PATROL_COUNT):
		var patrol := _make_disciple(str(camp.name), camp.tint, i, true)
		root.add_child(patrol)
		var offset := Vector3(-8.0 + float(i % 3) * 1.5, 0.0, -5.0 + float(i / 3) * 1.5)
		patrol.position = offset
		patrols.append({"node":patrol, "phase":float(i) * 1.2, "origin":offset, "target":_patrol_target(sect_id, i), "outbound":true})
	_camp_nodes[sect_id] = {"root":root, "residents":residents, "patrols":patrols, "camp":safe_camp}

## Spiral out from an authored anchor until we find dry, gently sloped ground
## outside any settlement's cleared area. Falls back to the original anchor.
func _find_safe_center(desired: Vector2) -> Vector2:
	var best := desired
	var best_score := -INF
	for ring in range(0, 11):
		var radius := float(ring) * 6.0
		var samples := 1 if ring == 0 else 16
		for i in range(samples):
			var a: float = TAU * float(i) / float(samples)
			var p: Vector2 = desired + Vector2(cos(a), sin(a)) * radius
			var h: float = _terrain.get_height(p.x, p.y)
			if h < 1.5 or h > 14.0:
				continue
			if _terrain.settlement_mask(p.x, p.y) > 0.02:
				continue
			var slope: float = maxf(
				absf(_terrain.get_height(p.x + 3.0, p.y) - h),
				absf(_terrain.get_height(p.x, p.y + 3.0) - h))
			if slope > 1.35:
				continue
			var score: float = -radius - slope * 4.0
			if score > best_score:
				best_score = score
				best = p
	return best

func _build_headquarters(root: Node3D, camp: Dictionary) -> void:
	var tint: Color = camp.tint
	var platform := MeshInstance3D.new()
	var slab := CylinderMesh.new()
	slab.top_radius = 5.6
	slab.bottom_radius = 6.2
	slab.height = 0.35
	platform.mesh = slab
	platform.position.y = 0.17
	platform.material_override = BuildingKit.get_material("cobble")
	root.add_child(platform)
	for i in range(3):
		var pillar := MeshInstance3D.new()
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.36
		mesh.bottom_radius = 0.5
		mesh.height = 3.2
		pillar.mesh = mesh
		var angle := TAU * float(i) / 3.0
		pillar.position = Vector3(cos(angle) * 4.3, 1.75, sin(angle) * 4.3)
		pillar.material_override = BuildingKit.get_material("stone")
		root.add_child(pillar)
	# A proper roofed hall reads as a building instead of a flat blue box.
	var hall: Node3D = BuildingKit.make_house(4.6, 3.6, 2.7, "plaster_white", "roof_blue", tint.lightened(0.35))
	hall.position = Vector3(0.0, 0.35, 1.0)
	root.add_child(hall)
	var label := Label3D.new()
	label.text = str(camp.name) + "\nFRONTIER OUTPOST  •  " + str(camp.region)
	label.position = Vector3(0.0, 6.6, 0.0)
	label.font_size = 32
	label.pixel_size = 0.006
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.modulate = Color(1.0, 0.9, 0.68)
	root.add_child(label)
	var banner := MeshInstance3D.new()
	var banner_mesh := BoxMesh.new()
	banner_mesh.size = Vector3(1.5, 1.9, 0.12)
	banner.mesh = banner_mesh
	banner.position = Vector3(0.0, 3.4, -3.5)
	var banner_mat := StandardMaterial3D.new()
	banner_mat.albedo_color = tint
	banner_mat.emission_enabled = true
	banner_mat.emission = tint.darkened(0.5)
	banner.material_override = banner_mat
	root.add_child(banner)
	_build_outpost_emblem(root, str(camp.id), tint)

func _build_outpost_emblem(root: Node3D, sect_id: String, tint: Color) -> void:
	var metal := StandardMaterial3D.new()
	metal.albedo_color = tint.lightened(0.18)
	metal.metallic = 0.68
	metal.roughness = 0.28
	var glow := StandardMaterial3D.new()
	glow.albedo_color = tint.lightened(0.3)
	glow.emission_enabled = true
	glow.emission = tint
	glow.emission_energy_multiplier = 1.25
	match sect_id:
		"azure_sword_hall":
			var blade := BoxMesh.new()
			blade.size = Vector3(0.22, 2.7, 0.16)
			_add_outpost_piece(root, blade, Vector3(0.0, 5.7, -0.15), Vector3(0.0, 0.0, -0.12), metal)
			var guard := BoxMesh.new()
			guard.size = Vector3(1.45, 0.16, 0.22)
			_add_outpost_piece(root, guard, Vector3(0.0, 4.8, -0.15), Vector3(0.0, 0.0, -0.08), glow)
		"crimson_pavilion":
			for wing_side in [-1.0, 1.0]:
				var wing := BoxMesh.new()
				wing.size = Vector3(0.22, 1.75, 0.55)
				_add_outpost_piece(root, wing, Vector3(wing_side * 0.82, 5.15, -0.1), Vector3(0.0, 0.0, -wing_side * 0.48), metal)
			var flame := SphereMesh.new()
			flame.radius = 0.48
			flame.height = 0.95
			_add_outpost_piece(root, flame, Vector3(0.0, 5.45, -0.1), Vector3.ZERO, glow)
		"stillwater_monastery":
			var water_ring := TorusMesh.new()
			water_ring.inner_radius = 0.72
			water_ring.outer_radius = 0.9
			_add_outpost_piece(root, water_ring, Vector3(0.0, 5.2, -0.1), Vector3.ZERO, glow)
			var pearl := SphereMesh.new()
			pearl.radius = 0.28
			pearl.height = 0.56
			_add_outpost_piece(root, pearl, Vector3(0.0, 5.2, -0.1), Vector3.ZERO, metal)
		"stormspire_order":
			var rod := CylinderMesh.new()
			rod.top_radius = 0.055
			rod.bottom_radius = 0.12
			rod.height = 2.8
			_add_outpost_piece(root, rod, Vector3(0.0, 5.7, -0.1), Vector3.ZERO, metal)
			var bolt_top := BoxMesh.new()
			bolt_top.size = Vector3(0.72, 0.16, 0.16)
			_add_outpost_piece(root, bolt_top, Vector3(0.0, 6.15, -0.1), Vector3(0.0, 0.0, 0.48), glow)
			var bolt_low := BoxMesh.new()
			bolt_low.size = Vector3(0.62, 0.16, 0.16)
			_add_outpost_piece(root, bolt_low, Vector3(0.0, 5.55, -0.1), Vector3(0.0, 0.0, -0.48), glow)
		"veiled_moon_covenant":
			var moon_ring := TorusMesh.new()
			moon_ring.inner_radius = 0.62
			moon_ring.outer_radius = 0.78
			_add_outpost_piece(root, moon_ring, Vector3(0.0, 5.35, -0.1), Vector3(PI * 0.5, 0.0, 0.0), metal)
			var moon_core := SphereMesh.new()
			moon_core.radius = 0.25
			moon_core.height = 0.5
			_add_outpost_piece(root, moon_core, Vector3(0.0, 5.35, -0.1), Vector3.ZERO, glow)
		"rootbound_circle":
			var trunk := CylinderMesh.new()
			trunk.top_radius = 0.12
			trunk.bottom_radius = 0.22
			trunk.height = 2.2
			_add_outpost_piece(root, trunk, Vector3(0.0, 5.2, -0.1), Vector3.ZERO, metal)
			for root_side in [-1.0, 1.0]:
				var branch := CylinderMesh.new()
				branch.top_radius = 0.07
				branch.bottom_radius = 0.13
				branch.height = 1.2
				_add_outpost_piece(root, branch, Vector3(root_side * 0.32, 5.9, -0.1), Vector3(0.0, 0.0, -root_side * 0.72), metal)
			var leaf := SphereMesh.new()
			leaf.radius = 0.38
			leaf.height = 0.7
			_add_outpost_piece(root, leaf, Vector3(0.0, 6.55, -0.1), Vector3.ZERO, glow)

func _add_outpost_piece(root: Node3D, mesh: Mesh, position_value: Vector3, rotation_value: Vector3, material: Material) -> void:
	var piece := MeshInstance3D.new()
	piece.mesh = mesh
	piece.position = position_value
	piece.rotation = rotation_value
	piece.material_override = material
	root.add_child(piece)

func _make_disciple(sect_name: String, tint: Color, index: int, armed: bool) -> Node3D:
	var actor := Node3D.new()
	actor.name = ("Patrol" if armed else "Resident") + str(index)
	var model := CharacterModel.new()
	model.name = "CharacterModel"
	actor.add_child(model)
	var asset := "samurai" if armed else ("witch" if index % 2 == 0 else "wizard")
	if sect_name.contains("Moon") and armed:
		asset = "ninja"
	model.build({"asset": asset, "robe": true, "asset_tint": tint.lightened(0.65), "held": "sword" if armed else "none"})
	model.set_motion(0.4 if armed else 0.0)
	var tag := Label3D.new()
	tag.text = "Disciple" if not armed else "Sect Patrol"
	tag.position.y = 2.25
	tag.font_size = 22
	tag.pixel_size = 0.004
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.no_depth_test = true
	tag.modulate = Color(1.0, 0.92, 0.72)
	actor.add_child(tag)
	return actor

func _patrol_target(sect_id: String, index: int) -> Vector2:
	var destination: Vector2 = SECT_ROUTES.get(sect_id, Vector2.ZERO)
	var formation_offset := Vector2(float(index % 2) * 2.5 - 1.25, float(index / 2) * 2.0 - 2.0)
	return destination + formation_offset

func _step_patrols(delta: float) -> void:
	var noise := _terrain
	for entry in _camp_nodes.values():
		var camp: Dictionary = entry.camp
		var center: Vector2 = camp.center
		for patrol in entry.patrols:
			var actor := patrol.node as Node3D
			if not is_instance_valid(actor):
				continue
			var target: Vector2 = patrol.target
			var current := Vector2(actor.position.x + center.x, actor.position.z + center.y)
			var direction := target - current
			if direction.length() < 2.0:
				patrol.outbound = not bool(patrol.outbound)
				if bool(patrol.outbound):
					patrol.target = _patrol_target(str(camp.id), int(patrol.phase / 1.2))
				else:
					patrol.target = center + Vector2(float(int(patrol.phase / 1.2) % 2) * 2.5 - 1.25, float(int(patrol.phase / 1.2) / 2) * 2.0 - 2.0)
				continue
			var step := direction.normalized() * minf(delta * WALK_SPEED, direction.length())
			var next_pos := current + step
			actor.position = Vector3(next_pos.x - center.x, noise.get_height(next_pos.x, next_pos.y) - noise.get_height(center.x, center.y), next_pos.y - center.y)
			actor.look_at(Vector3(target.x, actor.global_position.y, target.y))
			actor.position.y += absf(sin(_simulation_clock * 5.0 + float(patrol.phase))) * 0.035

func _step_residents(delta: float) -> void:
	for entry in _camp_nodes.values():
		for resident in entry.residents:
			var actor := resident.node as Node3D
			if not is_instance_valid(actor):
				continue
			var home: Vector3 = resident.home
			var phase := float(resident.phase)
			actor.position.x = home.x + sin(_simulation_clock * 0.22 + phase) * 0.8
			actor.position.z = home.z + cos(_simulation_clock * 0.18 + phase) * 0.8
			actor.rotation.y = sin(_simulation_clock * 0.12 + phase) * 0.45

func _remove_camp(sect_id: String) -> void:
	var entry: Dictionary = _camp_nodes[sect_id]
	var root := entry.root as Node3D
	if is_instance_valid(root):
		root.queue_free()
	_camp_nodes.erase(sect_id)
