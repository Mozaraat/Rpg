# Places repeatable world activities throughout the overworld.
extends Node3D
class_name WorldActivitySystem

var _noise: TerrainNoise

func _ready() -> void:
	add_to_group("world_activities")
	_noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	_place_all()

func _place_all() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + 88219
	_place("campfire", Vector2(-24.0, 12.0), "Wayfarer's Fire", Color(1.0, 0.38, 0.12), rng)
	_place("campfire", Vector2(24.0, -48.0), "Fisher's Fire", Color(1.0, 0.38, 0.12), rng)
	_place("tracking", Vector2(-58.0, -42.0), "Wolf Trail", Color(0.72, 0.55, 0.34), rng)
	_place("tracking", Vector2(24.0, -18.0), "Deer Crossing", Color(0.72, 0.55, 0.34), rng)
	_place("tracking", Vector2(42.0, 24.0), "Boar Run", Color(0.72, 0.55, 0.34), rng)
	_place("archaeology", Vector2(-70.0, -70.0), "Old Watch Inscription", Color(0.75, 0.62, 0.38), rng)
	_place("archaeology", Vector2(55.0, -30.0), "Broken Arch Tablet", Color(0.75, 0.62, 0.38), rng)
	_place("archaeology", Vector2(-4.0, -98.0), "Buried Expedition", Color(0.75, 0.62, 0.38), rng)
	_place("leyline", Vector2(-10.0, -95.0), "Moonpetal Convergence", Color(0.36, 0.66, 1.0), rng)
	_place("leyline", Vector2(35.0, 10.0), "Stoneheart Convergence", Color(0.36, 0.66, 1.0), rng)
	_place_shoreline(rng, 4)
	print("[Activities] Tracking, shore gathering, cooking, archaeology and leylines placed")

func _ground(x: float, z: float) -> float:
	return _noise.get_height(x, z)

func _place(kind: String, xz: Vector2, label: String, tint: Color, rng: RandomNumberGenerator) -> void:
	var pos := xz
	var height := _ground(pos.x, pos.y)
	if height < -0.1:
		var found_land := false
		for attempt in range(24):
			var candidate := xz + Vector2(rng.randf_range(-18.0, 18.0), rng.randf_range(-18.0, 18.0))
			var sample := _ground(candidate.x, candidate.y)
			if sample >= 0.0:
				pos = candidate
				height = sample
				found_land = true
				break
		if not found_land:
			push_warning("Skipping %s: could not find safe ground near its planned location." % label)
			return
	var activity := Area3D.new()
	activity.name = label.replace(" ", "")
	activity.position = Vector3(pos.x, height, pos.y)
	activity.set_script(load("res://entities/world_activity.gd"))
	activity.set("activity_kind", kind)
	activity.set("interact_range", 4.0)
	_build_activity_visual(activity, kind, label, tint, rng)
	add_child(activity)

func _place_shoreline(rng: RandomNumberGenerator, count: int) -> void:
	var placed: int = 0
	for attempt in range(120):
		if placed >= count:
			break
		var angle := rng.randf() * TAU
		var radius := rng.randf_range(55.0, 150.0)
		var point := TerrainNoise.VILLAGE_CENTER + Vector2(cos(angle), sin(angle)) * radius
		var height := _ground(point.x, point.y)
		if height < 0.2 or height > 2.2:
			continue
		var wet_neighbors: int = 0
		for offset in [Vector2(5, 0), Vector2(-5, 0), Vector2(0, 5), Vector2(0, -5)]:
			if _ground(point.x + offset.x, point.y + offset.y) < -0.15:
				wet_neighbors += 1
		if wet_neighbors == 0:
			continue
		_place("shoreline", point, "Tidepool Harvest %d" % (placed + 1), Color(0.22, 0.72, 0.78), rng)
		placed += 1

func _build_activity_visual(activity: Area3D, kind: String, label: String, tint: Color, rng: RandomNumberGenerator) -> void:
	var stone := _material(Color(0.25, 0.24, 0.23))
	var accent := _material(tint, true)
	match kind:
		"campfire":
			for i in range(3):
				var log := _mesh_box(Vector3(0.72, 0.16, 0.18), stone)
				log.position = Vector3(0, 0.16 + float(i % 2) * 0.08, 0)
				log.rotation.y = float(i) * PI / 3.0
				activity.add_child(log)
			var flame := MeshInstance3D.new(); flame.name = "Flame"
			var flame_mesh := SphereMesh.new(); flame_mesh.radius = 0.25; flame_mesh.height = 0.62
			flame.mesh = flame_mesh; flame.material_override = accent; flame.position.y = 0.56; flame.scale = Vector3(0.72, 1.3, 0.72); activity.add_child(flame)
			var fire_light := OmniLight3D.new(); fire_light.name = "ActivityLight"; fire_light.light_color = tint; fire_light.light_energy = 0.8; fire_light.omni_range = 8.0; fire_light.position.y = 0.75; activity.add_child(fire_light)
		"tracking":
			for i in range(4):
				var track_mark := MeshInstance3D.new(); var print_mesh := SphereMesh.new(); print_mesh.radius = 0.18; print_mesh.height = 0.08
				track_mark.mesh = print_mesh; track_mark.material_override = _material(tint.darkened(0.25)); track_mark.position = Vector3(randf_range(-0.55, 0.55), 0.04, float(i) * 0.42 - 0.6); track_mark.scale = Vector3(0.7, 0.7, 1.4); activity.add_child(track_mark)
		"shoreline":
			for i in range(5):
				var coral := MeshInstance3D.new(); var coral_mesh := CylinderMesh.new(); coral_mesh.top_radius = 0.04; coral_mesh.bottom_radius = 0.13; coral_mesh.height = rng.randf_range(0.35, 0.8); coral.mesh = coral_mesh; coral.material_override = accent; coral.position = Vector3(rng.randf_range(-0.55, 0.55), coral_mesh.height * 0.5, rng.randf_range(-0.45, 0.45)); coral.rotation.z = rng.randf_range(-0.3, 0.3); activity.add_child(coral)
			var pearl := MeshInstance3D.new(); var pearl_mesh := SphereMesh.new(); pearl_mesh.radius = 0.13; pearl_mesh.height = 0.26; pearl.mesh = pearl_mesh; pearl.material_override = _material(Color(0.8, 0.88, 0.95), true); pearl.position = Vector3(0.0, 0.18, 0.0); activity.add_child(pearl)
		"archaeology":
			var slab := _mesh_box(Vector3(1.45, 1.75, 0.3), stone); slab.position.y = 0.9; activity.add_child(slab)
			var glyph := Label3D.new(); glyph.text = "✦ ᚱ ᚨ ✦"; glyph.font_size = 22; glyph.position = Vector3(0, 1.0, -0.18); glyph.modulate = tint; activity.add_child(glyph)
			for rune_i in range(4):
				var rune := MeshInstance3D.new(); rune.name = "ActivityRune_%d" % (rune_i + 1)
				var rune_mesh := SphereMesh.new(); rune_mesh.radius = 0.095; rune_mesh.height = 0.19; rune.mesh = rune_mesh
				var rune_mat := _material(tint.lightened(0.18), true); rune.material_override = rune_mat
				rune.position = Vector3(-0.48 + float(rune_i) * 0.32, 0.27, -0.19); activity.add_child(rune)
			var light := OmniLight3D.new(); light.name = "ActivityLight"; light.light_color = tint; light.light_energy = 0.55; light.omni_range = 4.0; light.position.y = 1.5; activity.add_child(light)
		"leyline":
			var pillar := MeshInstance3D.new(); var crystal := PrismMesh.new(); crystal.size = Vector3(0.48, 1.8, 0.48); pillar.mesh = crystal; pillar.material_override = accent; pillar.position.y = 1.0; activity.add_child(pillar)
			var ring := MeshInstance3D.new(); var torus := TorusMesh.new(); torus.inner_radius = 0.8; torus.outer_radius = 0.9; ring.mesh = torus; ring.material_override = accent; ring.position.y = 0.2; ring.rotation.x = PI * 0.5; activity.add_child(ring)
			var mover := Node3D.new(); mover.name = "LeylineMotion"; mover.set_script(load("res://entities/animated_dungeon_prop.gd")); mover.set("spin_speed", 0.35); activity.add_child(mover)
			var light := OmniLight3D.new(); light.name = "ActivityLight"; light.light_color = tint; light.light_energy = 0.65; light.omni_range = 6.0; light.position.y = 1.3; activity.add_child(light)
	var label_node := Label3D.new(); label_node.text = label; label_node.font_size = 17; label_node.position.y = 2.0; label_node.modulate = tint.lightened(0.18); label_node.billboard = BaseMaterial3D.BILLBOARD_ENABLED; activity.add_child(label_node)
	var detection := CollisionShape3D.new(); var sphere := SphereShape3D.new(); sphere.radius = 1.8; detection.shape = sphere; activity.add_child(detection)

func _mesh_box(size: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new(); var mesh := BoxMesh.new(); mesh.size = size; instance.mesh = mesh; instance.material_override = material; return instance

func _material(color: Color, emission: bool = false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new(); material.albedo_color = color; material.roughness = 0.82
	if emission:
		material.emission_enabled = true; material.emission = color; material.emission_energy_multiplier = 0.8
	return material
