# Rare, earned cultivation discovery. Ordinary RPG progression is always available;
# cultivation remains locked until a character earns recognition and a legitimate method.
extends Node

signal discovery_progress_changed(report: Dictionary)
signal recognition_trial_resolved(passed: bool, report: Dictionary)
signal cultivation_method_acquired(method_id: String, source: String)

const REQUIRED_CLUES: int = 3
const REQUIRED_COMPREHENSION: float = 4.0
const REQUIRED_WILL: float = 4.0

func _ready() -> void:
	if not PlayerData.stats.has("cultivation_discovery"):
		PlayerData.stats["cultivation_discovery"] = _default_state()

func _default_state() -> Dictionary:
	return {
		"clues": {},
		"recognition_unlocked": false,
		"trial_attempts": 0,
		"trial_failures": 0,
		"trial_passed": false,
		"method_id": "",
		"method_source": "",
		"cultivation_started": false,
		"started_at": 0
	}

func _state() -> Dictionary:
	var raw: Variant = PlayerData.stats.get("cultivation_discovery", {})
	if raw is Dictionary:
		var result: Dictionary = _default_state()
		for key in raw.keys():
			result[key] = raw[key]
		return result
	return _default_state()

func _save_state(state: Dictionary) -> void:
	PlayerData.stats["cultivation_discovery"] = state.duplicate(true)
	discovery_progress_changed.emit(get_report())

func is_cultivation_unlocked() -> bool:
	var state: Dictionary = _state()
	return bool(state.get("cultivation_started", false)) and not str(state.get("method_id", "")).is_empty()

func record_clue(clue_id: String, source: String, evidence: String = "") -> bool:
	if clue_id.strip_edges().is_empty():
		return false
	var state: Dictionary = _state()
	var clues: Dictionary = state.get("clues", {}).duplicate(true)
	if clues.has(clue_id):
		return false
	clues[clue_id] = {"source": source, "evidence": evidence, "found_at": Time.get_unix_time_from_system()}
	state["clues"] = clues
	state["recognition_unlocked"] = clues.size() >= REQUIRED_CLUES
	_save_state(state)
	EventBus.activity.emit("Unusual discovery recorded: %s" % source, "discovery")
	if bool(state["recognition_unlocked"]):
		EventBus.toast.emit("Several discoveries seem connected. Someone knowledgeable may recognise their significance.", "discovery")
	return true

func comprehension_score(skills: SkillSystem) -> float:
	if skills == null:
		return 0.0
	return skills.get_value("knowledge") * 0.35 + skills.get_value("wisdom") * 0.25 + skills.get_value("ancient_lore") * 0.25 + skills.get_value("observation") * 0.15

func willpower_score(skills: SkillSystem) -> float:
	if skills == null:
		return 0.0
	# Will is demonstrated through endurance and deliberate practice, not a character-creation stat.
	return skills.get_value("vitality") * 0.35 + skills.get_value("unarmed") * 0.15 + skills.get_value("shield") * 0.15 + skills.get_value("wisdom") * 0.20 + skills.get_value("stealth") * 0.15

func begin_recognition_trial() -> Dictionary:
	var state: Dictionary = _state()
	if is_cultivation_unlocked():
		return {"available": false, "reason": "You already possess a cultivation method."}
	if not bool(state.get("recognition_unlocked", false)):
		return {"available": false, "reason": "You have not gathered enough evidence for recognition."}
	var player: Node = GameManager.player
	var skills: SkillSystem = null
	if player != null:
		skills = player.get_node_or_null("SkillSystem") as SkillSystem
	var comprehension: float = comprehension_score(skills)
	var will: float = willpower_score(skills)
	if comprehension < REQUIRED_COMPREHENSION:
		return {"available": false, "reason": "Your understanding is not yet deep enough. Study the clues, histories and inscriptions."}
	if will < REQUIRED_WILL:
		return {"available": false, "reason": "You lack the demonstrated discipline and endurance for this trial."}
	return {"available": true, "comprehension": comprehension, "willpower": will, "clues": _state().get("clues", {}).size()}

func resolve_recognition_trial(method_id: String, source: String, compatibility_evidence: String) -> bool:
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and not multiplayer.is_server():
		EventBus.toast.emit("This recognition trial must be validated by the authoritative world server.", "warning")
		return false
	if method_id.strip_edges().is_empty() or source.strip_edges().is_empty() or compatibility_evidence.strip_edges().is_empty():
		return false
	var eligibility: Dictionary = begin_recognition_trial()
	if not bool(eligibility.get("available", false)):
		EventBus.toast.emit(str(eligibility.get("reason", "The trial cannot begin.")), "warning")
		return false
	var state: Dictionary = _state()
	state["trial_attempts"] = int(state.get("trial_attempts", 0)) + 1
	# The trial is a demonstrated test, not a random roll. A valid method and
	# evidence of compatibility are required in addition to comprehension and will.
	var player: Node = GameManager.player
	var skills: SkillSystem = null
	if player != null:
		skills = player.get_node_or_null("SkillSystem") as SkillSystem
	var elemental_compatibility: float = 0.0
	if skills != null:
		for affinity_id in ["fire_affinity", "water_affinity", "wind_affinity", "earth_affinity", "lightning_affinity", "ice_affinity"]:
			elemental_compatibility = maxf(elemental_compatibility, skills.get_value(affinity_id))
	var passed: bool = skills != null and elemental_compatibility >= 1.0 and skills.get_value("spiritual_sense") >= 1.0 and compatibility_evidence.strip_edges().length() >= 12
	if passed:
		state["trial_passed"] = true
		state["method_id"] = method_id
		state["method_source"] = source
		state["compatibility_evidence"] = compatibility_evidence
		state["cultivation_started"] = true
		state["started_at"] = Time.get_unix_time_from_system()
		cultivation_method_acquired.emit(method_id, source)
		EventBus.toast.emit("A genuine cultivation method has been entrusted to you. Your journey begins now.", "levelup")
		EventBus.activity.emit("Acquired cultivation method: %s" % method_id, "cultivation")
	else:
		state["trial_failures"] = int(state.get("trial_failures", 0)) + 1
		EventBus.toast.emit("The inheritance did not recognise your compatibility. Further preparation may be needed.", "warning")
	_save_state(state)
	recognition_trial_resolved.emit(passed, get_report())
	return passed

func get_report() -> Dictionary:
	var state: Dictionary = _state()
	var clues: Dictionary = state.get("clues", {})
	var player: Node = GameManager.player
	var skills: SkillSystem = null
	if player != null:
		skills = player.get_node_or_null("SkillSystem") as SkillSystem
	return {
		"cultivation_unlocked": is_cultivation_unlocked(),
		"clues_found": clues.size(),
		"clues_required": REQUIRED_CLUES,
		"recognition_unlocked": bool(state.get("recognition_unlocked", false)),
		"trial_attempts": int(state.get("trial_attempts", 0)),
		"trial_failures": int(state.get("trial_failures", 0)),
		"method_id": str(state.get("method_id", "")),
		"method_source": str(state.get("method_source", "")),
		"comprehension": comprehension_score(skills),
		"willpower": willpower_score(skills)
	}
