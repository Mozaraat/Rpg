# Ten dungeon cultures: faction diplomacy, phrasebook, trade specialties and living conflicts.
extends Node

const CULTURES: Array[Dictionary] = [
	{"id":"labyrinth","name":"The First Cartographers","language":"Aruun","greeting":"Vael en tora","meaning":"May your path be clear","trade":"maps, bronze tools","conflict":"The Gatekeepers dispute the old route taxes"},
	{"id":"caverns","name":"The Stonekin Holds","language":"Kharum","greeting":"Dum kar vek","meaning":"Stone remembers","trade":"ore, gems, masonry","conflict":"Deep miners and surface clans contest a crystal seam"},
	{"id":"crystal","name":"The Prism Concord","language":"Ilyth","greeting":"Sera lumin","meaning":"Light reveals truth","trade":"crystal lenses, arcane catalysts","conflict":"Two houses accuse each other of stealing a resonance key"},
	{"id":"kingdom","name":"The Veiled Crown","language":"Old Elyric","greeting":"Aren valora","meaning":"Honour before glory","trade":"silks, heirlooms, royal arms","conflict":"A succession dispute divides the noble houses"},
	{"id":"ember","name":"The Cinderforged","language":"Dravik","greeting":"Ash var kor","meaning":"Fire tempers all","trade":"alloys, weapons, heatstones","conflict":"Forge guilds fight over control of the heart furnace"},
	{"id":"frozen","name":"The Pale Tribunal","language":"Nivren","greeting":"Eira solen","meaning":"Stillness guards us","trade":"furs, ice pearls, preservation salts","conflict":"Hunters and wardens disagree over sacred migration grounds"},
	{"id":"drowned","name":"The Thalassian Houses","language":"Thal","greeting":"Oru nai sela","meaning":"The tide carries memory","trade":"pearls, coral, navigational charts","conflict":"Reef divers and current-priests clash over a sealed vault"},
	{"id":"worldroot","name":"The Rootbound Circle","language":"Vaessa","greeting":"Nara vel en","meaning":"All life is joined","trade":"living timber, medicines, seeds","conflict":"The graft-keepers debate whether to awaken an ancient grove"},
	{"id":"abyss","name":"The Umbral Compact","language":"Vey","greeting":"Sha morai","meaning":"Trust the unseen","trade":"voidsilk, shadow glass, rare inks","conflict":"Two shadow houses compete for a dwindling safe passage"},
	{"id":"ancient","name":"The Astral Remnant","language":"Aetheric","greeting":"Oris caelum","meaning":"The stars bear witness","trade":"star-metal, relics, memory shards","conflict":"Archivists disagree over whether the final seal should remain closed"}
]

func culture_for_floor(floor: int) -> Dictionary:
	return CULTURES[clampi(floori(float(floor) / 10.0), 0, CULTURES.size() - 1)].duplicate(true)

func phrasebook(floor: int) -> Dictionary:
	var c := culture_for_floor(floor)
	return {"language":c.language, "phrase":c.greeting, "translation":c.meaning}

func reputation(culture_id: String) -> int:
	return int(PlayerData.stats.get("culture_rep_" + culture_id, 0))

func change_reputation(culture_id: String, amount: int) -> int:
	var key := "culture_rep_" + culture_id
	PlayerData.stats[key] = clampi(reputation(culture_id) + amount, -100, 100)
	return int(PlayerData.stats[key])

func trade_quote(floor: int, item_value: int, buying: bool = true) -> int:
	var c := culture_for_floor(floor)
	var rep := reputation(str(c.id))
	var factor := 1.0 - clampf(float(rep) / 500.0, -0.2, 0.2)
	return maxi(1, roundi(float(item_value) * factor * (1.0 if buying else 0.65)))

func resolve_conflict(floor: int, peaceful: bool = true) -> void:
	var c := culture_for_floor(floor)
	var id := str(c.id)
	change_reputation(id, 8 if peaceful else -5)
	var key := "culture_conflict_resolved_" + id
	PlayerData.stats[key] = true
	EventBus.activity.emit("%s: %s" % [str(c.name), "A local dispute was settled" if peaceful else "The dispute escalated"], "world")

func get_cultural_quest(floor: int) -> Dictionary:
	var c := culture_for_floor(floor)
	var id := str(c.id)
	if bool(PlayerData.stats.get("culture_conflict_resolved_" + id, false)):
		return {"title":"A New Accord", "description":"Return to %s and learn how the settlement has changed" % c.name, "reward_rep":4}
	return {"title":"Voices of %s" % c.name, "description":"Investigate this conflict: %s. Learn both sides before choosing a resolution" % c.conflict, "reward_rep":8}


# NPC households, regional faction influence and settlement commerce.
const FAMILY_NAMES := ["Ashford", "Brookmere", "Thornfield", "Stonewell", "Dawncrest", "Riversong", "Mossvale", "Ironroot"]
const GIVEN_NAMES := ["Aren", "Mira", "Tovin", "Sella", "Bran", "Neris", "Kael", "Ivara", "Dain", "Lysa"]
const BUSINESSES := {"farmer":["grain fields", "orchards", "livestock pens"], "smith":["forge", "armoury", "repair shop"], "merchant":["general store", "caravan exchange", "market stall"], "villager":["bakery", "tavern", "weaver's shop"]}

func family_profile(npc_name: String, role: String) -> Dictionary:
	var seed_value := absi(npc_name.hash())
	var family: String = str(FAMILY_NAMES[seed_value % FAMILY_NAMES.size()])
	var relative: String = str(GIVEN_NAMES[(seed_value / 7) % GIVEN_NAMES.size()])
	var trade_list: Array = BUSINESSES.get(role, BUSINESSES.villager)
	return {"family":family, "relative":relative, "occupation":str(trade_list[seed_value % trade_list.size()]), "ambition":["open a larger shop", "restore an old family home", "send a child to study", "protect the local woodland"][seed_value % 4]}

func household_story(npc_name: String, role: String) -> Array[String]:
	var f := family_profile(npc_name, role)
	return ["My family is the %s household. %s is my closest kin." % [f.family, f.relative], "I work as part of the %s. One day I hope to %s." % [f.occupation, f.ambition]]

func local_trade_specialty(floor: int) -> String:
	var culture := culture_for_floor(floor)
	return str(culture.trade)

func apply_faction_choice(culture_id: String, support_local: bool) -> void:
	var key := "faction_influence_" + culture_id
	var value := int(PlayerData.stats.get(key, 0)) + (5 if support_local else -3)
	PlayerData.stats[key] = clampi(value, -100, 100)
	change_reputation(culture_id, 4 if support_local else -2)
	PlayerData.stats["faction_conflict_pressure_" + culture_id] = maxi(0, int(PlayerData.stats.get("faction_conflict_pressure_" + culture_id, 20)) - (8 if support_local else -4))
	EventBus.activity.emit("Your decision shifted %s faction influence" % culture_id.capitalize(), "world")

func settlement_businesses(level: int, role: String) -> Array[String]:
	var options: Array = BUSINESSES.get(role, BUSINESSES.villager)
	var count := clampi(level, 1, options.size())
	var result: Array[String] = []
	for i in range(count): result.append(str(options[i]))
	return result
