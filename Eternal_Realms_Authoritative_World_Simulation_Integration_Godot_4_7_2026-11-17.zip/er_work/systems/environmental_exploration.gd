# Traversable landmark spaces, waterfalls, climbable world-trees and breakable scenery.
extends Node3D

var _noise: TerrainNoise
var _caves: Array[Dictionary] = []
var _tree_routes: Array[Dictionary] = []
var _breakables: Array[Dictionary] = []
var _water_material: ShaderMaterial
var _player_tree_step := -1
var _climbing_tree_index := -1
var _climb_angle := 0.0
var _climb_height := 0.0
var _inside_cave := -1
var _saved_position := Vector3.ZERO
var _event_clock := 0.0
var _water_center := Vector3.ZERO
var _water_surface_y := 0.0
var _track_tick := 0.0
var _last_critter_positions: Dictionary = {}
var _track_count := 0
var _cave_hint_cooldown := 0.0
var _world_environment: Environment = null

func _ready() -> void:
	add_to_group("environment_world")
	_noise = TerrainNoise.new(GameManager.world_seed)
	_build_caves()
	_build_giant_tree_routes()
	_build_waterfall_river()
	_build_breakables()

func _process(delta: float) -> void:
	_event_clock += delta
	_track_tick += delta
	_cave_hint_cooldown = maxf(_cave_hint_cooldown - delta, 0.0)
	if _track_tick >= 4.0:
		_track_tick = 0.0
		_update_wildlife_tracks()
	if _event_clock > 0.18:
		_event_clock = 0.0
		_update_nearby_environment()


func get_save_state() -> Dictionary:
	return {"inside_cave":_inside_cave,"saved_position":[_saved_position.x,_saved_position.y,_saved_position.z],"tree_step":_player_tree_step,"climbing_tree":_climbing_tree_index,"climb_angle":_climb_angle,"climb_height":_climb_height}

func restore_from_save(data: Dictionary) -> void:
	_inside_cave = clampi(int(data.get("inside_cave", -1)), -1, _caves.size() - 1)
	var pos: Array = data.get("saved_position", [0.0,0.0,0.0])
	if pos.size() >= 3: _saved_position = Vector3(float(pos[0]),float(pos[1]),float(pos[2]))
	_player_tree_step = int(data.get("tree_step", -1))
	_climbing_tree_index = int(data.get("climbing_tree", -1))
	_climb_angle = float(data.get("climb_angle", 0.0))
	_climb_height = float(data.get("climb_height", 0.0))
	if _climbing_tree_index < 0 or _climbing_tree_index >= _tree_routes.size():
		_climbing_tree_index = -1
	if GameManager.player and _climbing_tree_index >= 0:
		GameManager.player.set_meta("tree_climbing", true)
	if GameManager.player:
		GameManager.player.set_meta("inside_cave",_inside_cave >= 0)
	if _inside_cave >= 0:
		_apply_cave_environment(true)

func is_in_water(position: Vector3) -> bool:
	if _water_center == Vector3.ZERO: return false
	var point := Vector2(position.x, position.z)
	var pool_distance := point.distance_to(Vector2(_water_center.x, _water_center.z + 7.0))
	var river_distance := _distance_to_segment_2d(point, Vector2(_water_center.x, _water_center.z + 7.0), Vector2(_water_center.x, _water_center.z + 93.0))
	return (pool_distance < 9.0 or river_distance < 5.2) and position.y > _water_surface_y - 2.5 and position.y < _water_surface_y + 1.2

func _distance_to_segment_2d(point: Vector2, start: Vector2, finish: Vector2) -> float:
	var segment := finish - start
	var length_sq := segment.length_squared()
	if length_sq < 0.0001:
		return point.distance_to(start)
	var t := clampf((point - start).dot(segment) / length_sq, 0.0, 1.0)
	return point.distance_to(start + segment * t)

func is_player_climbing(player: CharacterBody3D) -> bool:
	return player != null and bool(player.get_meta("tree_climbing", false)) and _climbing_tree_index >= 0

func update_climbing(player: CharacterBody3D, input_dir: Vector2, delta: float) -> void:
	if not is_player_climbing(player):
		return
	var route: Dictionary = _tree_routes[_climbing_tree_index]
	var base: Vector3 = route.base
	var height: float = float(route.height)
	var scale := float(route.get("scale", 1.0))
	var top := float(route.get("climb_top", height - 1.2))
	var radius := float(route.radius) + 0.85
	if bool(route.get("hug_trunk", false)):
		var local_y := _climb_height / scale
		radius = lerpf(1.28, 0.82, clampf((local_y + 0.05) / 4.6, 0.0, 1.0)) * scale + 0.55
	_climb_height = clampf(_climb_height + (-input_dir.y) * 3.8 * delta, 0.9, top)
	_climb_angle = wrapf(_climb_angle + input_dir.x * 1.35 * delta, -PI, PI)
	var radial := Vector3(cos(_climb_angle), 0.0, sin(_climb_angle))
	player.global_position = base + radial * radius + Vector3.UP * _climb_height
	player.velocity = Vector3.ZERO
	player.rotation.y = atan2(-radial.x, -radial.z)
	var climbing_skills := player.get_node_or_null("SkillSystem") as SkillSystem
	if input_dir.length() > 0.1 and climbing_skills:
		climbing_skills.train("agility", 0.025, true)
	if _climb_height >= top - 0.05:
		_end_climb(player, true)

func end_climbing(player: CharacterBody3D, keep_current_height: bool = false) -> void:
	_end_climb(player, false, keep_current_height)

func _end_climb(player: CharacterBody3D, reached_canopy: bool, keep_current_height: bool = false) -> void:
	if player == null:
		return
	var route: Dictionary = _tree_routes[_climbing_tree_index] if _climbing_tree_index >= 0 and _climbing_tree_index < _tree_routes.size() else {}
	player.set_meta("tree_climbing", false)
	player.velocity = Vector3.ZERO
	if not route.is_empty():
		if reached_canopy:
			var radial := Vector3(cos(_climb_angle), 0.0, sin(_climb_angle))
			if route.has("cap_y"):
				player.global_position = route.base + radial * 1.0 + Vector3.UP * (float(route.cap_y) + 0.45)
			else:
				player.global_position = route.base + radial * (float(route.radius) + 1.25) + Vector3.UP * (float(route.height) + 0.8)
		elif keep_current_height:
			var radial := Vector3(cos(_climb_angle), 0.0, sin(_climb_angle))
			player.global_position = route.base + radial * (float(route.radius) + 1.0) + Vector3.UP * _climb_height
		else:
			player.global_position = route.base + Vector3(0.0, 0.25, 2.8)
	_climbing_tree_index = -1
	_climb_height = 0.0
	EventBus.toast.emit("You reach the canopy" if reached_canopy else "You climb down safely", "discovery")

func try_interact(player: CharacterBody3D) -> bool:
	if player == null:
		return false
	if is_player_climbing(player):
		_end_climb(player, false)
		return true
	if _inside_cave >= 0:
		var cave: Dictionary = _caves[_inside_cave]
		if player.global_position.distance_to(cave.interior_exit) < 4.5:
			player.global_position = _saved_position
			player.velocity = Vector3.ZERO
			player.set_meta("inside_cave", false)
			_inside_cave = -1
			_apply_cave_environment(false)
			EventBus.toast.emit("You emerge into the open air", "info")
			return true
		return false
	for i in range(_caves.size()):
		var cave: Dictionary = _caves[i]
		if player.global_position.distance_to(cave.entrance) < 4.0:
			_saved_position = player.global_position
			_inside_cave = i
			player.global_position = cave.interior_start
			player.velocity = Vector3.ZERO
			player.set_meta("inside_cave", true)
			_apply_cave_environment(true)
			EventBus.toast.emit("Entered %s — explore the chambers" % cave.name, "discovery")
			return true
	for i in range(_tree_routes.size()):
		var route: Dictionary = _tree_routes[i]
		var horizontal := Vector2(player.global_position.x - route.base.x, player.global_position.z - route.base.z).length()
		if horizontal < float(route.radius) + 2.0 and absf(player.global_position.y - route.base.y) < 3.0:
			_climbing_tree_index = i
			_climb_angle = atan2(player.global_position.z - route.base.z, player.global_position.x - route.base.x)
			_climb_height = 1.0
			player.set_meta("tree_climbing", true)
			player.global_position = route.base + Vector3(cos(_climb_angle), 0.0, sin(_climb_angle)) * (float(route.radius) + 0.85) + Vector3.UP
			player.velocity = Vector3.ZERO
			EventBus.toast.emit("Climbing %s — WASD to move around the trunk, Space to jump off" % route.name, "discovery")
			return true
	for i in range(_breakables.size()):
		var prop: Dictionary = _breakables[i]
		if not is_instance_valid(prop.node) or bool(prop.broken):
			continue
		if player.global_position.distance_to(prop.node.global_position) < 3.6:
			var hp: int = int(prop.hp) - 1
			prop.hp = hp
			_breakables[i] = prop
			VFX.burst(self, prop.node.global_position + Vector3.UP * 0.6, prop.color, 8, 2.5, 0.04)
			if hp <= 0:
				prop.broken = true
				_breakables[i] = prop
				prop.node.visible = false
				prop.node.set_meta("destroyed", true)
				for debris_i in range(5):
					var debris := _make_sphere(randf_range(0.18,0.42), prop.color.darkened(0.2), false)
					debris.position = prop.node.global_position + Vector3(randf_range(-1.0,1.0),randf_range(0.1,0.7),randf_range(-1.0,1.0))
					add_child(debris)
				PlayerData.add_item(str(prop.drop), int(prop.quantity))
				EventBus.toast.emit("%s destroyed — materials recovered" % prop.name, "loot")
			else:
				EventBus.toast.emit("%s damaged (%d strength remaining)" % [prop.name, hp], "info")
			return true
	return false

func _find_world_environment() -> WorldEnvironment:
	var main_scene: Node = get_tree().current_scene
	if main_scene:
		var we: WorldEnvironment = main_scene.get_node_or_null("WorldEnvironment") as WorldEnvironment
		if we:
			return we
	if get_parent():
		var parent_we: WorldEnvironment = get_parent().get_node_or_null("WorldEnvironment") as WorldEnvironment
		if parent_we:
			return parent_we
	for candidate in get_tree().root.find_children("*", "WorldEnvironment", true, false):
		if candidate is WorldEnvironment:
			return candidate
	return null

func _apply_cave_environment(inside: bool) -> void:
	# Underground, the sky must not light the chambers: the cave gets its own
	# dark environment and the overworld one is restored on the way out.
	var world_env: WorldEnvironment = _find_world_environment()
	if world_env == null:
		return
	if inside:
		if _world_environment == null:
			_world_environment = world_env.environment
		var cave_env := Environment.new()
		cave_env.background_mode = Environment.BG_COLOR
		cave_env.background_color = Color(0.008, 0.010, 0.015)
		cave_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		cave_env.ambient_light_color = Color(0.26, 0.28, 0.34)
		cave_env.ambient_light_energy = 0.55
		cave_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
		cave_env.glow_enabled = true
		cave_env.glow_intensity = 0.6
		cave_env.glow_bloom = 0.04
		cave_env.fog_enabled = true
		cave_env.fog_light_color = Color(0.15, 0.16, 0.19)
		cave_env.fog_density = 0.028
		cave_env.fog_depth_begin = 6.0
		cave_env.fog_depth_end = 62.0
		cave_env.fog_sky_affect = 0.0
		world_env.environment = cave_env
	elif _world_environment != null:
		world_env.environment = _world_environment

func _build_caves() -> void:
	# Side dungeons: short, self-contained exploration complexes scattered across
	# the overworld. Each is a gated adit at the surface leading down to a hall, a
	# resource chamber and a vault, stocked with harvestable veins and guarded.
	var specs := [
		{
			"name": "Mosslight Grotto", "pos": Vector2(-92, -82), "yaw": 0.0,
			"tint": Color(0.18, 0.58, 0.42), "cache": "moonpetal",
			"chambers": ["SPORE THRESHOLD", "FUNGAL GALLERY", "SEALED FUNGARIUM"],
			"resources": [
				{"name": "Glowcap Cluster", "drop": "glowcap", "qty": 3, "color": Color(0.36, 0.86, 0.46), "hp": 3},
				{"name": "Peat Seep", "drop": "peat", "qty": 2, "color": Color(0.34, 0.27, 0.18), "hp": 3},
			],
			"monsters": ["cave_slime", "cave_slime", "dungeon_rat"],
		},
		{
			"name": "Singing Crystal Cavern", "pos": Vector2(-52, -120), "yaw": PI * 0.5,
			"tint": Color(0.25, 0.55, 0.92), "cache": "forgotten_essence",
			"chambers": ["RESONANT THRESHOLD", "CHORUS GALLERY", "PRISM VAULT"],
			"resources": [
				{"name": "Mana Crystal Cluster", "drop": "mana_crystal", "qty": 2, "color": Color(0.34, 0.66, 1.0), "hp": 4},
				{"name": "Resin Seep", "drop": "amber_resin", "qty": 2, "color": Color(0.85, 0.62, 0.26), "hp": 3},
			],
			"monsters": ["prism_stalker", "night_wisp"],
		},
		{
			"name": "Ashen Hollow", "pos": Vector2(18, -104), "yaw": 0.0,
			"tint": Color(0.82, 0.36, 0.16), "cache": "obsidian_shard",
			"chambers": ["SCORCHED THRESHOLD", "EMBER GALLERY", "FORGE VAULT"],
			"resources": [
				{"name": "Sulfur Vein", "drop": "sulfur", "qty": 3, "color": Color(0.92, 0.84, 0.30), "hp": 3},
				{"name": "Obsidian Seam", "drop": "obsidian_shard", "qty": 1, "color": Color(0.20, 0.19, 0.24), "hp": 5},
			],
			"monsters": ["cinder_hound", "cinder_hound"],
		},
		{
			"name": "Sunscorch Cistern", "pos": Vector2(150, 90), "yaw": 0.0,
			"tint": Color(0.90, 0.70, 0.28), "cache": "amber_resin",
			"chambers": ["DUST THRESHOLD", "DRY GALLERY", "SUNKEN VAULT"],
			"resources": [
				{"name": "Amber Seep", "drop": "amber_resin", "qty": 2, "color": Color(0.88, 0.60, 0.22), "hp": 4},
				{"name": "Salt Crust", "drop": "sulfur", "qty": 3, "color": Color(0.88, 0.86, 0.72), "hp": 3},
			],
			"monsters": ["crystal_mimic", "spore_moth"],
		},
		{
			"name": "Ironback Delve", "pos": Vector2(200, -60), "yaw": 0.0,
			"tint": Color(0.72, 0.74, 0.80), "cache": "gold_ore",
			"chambers": ["QUARRY THRESHOLD", "ORE GALLERY", "DEEP VAULT"],
			"resources": [
				{"name": "Iron Seam", "drop": "iron_ore", "qty": 3, "color": Color(0.50, 0.52, 0.56), "hp": 4},
				{"name": "Copper Seam", "drop": "copper_ore", "qty": 2, "color": Color(0.78, 0.46, 0.28), "hp": 4},
				{"name": "Gold Seam", "drop": "gold_ore", "qty": 1, "color": Color(0.94, 0.76, 0.30), "hp": 6},
			],
			"monsters": ["grave_hound", "bone_skitter", "grave_hound"],
		},
		{
			"name": "Frostveil Hoard", "pos": Vector2(-200, -140), "yaw": 0.0,
			"tint": Color(0.62, 0.78, 0.98), "cache": "rune_fragment",
			"chambers": ["RIME THRESHOLD", "FROST GALLERY", "GLACIER VAULT"],
			"resources": [
				{"name": "Rime Crystal", "drop": "mana_crystal", "qty": 2, "color": Color(0.62, 0.86, 1.0), "hp": 5},
				{"name": "Obsidian Frost", "drop": "obsidian_shard", "qty": 1, "color": Color(0.18, 0.20, 0.28), "hp": 5},
				{"name": "Silver Seam", "drop": "silver_ore", "qty": 2, "color": Color(0.84, 0.86, 0.90), "hp": 4},
			],
			"monsters": ["frost_lynx", "shadow_bat"],
		},
		{
			"name": "Mirefen Sunken Vault", "pos": Vector2(-120, 140), "yaw": -PI * 0.5,
			"tint": Color(0.42, 0.70, 0.58), "cache": "ectoplasm",
			"chambers": ["MARSH THRESHOLD", "SUNKEN GALLERY", "DEEP VAULT"],
			"resources": [
				{"name": "Pearl Cluster", "drop": "pearl", "qty": 2, "color": Color(0.92, 0.92, 0.96), "hp": 4},
				{"name": "Marsh Orchid", "drop": "rare_orchid", "qty": 1, "color": Color(0.78, 0.44, 0.86), "hp": 3},
			],
			"monsters": ["void_jelly", "tide_serpent"],
		},
	]
	for i in range(specs.size()):
		var spec: Dictionary = specs[i]
		var p: Vector2 = spec.pos
		var surface: float = _noise.get_height(p.x, p.y)
		var entrance := Vector3(p.x, surface, p.y)
		var root := Node3D.new()
		root.name = str(spec.name).replace(" ", "")
		root.position = entrance
		# The adit faces the heart of the map so it is approached from the lowlands.
		var approach: Vector2 = (-p).normalized()
		root.rotation.y = atan2(-approach.x, -approach.y)
		add_child(root)
		_build_side_dungeon_adit(root, spec, i)
		var marker := _make_sphere(0.25, Color(0.35, 0.75, 1.0), true)
		marker.position.y = 1.2
		marker.visible = false
		root.add_child(marker)
		var entrance_label := Label3D.new()
		entrance_label.text = str(spec.name) + " — E TO ENTER"
		entrance_label.position = Vector3(0, 8.4, 0)
		entrance_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		entrance_label.font_size = 28
		entrance_label.outline_size = 6
		entrance_label.visible = false
		root.add_child(entrance_label)
		# The complex sits deep enough that its roof always stays under the rock.
		var origin := Vector3(p.x, surface - 46.0, p.y)
		var complex: Dictionary = SideDungeon.build_complex(self, origin, spec.tint,
			int(GameManager.world_seed) + 7919 * (i + 1), spec.chambers, spec.resources,
			str(spec.cache), float(spec.yaw), spec.monsters)
		for prop in complex.breakables:
			_breakables.append(prop)
		_caves.append({
			"name": spec.name,
			"entrance": entrance,
			"interior_start": complex.start,
			"interior_exit": complex.exit,
			"room": complex.hall,
			"deep_room": complex.vault,
			"marker": marker,
			"label": entrance_label,
		})


func _build_side_dungeon_adit(parent: Node3D, spec: Dictionary, index: int) -> void:
	# A built stone gate cut into a rocky mound: piers, lintel, rune keystone,
	# flanking torches, worn steps and the rubble of a collapsed mine mouth.
	var tint: Color = spec.tint
	var stone := Color(0.21, 0.21, 0.23)
	var trim := Color(0.31, 0.26, 0.20)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + 4421 * (index + 1)

	# The mound the gate is cut into hides the seam with the terrain.
	for i in range(8):
		var angle: float = TAU * float(i) / 8.0
		var mound := _make_sphere(2.3 + float(i % 3) * 0.6, stone.lightened(float(i % 2) * 0.05), false)
		mound.position = Vector3(cos(angle) * 5.4, -0.9 + float(i % 2) * 0.5, 0.9 + sin(angle) * 3.6)
		mound.scale = Vector3(1.2, 1.25, 1.2)
		parent.add_child(mound)

	# Gate piers, lintel and rune keystone.
	for side in [-1.0, 1.0]:
		var pier := _add_mesh(parent, BoxMesh.new(), Vector3(side * 2.9, 3.0, 0.0), stone)
		pier.mesh.size = Vector3(2.0, 6.0, 2.4)
		var plinth := _add_mesh(parent, BoxMesh.new(), Vector3(side * 2.9, 0.35, 0.0), stone.darkened(0.08))
		plinth.mesh.size = Vector3(2.6, 0.7, 3.0)
		var capital := _add_mesh(parent, BoxMesh.new(), Vector3(side * 2.9, 6.25, 0.0), trim)
		capital.mesh.size = Vector3(2.5, 0.5, 2.9)
		var brazier := _make_sphere(0.22, tint, true)
		brazier.position = Vector3(side * 2.9, 6.85, -0.9)
		parent.add_child(brazier)
		var torch_light := OmniLight3D.new()
		torch_light.light_color = tint
		torch_light.light_energy = 1.8
		torch_light.omni_range = 16.0
		torch_light.position = Vector3(side * 2.9, 6.9, -1.1)
		parent.add_child(torch_light)
	var lintel := _add_mesh(parent, BoxMesh.new(), Vector3(0, 6.85, 0.0), trim)
	lintel.mesh.size = Vector3(8.0, 1.0, 2.6)
	var keystone := _add_mesh(parent, PrismMesh.new(), Vector3(0, 7.7, -0.1), tint.lightened(0.2))
	keystone.mesh.size = Vector3(1.1, 1.5, 1.1)
	keystone.rotation.y = PI * 0.25
	var rune_light := OmniLight3D.new()
	rune_light.light_color = tint
	rune_light.light_energy = 1.6
	rune_light.omni_range = 13.0
	rune_light.position = Vector3(0, 7.4, -1.0)
	parent.add_child(rune_light)

	# The passage behind the gate: a black recess so the mouth reads as depth.
	var recess := _add_mesh(parent, BoxMesh.new(), Vector3(0, 2.6, 1.15), Color(0.015, 0.015, 0.02))
	recess.mesh.size = Vector3(5.2, 5.2, 0.5)
	var shaft_glow := OmniLight3D.new()
	shaft_glow.light_color = tint.lerp(Color(0.7, 0.8, 1.0), 0.4)
	shaft_glow.light_energy = 0.8
	shaft_glow.omni_range = 9.0
	shaft_glow.position = Vector3(0, 1.6, 0.7)
	parent.add_child(shaft_glow)

	# Worn steps and rubble spill in front of the gate.
	for step_i in range(3):
		var step := _add_mesh(parent, BoxMesh.new(), Vector3(0, 0.06 + float(2 - step_i) * 0.16, -2.0 - float(step_i) * 1.1), stone.lightened(0.04))
		step.mesh.size = Vector3(6.4, 0.32, 1.2)
	for rubble_i in range(9):
		var rubble := _make_sphere(0.18 + rng.randf_range(0.0, 0.3), stone.lightened(rng.randf_range(-0.04, 0.08)), false)
		rubble.position = Vector3(rng.randf_range(-4.6, 4.6), 0.12, -1.6 - rng.randf_range(0.0, 3.4))
		rubble.scale = Vector3(1.3, 0.7, 1.1)
		parent.add_child(rubble)

	# A broken ore cart beside the adit: evidence that the place was worked.
	var cart := Node3D.new()
	cart.name = "CollapsedOreCart"
	cart.position = Vector3(4.3, 0.0, -1.6)
	cart.rotation = Vector3(0.08, 0.7, 0.22)
	parent.add_child(cart)
	var cart_body := _add_mesh(cart, BoxMesh.new(), Vector3(0, 0.55, 0), Color(0.30, 0.22, 0.15))
	cart_body.mesh.size = Vector3(1.5, 0.7, 1.0)
	for wheel_side in [-1.0, 1.0]:
		var wheel := _add_mesh(cart, CylinderMesh.new(), Vector3(0, 0.32, wheel_side * 0.55), Color(0.16, 0.14, 0.13))
		wheel.mesh.top_radius = 0.32
		wheel.mesh.bottom_radius = 0.32
		wheel.mesh.height = 0.12
		wheel.mesh.radial_segments = 10
		wheel.rotation.x = PI * 0.5

func _build_giant_tree_routes() -> void:
	var specs := [
		{"name":"Elderheart Redwood", "pos":Vector2(-105,-52), "height":26.0, "species":"redwood", "scale":1.42},
		{"name":"Worldroot Baobab", "pos":Vector2(29,26), "height":18.5, "species":"baobab", "scale":3.4}
	]
	for spec in specs:
		var p: Vector2 = spec.pos
		var scale := float(spec.scale)
		# HeroTreeRig scales every child uniformly, so all dressing is authored in
		# world units and divided back into local space; otherwise rungs and
		# platforms orbit metres away from the trunk as floating slabs.
		var trunk_world_r := (1.25 if str(spec.species) == "baobab" else 0.95) * scale
		var is_baobab := str(spec.species) == "baobab"
		if is_baobab:
			VegetationKit.get_mesh("baobab")
		var base := Vector3(p.x, _noise.get_height(p.x, p.y), p.y)
		var tree := HeroTreeRig.new()
		tree.configure(str(spec.species), scale)
		tree.position = base
		tree.name = str(spec.name).replace(" ", "")
		add_child(tree)
		var tree_label := Label3D.new()
		tree_label.text = str(spec.name) + " — E TO CLIMB"
		tree_label.position = Vector3(0, (float(spec.height) + (6.0 if is_baobab else 3.0)) / scale, 0)
		tree_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tree_label.font_size = 26
		tree.add_child(tree_label)
		# Bark footholds follow a continuous spiral hugging the real trunk surface.
		# The baobab trunk cap sits at rig y=4.55; above it a woody liana carries
		# the spiral into the crown instead of leaving rungs in mid-air.
		if is_baobab:
			var liana := CylinderMesh.new()
			liana.top_radius = 0.30
			liana.bottom_radius = 0.40
			liana.height = 3.6
			var liana_mesh := _add_mesh(tree, liana, Vector3(0, 3.7, 0), Color(0.30, 0.21, 0.13))
			liana_mesh.rotation.z = 0.06
		var rung_count := int((float(spec.height) * 0.9 - 1.0) / 0.72)
		for rung_i in range(rung_count):
			var rung_angle := float(rung_i) * 0.38
			var rung_y := 1.0 + float(rung_i) * 0.72
			var rung_mesh := BoxMesh.new()
			rung_mesh.size = Vector3(1.45, 0.14, 0.42) / scale
			var rung := MeshInstance3D.new()
			rung.mesh = rung_mesh
			rung.material_override = _tree_foothold_material()
			var rung_r := trunk_world_r + 0.12
			var rung_x := 0.0
			if is_baobab:
				var local_y := rung_y / scale
				if local_y <= 4.55:
					rung_r = lerpf(1.28, 0.82, clampf((local_y + 0.05) / 4.6, 0.0, 1.0)) * scale + 0.12
				else:
					rung_r = lerpf(0.40, 0.30, clampf((local_y - 1.9) / 3.6, 0.0, 1.0)) * scale + 0.12
					rung_x = -sin(0.06) * (local_y - 3.7) * scale
			else:
				var local_y := rung_y / scale - 3.0
				var trunk_r := lerpf(0.92, 0.46, clampf((local_y + 3.45) / 12.5, 0.0, 1.0))
				if local_y > 9.05:
					trunk_r = lerpf(0.46, 0.12, clampf((local_y - 5.9) / 6.6, 0.0, 1.0))
				rung_r = trunk_r * scale + 0.12
			rung.position = Vector3(cos(rung_angle) * rung_r + rung_x, rung_y, sin(rung_angle) * rung_r) / scale
			rung.rotation.y = -rung_angle
			tree.add_child(rung)
		var route_points: Array[Vector3] = []
		# Platforms sit on real wood: the baobab's branch limbs (below the crown
		# blobs so climbers get headroom) and its trunk cap, the redwood's trunk
		# at deck heights. Never hovering beside the tree or buried in foliage.
		var deck_spots: Array[Vector3] = []
		if is_baobab:
			for branch_i in [0, 2, 4]:
				var a := TAU * float(branch_i) / 6.0
				var start := Vector3(cos(a) * 0.52, 3.15, sin(a) * 0.52)
				var end: Vector3 = VegetationKit.baobab_branch_ends[branch_i]
				var mid := start.lerp(end, 0.45)
				deck_spots.append(Vector3(mid.x, mid.y + 0.15, mid.z) * scale)
			deck_spots.append(Vector3(0, 4.55 * scale, 0))
		else:
			for level in range(4):
				var a := float(level) * 1.5
				deck_spots.append(Vector3(cos(a) * trunk_world_r * 0.7, 4.0 + float(level) * 4.5, sin(a) * trunk_world_r * 0.7))
		for deck in deck_spots:
			var point := base + deck
			route_points.append(point)
			var platform := CylinderMesh.new()
			platform.top_radius = 2.1 / scale
			platform.bottom_radius = 2.1 / scale
			platform.height = 0.35 / scale
			_add_mesh(tree, platform, deck / scale, Color(0.36,0.25,0.14))
			var platform_body := StaticBody3D.new()
			platform_body.position = deck / scale
			tree.add_child(platform_body)
			var platform_shape := CollisionShape3D.new()
			var platform_cylinder := CylinderShape3D.new()
			platform_cylinder.radius = 2.1 / scale
			platform_cylinder.height = 0.35 / scale
			platform_shape.shape = platform_cylinder
			platform_body.add_child(platform_shape)
			var lantern := _make_sphere(0.18 / scale, Color(0.95,0.68,0.28), true)
			lantern.position = (deck + Vector3(1.3,0.45,0)) / scale
			tree.add_child(lantern)
		var route_data := {"name":spec.name,"base":base,"points":route_points,"visual":tree,"height":float(spec.height),"radius":trunk_world_r,"scale":scale}
		if is_baobab:
			route_data["hug_trunk"] = true
			route_data["climb_top"] = 4.55 * scale
			route_data["cap_y"] = 4.55 * scale
		_tree_routes.append(route_data)

func _tree_foothold_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.34, 0.23, 0.14)
	material.roughness = 0.94
	material.detail_enabled = true
	return material

func _build_waterfall_river() -> void:
	# The falls pour off Mirror Pond's north headwall (a real 8 m bluff carved by
	# TerrainNoise) into the pond; the pond drains south as the Heartlands river.
	# _water_center stays at the pond/river datum for gameplay water checks.
	var center := Vector3(42.0, Constants.WATER_LEVEL, -12.0)
	_water_center = center
	_water_surface_y = Constants.WATER_LEVEL + 0.05
	var lip := Vector3(42.0, Constants.WATER_LEVEL + 0.05, -23.6)

	# Feeder stream along the bluff top, ending at the lip the sheet pours from.
	var feeder := _add_mesh(self, PlaneMesh.new(), Vector3(42.0, 7.12, -36.25), Color(0.10, 0.39, 0.52))
	feeder.name = "WaterfallFeederStream"
	feeder.scale = Vector3(3.2, 1.0, 11.75)
	feeder.material_override = ChunkManager.shared_water_material if ChunkManager.shared_water_material != null else _make_water_shader()
	feeder.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var fall := MeshInstance3D.new()
	fall.name = "ElyndorHeartlands_WaterfallSheet"
	fall.mesh = _make_waterfall_sheet(5.6, 7.0, 12, 22)
	fall.position = lip
	fall.material_override = _make_waterfall_material()
	fall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(fall)

	# A second, finer ribbon adds depth and broken rivulets without creating
	# another independent waterfall landmark.
	var veil := MeshInstance3D.new()
	veil.name = "WaterfallFineVeil"
	veil.mesh = _make_waterfall_sheet(4.2, 6.8, 10, 20)
	veil.position = lip + Vector3(0.0, 0.01, 0.06)
	var veil_material := _make_waterfall_material()
	veil_material.set_shader_parameter("flow_speed", 2.55)
	veil_material.set_shader_parameter("stream_phase", 1.7)
	veil_material.set_shader_parameter("opacity_scale", 0.48)
	veil.material_override = veil_material
	veil.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(veil)

	# The plunge pool and river are thin water surfaces at the same datum as
	# the global ocean plane. Their slight lift avoids depth fighting at shorelines.
	var pool := _add_mesh(self, PlaneMesh.new(), Vector3(42.0, 0.055, -20.0), Color(0.08, 0.34, 0.46))
	pool.name = "WaterfallPlungePool"
	pool.scale = Vector3(5.0, 1.0, 4.0)
	pool.material_override = ChunkManager.shared_water_material if ChunkManager.shared_water_material != null else _make_water_shader()
	pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var river := _add_mesh(self, PlaneMesh.new(), center + Vector3(0.0, 0.04, 50.0), Color(0.10, 0.39, 0.52))
	river.name = "HeartlandsRiverSurface"
	river.scale = Vector3(5.0, 1.0, 43.0)
	river.material_override = ChunkManager.shared_water_material if ChunkManager.shared_water_material != null else _make_water_shader()
	river.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# Soft airborne spray catches the warm/cool light at the foot of the fall.
	var spray := GPUParticles3D.new()
	spray.name = "WaterfallPlungeMist"
	spray.position = Vector3(42.0, 0.42, -21.5)
	spray.amount = 150
	spray.lifetime = 1.45
	spray.explosiveness = 0.0
	spray.randomness = 0.82
	spray.emitting = true
	var spray_process := ParticleProcessMaterial.new()
	spray_process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	spray_process.emission_box_extents = Vector3(2.6, 0.22, 0.85)
	spray_process.direction = Vector3(0.0, 1.0, 0.0)
	spray_process.spread = 68.0
	spray_process.initial_velocity_min = 0.35
	spray_process.initial_velocity_max = 2.15
	spray_process.gravity = Vector3(0.0, -1.15, 0.0)
	spray_process.scale_min = 0.28
	spray_process.scale_max = 0.85
	spray_process.color = Color(0.72, 0.88, 0.96, 0.54)
	spray.process_material = spray_process
	var spray_mesh := SphereMesh.new()
	spray_mesh.radius = 0.065
	spray_mesh.height = 0.13
	var spray_mat := StandardMaterial3D.new()
	spray_mat.albedo_color = Color(0.72, 0.88, 0.96, 0.52)
	spray_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	spray_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spray_mat.vertex_color_use_as_albedo = true
	spray_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	spray_mat.roughness = 0.35
	spray.draw_pass_1 = spray_mesh
	spray.material_override = spray_mat
	add_child(spray)

	# Water-worn rock shoulders frame the falls and tie the sheet into the bluff.
	# Each tier is seated on the terrain at its own position, never stacked in air.
	for side in [-1.0, 1.0]:
		for tier in range(3):
			var shoulder := MeshInstance3D.new()
			shoulder.name = "WaterfallRockShoulder"
			shoulder.mesh = VegetationKit.get_mesh("rock")
			var sx := 1.55 + float(tier) * 0.28
			var sy := 1.45 + float(tier) * 0.38
			shoulder.scale = Vector3(sx, sy, 1.5 + float(tier) * 0.28)
			var sx_pos: float = 42.0 + side * (3.4 + float(tier) * 0.9)
			var sz_pos := -24.2 + float(tier) * 0.9
			var ground := _noise.get_height(sx_pos, sz_pos)
			shoulder.position = Vector3(sx_pos, ground - sy * 0.25, sz_pos)
			shoulder.rotation.y = float(side) * 0.16 + float(tier) * 0.22
			var stone := StandardMaterial3D.new()
			stone.albedo_color = Color(0.24, 0.29, 0.29).lerp(Color(0.38, 0.40, 0.36), float(tier) * 0.13)
			stone.roughness = 0.96
			shoulder.material_override = stone
			shoulder.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			add_child(shoulder)

func _make_waterfall_sheet(width: float, height: float, columns: int, rows: int) -> ArrayMesh:
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var columns_plus := columns + 1
	var rows_plus := rows + 1
	vertices.resize(columns_plus * rows_plus)
	normals.resize(columns_plus * rows_plus)
	uvs.resize(columns_plus * rows_plus)
	for y in range(rows_plus):
		var v := float(y) / float(rows)
		for x in range(columns_plus):
			var u := float(x) / float(columns)
			var widening := 0.90 + 0.10 * sin(v * PI * 0.5)
			var waviness := sin(v * 12.0 + u * 7.0) * 0.055 + sin(v * 25.0 - u * 9.0) * 0.022
			var index := y * columns_plus + x
			vertices[index] = Vector3((u - 0.5) * width * widening, v * height, waviness)
			normals[index] = Vector3(0.0, 0.0, 1.0)
			uvs[index] = Vector2(u, v)
	for y in range(rows):
		for x in range(columns):
			var a := y * columns_plus + x
			var b := a + 1
			var c := a + columns_plus
			var d := c + 1
			indices.append_array(PackedInt32Array([a, b, c, b, d, c]))
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

func _make_waterfall_material() -> ShaderMaterial:
	var shader := load("res://shaders/waterfall.gdshader") as Shader
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

func _build_breakables() -> void:
	var specs := [
		{"name":"Weathered Boulder","pos":Vector2(-42,-30),"hp":3,"drop":"iron_ore","qty":2,"color":Color(0.5,0.5,0.52)},
		{"name":"Crystal Growth","pos":Vector2(-55,-98),"hp":4,"drop":"mana_crystal","qty":2,"color":Color(0.3,0.65,1.0)},
		{"name":"Deadfall Log","pos":Vector2(-90,-42),"hp":2,"drop":"wood_log","qty":3,"color":Color(0.36,0.22,0.12)}
	]
	for spec in specs:
		var p: Vector2=spec.pos; var node:=Node3D.new(); node.position=Vector3(p.x,_noise.get_height(p.x,p.y),p.y); add_child(node)
		var mesh:=_make_sphere(1.2,spec.color,false); mesh.scale=Vector3(1.5,1.0,1.2); node.add_child(mesh)
		_breakables.append({"name":spec.name,"node":node,"hp":int(spec.hp),"broken":false,"drop":spec.drop,"quantity":int(spec.qty),"color":spec.color})

func _update_wildlife_tracks() -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server(): return
	for animal_variant in get_tree().get_nodes_in_group("critter"):
		var animal := animal_variant as Node3D
		if not is_instance_valid(animal): continue
		var key := str(animal.get_instance_id())
		var previous: Vector3 = _last_critter_positions.get(key, animal.global_position)
		var moved := Vector2(animal.global_position.x - previous.x, animal.global_position.z - previous.z).length()
		if moved < 3.2: continue
		var direction := Vector3(animal.global_position.x - previous.x, 0.0, animal.global_position.z - previous.z).normalized()
		if direction.length_squared() < 0.01: continue
		var side := Vector3(-direction.z, 0.0, direction.x) * 0.16
		for foot in range(2):
			var print_mesh := CylinderMesh.new()
			print_mesh.top_radius = 0.055
			print_mesh.bottom_radius = 0.075
			print_mesh.height = 0.012
			var print_node := MeshInstance3D.new()
			print_node.mesh = print_mesh
			var material := StandardMaterial3D.new()
			material.albedo_color = Color(0.12, 0.095, 0.065, 0.62)
			material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			print_node.material_override = material
			print_node.add_to_group("wildlife_track")
			print_node.set_meta("prey_kind", str(animal.get("kind")))
			print_node.set_meta("track_direction", direction)
			print_node.set_meta("track_time", Time.get_ticks_msec())
			var foot_pos := animal.global_position - direction * (0.7 + float(foot) * 0.42) + side * (1.0 if foot == 0 else -1.0)
			foot_pos.y = _noise.get_height(foot_pos.x, foot_pos.z) + 0.025
			print_node.global_position = foot_pos
			print_node.rotation.y = atan2(-direction.x, -direction.z)
			add_child(print_node)
			var print_id: int = print_node.get_instance_id()
			get_tree().create_timer(95.0).timeout.connect(func() -> void:
				var live: Node = instance_from_id(print_id) as Node
				if live: live.queue_free())
		_track_count += 1
		_last_critter_positions[key] = animal.global_position
	if _track_count > 240:
		_track_count = 0
		_last_critter_positions.clear()

func _update_nearby_environment() -> void:
	var player: Node3D = GameManager.player
	var player_near := player != null
	for cave in _caves:
		var entrance_distance := player.global_position.distance_to(cave.entrance) if player_near else INF
		var revealed := entrance_distance < 19.0
		var marker: Node3D = cave.get("marker") as Node3D
		var cave_label: Label3D = cave.get("label") as Label3D
		if marker: marker.visible = revealed
		if cave_label: cave_label.visible = revealed
		if player_near and entrance_distance < 13.0 and entrance_distance > 4.0 and _cave_hint_cooldown <= 0.0 and not bool(PlayerData.stats.get("cave_clue_" + str(cave.name), false)):
			_cave_hint_cooldown = 24.0
			PlayerData.stats["cave_clue_" + str(cave.name)] = true
			EventBus.toast.emit("You notice disturbed stones and a faint draft nearby. There may be a hidden entrance.", "discovery")
	for route in _tree_routes:
		var tree: Node3D = route.get("visual")
		if tree == null: continue
		var shake_strength := 0.0
		for beast in get_tree().get_nodes_in_group("colossal_beast"):
			if not beast is Node3D: continue
			var beast_distance: float = tree.global_position.distance_to((beast as Node3D).global_position)
			if beast_distance < 18.0:
				shake_strength = maxf(shake_strength, 1.0 - beast_distance / 18.0)
		var wind := sin(Time.get_ticks_msec() * 0.00035 + tree.global_position.x) * 0.006
		tree.rotation.z = wind + sin(Time.get_ticks_msec() * 0.004) * 0.035 * shake_strength
		if player_near and player.global_position.distance_to(tree.global_position) < 18.0 and shake_strength > 0.25:
			if randf() < 0.04: EventBus.toast.emit("The ancient tree shudders under a colossal footfall", "warning")

func _make_water_shader() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_disabled;
uniform vec4 water_tint : source_color = vec4(0.20, 0.52, 0.68, 0.82);
void fragment() {
	vec2 flow_uv = UV + vec2(0.0, TIME * 0.22);
	float ripple = sin(flow_uv.y * 42.0 + sin(flow_uv.x * 18.0) * 2.0) * 0.08;
	float streak = smoothstep(0.68, 0.98, sin(flow_uv.y * 85.0 + flow_uv.x * 13.0) * 0.5 + 0.5);
	ALBEDO = water_tint.rgb + vec3(ripple * 0.35) + vec3(streak * 0.12);
	ROUGHNESS = 0.2;
	METALLIC = 0.04;
	ALPHA = water_tint.a;
}
"""
	var material := ShaderMaterial.new(); material.shader = shader
	return material

func _add_mesh(parent: Node3D, mesh: Mesh, pos: Vector3, tint: Color) -> MeshInstance3D:
	var mi:=MeshInstance3D.new(); mi.mesh=mesh; mi.position=pos
	var mat:=StandardMaterial3D.new(); mat.albedo_color=tint; mat.roughness=0.92; mi.material_override=mat; parent.add_child(mi); return mi

func _make_sphere(radius: float, tint: Color, glow: bool) -> MeshInstance3D:
	var mi:=MeshInstance3D.new(); var mesh:=SphereMesh.new(); mesh.radius=radius; mesh.height=radius*2; mesh.radial_segments=16; mesh.rings=10; mi.mesh=mesh
	var mat:=StandardMaterial3D.new(); mat.albedo_color=tint; mat.roughness=0.82
	if glow: mat.emission_enabled=true; mat.emission=tint; mat.emission_energy_multiplier=1.4
	mi.material_override=mat; return mi
