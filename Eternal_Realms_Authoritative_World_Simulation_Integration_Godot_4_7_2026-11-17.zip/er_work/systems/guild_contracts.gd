# Rotating single-player regional guild board. Contracts persist across saves;
# rotation is deterministic per in-game calendar day to avoid reroll exploits.
extends Node

signal contracts_changed(region_id: String, contracts: Array)
signal contract_progressed(contract_id: String, progress: int, required: int)
signal contract_completed(contract_id: String, reward_gold: int, reputation: int)

const SAVE_KEY := "guild_contract_state_v1"
const REGIONS := ["elyndor_heartlands", "whispering_woods", "crownfall_highlands", "mirror_lake", "ashen_frontier"]
const TYPES := [
	{"kind":"hunt", "title":"Cull the Threat", "desc":"Defeat hostile creatures threatening the roads", "target":5, "gold":90, "rep":8},
	{"kind":"gather", "title":"Field Provisions", "desc":"Gather useful materials for the regional stores", "target":8, "gold":65, "rep":6},
	{"kind":"craft", "title":"Supply the Artisans", "desc":"Craft equipment or useful supplies", "target":3, "gold":110, "rep":9},
	{"kind":"explore", "title":"Chart the Unknown", "desc":"Discover landmarks and forgotten places", "target":2, "gold":100, "rep":8},
	{"kind":"fish", "title":"Freshwater Trade", "desc":"Catch fish for the local kitchens", "target":5, "gold":75, "rep":6},
	{"kind":"dungeon", "title":"Delver's Commission", "desc":"Explore deeper into the underground civilization", "target":2, "gold":140, "rep":12}
]
var board: Dictionary = {}
var accepted: Dictionary = {}
var completed_ids: Array = []
var reputation: Dictionary = {}
var current_day: int = -1
var competition: Dictionary = {} # regional guild influence, persisted with the board

func _ready() -> void:
	_load()
	_roll_daily_board()
	if not EventBus.activity.is_connected(_on_activity):
		EventBus.activity.connect(_on_activity)
	if not EventBus.entity_died.is_connected(_on_entity_died):
		EventBus.entity_died.connect(_on_entity_died)

func _day_index() -> int:
	return int(floor(Time.get_unix_time_from_system() / 86400.0))

func _roll_daily_board() -> void:
	var day := _day_index()
	if current_day == day and not board.is_empty():
		return
	current_day = day
	board.clear()
	for region in REGIONS:
		var entries: Array = []
		var seed_value: int = absi((str(region) + str(day)).hash())
		for i in range(4):
			var spec: Dictionary = TYPES[(seed_value + i * 7 + (day % TYPES.size())) % TYPES.size()].duplicate(true)
			var regional_heat := int(competition.get(region, 0))
			var tier := clampi(1 + int(maxi(int(reputation.get(region, 0)), 0) / 35) + int(regional_heat / 120), 1, 5)
			spec["id"] = "%s_%d_%d" % [region, day, i]
			spec["region"] = region
			spec["tier"] = tier
			spec["target"] = int(spec.target) + (tier - 1) * 2
			spec["gold"] = int(spec.gold) * tier
			spec["rep"] = int(spec.rep) + tier * 2
			spec["progress"] = 0
			spec["status"] = "available"
			entries.append(spec)
		board[region] = entries
	_save()

func get_contracts(region_id: String = "elyndor_heartlands") -> Array:
	_roll_daily_board()
	return (board.get(region_id, []) as Array).duplicate(true)

func accept_contract(contract_id: String) -> bool:
	_roll_daily_board()
	for region in board:
		for contract in board[region]:
			if str(contract.id) == contract_id and str(contract.status) == "available":
				contract.status = "active"
				accepted[contract_id] = {"region":str(region), "kind":str(contract.kind), "target":int(contract.target), "progress":0, "gold":int(contract.gold), "rep":int(contract.rep)}
				_save()
				contracts_changed.emit(str(region), get_contracts(str(region)))
				return true
	return false

func abandon_contract(contract_id: String) -> bool:
	if not accepted.has(contract_id):
		return false
	var region := str(accepted[contract_id].region)
	accepted.erase(contract_id)
	for contract in board.get(region, []):
		if str(contract.id) == contract_id:
			contract.status = "abandoned"
	_save()
	contracts_changed.emit(region, get_contracts(region))
	return true

func record_progress(kind: String, amount: int = 1, region_id: String = "elyndor_heartlands") -> void:
	if amount <= 0:
		return
	for id in accepted.keys():
		var data: Dictionary = accepted[id]
		if str(data.kind) != kind or str(data.region) != region_id:
			continue
		data.progress = mini(int(data.progress) + amount, int(data.target))
		for contract in board.get(region_id, []):
			if str(contract.id) == str(id):
				contract.progress = int(data.progress)
		contract_progressed.emit(str(id), int(data.progress), int(data.target))
		if int(data.progress) >= int(data.target):
			_complete(str(id))
	_save()

func _complete(contract_id: String) -> void:
	if not accepted.has(contract_id):
		return
	var data: Dictionary = accepted[contract_id]
	var region := str(data.region)
	var gold := int(data.gold)
	var rep := int(data.rep)
	PlayerData.add_gold(gold)
	if is_instance_valid(GuildSystem):
		GuildSystem.add_renown(maxi(1, int(rep / 2)), "Regional commission: %s" % contract_id)
	reputation[region] = clampi(int(reputation.get(region, 0)) + rep, -100, 500)
	competition[region] = clampi(int(competition.get(region, 0)) + rep * 2, 0, 1000)
	completed_ids.append(contract_id)
	accepted.erase(contract_id)
	for contract in board.get(region, []):
		if str(contract.id) == contract_id:
			contract.status = "completed"
	contract_completed.emit(contract_id, gold, rep)
	EventBus.toast.emit("Guild contract complete: +%d gold, +%d regional reputation" % [gold, rep], "levelup")
	EventBus.activity.emit("Guild commission completed in %s" % region.replace("_", " ").capitalize(), "guild")
	contracts_changed.emit(region, get_contracts(region))

func regional_reputation(region_id: String) -> int:
	return int(reputation.get(region_id, 0))

func regional_competition_score(region_id: String) -> int:
	return int(competition.get(region_id, 0))

func regional_competition_tier(region_id: String) -> String:
	var score := regional_competition_score(region_id)
	if score >= 700: return "Dominant"
	if score >= 400: return "Contender"
	if score >= 150: return "Rising"
	return "Unproven"

func regional_rank(region_id: String) -> String:
	var value := regional_reputation(region_id)
	if value >= 250: return "Exalted"
	if value >= 150: return "Honoured"
	if value >= 75: return "Trusted"
	if value >= 25: return "Recognised"
	if value < 0: return "Distrusted"
	return "Unknown"

func _on_entity_died(entity: Node) -> void:
	if is_instance_valid(entity) and entity.is_in_group("enemy"):
		record_progress("hunt")

func _on_activity(message: String, category: String) -> void:
	# Activity messages are a compatibility bridge for legacy systems. Explicit
	# record_progress calls are preferred for exact item/species accounting.
	var text := message.to_lower()
	var kind := ""
	if category == "loot" and (text.contains("herb") or text.contains("ore") or text.contains("wood") or text.contains("resource")): kind = "gather"
	elif category == "combat" and (text.contains("defeat") or text.contains("slain") or text.contains("hunted")): kind = "hunt"
	elif category == "exploration" and (text.contains("discover") or text.contains("charted")): kind = "explore"
	elif category == "crafting" or text.begins_with("crafted "): kind = "craft"
	elif category == "fishing" or text.contains("caught a fish"): kind = "fish"
	elif category == "dungeon" and (text.contains("floor") or text.contains("descend")): kind = "dungeon"
	if kind != "":
		record_progress(kind)

func _save() -> void:
	PlayerData.stats[SAVE_KEY] = {"day":current_day, "board":board, "accepted":accepted, "completed":completed_ids, "reputation":reputation, "competition":competition}

func _load() -> void:
	var value: Variant = PlayerData.stats.get(SAVE_KEY, {})
	if value is Dictionary:
		current_day = int(value.get("day", -1))
		board = value.get("board", {})
		accepted = value.get("accepted", {})
		completed_ids = value.get("completed", [])
		reputation = value.get("reputation", {})
		competition = value.get("competition", {})
