extends Node

const CROPS := {
    "wheat_seed": {"crop":"wheat", "yield":"wheat", "days": 2, "color": Color(0.72, 0.62, 0.24)},
    "carrot_seed": {"crop":"carrot", "yield":"carrot", "days": 2, "color": Color(0.88, 0.42, 0.18)},
    "berry_seed": {"crop":"berry", "yield":"farm_berries", "days": 3, "color": Color(0.56, 0.22, 0.48)}
}
var plots: Array[Dictionary] = []
var visuals: Array[Node3D] = []
var selected_seed := "wheat_seed"
var _clock := 0.0

func _ready() -> void:
    add_to_group("farming_system")
    _load_state()
    call_deferred("_rebuild_visuals")

func _input(event: InputEvent) -> void:
    if GameManager.input_locked or not (event is InputEventKey) or not event.pressed or event.echo:
        return
    if event.keycode == KEY_F1: selected_seed = "wheat_seed"; EventBus.toast.emit("Selected wheat seeds", "info")
    elif event.keycode == KEY_F2: selected_seed = "carrot_seed"; EventBus.toast.emit("Selected carrot seeds", "info")
    elif event.keycode == KEY_F3: selected_seed = "berry_seed"; EventBus.toast.emit("Selected berry seeds", "info")
    elif event.keycode == KEY_N: _create_plot()
    elif event.keycode == KEY_H: plant_nearest()
    elif event.keycode == KEY_Z: _tend_nearest("water")
    elif event.keycode == KEY_Y: _tend_nearest("prune")
    elif event.keycode == KEY_U: _tend_nearest("harvest")
    if event.keycode in [KEY_F1, KEY_F2, KEY_F3, KEY_N, KEY_H, KEY_Z, KEY_Y, KEY_U]: get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
    _clock += delta
    if _clock < 45.0:
        return
    var elapsed := _clock
    _clock = 0.0
    var changed := false
    for plot in plots:
        if str(plot.get("seed", "")) == "" or int(plot.get("stage", 0)) >= 3:
            continue
        var position := Vector3(float(plot.get("x", 0.0)), float(plot.get("y", 0.0)), float(plot.get("z", 0.0)))
        var water_state := HydrologySystem.update_cell(position, elapsed)
        var moisture := float(water_state.get("soil_saturation", 0.0))
        var flood_risk := float(water_state.get("flood_risk", 0.0))
        plot["soil_moisture"] = moisture
        plot["water"] = clampi(roundi(moisture * 4.0), 0, 4)
        plot["flood_stress"] = flood_risk
        var climate := ClimateSystem.sample_at(position)
        var temperature := float(climate.get("temperature_c", 18.0))
        var seasonal_factor := 1.0
        var season_name := ClimateSystem.get_season_name()
        var seed_id := str(plot.get("seed", ""))
        if season_name == "Winter":
            seasonal_factor = 0.25 if seed_id == "carrot_seed" else 0.12
        elif season_name == "Autumn":
            seasonal_factor = 0.9 if seed_id == "wheat_seed" else 0.7
        elif season_name == "Summer":
            seasonal_factor = 1.0 if seed_id != "berry_seed" else 0.85
        else:
            seasonal_factor = 1.0
        if temperature < 3.0:
            seasonal_factor *= 0.45
        elif temperature < 8.0 or temperature > 34.0:
            seasonal_factor *= 0.7
        var moisture_factor := clampf((moisture - 0.12) / 0.48, 0.0, 1.0)
        if moisture > 0.92:
            moisture_factor *= 0.55 # waterlogged roots lose oxygen
        var flood_factor := 1.0 - clampf(flood_risk * 0.9, 0.0, 0.9)
        var growth_delta := 0.22 * seasonal_factor * moisture_factor * flood_factor * (elapsed / 45.0)
        if moisture < 0.08:
            growth_delta = 0.0
        plot["growth"] = float(plot.get("growth", 0.0)) + growth_delta
        if float(plot["growth"]) >= 1.0:
            plot["stage"] = mini(3, int(plot.get("stage", 0)) + 1)
            plot["growth"] = 0.0
        changed = true
    if changed:
        _save_state()
        _rebuild_visuals()

func _create_plot() -> void:
    var player: Node3D = GameManager.player
    if player == null or not PlayerData.remove_item("wood_log", 2):
        EventBus.toast.emit("Need 2 wood logs to edge a garden bed.", "warning"); return
    var point := player.global_position + -player.global_transform.basis.z * 3.0
    point.y = _ground_height(point)
    for plot in plots:
        if Vector2(float(plot.x), float(plot.z)).distance_to(Vector2(point.x, point.z)) < 2.4:
            EventBus.toast.emit("There is already a garden bed here.", "warning"); PlayerData.add_item("wood_log", 2); return
    plots.append({"x":point.x,"y":point.y,"z":point.z,"seed":"","stage":0,"water":0,"soil_moisture":0.25,"flood_stress":0.0,"growth":0.0,"pruned":false})
    _save_state(); _rebuild_visuals(); EventBus.toast.emit("Garden bed prepared. Plant with F1/F2/F3.", "success")

func create_plot_at(point: Vector3) -> void:
    for plot in plots:
        if Vector2(float(plot.x), float(plot.z)).distance_to(Vector2(point.x, point.z)) < 2.4:
            return
    plots.append({"x":point.x,"y":point.y,"z":point.z,"seed":"","stage":0,"water":0,"soil_moisture":0.25,"flood_stress":0.0,"growth":0.0,"pruned":false})
    _save_state(); _rebuild_visuals()

func _tend_nearest(action: String) -> void:
    var player: Node3D = GameManager.player
    if player == null: return
    var idx := _nearest_plot(player.global_position)
    if idx < 0: EventBus.toast.emit("No garden bed nearby.", "warning"); return
    var plot: Dictionary = plots[idx]
    if action == "water":
        if int(plot.stage) >= 3 or str(plot.seed) == "": EventBus.toast.emit("Nothing here needs watering.", "info"); return
        plot.water = mini(4, int(plot.water) + 3)
        plot.soil_moisture = clampf(float(plot.get("soil_moisture", 0.25)) + 0.35, 0.0, 1.0)
        HydrologySystem.add_soil_moisture(Vector3(float(plot.x), float(plot.y), float(plot.z)), 0.35)
        EventBus.toast.emit("You water the crop. Moisture: %d/3" % int(plot.water), "success")
    elif action == "prune":
        if str(plot.seed) != "berry_seed" or int(plot.stage) < 1: EventBus.toast.emit("Only a growing berry bush needs pruning.", "info"); return
        plot.pruned = true; EventBus.toast.emit("You prune the berry bush for healthier growth.", "success")
    elif action == "harvest":
        if int(plot.stage) < 3: EventBus.toast.emit("The crop is not ripe yet.", "warning"); return
        var seed_id := str(plot.seed)
        var yield_id := str(CROPS[seed_id]["yield"])
        var amount := 3 if seed_id == "berry_seed" and bool(plot.pruned) else 2
        PlayerData.add_item(yield_id, amount)
        PlayerData.add_item(seed_id, 1)
        plot.seed = ""; plot.stage = 0; plot.water = 0; plot.growth = 0.0; plot.pruned = false
        if player.get("skills"): player.skills.train("farming", 0.5)
        EventBus.toast.emit("Harvest gathered. You saved a seed for the next planting.", "success")
    _save_state(); _rebuild_visuals()

func plant_nearest() -> void:
    var player: Node3D = GameManager.player
    if player == null: return
    var idx := _nearest_plot(player.global_position)
    if idx < 0: EventBus.toast.emit("Prepare a garden bed first with N.", "warning"); return
    if str(plots[idx].seed) != "": EventBus.toast.emit("This bed is already planted.", "warning"); return
    if not PlayerData.remove_item(selected_seed, 1): EventBus.toast.emit("You need " + selected_seed.replace("_", " ") + ".", "warning"); return
    plots[idx].seed = selected_seed; plots[idx].stage = 0; plots[idx].water = 0; plots[idx].soil_moisture = HydrologySystem.get_soil_moisture(Vector3(float(plots[idx].x), float(plots[idx].y), float(plots[idx].z))); plots[idx].growth = 0.0
    _save_state(); _rebuild_visuals(); EventBus.toast.emit("Seed planted. Water it with Z.", "success")

func _nearest_plot(pos: Vector3) -> int:
    var best := -1; var best_d := 4.0
    for i in range(plots.size()):
        var d := pos.distance_to(Vector3(float(plots[i].x), float(plots[i].y), float(plots[i].z)))
        if d < best_d: best_d = d; best = i
    return best

func _ground_height(p: Vector3) -> float:
    var chunk_manager := get_tree().get_first_node_in_group("chunk_manager")
    if chunk_manager != null and chunk_manager.has_method("get_height"):
        return float(chunk_manager.get_height(p.x, p.z)) + 0.08
    var noise := TerrainNoise.new(GameManager.world_seed)
    return noise.get_height(p.x, p.z) + 0.08

func _save_state() -> void:
    PlayerData.stats["farm_plots"] = plots.duplicate(true)

func restore_from_player_data() -> void:
    _load_state()
    _rebuild_visuals()

func _load_state() -> void:
    var saved: Variant = PlayerData.stats.get("farm_plots", [])
    if saved is Array: plots.assign(saved)

func _rebuild_visuals() -> void:
    for v in visuals:
        if is_instance_valid(v): v.queue_free()
    visuals.clear()
    for plot in plots:
        var root := Node3D.new()
        root.position = Vector3(float(plot.x), float(plot.y), float(plot.z))
        root.add_to_group("player_built")
        get_tree().current_scene.add_child(root)
        visuals.append(root)
        var soil := MeshInstance3D.new()
        var soil_mesh := BoxMesh.new(); soil_mesh.size = Vector3(1.8, 0.12, 1.8); soil.mesh = soil_mesh
        var soil_mat := StandardMaterial3D.new()
        soil_mat.albedo_color = Color(0.16,0.10,0.055) if int(plot.get("water",0)) > 0 else Color(0.27,0.16,0.085)
        soil_mat.roughness = 1.0; soil.material_override = soil_mat; root.add_child(soil)
        # Raised timber edging makes the bed readable against uneven terrain.
        for edge in range(4):
            var border := MeshInstance3D.new(); var border_mesh := BoxMesh.new(); border_mesh.size = Vector3(1.92,0.16,0.12) if edge < 2 else Vector3(0.12,0.16,1.8); border.mesh = border_mesh
            border.position = Vector3(0,0.08,(-0.88 if edge == 0 else (0.88 if edge == 1 else 0.0))) if edge < 2 else Vector3((-0.88 if edge == 2 else 0.88),0.08,0)
            var wood_mat := StandardMaterial3D.new(); wood_mat.albedo_color = Color(0.30,0.19,0.10); wood_mat.roughness = 0.95; border.material_override = wood_mat; root.add_child(border)
        var seed_id := str(plot.get("seed", ""))
        if seed_id == "": continue
        var stage := int(plot.get("stage",0))
        var plant_count := 3 if stage == 0 else 5
        for i in range(plant_count):
            var px := -0.48 + float(i % 3) * 0.48
            var pz := -0.42 + float(i / 3) * 0.55
            var stem := MeshInstance3D.new(); var stem_mesh := CylinderMesh.new(); stem_mesh.top_radius = 0.025; stem_mesh.bottom_radius = 0.04; stem_mesh.height = 0.28 + float(stage) * 0.22; stem.mesh = stem_mesh
            var stem_mat := StandardMaterial3D.new(); stem_mat.albedo_color = Color(0.20,0.38,0.12); stem.material_override = stem_mat; stem.position = Vector3(px,stem_mesh.height * 0.5 + 0.08,pz); root.add_child(stem)
            for leaf_side in [-1.0,1.0]:
                var leaf := MeshInstance3D.new(); var leaf_mesh := SphereMesh.new(); leaf_mesh.radius = 0.13 + float(stage) * 0.035; leaf_mesh.height = 0.09 + float(stage) * 0.02; leaf.mesh = leaf_mesh
                var leaf_mat := StandardMaterial3D.new(); leaf_mat.albedo_color = Color(0.24,0.48,0.16) if seed_id != "berry_seed" else Color(0.18,0.40,0.20); leaf_mat.roughness = 0.8; leaf.material_override = leaf_mat
                leaf.position = Vector3(px + leaf_side * 0.12,stem_mesh.height * 0.58 + 0.08,pz); leaf.scale = Vector3(1.0,0.55,1.6); root.add_child(leaf)
            if stage >= 2:
                var fruit := MeshInstance3D.new(); var fruit_mesh := SphereMesh.new(); fruit_mesh.radius = 0.095 if seed_id != "carrot_seed" else 0.12; fruit_mesh.height = fruit_mesh.radius * 2.0; fruit.mesh = fruit_mesh
                var fruit_mat := StandardMaterial3D.new(); fruit_mat.albedo_color = Color(0.68,0.18,0.12) if seed_id == "berry_seed" else (Color(0.90,0.42,0.12) if seed_id == "carrot_seed" else Color(0.78,0.68,0.24)); fruit_mat.roughness = 0.55; fruit.material_override = fruit_mat
                fruit.position = Vector3(px,stem_mesh.height + 0.08,pz); root.add_child(fruit)
