# MeshKit - tiny procedural geometry toolkit (SurfaceTool based)
#
# Every helper takes an "outward" hint or vertex normals and fixes triangle winding
# automatically (Godot front faces are clockwise), so shapes can't come out inside-out.
# UVs are in METERS so pattern shaders (bricks, planks, tiles...) keep a constant scale.
class_name MeshKit
extends RefCounted

const WHITE := Color(1, 1, 1, 1)

static func tri_core(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3,
		na: Vector3, nb: Vector3, nc: Vector3,
		ca: Color, cb: Color, cc: Color,
		ua: Vector2, ub: Vector2, uc: Vector2) -> void:
	var fn: Vector3 = (b - a).cross(c - a)
	if fn.length_squared() < 1e-10:
		return
	# Make (b-a)x(c-a) agree with the outward normals, then emit a,c,b (clockwise from outside).
	if fn.dot(na + nb + nc) < 0.0:
		var tv: Vector3 = b
		b = c
		c = tv
		var tn: Vector3 = nb
		nb = nc
		nc = tn
		var tc: Color = cb
		cb = cc
		cc = tc
		var tu: Vector2 = ub
		ub = uc
		uc = tu
	st.set_normal(na); st.set_color(ca); st.set_uv(ua); st.add_vertex(a)
	st.set_normal(nc); st.set_color(cc); st.set_uv(uc); st.add_vertex(c)
	st.set_normal(nb); st.set_color(cb); st.set_uv(ub); st.add_vertex(b)

## Flat shaded triangle. `outward` is any vector pointing away from the solid's interior.
static func flat_tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, outward: Vector3,
		ca: Color = WHITE, cb: Color = WHITE, cc: Color = WHITE,
		ua: Vector2 = Vector2.ZERO, ub: Vector2 = Vector2.ZERO, uc: Vector2 = Vector2.ZERO) -> void:
	var n: Vector3 = (b - a).cross(c - a)
	if n.length_squared() < 1e-10:
		return
	n = n.normalized()
	if n.dot(outward) < 0.0:
		n = -n
	tri_core(st, a, b, c, n, n, n, ca, cb, cc, ua, ub, uc)

## Quad given as a,b,c,d around the perimeter.
static func flat_quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, outward: Vector3,
		ca: Color = WHITE, cb: Color = WHITE, cc: Color = WHITE, cd: Color = WHITE,
		ua: Vector2 = Vector2(0, 0), ub: Vector2 = Vector2(1, 0), uc: Vector2 = Vector2(1, 1), ud: Vector2 = Vector2(0, 1)) -> void:
	flat_tri(st, a, b, c, outward, ca, cb, cc, ua, ub, uc)
	flat_tri(st, a, c, d, outward, ca, cc, cd, ua, uc, ud)

# Box face table: [normal, u axis, v axis]
const _BOX_FACES: Array = [
	[Vector3.RIGHT, Vector3.BACK, Vector3.UP],
	[Vector3.LEFT, Vector3.FORWARD, Vector3.UP],
	[Vector3.UP, Vector3.RIGHT, Vector3.BACK],
	[Vector3.DOWN, Vector3.RIGHT, Vector3.FORWARD],
	[Vector3.BACK, Vector3.LEFT, Vector3.UP],
	[Vector3.FORWARD, Vector3.RIGHT, Vector3.UP],
]

## Box centered on the transform origin. Colors blend bottom->top for cheap fake AO.
static func box(st: SurfaceTool, xf: Transform3D, size: Vector3, c_bottom: Color = WHITE, c_top: Color = WHITE) -> void:
	var half: Vector3 = size * 0.5
	for f in _BOX_FACES:
		var n: Vector3 = f[0]
		var u: Vector3 = f[1]
		var v: Vector3 = f[2]
		var hn: float = absf(n.dot(half))
		var hu: float = absf(u.dot(half))
		var hv: float = absf(v.dot(half))
		var corners: Array[Vector3] = [
			n * hn - u * hu - v * hv,
			n * hn + u * hu - v * hv,
			n * hn + u * hu + v * hv,
			n * hn - u * hu + v * hv,
		]
		var uvs: Array[Vector2] = [Vector2(0, 0), Vector2(2.0 * hu, 0), Vector2(2.0 * hu, 2.0 * hv), Vector2(0, 2.0 * hv)]
		var cols: Array[Color] = []
		var wpos: Array[Vector3] = []
		for p in corners:
			var t: float = clampf((p.y + half.y) / maxf(size.y, 0.0001), 0.0, 1.0)
			cols.append(c_bottom.lerp(c_top, t))
			wpos.append(xf * p)
		var wn: Vector3 = (xf.basis * n).normalized()
		flat_quad(st, wpos[0], wpos[1], wpos[2], wpos[3], wn, cols[0], cols[1], cols[2], cols[3], uvs[0], uvs[1], uvs[2], uvs[3])

static func box_at(st: SurfaceTool, pos: Vector3, size: Vector3, c_bottom: Color = WHITE, c_top: Color = WHITE) -> void:
	box(st, Transform3D(Basis.IDENTITY, pos), size, c_bottom, c_top)

## Vertical (Y axis) cylinder / cone / frustum. Origin is the CENTER of the base.
static func cylinder(st: SurfaceTool, xf: Transform3D, r_bottom: float, r_top: float, height: float,
		segs: int = 10, c_bottom: Color = WHITE, c_top: Color = WHITE,
		cap_bottom: bool = true, cap_top: bool = true, smooth: bool = true) -> void:
	var avg_r: float = maxf((r_bottom + r_top) * 0.5, 0.001)
	var slope: float = r_bottom - r_top
	for i in range(segs):
		var a0: float = TAU * float(i) / float(segs)
		var a1: float = TAU * float(i + 1) / float(segs)
		var d0: Vector3 = Vector3(cos(a0), 0, sin(a0))
		var d1: Vector3 = Vector3(cos(a1), 0, sin(a1))
		var b0: Vector3 = xf * (d0 * r_bottom)
		var b1: Vector3 = xf * (d1 * r_bottom)
		var t0: Vector3 = xf * (d0 * r_top + Vector3(0, height, 0))
		var t1: Vector3 = xf * (d1 * r_top + Vector3(0, height, 0))
		var n0: Vector3 = (xf.basis * (d0 * height + Vector3(0, slope, 0))).normalized()
		var n1: Vector3 = (xf.basis * (d1 * height + Vector3(0, slope, 0))).normalized()
		var u0: float = TAU * avg_r * float(i) / float(segs)
		var u1: float = TAU * avg_r * float(i + 1) / float(segs)
		if smooth:
			tri_core(st, b0, b1, t1, n0, n1, n1, c_bottom, c_bottom, c_top, Vector2(u0, 0), Vector2(u1, 0), Vector2(u1, height))
			tri_core(st, b0, t1, t0, n0, n1, n0, c_bottom, c_top, c_top, Vector2(u0, 0), Vector2(u1, height), Vector2(u0, height))
		else:
			var nm: Vector3 = (n0 + n1).normalized()
			flat_tri(st, b0, b1, t1, nm, c_bottom, c_bottom, c_top, Vector2(u0, 0), Vector2(u1, 0), Vector2(u1, height))
			flat_tri(st, b0, t1, t0, nm, c_bottom, c_top, c_top, Vector2(u0, 0), Vector2(u1, height), Vector2(u0, height))
		if cap_bottom and r_bottom > 0.001:
			flat_tri(st, xf * Vector3.ZERO, b1, b0, xf.basis * Vector3.DOWN, c_bottom, c_bottom, c_bottom,
				Vector2.ZERO, Vector2(d1.x, d1.z) * r_bottom, Vector2(d0.x, d0.z) * r_bottom)
		if cap_top and r_top > 0.001:
			var top: Vector3 = xf * Vector3(0, height, 0)
			flat_tri(st, top, t0, t1, xf.basis * Vector3.UP, c_top, c_top, c_top,
				Vector2.ZERO, Vector2(d0.x, d0.z) * r_top, Vector2(d1.x, d1.z) * r_top)

static func cylinder_at(st: SurfaceTool, pos: Vector3, r_bottom: float, r_top: float, height: float,
		segs: int = 10, c_bottom: Color = WHITE, c_top: Color = WHITE, smooth: bool = true) -> void:
	cylinder(st, Transform3D(Basis.IDENTITY, pos), r_bottom, r_top, height, segs, c_bottom, c_top, true, true, smooth)

## Flat shaded, slightly lumpy ellipsoid - the building block of stylized foliage and rocks.
## Colors blend low->high; `tint_a` is written to vertex alpha (foliage shader tint weight).
static func blob(st: SurfaceTool, center: Vector3, radii: Vector3, rng: RandomNumberGenerator,
		c_low: Color, c_high: Color, jitter: float = 0.18, segs: int = 7, rings: int = 5, tint_a: float = 1.0) -> void:
	var jit: Array[float] = []
	for i in range((rings + 1) * segs):
		jit.append(1.0 + (rng.randf() - 0.5) * 2.0 * jitter)
	var pos: Array[Vector3] = []
	var cols: Array[Color] = []
	for r in range(rings + 1):
		var phi: float = PI * float(r) / float(rings)
		for s in range(segs):
			var theta: float = TAU * float(s) / float(segs)
			var dir: Vector3 = Vector3(sin(phi) * cos(theta), cos(phi), sin(phi) * sin(theta))
			var j: float = 1.0
			if r != 0 and r != rings:
				j = jit[r * segs + s]
			pos.append(center + dir * radii * j)
			var col: Color = c_low.lerp(c_high, clampf(dir.y * 0.5 + 0.5, 0.0, 1.0))
			col.a = tint_a
			cols.append(col)
	for r in range(rings):
		for s in range(segs):
			var s2: int = (s + 1) % segs
			var i00: int = r * segs + s
			var i01: int = r * segs + s2
			var i10: int = (r + 1) * segs + s
			var i11: int = (r + 1) * segs + s2
			var o: Vector3 = (pos[i00] + pos[i11]) * 0.5 - center
			flat_tri(st, pos[i00], pos[i10], pos[i11], o, cols[i00], cols[i10], cols[i11])
			flat_tri(st, pos[i00], pos[i11], pos[i01], o, cols[i00], cols[i11], cols[i01])

## Rounded wedge used for rocks etc: just a blob with higher jitter.
static func rock(st: SurfaceTool, center: Vector3, radii: Vector3, rng: RandomNumberGenerator, c_low: Color, c_high: Color) -> void:
	blob(st, center, radii, rng, c_low, c_high, 0.28, 6, 4, 0.6)

## Smooth-shaded ellipsoid. Used for leaf masses: the soft normals read as a
## single canopy rather than a pile of hard facets, while the silhouette keeps
## the procedural lumpiness of `blob`.
static func blob_smooth(st: SurfaceTool, center: Vector3, radii: Vector3, rng: RandomNumberGenerator,
		c_low: Color, c_high: Color, jitter: float = 0.16, segs: int = 9, rings: int = 6, tint_a: float = 1.0) -> void:
	var jit: Array[float] = []
	for i in range((rings + 1) * segs):
		jit.append(1.0 + (rng.randf() - 0.5) * 2.0 * jitter)
	var pos: Array[Vector3] = []
	var cols: Array[Color] = []
	var nrms: Array[Vector3] = []
	var safe_r := Vector3(maxf(radii.x, 0.001), maxf(radii.y, 0.001), maxf(radii.z, 0.001))
	for r in range(rings + 1):
		var phi: float = PI * float(r) / float(rings)
		for s in range(segs):
			var theta: float = TAU * float(s) / float(segs)
			var dir: Vector3 = Vector3(sin(phi) * cos(theta), cos(phi), sin(phi) * sin(theta))
			var j: float = 1.0
			if r != 0 and r != rings:
				j = jit[r * segs + s]
			pos.append(center + dir * radii * j)
			nrms.append((dir / safe_r).normalized())
			var col: Color = c_low.lerp(c_high, clampf(dir.y * 0.5 + 0.5, 0.0, 1.0))
			col.a = tint_a
			cols.append(col)
	for r in range(rings):
		for s in range(segs):
			var s2: int = (s + 1) % segs
			var i00: int = r * segs + s
			var i01: int = r * segs + s2
			var i10: int = (r + 1) * segs + s
			var i11: int = (r + 1) * segs + s2
			var n00: Vector3 = nrms[i00]
			var n01: Vector3 = nrms[i01]
			var n10: Vector3 = nrms[i10]
			var n11: Vector3 = nrms[i11]
			tri_core(st, pos[i00], pos[i10], pos[i11], n00, n10, n11, cols[i00], cols[i10], cols[i11], Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
			tri_core(st, pos[i00], pos[i11], pos[i01], n00, n11, n01, cols[i00], cols[i11], cols[i01], Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)

## Cylinder between two arbitrary points - ideal for branches, roots and vines.
static func cylinder_between(st: SurfaceTool, a: Vector3, b: Vector3, r_a: float, r_b: float,
		segs: int = 6, c_a: Color = WHITE, c_b: Color = WHITE, smooth: bool = true) -> void:
	var delta: Vector3 = b - a
	var height: float = delta.length()
	if height < 0.0001:
		return
	var up: Vector3 = delta / height
	var basis := Basis(Quaternion(Vector3.UP, up))
	cylinder(st, Transform3D(basis, a), r_a, r_b, height, segs, c_a, c_b, false, true, smooth)
