# Chunk Streaming Manager
# Loads / unloads terrain chunks around the player. New chunks are built in stages
# with a small per-frame time budget so walking around stays smooth.
extends Node3D
class_name ChunkManager

const FRAME_BUDGET_USEC: int = 5000

var noise: TerrainNoise
var loaded_chunks: Dictionary = {}   # Vector2i -> Chunk
var last_player_chunk: Vector2i = Vector2i(9999, 9999)
var terrain_material: ShaderMaterial
var water: MeshInstance3D
var water_material: ShaderMaterial

static var shared_water_material: ShaderMaterial = null

var _building: Array[Chunk] = []

@export var render_distance: int = Constants.RENDER_DISTANCE

var current_water_level: float = Constants.WATER_LEVEL

func _ready() -> void:
	add_to_group("chunk_manager")
	current_water_level = Constants.WATER_LEVEL
	noise = TerrainNoise.new(GameManager.world_seed)
	_make_materials()
	_make_water()
	# Build the ground around the spawn point immediately, so the player never starts in mid-air.
	var spawn_chunk: Vector2i = _world_to_chunk(Vector3(Constants.SPAWN_XZ.x, 0.0, Constants.SPAWN_XZ.y))
	for x in range(spawn_chunk.x - 1, spawn_chunk.x + 2):
		for z in range(spawn_chunk.y - 1, spawn_chunk.y + 2):
			var c: Chunk = _start_chunk(Vector2i(x, z))
			# Build only terrain + collision synchronously. Trees, rocks and grass
			# continue through the normal frame-budget queue after the player spawns.
			while c.stage == 0:
				c.advance()
	last_player_chunk = spawn_chunk
	_update_chunks(spawn_chunk)
	print("[ChunkManager] Ready - streaming enabled")

func _make_materials() -> void:
	terrain_material = ShaderMaterial.new()
	terrain_material.shader = load("res://shaders/terrain.gdshader")
	terrain_material.set_shader_parameter("water_level", Constants.WATER_LEVEL)
	terrain_material.set_shader_parameter("tide_offset", 0.0)

func _make_water() -> void:
	water_material = ShaderMaterial.new()
	water_material.shader = load("res://shaders/water.gdshader")
	water_material.set_shader_parameter("height_map", noise.build_height_map())
	water_material.set_shader_parameter("map_extent", 1400.0)
	water_material.set_shader_parameter("tide_offset", 0.0)
	shared_water_material = water_material
	water = MeshInstance3D.new()
	water.name = "Water"
	var plane := PlaneMesh.new()
	plane.size = Vector2(1400.0, 1400.0)
	# Dense enough that the bed-depth tide mask interpolates cleanly along coasts.
	plane.subdivide_width = 96
	plane.subdivide_depth = 96
	water.mesh = plane
	water.material_override = water_material
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	water.position = Vector3(0, Constants.WATER_LEVEL, 0)
	add_child(water)

func set_tide_level(level: float) -> void:
	current_water_level = level
	var offset: float = level - Constants.WATER_LEVEL
	if terrain_material:
		terrain_material.set_shader_parameter("tide_offset", offset)
	if water_material:
		water_material.set_shader_parameter("tide_offset", offset)

func _process(_delta: float) -> void:
	var player: Node3D = GameManager.player
	if player == null:
		return

	# Keep the (big) water plane centred under the player, snapped so the world-space waves never swim.
	water.position = Vector3(snappedf(player.global_position.x, 16.0), Constants.WATER_LEVEL, snappedf(player.global_position.z, 16.0))

	var player_chunk: Vector2i = _world_to_chunk(player.global_position)
	if player_chunk != last_player_chunk:
		last_player_chunk = player_chunk
		_update_chunks(player_chunk)

	_pump_builds()

func _pump_builds() -> void:
	if _building.is_empty():
		return
	var t0: int = Time.get_ticks_usec()
	while not _building.is_empty() and Time.get_ticks_usec() - t0 < FRAME_BUDGET_USEC:
		var c: Chunk = _building[0]
		if not is_instance_valid(c):
			_building.pop_front()
			continue
		if c.advance():
			_building.pop_front()

func _world_to_chunk(pos: Vector3) -> Vector2i:
	return Vector2i(
		floori(pos.x / Constants.CHUNK_SIZE),
		floori(pos.z / Constants.CHUNK_SIZE)
	)

func _update_chunks(center: Vector2i) -> void:
	var wanted: Array[Vector2i] = []
	for x in range(center.x - render_distance, center.x + render_distance + 1):
		for z in range(center.y - render_distance, center.y + render_distance + 1):
			var key := Vector2i(x, z)
			if not loaded_chunks.has(key):
				wanted.append(key)
	# Nearest first
	wanted.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return Vector2(a - center).length_squared() < Vector2(b - center).length_squared())
	for key in wanted:
		_start_chunk(key)

	# Unload far chunks (with a 1-chunk hysteresis so crossing a border doesn't thrash)
	var to_remove: Array[Vector2i] = []
	for key in loaded_chunks.keys():
		if absi(key.x - center.x) > render_distance + 1 or absi(key.y - center.y) > render_distance + 1:
			to_remove.append(key)
	for key in to_remove:
		_unload_chunk(key)

func _start_chunk(key: Vector2i) -> Chunk:
	var chunk := Chunk.new()
	chunk.setup(key, noise, terrain_material)
	add_child(chunk)
	loaded_chunks[key] = chunk
	_building.append(chunk)
	EventBus.chunk_loaded.emit(key)
	return chunk

func _unload_chunk(key: Vector2i) -> void:
	if not loaded_chunks.has(key):
		return
	var chunk: Chunk = loaded_chunks[key]
	loaded_chunks.erase(key)
	_building.erase(chunk)
	if is_instance_valid(chunk):
		# MultiMesh vegetation nodes are children of the chunk. Releasing the whole
		# chunk also releases their visibility-range fade/culling instances cleanly.
		chunk.queue_free()


## Rebuild terrain chunks after persistent erosion/deposition changes.
## Uses the normal staged builder; never mutates a live collision mesh in-place.
func refresh_chunks(keys: Array) -> void:
	for value in keys:
		if not (value is Vector2i):
			continue
		var key: Vector2i = value
		if not loaded_chunks.has(key):
			continue
		var old_chunk: Chunk = loaded_chunks[key]
		_building.erase(old_chunk)
		loaded_chunks.erase(key)
		if is_instance_valid(old_chunk):
			old_chunk.queue_free()
		_start_chunk(key)

func regenerate_world(seed_value: int) -> void:
	# Called by a future world-reset/seed-change flow. Clear both loaded and
	# queued chunks so old vegetation fade bounds cannot survive a new world.
	for chunk_value in loaded_chunks.values():
		var chunk: Chunk = chunk_value
		if is_instance_valid(chunk):
			chunk.queue_free()
	loaded_chunks.clear()
	_building.clear()
	GameManager.world_seed = seed_value
	noise = TerrainNoise.new(seed_value)
	last_player_chunk = Vector2i(9999, 9999)
	var player: Node3D = GameManager.player
	var center: Vector2i = _world_to_chunk(player.global_position) if player else _world_to_chunk(Vector3(Constants.SPAWN_XZ.x, 0.0, Constants.SPAWN_XZ.y))
	for x in range(center.x - 1, center.x + 2):
		for z in range(center.y - 1, center.y + 2):
			var spawn_chunk: Chunk = _start_chunk(Vector2i(x, z))
			while spawn_chunk.stage == 0:
				spawn_chunk.advance()
	last_player_chunk = center
	_update_chunks(center)

func get_height(x: float, z: float) -> float:
	return noise.get_height(x, z)
