# Repair + upgrade gear using materials (uses existing equipment slots)
extends Node
class_name GearUpgrade

func _ready() -> void:
	add_to_group("gear_upgrade")

## Repair equipped weapon/armor for gold + materials
func repair_slot(slot: String) -> bool:
	var it: Dictionary = PlayerData.equipment.get(slot, {})
	if it.is_empty():
		EventBus.toast.emit("Nothing equipped in %s" % slot, "warning")
		return false
	var max_dur: float = float(ItemDB.def(str(it["id"])).get("durability", 100.0))
	var cur: float = float(it.get("dur", max_dur))
	if cur >= max_dur * 0.99:
		EventBus.toast.emit("Already in good condition", "info")
		return false
	var cost: int = maxi(int((max_dur - cur) * 0.4), 5)
	if not PlayerData.spend_gold(cost):
		EventBus.toast.emit("Need %d gold to repair" % cost, "warning")
		return false
	it["dur"] = max_dur
	PlayerData.equipment[slot] = it
	PlayerData.equipment_changed.emit()
	EventBus.toast.emit("Repaired %s (%dg)" % [str(ItemDB.def(str(it["id"])).get("name", it["id"])), cost], "info")
	return true

## Upgrade grade by 1 using rare mats
func upgrade_slot(slot: String) -> bool:
	var it: Dictionary = PlayerData.equipment.get(slot, {})
	if it.is_empty():
		EventBus.toast.emit("Nothing equipped", "warning")
		return false
	var g: int = int(it.get("grade", 0))
	if g >= 5:
		EventBus.toast.emit("Already maximum grade", "warning")
		return false
	var need_id := "mana_crystal" if g >= 3 else "iron_ingot"
	var need_n: int = 1 + g
	if PlayerData.count_item(need_id) < need_n:
		EventBus.toast.emit("Need %d %s" % [need_n, need_id], "warning")
		return false
	if not PlayerData.spend_gold(30 + g * 25):
		EventBus.toast.emit("Not enough gold", "warning")
		return false
	PlayerData.remove_item(need_id, need_n)
	it["grade"] = g + 1
	PlayerData.equipment[slot] = it
	PlayerData.equipment_changed.emit()
	EventBus.toast.emit("Upgraded to %s!" % str(ItemDB.grade_info(g + 1).get("name", "higher")), "levelup")
	var skills: Variant = GameManager.player.get("skills") if GameManager.player else null
	if skills != null and skills.has_method("train"):
		skills.call("train", "smithing", 0.45)
	return true
