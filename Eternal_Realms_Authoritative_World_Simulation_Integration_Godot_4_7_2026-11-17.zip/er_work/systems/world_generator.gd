# World root - now just hosts the ChunkManager + settlements
# Old single-mesh generation replaced by streaming chunks
extends Node3D
class_name WorldGenerator

func _ready() -> void:
	var manager = ChunkManager.new()
	manager.name = "ChunkManager"
	add_child(manager)
	print("[WorldGenerator] Chunk streaming active")
