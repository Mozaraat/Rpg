# Living ecosystem: a food web whose populations breed, mature, die, mutate rare
# variants and occasionally give rise to new species. Visuals use primitives only.
extends Node

const SAVE_PATH := "user://living_ecosystem.json"
const TICK := 20.0
const MAX_SAPLINGS := 60
const MAX_JUVENILES := 6
const JUVENILE_TICKS := 4
const SPECIES := {
	"soil_microbes": {"group": "micro", "cap": 5000.0, "rate": 0.30, "food": "", "rare": "Glowspore Bloom", "rare_chance": 0.002},
	"plankton": {"group": "micro", "cap": 4000.0, "rate": 0.28, "food": "", "rare": "Starlight Plankton", "rare_chance": 0.002},
	"bees": {"group": "insect", "cap": 300.0, "rate": 0.18, "food": "soil_microbes", "rare": "Gilded Bee", "rare_chance": 0.01},
	"fireflies": {"group": "insect", "cap": 240.0, "rate": 0.16, "food": "soil_microbes", "rare": "Azure Firefly", "rare_chance": 0.012},
	"songbirds": {"group": "bird", "cap": 60.0, "rate": 0.08, "food": "bees", "rare": "Crimson Songbird", "rare_chance": 0.02},
	"trout": {"group": "fish", "cap": 120.0, "rate": 0.10, "food": "plankton", "rare": "Golden Trout", "rare_chance": 0.015},
	"rabbit": {"group": "creature", "cap": 40.0, "rate": 0.12, "food": "", "rare": "Snowcoat Rabbit", "rare_chance": 0.03, "tint": Color(0.95, 0.95, 0.97)},
	"deer": {"group": "creature", "cap": 24.0, "rate": 0.06, "food": "", "rare": "White Stag", "rare_chance": 0.02, "tint": Color(0.92, 0.92, 0.9)},
	"boar": {"group": "creature", "cap": 20.0, "rate": 0.07, "food": "", "rare": "Ironhide Boar", "rare_chance": 0.02, "tint": Color(0.3, 0.32, 0.36)},
	"wolf": {"group": "creature", "cap": 10.0, "rate": 0.05, "food": "deer", "rare": "Silver Wolf", "rare_chance": 0.03, "tint": Color(0.8, 0.84, 0.9)},
}

# Biome-specific fauna. Numeric biome ids match TerrainNoise.Biome.
# Populations are coarse regional cohorts; visual animals are only spawned near players.
const REGIONAL_SPECIES := {
	"rabbit": {"biomes": [2, 3, 4, 9, 13, 14, 15, 16], "cap": 52.0, "birth": 0.22, "max_age": 5.0, "strength": 1.0, "prey": "", "predator": false},
	"red_deer": {"biomes": [2, 3, 4, 9, 13, 16], "cap": 34.0, "birth": 0.10, "max_age": 14.0, "strength": 1.4, "prey": "", "predator": false},
	"wild_boar": {"biomes": [2, 3, 7, 9, 11, 12, 16], "cap": 26.0, "birth": 0.13, "max_age": 10.0, "strength": 1.8, "prey": "", "predator": false},
	"red_fox": {"biomes": [2, 3, 4, 8, 9, 13, 14, 16], "cap": 18.0, "birth": 0.09, "max_age": 9.0, "strength": 2.0, "prey": "rabbit", "predator": true},
	"grey_wolf": {"biomes": [3, 4, 5, 13, 14], "cap": 12.0, "birth": 0.08, "max_age": 11.0, "strength": 3.4, "prey": "red_deer", "predator": true},
	"brown_bear": {"biomes": [3, 4, 5, 7, 11, 13], "cap": 7.0, "birth": 0.045, "max_age": 24.0, "strength": 6.0, "prey": "wild_boar", "predator": true},
	"mountain_goat": {"biomes": [4, 5, 6], "cap": 22.0, "birth": 0.085, "max_age": 13.0, "strength": 2.8, "prey": "", "predator": false},
	"snow_leopard": {"biomes": [5, 6, 14], "cap": 5.0, "birth": 0.035, "max_age": 17.0, "strength": 5.2, "prey": "mountain_goat", "predator": true},
	"arctic_hare": {"biomes": [6, 14], "cap": 38.0, "birth": 0.19, "max_age": 4.0, "strength": 0.9, "prey": "", "predator": false},
	"snow_fox": {"biomes": [6, 13, 14], "cap": 10.0, "birth": 0.075, "max_age": 9.0, "strength": 1.8, "prey": "arctic_hare", "predator": true},
	"elk": {"biomes": [3, 4, 13], "cap": 20.0, "birth": 0.07, "max_age": 18.0, "strength": 3.0, "prey": "", "predator": false},
	"lynx": {"biomes": [3, 4, 13, 14], "cap": 8.0, "birth": 0.055, "max_age": 13.0, "strength": 2.7, "prey": "rabbit", "predator": true},
	"marsh_deer": {"biomes": [7, 11, 12], "cap": 18.0, "birth": 0.085, "max_age": 12.0, "strength": 1.5, "prey": "", "predator": false},
	"marsh_crocodile": {"biomes": [7, 11, 12], "cap": 9.0, "birth": 0.06, "max_age": 45.0, "strength": 5.5, "prey": "marsh_deer", "predator": true},
	"jaguar": {"biomes": [11, 12], "cap": 7.0, "birth": 0.045, "max_age": 16.0, "strength": 5.0, "prey": "wild_boar", "predator": true},
	"tapir": {"biomes": [11, 12], "cap": 16.0, "birth": 0.055, "max_age": 25.0, "strength": 2.1, "prey": "", "predator": false},
	"monkey": {"biomes": [11, 12], "cap": 40.0, "birth": 0.15, "max_age": 20.0, "strength": 1.1, "prey": "", "predator": false},
	"desert_gazelle": {"biomes": [8, 15, 16], "cap": 32.0, "birth": 0.12, "max_age": 11.0, "strength": 1.6, "prey": "", "predator": false},
	"sand_cat": {"biomes": [8, 15], "cap": 8.0, "birth": 0.07, "max_age": 10.0, "strength": 2.0, "prey": "desert_gazelle", "predator": true},
	"hyena": {"biomes": [8, 15], "cap": 11.0, "birth": 0.09, "max_age": 13.0, "strength": 3.1, "prey": "desert_gazelle", "predator": true},
	"ash_goat": {"biomes": [10], "cap": 14.0, "birth": 0.06, "max_age": 12.0, "strength": 2.6, "prey": "", "predator": false},
	"ember_lizard": {"biomes": [10], "cap": 45.0, "birth": 0.17, "max_age": 8.0, "strength": 1.2, "prey": "", "predator": false},
	"vulture": {"biomes": [8, 10, 15], "cap": 13.0, "birth": 0.055, "max_age": 28.0, "strength": 1.7, "prey": "", "predator": false},
	"shorebird": {"biomes": [1, 2, 7, 16], "cap": 65.0, "birth": 0.16, "max_age": 12.0, "strength": 0.8, "prey": "", "predator": false},
	"trout": {"biomes": [0, 2, 3, 7, 11, 12, 13, 16], "cap": 95.0, "birth": 0.16, "max_age": 9.0, "strength": 0.9, "prey": "", "predator": false},
	"coastal_seal": {"biomes": [0, 1], "cap": 16.0, "birth": 0.07, "max_age": 30.0, "strength": 2.8, "prey": "trout", "predator": true},
	"river_otter": {"biomes": [2, 3, 7, 11, 12, 13, 16], "cap": 14.0, "birth": 0.09, "max_age": 16.0, "strength": 1.7, "prey": "trout", "predator": true},
	"reef_shark": {"biomes": [0], "cap": 5.0, "birth": 0.035, "max_age": 40.0, "strength": 7.0, "prey": "coastal_seal", "predator": true},
	"marsh_heron": {"biomes": [7, 11, 12], "cap": 22.0, "birth": 0.08, "max_age": 18.0, "strength": 1.1, "prey": "", "predator": false},
	"tundra_muskox": {"biomes": [6, 14], "cap": 15.0, "birth": 0.045, "max_age": 22.0, "strength": 4.1, "prey": "", "predator": false},
	"savanna_elephant": {"biomes": [15], "cap": 8.0, "birth": 0.025, "max_age": 65.0, "strength": 8.0, "prey": "", "predator": false},
	"savanna_lion": {"biomes": [15], "cap": 7.0, "birth": 0.05, "max_age": 18.0, "strength": 5.8, "prey": "desert_gazelle", "predator": true}
}

# New species appear only once their ecological niche has been sustained.
const EMERGENT := {
	"emberwing_moth": {"name": "Emberwing Moth", "group": "insect", "cap": 120.0, "rate": 0.14, "food": "fireflies", "rare": "Phoenix Moth", "rare_chance": 0.01, "needs": {"fireflies": 180.0, "soil_microbes": 2500.0}},
	"mirelight_eel": {"name": "Mirelight Eel", "group": "fish", "cap": 40.0, "rate": 0.06, "food": "plankton", "rare": "Abyssal Eel", "rare_chance": 0.02, "needs": {"plankton": 2100.0, "trout": 80.0}},
}

var _pop: Dictionary = {}
var _rare_seen: Dictionary = {}
var _emerged: Dictionary = {}
var _seen_carcasses: Dictionary = {}
var _clock := 0.0
var _t := 0.0
var _terrain: TerrainNoise
var _swarm: MultiMeshInstance3D
var _plankton: MultiMeshInstance3D
var _swarm_points: Array[Vector3] = []
var _plankton_points: Array[Vector3] = []
var _migration_season: String = ""
var _regional_populations: Dictionary = {}
var _regional_tick: int = 0
var _regional_backend_revision: int = 0
var _regional_backend_save_pending: bool = false
var _regional_backend_restore_pending: bool = false
var _regional_worker: Thread = Thread.new()
var _regional_worker_executor: RefCounted
var _regional_worker_running: bool = false
var _regional_worker_result: Dictionary = {}
var _pending_regional_hunts: Dictionary = {}

func _ready() -> void:
	add_to_group("living_ecosystem")
	_regional_worker_executor = preload("res://systems/regional_ecology_worker.gd").new()
	_terrain = TerrainNoise.new(GameManager.world_seed)
	for id in SPECIES.keys():
		var cap := float(SPECIES[id].cap)
		_pop[id] = {"juv": cap * 0.1, "adult": cap * 0.4, "rare": 0}
	_load()
	_initialize_regional_populations()
	_regional_backend_restore_pending = WorldDeploymentGuard.production_mode and MMORPGNetwork.is_authority() and CentralBackend.is_configured()
	call_deferred("_restore_regional_population_state")
	_swarm = _make_points(64, 0.05)
	_plankton = _make_points(48, 0.035)

func _process(delta: float) -> void:
	_poll_regional_worker()
	var simulation_active := GameManager.current_state == GameManager.GameState.PLAYING \
		and get_tree().get_first_node_in_group("dungeon_active") == null
	var visuals_active := simulation_active and GameManager.player != null
	_swarm.visible = visuals_active
	_plankton.visible = visuals_active
	if not simulation_active:
		return
	_t += delta
	if visuals_active:
		_animate_points()
	_clock += delta
	if _clock < TICK:
		return
	_clock = 0.0
	if MMORPGNetwork.is_authority():
		if visuals_active:
			_grow_juveniles()
		simulate_tick()
		_update_seasonal_migration()
		_start_regional_worker()
	if visuals_active:
		_spread_trees()
		_place_points()

func simulate_tick() -> void:
	var trees := float(get_tree().get_nodes_in_group("growing_tree").size())
	var plant_cover := clampf(0.6 + trees / 60.0, 0.6, 1.4)
	var habitat_position := GameManager.player.global_position if GameManager.player != null else Vector3.ZERO
	var water_state := HydrologySystem.get_water_state(habitat_position)
	var habitat_moisture := float(water_state.get("soil_saturation", 0.25))
	var habitat_flow := float(water_state.get("discharge_m3_s", 0.0))
	var climate := ClimateSystem.sample_at(habitat_position)
	var habitat_temperature := float(climate.get("temperature_c", 18.0))
	var decomposed := _consume_carcasses()
	for id in _pop.keys():
		var def := species_def(id)
		var p: Dictionary = _pop[id]
		var cap := float(def.cap)
		var food := str(def.food)
		if str(def.group) == "fish":
			cap *= clampf((habitat_flow + habitat_moisture * 0.5) * 1.8, 0.12, 1.5)
		elif str(def.group) == "creature":
			cap *= clampf(0.45 + habitat_moisture * 0.85, 0.25, 1.25)
			if habitat_temperature < -8.0 or habitat_temperature > 36.0:
				cap *= 0.72
		if def.group == "micro":
			cap *= plant_cover + decomposed * 0.02
		elif food == "":
			cap *= plant_cover
		else:
			var food_cap := float(species_def(food).cap)
			cap *= clampf(float(_pop[food].adult) / (food_cap * 0.5), 0.1, 1.0)
		var adults := float(p.adult)
		var juveniles := float(p.juv)
		var total := adults + juveniles
		var seasonal_breeding := 0.55 if habitat_temperature < 2.0 or habitat_temperature > 33.0 else 1.0
		var births := adults * float(def.rate) * seasonal_breeding * maxf(0.0, 1.0 - total / maxf(cap, 1.0))
		var matured := juveniles * 0.25
		var deaths := adults * 0.02 + maxf(0.0, total - cap) * 0.1
		p.juv = maxf(0.0, juveniles + births - matured - juveniles * 0.03)
		p.adult = maxf(0.0, adults + matured - deaths)
		if food != "":
			_pop[food].adult = maxf(0.0, float(_pop[food].adult) - adults * 0.04)
		if births >= 1.0 and randf() < minf(0.5, float(def.rare_chance) * minf(births, 20.0)):
			p.rare = int(p.rare) + 1
			_announce_rare(id, str(def.rare))
		p.rare = mini(int(p.rare), int(p.adult))
		if id in ["rabbit", "deer", "boar", "wolf"] and births >= 0.5:
			_birth_visible_young(id, def)
	_check_emergence()


## Coarse populations exist for every authored region, whether or not a player
## has loaded its terrain. These are ecological counts, not spawned NPC instances.
func _initialize_regional_populations() -> void:
	var regions := _terrain.get_region_anchor_data()
	for region in regions:
		var region_id := str(region.get("name", ""))
		if region_id.is_empty():
			continue
		var center: Vector2 = region.get("center", Vector2.ZERO)
		var climate := ClimateSystem.sample_at(Vector3(center.x, 0.0, center.y))
		var moisture := float(ClimateSystem.humidity_at(Vector3(center.x, 0.0, center.y))) if ClimateSystem else 0.5
		var temperature := float(climate.get("temperature_c", 17.0))
		var biome_id := int(_terrain.get_biome(center.x, center.y, _terrain.get_height(center.x, center.y)))
		if _regional_populations.has(region_id):
			var existing_region: Dictionary = _regional_populations[region_id]
			var existing_species: Dictionary = existing_region.get("species", {})
			for old_id in ["deer", "boar", "wolf"]:
				var new_id := {"deer": "red_deer", "boar": "wild_boar", "wolf": "grey_wolf"}[old_id]
				if existing_species.has(old_id) and not existing_species.has(new_id):
					existing_species[new_id] = existing_species[old_id]
				existing_species.erase(old_id)
			for species_id in REGIONAL_SPECIES.keys():
				var existing_def: Dictionary = REGIONAL_SPECIES[species_id]
				if biome_id not in existing_def.biomes or existing_species.has(species_id):
					continue
				var existing_capacity := float(existing_def.cap) * clampf(0.55 + moisture * 0.35, 0.3, 1.0)
				existing_species[species_id] = {"adults": existing_capacity * 0.23, "juveniles": existing_capacity * 0.09, "carrying_capacity": existing_capacity, "mean_age": float(existing_def.max_age) * 0.35, "mean_strength": float(existing_def.strength) * 0.55, "generation": 1, "hunting_pressure": 0.0}
			existing_region["center_x"] = center.x
			existing_region["center_z"] = center.y
			existing_region["biome_id"] = biome_id
			existing_region["temperature_c"] = temperature
			existing_region["moisture"] = moisture
			existing_region["species"] = existing_species
			_regional_populations[region_id] = existing_region
			continue
		var species_state := {}
		for species_id in REGIONAL_SPECIES.keys():
			var def: Dictionary = REGIONAL_SPECIES[species_id]
			if biome_id not in def.biomes:
				continue
			var thermal_fit := clampf(1.0 - absf(temperature - 16.0) / 48.0, 0.25, 1.0)
			var moisture_fit := clampf(0.55 + moisture * 0.35, 0.3, 1.0)
			var capacity := float(def.cap) * thermal_fit * moisture_fit
			var initial_total := capacity * 0.32
			species_state[species_id] = {
				"adults": initial_total * 0.72,
				"juveniles": initial_total * 0.28,
				"carrying_capacity": capacity,
				"mean_age": float(def.max_age) * 0.35,
				"mean_strength": float(def.strength) * 0.55,
				"generation": 1,
				"hunting_pressure": 0.0
			}
		_regional_populations[region_id] = {
			"center_x": center.x, "center_z": center.y, "biome_id": biome_id,
			"temperature_c": temperature, "moisture": moisture,
			"species": species_state, "last_simulated_tick": _regional_tick
		}
	# Fill the explored world envelope with coarse biome cells, including uncharted
	# terrain that has no hand-authored region name. The grid is seeded by the same
	# TerrainNoise field used by streamed chunks, so biome boundaries stay coherent.
	for gz in range(-3, 4):
		for gx in range(-3, 4):
			var point := Vector2(float(gx * 240), float(gz * 240))
			var overlaps_authored := false
			for authored in regions:
				var authored_center: Vector2 = authored.get("center", Vector2.ZERO)
				if authored_center.distance_to(point) < 135.0:
					overlaps_authored = true
					break
			if overlaps_authored:
				continue
			var grid_id := "wilds_%d_%d" % [gx, gz]
			if _regional_populations.has(grid_id):
				continue
			var height := _terrain.get_height(point.x, point.y)
			var biome_id := int(_terrain.get_biome(point.x, point.y, height))
			var climate := ClimateSystem.sample_at(Vector3(point.x, 0.0, point.y))
			var moisture := float(ClimateSystem.humidity_at(Vector3(point.x, 0.0, point.y))) if ClimateSystem else 0.5
			var species_state := {}
			for species_id in REGIONAL_SPECIES.keys():
				var def: Dictionary = REGIONAL_SPECIES[species_id]
				if biome_id not in def.biomes:
					continue
				var thermal_fit := clampf(1.0 - absf(float(climate.get("temperature_c", 16.0)) - 16.0) / 48.0, 0.25, 1.0)
				var capacity := float(def.cap) * thermal_fit * clampf(0.55 + moisture * 0.35, 0.3, 1.0)
				species_state[species_id] = {"adults": capacity * 0.23, "juveniles": capacity * 0.09, "carrying_capacity": capacity, "mean_age": float(def.max_age) * 0.35, "mean_strength": float(def.strength) * 0.55, "generation": 1, "hunting_pressure": 0.0}
			_regional_populations[grid_id] = {"center_x": point.x, "center_z": point.y, "biome_id": biome_id, "temperature_c": float(climate.get("temperature_c", 16.0)), "moisture": moisture, "species": species_state, "last_simulated_tick": _regional_tick}

## Run all unloaded-region ecology on a worker thread. The worker receives only
## copied dictionaries and primitive values; it never touches SceneTree, Nodes,
## Resources, rendering, physics or shared live state.
func _start_regional_worker() -> void:
	if _regional_worker_running or _regional_backend_restore_pending or _regional_populations.is_empty():
		return
	var snapshot := {
		"regions": _regional_populations.duplicate(true),
		"species_defs": REGIONAL_SPECIES.duplicate(true),
		"tick": _regional_tick + 1,
		"season": ClimateSystem.get_season_name()
	}
	var err := _regional_worker.start(Callable(_regional_worker_executor, "simulate").bind(snapshot))
	if err == OK:
		_regional_worker_running = true
	else:
		push_warning("Regional ecology worker could not start; retaining previous regional snapshot")
		_apply_pending_regional_hunts()
		_save()

func _poll_regional_worker() -> void:
	if not _regional_worker_running or _regional_worker.is_alive():
		return
	_regional_worker_result = _regional_worker.wait_to_finish()
	_regional_worker_running = false
	if _regional_worker_result is Dictionary and not _regional_worker_result.is_empty():
		_regional_populations = _regional_worker_result.get("regions", _regional_populations)
		_regional_tick = int(_regional_worker_result.get("tick", _regional_tick))
		_apply_pending_regional_hunts()
		_apply_wildlife_settlement_conflicts()
		_save()


## Register kills from the loaded world against the appropriate regional cohort.
func _record_regional_hunt(position: Vector3, species_id: String) -> void:
	var aliases := {"deer": "red_deer", "wolf": "grey_wolf", "boar": "wild_boar", "rabbit": "rabbit"}
	species_id = str(aliases.get(species_id, species_id))
	var best_id := ""
	var best_distance := INF
	for region_id in _regional_populations.keys():
		var region: Dictionary = _regional_populations[region_id]
		var species_state: Dictionary = region.get("species", {})
		if not species_state.has(species_id):
			continue
		var distance := Vector2(position.x, position.z).distance_to(Vector2(float(region.get("center_x", 0.0)), float(region.get("center_z", 0.0))))
		if distance < best_distance:
			best_distance = distance
			best_id = str(region_id)
	if best_id.is_empty():
		return
	if not _pending_regional_hunts.has(best_id):
		_pending_regional_hunts[best_id] = {}
	var hunts: Dictionary = _pending_regional_hunts[best_id]
	hunts[species_id] = float(hunts.get(species_id, 0.0)) + 1.0
	_pending_regional_hunts[best_id] = hunts

func _apply_pending_regional_hunts() -> void:
	for region_id in _pending_regional_hunts.keys():
		if not _regional_populations.has(region_id):
			continue
		var region: Dictionary = _regional_populations[region_id]
		var species_state: Dictionary = region.get("species", {})
		var hunts: Dictionary = _pending_regional_hunts[region_id]
		for species_id in hunts.keys():
			if not species_state.has(species_id):
				continue
			var pop: Dictionary = species_state[species_id]
			pop["hunting_pressure"] = float(pop.get("hunting_pressure", 0.0)) + float(hunts[species_id])
			species_state[species_id] = pop
		region["species"] = species_state
		_regional_populations[region_id] = region
	_pending_regional_hunts.clear()

## Turn regional predator pressure into visible consequences for farms and settlements.
## This runs on the main thread after the worker returns; the worker never touches Nodes.
func _apply_wildlife_settlement_conflicts() -> void:
	var settlement_system := get_tree().get_first_node_in_group("settlement_growth")
	if settlement_system != null and settlement_system.get("settlements") is Dictionary:
		var settlements: Dictionary = settlement_system.get("settlements")
		for settlement_id in settlements.keys():
			var settlement: Dictionary = settlements[settlement_id]
			var center: Vector2 = settlement.get("center", Vector2.ZERO)
			var region_id := _nearest_regional_id(Vector3(center.x, 0.0, center.y))
			if region_id.is_empty():
				continue
			var region: Dictionary = _regional_populations[region_id]
			var pressure := clampf(float(region.get("predator_pressure", 0.0)), 0.0, 1.5)
			var population := maxi(1, int(settlement.get("population", 1)))
			var level := int(settlement.get("level", 0))
			# Settlements organise hunters and guards as they grow. Defenders reduce
			# losses, but high predator pressure still requires active hunting.
			var hunter_strength := float(settlement.get("wildlife_hunters", 0.0))
			var guard_strength := float(settlement.get("wildlife_guards", 0.0))
			hunter_strength = maxf(hunter_strength, population * (0.025 + float(level) * 0.012))
			guard_strength = maxf(guard_strength, population * (0.035 + float(level) * 0.018))
			settlement["wildlife_hunters"] = hunter_strength
			settlement["wildlife_guards"] = guard_strength
			settlement["wildlife_threat"] = pressure
			var raid_chance := clampf((pressure - 0.12) * 0.16 - guard_strength * 0.012, 0.0, 0.10)
			if pressure > 0.18 and randf() < raid_chance:
				var defended := guard_strength + hunter_strength * 0.65
				var damage := clampf(pressure * 0.22 - defended * 0.012, 0.01, 0.16)
				settlement["livestock_losses"] = float(settlement.get("livestock_losses", 0.0)) + damage
				settlement["farm_damage"] = clampf(float(settlement.get("farm_damage", 0.0)) + damage * 0.7, 0.0, 1.0)
				settlement["wildlife_incidents"] = int(settlement.get("wildlife_incidents", 0)) + 1
				if damage > 0.07:
					settlement["progress"] = maxf(0.0, float(settlement.get("progress", 0.0)) - damage * 5.0)
				EventBus.activity.emit("Wild predators raided the outskirts of %s; hunters and guards drove them back" % str(settlement.get("name", settlement_id)), "world")
				EventBus.toast.emit("Wildlife threat near %s. Organise hunters and strengthen defences." % str(settlement.get("name", settlement_id)), "warning")
			settlements[settlement_id] = settlement
		settlement_system.set("settlements", settlements)
	# Player farms and livestock are also exposed when their location lies in a
	# high-pressure region. Damage is gradual and persisted in PlayerData.
	var farms: Array = PlayerData.stats.get("farm_plots", [])
	var farm_changed := false
	for plot in farms:
		if not plot is Dictionary or str(plot.get("seed", "")).is_empty():
			continue
		var pos := Vector3(float(plot.get("x", 0.0)), float(plot.get("y", 0.0)), float(plot.get("z", 0.0)))
		var region_id := _nearest_regional_id(pos)
		if region_id.is_empty():
			continue
		var pressure := float(_regional_populations[region_id].get("predator_pressure", 0.0))
		if pressure > 0.28 and randf() < clampf((pressure - 0.2) * 0.035, 0.0, 0.025):
			plot["wildlife_damage"] = clampf(float(plot.get("wildlife_damage", 0.0)) + 0.12, 0.0, 1.0)
			plot["growth"] = maxf(0.0, float(plot.get("growth", 0.0)) - 0.18)
			farm_changed = true
	if farm_changed:
		PlayerData.stats["farm_plots"] = farms.duplicate(true)
		var farming := get_tree().get_first_node_in_group("farming_system")
		if farming != null and farming.has_method("_save_state"):
			farming.call("_save_state")
		if farming != null and farming.has_method("_rebuild_visuals"):
			farming.call("_rebuild_visuals")
	var husbandry := get_tree().get_first_node_in_group("animal_husbandry")
	if husbandry != null and husbandry.get("pens") is Array:
		var pens: Array = husbandry.get("pens")
		var livestock_changed := false
		var lost_animals: Array[int] = []
		for animal_index in range(pens.size()):
			var animal: Dictionary = pens[animal_index]
			var animal_pos := Vector3(float(animal.get("x", 0.0)), float(animal.get("y", 0.0)), float(animal.get("z", 0.0)))
			var animal_region := _nearest_regional_id(animal_pos)
			if animal_region.is_empty():
				continue
			var animal_pressure := float(_regional_populations[animal_region].get("predator_pressure", 0.0))
			if animal_pressure > 0.3 and randf() < clampf((animal_pressure - 0.25) * 0.025, 0.0, 0.02):
				animal["needs"] = minf(100.0, float(animal.get("needs", 50.0)) + 8.0)
				animal["threatened"] = true
				if randf() < clampf((animal_pressure - 0.3) * 0.003, 0.0, 0.006):
					lost_animals.append(animal_index)
				livestock_changed = true
		for lost_index in lost_animals:
			var lost: Dictionary = pens[lost_index]
			EventBus.activity.emit("A predator killed %s outside its enclosure" % str(lost.get("name", "livestock animal")), "world")
		lost_animals.reverse()
		for lost_index in lost_animals:
			pens.remove_at(lost_index)
		if livestock_changed:
			husbandry.set("pens", pens)
			PlayerData.stats["livestock"] = pens.duplicate(true)

## Settlement leaders can invest labour into permanent hunter patrols and guards.
## More hunters suppress nearby predator pressure; guards reduce raid damage.
func organise_settlement_wildlife_defence(settlement_id: String, hunters: int, guards: int) -> bool:
	var settlement_system := get_tree().get_first_node_in_group("settlement_growth")
	if settlement_system == null or not (settlement_system.get("settlements") is Dictionary):
		return false
	var settlements: Dictionary = settlement_system.get("settlements")
	if not settlements.has(settlement_id):
		return false
	var settlement: Dictionary = settlements[settlement_id]
	var population := maxi(1, int(settlement.get("population", 1)))
	var assigned := maxi(0, hunters) + maxi(0, guards)
	if assigned > population:
		return false
	settlement["wildlife_hunters"] = maxi(0, hunters)
	settlement["wildlife_guards"] = maxi(0, guards)
	settlement["wildlife_defence_assigned"] = assigned
	settlements[settlement_id] = settlement
	settlement_system.set("settlements", settlements)
	return true

func _nearest_regional_id(position: Vector3) -> String:
	var best_id := ""
	var best_distance := INF
	for region_id in _regional_populations.keys():
		var region: Dictionary = _regional_populations[region_id]
		var distance := Vector2(position.x, position.z).distance_to(Vector2(float(region.get("center_x", 0.0)), float(region.get("center_z", 0.0))))
		if distance < best_distance:
			best_distance = distance
			best_id = str(region_id)
	return best_id

func get_regional_population_report() -> Dictionary:
	return _regional_populations.duplicate(true)

func get_wildlife_pressure_at(position: Vector3) -> float:
	var best_pressure := 0.0
	var best_distance := INF
	for region_id in _regional_populations.keys():
		var region: Dictionary = _regional_populations[region_id]
		var distance := Vector2(position.x, position.z).distance_to(Vector2(float(region.get("center_x", 0.0)), float(region.get("center_z", 0.0))))
		if distance < best_distance:
			best_distance = distance
			best_pressure = float(region.get("wildlife_pressure", 0.0))
	return clampf(best_pressure, 0.0, 1.0)

func _update_seasonal_migration() -> void:
	var season := ClimateSystem.get_season_name()
	if season == _migration_season:
		return
	_migration_season = season
	for animal in get_tree().get_nodes_in_group("critter"):
		if not animal is Critter or animal._carcass or animal.kind in ["chicken", "wolf", "grey_wolf", "red_fox", "snow_fox", "lynx", "jaguar", "snow_leopard", "hyena", "sand_cat", "savanna_lion", "vulture"]:
			continue
		var origin: Vector3 = animal.global_position
		var best := origin
		var best_score := -INF
		# Search a broad 1.5 km seasonal range. Water, forage moisture and temperature
		# determine the destination; seeded offsets keep the herd direction stable.
		var seed_value := int(hash(Vector2i(roundi(origin.x / 96.0), roundi(origin.z / 96.0))))
		var rng := RandomNumberGenerator.new()
		rng.seed = abs(seed_value + int(season.hash()))
		for i in range(18):
			var candidate := origin + Vector3(rng.randf_range(-750.0, 750.0), 0.0, rng.randf_range(-750.0, 750.0))
			var climate := ClimateSystem.sample_at(candidate)
			var water := HydrologySystem.get_water_state(candidate)
			var thermal := 1.0 - clampf(absf(float(climate.temperature_c) - 17.0) / 35.0, 0.0, 1.0)
			var moisture := clampf(float(water.get("soil_saturation", 0.25)) * 1.4, 0.0, 1.0)
			var score := thermal * 0.55 + moisture * 0.45 - origin.distance_to(candidate) / 5000.0
			if score > best_score:
				best_score = score
				best = candidate
		if best.distance_to(origin) > 90.0:
			best.y = _terrain.get_height(best.x, best.z)
			animal.set_meta("seasonal_migration_target", best)

func species_def(id: String) -> Dictionary:
	return SPECIES[id] if SPECIES.has(id) else EMERGENT.get(id, {})

func get_report() -> Dictionary:
	var result := {}
	for id in _pop.keys():
		result[id] = {"adults": int(_pop[id].adult), "young": int(_pop[id].juv), "rare": int(_pop[id].rare), "rare_name": str(species_def(id).rare)}
	return {"species": result, "rare_discovered": _rare_seen.keys(), "emerged": _emerged.keys()}

func _consume_carcasses() -> int:
	var fresh := 0
	var live := {}
	for node in get_tree().get_nodes_in_group("wildlife_carcass"):
		var key := node.get_instance_id()
		live[key] = true
		if _seen_carcasses.has(key):
			continue
		fresh += 1
		var kind := str(node.get_meta("carcass_species", ""))
		if node is Node3D:
			_record_regional_hunt((node as Node3D).global_position, kind)
		if _pop.has(kind):
			_pop[kind].adult = maxf(0.0, float(_pop[kind].adult) - 1.0)
	_seen_carcasses = live
	return fresh + live.size()

func _check_emergence() -> void:
	for id in EMERGENT.keys():
		if _emerged.has(id):
			continue
		var ok := true
		var needs: Dictionary = EMERGENT[id].needs
		for need in needs.keys():
			if float(_pop[need].adult) < float(needs[need]):
				ok = false
		if ok:
			_emerged[id] = true
			_pop[id] = {"juv": 4.0, "adult": 2.0, "rare": 0}
			var msg := "A new species has arisen in Elyndor: the %s." % str(EMERGENT[id].name)
			EventBus.toast.emit(msg, "levelup")
			EventBus.activity.emit(msg, "journal")

func _announce_rare(id: String, rare_name: String) -> void:
	if _rare_seen.has(id):
		return
	_rare_seen[id] = true
	EventBus.activity.emit("Rare variant born: %s" % rare_name, "journal")

# Young are born beside an adult of their kind near the player, then grow up.
func _birth_visible_young(kind: String, def: Dictionary) -> void:
	var player: Node3D = GameManager.player
	if player == null:
		return
	if get_tree().get_nodes_in_group("eco_juvenile").size() >= MAX_JUVENILES:
		return
	for node in get_tree().get_nodes_in_group("critter"):
		if not node is Critter or node.kind != kind or node.is_in_group("eco_juvenile"):
			continue
		if node.global_position.distance_to(player.global_position) > 70.0:
			continue
		var pos: Vector3 = node.global_position + Vector3(randf_range(-1.5, 1.5), 0.0, randf_range(-1.5, 1.5))
		var young := Critter.new()
		young.kind = kind
		young.position = Vector3(pos.x, _terrain.get_height(pos.x, pos.z) + 0.12, pos.z)
		young.add_to_group("eco_juvenile")
		young.add_to_group("elyndor_spawned_wildlife")
		young.set_meta("eco_age", 0)
		node.get_parent().add_child(young)
		young.set_meta("eco_adult_scale", young._model.scale)
		young._model.scale *= 0.5
		if randf() < float(def.rare_chance) * 4.0:
			_make_rare(young, def)
		return

func _make_rare(animal: Critter, def: Dictionary) -> void:
	animal.set_meta("rare_variant", str(def.rare))
	for mesh in animal._model.find_children("*", "MeshInstance3D", true, false):
		var mat: Material = (mesh as MeshInstance3D).material_override
		if mat is StandardMaterial3D:
			var tinted := (mat as StandardMaterial3D).duplicate() as StandardMaterial3D
			tinted.albedo_color = (def.tint as Color).lerp(tinted.albedo_color, 0.25)
			(mesh as MeshInstance3D).material_override = tinted
	var label := Label3D.new()
	label.text = str(def.rare)
	label.font_size = 18
	label.outline_size = 5
	label.modulate = Color(1.0, 0.85, 0.4)
	label.position.y = 1.4
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	animal.add_child(label)
	_pop[animal.kind].rare = int(_pop[animal.kind].rare) + 1
	_announce_rare(animal.kind, str(def.rare))

func _grow_juveniles() -> void:
	for animal in get_tree().get_nodes_in_group("critter"):
		if not animal is Critter or animal._carcass:
			continue
		animal.advance_ecological_age()
	for young in get_tree().get_nodes_in_group("eco_juvenile"):
		if not young is Critter or young._carcass:
			continue
		var age := int(young.get_meta("eco_age", 0)) + 1
		young.set_meta("eco_age", age)
		var adult_scale: Vector3 = young.get_meta("eco_adult_scale", Vector3.ONE)
		young._model.scale = adult_scale * lerpf(0.5, 1.0, minf(1.0, float(age) / JUVENILE_TICKS))
		if age >= JUVENILE_TICKS:
			young.remove_from_group("eco_juvenile")


func _breed_visible_wildlife() -> void:
	if get_tree().get_nodes_in_group("eco_juvenile").size() >= MAX_JUVENILES:
		return
	var breeding_chances := {
		"rabbit": 0.085, "arctic_hare": 0.075, "monkey": 0.045, "wild_boar": 0.035,
		"boar": 0.035, "red_deer": 0.022, "deer": 0.022, "marsh_deer": 0.022,
		"red_fox": 0.018, "snow_fox": 0.018, "grey_wolf": 0.014, "wolf": 0.014,
		"elk": 0.012, "mountain_goat": 0.016, "tapir": 0.012, "brown_bear": 0.008,
		"jaguar": 0.008, "snow_leopard": 0.007, "hyena": 0.014, "desert_gazelle": 0.025,
		"ash_goat": 0.015, "ember_lizard": 0.05, "lynx": 0.01
	}
	for parent in get_tree().get_nodes_in_group("critter"):
		if not parent is Critter or parent._carcass or parent.is_in_group("eco_juvenile"):
			continue
		if not breeding_chances.has(parent.kind) or randf() >= float(breeding_chances[parent.kind]):
			continue
		if get_tree().get_nodes_in_group("eco_juvenile").size() >= MAX_JUVENILES:
			return
		var offset := Vector3(randf_range(-1.8, 1.8), 0.0, randf_range(-1.8, 1.8))
		var child_position := parent.global_position + offset
		child_position.y = _terrain.get_height(child_position.x, child_position.z) + 0.12
		var child := Critter.new()
		child.kind = parent.kind
		child.position = child_position
		child.add_to_group("eco_juvenile")
		child.add_to_group("elyndor_spawned_wildlife")
		child.set_meta("eco_age", 0)
		parent.get_parent().add_child(child)
		child.set_meta("eco_adult_scale", child._model.scale)
		child._model.scale *= 0.5
		child.physical_strength *= 0.45
		child.set_meta("physical_strength", child.physical_strength)
		return

# Mature trees cast seeds, so forests spread outward instead of spawning randomly.
func _spread_trees() -> void:
	if get_tree().get_nodes_in_group("sapling").size() >= MAX_SAPLINGS:
		return
	var mature: Array = get_tree().get_nodes_in_group("growing_tree").filter(func(t): return t.maturity >= 1.0)
	mature.shuffle()
	for tree in mature.slice(0, 2):
		if randf() > 0.35:
			continue
		var a := randf() * TAU
		var r := randf_range(4.0, 10.0)
		var x: float = tree.global_position.x + cos(a) * r
		var z: float = tree.global_position.z + sin(a) * r
		var h := _terrain.get_height(x, z)
		if h < 1.6 or h > 12.0 or _terrain.settlement_mask(x, z) > 0.05:
			continue
		var seedling := GrowingTree.new()
		seedling.species = tree.species
		seedling.maturity = 0.05
		seedling.position = Vector3(x, h, z)
		tree.get_parent().add_child(seedling)

func _make_points(count: int, radius: float) -> MultiMeshInstance3D:
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 6
	sphere.rings = 3
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	sphere.material = mat
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = sphere
	mm.instance_count = count
	mm.visible_instance_count = 0
	var node := MultiMeshInstance3D.new()
	node.multimesh = mm
	node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(node)
	return node

func _is_day() -> bool:
	var dn := get_tree().get_first_node_in_group("day_night")
	return dn == null or bool(dn.is_day)

# Swarm density mirrors simulated populations: bees by day, fireflies and moths by night,
# and bioluminescent plankton over nearby water after dark.
func _place_points() -> void:
	var center: Vector3 = GameManager.player.global_position
	var day := _is_day()
	var swarm_mm := _swarm.multimesh
	_swarm_points.clear()
	var kinds: Array = ["bees"] if day else ["fireflies", "emberwing_moth"]
	for kind in kinds:
		if not _pop.has(kind):
			continue
		var share := float(_pop[kind].adult) / float(species_def(kind).cap)
		var n := mini(int(share * 40.0), swarm_mm.instance_count - _swarm_points.size())
		for i in range(n):
			var p := _random_land_point(center)
			if p == Vector3.INF:
				continue
			var color := Color(1.0, 0.82, 0.2) if kind == "bees" else (Color(1.0, 0.45, 0.12) if kind == "emberwing_moth" else Color(0.75, 1.0, 0.3))
			if i < int(_pop[kind].rare) and i < 2:
				color = Color(1.0, 0.9, 0.5) if kind == "bees" else Color(0.35, 0.7, 1.0)
			swarm_mm.set_instance_color(_swarm_points.size(), color)
			_swarm_points.append(p)
	swarm_mm.visible_instance_count = _swarm_points.size()
	var plankton_mm := _plankton.multimesh
	_plankton_points.clear()
	if not day:
		var glow := int(float(_pop.plankton.adult) / float(SPECIES.plankton.cap) * plankton_mm.instance_count)
		for i in range(glow * 3):
			if _plankton_points.size() >= glow:
				break
			var x := center.x + randf_range(-26.0, 26.0)
			var z := center.z + randf_range(-26.0, 26.0)
			var bed := _terrain.get_height(x, z)
			var surface: float = TideSystem.level_at_bed(bed)
			if bed > surface - 0.3:
				continue
			var color := Color(0.3, 0.85, 1.0) if _plankton_points.size() >= int(_pop.plankton.rare) else Color(0.95, 0.95, 1.0)
			plankton_mm.set_instance_color(_plankton_points.size(), color)
			_plankton_points.append(Vector3(x, surface - 0.08, z))
	plankton_mm.visible_instance_count = _plankton_points.size()

func _random_land_point(center: Vector3) -> Vector3:
	for attempt in range(4):
		var x := center.x + randf_range(-22.0, 22.0)
		var z := center.z + randf_range(-22.0, 22.0)
		var h := _terrain.get_height(x, z)
		if h > Constants.WATER_LEVEL + 0.4:
			return Vector3(x, h + randf_range(0.5, 1.8), z)
	return Vector3.INF

func _animate_points() -> void:
	for i in range(_swarm_points.size()):
		var p := _swarm_points[i]
		var offset := Vector3(sin(_t * 1.7 + i), sin(_t * 2.3 + i * 0.7) * 0.4, cos(_t * 1.3 + i * 1.3)) * 0.6
		_swarm.multimesh.set_instance_transform(i, Transform3D(Basis(), p + offset))
	for i in range(_plankton_points.size()):
		var q := _plankton_points[i]
		var drift := Vector3(sin(_t * 0.3 + i), 0.0, cos(_t * 0.25 + i)) * 0.5
		_plankton.multimesh.set_instance_transform(i, Transform3D(Basis(), q + drift))

func _save() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"pop": _pop, "rare_seen": _rare_seen, "emerged": _emerged, "regional_populations": _regional_populations, "regional_tick": _regional_tick}))
		file.close()
	call_deferred("_persist_regional_population_state")

func _restore_regional_population_state() -> void:
	if not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured():
		_regional_backend_restore_pending = false
		return
	var response: Dictionary = await CentralBackend.server_load_region_entities("world-ecology")
	if not bool(response.get("ok", false)):
		push_warning("Central regional ecology restore unavailable; using local snapshot: %s" % str(response.get("error", response.get("status", "unknown"))))
		_regional_backend_restore_pending = false
		return
	var body: Dictionary = response.get("body", {})
	var rows: Variant = body.get("entities", body.get("items", []))
	if not rows is Array:
		_regional_backend_restore_pending = false
		return
	var expected_id := "regional_ecology_%d" % GameManager.world_seed
	for row in rows:
		if not row is Dictionary or str(row.get("entity_id", "")) != expected_id:
			continue
		var state: Variant = row.get("entity_state", {})
		if state is Dictionary:
			var saved_regions: Variant = state.get("regions", {})
			if saved_regions is Dictionary:
				_regional_populations = saved_regions.duplicate(true)
				_regional_tick = int(state.get("tick", _regional_tick))
				_regional_backend_revision = int(row.get("revision", 0))
				_initialize_regional_populations()
		_regional_backend_restore_pending = false
		return
	_regional_backend_restore_pending = false

func _persist_regional_population_state() -> void:
	if _regional_backend_save_pending or not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured() or _regional_populations.is_empty():
		return
	_regional_backend_save_pending = true
	var entity_id := "regional_ecology_%d" % GameManager.world_seed
	var state := {"seed": GameManager.world_seed, "tick": _regional_tick, "regions": _regional_populations}
	var result: Dictionary = await CentralBackend.server_save_world_entity(entity_id, "regional_ecology", "world-ecology", _regional_backend_revision, state)
	if bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		_regional_backend_revision = int(body.get("revision", _regional_backend_revision + 1))
	else:
		push_warning("Central regional ecology save failed: %s" % str(result.get("error", result.get("status", "unknown"))))
	_regional_backend_save_pending = false

func _load() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not data is Dictionary:
		return
	var saved_pop: Dictionary = data.get("pop", {})
	for id in saved_pop.keys():
		if (SPECIES.has(id) or EMERGENT.has(id)) and saved_pop[id] is Dictionary:
			_pop[id] = {"juv": float(saved_pop[id].get("juv", 0.0)), "adult": float(saved_pop[id].get("adult", 0.0)), "rare": int(saved_pop[id].get("rare", 0))}
	_rare_seen = data.get("rare_seen", {})
	_emerged = data.get("emerged", {})
	_regional_populations = data.get("regional_populations", {})
	_regional_tick = int(data.get("regional_tick", 0))

func _exit_tree() -> void:
	if _regional_worker_running:
		var final_state: Variant = _regional_worker.wait_to_finish()
		_regional_worker_running = false
		if final_state is Dictionary and not final_state.is_empty():
			_regional_populations = final_state.get("regions", _regional_populations)
			_regional_tick = int(final_state.get("tick", _regional_tick))
			_apply_pending_regional_hunts()
			var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
			if file:
				file.store_string(JSON.stringify({"pop": _pop, "rare_seen": _rare_seen, "emerged": _emerged, "regional_populations": _regional_populations, "regional_tick": _regional_tick}))
				file.close()
