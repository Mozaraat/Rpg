# Player construction system. All placed structures are collidable and persistent.
extends Node

var build_mode := false
var selected := 0
var ghost: MeshInstance3D
var _spawned: Array[Node] = []
var _restoring := false
var _settings_panel: PanelContainer
var _settings_open := false
var _settings_lock_held := false
var _ghost_valid := false
var build_settings: Dictionary = {
    "grid_snap": true,
    "snap_size": 0.5,
    "rotation_step": 90,
    "placement_range": 6.0,
    "ghost_preview": true,
    "free_build": false
}
var pieces := ["wood_floor", "wood_wall", "campfire", "storage_crate", "road_segment", "small_house", "workshop", "market_stall", "coop", "barn", "farm_plot", "sheep_pen", "dairy", "bakery", "settlement_hall"]
var costs := {
    "wood_floor":{"wood_log":3}, "wood_wall":{"wood_log":4},
    "campfire":{"wood_log":3, "iron_ore":1}, "storage_crate":{"wood_log":5},
    "road_segment":{"wood_log":1}, "small_house":{"wood_log":18},
    "workshop":{"wood_log":14,"iron_ingot":2}, "market_stall":{"wood_log":8},
    "coop":{"wood_log":10}, "barn":{"wood_log":16}, "farm_plot":{"wood_log":2}, "sheep_pen":{"wood_log":12}, "dairy":{"wood_log":14,"iron_ingot":1}, "bakery":{"wood_log":12,"iron_ingot":1}, "settlement_hall":{"wood_log":28,"iron_ingot":5}
}

func _ready() -> void:
    add_to_group("player_building")
    var saved_settings: Variant = PlayerData.stats.get("build_settings", {})
    if saved_settings is Dictionary:
        for key in saved_settings:
            build_settings[key] = saved_settings[key]
    _create_settings_panel()
    call_deferred("_restore_structures")

func _save_build_settings() -> void:
    PlayerData.stats["build_settings"] = build_settings.duplicate(true)

func _set_build_setting(key: String, value: Variant) -> void:
    build_settings[key] = value
    _save_build_settings()
    if key == "ghost_preview" and is_instance_valid(ghost):
        ghost.visible = bool(value) and ghost.visible

func _create_settings_panel() -> void:
    var layer := CanvasLayer.new()
    layer.name = "BuildSettingsLayer"
    layer.layer = 80
    add_child(layer)
    _settings_panel = PanelContainer.new()
    _settings_panel.name = "BuildSettingsPanel"
    _settings_panel.position = Vector2(24, 90)
    _settings_panel.custom_minimum_size = Vector2(330, 0)
    _settings_panel.visible = false
    _settings_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    layer.add_child(_settings_panel)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.055, 0.075, 0.105, 0.97)
    style.border_color = Color(0.55, 0.68, 0.78, 0.8)
    style.set_border_width_all(1)
    style.set_corner_radius_all(8)
    style.content_margin_left = 16.0
    style.content_margin_right = 16.0
    style.content_margin_top = 14.0
    style.content_margin_bottom = 14.0
    _settings_panel.add_theme_stylebox_override("panel", style)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 9)
    _settings_panel.add_child(column)
    var heading := Label.new()
    heading.text = "BUILD MODE SETTINGS"
    heading.add_theme_font_size_override("font_size", 18)
    column.add_child(heading)
    var hint := Label.new()
    hint.text = "F3 to close • V toggles building"
    hint.add_theme_color_override("font_color", Color(0.65, 0.75, 0.83))
    column.add_child(hint)
    _add_setting_toggle(column, "Grid snapping", "grid_snap")
    _add_setting_toggle(column, "Free construction (no materials)", "free_build")
    _add_setting_toggle(column, "Show placement preview", "ghost_preview")
    var snap_label := Label.new()
    snap_label.text = "Grid size"
    column.add_child(snap_label)
    var snap := OptionButton.new()
    for size in [0.25, 0.5, 1.0, 2.0]:
        snap.add_item("%.2f metres" % size)
    snap.item_selected.connect(func(index: int) -> void:
        _set_build_setting("snap_size", [0.25, 0.5, 1.0, 2.0][index]))
    column.add_child(snap)
    snap.select([0.25, 0.5, 1.0, 2.0].find(float(build_settings["snap_size"])))
    var rotation_label := Label.new()
    rotation_label.text = "Rotation increment"
    column.add_child(rotation_label)
    var rotation := OptionButton.new()
    for degrees in [15, 30, 45, 90]:
        rotation.add_item("%d degrees" % degrees)
    rotation.item_selected.connect(func(index: int) -> void:
        _set_build_setting("rotation_step", [15, 30, 45, 90][index]))
    column.add_child(rotation)
    rotation.select([15, 30, 45, 90].find(int(build_settings["rotation_step"])))
    var range_label := Label.new()
    range_label.text = "Placement distance"
    column.add_child(range_label)
    var range_slider := HSlider.new()
    range_slider.min_value = 3.0
    range_slider.max_value = 12.0
    range_slider.step = 0.5
    range_slider.value = float(build_settings["placement_range"])
    range_slider.value_changed.connect(func(value: float) -> void:
        _set_build_setting("placement_range", value)
        range_label.text = "Placement distance: %.1f m" % value
    )
    column.add_child(range_slider)
    range_label.text = "Placement distance: %.1f m" % range_slider.value
    var close_button := Button.new()
    close_button.text = "Close settings"
    close_button.pressed.connect(_toggle_settings_panel)
    column.add_child(close_button)

func _add_setting_toggle(parent: VBoxContainer, label_text: String, setting_key: String) -> void:
    var toggle := CheckButton.new()
    toggle.text = label_text
    toggle.button_pressed = bool(build_settings[setting_key])
    if setting_key == "free_build" and WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
        toggle.disabled = true
        toggle.button_pressed = false
    toggle.toggled.connect(func(enabled: bool) -> void:
        _set_build_setting(setting_key, enabled)
    )
    parent.add_child(toggle)

func _toggle_settings_panel() -> void:
    _settings_open = not _settings_open
    if is_instance_valid(_settings_panel):
        _settings_panel.visible = _settings_open
    if _settings_open and not _settings_lock_held:
        GameManager.push_ui_lock()
        _settings_lock_held = true
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif not _settings_open and _settings_lock_held:
        GameManager.pop_ui_lock()
        _settings_lock_held = false
        if build_mode:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func restore_from_player_data() -> void:
    _restore_structures()

func _restore_structures() -> void:
    _restoring = true
    for node in _spawned:
        if is_instance_valid(node): node.queue_free()
    _spawned.clear()
    var saved: Variant = PlayerData.stats.get("player_buildings", [])
    if saved is Array:
        for entry in saved:
            if entry is Dictionary:
                _spawn_structure(str(entry.get("piece", "wood_floor")), Vector3(float(entry.get("x", 0.0)), float(entry.get("y", 0.0)), float(entry.get("z", 0.0))), float(entry.get("rotation", 0.0)))
    _restoring = false

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_F3:
            _toggle_settings_panel()
            get_viewport().set_input_as_handled()
            return
        if _settings_open:
            return
        if GameManager.input_locked:
            return
        if event.keycode == KEY_V:
            build_mode = not build_mode
            EventBus.toast.emit("Building mode " + ("enabled — F3 opens settings" if build_mode else "disabled"), "info")
            if not build_mode:
                _remove_ghost()
        elif build_mode and event.keycode >= KEY_1 and event.keycode <= KEY_9:
            selected = mini(event.keycode - KEY_1, pieces.size() - 1)
            _update_ghost_shape()
            EventBus.toast.emit("Selected: " + pieces[selected].replace("_", " "), "info")
        elif build_mode and event.keycode == KEY_0:
            selected = 9; _update_ghost_shape(); EventBus.toast.emit("Selected: barn", "info")
        elif build_mode and event.keycode == KEY_MINUS:
            selected = 10; _update_ghost_shape(); EventBus.toast.emit("Selected: farm plot", "info")
        elif build_mode and event.keycode == KEY_EQUAL:
            selected = 11; _update_ghost_shape(); EventBus.toast.emit("Selected: sheep pen", "info")
        elif build_mode and event.keycode == KEY_BRACKETRIGHT:
            selected = 12; _update_ghost_shape(); EventBus.toast.emit("Selected: dairy", "info")
        elif build_mode and event.keycode == KEY_BACKSLASH:
            selected = 13; _update_ghost_shape(); EventBus.toast.emit("Selected: bakery", "info")
        elif build_mode and event.keycode == KEY_BACKSPACE:
            selected = 14; _update_ghost_shape(); EventBus.toast.emit("Selected: settlement hall", "info")
        elif build_mode and event.keycode == KEY_R and is_instance_valid(ghost):
            ghost.rotate_y(deg_to_rad(float(build_settings["rotation_step"])))
    if _settings_open:
        return
    if build_mode and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        _place()
        get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
    if not build_mode or _settings_open: return
    var player: Node3D = GameManager.player
    if player == null: return
    if ghost == null:
        ghost = MeshInstance3D.new()
        ghost.mesh = BoxMesh.new()
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.3, 0.8, 0.45, 0.42)
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        ghost.material_override = mat
        get_tree().current_scene.add_child(ghost)
        _update_ghost_shape()
    var from := player.global_position + Vector3.UP * 1.2
    var placement_range := float(build_settings["placement_range"])
    var to := from + -player.global_transform.basis.z * placement_range + Vector3.DOWN * 5.0
    var query := PhysicsRayQueryParameters3D.create(from, to, Constants.LAYER_WORLD)
    var hit := player.get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        var target_position: Vector3 = hit.position + Vector3.UP * 0.12
        if bool(build_settings["grid_snap"]):
            var snap_size := maxf(0.05, float(build_settings["snap_size"]))
            target_position.x = snappedf(target_position.x, snap_size)
            target_position.z = snappedf(target_position.z, snap_size)
        ghost.global_position = target_position
        _ghost_valid = true
        ghost.visible = bool(build_settings["ghost_preview"])
    else:
        _ghost_valid = false
        ghost.visible = false

func _place() -> void:
    if ghost == null or not _ghost_valid: return
    var id: String = pieces[selected]
    var cost: Dictionary = costs[id]
    var free_build_allowed := bool(build_settings["free_build"]) and not (WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online())
    if not free_build_allowed:
        for item in cost:
            if PlayerData.count_item(item) < int(cost[item]):
                EventBus.toast.emit("Missing materials: " + item.replace("_", " "), "warning")
                return
        for item in cost:
            PlayerData.remove_item(item, int(cost[item]))
    _spawn_structure(id, ghost.global_position, ghost.rotation.y)
    var records: Array = PlayerData.stats.get("player_buildings", [])
    records.append({"piece":id,"x":ghost.global_position.x,"y":ghost.global_position.y,"z":ghost.global_position.z,"rotation":ghost.rotation.y})
    PlayerData.stats["player_buildings"] = records
    PlayerData.stats["built_structures"] = int(PlayerData.stats.get("built_structures", 0)) + 1
    EventBus.toast.emit("Placed " + id.replace("_", " "), "success")

func _remove_ghost() -> void:
    if is_instance_valid(ghost): ghost.queue_free()
    ghost = null
    _ghost_valid = false

func _spawn_structure(id: String, world_pos: Vector3, yaw: float) -> void:
    if id == "farm_plot":
        if not _restoring: FarmingSystem.create_plot_at(world_pos)
        return
    var body := StaticBody3D.new()
    body.name = "PlayerBuilt_" + id
    body.position = world_pos
    body.rotation.y = yaw
    body.collision_layer = Constants.LAYER_WORLD
    body.add_to_group("player_built")
    var mesh := MeshInstance3D.new()
    var shape: Shape3D = BoxShape3D.new()
    var mesh_y := 0.0
    var collision_y := 0.0
    match id:
        "wood_floor":
            var floor_piece_mesh := BoxMesh.new(); floor_piece_mesh.size = Vector3(2.5,0.18,2.5); mesh.mesh = floor_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = floor_piece_mesh.size
        "wood_wall":
            var wall_piece_mesh := BoxMesh.new(); wall_piece_mesh.size = Vector3(2.5,2.5,0.25); mesh.mesh = wall_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = wall_piece_mesh.size; mesh_y = 1.25; collision_y = 1.25
        "campfire":
            var fire_piece_mesh := CylinderMesh.new(); fire_piece_mesh.top_radius = 0.8; fire_piece_mesh.bottom_radius = 1.0; fire_piece_mesh.height = 0.35; mesh.mesh = fire_piece_mesh; var fire_shape := CylinderShape3D.new(); fire_shape.radius = 0.9; fire_shape.height = 0.4; shape = fire_shape; mesh_y = 0.18; collision_y = 0.2
        "storage_crate":
            var crate_piece_mesh := BoxMesh.new(); crate_piece_mesh.size = Vector3(1.1,0.8,0.8); mesh.mesh = crate_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = crate_piece_mesh.size; mesh_y = 0.4; collision_y = 0.4
        "road_segment":
            var road_piece_mesh := BoxMesh.new(); road_piece_mesh.size = Vector3(3.5,0.12,2.0); mesh.mesh = road_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = road_piece_mesh.size
        "farm_plot":
            var bed_piece_mesh := BoxMesh.new(); bed_piece_mesh.size = Vector3(1.8,0.12,1.8); mesh.mesh = bed_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = bed_piece_mesh.size; mesh_y = 0.06
        "market_stall":
            var stall_piece_mesh := BoxMesh.new(); stall_piece_mesh.size = Vector3(3.0,1.5,2.0); mesh.mesh = stall_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = stall_piece_mesh.size; mesh_y = 0.75; collision_y = 0.75
        "small_house", "workshop", "coop", "barn", "sheep_pen", "dairy", "bakery", "settlement_hall":
            mesh.visible = false
            var tiny := BoxShape3D.new(); tiny.size = Vector3(0.05,0.05,0.05); shape = tiny
        _:
            var fallback_piece_mesh := BoxMesh.new(); fallback_piece_mesh.size = Vector3(1.0,0.8,1.0); mesh.mesh = fallback_piece_mesh; shape = BoxShape3D.new(); (shape as BoxShape3D).size = fallback_piece_mesh.size
    mesh.position.y = mesh_y
    var mat: Material = BuildingKit.get_material("cobble") if id == "road_segment" else (BuildingKit.get_material("soil") if id == "farm_plot" else (BuildingKit.get_material("plaster_cream") if id == "small_house" else BuildingKit.get_material("wood")))
    mesh.material_override = mat
    body.add_child(mesh)
    if id in ["small_house","workshop","coop","barn","sheep_pen","dairy","bakery","settlement_hall"]:
        _add_building_shell(body, id)
    elif id == "market_stall":
        var canopy := MeshInstance3D.new(); var canopy_mesh := BoxMesh.new(); canopy_mesh.size = Vector3(3.3,0.16,2.3); canopy.mesh = canopy_mesh; canopy.position.y = 2.0
        var canopy_mat := StandardMaterial3D.new(); canopy_mat.albedo_color = Color(0.65,0.20,0.13); canopy.material_override = canopy_mat; body.add_child(canopy)
    var cs := CollisionShape3D.new(); cs.shape = shape; cs.position.y = collision_y; body.add_child(cs)
    if id == "campfire":
        var light := OmniLight3D.new(); light.light_color = Color(1.0,0.42,0.12); light.light_energy = 1.2; light.omni_range = 5.0; light.position.y = 1.0; body.add_child(light)
    get_tree().current_scene.add_child(body)
    _spawned.append(body)
    if not _restoring:
        if id == "coop": AnimalHusbandrySystem.register_animal("chicken", "Coop Hen", world_pos + Vector3(1.2,-0.12,0.8))
        elif id == "barn": AnimalHusbandrySystem.register_animal("cow", "Barn Cow", world_pos + Vector3(1.2,-0.12,0.8))
        elif id == "sheep_pen": AnimalHusbandrySystem.register_animal("sheep", "Pen Sheep", world_pos + Vector3(1.2,-0.12,0.8))
        elif id == "dairy": PlayerBusinessSystem.register_business("dairy", "Player Dairy")
        elif id == "bakery": PlayerBusinessSystem.register_business("bakery", "Player Bakery")
        elif id == "settlement_hall": PlayerBusinessSystem.register_settlement(world_pos)
        elif id == "workshop": PlayerBusinessSystem.register_business("carpenter", "Player Workshop")
        elif id == "market_stall": PlayerBusinessSystem.register_business("market", "Player Market Stall")

func _add_building_shell(body: StaticBody3D, kind: String) -> void:
    var height := 3.8 if kind == "barn" else 3.0
    var wall_mat: Material = BuildingKit.get_material("plaster_cream") if kind in ["small_house", "settlement_hall"] else BuildingKit.get_material("wood")
    var roof_mat: Material = BuildingKit.get_material("roof_clay") if kind == "settlement_hall" else (BuildingKit.get_material("roof_brown") if kind not in ["coop", "sheep_pen"] else BuildingKit.get_material("thatch"))
    # Floor, rear and side walls. The front is split around a real doorway so the player can enter.
    _add_wall_segment(body, Vector3(4.8,0.16,4.0), Vector3(0,0.0,0), BuildingKit.get_material("wood_dark"))
    _add_wall_segment(body, Vector3(5.0,height,0.18), Vector3(0,height * 0.5,2.0), wall_mat)
    _add_wall_segment(body, Vector3(0.18,height,4.2), Vector3(-2.4,height * 0.5,0), wall_mat)
    _add_wall_segment(body, Vector3(0.18,height,4.2), Vector3(2.4,height * 0.5,0), wall_mat)
    _add_wall_segment(body, Vector3(1.95,height,0.18), Vector3(-1.52,height * 0.5,-2.0), wall_mat)
    _add_wall_segment(body, Vector3(1.95,height,0.18), Vector3(1.52,height * 0.5,-2.0), wall_mat)
    _add_wall_segment(body, Vector3(1.1,0.75,0.18), Vector3(0,height - 0.375,-2.0), wall_mat)
    var roof := MeshInstance3D.new(); var roof_mesh := PrismMesh.new(); roof_mesh.size = Vector3(5.5,1.45,4.7); roof.mesh = roof_mesh; roof.position.y = height + 0.65; roof.material_override = roof_mat; body.add_child(roof)
    # Door leaf is visual only; doorway collision is intentionally open.
    var door := MeshInstance3D.new(); var door_mesh := BoxMesh.new(); door_mesh.size = Vector3(0.86,1.9,0.08); door.mesh = door_mesh; door.position = Vector3(0,0.95,-2.08); door.material_override = BuildingKit.get_material("wood_dark"); body.add_child(door)
    if kind in ["small_house", "workshop", "dairy", "bakery", "settlement_hall"]:
        for side_x in [-1.45,1.45]:
            var window := MeshInstance3D.new(); var window_mesh := BoxMesh.new(); window_mesh.size = Vector3(0.72,0.62,0.08); window.mesh = window_mesh; window.position = Vector3(side_x,1.95,-2.11)
            var glass := StandardMaterial3D.new(); glass.albedo_color = Color(0.28,0.55,0.68,0.72); glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA; glass.metallic = 0.12; glass.roughness = 0.2; window.material_override = glass; body.add_child(window)

func _add_wall_segment(body: StaticBody3D, size: Vector3, offset: Vector3, material: Material) -> void:
    var wall := MeshInstance3D.new(); var wall_mesh := BoxMesh.new(); wall_mesh.size = size; wall.mesh = wall_mesh; wall.position = offset; wall.material_override = material; body.add_child(wall)
    var collision := CollisionShape3D.new(); var box := BoxShape3D.new(); box.size = size; collision.shape = box; collision.position = offset; body.add_child(collision)

func _update_ghost_shape() -> void:
    if ghost == null: return
    var preview := ghost.mesh as BoxMesh
    if preview == null: preview = BoxMesh.new(); ghost.mesh = preview
    match pieces[selected]:
        "wood_floor": preview.size = Vector3(2.5,0.18,2.5); preview.position.y = 0.0
        "wood_wall": preview.size = Vector3(2.5,2.5,0.25); preview.position.y = 1.25
        "campfire": preview.size = Vector3(1.8,0.35,1.8); preview.position.y = 0.18
        "storage_crate": preview.size = Vector3(1.1,0.8,0.8); preview.position.y = 0.4
        "road_segment": preview.size = Vector3(3.5,0.12,2.0); preview.position.y = 0.0
        "small_house", "workshop", "coop", "sheep_pen", "dairy", "bakery", "settlement_hall": preview.size = Vector3(5.0,3.0,4.2); preview.position.y = 1.5
        "barn": preview.size = Vector3(5.0,3.8,4.2); preview.position.y = 1.9
        "market_stall": preview.size = Vector3(3.0,1.5,2.0); preview.position.y = 0.75
        "farm_plot": preview.size = Vector3(1.8,0.12,1.8); preview.position.y = 0.06
