# WorldProps - authored set dressing for settlements, roads and camps.
#
# Each prop bakes into one mesh per material (like BuildingKit), so a fully
# dressed square costs a handful of draw calls. Small coloured details (cloth,
# rope, flowers, runes) ride in a vertex-coloured mesh so they need no new
# shader materials.
class_name WorldProps
extends RefCounted

static var _plain_cache: Dictionary = {}

# ---------------------------------------------------------------------------
# Materials / mesh helpers
# ---------------------------------------------------------------------------
static func _plain(c: Color, rough: float = 0.85, metal: float = 0.0) -> StandardMaterial3D:
	var key: String = "%s|%.2f|%.2f" % [c.to_html(), rough, metal]
	if _plain_cache.has(key):
		return _plain_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	_plain_cache[key] = m
	return m

static func _vc_material(cull_disabled: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	m.roughness = 0.88
	if cull_disabled:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m

## Builds a vertex-coloured detail mesh (flags, rope, petals) as one child node.
static func _add_vc(parent: Node3D, build: Callable, cull_disabled: bool = false, node_name: String = "Detail") -> MeshInstance3D:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	build.call(st)
	st.set_material(_vc_material(cull_disabled))
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = st.commit()
	parent.add_child(mi)
	return mi

static func _finish(b: MeshBatch, shapes: Array, node_name: String) -> StaticBody3D:
	return BuildingKit._finish(b, shapes, node_name)

static func _box_shape(size: Vector3, pos: Vector3, yaw: float = 0.0) -> Array:
	return BuildingKit._box_shape(size, pos, yaw)

static func _cyl_shape(radius: float, height: float, pos: Vector3) -> Array:
	return BuildingKit._cyl_shape(radius, height, pos)

static func _label(text: String, font_size: int, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = font_size
	l.pixel_size = 0.0032
	l.modulate = color
	l.outline_size = 0
	l.shaded = true
	l.double_sided = true
	l.alpha_cut = Label3D.ALPHA_CUT_DISABLED
	return l

# ---------------------------------------------------------------------------
# Cart - two-wheeled timber hauler with optional cargo
# ---------------------------------------------------------------------------
static func make_cart(loaded: bool = true) -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dark: SurfaceTool = b.surface("wood_dark")
	var iron: SurfaceTool = b.surface("iron")

	# Bed, frame rails and tailgate (long axis = Z, shafts point +Z)
	MeshKit.box_at(wood, Vector3(0, 0.74, 0.2), Vector3(1.24, 0.13, 2.3), Color(0.72, 0.72, 0.72), Color.WHITE)
	MeshKit.box_at(dark, Vector3(0, 0.64, 0.2), Vector3(1.36, 0.09, 2.42), Color(0.6, 0.6, 0.6), Color.WHITE)
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(dark, Vector3(sx * 0.64, 0.98, 0.2), Vector3(0.08, 0.08, 2.3))
		for zz in [-0.85, 0.2, 1.2]:
			MeshKit.box_at(dark, Vector3(sx * 0.64, 0.9, zz), Vector3(0.08, 0.36, 0.08))
	MeshKit.box_at(wood, Vector3(0, 0.92, -0.97), Vector3(1.24, 0.4, 0.08))
	MeshKit.box_at(wood, Vector3(0, 0.9, 1.34), Vector3(1.24, 0.36, 0.08))

	# Wheels: axle along X, six spokes and an iron tyre each
	for sx in [-1.0, 1.0]:
		var wpos := Vector3(sx * 0.74, 0.55, -0.22)
		MeshKit.cylinder(wood, Transform3D(Basis(Vector3.BACK, PI * 0.5), wpos + Vector3(0.06, 0, 0)), 0.55, 0.55, 0.12, 12, Color(0.62, 0.62, 0.62), Color.WHITE)
		MeshKit.cylinder(iron, Transform3D(Basis(Vector3.BACK, PI * 0.5), wpos + Vector3(0.012, 0, 0)), 0.58, 0.58, 0.035, 12)
		MeshKit.cylinder(dark, Transform3D(Basis(Vector3.BACK, PI * 0.5), wpos), 0.15, 0.15, 0.18, 8)
		for k in range(6):
			var ang: float = TAU * float(k) / 6.0
			var dir := Vector3(0, cos(ang), sin(ang))
			MeshKit.box(wood, Transform3D(Basis(Vector3.RIGHT, ang), wpos + dir * 0.27), Vector3(0.06, 0.56, 0.06))
	MeshKit.cylinder_between(dark, Vector3(-0.74, 0.55, -0.22), Vector3(0.74, 0.55, -0.22), 0.07, 0.07, 6)

	# Shafts and legs
	for sx in [-1.0, 1.0]:
		MeshKit.cylinder_between(wood, Vector3(sx * 0.42, 0.78, 1.2), Vector3(sx * 0.36, 0.3, 2.3), 0.055, 0.045, 6)
		MeshKit.box_at(dark, Vector3(sx * 0.5, 0.3, 0.85), Vector3(0.09, 0.62, 0.09))

	if loaded:
		var hay: SurfaceTool = b.surface("hay")
		MeshKit.cylinder_at(wood, Vector3(0.28, 0.78, 0.75), 0.25, 0.28, 0.52, 10, Color(0.7, 0.7, 0.7), Color.WHITE)
		MeshKit.cylinder_at(iron, Vector3(0.28, 0.92, 0.75), 0.27, 0.27, 0.05, 10)
		MeshKit.cylinder_at(iron, Vector3(0.28, 1.18, 0.75), 0.285, 0.285, 0.05, 10)
		var rng := RandomNumberGenerator.new()
		rng.seed = 431
		MeshKit.blob_smooth(hay, Vector3(-0.32, 1.0, 0.55), Vector3(0.27, 0.29, 0.25), rng, Color(0.65, 0.65, 0.65), Color.WHITE, 0.18, 7, 4)
		MeshKit.blob_smooth(hay, Vector3(-0.18, 1.02, -0.25), Vector3(0.24, 0.26, 0.23), rng, Color(0.6, 0.6, 0.6), Color.WHITE, 0.18, 7, 4)
		MeshKit.box_at(wood, Vector3(0.3, 1.05, -0.4), Vector3(0.5, 0.42, 0.5))
		MeshKit.box_at(dark, Vector3(0.3, 1.27, -0.4), Vector3(0.54, 0.06, 0.54))

	var shapes: Array = [_box_shape(Vector3(1.5, 1.5, 2.8), Vector3(0, 0.75, 0.25))]
	return _finish(b, shapes, "Cart")

# ---------------------------------------------------------------------------
# Signpost - carved boards with painted destination names
# ---------------------------------------------------------------------------
static func make_signpost(entries: Array) -> Node3D:
	var root := Node3D.new()
	root.name = "Signpost"
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dark: SurfaceTool = b.surface("wood_dark")
	var iron: SurfaceTool = b.surface("iron")
	MeshKit.cylinder_at(b.surface("stone"), Vector3.ZERO, 0.2, 0.14, 0.22, 8)
	MeshKit.cylinder_at(dark, Vector3(0, 0.15, 0), 0.11, 0.085, 2.75, 8, Color(0.6, 0.6, 0.6), Color.WHITE)
	MeshKit.cylinder_at(iron, Vector3(0, 2.9, 0), 0.13, 0.0, 0.16, 6)

	for i in range(entries.size()):
		var entry: Dictionary = entries[i]
		var text: String = str(entry.get("text", ""))
		var dir2: Vector2 = entry.get("dir", Vector2(0, 1))
		var d3 := Vector3(dir2.x, 0, dir2.y).normalized()
		if d3.length_squared() < 0.001:
			d3 = Vector3(0, 0, 1)
		var yaw: float = atan2(d3.x, d3.z) - PI * 0.5
		var y: float = 2.55 - float(i) * 0.42
		var center: Vector3 = d3 * 0.56 + Vector3(0, y, 0)
		MeshKit.box(wood, Transform3D(Basis(Vector3.UP, yaw), center), Vector3(1.05, 0.21, 0.055), Color(0.78, 0.78, 0.78), Color.WHITE)
		MeshKit.box(dark, Transform3D(Basis(Vector3.UP, yaw), center + d3 * 0.52), Vector3(0.06, 0.23, 0.06))
		var normal: Vector3 = Vector3(sin(yaw), 0, cos(yaw))
		var label := _label(text, 24, Color(0.28, 0.2, 0.12))
		label.transform = Transform3D(Basis(Vector3.UP, yaw), center + normal * 0.041 + Vector3(0, -0.002, 0))
		root.add_child(label)

	root.add_child(_finish(b, [_cyl_shape(0.14, 2.9, Vector3(0, 1.45, 0))], "Body"))
	return root

# ---------------------------------------------------------------------------
# Woodpile and chopping block
# ---------------------------------------------------------------------------
static func make_woodpile() -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dark: SurfaceTool = b.surface("wood_dark")
	var iron: SurfaceTool = b.surface("iron")
	for row in range(3):
		for i in range(3):
			var offset: float = 0.2 if row % 2 == 1 else 0.0
			var p := Vector3(0.75, 0.15 + float(row) * 0.285, -0.5 + float(i) * 0.46 + offset)
			MeshKit.cylinder(wood, Transform3D(Basis(Vector3.BACK, PI * 0.5), p), 0.145, 0.14, 1.5, 9, Color(0.55, 0.55, 0.55), Color.WHITE)
	# Chopping block, axe lodged in it
	MeshKit.cylinder_at(dark, Vector3(1.2, 0, 0.85), 0.31, 0.27, 0.48, 10, Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.cylinder_between(wood, Vector3(1.34, 0.5, 0.92), Vector3(1.1, 0.96, 0.86), 0.032, 0.028, 6)
	MeshKit.box_at(iron, Vector3(1.08, 1.0, 0.85), Vector3(0.09, 0.16, 0.2))
	MeshKit.flat_tri(b.surface("iron"), Vector3(1.02, 0.9, 0.95), Vector3(1.02, 1.1, 0.95), Vector3(1.02, 1.0, 0.71), Vector3.LEFT)
	# Sawn rounds leaning at the end of the stack
	var rng := RandomNumberGenerator.new()
	rng.seed = 617
	for i in range(3):
		MeshKit.cylinder(wood, Transform3D(Basis(Vector3.BACK, PI * 0.5), Vector3(-0.95, 0.18 + float(i) * 0.24, 0.95)), 0.18, 0.18, 0.16, 9, Color(0.62, 0.62, 0.62), Color.WHITE)
	var shapes: Array = [_box_shape(Vector3(1.6, 0.95, 1.5), Vector3(0, 0.45, 0)),
		_box_shape(Vector3(0.62, 0.5, 0.62), Vector3(1.2, 0.25, 0.85))]
	return _finish(b, shapes, "Woodpile")

# ---------------------------------------------------------------------------
# Laundry line with wind-caught cloth
# ---------------------------------------------------------------------------
static func make_laundry_line(width: float = 4.6) -> Node3D:
	var root := Node3D.new()
	root.name = "LaundryLine"
	var b := MeshBatch.new()
	var dark: SurfaceTool = b.surface("wood_dark")
	var stone: SurfaceTool = b.surface("stone")
	for sx in [-1.0, 1.0]:
		var px: float = sx * width * 0.5
		MeshKit.cylinder_at(stone, Vector3(px, 0, 0), 0.16, 0.11, 0.2, 7)
		MeshKit.cylinder_at(dark, Vector3(px, 0, 0), 0.07, 0.05, 2.3, 6, Color(0.65, 0.65, 0.65), Color.WHITE)
		MeshKit.box_at(dark, Vector3(px, 2.16, 0), Vector3(0.5, 0.06, 0.06))
	root.add_child(_finish(b, [], "Posts"))

	var rope: Color = Color(0.36, 0.28, 0.18)
	var palette: Array[Color] = [
		Color(0.72, 0.16, 0.13), Color(0.9, 0.87, 0.76),
		Color(0.22, 0.36, 0.66), Color(0.85, 0.75, 0.5),
	]
	var half: float = width * 0.5 - 0.22
	var build := func(st: SurfaceTool) -> void:
		var segs := 12
		var prev := Vector3(-half, 2.17, 0)
		for i in range(1, segs + 1):
			var t: float = float(i) / float(segs)
			var p := Vector3(lerpf(-half, half, t), 2.17 - sin(t * PI) * 0.26, 0)
			MeshKit.cylinder_between(st, prev, p, 0.017, 0.017, 4, rope, rope)
			prev = p
		var pieces := 4
		for k in range(pieces):
			var t2: float = 0.18 + float(k) * 0.21
			var x: float = lerpf(-half, half, t2)
			var top_y: float = 2.17 - sin(t2 * PI) * 0.26
			var w: float = 0.5 + fmod(float(k) * 0.17, 0.22)
			var h: float = 0.72 - float(k % 2) * 0.14
			var c: Color = palette[k % palette.size()]
			var skew: float = 0.03 * float(k % 3 - 1)
			# Double-sided panels so cloth reads from both sides of the lane.
			for side in [1.0, -1.0]:
				var out := Vector3(0, 0, side)
				MeshKit.flat_quad(st,
					Vector3(x - w * 0.5, top_y, 0),
					Vector3(x + w * 0.5, top_y, 0),
					Vector3(x + w * 0.44 + skew, top_y - h, 0.02 * side),
					Vector3(x - w * 0.44 + skew, top_y - h, 0),
					out, c, c, c.darkened(0.08), c.darkened(0.08))
			MeshKit.cylinder_at(st, Vector3(x, top_y - 0.02, 0), 0.035, 0.028, 0.08, 5, rope, rope)
	_add_vc(root, build, true, "Cloth")
	return root

# ---------------------------------------------------------------------------
# Water trough
# ---------------------------------------------------------------------------
static func make_trough() -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dark: SurfaceTool = b.surface("wood_dark")
	MeshKit.box_at(wood, Vector3(0, 0.42, 0), Vector3(2.0, 0.12, 0.78))
	for sz in [-1.0, 1.0]:
		MeshKit.box_at(wood, Vector3(0, 0.66, sz * 0.36), Vector3(2.02, 0.4, 0.08))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(wood, Vector3(sx * 0.97, 0.62, 0), Vector3(0.08, 0.44, 0.72))
		for sz in [-1.0, 1.0]:
			MeshKit.box_at(dark, Vector3(sx * 0.78, 0.2, sz * 0.26), Vector3(0.1, 0.42, 0.1))
	MeshKit.box_at(b.surface("water_basin"), Vector3(0, 0.61, 0), Vector3(1.9, 0.03, 0.66))
	var shapes: Array = [_box_shape(Vector3(2.05, 0.85, 0.85), Vector3(0, 0.42, 0))]
	return _finish(b, shapes, "Trough")

# ---------------------------------------------------------------------------
# Flower planter (barrel with soil and blooms)
# ---------------------------------------------------------------------------
static func make_planter() -> Node3D:
	var root := Node3D.new()
	root.name = "Planter"
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var iron: SurfaceTool = b.surface("iron")
	MeshKit.cylinder_at(wood, Vector3.ZERO, 0.3, 0.36, 0.5, 10, Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.cylinder_at(wood, Vector3(0, 0.5, 0), 0.36, 0.3, 0.2, 10, Color.WHITE, Color.WHITE)
	MeshKit.cylinder_at(iron, Vector3(0, 0.1, 0), 0.335, 0.34, 0.06, 10)
	MeshKit.cylinder_at(iron, Vector3(0, 0.55, 0), 0.345, 0.335, 0.05, 10)
	MeshKit.cylinder_at(b.surface("soil"), Vector3(0, 0.69, 0), 0.3, 0.28, 0.04, 10)
	root.add_child(_finish(b, [_cyl_shape(0.36, 0.7, Vector3(0, 0.35, 0))], "Barrel"))

	var rng := RandomNumberGenerator.new()
	rng.seed = 733
	var petal_cols: Array[Color] = [Color(0.9, 0.2, 0.22), Color(0.98, 0.93, 0.85), Color(0.98, 0.78, 0.2), Color(0.6, 0.35, 0.85)]
	var stem_col := Color(0.18, 0.4, 0.12)
	var build := func(st: SurfaceTool) -> void:
		for i in range(7):
			var a: float = TAU * float(i) / 7.0 + 0.4
			var rad: float = 0.13 + rng.randf() * 0.12
			var base := Vector3(cos(a) * rad, 0.69, sin(a) * rad)
			var top := base + Vector3(rng.randf_range(-0.04, 0.04), rng.randf_range(0.2, 0.3), rng.randf_range(-0.04, 0.04))
			MeshKit.cylinder_between(st, base, top, 0.012, 0.008, 4, stem_col, stem_col)
			var pc: Color = petal_cols[i % petal_cols.size()]
			for p in range(5):
				var pa: float = TAU * float(p) / 5.0
				MeshKit.blob_smooth(st, top + Vector3(cos(pa) * 0.045, 0.02, sin(pa) * 0.045), Vector3(0.04, 0.016, 0.04), rng, pc, pc, 0.1, 5, 3)
			MeshKit.blob_smooth(st, top + Vector3(0, 0.045, 0), Vector3(0.026, 0.02, 0.026), rng, Color(0.95, 0.72, 0.1), Color(0.95, 0.78, 0.2), 0.05, 5, 3)
	_add_vc(root, build, false, "Flowers")
	return root

# ---------------------------------------------------------------------------
# Grain sacks
# ---------------------------------------------------------------------------
static func make_sack_pile() -> Node3D:
	var b := MeshBatch.new()
	var hay: SurfaceTool = b.surface("hay")
	var rng := RandomNumberGenerator.new()
	rng.seed = 811
	MeshKit.blob_smooth(hay, Vector3(0, 0.32, 0), Vector3(0.3, 0.38, 0.28), rng, Color(0.66, 0.66, 0.66), Color.WHITE, 0.16, 7, 4)
	MeshKit.blob_smooth(hay, Vector3(0.48, 0.27, 0.14), Vector3(0.27, 0.32, 0.25), rng, Color(0.62, 0.62, 0.62), Color.WHITE, 0.16, 7, 4)
	MeshKit.blob_smooth(hay, Vector3(0.05, 0.82, -0.06), Vector3(0.26, 0.3, 0.24), rng, Color(0.7, 0.7, 0.7), Color.WHITE, 0.16, 7, 4)
	var root := _finish(b, [_box_shape(Vector3(1.15, 0.95, 0.8), Vector3(0.2, 0.45, 0))], "Sacks")
	var rope := Color(0.4, 0.3, 0.19)
	var build := func(st: SurfaceTool) -> void:
		MeshKit.cylinder_at(st, Vector3(0, 0.68, 0), 0.1, 0.08, 0.06, 6, rope, rope)
		MeshKit.cylinder_at(st, Vector3(0.48, 0.58, 0.14), 0.09, 0.07, 0.05, 6, rope, rope)
		MeshKit.cylinder_at(st, Vector3(0.05, 1.11, -0.06), 0.09, 0.07, 0.05, 6, rope, rope)
	_add_vc(root, build, false, "Ties")
	return root

# ---------------------------------------------------------------------------
# Campfire ring - stones, logs, tripod and a cooking pot
# ---------------------------------------------------------------------------
static func make_campfire() -> Node3D:
	var root := Node3D.new()
	root.name = "Campfire"
	var b := MeshBatch.new()
	var stone: SurfaceTool = b.surface("stone")
	var wood: SurfaceTool = b.surface("wood_dark")
	var iron: SurfaceTool = b.surface("iron")
	var rng := RandomNumberGenerator.new()
	rng.seed = 941
	for i in range(10):
		var a: float = TAU * float(i) / 10.0
		var rr: float = rng.randf_range(0.7, 0.92)
		MeshKit.rock(stone, Vector3(cos(a) * rr, 0.12, sin(a) * rr), Vector3(0.21, 0.15, 0.19), rng, Color(0.35, 0.34, 0.32), Color(0.62, 0.6, 0.56))
	MeshKit.cylinder_at(b.surface("plaster_cream"), Vector3(0, 0.02, 0), 0.55, 0.5, 0.05, 10, Color(0.28, 0.26, 0.24), Color(0.36, 0.34, 0.3))
	for i in range(4):
		var a2: float = TAU * float(i) / 4.0 + 0.5
		MeshKit.cylinder_between(wood, Vector3(cos(a2) * 0.55, 0.1, sin(a2) * 0.55), Vector3(0, 0.62, 0), 0.06, 0.045, 6, Color(0.55, 0.55, 0.55), Color.WHITE)
	for i in range(3):
		var a3: float = TAU * float(i) / 3.0 + 0.2
		MeshKit.cylinder_between(wood, Vector3(cos(a3) * 0.62, 0.05, sin(a3) * 0.62), Vector3(cos(a3) * 0.12, 1.35, sin(a3) * 0.12), 0.035, 0.03, 5)
	MeshKit.blob_smooth(iron, Vector3(0, 1.0, 0), Vector3(0.19, 0.15, 0.19), rng, Color(0.2, 0.2, 0.22), Color(0.4, 0.4, 0.43), 0.06, 8, 4)
	MeshKit.cylinder_at(iron, Vector3(0, 1.13, 0), 0.13, 0.15, 0.05, 8)
	root.add_child(_finish(b, [], "Ring"))
	VFX.fire(root, Vector3(0, 0.12, 0), 1.1)
	VFX.smoke(root, Vector3(0, 1.2, 0))
	BuildingKit.add_light(root, Vector3(0, 0.95, 0), Color(1.0, 0.55, 0.22), 2.2, 8.0, 0.06, true)
	return root

# ---------------------------------------------------------------------------
# Village arch - gateway sign over the approach road
# ---------------------------------------------------------------------------
static func make_arch(title: String) -> Node3D:
	var root := Node3D.new()
	root.name = "VillageArch"
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dark: SurfaceTool = b.surface("wood_dark")
	var roof: SurfaceTool = b.surface("roof_brown")
	var iron: SurfaceTool = b.surface("iron")
	var lantern: SurfaceTool = b.surface("lantern")
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(b.surface("stone"), Vector3(sx * 2.6, 0.25, 0), Vector3(0.62, 0.5, 0.62))
		MeshKit.box_at(dark, Vector3(sx * 2.6, 1.95, 0), Vector3(0.3, 3.4, 0.3))
		MeshKit.box_at(wood, Vector3(sx * 2.6, 2.55, 0.17), Vector3(0.05, 2.2, 0.05))
		MeshKit.box_at(iron, Vector3(sx * 2.6, 3.62, 0), Vector3(0.62, 0.1, 0.62))
		# Door lanterns hung from the posts
		MeshKit.box_at(lantern, Vector3(sx * 3.12, 2.45, 0.18), Vector3(0.2, 0.3, 0.2))
		MeshKit.box_at(iron, Vector3(sx * 3.12, 2.72, 0.12), Vector3(0.36, 0.05, 0.05))
	MeshKit.box_at(wood, Vector3(0, 3.52, 0), Vector3(6.3, 0.28, 0.4))
	MeshKit.box_at(dark, Vector3(0, 3.0, 0), Vector3(6.0, 0.16, 0.3))
	for sx in [-1.0, 1.0]:
		MeshKit.box(roof, Transform3D(Basis(Vector3.RIGHT, sx * 0.55), Vector3(0, 3.85, sx * 0.34)), Vector3(6.9, 0.1, 0.95))
	MeshKit.box_at(dark, Vector3(0, 4.02, 0), Vector3(7.0, 0.12, 0.16))
	# Hanging board with the settlement name, readable from both sides
	for sz in [1.0, -1.0]:
		MeshKit.box_at(dark, Vector3(0, 3.02, 0.16 * sz), Vector3(2.9, 0.72, 0.09))
		MeshKit.box_at(wood, Vector3(0, 3.02, 0.22 * sz), Vector3(2.7, 0.56, 0.05))
		var label := _label(title, 56, Color(1.0, 0.84, 0.42))
		label.pixel_size = 0.0036
		label.shaded = false
		label.outline_size = 12
		label.outline_modulate = Color(0.14, 0.08, 0.03)
		label.transform = Transform3D(Basis(Vector3.UP, 0.0 if sz > 0.0 else PI), Vector3(0, 3.04, 0.27 * sz))
		root.add_child(label)
	# Small pennants along the tie beam
	var pennants := func(st: SurfaceTool) -> void:
		var cols: Array[Color] = [Color(0.75, 0.16, 0.13), Color(0.93, 0.89, 0.78), Color(0.22, 0.35, 0.62)]
		for i in range(9):
			var x: float = -2.7 + float(i) * 0.675
			var c: Color = cols[i % cols.size()]
			MeshKit.flat_tri(st, Vector3(x - 0.18, 3.36, 0.22), Vector3(x + 0.18, 3.36, 0.22), Vector3(x, 3.02, 0.22), Vector3.BACK, c, c, c)
			MeshKit.flat_tri(st, Vector3(x - 0.18, 3.36, 0.22), Vector3(x, 3.02, 0.22), Vector3(x + 0.18, 3.36, 0.22), Vector3.FORWARD, c, c, c)
	_add_vc(root, pennants, true, "Pennants")
	var shapes: Array = [_box_shape(Vector3(0.42, 3.6, 0.42), Vector3(-2.6, 1.9, 0)),
		_box_shape(Vector3(0.42, 3.6, 0.42), Vector3(2.6, 1.9, 0))]
	root.add_child(_finish(b, shapes, "Body"))
	BuildingKit.add_light(root, Vector3(-3.12, 2.45, 0.3), Color(1.0, 0.6, 0.26), 1.6, 8.0, 0.05)
	BuildingKit.add_light(root, Vector3(3.12, 2.45, 0.3), Color(1.0, 0.6, 0.26), 1.6, 8.0, 0.05)
	return root

# ---------------------------------------------------------------------------
# Bunting - sagging rope of triangular cloth flags between two points
# ---------------------------------------------------------------------------
static func make_bunting(a: Vector3, b: Vector3, sag: float = 0.5) -> Node3D:
	var root := Node3D.new()
	root.name = "Bunting"
	var rope_col := Color(0.3, 0.24, 0.16)
	var cols: Array[Color] = [
		Color(0.78, 0.16, 0.13), Color(0.95, 0.9, 0.78), Color(0.2, 0.34, 0.64),
		Color(0.92, 0.72, 0.22),
	]
	var flags := func(st: SurfaceTool) -> void:
		var span: float = a.distance_to(b)
		var segs: int = maxi(6, int(span / 0.8))
		var prev := a
		for i in range(1, segs + 1):
			var t: float = float(i) / float(segs)
			var p := a.lerp(b, t) + Vector3(0, -sin(t * PI) * sag, 0)
			MeshKit.cylinder_between(st, prev, p, 0.014, 0.014, 4, rope_col, rope_col)
			prev = p
		var count: int = maxi(3, int(span / 0.85))
		var flat := Vector3(b.x - a.x, 0, b.z - a.z).normalized()
		var side := Vector3(-flat.z, 0, flat.x)
		for i in range(count):
			var t2: float = (float(i) + 0.5) / float(count)
			var p2 := a.lerp(b, t2) + Vector3(0, -sin(t2 * PI) * sag, 0)
			var c: Color = cols[i % cols.size()]
			for sgn in [1.0, -1.0]:
				var out: Vector3 = side * sgn
				MeshKit.flat_tri(st,
					p2 - flat * 0.21, p2 + flat * 0.21,
					p2 + Vector3(0, -0.36, 0),
					out, c, c, c.darkened(0.06))
	_add_vc(root, flags, true, "Cloth")
	return root
