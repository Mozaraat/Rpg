extends Node

## Semidiurnal lunar tide approximation for the overworld.
## The ocean surface, wet shoreline shader and aquatic gameplay read this shared value.

signal tide_changed(level: float, phase_name: String)

@export_range(0.1, 3.0, 0.05) var tide_amplitude_m: float = 1.25
@export_range(2.0, 30.0, 0.1) var spring_neap_period_days: float = 14.77

var current_level: float = Constants.WATER_LEVEL
var current_strength: float = 0.0
var phase_name: String = "Rising tide"
var _update_timer: float = 0.0
var _absolute_day: float = 0.0
var _phase_angle: float = 0.0
var _last_emitted_phase: String = ""

const LUNAR_DAY_DAYS: float = 1.035
const UPDATE_INTERVAL: float = 0.16

func _ready() -> void:
	add_to_group("tide_system")
	current_level = Constants.WATER_LEVEL

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_update_timer += delta
	var day_node := get_tree().get_first_node_in_group("day_night")
	var day_phase := float(day_node.get("time_of_day")) if day_node != null else 0.0
	_absolute_day = float(LivingWorldSystem.get_world_day()) + day_phase
	_phase_angle = TAU * 2.0 * _absolute_day / LUNAR_DAY_DAYS
	var spring_phase := TAU * _absolute_day / spring_neap_period_days
	var spring_neap := 0.58 + 0.42 * (0.5 + 0.5 * cos(spring_phase))
	var semidiurnal_wave := 0.84 * sin(_phase_angle) + 0.16 * sin((_phase_angle * 2.0) + 0.35)
	current_level = Constants.WATER_LEVEL + tide_amplitude_m * spring_neap * semidiurnal_wave
	var tide_slope := 0.84 * cos(_phase_angle) + 0.32 * cos((_phase_angle * 2.0) + 0.35)
	current_strength = clampf(absf(tide_slope) / 1.16 * spring_neap, 0.0, 1.0)
	if absf(tide_slope) < 0.07:
		phase_name = "High tide" if semidiurnal_wave >= 0.0 else "Low tide"
	elif tide_slope > 0.0:
		phase_name = "Rising tide"
	else:
		phase_name = "Falling tide"
	if _update_timer >= UPDATE_INTERVAL:
		_update_timer = 0.0
		for manager in get_tree().get_nodes_in_group("chunk_manager"):
			if manager.has_method("set_tide_level"):
				manager.set_tide_level(current_level)
		if phase_name != _last_emitted_phase:
			_last_emitted_phase = phase_name
			tide_changed.emit(current_level, phase_name)

func get_water_level() -> float:
	return current_level

## The tide only lifts deep ocean beds. Inland streams, rivers and lakes keep the
## base level so they never drain at low tide or flood their banks at high tide.
func level_at_bed(bed: float) -> float:
	return Constants.WATER_LEVEL + (current_level - Constants.WATER_LEVEL) * (1.0 - smoothstep(-2.4, -1.4, bed))

func level_at(x: float, z: float) -> float:
	var bed: float = -3.0
	var cm := get_tree().get_first_node_in_group("chunk_manager")
	if cm != null and cm.noise != null:
		bed = cm.noise.get_height(x, z)
	return level_at_bed(bed)

func get_status_text() -> String:
	var offset := current_level - Constants.WATER_LEVEL
	var signed_offset := "+%.2f" % offset if offset >= 0.0 else "%.2f" % offset
	var display_phase := phase_name.to_upper().replace(" TIDE", "")
	return "TIDE  %s  %sm" % [display_phase, signed_offset]

func get_current_vector(_position: Vector3 = Vector3.ZERO) -> Vector3:
	var direction := Vector3(cos(_phase_angle * 0.5), 0.0, sin(_phase_angle * 0.5)).normalized()
	return direction * current_strength

func get_current_strength() -> float:
	return current_strength

func is_high_tide() -> bool:
	return phase_name == "High tide"

func is_low_tide() -> bool:
	return phase_name == "Low tide"
