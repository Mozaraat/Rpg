# Expedition coordinator. Stores party/run metadata separately from character progression.
# Network transport is intentionally delegated to a future authoritative server backend.
extends Node

signal expedition_changed(data: Dictionary)
signal leaderboard_changed(entries: Array)

const LEADERBOARD_PATH: String = "user://dungeon_expedition_records.json"
var active: bool = false
var expedition_id: String = ""
var leader_peer_id: int = 1
var party_peer_ids: Array[int] = [1]
var deepest_floor: int = 0
var secured_floor: int = 0
var floors_cleared: int = 0
var deaths: int = 0
var elapsed_seconds: float = 0.0
var supplies: int = 8
var event_log: Array[String] = []
var records: Array[Dictionary] = []

func _ready() -> void:
	_load_records()

func start_expedition(peer_ids: Array = []) -> void:
	active = true
	expedition_id = "ELY-%d-%d" % [int(Time.get_unix_time_from_system()), randi_range(1000, 9999)]
	party_peer_ids.clear()
	for raw_id in peer_ids:
		var peer_id: int = int(raw_id)
		if peer_id > 0 and not party_peer_ids.has(peer_id):
			party_peer_ids.append(peer_id)
	if party_peer_ids.is_empty():
		party_peer_ids.append(1)
	leader_peer_id = party_peer_ids[0]
	deepest_floor = 1
	secured_floor = 1
	floors_cleared = 0
	deaths = 0
	elapsed_seconds = 0.0
	supplies = 8
	event_log.clear()
	_log("Expedition %s formed" % expedition_id)
	_emit_changed()

func _process(delta: float) -> void:
	if active:
		elapsed_seconds += delta

func add_member(peer_id: int) -> bool:
	if not active or peer_id <= 0 or party_peer_ids.has(peer_id) or party_peer_ids.size() >= PartySystem.MAX_PARTY_SIZE:
		return false
	party_peer_ids.append(peer_id)
	_log("Peer %d joined the expedition" % peer_id)
	_emit_changed()
	return true

func remove_member(peer_id: int) -> void:
	party_peer_ids.erase(peer_id)
	if party_peer_ids.is_empty():
		finish_expedition(false)
	elif leader_peer_id == peer_id:
		leader_peer_id = party_peer_ids[0]
	_emit_changed()

func on_floor_entered(floor_number: int) -> void:
	if not active:
		start_expedition([1])
	deepest_floor = maxi(deepest_floor, floor_number)
	if floor_number > secured_floor:
		if supplies > 0:
			supplies -= 1
		else:
			EventBus.toast.emit("Expedition supplies depleted! Rest at the next sanctuary.", "warning")
	_log("Reached floor %d" % floor_number)
	_emit_changed()

func secure_checkpoint(floor_number: int) -> void:
	secured_floor = maxi(secured_floor, floor_number)
	deepest_floor = maxi(deepest_floor, floor_number)
	floors_cleared = maxi(floors_cleared, floor_number - 1)
	supplies = mini(supplies + 3, 12)
	_log("Checkpoint secured at floor %d" % floor_number)
	_emit_changed()

func record_death() -> void:
	deaths += 1
	_log("A party member fell in the depths")
	_emit_changed()

func consume_supply(amount: int = 1) -> bool:
	if supplies < amount:
		return false
	supplies -= amount
	_emit_changed()
	return true

func restore_supplies(amount: int) -> void:
	supplies = mini(supplies + maxi(amount, 0), 12)
	_emit_changed()

func finish_expedition(success: bool) -> void:
	if not active:
		return
	active = false
	var entry: Dictionary = {
		"expedition_id": expedition_id,
		"deepest_floor": deepest_floor,
		"secured_floor": secured_floor,
		"party_size": party_peer_ids.size(),
		"deaths": deaths,
		"duration": int(elapsed_seconds),
		"success": success,
		"timestamp": int(Time.get_unix_time_from_system())
	}
	records.append(entry)
	records.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if int(a.get("deepest_floor", 0)) == int(b.get("deepest_floor", 0)):
			return int(a.get("duration", 0)) > int(b.get("duration", 0))
		return int(a.get("deepest_floor", 0)) > int(b.get("deepest_floor", 0)))
	while records.size() > 50:
		records.pop_back()
	_save_records()
	leaderboard_changed.emit(records.duplicate(true))
	_log("Expedition ended at floor %d" % deepest_floor)
	_emit_changed()

func get_snapshot() -> Dictionary:
	return {"active": active, "expedition_id": expedition_id, "leader_peer_id": leader_peer_id,
		"party_peer_ids": party_peer_ids.duplicate(), "deepest_floor": deepest_floor,
		"secured_floor": secured_floor, "floors_cleared": floors_cleared,
		"deaths": deaths, "elapsed_seconds": elapsed_seconds, "supplies": supplies}

func _log(message: String) -> void:
	event_log.append(message)
	while event_log.size() > 30:
		event_log.pop_front()

func _emit_changed() -> void:
	expedition_changed.emit(get_snapshot())

func _load_records() -> void:
	if not FileAccess.file_exists(LEADERBOARD_PATH):
		return
	var file := FileAccess.open(LEADERBOARD_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Array:
		for row in parsed:
			if row is Dictionary:
				records.append(row)
	leaderboard_changed.emit(records.duplicate(true))

func _save_records() -> void:
	var file := FileAccess.open(LEADERBOARD_PATH, FileAccess.WRITE)
	if file == null:
		push_warning("Could not save expedition leaderboard")
		return
	file.store_string(JSON.stringify(records, "\t"))
	file.close()

func restore_snapshot(snapshot: Dictionary) -> void:
	active = bool(snapshot.get("active", false))
	expedition_id = str(snapshot.get("expedition_id", ""))
	leader_peer_id = int(snapshot.get("leader_peer_id", 1))
	party_peer_ids.clear()
	for raw_id in snapshot.get("party_peer_ids", [1]):
		party_peer_ids.append(int(raw_id))
	if party_peer_ids.is_empty():
		party_peer_ids.append(1)
	deepest_floor = int(snapshot.get("deepest_floor", 1))
	secured_floor = int(snapshot.get("secured_floor", 1))
	floors_cleared = int(snapshot.get("floors_cleared", 0))
	deaths = int(snapshot.get("deaths", 0))
	elapsed_seconds = float(snapshot.get("elapsed_seconds", 0.0))
	supplies = int(snapshot.get("supplies", 8))
	_emit_changed()
