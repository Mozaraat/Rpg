extends Node

## Authoritative long-lived simulation for regional ecology, sect populations,
## migration, territorial pressure, resources and world events.
## State is JSON-safe and stored through MMORPGWorldState (server authority only online).

signal regional_event_started(region_id: String, event_id: String)
signal regional_event_ended(region_id: String, event_id: String)
signal world_state_changed(revision: int)

const TICK_SECONDS: float = 75.0
const MAX_OFFLINE_TICKS: int = 8
const SECTION_KEY: String = "simulation"

const REGIONS: Array[Dictionary] = [
	{"id":"frostveil", "rx":118.0, "rz":104.0, "name":"Frostveil Continent", "center":[-250.0,-200.0], "neighbors":["ironback","whispering_woods"], "populations":{"frost_lynx":42,"grey_wolf":34,"snowstag":58}, "resources":{"herbs":52.0,"timber":38.0,"ore":62.0,"fish":18.0,"spirit_motes":35.0}},
	{"id":"cinderwake", "rx":48.0, "rz":42.0, "name":"Cinderwake Continent", "center":[220.0,150.0], "neighbors":["sunscorch","emberfall"], "populations":{"ember_wyrm":8,"ash_imp":43,"cinder_hound":37}, "resources":{"herbs":20.0,"timber":12.0,"ore":76.0,"fish":8.0,"spirit_motes":28.0}},
	{"id":"mirrorwater", "rx":38.0, "rz":31.0, "name":"Mirrorwater Basin", "center":[47.0,-9.0], "neighbors":["elyndor","amberleaf","ironback"], "populations":{"reef_crab":72,"drowned_guard":16,"tide_serpent":5}, "resources":{"herbs":48.0,"timber":26.0,"ore":22.0,"fish":82.0,"spirit_motes":44.0}},
	{"id":"elyndor", "rx":62.0, "rz":58.0, "name":"Elyndor Heartlands", "center":[-25.0,-30.0], "neighbors":["mirrorwater","whispering_woods","amberleaf"], "populations":{"grey_wolf":22,"deer":46,"rabbit":58,"boar":24,"slime":48,"bandit":18}, "resources":{"herbs":68.0,"timber":52.0,"ore":36.0,"fish":35.0,"spirit_motes":40.0}},
	{"id":"whispering_woods", "rx":82.0, "rz":76.0, "name":"Whispering Woods", "center":[-112.0,12.0], "neighbors":["elyndor","frostveil","mirefen","amberleaf"], "populations":{"fungal_stalker":34,"grave_hound":17,"grey_wolf":49}, "resources":{"herbs":85.0,"timber":91.0,"ore":24.0,"fish":28.0,"spirit_motes":58.0}},
	{"id":"amberleaf", "rx":72.0, "rz":58.0, "name":"Amberleaf Glade", "center":[18.0,-112.0], "neighbors":["elyndor","mirrorwater","ironback","whispering_woods"], "populations":{"rootbound_guardian":12,"moonpetal_deer":56,"spore_moth":32}, "resources":{"herbs":94.0,"timber":72.0,"ore":18.0,"fish":20.0,"spirit_motes":67.0}},
	{"id":"ironback", "rx":88.0, "rz":72.0, "name":"Ironback Range", "center":[132.0,-104.0], "neighbors":["mirrorwater","amberleaf","frostveil","emberfall"], "populations":{"stone_crawler":45,"frost_lynx":18,"bronze_sentinel":12}, "resources":{"herbs":25.0,"timber":33.0,"ore":95.0,"fish":10.0,"spirit_motes":46.0}},
	{"id":"mirefen", "rx":72.0, "rz":64.0, "name":"Mirefen Wetlands", "center":[-150.0,112.0], "neighbors":["whispering_woods","sunscorch"], "populations":{"abyss_mantis":26,"fungal_stalker":42,"reef_crab":28}, "resources":{"herbs":82.0,"timber":37.0,"ore":15.0,"fish":75.0,"spirit_motes":52.0}},
	{"id":"sunscorch", "rx":78.0, "rz":68.0, "name":"Sunscorch Expanse", "center":[148.0,104.0], "neighbors":["mirefen","cinderwake","emberfall"], "populations":{"ash_imp":52,"cinder_hound":30,"stone_crawler":16}, "resources":{"herbs":17.0,"timber":9.0,"ore":72.0,"fish":8.0,"spirit_motes":31.0}},
	{"id":"emberfall", "rx":54.0, "rz":76.0, "name":"Emberfall Reach", "center":[206.0,-8.0], "neighbors":["ironback","sunscorch","cinderwake"], "populations":{"ember_wyrm":14,"ash_imp":35,"night_wisp":24}, "resources":{"herbs":24.0,"timber":18.0,"ore":83.0,"fish":14.0,"spirit_motes":61.0}},
	{"id":"greenveil", "rx":112.0, "rz":94.0, "name":"Greenveil Rainforest", "center":[-450.0,120.0], "neighbors":["mirefen","whispering_woods"], "populations":{"deer":38,"boar":34,"fungal_stalker":28}, "resources":{"herbs":96.0,"timber":94.0,"ore":18.0,"fish":34.0,"spirit_motes":72.0}},
	{"id":"thornwild", "rx":118.0, "rz":102.0, "name":"Thornwild Jungle", "center":[420.0,-60.0], "neighbors":["emberfall","sunscorch"], "populations":{"boar":42,"grey_wolf":22,"abyss_mantis":24}, "resources":{"herbs":88.0,"timber":86.0,"ore":28.0,"fish":22.0,"spirit_motes":64.0}}
]

const SECT_DEFINITIONS: Array[Dictionary] = [
	{"id":"azure_sword_hall","name":"Azure Sword Hall","rival":"crimson_pavilion","region":"elyndor","members":84},
	{"id":"crimson_pavilion","name":"Crimson Phoenix Pavilion","rival":"azure_sword_hall","region":"emberfall","members":76},
	{"id":"stillwater_monastery","name":"Stillwater Monastery","rival":"stormspire_order","region":"mirrorwater","members":71},
	{"id":"stormspire_order","name":"Stormspire Order","rival":"stillwater_monastery","region":"ironback","members":68},
	{"id":"veiled_moon_covenant","name":"Veiled Moon Covenant","rival":"rootbound_circle","region":"whispering_woods","members":55},
	{"id":"rootbound_circle","name":"Rootbound Circle","rival":"veiled_moon_covenant","region":"amberleaf","members":93}
]

const EVENT_DEFINITIONS: Array[Dictionary] = [
	{"id":"beast_migration","title":"Great Beast Migration","detail":"Herds and predators are moving between neighbouring territories. Hunting grounds will shift for a time.","duration":5},
	{"id":"predator_war","title":"Territorial Hunt","detail":"Two dominant packs are contesting hunting ground. Prey numbers are falling where their trails meet.","duration":4},
	{"id":"spirit_bloom","title":"Spirit Bloom","detail":"A surge of spiritual energy has awakened rare herbs and spirit motes across the region.","duration":5},
	{"id":"bandit_raid","title":"Bandit Incursion","detail":"A roaming band has disrupted trade and is stripping nearby stores of supplies.","duration":4},
	{"id":"sect_tournament","title":"Sect Tournament","detail":"Disciples and masters have gathered for a public tournament. Sect influence and recruitment are shifting.","duration":4},
	{"id":"resource_boom","title":"Resource Vein Exposed","detail":"A newly exposed seam is drawing miners and gatherers. Local materials are unusually plentiful.","duration":5},
	{"id":"blight","title":"Lingering Blight","detail":"A spreading blight is weakening local growth and driving creatures away from tainted ground.","duration":4},
	{"id":"apex_beast","title":"Apex Beast Awakened","detail":"An ancient territorial beast has emerged. The region's creatures are fleeing its hunting ground.","duration":10}
]

const BOSS_PROFILES: Dictionary = {
	"frostveil":{"monster_id":"frost_lynx","name":"Frostveil Crownfang","hp":920.0,"damage":34.0,"pattern":"frost_ring","reward":"ancient_scale","color":[0.52,0.78,0.98]},
	"cinderwake":{"monster_id":"ember_wyrm","name":"Cinderwake Ash Sovereign","hp":1120.0,"damage":42.0,"pattern":"ash_cone","reward":"dragonbone","color":[1.0,0.34,0.12]},
	"mirrorwater":{"monster_id":"tide_serpent","name":"Mirrorwater Abyssal Coil","hp":1050.0,"damage":38.0,"pattern":"tide_surge","reward":"heart_of_depths","color":[0.18,0.62,0.9]},
	"elyndor":{"monster_id":"rootbound_guardian","name":"Elyndor Elderroot","hp":900.0,"damage":32.0,"pattern":"root_snare","reward":"runebound_core","color":[0.35,0.72,0.32]},
	"whispering_woods":{"monster_id":"grave_hound","name":"Whispering Dreadstalker","hp":880.0,"damage":36.0,"pattern":"void_fold","reward":"voidsilk","color":[0.38,0.28,0.62]},
	"amberleaf":{"monster_id":"fungal_stalker","name":"Amberleaf Spore Matriarch","hp":940.0,"damage":30.0,"pattern":"spore_cloud","reward":"spore_sac","color":[0.44,0.78,0.42]},
	"ironback":{"monster_id":"stone_crawler","name":"Ironback Mountain-Tyrant","hp":1250.0,"damage":44.0,"pattern":"bronze_lance","reward":"runebound_core","color":[0.66,0.58,0.42]},
	"mirefen":{"monster_id":"abyss_mantis","name":"Mirefen Drowned Sovereign","hp":980.0,"damage":39.0,"pattern":"grave_pulse","reward":"abyssal_chitin","color":[0.28,0.56,0.48]},
	"sunscorch":{"monster_id":"ash_imp","name":"Sunscorch Furnace Devil","hp":900.0,"damage":37.0,"pattern":"ash_cone","reward":"cinder_core","color":[0.95,0.48,0.18]},
	"emberfall":{"monster_id":"ember_wyrm","name":"Emberfall Star-Eater","hp":1350.0,"damage":48.0,"pattern":"astral_orbit","reward":"celestial_codex","color":[0.86,0.48,0.28]},
	"greenveil":{"monster_id":"fungal_stalker","name":"Greenveil Ancient Bloom","hp":1180.0,"damage":39.0,"pattern":"spore_cloud","reward":"spore_sac","color":[0.28,0.72,0.36]},
	"thornwild":{"monster_id":"abyss_mantis","name":"Thornwild Razor Matriarch","hp":1260.0,"damage":43.0,"pattern":"grave_pulse","reward":"abyssal_chitin","color":[0.24,0.56,0.32]}
}

var _state: Dictionary = {}
var _tick_timer: float = TICK_SECONDS
var _ready_state: bool = false
var _server_snapshot_revision: int = -1
var _apex_retry_timer: float = 12.0
var _region_last_spawn: Dictionary = {}
var _last_gather_request_at: Dictionary = {}
var _population_revisions: Dictionary = {}
var _territory_revisions: Dictionary = {}
var _population_save_pending: bool = false
var _territory_save_pending: bool = false
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	add_to_group("world_life_simulation")
	_rng.randomize()
	_load_state()
	if MMORPGNetwork.is_authority() and WorldDeploymentGuard.production_mode and CentralBackend.is_configured():
		await _restore_persistent_populations()
		await _restore_persistent_territories()
		_persist()
	_ready_state = true
	if MMORPGNetwork.is_authority():
		_catch_up_offline()

func _process(delta: float) -> void:
	if not _ready_state or GameManager.current_state != GameManager.GameState.PLAYING:
		return
	if not MMORPGNetwork.is_authority():
		return
	_apex_retry_timer -= delta
	if _apex_retry_timer <= 0.0:
		_apex_retry_timer = 18.0
		_ensure_active_apex_bosses()
	_tick_timer -= delta
	if _tick_timer > 0.0:
		return
	_tick_timer = TICK_SECONDS
	_simulate_tick()

func _load_state() -> void:
	var saved: Variant = MMORPGWorldState.get_world_value("living_world", SECTION_KEY, {})
	if saved is Dictionary and not saved.is_empty():
		_state = saved.duplicate(true)
	else:
		_state = _create_initial_state()
		if not (WorldDeploymentGuard.production_mode and CentralBackend.is_configured()):
			_persist()
	# Forward-compatible defaults for state created by earlier milestone versions.
	if not _state.has("regions"):
		_state["regions"] = _create_initial_state()["regions"]
	if not _state.has("sects"):
		_state["sects"] = _create_initial_state()["sects"]
	if not _state.has("event_history"):
		_state["event_history"] = []
	if not (_state.get("caravan_reservations", {}) is Dictionary):
		_state["caravan_reservations"] = {}
	var saved_regions: Dictionary = _state.get("regions", {}).duplicate(true)
	for saved_region_id in saved_regions.keys():
		var saved_region: Dictionary = saved_regions[saved_region_id]
		if not (saved_region.get("economy", {}) is Dictionary):
			saved_region["economy"] = {"food":42.0,"timber":24.0,"ore":18.0,"herbs":16.0}
		if not (saved_region.get("prices", {}) is Dictionary):
			saved_region["prices"] = {"food":4.0,"timber":7.0,"ore":12.0,"herbs":9.0}
		saved_regions[saved_region_id] = saved_region
	_state["regions"] = saved_regions
	# Older builds placed Crimson Phoenix on the Cinderwake island even though its
	# headquarters and territory markers are in Emberfall Reach. Normalize saved worlds.
	var territory_fixes: Dictionary = {
		"azure_sword_hall":"elyndor",
		"crimson_pavilion":"emberfall",
		"stillwater_monastery":"mirrorwater",
		"stormspire_order":"ironback",
		"veiled_moon_covenant":"whispering_woods",
		"rootbound_circle":"amberleaf"
	}
	var saved_sects: Variant = _state.get("sects", {})
	if saved_sects is Dictionary:
		var normalized_sects: Dictionary = saved_sects.duplicate(true)
		var territory_changed: bool = false
		for sect_id in territory_fixes:
			var sect_value: Variant = normalized_sects.get(sect_id, {})
			if sect_value is Dictionary and str(sect_value.get("territory", "")) != str(territory_fixes[sect_id]):
				sect_value["territory"] = territory_fixes[sect_id]
				normalized_sects[sect_id] = sect_value
				territory_changed = true
		if territory_changed:
			_state["sects"] = normalized_sects
			_persist()

func _create_initial_state() -> Dictionary:
	var regions: Dictionary = {}
	for definition in REGIONS:
		regions[str(definition.get("id", ""))] = {
			"name":str(definition.get("name", "Unknown")),
			"populations":definition.get("populations", {}).duplicate(true),
			"resources":definition.get("resources", {}).duplicate(true),
			"territory_pressure":{},
			"event":{},
			"settlement_supply":100.0,
			"economy":{"food":42.0,"timber":24.0,"ore":18.0,"herbs":16.0},
			"prices":{"food":4.0,"timber":7.0,"ore":12.0,"herbs":9.0},
			"last_change":"The region is following its usual seasonal rhythm."
		}
	var sects: Dictionary = {}
	for definition in SECT_DEFINITIONS:
		sects[str(definition.get("id", ""))] = {
			"name":str(definition.get("name", "Unknown")),
			"members":int(definition.get("members", 0)),
			"influence":50.0,
			"territory":str(definition.get("region", "")),
			"rival":str(definition.get("rival", "")),
			"rivalry":52.0 if str(definition.get("rival", "")) != "" else 0.0,
			"recruitment_pressure":0.0,
			"victories":0,
			"defeats":0
		}
	return {"version":1,"last_tick_unix":Time.get_unix_time_from_system(),"regions":regions,"sects":sects,"event_history":[],"boss_defeats":{},"world_month":0}

func _catch_up_offline() -> void:
	var previous: int = int(_state.get("last_tick_unix", Time.get_unix_time_from_system()))
	var elapsed: int = maxi(0, int(Time.get_unix_time_from_system()) - previous)
	var ticks: int = mini(MAX_OFFLINE_TICKS, int(elapsed / int(TICK_SECONDS * 4.0)))
	for _i in range(ticks):
		_simulate_tick(false)
	if ticks > 0:
		EventBus.activity.emit("The regions have continued to change while you were away (%d world cycles)." % ticks, "world")

const GOVERNANCE_POLICIES: Dictionary = {
	"balanced": {"food": 1.0, "security": 1.0, "recovery": 1.0, "conservation": 1.0},
	"provisioning": {"food": 1.7, "security": 0.8, "recovery": 1.2, "conservation": 0.7},
	"security": {"food": 1.0, "security": 1.8, "recovery": 0.9, "conservation": 0.7},
	"stewardship": {"food": 1.0, "security": 0.7, "recovery": 1.0, "conservation": 1.8},
	"hands_off": {"food": 0.0, "security": 0.0, "recovery": 0.0, "conservation": 0.0}
}

func set_governance_policy(policy: String) -> bool:
	if not MMORPGNetwork.is_authority() or not GOVERNANCE_POLICIES.has(policy):
		return false
	_state["governance_policy"] = policy
	_persist()
	return true

func get_governance_report() -> Dictionary:
	return {"policy": str(_state.get("governance_policy", "balanced")), "decisions": _state.get("governance_history", []).duplicate(true)}

func _govern_region(region_id: String, entry: Dictionary) -> void:
	var policy: Dictionary = GOVERNANCE_POLICIES.get(str(_state.get("governance_policy", "balanced")), GOVERNANCE_POLICIES.balanced)
	var economy: Dictionary = entry.get("economy", {})
	var resources: Dictionary = entry.get("resources", {})
	var food := float(economy.get("food", 0.0))
	var supply := float(entry.get("settlement_supply", 100.0))
	var pressures: Dictionary = entry.get("territory_pressure", {})
	var threat := ""
	var pressure := 0.0
	for faction in pressures:
		if float(pressures[faction]) > pressure:
			threat = str(faction)
			pressure = float(pressures[faction])
	var reserve := ""
	var reserve_value := 100.0
	for key in resources:
		if str(key) not in ["herbs", "timber", "fish"]:
			continue
		if float(resources[key]) < reserve_value:
			reserve = str(key)
			reserve_value = float(resources[key])
	var candidates: Array[Dictionary] = []
	if food < 30.0 and float(resources.get("herbs", 0.0)) >= 4.0 and float(economy.get("timber", 0.0)) >= 1.0:
		candidates.append({"action": "food", "score": (30.0 - food) * float(policy.food), "reason": "Low food stocks; send provisioners to gather edible plants."})
	if pressure > 20.0 and food >= 3.0 and float(economy.get("ore", 0.0)) >= 1.0:
		candidates.append({"action": "security", "score": pressure * float(policy.security), "reason": "Territorial pressure; provision a defensive patrol."})
	if supply < 85.0 and food >= 2.0 and float(economy.get("herbs", 0.0)) >= 2.0:
		candidates.append({"action": "recovery", "score": (100.0 - supply) * float(policy.recovery), "reason": "Settlement hardship; distribute food and medical supplies."})
	if reserve != "" and reserve_value < 40.0 and food >= 2.0:
		candidates.append({"action": "conservation", "score": (40.0 - reserve_value) * float(policy.conservation), "reason": "Depleted reserves; fund habitat restoration and reduced extraction."})
	var choice: Dictionary = {}
	for candidate in candidates:
		if float(candidate.score) > float(choice.get("score", 0.0)):
			choice = candidate
	if choice.is_empty():
		return
	match str(choice.action):
		"food":
			resources["herbs"] = float(resources.herbs) - 4.0
			economy["timber"] = float(economy.timber) - 1.0
			economy["food"] = food + 8.0
		"security":
			economy["food"] = food - 3.0
			economy["ore"] = float(economy.ore) - 1.0
			pressures[threat] = maxf(0.0, pressure - 6.0)
			entry["territory_pressure"] = pressures
		"recovery":
			economy["food"] = food - 2.0
			economy["herbs"] = float(economy.herbs) - 2.0
			entry["settlement_supply"] = minf(100.0, supply + 6.0)
		"conservation":
			economy["food"] = food - 2.0
			resources[reserve] = minf(100.0, reserve_value + 4.0)
	entry["economy"] = economy
	entry["resources"] = resources
	entry["governance_decision"] = choice.reason
	var history: Array = _state.get("governance_history", [])
	history.append({"region": str(entry.get("name", region_id)), "action": choice.action, "reason": choice.reason, "month": int(_state.get("world_month", 0))})
	_state["governance_history"] = _trim_history(history, 48)

func _simulate_tick(announce: bool = true) -> void:
	if not MMORPGNetwork.is_authority():
		return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var sects: Dictionary = _state.get("sects", {}).duplicate(true)
	var event_history: Array = _state.get("event_history", []).duplicate(true)
	var active_count: int = 0
	for rid in regions.keys():
		var entry: Dictionary = regions[rid]
		var populations: Dictionary = entry.get("populations", {}).duplicate(true)
		var resources: Dictionary = entry.get("resources", {}).duplicate(true)
		var active_event: Dictionary = entry.get("event", {}).duplicate(true)
		if not active_event.is_empty():
			active_count += 1
			active_event["remaining"] = int(active_event.get("remaining", 1)) - 1
			if int(active_event["remaining"]) <= 0 and str(active_event.get("id", "")) != "apex_beast":
				event_history.append({"region":str(entry.get("name", rid)),"event":str(active_event.get("title", "Regional event")),"ended_at":Time.get_unix_time_from_system()})
				if announce:
					regional_event_ended.emit(str(rid), str(active_event.get("id", "")))
				active_event = {}
			else:
				entry["event"] = active_event
		# Population renewal is species-specific; predators depend on nearby prey stock.
		for species in populations.keys():
			var value: float = float(populations[species])
			var is_predator: bool = str(species) in ["frost_lynx","grey_wolf","cinder_hound","grave_hound","abyss_mantis","ember_wyrm","tide_serpent","rootbound_guardian"]
			var growth: float = -0.45 if is_predator else 0.7
			if is_predator:
				var prey_total: float = 0.0
				for prey in populations.keys():
					if str(prey) != str(species):
						prey_total += float(populations[prey])
				growth = 0.28 if prey_total > 70.0 else -0.75
			value = clampf(value + growth + randf_range(-0.8, 0.8), 0.0, 160.0)
			populations[species] = int(round(value))
		# Resource regeneration; events alter carrying capacity and local supply.
		for resource in resources.keys():
			var regen: float = 1.25 if str(resource) in ["herbs","timber","fish"] else 0.85
			resources[resource] = clampf(float(resources[resource]) + regen, 0.0, 100.0)
		entry["populations"] = populations
		entry["resources"] = resources
		entry["event"] = active_event
		var economy: Dictionary = entry.get("economy", {}).duplicate(true)
		var prices: Dictionary = entry.get("prices", {}).duplicate(true)
		# Settlements consume food every world cycle. Production and caravans replenish it.
		economy["food"] = maxf(0.0, float(economy.get("food", 42.0)) - 2.4)
		for commodity in ["food", "timber", "ore", "herbs"]:
			var base_price: float = {"food":4.0,"timber":7.0,"ore":12.0,"herbs":9.0}.get(commodity, 5.0)
			var stock: float = float(economy.get(commodity, 0.0))
			var scarcity: float = clampf((35.0 - stock) / 35.0, -0.5, 2.5)
			prices[commodity] = snappedf(base_price * (1.0 + scarcity * 0.55), 0.1)
		var food_stock: float = float(economy.get("food", 0.0))
		var supply_delta: float = 0.9 if food_stock >= 18.0 else (-2.8 if food_stock < 6.0 else -0.8)
		entry["settlement_supply"] = clampf(float(entry.get("settlement_supply", 100.0)) + supply_delta, 0.0, 100.0)
		entry["economy"] = economy
		entry["prices"] = prices
		if food_stock < 6.0:
			entry["last_change"] = "Food stores are critically low; prices are rising and settlement growth is slowing."
		_govern_region(str(rid), entry)
		regions[rid] = entry
	# Migration moves a share of overfull species toward a neighbouring region with room.
	_migrate_populations(regions)
	# Rival sects contest influence, recruit, and gradually alter their regional balance.
	for sect_id in sects.keys():
		var sect: Dictionary = sects[sect_id]
		var members: int = int(sect.get("members", 0))
		var recruitment: float = 1.0 if float(sect.get("influence", 50.0)) > 35.0 else 0.0
		members = clampi(members + (1 if randf() < 0.35 + recruitment * 0.2 else 0), 5, 600)
		sect["members"] = members
		sect["influence"] = clampf(float(sect.get("influence", 50.0)) + randf_range(-1.4, 1.3), 0.0, 100.0)
		sect["rivalry"] = clampf(float(sect.get("rivalry", 52.0)) + randf_range(-0.8, 1.8), 0.0, 100.0)
		sect["recruitment_pressure"] = maxf(0.0, float(sect.get("recruitment_pressure", 0.0)) - 2.0)
		sects[sect_id] = sect
	# Strong rivalries can escalate into a real regional sect clash.
	if active_count < 3 and randf() < 0.08:
		var clash: Dictionary = _highest_rivalry_pair(sects)
		if not clash.is_empty():
			var clash_region: String = str(clash.get("region", "elyndor"))
			var clash_data: Dictionary = regions.get(clash_region, {})
			var current_event: Dictionary = clash_data.get("event", {})
			if current_event.is_empty():
				_start_sect_clash(clash_region, clash, clash_data, regions, sects, event_history, announce)
				active_count += 1
	# New incidents are rare enough to remain meaningful; keep the shared world readable.
	if active_count < 3:
		for rid in regions.keys():
			var entry2: Dictionary = regions[rid]
			var event_value: Variant = entry2.get("event", {})
			if event_value is Dictionary and event_value.is_empty() and randf() < 0.075:
				_start_regional_event(str(rid), entry2, regions, sects, event_history, announce)
				break
	_state["regions"] = regions
	_state["sects"] = sects
	_state["event_history"] = _trim_history(event_history, 80)
	_state["last_tick_unix"] = Time.get_unix_time_from_system()
	_state["world_month"] = int(_state.get("world_month", 0)) + 1
	_persist()
	var elyndor_region: Dictionary = regions.get("elyndor", {})
	var elyndor_food: float = float(elyndor_region.get("economy", {}).get("food", 0.0))
	var settlement_growth: Node = get_tree().get_first_node_in_group("settlement_growth")
	if settlement_growth and settlement_growth.has_method("add_progress"):
		if elyndor_food < 6.0:
			settlement_growth.add_progress("elyndor", -0.7, "food shortage")
		elif elyndor_food >= 24.0:
			settlement_growth.add_progress("elyndor", 0.25, "steady food supply")

func _migrate_populations(regions: Dictionary) -> void:
	for region_id in regions.keys():
		var region: Dictionary = regions[region_id]
		var neighbors: Array = _region_definition(str(region_id)).get("neighbors", [])
		if neighbors.is_empty():
			continue
		var populations: Dictionary = region.get("populations", {}).duplicate(true)
		for species in populations.keys():
			var current: int = int(populations[species])
			if current < 55 or randf() > 0.16:
				continue
			var target_id: String = str(neighbors[randi_range(0, neighbors.size() - 1)])
			if not regions.has(target_id):
				continue
			var target: Dictionary = regions[target_id]
			var target_pop: Dictionary = target.get("populations", {}).duplicate(true)
			var target_count: int = int(target_pop.get(species, 0))
			var moved: int = maxi(1, int(current * 0.045))
			populations[species] = maxi(0, current - moved)
			target_pop[species] = mini(160, target_count + moved)
			target["populations"] = target_pop
			target["last_change"] = "%s migrated in from %s." % [str(species).replace("_", " ").capitalize(), str(region.get("name", region_id))]
			regions[target_id] = target
			break
		region["populations"] = populations
		regions[region_id] = region
	# Predators leave exhausted hunting grounds rather than growing indefinitely in empty habitats.
	for region_id in regions.keys():
		var region: Dictionary = regions[region_id]
		var populations: Dictionary = region.get("populations", {}).duplicate(true)
		var prey_total := 0
		for species in populations.keys():
			if str(species) not in ["frost_lynx","grey_wolf","cinder_hound","grave_hound","abyss_mantis","ember_wyrm","tide_serpent","rootbound_guardian"]:
				prey_total += int(populations[species])
		if prey_total >= 12: continue
		var predator_keys: Array = []
		for species in populations.keys():
			if str(species) in ["frost_lynx","grey_wolf","cinder_hound","grave_hound","abyss_mantis","ember_wyrm","tide_serpent","rootbound_guardian"] and int(populations[species]) >= 2:
				predator_keys.append(str(species))
		if predator_keys.is_empty(): continue
		var neighbors: Array = _region_definition(str(region_id)).get("neighbors", [])
		if neighbors.is_empty(): continue
		var target_id := str(neighbors[randi_range(0, neighbors.size() - 1)])
		if not regions.has(target_id): continue
		var species_to_move := str(predator_keys[0])
		var moved := maxi(1, int(populations[species_to_move] * 0.12))
		populations[species_to_move] = maxi(0, int(populations[species_to_move]) - moved)
		region["populations"] = populations
		region["last_change"] = "Predators are leaving because prey has become scarce."
		regions[region_id] = region
		var target: Dictionary = regions[target_id]
		var target_pop: Dictionary = target.get("populations", {}).duplicate(true)
		target_pop[species_to_move] = mini(160, int(target_pop.get(species_to_move, 0)) + moved)
		target["populations"] = target_pop
		target["last_change"] = "%s migrated in search of prey." % species_to_move.replace("_", " ").capitalize()
		regions[target_id] = target

func _start_regional_event(region_id: String, region: Dictionary, regions: Dictionary, sects: Dictionary, history: Array, announce: bool) -> void:
	var definition: Dictionary = EVENT_DEFINITIONS[randi_range(0, EVENT_DEFINITIONS.size() - 1)]
	var event_id: String = str(definition.get("id", ""))
	# Apex encounters are less common than ordinary seasonal incidents.
	if event_id == "apex_beast" and randf() > 0.32:
		definition = EVENT_DEFINITIONS[0]
		event_id = str(definition.get("id", ""))
	var active := {"id":event_id,"title":str(definition.get("title", "Regional event")),"detail":str(definition.get("detail", "")),"remaining":int(definition.get("duration", 1)),"started_at":Time.get_unix_time_from_system(),"intensity":randf_range(0.75, 1.25)}
	region["event"] = active
	var populations: Dictionary = region.get("populations", {}).duplicate(true)
	var resources: Dictionary = region.get("resources", {}).duplicate(true)
	match event_id:
		"beast_migration":
			for species in populations.keys(): populations[species] = mini(160, int(populations[species]) + 8)
			region["last_change"] = "Herds and predators have shifted along the migration paths."
		"predator_war":
			var predator_species: Array[String] = []
			for species in populations.keys():
				if str(species) in ["grey_wolf","frost_lynx","cinder_hound","grave_hound","abyss_mantis","ember_wyrm","tide_serpent"] and int(populations[species]) >= 8:
					predator_species.append(str(species))
				if str(species) in ["grey_wolf","frost_lynx","cinder_hound","grave_hound","abyss_mantis"]: populations[species] = mini(160, int(populations[species]) + 3)
				else: populations[species] = maxi(0, int(populations[species]) - 5)
			region["last_change"] = "Predator packs are contesting territory; prey has scattered."
			if predator_species.size() > 0:
				var first_species: String = predator_species[0]
				var second_species: String = predator_species[1] if predator_species.size() > 1 else first_species
				_spawn_territorial_conflict(region_id, first_species, second_species)
		"spirit_bloom":
			resources["herbs"] = minf(100.0, float(resources.get("herbs", 0.0)) + 24.0)
			resources["spirit_motes"] = minf(100.0, float(resources.get("spirit_motes", 0.0)) + 30.0)
			region["last_change"] = "A spirit bloom has enriched herbs and spiritual energy."
		"bandit_raid":
			region["settlement_supply"] = maxf(0.0, float(region.get("settlement_supply", 100.0)) - 18.0)
			resources["ore"] = maxf(0.0, float(resources.get("ore", 0.0)) - 6.0)
			region["last_change"] = "Bandits have raided caravans and local storehouses."
		"sect_tournament":
			for sect_id in sects.keys():
				var sect: Dictionary = sects[sect_id]
				if str(sect.get("territory", "")) == region_id:
					sect["influence"] = minf(100.0, float(sect.get("influence", 50.0)) + 8.0)
					sect["members"] = int(sect.get("members", 0)) + randi_range(2, 5)
					sects[sect_id] = sect
			region["last_change"] = "A sect tournament has drawn disciples and wandering challengers."
		"resource_boom":
			for resource in resources.keys(): resources[resource] = minf(100.0, float(resources[resource]) + 14.0)
			region["last_change"] = "Newly exposed veins are drawing gatherers and miners."
		"blight":
			resources["herbs"] = maxf(0.0, float(resources.get("herbs", 0.0)) - 22.0)
			for species in populations.keys(): populations[species] = maxi(0, int(populations[species]) - 4)
			region["settlement_supply"] = maxf(0.0, float(region.get("settlement_supply", 100.0)) - 8.0)
			region["last_change"] = "A blight has damaged growth and driven creatures away."
		"apex_beast":
			for species in populations.keys(): populations[species] = maxi(0, int(populations[species]) - 6)
			region["last_change"] = "Creatures are fleeing the territory of an awakened apex beast."
	region["populations"] = populations
	region["resources"] = resources
	_apply_settlement_event(region_id, event_id, region)
	regions[region_id] = region
	history.append({"region":str(region.get("name", region_id)),"event":str(definition.get("title", "Regional event")),"started_at":Time.get_unix_time_from_system()})
	if announce:
		regional_event_started.emit(region_id, event_id)
		EventBus.activity.emit("Regional event: %s — %s" % [str(definition.get("title", "Regional event")), str(region.get("name", region_id))], "world")
		EventBus.toast.emit("%s: %s" % [str(region.get("name", region_id)), str(definition.get("title", "Regional event"))], "scene")
	if event_id == "apex_beast":
		_spawn_apex_for_region(region_id)
	elif event_id == "beast_migration":
		_spawn_migration_group(region_id, populations)


func _ensure_active_apex_bosses() -> void:
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null or not director.has_method("spawn_world_boss"):
		return
	for region_id in _state.get("regions", {}).keys():
		var region: Dictionary = _state["regions"][region_id]
		var event: Dictionary = region.get("event", {})
		if str(event.get("id", "")) == "apex_beast":
			_spawn_apex_for_region(str(region_id))

func _highest_rivalry_pair(sects: Dictionary) -> Dictionary:
	var best: Dictionary = {}
	var best_score: float = 70.0
	for sect_id in sects.keys():
		var sect: Dictionary = sects[sect_id]
		var rival_id: String = str(sect.get("rival", ""))
		if rival_id == "" or not sects.has(rival_id) or str(sect_id) > rival_id:
			continue
		var score: float = float(sect.get("rivalry", 0.0))
		if score > best_score:
			best_score = score
			best = {"sect_a":str(sect_id),"sect_b":rival_id,"score":score,"region":str(sect.get("territory", "elyndor"))}
	return best

func _start_sect_clash(region_id: String, clash: Dictionary, region: Dictionary, regions: Dictionary, sects: Dictionary, history: Array, announce: bool) -> void:
	var first: Dictionary = sects.get(str(clash.sect_a), {})
	var second: Dictionary = sects.get(str(clash.sect_b), {})
	var first_name: String = str(first.get("name", "First Sect"))
	var second_name: String = str(second.get("name", "Rival Sect"))
	var first_loss: int = randi_range(1, 4)
	var second_loss: int = randi_range(1, 4)
	first["members"] = maxi(5, int(first.get("members", 0)) - first_loss)
	second["members"] = maxi(5, int(second.get("members", 0)) - second_loss)
	first["influence"] = maxf(0.0, float(first.get("influence", 50.0)) - 3.0)
	second["influence"] = maxf(0.0, float(second.get("influence", 50.0)) - 3.0)
	first["defeats"] = int(first.get("defeats", 0)) + 1
	second["defeats"] = int(second.get("defeats", 0)) + 1
	sects[str(clash.sect_a)] = first
	sects[str(clash.sect_b)] = second
	var event := {"id":"sect_clash","title":"%s clashes with %s" % [first_name, second_name],"detail":"A rivalry has erupted into open conflict. Both sects have lost disciples and influence; the surrounding settlements are avoiding the contested paths.","remaining":4,"started_at":Time.get_unix_time_from_system(),"sect_a":str(clash.sect_a),"sect_b":str(clash.sect_b)}
	region["event"] = event
	region["settlement_supply"] = maxf(0.0, float(region.get("settlement_supply", 100.0)) - 5.0)
	region["last_change"] = "A sect clash has cost both rival orders disciples and influence."
	regions[region_id] = region
	history.append({"region":str(region.get("name", region_id)),"event":str(event.get("title", "Regional event")),"started_at":Time.get_unix_time_from_system()})
	if announce:
		regional_event_started.emit(region_id, "sect_clash")
		EventBus.activity.emit("Sect clash: %s against %s" % [first_name, second_name], "world")
		EventBus.toast.emit("Rival sects have entered open conflict in %s." % str(region.get("name", region_id)), "scene")

func _apply_settlement_event(region_id: String, event_id: String, region: Dictionary) -> void:
	if region_id != "elyndor":
		return
	var living: Node = get_tree().get_first_node_in_group("living_world")
	var settlement_growth: Node = get_tree().get_first_node_in_group("settlement_growth")
	if event_id == "bandit_raid" or event_id == "blight":
		var stock_loss_value: Variant = living.get("businesses") if living else null
		if stock_loss_value is Dictionary:
			var stock_loss_businesses: Dictionary = stock_loss_value.duplicate(true)
			for business_id in stock_loss_businesses.keys():
				var stock_loss: Dictionary = stock_loss_businesses[business_id].get("stock", {}).duplicate(true)
				for item_id in stock_loss.keys():
					stock_loss[item_id] = maxi(0, int(stock_loss[item_id]) - maxi(1, int(float(stock_loss[item_id]) * 0.12)))
				stock_loss_businesses[business_id]["stock"] = stock_loss
			living.set("businesses", stock_loss_businesses)
			if living.has_method("_save_state"):
				living.call("_save_state")
		if settlement_growth and settlement_growth.has_method("add_progress"):
			settlement_growth.add_progress("elyndor", -7.0, "regional hardship")
	elif event_id == "resource_boom" or event_id == "spirit_bloom":
		var stock_gain_value: Variant = living.get("businesses") if living else null
		if stock_gain_value is Dictionary:
			var stock_gain_businesses: Dictionary = stock_gain_value.duplicate(true)
			for business_id in stock_gain_businesses.keys():
				var stock_gain: Dictionary = stock_gain_businesses[business_id].get("stock", {}).duplicate(true)
				for item_id in stock_gain.keys():
					stock_gain[item_id] = mini(40, int(stock_gain[item_id]) + 2)
				stock_gain_businesses[business_id]["stock"] = stock_gain
			living.set("businesses", stock_gain_businesses)
			if living.has_method("_save_state"):
				living.call("_save_state")
		if settlement_growth and settlement_growth.has_method("add_progress"):
			settlement_growth.add_progress("elyndor", 8.0, "regional prosperity")

func _spawn_apex_for_region(region_id: String) -> void:
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null or not director.has_method("spawn_world_boss"):
		return
	var profile: Dictionary = BOSS_PROFILES.get(region_id, BOSS_PROFILES["elyndor"]).duplicate(true)
	var center: Array = _region_definition(region_id).get("center", [0.0, 0.0])
	director.spawn_world_boss("apex_" + region_id, profile, Vector2(float(center[0]), float(center[1])), region_id)

func _spawn_territorial_conflict(region_id: String, first_species: String, second_species: String) -> void:
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null or not director.has_method("spawn_territorial_conflict"):
		return
	var definition: Dictionary = _region_definition(region_id)
	var center_values: Array = definition.get("center", [0.0, 0.0])
	director.spawn_territorial_conflict(region_id, first_species, second_species, Vector2(float(center_values[0]), float(center_values[1])))

func _spawn_migration_group(region_id: String, populations: Dictionary) -> void:
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null or not director.has_method("spawn_ecology_group"):
		return
	var def: Dictionary = _region_definition(region_id)
	var center: Array = def.get("center", [0.0, 0.0])
	var species: String = "grey_wolf"
	for candidate in populations.keys():
		if str(candidate) in ["grey_wolf","frost_lynx","cinder_hound","reef_crab","fungal_stalker","stone_crawler"]:
			species = str(candidate)
			break
	director.spawn_ecology_group(species, 3, Vector2(float(center[0]), float(center[1])), 28.0, region_id)

func on_region_entered(region_name: String) -> void:
	var region_id: String = region_id_from_name(region_name)
	if region_id == "":
		return
	if not MMORPGNetwork.is_authority():
		if MMORPGNetwork.is_online():
			rpc_id(1, "request_region_entry", region_id)
		return
	var now: float = GameManager.game_time_seconds
	if float(_region_last_spawn.get(region_id, -9999.0)) + 210.0 > now:
		return
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null or not director.has_method("spawn_ecology_group"):
		return
	var active_count: int = 0
	for monster in get_tree().get_nodes_in_group("enemy"):
		if monster is Monster and str(monster.get_meta("ecology_region", "")) == region_id and monster.state != Monster.State.DEAD:
			active_count += 1
	if active_count >= 4:
		return
	var report: Dictionary = get_region_report(region_id)
	var populations: Dictionary = report.get("populations", {})
	var preferred: Array[String] = []
	for species in populations.keys():
		if str(species) in ["frost_lynx","grey_wolf","cinder_hound","reef_crab","drowned_guard","fungal_stalker","grave_hound","stone_crawler","abyss_mantis","ash_imp","night_wisp"] and int(populations[species]) >= 15:
			preferred.append(str(species))
	if preferred.is_empty():
		return
	preferred.sort_custom(func(a: String, b: String) -> bool: return int(populations.get(a, 0)) > int(populations.get(b, 0)))
	var def: Dictionary = _region_definition(region_id)
	var center_values: Array = def.get("center", [0.0, 0.0])
	var center := Vector2(float(center_values[0]), float(center_values[1]))
	var count: int = 2 if active_count <= 1 else 1
	var spawned: int = int(director.spawn_ecology_group(preferred[0], count, center, 34.0, region_id))
	if spawned > 0:
		_region_last_spawn[region_id] = now

func record_monster_killed(monster: Node) -> void:
	if not MMORPGNetwork.is_authority() or monster == null or monster.has_meta("dungeon_floor"):
		return
	var region_id: String = region_id_at(float(monster.global_position.x), float(monster.global_position.z))
	if region_id == "":
		return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var populations: Dictionary = entry.get("populations", {}).duplicate(true)
	var species: String = str(monster.get("monster_id"))
	if populations.has(species):
		populations[species] = maxi(0, int(populations[species]) - 1)
		entry["populations"] = populations
		entry["last_change"] = "Local hunters have reduced the %s population." % species.replace("_", " ")
		regions[region_id] = entry
		_state["regions"] = regions
		_persist()

func record_player_gather(region_name: String, resource_id: String, amount: float, resource_node: ResourceNode = null) -> void:
	if amount <= 0.0 or not is_instance_valid(resource_node):
		return
	var node_region_id: String = region_id_at(resource_node.global_position.x, resource_node.global_position.z)
	var region_id: String = node_region_id if node_region_id != "" else region_id_from_name(region_name)
	if region_id == "":
		return
	if not MMORPGNetwork.is_authority():
		if MMORPGNetwork.is_online():
			rpc_id(1, "request_player_gather", region_id, resource_id, clampf(amount, 0.0, 2.0), resource_node.get_path())
		return
	_apply_player_gather(region_id, resource_id, clampf(amount, 0.0, 2.0))

func _apply_player_gather(region_id: String, resource_id: String, amount: float) -> void:
	if amount <= 0.0 or not _state.get("regions", {}).has(region_id):
		return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var resources: Dictionary = entry.get("resources", {}).duplicate(true)
	if resources.has(resource_id):
		resources[resource_id] = maxf(0.0, float(resources[resource_id]) - amount)
		entry["resources"] = resources
		entry["last_change"] = "Gathering has reduced the local %s reserve." % resource_id
		regions[region_id] = entry
		_state["regions"] = regions
		_persist()

func record_player_joined_sect(sect_id: String) -> void:
	if not _is_known_sect(sect_id):
		return
	if not MMORPGNetwork.is_authority():
		if MMORPGNetwork.is_online():
			rpc_id(1, "request_player_joined_sect", sect_id)
		return
	var character_id: String = str(MMORPGNetwork.local_character_id)
	if character_id.is_empty():
		character_id = "local-offline-character"
	_record_sect_membership(character_id, sect_id)

func _record_sect_membership(character_id: String, sect_id: String) -> void:
	if character_id.is_empty() or not _is_known_sect(sect_id):
		return
	var memberships: Dictionary = _state.get("sect_memberships", {}).duplicate(true)
	var previous_sect: String = str(memberships.get(character_id, ""))
	if previous_sect == sect_id:
		return
	var sects: Dictionary = _state.get("sects", {}).duplicate(true)
	if previous_sect != "" and sects.has(previous_sect):
		var previous: Dictionary = sects[previous_sect]
		previous["members"] = maxi(0, int(previous.get("members", 0)) - 1)
		sects[previous_sect] = previous
	var sect: Dictionary = sects.get(sect_id, {})
	sect["members"] = int(sect.get("members", 0)) + 1
	sect["influence"] = minf(100.0, float(sect.get("influence", 50.0)) + 2.0)
	sect["recruitment_pressure"] = maxf(0.0, float(sect.get("recruitment_pressure", 0.0)) - 5.0)
	sects[sect_id] = sect
	memberships[character_id] = sect_id
	_state["sect_memberships"] = memberships
	_state["sects"] = sects
	_persist()

func _is_known_sect(sect_id: String) -> bool:
	for definition in SECT_DEFINITIONS:
		if str(definition.get("id", "")) == sect_id:
			return true
	return false

@rpc("any_peer", "reliable")
func request_player_joined_sect(sect_id: String) -> void:
	if not multiplayer.is_server() or not _is_known_sect(sect_id):
		return
	var sender: int = multiplayer.get_remote_sender_id()
	var identity: Dictionary = MMORPGNetwork.peer_characters.get(sender, {})
	if identity.is_empty():
		return
	_record_sect_membership(str(identity.get("character_id", "")), sect_id)

func request_authoritative_gather(resource_node: ResourceNode) -> void:
	if not WorldDeploymentGuard.is_production_session() or not MMORPGNetwork.is_online() or not is_instance_valid(resource_node):
		return
	if MMORPGNetwork.is_authority():
		_commit_authoritative_gather(1, str(MMORPGNetwork.local_character_id), resource_node)
	else:
		rpc_id(1, "server_request_authoritative_gather", resource_node.get_path())

@rpc("any_peer", "reliable")
func server_request_authoritative_gather(resource_path: NodePath) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	var sender := multiplayer.get_remote_sender_id()
	var identity: Dictionary = MMORPGNetwork.peer_characters.get(sender, {})
	var character_id := str(identity.get("character_id", ""))
	var resource_node := get_tree().root.get_node_or_null(resource_path) as ResourceNode
	if character_id.is_empty() or not is_instance_valid(resource_node) or resource_node.depleted or resource_node.charges <= 0 or not ResourceNode.CONFIGS.has(resource_node.kind):
		return
	var accepted: Vector3 = MMORPGNetwork.accepted_positions.get(sender, Vector3(1.0e9, 0.0, 1.0e9))
	if accepted.distance_to(resource_node.global_position) > 4.5:
		return
	_commit_authoritative_gather(sender, character_id, resource_node)

@rpc("authority", "reliable")
func apply_authoritative_resource_node_state(resource_path: NodePath, remaining_charges: int, is_depleted: bool) -> void:
	if multiplayer.is_server(): return
	var node := get_tree().root.get_node_or_null(resource_path) as ResourceNode
	if not is_instance_valid(node): return
	if is_depleted and not node.depleted:
		node.call("_deplete")
	elif not is_depleted and node.depleted:
		node.call("_respawn")
	node.charges = maxi(0, remaining_charges)

func _commit_authoritative_gather(peer_id: int, character_id: String, resource_node: ResourceNode) -> void:
	if character_id.is_empty() or not is_instance_valid(resource_node) or resource_node.depleted or resource_node.charges <= 0:
		return
	var config: Dictionary = ResourceNode.CONFIGS.get(resource_node.kind, {})
	if config.is_empty(): return
	var gather_key := "%d:%s" % [peer_id, str(resource_node.get_path())]
	var now := Time.get_ticks_msec() / 1000.0
	var previous := float(_last_gather_request_at.get(gather_key, -999.0))
	if now - previous < maxf(1.0, float(config.get("time", 2.0)) * 0.75):
		return
	_last_gather_request_at[gather_key] = now
	var item_id := str(config.get("item", ""))
	var quantity := _rng.randi_range(int(config.get("min_q", 1)), int(config.get("max_q", 1)))
	var charge_before := int(resource_node.charges)
	resource_node.charges = maxi(0, resource_node.charges - 1) # reserve the shared node charge before the database await
	var request_key := "%s" % MMORPGNetwork.call("_stable_world_uuid", "gather:%s:%s:%d" % [character_id, str(resource_node.get_path()), charge_before])
	var grant: Dictionary = await CentralBackend.server_grant_item(character_id, item_id, quantity, request_key)
	if not bool(grant.get("ok", false)):
		resource_node.charges += 1 # release the reservation if the item transaction did not commit
		push_warning("Authoritative gathering grant failed: %s" % str(grant.get("error", grant.get("body", {}))))
		return
	var quest_key := str(MMORPGNetwork.call("_stable_world_uuid", "gather-quest:%s:%s:%d" % [character_id, resource_node.get_path(), charge_before]))
	var quest_event: Dictionary = await CentralBackend.server_record_quest_objective(character_id, "collect", item_id, quest_key, "*", quantity)
	var quest_event_body: Dictionary = quest_event.get("body", {})
	var quest_event_result: Dictionary = quest_event_body.get("result", {}) if quest_event_body.get("result", {}) is Dictionary else {}
	if not quest_event_result.get("quest_ids", []).is_empty():
		await MMORPGNetwork.sync_authoritative_quests_to_peer(peer_id, character_id)
	if resource_node.charges <= 0 and resource_node.has_method("_deplete"):
		resource_node.call("_deplete")
	if multiplayer.is_server():
		rpc("apply_authoritative_resource_node_state", resource_node.get_path(), resource_node.charges, resource_node.depleted)
	var region_id := region_id_at(resource_node.global_position.x, resource_node.global_position.z)
	var regional_resource := "ore" if str(config.get("skill", "")) == "mining" else ("timber" if str(config.get("skill", "")) == "woodcutting" else "herbs")
	if region_id != "":
		_apply_player_gather(region_id, regional_resource, float(quantity) * 0.65)
	await MMORPGNetwork.sync_authoritative_inventory_to_peer(peer_id, character_id)

@rpc("any_peer", "reliable")
func request_player_gather(region_id: String, resource_id: String, amount: float, resource_path: NodePath) -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if not MMORPGNetwork.peer_characters.has(sender):
		return
	var resource_node: ResourceNode = get_tree().root.get_node_or_null(resource_path) as ResourceNode
	if not is_instance_valid(resource_node) or resource_node.depleted or not ResourceNode.CONFIGS.has(resource_node.kind):
		return
	var expected_resource: String = "ore" if resource_node.skill_id == "mining" else ("timber" if resource_node.skill_id == "woodcutting" else "herbs")
	if resource_id != expected_resource:
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	var previous_request: float = float(_last_gather_request_at.get(sender, 0.0))
	if now - previous_request < 0.35:
		return
	var accepted: Vector3 = MMORPGNetwork.accepted_positions.get(sender, Vector3(1.0e9, 0.0, 1.0e9))
	if accepted.distance_to(resource_node.global_position) > 5.0:
		return
	var actual_region_id: String = region_id_at(resource_node.global_position.x, resource_node.global_position.z)
	if actual_region_id == "" or actual_region_id != region_id:
		return
	var safe_amount: float = clampf(amount, 0.0, 2.0)
	if safe_amount <= 0.0:
		return
	_last_gather_request_at[sender] = now
	_apply_player_gather(actual_region_id, expected_resource, safe_amount)

@rpc("any_peer", "reliable")
func request_region_entry(region_id: String) -> void:
	if not multiplayer.is_server() or not MMORPGNetwork.peer_characters.has(multiplayer.get_remote_sender_id()):
		return
	var sender: int = multiplayer.get_remote_sender_id()
	var accepted: Vector3 = MMORPGNetwork.accepted_positions.get(sender, Vector3(1.0e9, 0.0, 1.0e9))
	if region_id_at(accepted.x, accepted.z) != region_id:
		return
	var definition: Dictionary = _region_definition(region_id)
	if not definition.is_empty():
		on_region_entered(str(definition.get("name", region_id)))
		var identity: Dictionary = MMORPGNetwork.peer_characters.get(sender, {})
		var character_id := str(identity.get("character_id", ""))
		var objective_region_name := str(definition.get("name", region_id))
		if region_id == "ironback": objective_region_name = "Ironback Range"
		if region_id == "mirrorwater": objective_region_name = "Mirrorwater Basin"
		if not character_id.is_empty():
			var visit_key := str(MMORPGNetwork.call("_stable_world_uuid", "quest-region-visit:%s:%s:%d" % [character_id, region_id, Time.get_ticks_usec()]))
			await CentralBackend.server_record_quest_objective(character_id, "visit", objective_region_name, visit_key)
			await MMORPGNetwork.sync_authoritative_quests_to_peer(sender, character_id)

func record_world_boss_defeated(monster: Node) -> void:
	if not MMORPGNetwork.is_authority() or monster == null or not bool(monster.get_meta("world_boss", false)):
		return
	var boss_id: String = str(monster.get_meta("world_boss_id", ""))
	var region_id: String = str(monster.get_meta("world_boss_region", ""))
	var defeats: Dictionary = _state.get("boss_defeats", {}).duplicate(true)
	defeats[boss_id] = {"region":region_id,"defeated_at":Time.get_unix_time_from_system(),"character":str(PlayerData.stats.get("character_name", ""))}
	_state["boss_defeats"] = defeats
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	if regions.has(region_id):
		var entry: Dictionary = regions[region_id]
		entry["event"] = {}
		entry["last_change"] = "The awakened apex has fallen. Wildlife is cautiously returning."
		entry["settlement_supply"] = minf(100.0, float(entry.get("settlement_supply", 100.0)) + 12.0)
		regions[region_id] = entry
	_state["regions"] = regions
	_persist()
	EventBus.activity.emit("The apex threat in %s has been ended. Its territory begins to recover." % str(_region_definition(region_id).get("name", region_id)), "world")

func record_local_production(region_name_or_id: String, commodity: String, amount: float) -> void:
	if amount <= 0.0 or not MMORPGNetwork.is_authority():
		return
	var region_id := region_id_from_name(region_name_or_id)
	if region_id == "" and _state.get("regions", {}).has(region_name_or_id):
		region_id = region_name_or_id
	if region_id == "": return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var economy: Dictionary = entry.get("economy", {}).duplicate(true)
	if not economy.has(commodity): return
	economy[commodity] = clampf(float(economy.get(commodity, 0.0)) + amount, 0.0, 250.0)
	entry["economy"] = economy
	entry["last_change"] = "%s production replenished local %s stores." % [str(entry.get("name", region_id)), commodity]
	regions[region_id] = entry
	_state["regions"] = regions
	_persist()

func record_local_resource_production(region_name_or_id: String, resource_id: String, amount: float) -> void:
	if amount <= 0.0 or not MMORPGNetwork.is_authority(): return
	var region_id := region_id_from_name(region_name_or_id)
	if region_id == "" and _state.get("regions", {}).has(region_name_or_id):
		region_id = region_name_or_id
	if region_id == "": return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var resources: Dictionary = entry.get("resources", {}).duplicate(true)
	if not resources.has(resource_id): return
	resources[resource_id] = clampf(float(resources.get(resource_id, 0.0)) + amount, 0.0, 100.0)
	entry["resources"] = resources
	entry["last_change"] = "%s activity replenished local %s reserves." % [str(entry.get("name", region_id)), resource_id]
	regions[region_id] = entry
	_state["regions"] = regions
	_persist()

func record_market_sale(region_name_or_id: String, commodity: String, amount: float) -> void:
	if amount <= 0.0 or not MMORPGNetwork.is_authority(): return
	var region_id := region_id_from_name(region_name_or_id)
	if region_id == "" and _state.get("regions", {}).has(region_name_or_id): region_id = region_name_or_id
	if region_id == "": return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var economy: Dictionary = entry.get("economy", {}).duplicate(true)
	if not economy.has(commodity): return
	var sold := minf(amount, float(economy.get(commodity, 0.0)))
	economy[commodity] = maxf(0.0, float(economy.get(commodity, 0.0)) - sold)
	entry["economy"] = economy
	if sold > 0.0: entry["last_change"] = "Market demand sold %.1f %s." % [sold, commodity]
	regions[region_id] = entry
	_state["regions"] = regions
	_persist()

func reserve_caravan_shipment(shipment_id: String, from_region: String, to_region: String, commodity: String, amount: float) -> Dictionary:
	if not MMORPGNetwork.is_authority() or shipment_id.is_empty() or amount <= 0.0:
		return {"ok":false,"reason":"invalid_request"}
	var reservations: Dictionary = _state.get("caravan_reservations", {}).duplicate(true)
	if reservations.has(shipment_id):
		return {"ok":false,"reason":"duplicate_shipment"}
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	if not regions.has(from_region) or not regions.has(to_region) or from_region == to_region:
		return {"ok":false,"reason":"invalid_route"}
	var source: Dictionary = regions[from_region]
	var stock: Dictionary = source.get("economy", {}).duplicate(true)
	var available: float = float(stock.get(commodity, 0.0))
	var reserved: float = minf(amount, available)
	if reserved <= 0.0:
		return {"ok":false,"reason":"insufficient_stock"}
	stock[commodity] = maxf(0.0, available - reserved)
	source["economy"] = stock
	source["last_change"] = "A caravan departed with reserved %s %s." % [str(snappedf(reserved, 0.1)), commodity]
	regions[from_region] = source
	reservations[shipment_id] = {"from":from_region,"to":to_region,"commodity":commodity,"amount":reserved,"status":"in_transit","created_at":Time.get_unix_time_from_system()}
	_state["regions"] = regions
	_state["caravan_reservations"] = reservations
	_persist()
	return {"ok":true,"amount":reserved}

func resolve_caravan_shipment(shipment_id: String, delivered: bool) -> bool:
	if not MMORPGNetwork.is_authority(): return false
	var reservations: Dictionary = _state.get("caravan_reservations", {}).duplicate(true)
	if not reservations.has(shipment_id): return false
	var shipment: Dictionary = reservations[shipment_id]
	if str(shipment.get("status", "")) != "in_transit": return false
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var commodity: String = str(shipment.get("commodity", "food"))
	var amount: float = float(shipment.get("amount", 0.0))
	var from_id: String = str(shipment.get("from", ""))
	var to_id: String = str(shipment.get("to", ""))
	if delivered and regions.has(to_id):
		var destination: Dictionary = regions[to_id]
		var destination_stock: Dictionary = destination.get("economy", {}).duplicate(true)
		destination_stock[commodity] = minf(250.0, float(destination_stock.get(commodity, 0.0)) + amount)
		destination["economy"] = destination_stock
		destination["last_change"] = "A caravan delivered %.1f %s." % [amount, commodity]
		regions[to_id] = destination
		shipment["status"] = "delivered"
	else:
		shipment["status"] = "lost"
		if regions.has(from_id):
			var source: Dictionary = regions[from_id]
			source["last_change"] = "Bandits seized a reserved shipment of %.1f %s." % [amount, commodity]
			regions[from_id] = source
	reservations[shipment_id] = shipment
	# Keep a bounded idempotency history so retries cannot duplicate deliveries.
	var completed: Array = reservations.keys()
	if completed.size() > 160:
		for old_id in completed:
			if str(reservations[old_id].get("status", "")) != "in_transit":
				reservations.erase(old_id)
				if reservations.size() <= 120: break
	_state["regions"] = regions
	_state["caravan_reservations"] = reservations
	_persist()
	return true

func record_caravan_shipment(from_region: String, to_region: String, commodity: String, amount: float, delivered: bool) -> void:
	# Compatibility wrapper for older callers. New caravans reserve at departure.
	var shipment_id := "legacy:%s:%s:%s:%d" % [from_region, to_region, commodity, Time.get_ticks_usec()]
	var reservation := reserve_caravan_shipment(shipment_id, from_region, to_region, commodity, amount)
	if bool(reservation.get("ok", false)):
		resolve_caravan_shipment(shipment_id, delivered)

func record_hunt_kill(x: float, z: float, species: String, amount: int = 1) -> void:
	if not MMORPGNetwork.is_authority(): return
	var region_id := region_id_at(x, z)
	if region_id == "": return
	var regions: Dictionary = _state.get("regions", {}).duplicate(true)
	var entry: Dictionary = regions.get(region_id, {})
	var populations: Dictionary = entry.get("populations", {}).duplicate(true)
	if populations.has(species):
		populations[species] = maxi(0, int(populations[species]) - maxi(1, amount))
		entry["populations"] = populations
		entry["last_change"] = "Hunting pressure has reduced the local %s population." % species.replace("_", " ")
		regions[region_id] = entry
		_state["regions"] = regions
		_persist()

func get_market_quote(region_name_or_id: String, commodity: String) -> Dictionary:
	var report := get_region_report(region_name_or_id)
	var prices: Dictionary = report.get("prices", {})
	var economy: Dictionary = report.get("economy", {})
	return {"commodity":commodity,"price":float(prices.get(commodity, 5.0)),"stock":float(economy.get(commodity, 0.0)),"shortage":float(economy.get(commodity, 0.0)) < 6.0}

func get_active_event_for_region(region_name: String) -> Dictionary:
	var region_id: String = region_id_from_name(region_name)
	if region_id == "":
		return {}
	var region: Dictionary = _state.get("regions", {}).get(region_id, {})
	var active: Variant = region.get("event", {})
	return active.duplicate(true) if active is Dictionary else {}

func get_region_report(region_name_or_id: String) -> Dictionary:
	var region_id: String = region_id_from_name(region_name_or_id)
	if region_id == "" and _state.get("regions", {}).has(region_name_or_id):
		region_id = region_name_or_id
	if region_id == "":
		return {}
	var result: Dictionary = _state.get("regions", {}).get(region_id, {}).duplicate(true)
	result["id"] = region_id
	return result

func get_resource_modifier(region_name: String, resource_id: String) -> float:
	var report: Dictionary = get_region_report(region_name)
	var resources: Dictionary = report.get("resources", {})
	return clampf(float(resources.get(resource_id, 50.0)) / 50.0, 0.2, 2.0)

func get_sect_report(sect_id: String) -> Dictionary:
	var value: Variant = _state.get("sects", {}).get(sect_id, {})
	return value.duplicate(true) if value is Dictionary else {}

func get_world_summary() -> Dictionary:
	var active_events: Array[Dictionary] = []
	for rid in _state.get("regions", {}).keys():
		var region: Dictionary = _state["regions"][rid]
		var event: Dictionary = region.get("event", {})
		if not event.is_empty():
			active_events.append({"region":str(region.get("name", rid)),"event":str(event.get("title", "Unknown")),"remaining":int(event.get("remaining", 0))})
	return {"world_id":MMORPGNetwork.SINGLE_WORLD_ID,"revision":MMORPGWorldState.revision,"active_events":active_events,"sect_count":_state.get("sects", {}).size(),"regions":_state.get("regions", {}).size()}

func region_id_at(x: float, z: float) -> String:
	for region in REGIONS:
		var center: Array = region.get("center", [0.0, 0.0])
		var nx: float = (x - float(center[0])) / float(region.get("rx", 1.0))
		var nz: float = (z - float(center[1])) / float(region.get("rz", 1.0))
		if nx * nx + nz * nz <= 1.0:
			return str(region.get("id", ""))
	return ""

func get_region_center(region_id: String) -> Vector3:
	var definition := _region_definition(region_id)
	if definition.is_empty(): return Vector3.ZERO
	var center: Array = definition.get("center", [0.0, 0.0])
	var x := float(center[0])
	var z := float(center[1])
	var terrain := TerrainNoise.new(GameManager.world_seed)
	return Vector3(x, terrain.get_height(x, z), z)

func get_region_neighbors(region_id: String) -> Array[String]:
	var definition := _region_definition(region_id)
	var result: Array[String] = []
	for neighbor in definition.get("neighbors", []):
		result.append(str(neighbor))
	return result

func get_safe_region_location(region_id: String) -> Vector3:
	var definition := _region_definition(region_id)
	if definition.is_empty(): return Vector3.ZERO
	var center: Array = definition.get("center", [0.0, 0.0])
	var center_x := float(center[0])
	var center_z := float(center[1])
	var radius_x := float(definition.get("rx", 1.0)) * 0.88
	var radius_z := float(definition.get("rz", 1.0)) * 0.88
	var terrain := TerrainNoise.new(GameManager.world_seed)
	var safe_height := Constants.WATER_LEVEL + 1.8
	var best_position := Vector3.ZERO
	var best_height := -INF
	for ring in range(0, 10):
		var radius := float(ring) * 7.5
		for sample in range(24):
			var angle := TAU * float(sample) / 24.0
			var x := center_x + cos(angle) * radius
			var z := center_z + sin(angle) * radius
			var nx := (x - center_x) / maxf(radius_x, 1.0)
			var nz := (z - center_z) / maxf(radius_z, 1.0)
			if nx * nx + nz * nz > 0.92: continue
			var height := terrain.get_height(x, z)
			if height > best_height:
				best_height = height
				best_position = Vector3(x, height, z)
			if height >= safe_height:
				return Vector3(x, height, z)
	return best_position if best_height > Constants.WATER_LEVEL + 0.6 else Vector3.ZERO

func region_id_from_name(region_name: String) -> String:
	var query: String = region_name.strip_edges().to_lower()
	for region in REGIONS:
		if query == str(region.get("id", "")).to_lower() or query == str(region.get("name", "Unknown region")).to_lower():
			return str(region.get("id", ""))
	return ""

func _region_definition(region_id: String) -> Dictionary:
	for region in REGIONS:
		if str(region.get("id", "")) == region_id:
			return region
	return {}

func _trim_history(history: Array, maximum: int) -> Array:
	while history.size() > maximum:
		history.pop_front()
	return history

func send_snapshot_to_peer(peer_id: int) -> void:
	if MMORPGNetwork.is_online() and multiplayer.is_server() and peer_id > 1:
		rpc_id(peer_id, "apply_server_snapshot", _state, MMORPGWorldState.revision)

@rpc("authority", "reliable")
func apply_server_snapshot(snapshot: Dictionary, state_revision: int) -> void:
	if not MMORPGNetwork.is_online() or multiplayer.is_server() or state_revision < _server_snapshot_revision:
		return
	_server_snapshot_revision = state_revision
	_state = snapshot.duplicate(true)
	_ready_state = true
	var client_world: Dictionary = MMORPGWorldState.world_state.duplicate(true)
	var living_section: Dictionary = client_world.get("living_world", {}).duplicate(true)
	living_section[SECTION_KEY] = _state.duplicate(true)
	client_world["living_world"] = living_section
	MMORPGWorldState.world_state = client_world
	MMORPGWorldState.revision = state_revision
	world_state_changed.emit(state_revision)

func _restore_persistent_populations() -> void:
	var result: Dictionary = await CentralBackend.server_load_populations()
	if not bool(result.get("ok", false)):
		push_warning("Persistent ecology restore failed; retaining last world snapshot: %s" % str(result.get("error", result.get("status", "unknown"))))
		return
	var body: Dictionary = result.get("body", {})
	for row_variant in body.get("populations", []):
		if not row_variant is Dictionary:
			continue
		var row: Dictionary = row_variant
		var region_id := str(row.get("region_id", ""))
		var species_id := str(row.get("species_id", ""))
		var regions: Dictionary = _state.get("regions", {})
		if not regions.has(region_id) or species_id.is_empty():
			continue
		var region: Dictionary = regions[region_id]
		var populations: Dictionary = region.get("populations", {}).duplicate(true)
		var saved_state: Dictionary = row.get("population_state", {}) if row.get("population_state", {}) is Dictionary else {}
		populations[species_id] = clampi(int(saved_state.get("population", populations.get(species_id, 0))), 0, 1000000)
		region["populations"] = populations
		regions[region_id] = region
		_state["regions"] = regions
		_population_revisions["%s/%s" % [region_id, species_id]] = int(row.get("revision", 0))

func _persist_persistent_populations() -> void:
	if _population_save_pending or not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured() or not MMORPGNetwork.is_authority():
		return
	_population_save_pending = true
	var rows: Array = []
	var regions: Dictionary = _state.get("regions", {})
	for region_id in regions:
		var populations: Dictionary = regions[region_id].get("populations", {})
		for species_id in populations:
			var key := "%s/%s" % [str(region_id), str(species_id)]
			rows.append({"region_id": str(region_id), "species_id": str(species_id), "revision": int(_population_revisions.get(key, 0)), "population_state": {"population": int(populations[species_id])}})
	if rows.is_empty():
		_population_save_pending = false
		return
	var result: Dictionary = await CentralBackend.server_save_population_snapshot(rows)
	if bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		for revision_row in body.get("revisions", []):
			if revision_row is Dictionary:
				var key := "%s/%s" % [str(revision_row.get("region_id", "")), str(revision_row.get("species_id", ""))]
				_population_revisions[key] = int(revision_row.get("revision", 0))
	else:
		push_warning("Persistent monster population save failed: %s" % str(result.get("error", result.get("status", "unknown"))))
	_population_save_pending = false

func _restore_persistent_territories() -> void:
	var result: Dictionary = await CentralBackend.server_load_territories()
	if not bool(result.get("ok", false)):
		push_warning("Persistent territory restore failed: %s" % str(result.get("error", result.get("status", "unknown"))))
		return
	var control: Dictionary = _state.get("territory_control", {}).duplicate(true)
	for row_variant in result.get("body", {}).get("territories", []):
		if not row_variant is Dictionary: continue
		var row: Dictionary = row_variant
		var territory_id := str(row.get("territory_id", ""))
		var saved: Dictionary = row.get("control_state", {}) if row.get("control_state", {}) is Dictionary else {}
		if territory_id == "elyndor":
			_state["governance_policy"] = str(saved.get("governance_policy", "balanced"))
			_state["governance_history"] = saved.get("governance_history", [])
		control[territory_id] = saved.duplicate(true)
		_territory_revisions[territory_id] = int(row.get("revision", 0))
		var regions: Dictionary = _state.get("regions", {})
		if regions.has(territory_id):
			var region: Dictionary = regions[territory_id]
			for key in ["settlement_supply", "territory_pressure", "event", "last_change", "economy", "prices", "resources", "governance_decision"]:
				if saved.has(key): region[key] = saved[key]
			regions[territory_id] = region
			_state["regions"] = regions
	_state["territory_control"] = control

func _persist_persistent_territories() -> void:
	if _territory_save_pending or not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured() or not MMORPGNetwork.is_authority(): return
	_territory_save_pending = true
	var rows: Array = []
	var regions: Dictionary = _state.get("regions", {})
	var sects: Dictionary = _state.get("sects", {})
	for territory_id in regions:
		var region: Dictionary = regions[territory_id]
		var controller := ""
		for sect_id in sects:
			if str(sects[sect_id].get("territory", "")) == str(territory_id):
				controller = str(sect_id)
				break
		var state := {"settlement_supply": float(region.get("settlement_supply", 100.0)), "territory_pressure": region.get("territory_pressure", {}), "event": region.get("event", {}), "last_change": str(region.get("last_change", "")), "controlling_sect": controller}
		for key in ["economy", "prices", "resources", "governance_decision"]:
			if region.has(key):
				state[key] = region[key]
		if str(territory_id) == "elyndor":
			state["governance_policy"] = str(_state.get("governance_policy", "balanced"))
			state["governance_history"] = _state.get("governance_history", [])
		rows.append({"territory_id": str(territory_id), "revision": int(_territory_revisions.get(str(territory_id), 0)), "control_state": state})
	if rows.is_empty():
		_territory_save_pending = false
		return
	var result: Dictionary = await CentralBackend.server_save_territory_snapshot(rows)
	if bool(result.get("ok", false)):
		for revision_row in result.get("body", {}).get("revisions", []):
			if revision_row is Dictionary: _territory_revisions[str(revision_row.get("territory_id", ""))] = int(revision_row.get("revision", 0))
	else:
		push_warning("Persistent territory save failed: %s" % str(result.get("error", result.get("status", "unknown"))))
	_territory_save_pending = false

func _persist() -> void:
	var committed: bool = MMORPGWorldState.commit_world_changes([{"section":"living_world","key":SECTION_KEY,"value":_state}])
	if (committed or WorldDeploymentGuard.production_mode) and MMORPGNetwork.is_online() and multiplayer.is_server():
		rpc("apply_server_snapshot", _state, MMORPGWorldState.revision)
	if WorldDeploymentGuard.production_mode and MMORPGNetwork.is_authority():
		call_deferred("_persist_persistent_populations")
		call_deferred("_persist_persistent_territories")
	world_state_changed.emit(MMORPGWorldState.revision)
