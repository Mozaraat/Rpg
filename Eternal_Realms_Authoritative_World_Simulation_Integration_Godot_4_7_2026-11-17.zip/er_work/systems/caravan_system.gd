# Authoritative trade caravans with replicated carts, cargo, guards and ambushes.
extends Node
class_name CaravanSystem

var _timer: float = 60.0
var _active: Array = []
var _terrain: TerrainNoise
var _shipment_sequence: int = 0
var _replication_clock: float = 0.0

func _ready() -> void:
	add_to_group("caravans")
	_terrain = TerrainNoise.new(GameManager.world_seed)
	if not multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.connect(_on_peer_connected)

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		_update_replica_visuals(delta)
		return
	_timer -= delta
	if _timer <= 0.0:
		_timer = randf_range(70.0, 140.0)
		_spawn_caravan()
	_update_caravans(delta)
	if MMORPGNetwork.is_online():
		_replication_clock += delta
		if _replication_clock >= 0.2:
			_replication_clock = 0.0
			_broadcast_caravan_updates()

func _on_peer_connected(peer_id: int) -> void:
	if not MMORPGNetwork.is_online() or not MMORPGNetwork.is_authority():
		return
	var snapshot: Array = []
	for caravan in _active:
		snapshot.append(_caravan_payload(caravan))
	rpc_id(peer_id, "client_receive_caravan_snapshot", snapshot)

func _spawn_caravan() -> void:
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg == null or not ("settlements" in sg):
		return
	var ids: Array = sg.settlements.keys()
	if ids.size() < 2:
		ids = ["elyndor", "arcane_spire"]
	var a: String = str(ids[randi() % ids.size()])
	var b: String = str(ids[randi() % ids.size()])
	if a == b:
		return
	var ca: Vector2 = sg.settlements[a]["center"] if sg.settlements.has(a) else TerrainNoise.VILLAGE_CENTER
	var cb: Vector2 = sg.settlements[b]["center"] if sg.settlements.has(b) else TerrainNoise.SPIRE_CENTER
	var caravan_name := "Caravan %s→%s" % [str(sg.settlements.get(a, {}).get("name", a)), str(sg.settlements.get(b, {}).get("name", b))]
	var from_region := WorldLifeSimulation.region_id_at(ca.x, ca.y)
	var to_region := WorldLifeSimulation.region_id_at(cb.x, cb.y)
	if from_region.is_empty() or to_region.is_empty() or from_region == to_region:
		return
	var cargo_amount := 8.0
	var food_quote := WorldLifeSimulation.get_market_quote(from_region, "food")
	var cargo_type := "food"
	if float(food_quote.get("stock", 0.0)) < cargo_amount:
		var timber_quote := WorldLifeSimulation.get_market_quote(from_region, "timber")
		if float(timber_quote.get("stock", 0.0)) < 5.0:
			return
		cargo_type = "timber"
		cargo_amount = 5.0
	_shipment_sequence += 1
	var shipment_id := "%s:%s:%d:%d" % [from_region, to_region, Time.get_unix_time_from_system(), _shipment_sequence]
	var reservation: Dictionary = WorldLifeSimulation.reserve_caravan_shipment(shipment_id, from_region, to_region, cargo_type, cargo_amount)
	if not bool(reservation.get("ok", false)):
		return
	cargo_amount = float(reservation.get("amount", 0.0))
	var start_height := _terrain.get_height(ca.x, ca.y)
	var end_height := _terrain.get_height(cb.x, cb.y)
	var route: Array[Vector3] = [Vector3(ca.x, start_height, ca.y)]
	if (a == "elyndor" and b == "arcane_spire") or (a == "arcane_spire" and b == "elyndor"):
		var crossing_points: Array[Vector2] = [Vector2(-112.0, -82.0), Vector2(-178.0, -130.0)]
		if a == "arcane_spire":
			crossing_points.reverse()
		for point in crossing_points:
			route.append(Vector3(point.x, _terrain.get_height(point.x, point.y), point.y))
	route.append(Vector3(cb.x, end_height, cb.y))
	var payload := {
		"id": shipment_id, "name": caravan_name, "from": a, "to": b,
		"from_region": from_region, "to_region": to_region,
		"cargo_type": cargo_type, "cargo_amount": cargo_amount,
		"start": Vector3(ca.x, start_height, ca.y),
		"end": Vector3(cb.x, end_height, cb.y), "route": route,
		"position": Vector3(ca.x, start_height, ca.y),
		"progress": 0.0, "attacked": false, "ambush_position": Vector3.ZERO,
		"ambush_remaining": 0.0, "ambush_resolved": false, "cargo_lost": false
	}
	_apply_caravan_spawn(payload)
	if MMORPGNetwork.is_online():
		rpc("client_spawn_caravan", payload)
	EventBus.toast.emit("%s departs" % caravan_name, "info")
	EventBus.activity.emit("Trade route active", "world")

func _update_caravans(delta: float) -> void:
	var keep: Array = []
	for c_variant in _active:
		var c: Dictionary = c_variant
		if bool(c.get("attacked", false)) and not bool(c.get("ambush_resolved", false)):
			c["ambush_remaining"] = float(c.get("ambush_remaining", 0.0)) - delta
			if float(c["ambush_remaining"]) <= 0.0:
				c["ambush_resolved"] = true
				c["cargo_lost"] = randf() < 0.55
				_resolve_ambush_visual(c)
		else:
			c["progress"] = minf(float(c.get("progress", 0.0)) + delta / 90.0, 1.0)
		var t := float(c["progress"])
		var route: Array = c.get("route", [c.get("start", Vector3.ZERO), c.get("end", Vector3.ZERO)])
		var pos := _route_position(route, t)
		pos.y = _terrain.get_height(pos.x, pos.z)
		c["position"] = pos
		_update_caravan_visual(c, delta)
		if not bool(c.get("attacked", false)) and t > 0.35 and t < 0.7 and randf() < 0.012:
			c["attacked"] = true
			c["ambush_position"] = pos
			c["ambush_remaining"] = 7.0
			_apply_ambush_visual(c)
			EventBus.toast.emit("Bandits ambush the %s! Its guards fight to protect the cargo." % str(c["name"]), "scene")
			var rep = get_tree().get_first_node_in_group("reputation")
			if rep:
				rep.add_rep("bandits", -2)
		if t < 1.0:
			keep.append(c)
		else:
			var delivered := not bool(c.get("cargo_lost", false))
			WorldLifeSimulation.resolve_caravan_shipment(str(c.get("id", "")), delivered)
			if delivered:
				EventBus.toast.emit("%s delivered its %s shipment" % [str(c["name"]), str(c.get("cargo_type", "goods"))], "info")
			else:
				EventBus.toast.emit("The %s shipment was lost to bandits" % str(c["name"]), "warning")
			var sg = get_tree().get_first_node_in_group("settlement_growth")
			if sg and delivered:
				sg.add_progress(str(c["to"]), 4.0)
				sg.add_progress(str(c["from"]), 2.0)
			_remove_caravan_visual(c)
			if MMORPGNetwork.is_online():
				rpc("client_remove_caravan", str(c.get("id", "")))
	_active = keep

func _broadcast_caravan_updates() -> void:
	for c in _active:
		rpc("client_update_caravan", str(c.get("id", "")), c.get("position", Vector3.ZERO), float(c.get("progress", 0.0)), bool(c.get("attacked", false)), c.get("ambush_position", Vector3.ZERO), bool(c.get("ambush_resolved", false)), bool(c.get("cargo_lost", false)))

func _caravan_payload(c: Dictionary) -> Dictionary:
	return {
		"id": str(c.get("id", "")), "name": str(c.get("name", "Trade Caravan")),
		"from": str(c.get("from", "")), "to": str(c.get("to", "")),
		"cargo_type": str(c.get("cargo_type", "goods")), "cargo_amount": float(c.get("cargo_amount", 0.0)),
		"start": c.get("start", Vector3.ZERO), "end": c.get("end", Vector3.ZERO),
		"route": c.get("route", [c.get("start", Vector3.ZERO), c.get("end", Vector3.ZERO)]),
		"position": c.get("position", Vector3.ZERO), "progress": float(c.get("progress", 0.0)),
		"attacked": bool(c.get("attacked", false)), "ambush_position": c.get("ambush_position", Vector3.ZERO),
		"ambush_remaining": float(c.get("ambush_remaining", 0.0)),
		"ambush_resolved": bool(c.get("ambush_resolved", false)), "cargo_lost": bool(c.get("cargo_lost", false))
	}

func _apply_caravan_spawn(payload: Dictionary) -> void:
	var caravan_id := str(payload.get("id", ""))
	if caravan_id.is_empty() or _find_caravan(caravan_id) >= 0:
		return
	var c := payload.duplicate(true)
	c["visual"] = _build_caravan_visual(str(c.get("name", "Trade Caravan")), str(c.get("cargo_type", "goods")), float(c.get("cargo_amount", 0.0)))
	get_tree().current_scene.add_child(c["visual"])
	_active.append(c)
	_update_caravan_visual(c, 0.0)
	if bool(c.get("attacked", false)):
		_apply_ambush_visual(c)
		if bool(c.get("ambush_resolved", false)):
			_resolve_ambush_visual(c)

func _route_position(route: Array, progress: float) -> Vector3:
	if route.is_empty():
		return Vector3.ZERO
	if route.size() == 1:
		return route[0]
	var total_length := 0.0
	for i in range(route.size() - 1):
		var a: Vector3 = route[i]
		var b: Vector3 = route[i + 1]
		total_length += Vector2(a.x, a.z).distance_to(Vector2(b.x, b.z))
	if total_length <= 0.001:
		return route[route.size() - 1]
	var remaining := clampf(progress, 0.0, 1.0) * total_length
	for i in range(route.size() - 1):
		var a: Vector3 = route[i]
		var b: Vector3 = route[i + 1]
		var segment_length := Vector2(a.x, a.z).distance_to(Vector2(b.x, b.z))
		if remaining <= segment_length or i == route.size() - 2:
			return a.lerp(b, clampf(remaining / maxf(segment_length, 0.001), 0.0, 1.0))
		remaining -= segment_length
	return route[route.size() - 1]

func _find_caravan(caravan_id: String) -> int:
	for i in range(_active.size()):
		if str(_active[i].get("id", "")) == caravan_id:
			return i
	return -1

func _update_caravan_visual(c: Dictionary, delta: float) -> void:
	var visual: Node3D = c.get("visual") as Node3D
	if not is_instance_valid(visual):
		return
	var pos: Vector3 = c.get("position", Vector3.ZERO)
	visual.global_position = pos
	var route: Array = c.get("route", [c.get("start", pos), c.get("end", pos)])
	var progress := float(c.get("progress", 0.0))
	var direction: Vector3 = _route_position(route, minf(1.0, progress + 0.02)) - _route_position(route, maxf(0.0, progress - 0.02))
	direction.y = 0.0
	if direction.length() > 0.01:
		visual.rotation.y = atan2(-direction.x, -direction.z)
	for wheel in visual.get_children():
		if wheel is MeshInstance3D and wheel.has_meta("caravan_wheel"):
			wheel.rotate_x(delta * 2.8)
	var guards: Node3D = visual.get_node_or_null("Guards") as Node3D
	if guards:
		guards.visible = true

func _update_replica_visuals(delta: float) -> void:
	for c in _active:
		_update_caravan_visual(c, delta)

func _apply_ambush_visual(c: Dictionary) -> void:
	var visual: Node3D = c.get("visual") as Node3D
	if not is_instance_valid(visual) or visual.has_node("Ambushers"):
		return
	var ambushers := Node3D.new()
	ambushers.name = "Ambushers"
	visual.add_child(ambushers)
	var bandit_mat := _mat(Color(0.22, 0.17, 0.16))
	var steel_mat := _mat(Color(0.55, 0.57, 0.58), 0.4)
	for i in range(4):
		var bandit := Node3D.new()
		bandit.position = Vector3(-4.0 + float(i % 2) * 8.0, 0.0, -2.5 if i < 2 else 2.5)
		ambushers.add_child(bandit)
		_add_capsule(bandit, Vector3(0, 0.92, 0), 0.24, 0.95, bandit_mat)
		_add_sphere(bandit, Vector3(0, 1.62, 0), 0.19, bandit_mat)
		_add_box(bandit, Vector3(0.38, 0.9, -0.05), Vector3(0.09, 0.75, 0.09), steel_mat)
		_add_box(bandit, Vector3(0.38, 1.28, -0.05), Vector3(0.055, 0.48, 0.055), steel_mat)
	var label := Label3D.new()
	label.name = "AmbushResult"
	label.text = "BANDIT AMBUSH"
	label.font_size = 24
	label.outline_size = 8
	label.shaded = false
	label.modulate = Color(1.0, 0.45, 0.28)
	label.outline_modulate = Color(0.02, 0.01, 0.01)
	label.position = Vector3(0, 2.8, 0)
	ambushers.add_child(label)

func _resolve_ambush_visual(c: Dictionary) -> void:
	var visual: Node3D = c.get("visual") as Node3D
	if not is_instance_valid(visual):
		return
	var ambushers: Node3D = visual.get_node_or_null("Ambushers") as Node3D
	if not bool(c.get("cargo_lost", false)):
		if is_instance_valid(ambushers):
			ambushers.queue_free()
		var result_label := Label3D.new()
		result_label.name = "AmbushResult"
		result_label.text = "GUARDS HOLD THE ROAD"
		result_label.font_size = 20
		result_label.outline_size = 7
		result_label.shaded = false
		result_label.modulate = Color(0.55, 1.0, 0.62)
		result_label.outline_modulate = Color(0.01, 0.02, 0.01)
		result_label.position = Vector3(0, 2.8, 0)
		visual.add_child(result_label)
	else:
		var result_label := visual.get_node_or_null("Ambushers/AmbushResult") as Label3D
		if is_instance_valid(result_label):
			result_label.text = "CARGO SEIZED"
			result_label.modulate = Color(1.0, 0.32, 0.22)

func _remove_caravan_visual(c: Dictionary) -> void:
	var visual: Node3D = c.get("visual") as Node3D
	if is_instance_valid(visual):
		visual.queue_free()

func _build_caravan_visual(caravan_name: String, cargo_type: String, cargo_amount: float) -> Node3D:
	var root := Node3D.new()
	root.name = "TradeCaravan_%s" % str(Time.get_ticks_msec())
	root.set_meta("trade_caravan", true)
	var wood := _mat(Color(0.31, 0.20, 0.12))
	var canvas := _mat(Color(0.58, 0.39, 0.22))
	var metal := _mat(Color(0.22, 0.23, 0.24), 0.35)
	_add_box(root, Vector3(0, 0.9, 0), Vector3(2.0, 0.28, 3.0), wood)
	for side in [-0.88, 0.88]:
		var wheel := MeshInstance3D.new()
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.62
		mesh.bottom_radius = 0.62
		mesh.height = 0.16
		mesh.radial_segments = 12
		wheel.mesh = mesh
		wheel.material_override = wood
		wheel.position = Vector3(side, 0.62, 0.0)
		wheel.rotation.z = PI * 0.5
		wheel.set_meta("caravan_wheel", true)
		root.add_child(wheel)
	var crate_count := clampi(int(ceil(cargo_amount / 2.0)), 2, 8)
	for i in range(crate_count):
		var crate_mat := canvas if cargo_type == "food" and i % 3 == 0 else wood
		_add_box(root, Vector3(-0.58 + float(i % 3) * 0.58, 1.34 + float(i / 3) * 0.48, -0.65 + float(i / 3) * 0.9), Vector3(0.52, 0.48, 0.52), crate_mat)
	# Draft horse and harness, visibly pulling the cart.
	var horse := Node3D.new()
	horse.name = "DraftHorse"
	horse.position = Vector3(0, 0, -2.15)
	root.add_child(horse)
	var horse_mat := _mat(Color(0.39, 0.23, 0.15))
	_add_capsule(horse, Vector3(0, 0.88, 0), 0.28, 1.1, horse_mat)
	_add_sphere(horse, Vector3(0, 1.48, -0.32), 0.2, horse_mat)
	for side in [-1.0, 1.0]:
		_add_box(horse, Vector3(side * 0.17, 0.38, 0.0), Vector3(0.11, 0.72, 0.12), horse_mat)
	# Two armed escorts accompany every shipment.
	var guards := Node3D.new()
	guards.name = "Guards"
	root.add_child(guards)
	var guard_mat := _mat(Color(0.22, 0.29, 0.34))
	for side in [-1.0, 1.0]:
		var guard := Node3D.new()
		guard.position = Vector3(side * 1.8, 0.0, 0.7)
		guards.add_child(guard)
		_add_capsule(guard, Vector3(0, 0.88, 0), 0.22, 0.95, guard_mat)
		_add_sphere(guard, Vector3(0, 1.55, 0), 0.17, _mat(Color(0.66, 0.49, 0.34)))
		_add_box(guard, Vector3(side * 0.22, 0.9, -0.08), Vector3(0.08, 0.72, 0.08), metal)
	var sign := Label3D.new()
	sign.text = "%s  |  %s" % ["TRADE CARAVAN", cargo_type.to_upper()]
	sign.font_size = 20
	sign.outline_size = 7
	sign.shaded = false
	sign.modulate = Color(0.95, 0.82, 0.56)
	sign.outline_modulate = Color(0.02, 0.015, 0.01)
	sign.position = Vector3(0, 2.35, -1.3)
	root.add_child(sign)
	root.set_meta("route_name", caravan_name)
	return root

func _mat(color: Color, roughness: float = 0.9) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	return material

func _add_box(parent: Node3D, position: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.material_override = material
	instance.position = position
	parent.add_child(instance)
	return instance

func _add_sphere(parent: Node3D, position: Vector3, radius: float, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	instance.mesh = mesh
	instance.material_override = material
	instance.position = position
	parent.add_child(instance)
	return instance

func _add_capsule(parent: Node3D, position: Vector3, radius: float, height: float, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	instance.mesh = mesh
	instance.material_override = material
	instance.position = position
	parent.add_child(instance)
	return instance

@rpc("authority", "reliable")
func client_spawn_caravan(payload: Dictionary) -> void:
	if MMORPGNetwork.is_authority():
		return
	_apply_caravan_spawn(payload)

@rpc("authority", "unreliable")
func client_update_caravan(caravan_id: String, position: Vector3, progress: float, attacked: bool, ambush_position: Vector3, ambush_resolved: bool, cargo_lost: bool) -> void:
	if MMORPGNetwork.is_authority():
		return
	var index := _find_caravan(caravan_id)
	if index < 0:
		return
	var c: Dictionary = _active[index]
	c["position"] = position
	c["progress"] = progress
	if attacked and not bool(c.get("attacked", false)):
		c["attacked"] = true
		c["ambush_position"] = ambush_position
		_apply_ambush_visual(c)
	if ambush_resolved and not bool(c.get("ambush_resolved", false)):
		c["ambush_resolved"] = true
		c["cargo_lost"] = cargo_lost
		_resolve_ambush_visual(c)
	_active[index] = c

@rpc("authority", "reliable")
func client_remove_caravan(caravan_id: String) -> void:
	if MMORPGNetwork.is_authority():
		return
	var index := _find_caravan(caravan_id)
	if index >= 0:
		_remove_caravan_visual(_active[index])
		_active.remove_at(index)

@rpc("authority", "reliable")
func client_receive_caravan_snapshot(snapshot: Array) -> void:
	if MMORPGNetwork.is_authority():
		return
	for existing in _active:
		_remove_caravan_visual(existing)
	_active.clear()
	for payload in snapshot:
		if payload is Dictionary:
			_apply_caravan_spawn(payload)

func get_map_markers() -> Array:
	var out: Array = []
	for c in _active:
		var pos: Vector3 = c.get("position", Vector3.ZERO)
		out.append({"name": "Caravan", "pos": Vector2(pos.x, pos.z), "kind": "caravan", "title": "Trade Route", "color": Color(0.95, 0.8, 0.3)})
	return out
