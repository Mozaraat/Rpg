# Small environmental details that make the world feel inhabited.
# Effects follow the player but change by biome, weather and time of day.
extends Node3D
class_name ImmersionDirector

var _particles: CPUParticles3D
var _ambient_player: AudioStreamPlayer3D
var _call_timer: float = 9.0
var _last_profile: String = ""
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	add_to_group("immersion_director")
	_rng.seed = GameManager.world_seed ^ 0x51A7
	_build_particles()
	_build_ambient_audio()

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		if _particles:
			_particles.emitting = false
		return
	var player: Node3D = GameManager.player as Node3D
	if player == null:
		return
	var profile := _profile_for_player(player)
	if profile != _last_profile:
		_last_profile = profile
		_apply_profile(profile)
	if _particles:
		_particles.global_position = player.global_position + Vector3(0, 2.8, 0)
	_call_timer -= delta
	if _call_timer <= 0.0:
		_call_timer = _rng.randf_range(13.0, 25.0)
		_try_ambient_call(player, profile)

func _profile_for_player(player: Node3D) -> String:
	if get_tree().get_first_node_in_group("dungeon_active"):
		return "dungeon"
	var x := player.global_position.x
	var z := player.global_position.z
	if x > 28.0 and z > -35.0:
		return "coast"
	if x < -42.0 and z > -65.0:
		return "woods"
	if x < -25.0 and z < -72.0:
		return "mountains"
	var dn := get_tree().get_first_node_in_group("day_night")
	if dn and not bool(dn.is_day):
		return "night"
	return "meadows"

func _build_particles() -> void:
	_particles = CPUParticles3D.new()
	_particles.name = "LocalAtmosphere"
	_particles.amount = 90
	_particles.lifetime = 5.0
	_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_particles.emission_box_extents = Vector3(15.0, 5.0, 15.0)
	_particles.direction = Vector3(0.12, 0.3, 0.08)
	_particles.spread = 48.0
	_particles.initial_velocity_min = 0.08
	_particles.initial_velocity_max = 0.42
	_particles.gravity = Vector3(0.0, 0.025, 0.0)
	_particles.damping_min = 0.02
	_particles.damping_max = 0.08
	_particles.emitting = false
	var mesh := SphereMesh.new()
	mesh.radius = 0.025
	mesh.height = 0.05
	_particles.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.9, 0.83, 0.58, 0.48)
	mat.emission_enabled = true
	mat.emission = Color(0.55, 0.44, 0.2)
	mat.emission_energy_multiplier = 0.35
	_particles.material_override = mat
	add_child(_particles)

func _apply_profile(profile: String) -> void:
	if _particles == null:
		return
	var mat := _particles.material_override as StandardMaterial3D
	_particles.emitting = profile != "village"
	_particles.amount = 120 if profile == "woods" else 70
	_particles.lifetime = 6.5 if profile == "coast" else 4.5
	_particles.initial_velocity_min = 0.05
	_particles.initial_velocity_max = 0.3
	match profile:
		"woods":
			mat.albedo_color = Color(0.75, 0.9, 0.58, 0.5)
			mat.emission = Color(0.28, 0.45, 0.12)
		"coast":
			mat.albedo_color = Color(0.75, 0.88, 1.0, 0.35)
			mat.emission = Color(0.18, 0.32, 0.42)
		"mountains":
			mat.albedo_color = Color(0.9, 0.88, 0.8, 0.4)
			mat.emission = Color(0.3, 0.28, 0.22)
		"dungeon":
			mat.albedo_color = Color(0.62, 0.55, 0.42, 0.4)
			mat.emission = Color(0.24, 0.12, 0.04)
		"night":
			mat.albedo_color = Color(0.48, 0.72, 1.0, 0.7)
			mat.emission = Color(0.16, 0.38, 0.9)
			mat.emission_energy_multiplier = 1.1
		_:
			mat.albedo_color = Color(0.95, 0.84, 0.56, 0.42)
			mat.emission = Color(0.4, 0.3, 0.12)
	mat.emission_energy_multiplier = 0.7 if profile == "night" else 0.3

func _build_ambient_audio() -> void:
	_ambient_player = AudioStreamPlayer3D.new()
	_ambient_player.name = "DistantWildlifeCall"
	_ambient_player.bus = "Master"
	_ambient_player.volume_db = -23.0
	_ambient_player.max_distance = 48.0
	_ambient_player.unit_size = 8.0
	_ambient_player.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	_ambient_player.stream = _make_bird_call()
	add_child(_ambient_player)

func _make_bird_call() -> AudioStreamWAV:
	const RATE := 22050
	const LENGTH := 0.72
	var bytes := PackedByteArray()
	var count := int(RATE * LENGTH)
	bytes.resize(count * 2)
	for i in range(count):
		var t := float(i) / float(RATE)
		var env := 0.0
		for start in [0.04, 0.29, 0.49]:
			var local_t: float = t - float(start)
			if local_t >= 0.0 and local_t < 0.16:
				env += sin(PI * local_t / 0.16) * (1.0 - local_t / 0.16)
		var sweep := 1150.0 + 680.0 * sin(TAU * t * 1.15)
		var sample := sin(TAU * sweep * t) * env * 0.12
		bytes.encode_s16(i * 2, int(clampf(sample, -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	return wav

func _try_ambient_call(player: Node3D, profile: String) -> void:
	if profile == "dungeon" or profile == "mountains":
		return
	var weather := get_tree().get_first_node_in_group("weather")
	if weather and str(weather.get("kind")) == "storm":
		return
	var angle := _rng.randf_range(0.0, TAU)
	var distance := _rng.randf_range(9.0, 22.0)
	_ambient_player.global_position = player.global_position + Vector3(cos(angle) * distance, _rng.randf_range(2.0, 5.0), sin(angle) * distance)
	_ambient_player.pitch_scale = _rng.randf_range(0.82, 1.18)
	if not _ambient_player.playing:
		_ambient_player.play()
