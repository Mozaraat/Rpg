# DungeonFloorDressing - SAO-style floor architecture for the hundred-floor raid.
#
# A floor is a floating slab of light-sealed architecture: perimeter barriers of
# light instead of a cave roof, heavy doors that unlock when a chamber is
# cleared, a grand stairway down to the next floor and a guardian crystal that
# tracks the floor boss. Everything is built from real geometry so doors can
# block, open and animate without fake tricks.
class_name DungeonFloorDressing
extends RefCounted

const DOOR_WIDTH: float = 4.2
const DOOR_HEIGHT: float = 4.8
const WALL_HEIGHT: float = 8.4
const BARRIER_HEIGHT: float = 30.0

static var _barrier_materials: Dictionary = {}
static var _stone_materials: Dictionary = {}
static var _ceiling_materials: Dictionary = {}

static func barrier_material(glow: Color, mode: int) -> ShaderMaterial:
	if mode == 1:
		return ceiling_material(glow)
	var key: String = "%s_%d" % [glow.to_html(false), mode]
	if _barrier_materials.has(key):
		return _barrier_materials[key]
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/dungeon_barrier.gdshader")
	mat.set_shader_parameter("barrier_color", glow)
	mat.set_shader_parameter("barrier_mode", mode)
	_barrier_materials[key] = mat
	return mat

# The ceiling has to be genuinely opaque: a light-sealed floor with the void
# showing through overhead reads as an open platform, not a dungeon.
static func ceiling_material(glow: Color) -> ShaderMaterial:
	var key: String = glow.to_html(false)
	if _ceiling_materials.has(key):
		return _ceiling_materials[key]
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/dungeon_ceiling.gdshader")
	mat.set_shader_parameter("barrier_color", glow)
	_ceiling_materials[key] = mat
	return mat

static func stone_material(color: Color, roughness: float = 0.9, metallic: float = 0.04) -> StandardMaterial3D:
	var key: String = "%s_%.2f_%.2f" % [color.to_html(false), roughness, metallic]
	if _stone_materials.has(key):
		return _stone_materials[key]
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	_stone_materials[key] = mat
	return mat

static func glow_material(color: Color, energy: float = 2.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	mat.roughness = 0.35
	mat.metallic = 0.25
	return mat

static func box(parent: Node, node_name: String, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

static func cylinder(parent: Node, node_name: String, pos: Vector3, top_radius: float, bottom_radius: float, height: float, material: Material, segments: int = 12) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	mesh.radial_segments = segments
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

# --- Floor envelope -------------------------------------------------------

static func build_floor_envelope(parent: Node3D, span: float, stone: Color, trim: Color, glow: Color) -> void:
	# A solid coffered ceiling seals the floor overhead and a curtain of light walls
	# closes its perimeter, so the slab reads as an enclosed dungeon storey.
	var ceiling := MeshInstance3D.new()
	ceiling.name = "FloorStoneCeiling"
	var plane := PlaneMesh.new()
	plane.size = Vector2(span, span)
	ceiling.mesh = plane
	ceiling.material_override = ceiling_material(glow)
	ceiling.position.y = WALL_HEIGHT + 0.05
	parent.add_child(ceiling)

	var half: float = span * 0.5
	var barrier_mat := barrier_material(glow, 0)
	for side in [-1.0, 1.0]:
		var wall := MeshInstance3D.new()
		wall.name = "PerimeterBarrierX"
		var wall_mesh := PlaneMesh.new()
		wall_mesh.size = Vector2(span, BARRIER_HEIGHT)
		wall.mesh = wall_mesh
		wall.material_override = barrier_mat
		wall.position = Vector3(side * (half + 0.9), BARRIER_HEIGHT * 0.5, 0)
		wall.rotation.y = PI * 0.5
		parent.add_child(wall)
		var wall_z := MeshInstance3D.new()
		wall_z.name = "PerimeterBarrierZ"
		var wall_z_mesh := PlaneMesh.new()
		wall_z_mesh.size = Vector2(span, BARRIER_HEIGHT)
		wall_z.mesh = wall_z_mesh
		wall_z.material_override = barrier_mat
		wall_z.position = Vector3(0, BARRIER_HEIGHT * 0.5, side * (half + 0.9))
		parent.add_child(wall_z)

	# Corner pylons anchor the light curtain and give the silhouette structure.
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var pylon := Node3D.new()
			pylon.name = "BarrierPylon"
			pylon.position = Vector3(sx * (half + 1.2), 0.0, sz * (half + 1.2))
			parent.add_child(pylon)
			cylinder(pylon, "PylonFoot", Vector3(0, 0.5, 0), 2.1, 2.6, 1.0, stone_material(stone.darkened(0.06)), 8)
			cylinder(pylon, "PylonShaft", Vector3(0, 8.0, 0), 1.35, 1.9, 14.0, stone_material(stone), 8)
			cylinder(pylon, "PylonCollar", Vector3(0, 15.4, 0), 1.75, 1.45, 1.1, stone_material(trim), 8)
			var capstone := cylinder(pylon, "PylonBeacon", Vector3(0, 16.6, 0), 0.9, 1.5, 1.6, glow_material(glow, 2.6), 8)
			capstone.rotation.x = PI * 0.5
			var light := OmniLight3D.new()
			light.light_color = glow
			light.light_energy = 1.4
			light.omni_range = 30.0
			light.position = Vector3(0, 17.0, 0)
			pylon.add_child(light)

static func build_cloud_sea(parent: Node3D, span: float, glow: Color) -> void:
	# Far below the slab, a slow cloud sea hides the void and gives the drop real depth.
	var sea := MeshInstance3D.new()
	sea.name = "CloudSea"
	var plane := PlaneMesh.new()
	plane.size = Vector2(span * 2.4, span * 2.4)
	sea.mesh = plane
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.74, 0.80, 0.90)
	mat.emission_enabled = true
	mat.emission = Color(0.42, 0.50, 0.66)
	mat.emission_energy_multiplier = 0.35
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color.a = 0.92
	sea.material_override = mat
	sea.position.y = -46.0
	parent.add_child(sea)
	var rng := RandomNumberGenerator.new()
	rng.seed = 9173
	for i in range(26):
		var puff := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = rng.randf_range(7.0, 15.0)
		sphere.radial_segments = 8
		sphere.rings = 5
		puff.mesh = sphere
		var puff_mat := StandardMaterial3D.new()
		puff_mat.albedo_color = Color(0.82, 0.87, 0.95, 0.55)
		puff_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		puff_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		puff.material_override = puff_mat
		puff.position = Vector3(rng.randf_range(-span, span), rng.randf_range(-40.0, -30.0), rng.randf_range(-span, span))
		puff.scale = Vector3(1.0, 0.22, 1.0)
		parent.add_child(puff)

# --- Doors ----------------------------------------------------------------

static func build_wall_panel(parent: Node3D, center: Vector3, along_x: bool, stone: Color, trim: Color, glow: Color) -> void:
	# A stone panel that closes a cell opening: flanking walls plus a dressed frame.
	var panel := Node3D.new()
	panel.name = "ChamberWall"
	panel.position = center
	parent.add_child(panel)
	var axis := Vector3.RIGHT if along_x else Vector3.FORWARD
	var side_len: float = 5.9
	for sign in [-1.0, 1.0]:
		var flank_center: Vector3 = axis * (sign * (DOOR_WIDTH * 0.5 + side_len * 0.5))
		var flank_size := Vector3(side_len, WALL_HEIGHT, 0.8) if along_x else Vector3(0.8, WALL_HEIGHT, side_len)
		var flank := StaticBody3D.new()
		flank.name = "ChamberFlank"
		flank.collision_layer = Constants.LAYER_WORLD
		flank.collision_mask = 0
		flank.position = flank_center
		var flank_mesh := MeshInstance3D.new()
		var flank_box := BoxMesh.new()
		flank_box.size = flank_size
		flank_mesh.mesh = flank_box
		flank_mesh.material_override = stone_material(stone)
		flank.add_child(flank_mesh)
		var flank_shape := CollisionShape3D.new()
		var flank_collision := BoxShape3D.new()
		flank_collision.size = flank_size
		flank_shape.shape = flank_collision
		flank.add_child(flank_shape)
		panel.add_child(flank)
	for sign in [-1.0, 1.0]:
		box(panel, "DoorJamb", axis * (sign * (DOOR_WIDTH * 0.5 + 0.25)) + Vector3(0, DOOR_HEIGHT * 0.5, 0), Vector3(0.7, DOOR_HEIGHT, 1.2), stone_material(trim))
	box(panel, "DoorLintel", Vector3(0, DOOR_HEIGHT + 0.35, 0), Vector3(DOOR_WIDTH + 1.6, 0.7, 1.3), stone_material(trim))
	# Transom closes the wall above the door so the chamber stays sealed to the ceiling.
	var transom_bottom: float = DOOR_HEIGHT + 0.7
	if WALL_HEIGHT > transom_bottom:
		box(panel, "DoorTransom", Vector3(0, (transom_bottom + WALL_HEIGHT) * 0.5, 0), Vector3(DOOR_WIDTH + 1.6, WALL_HEIGHT - transom_bottom, 0.9), stone_material(stone))
	box(panel, "DoorThreshold", Vector3(0, 0.08, 0), Vector3(DOOR_WIDTH + 1.2, 0.16, 1.6), stone_material(stone.lightened(0.05)))

static func build_door(parent: Node3D, center: Vector3, along_x: bool, room_cells: Array[Vector2i], floor_index: int, stone: Color, trim: Color, glow: Color) -> Node3D:
	# A framed stone doorway with two iron-banded leaves. The leaves block the
	# passage until every hostile in the chamber beyond has fallen.
	var door := Node3D.new()
	door.name = "ChamberDoor"
	door.position = center
	var axis := Vector3.RIGHT if along_x else Vector3.FORWARD
	# The script is attached before the node enters the tree so its _ready runs
	# with the leaves, seals and blocking collider already in place.
	door.set_script(load("res://entities/dungeon_door.gd"))
	door.set("room_cells", room_cells)
	door.set("floor_index", floor_index)
	door.set("leaf_axis", axis)
	build_wall_panel(door, Vector3.ZERO, along_x, stone, trim, glow)

	var leaves := Node3D.new()
	leaves.name = "DoorLeaves"
	door.add_child(leaves)
	var leaf_width: float = DOOR_WIDTH * 0.5 - 0.04
	for sign in [-1.0, 1.0]:
		var leaf := MeshInstance3D.new()
		leaf.name = "DoorLeaf"
		var leaf_mesh := BoxMesh.new()
		leaf_mesh.size = Vector3(leaf_width, DOOR_HEIGHT - 0.1, 0.26)
		leaf.mesh = leaf_mesh
		leaf.material_override = stone_material(trim.darkened(0.18), 0.72, 0.18)
		leaf.position = axis * (sign * leaf_width * 0.5)
		leaves.add_child(leaf)
		for band_i in range(3):
			var band := MeshInstance3D.new()
			var band_mesh := BoxMesh.new()
			band_mesh.size = Vector3(leaf_width * 0.96, 0.16, 0.32)
			band.mesh = band_mesh
			band.material_override = stone_material(Color(0.13, 0.12, 0.12), 0.55, 0.55)
			band.position = axis * (sign * leaf_width * 0.5) + Vector3(0, -1.5 + float(band_i) * 1.5, 0)
			leaves.add_child(band)
		var seal := MeshInstance3D.new()
		seal.name = "DoorSeal"
		var seal_mesh := PrismMesh.new()
		seal_mesh.size = Vector3(0.34, 0.9, 0.34)
		seal.mesh = seal_mesh
		seal.material_override = glow_material(glow, 2.4)
		seal.position = axis * (sign * leaf_width * 0.5) + Vector3(0, 0.5, 0)
		leaves.add_child(seal)

	var block := StaticBody3D.new()
	block.name = "DoorBlock"
	block.collision_layer = Constants.LAYER_WORLD
	block.collision_mask = 0
	var block_shape := CollisionShape3D.new()
	var block_collision := BoxShape3D.new()
	block_collision.size = Vector3(DOOR_WIDTH, DOOR_HEIGHT, 0.6) if along_x else Vector3(0.6, DOOR_HEIGHT, DOOR_WIDTH)
	block_shape.shape = block_collision
	block.add_child(block_shape)
	door.add_child(block)

	var light := OmniLight3D.new()
	light.light_color = glow
	light.light_energy = 1.1
	light.omni_range = 9.0
	light.position = Vector3(0, DOOR_HEIGHT - 0.4, 0)
	door.add_child(light)

	parent.add_child(door)
	return door

# --- Stairway and guardian ------------------------------------------------

static func build_stair_chamber(parent: Node3D, center: Vector3, stone: Color, trim: Color, glow: Color, next_floor_label: String) -> Node3D:
	# The way down. A broad ramp climbs to a landing, and behind the landing a lit
	# shaft drops into the floor below, so the gate reads as a descent rather than
	# a staircase to nowhere. The flight is a ramp, not steps, so it is walkable.
	var chamber := Node3D.new()
	chamber.name = "DescentStairChamber"
	chamber.position = center
	parent.add_child(chamber)

	var flight_width: float = 8.0
	var flight_run: float = 7.0
	var flight_rise: float = 2.4
	var slope: float = atan2(flight_rise, flight_run)
	var ramp_length: float = sqrt(flight_run * flight_run + flight_rise * flight_rise)

	var ramp := box(chamber, "DescentRamp", Vector3(0, flight_rise * 0.5, 0), Vector3(flight_width, 0.5, ramp_length), stone_material(stone.lightened(0.04)))
	ramp.rotation.x = slope
	for side in [-1.0, 1.0]:
		var cheek := box(chamber, "StairCheekWall", Vector3(side * (flight_width * 0.5 + 0.45), flight_rise * 0.5 + 0.85, 0), Vector3(0.9, 1.7, ramp_length), stone_material(stone.darkened(0.05)))
		cheek.rotation.x = slope
		var rail := box(chamber, "StairHandrail", Vector3(side * (flight_width * 0.5 + 0.45), flight_rise * 0.5 + 1.78, 0), Vector3(0.26, 0.26, ramp_length), stone_material(trim))
		rail.rotation.x = slope

	# Landing at the head of the flight.
	var landing_z: float = -flight_run * 0.5 - 1.8
	box(chamber, "DescentLanding", Vector3(0, flight_rise, landing_z), Vector3(flight_width + 1.2, 0.5, 3.8), stone_material(stone.lightened(0.06)))
	# Shaft descending behind the gate: a stack of light rings marks the drop.
	var shaft_z: float = landing_z - 2.9
	box(chamber, "DescentShaft", Vector3(0, flight_rise - 4.4, shaft_z), Vector3(6.4, 10.0, 4.2), stone_material(stone.darkened(0.22)))
	for ring_i in range(4):
		var ring := MeshInstance3D.new()
		ring.name = "DescentShaftRing"
		var ring_mesh := TorusMesh.new()
		ring_mesh.inner_radius = 1.5
		ring_mesh.outer_radius = 1.72
		ring_mesh.rings = 24
		ring_mesh.ring_segments = 8
		ring.mesh = ring_mesh
		ring.material_override = glow_material(glow, 1.8)
		ring.position = Vector3(0, flight_rise - 1.2 - float(ring_i) * 2.1, shaft_z)
		chamber.add_child(ring)

	# Monumental gate frame standing on the landing.
	var gate_z: float = landing_z - 1.9
	for side in [-1.0, 1.0]:
		box(chamber, "DescentGatePier", Vector3(side * 2.9, flight_rise + 2.6, gate_z), Vector3(1.0, 5.2, 1.5), stone_material(stone))
		box(chamber, "DescentGatePierTrim", Vector3(side * 2.9, flight_rise + 0.35, gate_z), Vector3(1.5, 0.7, 1.9), stone_material(trim))
		var banner := box(chamber, "DescentGateBanner", Vector3(side * 3.9, flight_rise + 3.0, gate_z + 0.9), Vector3(1.1, 3.2, 0.06), stone_material(trim.darkened(0.25), 0.95, 0.0))
		banner.rotation.z = side * 0.02
	box(chamber, "DescentGateLintel", Vector3(0, flight_rise + 5.5, gate_z), Vector3(7.2, 0.9, 1.8), stone_material(trim))
	box(chamber, "DescentGateKeystone", Vector3(0, flight_rise + 6.15, gate_z), Vector3(1.2, 0.5, 2.0), glow_material(glow, 1.6))

	var portal := MeshInstance3D.new()
	portal.name = "DescentPortal"
	var portal_mesh := QuadMesh.new()
	portal_mesh.size = Vector2(4.6, 4.2)
	portal.mesh = portal_mesh
	var portal_mat := StandardMaterial3D.new()
	portal_mat.albedo_color = Color(0.03, 0.02, 0.07, 0.9)
	portal_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	portal_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	portal_mat.emission_enabled = true
	portal_mat.emission = glow
	portal_mat.emission_energy_multiplier = 2.4
	portal.material_override = portal_mat
	portal.position = Vector3(0, flight_rise + 2.3, gate_z + 0.1)
	chamber.add_child(portal)

	var ring := MeshInstance3D.new()
	ring.name = "DescentPortalRing"
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 2.25
	ring_mesh.outer_radius = 2.55
	ring_mesh.rings = 30
	ring_mesh.ring_segments = 10
	ring.mesh = ring_mesh
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = glow
	ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ring_mat.emission_enabled = true
	ring_mat.emission = glow
	ring_mat.emission_energy_multiplier = 2.0
	ring.material_override = ring_mat
	ring.rotation.x = PI * 0.5
	ring.position = Vector3(0, flight_rise + 2.3, gate_z + 0.05)
	chamber.add_child(ring)

	var portal_light := OmniLight3D.new()
	portal_light.light_color = glow
	portal_light.light_energy = 2.4
	portal_light.omni_range = 17.0
	portal_light.position = Vector3(0, flight_rise + 2.4, gate_z + 1.4)
	chamber.add_child(portal_light)

	var sign := Label3D.new()
	sign.name = "DescentSign"
	sign.text = next_floor_label
	sign.font_size = 26
	sign.position = Vector3(0, flight_rise + 6.2, gate_z)
	sign.modulate = glow.lightened(0.25)
	sign.outline_size = 6
	sign.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	chamber.add_child(sign)

	# Guardian statues flank the foot of the flight.
	for sign_side in [-1.0, 1.0]:
		var statue := Node3D.new()
		statue.name = "StairGuardianStatue"
		statue.position = Vector3(sign_side * 5.2, 0.0, flight_run * 0.5 + 1.2)
		chamber.add_child(statue)
		cylinder(statue, "StatuePlinth", Vector3(0, 0.45, 0), 0.95, 1.15, 0.9, stone_material(trim), 8)
		cylinder(statue, "StatueBody", Vector3(0, 2.2, 0), 0.52, 0.78, 2.7, stone_material(stone.lightened(0.06)), 8)
		cylinder(statue, "StatueHead", Vector3(0, 3.8, 0), 0.34, 0.44, 0.7, stone_material(stone.lightened(0.1)), 8)
		var eye := MeshInstance3D.new()
		var eye_mesh := SphereMesh.new()
		eye_mesh.radius = 0.12
		eye_mesh.height = 0.24
		eye.mesh = eye_mesh
		eye.material_override = glow_material(glow, 2.2)
		eye.position = Vector3(0, 3.85, -0.36)
		statue.add_child(eye)
	return chamber

static func build_guardian_crystal(parent: Node3D, center: Vector3, glow: Color) -> Node3D:
	# The floor guardian's core hangs under the light ceiling over the arena and
	# dims as the guardian falls.
	var core := Node3D.new()
	core.name = "GuardianCore"
	core.position = center + Vector3(0, 7.4, -16.0)
	core.set_meta("dungeon_floor", parent.get_meta("dungeon_floor", -1))
	core.set_script(load("res://entities/dungeon_guardian_crystal.gd"))
	core.set("glow_color", glow)
	var crystal := MeshInstance3D.new()
	crystal.name = "GuardianCrystal"
	var prism := PrismMesh.new()
	prism.size = Vector3(1.0, 1.8, 1.0)
	crystal.mesh = prism
	crystal.material_override = glow_material(glow, 2.2)
	core.add_child(crystal)
	var halo := MeshInstance3D.new()
	halo.name = "GuardianHalo"
	var torus := TorusMesh.new()
	torus.inner_radius = 1.1
	torus.outer_radius = 1.22
	torus.rings = 30
	torus.ring_segments = 8
	halo.mesh = torus
	halo.material_override = glow_material(glow.lightened(0.25), 1.6)
	halo.rotation.x = PI * 0.5
	core.add_child(halo)
	var light := OmniLight3D.new()
	light.light_color = glow
	light.light_energy = 2.6
	light.omni_range = 26.0
	core.add_child(light)
	core.set("crystal_node", crystal)
	core.set("halo_node", halo)
	parent.add_child(core)
	return core

# --- Props ----------------------------------------------------------------

static func face_toward(node: Node3D, direction: Vector3) -> void:
	# Orientation is set directly instead of with look_at, because dressing is
	# built before the room node enters the tree.
	var z_axis := -direction.normalized()
	if z_axis.length() < 0.001:
		return
	var x_axis := Vector3.UP.cross(z_axis)
	if x_axis.length() < 0.001:
		x_axis = Vector3.RIGHT
	x_axis = x_axis.normalized()
	var y_axis := z_axis.cross(x_axis).normalized()
	node.basis = Basis(x_axis, y_axis, z_axis)

static func build_sconce(parent: Node3D, pos: Vector3, facing: Vector3, glow: Color) -> void:
	# Wall bracket torch: the corridor's readable light source.
	var sconce := Node3D.new()
	sconce.name = "WallSconce"
	sconce.position = pos
	face_toward(sconce, facing)
	parent.add_child(sconce)
	box(sconce, "SconceBracket", Vector3(0, 0, 0.18), Vector3(0.16, 0.42, 0.5), stone_material(Color(0.12, 0.11, 0.10), 0.6, 0.5))
	var flame := MeshInstance3D.new()
	var flame_mesh := SphereMesh.new()
	flame_mesh.radius = 0.16
	flame_mesh.height = 0.36
	flame.mesh = flame_mesh
	flame.material_override = glow_material(glow, 3.0)
	flame.position = Vector3(0, 0.28, 0.36)
	sconce.add_child(flame)
	var light := OmniLight3D.new()
	light.light_color = glow
	light.light_energy = 2.1
	light.omni_range = 13.0
	light.position = Vector3(0, 0.42, 0.55)
	sconce.add_child(light)

static func build_banner(parent: Node3D, pos: Vector3, facing: Vector3, cloth: Color, glow: Color) -> void:
	var banner := Node3D.new()
	banner.name = "WallBanner"
	banner.position = pos
	face_toward(banner, facing)
	parent.add_child(banner)
	box(banner, "BannerRod", Vector3(0, 2.5, 0.06), Vector3(1.7, 0.12, 0.12), stone_material(Color(0.18, 0.15, 0.13), 0.6, 0.45))
	var cloth_mesh := box(banner, "BannerCloth", Vector3(0, 1.55, 0.02), Vector3(1.25, 2.1, 0.05), stone_material(cloth, 0.95, 0.0))
	cloth_mesh.rotation.z = 0.0
	var emblem := box(banner, "BannerEmblem", Vector3(0, 1.6, 0.07), Vector3(0.5, 0.5, 0.06), glow_material(glow, 1.5))
	emblem.rotation.z = PI * 0.25

static func build_supply_crate(parent: Node3D, pos: Vector3, yaw: float, wood: Color) -> void:
	var crate := Node3D.new()
	crate.name = "SupplyCrate"
	crate.position = pos
	crate.rotation.y = yaw
	parent.add_child(crate)
	box(crate, "CrateBody", Vector3(0, 0.42, 0), Vector3(0.95, 0.84, 0.95), stone_material(wood, 0.94, 0.0))
	box(crate, "CrateLid", Vector3(0, 0.88, 0), Vector3(1.02, 0.1, 1.02), stone_material(wood.darkened(0.08), 0.94, 0.0))
	for sx in [-1.0, 1.0]:
		box(crate, "CrateBrace", Vector3(sx * 0.44, 0.42, 0), Vector3(0.08, 0.86, 0.99), stone_material(wood.darkened(0.18), 0.9, 0.0))

static func build_floor_medallion(parent: Node3D, center: Vector3, glow: Color, radius: float) -> void:
	var disc := MeshInstance3D.new()
	disc.name = "FloorMedallion"
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = 0.06
	disc.mesh = mesh
	disc.material_override = glow_material(glow.darkened(0.15), 1.1)
	disc.position = center + Vector3(0, 0.34, 0)
	parent.add_child(disc)
	var ring := MeshInstance3D.new()
	ring.name = "FloorMedallionRing"
	var torus := TorusMesh.new()
	torus.inner_radius = radius * 0.82
	torus.outer_radius = radius
	torus.rings = 32
	torus.ring_segments = 8
	ring.mesh = torus
	ring.material_override = glow_material(glow, 1.8)
	ring.position = center + Vector3(0, 0.37, 0)
	parent.add_child(ring)
