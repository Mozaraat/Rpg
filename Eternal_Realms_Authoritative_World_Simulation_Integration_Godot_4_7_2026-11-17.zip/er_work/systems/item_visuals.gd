# ItemVisuals - procedural 3D models for every inventory item.
#
# Loot in the world is not a generic orb: every item id resolves to a family
# (sword, ore chunk, potion, fish, relic...) and gets a small hand-built mesh
# with tier-coloured metal, glow accents and readable silhouette. Meshes are
# cached per id and scaled to a common ground-display size so a fang and a
# warhammer both read clearly while spinning over the ground.
class_name ItemVisuals
extends RefCounted

const WOOD := Color(0.36, 0.23, 0.13)
const WOOD_DARK := Color(0.23, 0.145, 0.085)
const LEATHER := Color(0.30, 0.20, 0.12)
const ROPE := Color(0.55, 0.46, 0.30)
const IVORY := Color(0.90, 0.86, 0.73)
const BURLAP := Color(0.60, 0.51, 0.34)
const CREAM := Color(0.92, 0.87, 0.73)
const CLOTH := Color(0.52, 0.46, 0.38)

static var _mats: Dictionary = {}
static var _mesh_cache: Dictionary = {}
static var _rng := RandomNumberGenerator.new()
static var _active: Array[SurfaceTool] = []

static func make(item_id: String) -> Node3D:
	var root := Node3D.new()
	root.name = "ItemModel"
	var mesh: ArrayMesh
	if _mesh_cache.has(item_id):
		mesh = _mesh_cache[item_id]
	else:
		var spec := profile(item_id)
		_rng.seed = abs(hash(item_id))
		mesh = ArrayMesh.new()
		_build(mesh, spec)
		_mesh_cache[item_id] = mesh
	var mi := MeshInstance3D.new()
	mi.name = "Mesh"
	mi.mesh = mesh
	# Normalise to a readable hover size (roughly life-sized per family) and rest
	# the model on y = 0.
	var aabb: AABB = mesh.get_aabb()
	var max_dim: float = maxf(aabb.size.x, maxf(aabb.size.y, aabb.size.z))
	var fit: float = profile(item_id)["fit"]
	var f: float = clampf(fit / maxf(max_dim, 0.01), 0.30, 2.6)
	mi.scale = Vector3.ONE * f
	mi.position.y = -aabb.position.y * f
	root.add_child(mi)
	return root

static func glow_color(item_id: String) -> Color:
	return profile(item_id)["glow"]

# ---------------------------------------------------------------------------
# Item classification
# ---------------------------------------------------------------------------
static func profile(item_id: String) -> Dictionary:
	var d: Dictionary = ItemDB.def(item_id)
	var name := str(d.get("name", item_id))
	var kind := _kind(item_id, d)
	var tint := _tint(item_id, name)
	var value := float(d.get("value", 10))
	var glow := _glow(item_id, tint, str(d.get("type", "material")))
	var energy: float = clampf(0.4 + value / 380.0, 0.4, 2.4)
	return {"id": item_id, "kind": kind, "tint": tint, "glow": glow, "energy": energy, "fit": _fit(kind), "data": d}

static func _fit(kind: String) -> float:
	match kind:
		"sword", "dagger", "axe", "spear", "trident", "blunt", "bow", "staff", "wand", "rod":
			return 0.80
		"plate", "hide_armor", "cloth", "cloak":
			return 0.56
		"book", "medallion", "crown", "core", "wisp", "dust", "sac", "sapling", "potion", "jar":
			return 0.42
		"bread", "cheese", "bowl", "berries", "carrot", "egg", "jug", "fish", "cooked_fish", "wheat":
			return 0.40
	return 0.36

static func _kind(id: String, d: Dictionary) -> String:
	var t := str(d.get("type", "material"))
	if t == "weapon":
		if id == "tidecaller_trident":
			return "trident"
		return str(d.get("weapon_class", "sword"))
	if t == "armor":
		if id.contains("cloak"):
			return "cloak"
		if id.contains("hide") or id.contains("leather"):
			return "hide_armor"
		if id.contains("plate"):
			return "plate"
		return "cloth"
	if id == "healing_potion":
		return "potion"
	if id == "fishing_rod":
		return "rod"
	if id.contains("heartwood") or id.contains("willow_bark"):
		return "log"
	if id.contains("signet") or id.contains("badge") or id.contains("insignia") or id.contains("sigil"):
		return "medallion"
	if id.contains("crown"):
		return "crown"
	if id.contains("scripture") or id.contains("codex") or id.contains("charter") or id.contains("notes"):
		return "book"
	if id.contains("sapling") or id == "choir_seed":
		return "sapling"
	if id.contains("dust"):
		return "dust"
	if id.contains("essence") or id.contains("ectoplasm"):
		return "wisp"
	if id.contains("spore"):
		return "sac"
	if id.contains("relic") or id.contains("heart") or id.contains("core") or id.contains("rune_fragment") or id.contains("prism_heart"):
		return "core"
	if id.contains("scale") or id.contains("chitin"):
		return "chitin" if id.contains("chitin") else "scale"
	if id.contains("coral"):
		return "coral"
	if id.contains("pearl"):
		return "pearl"
	if id == "egg":
		return "egg"
	if id == "milk":
		return "jug"
	if id.contains("wool") or id.contains("fur"):
		return "fur"
	if id.contains("pelt") or id.contains("hide"):
		return "pelt"
	if id.contains("fang") or id.contains("tusk"):
		return "fang"
	if id.contains("bone"):
		return "bone"
	if id.contains("coin"):
		return "coins"
	if id.contains("ore"):
		return "ore"
	if id.contains("ingot"):
		return "ingot"
	if id.contains("plank"):
		return "plank"
	if id.contains("wood") or id.contains("bark"):
		return "log"
	if id.contains("seed"):
		return "pouch"
	if id.contains("flour"):
		return "sack"
	if id.contains("hay") or id.contains("fiber") or id.contains("silk"):
		return "bundle"
	if id.contains("leather_strip"):
		return "strap"
	if id.begins_with("fish_"):
		return "fish"
	if id.begins_with("cooked_"):
		return "cooked_fish"
	if id.contains("stew"):
		return "bowl"
	if id.contains("bread"):
		return "bread"
	if id.contains("cheese"):
		return "cheese"
	if id.contains("berry") or id.contains("berries"):
		if id.contains("preserve"):
			return "jar"
		return "berries"
	if id.contains("carrot"):
		return "carrot"
	if id == "wheat":
		return "wheat"
	if id.contains("mushroom") or id.contains("glowcap"):
		return "mushroom"
	if id.contains("orchid") or id.contains("moonpetal"):
		return "flower"
	if id.contains("sulfur") or id.contains("salt") or id.contains("obsidian") or id.contains("amber") or id.contains("crystal") or id.contains("shard") or id.contains("prism") or id.contains("moonstone"):
		return "crystal"
	if id.contains("peat") or id.contains("seaweed") or id.contains("moss"):
		return "moss"
	if id.contains("gel") or id.contains("slime") or id.contains("resin") or id.contains("preserve"):
		return "gel"
	return "chunk"

static func _tint(id: String, name: String) -> Color:
	var s := (id + " " + name).to_lower()
	if s.contains("gold") or s.contains("gilded") or s.contains("amber") or s.contains("celestial"):
		return Color(0.95, 0.74, 0.28)
	if s.contains("silver") or s.contains("moon") or s.contains("pearl") or s.contains("astral"):
		return Color(0.78, 0.84, 0.92)
	if s.contains("copper"):
		return Color(0.82, 0.47, 0.25)
	if s.contains("rust"):
		return Color(0.55, 0.42, 0.34)
	if s.contains("void") or s.contains("abyss") or s.contains("starless") or s.contains("eclipse") or s.contains("shadow"):
		return Color(0.40, 0.29, 0.60)
	if s.contains("ember") or s.contains("cinder") or s.contains("fire") or s.contains("sulfur"):
		return Color(0.92, 0.48, 0.22)
	if s.contains("glacier") or s.contains("frost") or s.contains("ice"):
		return Color(0.62, 0.82, 0.92)
	if s.contains("tide") or s.contains("drowned") or s.contains("coral") or s.contains("sea") or s.contains("thala"):
		return Color(0.32, 0.72, 0.72)
	if s.contains("verdant") or s.contains("choir") or s.contains("worldroot") or s.contains("jungle") or s.contains("moss"):
		return Color(0.42, 0.68, 0.30)
	if s.contains("dragon") or s.contains("ancient") or s.contains("royal") or s.contains("king"):
		return Color(0.62, 0.36, 0.26)
	if s.contains("crimson") or s.contains("blood") or s.contains("red"):
		return Color(0.76, 0.25, 0.22)
	if s.contains("glow") or s.contains("prism") or s.contains("mana") or s.contains("crystal"):
		return Color(0.42, 0.80, 0.95)
	if s.contains("cherry"):
		return Color(0.80, 0.46, 0.52)
	if s.contains("slime"):
		return Color(0.36, 0.80, 0.46)
	if s.contains("wheat") or s.contains("hay") or s.contains("flour") or s.contains("bread") or s.contains("cheese"):
		return Color(0.82, 0.66, 0.34)
	if s.contains("iron") or s.contains("steel") or s.contains("stone") or s.contains("worn"):
		return Color(0.58, 0.60, 0.64)
	return Color(0.70, 0.68, 0.64)

static func _glow(id: String, tint: Color, item_type: String) -> Color:
	if id.contains("glow") or id.contains("mana") or id.contains("crystal") or id.contains("prism") or id.contains("moon") or id.contains("ember") or id.contains("cinder") or id.contains("essence") or id.contains("relic") or id.contains("core") or id.contains("rune") or id.contains("spore") or id.contains("astral"):
		return tint
	if item_type == "consumable":
		return Color(0.45, 1.0, 0.55) if id.contains("heal") else Color(0.55, 0.85, 1.0)
	return tint.lerp(Color.WHITE, 0.18)

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------
static func _build(mesh: ArrayMesh, spec: Dictionary) -> void:
	var kind: String = spec["kind"]
	var d: Dictionary = spec["data"]
	var s: float = 1.0
	if kind == "sword" or kind == "dagger" or kind == "axe" or kind == "spear" or kind == "trident" or kind == "blunt" or kind == "bow" or kind == "staff":
		s = clampf(float(d.get("damage", 16.0)) / 26.0, 0.86, 1.32)
	_active.clear()
	match kind:
		"sword": _sword(mesh, spec, s)
		"dagger": _dagger(mesh, spec, s)
		"axe": _axe(mesh, spec, s)
		"spear": _spear(mesh, spec, s, false)
		"trident": _spear(mesh, spec, s, true)
		"blunt": _blunt(mesh, spec, s)
		"bow": _bow(mesh, spec, s)
		"staff": _staff(mesh, spec, s)
		"wand": _wand(mesh, spec)
		"plate": _plate(mesh, spec)
		"hide_armor": _hide_armor(mesh, spec)
		"cloth": _cloth_armor(mesh, spec)
		"cloak": _cloak(mesh, spec)
		"potion": _potion(mesh, spec)
		"jar": _jar(mesh, spec)
		"bread": _bread(mesh, spec)
		"cheese": _cheese(mesh, spec)
		"bowl": _bowl(mesh, spec)
		"berries": _berries(mesh, spec)
		"carrot": _carrot(mesh, spec)
		"wheat": _wheat(mesh, spec)
		"egg": _egg(mesh, spec)
		"jug": _jug(mesh, spec)
		"fish": _fish(mesh, spec, false)
		"cooked_fish": _fish(mesh, spec, true)
		"ore": _ore(mesh, spec)
		"ingot": _ingot(mesh, spec)
		"log": _log(mesh, spec)
		"plank": _plank(mesh, spec)
		"crystal": _crystal(mesh, spec)
		"flower": _flower(mesh, spec)
		"mushroom": _mushroom(mesh, spec)
		"moss": _moss(mesh, spec)
		"gel": _gel(mesh, spec)
		"pouch": _pouch(mesh, spec)
		"sack": _sack(mesh, spec)
		"bundle": _bundle(mesh, spec)
		"pelt": _pelt(mesh, spec)
		"fur": _fur(mesh, spec)
		"fang": _fang(mesh, spec)
		"bone": _bone(mesh, spec)
		"coins": _coins(mesh, spec)
		"pearl": _pearl(mesh, spec)
		"scale": _scale(mesh, spec)
		"chitin": _chitin(mesh, spec)
		"coral": _coral(mesh, spec)
		"strap": _strap(mesh, spec)
		"rod": _rod(mesh, spec)
		"book": _book(mesh, spec)
		"medallion": _medallion(mesh, spec)
		"crown": _crown(mesh, spec)
		"core": _core(mesh, spec)
		"wisp": _wisp(mesh, spec)
		"dust": _dust(mesh, spec)
		"sac": _sac(mesh, spec)
		"sapling": _sapling(mesh, spec)
		_: _chunk(mesh, spec)
	for st in _active:
		st.commit(mesh)
	_active.clear()

static func _mat(c: Color, rough: float = 0.7, metal: float = 0.0, emit: Color = Color.BLACK,
		energy: float = 0.0, alpha: float = 1.0, unshaded: bool = false) -> StandardMaterial3D:
	var key := "%s|%.3f|%.2f|%s|%.2f|%.2f|%s" % [c.to_html(true), rough, metal, emit.to_html(true), energy, alpha, unshaded]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	m.vertex_color_use_as_albedo = true
	if emit != Color.BLACK or energy > 0.0:
		m.emission_enabled = true
		m.emission = emit if emit != Color.BLACK else c
		m.emission_energy_multiplier = energy
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color.a = alpha
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mats[key] = m
	return m

static func _metal(c: Color) -> StandardMaterial3D:
	return _mat(c, 0.30, 0.86)

static func _edge(c: Color) -> StandardMaterial3D:
	return _mat(c.lerp(Color.WHITE, 0.42), 0.16, 0.94)

static func _wood(c: Color = WOOD) -> StandardMaterial3D:
	return _mat(c, 0.84, 0.0)

static func _glow_mat(c: Color, energy: float) -> StandardMaterial3D:
	return _mat(c, 0.22, 0.1, c, energy)

static func _st(mesh: ArrayMesh, m: Material) -> SurfaceTool:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_material(m)
	_active.append(st)
	return st

static func _cyl(st: SurfaceTool, pos: Vector3, r0: float, r1: float, h: float, c: Color,
		segs: int = 8, cap_top: bool = true) -> void:
	MeshKit.cylinder(st, Transform3D(Basis.IDENTITY, pos), r0, r1, h, segs, c, c, true, cap_top)

static func _box(st: SurfaceTool, pos: Vector3, size: Vector3, c: Color, rot: Vector3 = Vector3.ZERO) -> void:
	MeshKit.box(st, Transform3D(Basis.from_euler(rot), pos), size, c, c)

static func _ball(st: SurfaceTool, pos: Vector3, r: float, c: Color, flat: float = 1.0, segs: int = 8, rings: int = 5) -> void:
	MeshKit.blob_smooth(st, pos, Vector3(r, r * flat, r), _rng, c, c, 0.03, segs, rings, 1.0)

## Tapered blade with a pointed tip. Built along +Y from base_y.
static func _blade(st: SurfaceTool, base_y: float, w: float, length: float, thick: float, c: Color) -> void:
	var tip_len: float = minf(length * 0.30, w * 2.6)
	var y1: float = base_y + length - tip_len
	var y2: float = base_y + length
	var a := Vector3(-w * 0.5, base_y, -thick * 0.5)
	var b := Vector3(w * 0.5, base_y, -thick * 0.5)
	var c1 := Vector3(w * 0.5, base_y, thick * 0.5)
	var d := Vector3(-w * 0.5, base_y, thick * 0.5)
	var e := Vector3(-w * 0.5, y1, -thick * 0.5)
	var f := Vector3(w * 0.5, y1, -thick * 0.5)
	var g := Vector3(w * 0.5, y1, thick * 0.5)
	var h := Vector3(-w * 0.5, y1, thick * 0.5)
	var tip := Vector3(0.0, y2, 0.0)
	MeshKit.flat_quad(st, a, b, f, e, Vector3(0, 0, -1), c, c, c, c)
	MeshKit.flat_quad(st, d, h, g, c1, Vector3(0, 0, 1), c, c, c, c)
	MeshKit.flat_quad(st, b, c1, g, f, Vector3(1, 0, 0), c, c, c, c)
	MeshKit.flat_quad(st, a, e, h, d, Vector3(-1, 0, 0), c, c, c, c)
	MeshKit.flat_quad(st, a, d, c1, b, Vector3(0, -1, 0), c, c, c, c)
	MeshKit.flat_tri(st, e, f, tip, Vector3(0, 0, -1), c, c, c)
	MeshKit.flat_tri(st, h, tip, g, Vector3(0, 0, 1), c, c, c)
	MeshKit.flat_tri(st, f, g, tip, Vector3(1, 0, 0), c, c, c)
	MeshKit.flat_tri(st, e, tip, h, Vector3(-1, 0, 0), c, c, c)

static func _shard(st: SurfaceTool, base: Vector3, height: float, radius: float, axis: Vector3, tilt: float, c: Color) -> void:
	MeshKit.cylinder(st, Transform3D(Basis(axis, tilt), base), radius, 0.0, height, 5, c, c, true, true)

# ---------------------------------------------------------------------------
# Weapons
# ---------------------------------------------------------------------------
static func _sword(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var metal := _st(mesh, _metal(tint))
	var edge := _st(mesh, _edge(tint))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	var g: float = 0.17 * s
	_cyl(grip, Vector3.ZERO, 0.030, 0.034, g, LEATHER.darkened(0.2), 8)
	_cyl(grip, Vector3(0, g * 0.18, 0), 0.036, 0.036, 0.03, ROPE, 8)
	_cyl(grip, Vector3(0, g * 0.62, 0), 0.036, 0.036, 0.03, ROPE, 8)
	_ball(metal, Vector3(0, 0.01, 0), 0.048 * s, tint, 0.7)
	_box(metal, Vector3(0, g + 0.022 * s, 0), Vector3(0.26 * s, 0.045 * s, 0.075 * s), tint)
	_ball(glow, Vector3(0, g + 0.024 * s, 0.042 * s), 0.026 * s, spec["glow"])
	var base: float = g + 0.045 * s
	_blade(edge, base, 0.105 * s, 0.66 * s, 0.017 * s, tint.lerp(Color.WHITE, 0.30))
	_box(metal, Vector3(0, base + 0.26 * s, 0.010 * s), Vector3(0.013 * s, 0.34 * s, 0.0025), tint.darkened(0.4))
	_box(metal, Vector3(0, base + 0.26 * s, -0.010 * s), Vector3(0.013 * s, 0.34 * s, 0.0025), tint.darkened(0.4))

static func _dagger(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var metal := _st(mesh, _metal(tint))
	var edge := _st(mesh, _edge(tint))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	var g: float = 0.12 * s
	_cyl(grip, Vector3.ZERO, 0.026, 0.030, g, LEATHER.darkened(0.2), 8)
	_cyl(grip, Vector3(0, g * 0.3, 0), 0.032, 0.032, 0.024, ROPE, 8)
	_ball(metal, Vector3(0, 0.008, 0), 0.038 * s, tint, 0.7)
	_box(metal, Vector3(0, g + 0.016 * s, 0), Vector3(0.17 * s, 0.035 * s, 0.055 * s), tint)
	_ball(glow, Vector3(0, g + 0.018 * s, 0.030 * s), 0.020 * s, spec["glow"])
	_blade(edge, g + 0.034 * s, 0.075 * s, 0.36 * s, 0.014 * s, tint.lerp(Color.WHITE, 0.28))

static func _axe(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood())
	var metal := _st(mesh, _metal(tint))
	var edge := _st(mesh, _edge(tint))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var h: float = 0.98 * s
	_cyl(wood, Vector3.ZERO, 0.032, 0.027, h, WOOD, 8)
	for k in 3:
		_cyl(grip, Vector3(0, 0.14 * s + float(k) * 0.055 * s, 0), 0.035, 0.035, 0.032, LEATHER.darkened(0.15), 8)
	_cyl(metal, Vector3(0, h - 0.12, 0), 0.045, 0.043, 0.16, tint, 8)
	MeshKit.blob(metal, Vector3(0.10 * s, h - 0.03, 0), Vector3(0.14 * s, 0.17 * s, 0.035 * s), _rng, tint.darkened(0.28), tint, 0.06, 7, 4)
	_box(edge, Vector3(0.225 * s, h - 0.03, 0), Vector3(0.028 * s, 0.30 * s, 0.045 * s), tint.lerp(Color.WHITE, 0.4))
	MeshKit.cylinder(metal, Transform3D(Basis(Vector3.BACK, PI * 0.5), Vector3(-0.055 * s, h - 0.03, 0)), 0.030, 0.0, 0.12 * s, 5, tint, tint, true, true)
	_cyl(metal, Vector3(0, 0.02, 0), 0.034, 0.030, 0.05, tint, 8)

static func _spear(mesh: ArrayMesh, spec: Dictionary, s: float, trident: bool) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood())
	var metal := _st(mesh, _metal(tint))
	var edge := _st(mesh, _edge(tint))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var h: float = 1.74 * s
	_cyl(wood, Vector3.ZERO, 0.023, 0.019, h, WOOD, 8)
	for k in 3:
		_cyl(grip, Vector3(0, h * 0.42 + float(k) * 0.05, 0), 0.027, 0.027, 0.035, LEATHER.darkened(0.15), 8)
	_cyl(metal, Vector3(0, h - 0.02, 0), 0.032, 0.028, 0.12, tint, 8)
	_cyl(metal, Vector3(0, 0.0, 0), 0.028, 0.032, 0.09, tint, 8)
	if trident:
		_blade(edge, h + 0.09, 0.075 * s, 0.34 * s, 0.012 * s, tint.lerp(Color.WHITE, 0.35))
		for sx in [-1.0, 1.0]:
			var a := Vector3(0, h - 0.14, 0)
			var b := Vector3(sx * 0.14 * s, h + 0.02, 0)
			var c := Vector3(sx * 0.14 * s, h + 0.26, 0)
			MeshKit.cylinder_between(metal, a, b, 0.020, 0.016, 6, tint, tint)
			MeshKit.cylinder_between(metal, b, c, 0.016, 0.010, 6, tint, tint)
			_shard(metal, c, 0.18 * s, 0.028, Vector3.BACK, 0.0, tint.lerp(Color.WHITE, 0.3))
	else:
		_blade(edge, h + 0.08, 0.095 * s, 0.33 * s, 0.013 * s, tint.lerp(Color.WHITE, 0.35))

static func _blunt(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood())
	var metal := _st(mesh, _metal(tint))
	var edge := _st(mesh, _edge(tint))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var h: float = 0.86 * s
	_cyl(wood, Vector3.ZERO, 0.031, 0.026, h, WOOD, 8)
	for k in 2:
		_cyl(grip, Vector3(0, 0.15 * s + float(k) * 0.05, 0), 0.035, 0.035, 0.04, LEATHER.darkened(0.15), 8)
	_box(metal, Vector3(0, h + 0.12 * s, 0), Vector3(0.34 * s, 0.26 * s, 0.22 * s), tint)
	_box(edge, Vector3(0, h + 0.25 * s, 0), Vector3(0.36 * s, 0.025 * s, 0.24 * s), tint.lerp(Color.WHITE, 0.35))
	_box(metal, Vector3(0, h + 0.12 * s, 0.115 * s), Vector3(0.035 * s, 0.24 * s, 0.025), tint.darkened(0.35))
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_ball(edge, Vector3(sx * 0.135 * s, h + 0.12 * s, sz * 0.085 * s), 0.020 * s, tint.lightened(0.15), 1.0, 5, 3)

static func _bow(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood(tint.lerp(WOOD, 0.55)))
	var string := _st(mesh, _mat(ROPE, 0.9))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 0.6))
	var h: float = 1.16 * s
	var belly: float = 0.30 * s
	var prev := Vector3.ZERO
	var prev_r: float = 0.0
	for i in range(11):
		var t: float = float(i) / 10.0
		var p := Vector3(belly * sin(PI * t), 0.04 + h * t, 0.0)
		var r: float = lerpf(0.007, 0.021, sin(PI * t))
		if i > 0:
			MeshKit.cylinder_between(wood, prev, p, prev_r, r, 6, tint.lerp(WOOD, 0.4), tint.lerp(WOOD, 0.7))
		prev = p
		prev_r = r
	_cyl(grip, Vector3(belly * 0.985, 0.5 * h - 0.09, 0), 0.032, 0.032, 0.18, LEATHER.darkened(0.15), 8)
	MeshKit.cylinder_between(string, Vector3(0, 0.04, 0), Vector3(0, 0.04 + h, 0), 0.0035, 0.0035, 4, ROPE, ROPE)
	for ty in [0.04, 0.04 + h]:
		_ball(string, Vector3(0, ty, 0), 0.014, ROPE, 1.0, 5, 3)
	if spec["kind"] == "bow" and spec["id"] == "prism_longbow":
		_ball(glow, Vector3(belly * 0.985, 0.5 * h, 0.04), 0.035, spec["glow"])

static func _staff(mesh: ArrayMesh, spec: Dictionary, s: float) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood(WOOD_DARK.lerp(tint, 0.18)))
	var metal := _st(mesh, _metal(tint.lerp(Color(0.72, 0.62, 0.38), 0.55)))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.8))
	var h: float = 1.42 * s
	_cyl(wood, Vector3.ZERO, 0.029, 0.023, h, WOOD, 8)
	_cyl(grip, Vector3(0, h * 0.38, 0), 0.033, 0.033, h * 0.18, LEATHER.darkened(0.15), 8)
	_cyl(metal, Vector3(0, h - 0.06, 0), 0.038, 0.031, 0.10, tint, 8)
	for k in 3:
		var a: float = TAU * float(k) / 3.0
		var start := Vector3(0, h - 0.01, 0)
		var mid := Vector3(cos(a) * 0.075 * s, h + 0.10 * s, sin(a) * 0.075 * s)
		var end := Vector3(cos(a) * 0.055 * s, h + 0.19 * s, sin(a) * 0.055 * s)
		MeshKit.cylinder_between(metal, start, mid, 0.016, 0.012, 6, tint, tint)
		MeshKit.cylinder_between(metal, mid, end, 0.012, 0.008, 6, tint, tint)
	_ball(glow, Vector3(0, h + 0.13 * s, 0), 0.085 * s, spec["glow"], 1.0, 10, 7)
	var prev := Vector3(0.13 * s, h + 0.13 * s, 0)
	for i in range(1, 13):
		var a2: float = TAU * float(i) / 12.0
		var p := Vector3(cos(a2) * 0.13 * s, h + 0.13 * s, sin(a2) * 0.13 * s)
		MeshKit.cylinder_between(metal, prev, p, 0.007, 0.007, 5, tint, tint)
		prev = p
	MeshKit.cylinder_between(metal, prev, Vector3(0.13 * s, h + 0.13 * s, 0), 0.007, 0.007, 5, tint, tint)

static func _wand(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var wood := _st(mesh, _wood(WOOD_DARK))
	var metal := _st(mesh, _metal(tint.lerp(Color(0.75, 0.66, 0.40), 0.4)))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.9))
	_cyl(wood, Vector3.ZERO, 0.020, 0.016, 0.36, WOOD, 8)
	_cyl(grip, Vector3(0, 0.06, 0), 0.024, 0.024, 0.13, LEATHER.darkened(0.15), 8)
	_cyl(metal, Vector3(0, 0.36, 0), 0.024, 0.020, 0.05, tint, 8)
	for k in 3:
		var a: float = TAU * float(k) / 3.0
		var p := Vector3(cos(a) * 0.035, 0.52, sin(a) * 0.035)
		MeshKit.cylinder_between(metal, Vector3(0, 0.39, 0), p, 0.009, 0.006, 5, tint, tint)
	_shard(glow, Vector3(0, 0.40, 0), 0.24, 0.040, Vector3.RIGHT, 0.18, spec["glow"])
	_shard(glow, Vector3(0.04, 0.40, 0.02), 0.14, 0.022, Vector3.BACK, -0.3, spec["glow"])

# ---------------------------------------------------------------------------
# Armour
# ---------------------------------------------------------------------------
static func _plate(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var steel := _st(mesh, _metal(tint))
	var trim := _st(mesh, _mat(tint.lerp(Color(0.86, 0.72, 0.38), 0.45), 0.32, 0.88))
	var cloth := _st(mesh, _mat(LEATHER.darkened(0.15), 0.9))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	MeshKit.blob_smooth(steel, Vector3(0, 0.32, 0), Vector3(0.20, 0.24, 0.13), _rng, tint.darkened(0.35), tint.lerp(Color.WHITE, 0.18), 0.05, 10, 7)
	for sx in [-1.0, 1.0]:
		MeshKit.blob_smooth(steel, Vector3(sx * 0.205, 0.45, 0), Vector3(0.115, 0.095, 0.115), _rng, tint.darkened(0.3), tint.lerp(Color.WHITE, 0.12), 0.05, 8, 5)
		_box(trim, Vector3(sx * 0.205, 0.53, 0), Vector3(0.02, 0.035, 0.16), tint.lerp(Color.WHITE, 0.25))
	_cyl(trim, Vector3(0, 0.52, 0), 0.095, 0.085, 0.045, tint.lerp(Color.WHITE, 0.2), 10)
	_box(cloth, Vector3(0, 0.115, 0), Vector3(0.36, 0.09, 0.24), LEATHER.darkened(0.2))
	_box(trim, Vector3(0, 0.115, 0.125), Vector3(0.07, 0.07, 0.02), Color(0.85, 0.72, 0.40))
	_box(trim, Vector3(0, 0.34, 0.115), Vector3(0.035, 0.30, 0.03), tint.lerp(Color.WHITE, 0.22))
	_ball(glow, Vector3(0, 0.40, 0.135), 0.026, spec["glow"], 1.0, 7, 4)
	for sx in [-1.0, 1.0]:
		_box(trim, Vector3(sx * 0.10, 0.16, 0.12), Vector3(0.03, 0.05, 0.015), tint.lerp(Color.WHITE, 0.32))

static func _hide_armor(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var hide := _st(mesh, _mat(tint.lerp(LEATHER, 0.45), 0.86))
	var fur := _st(mesh, _mat(tint.lerp(IVORY, 0.35), 0.95))
	var trim := _st(mesh, _mat(LEATHER.darkened(0.3), 0.7))
	MeshKit.blob_smooth(hide, Vector3(0, 0.30, 0), Vector3(0.21, 0.25, 0.14), _rng, tint.darkened(0.35), tint.lerp(LEATHER, 0.2), 0.09, 9, 6)
	for sx in [-1.0, 1.0]:
		MeshKit.blob_smooth(hide, Vector3(sx * 0.21, 0.43, 0), Vector3(0.10, 0.09, 0.11), _rng, tint.darkened(0.35), tint, 0.08, 7, 5)
	_box(trim, Vector3(0, 0.14, 0), Vector3(0.40, 0.06, 0.25), LEATHER.darkened(0.35))
	for i in range(6):
		var a: float = PI * (0.15 + 0.14 * float(i))
		MeshKit.blob(fur, Vector3(cos(a) * 0.20, 0.50 + sin(a) * 0.02, sin(a) * 0.10), Vector3(0.07, 0.06, 0.07), _rng, tint.darkened(0.2), tint.lerp(IVORY, 0.4), 0.25, 6, 4)
	for sx in [-1.0, 1.0]:
		_box(trim, Vector3(sx * 0.10, 0.32, 0.135), Vector3(0.025, 0.20, 0.015), LEATHER.darkened(0.2), Vector3(0, 0, sx * 0.2))

static func _cloth_armor(mesh: ArrayMesh, spec: Dictionary) -> void:
	var base: Color = spec["tint"].lerp(Color(0.34, 0.42, 0.56), 0.55)
	var cloth := _st(mesh, _mat(base, 0.92))
	var trim := _st(mesh, _mat(base.lerp(CREAM, 0.35), 0.9))
	var belt := _st(mesh, _mat(LEATHER, 0.8))
	MeshKit.blob_smooth(cloth, Vector3(0, 0.31, 0), Vector3(0.185, 0.23, 0.105), _rng, base.darkened(0.22), base.lightened(0.12), 0.07, 9, 6)
	for sx in [-1.0, 1.0]:
		var xf := Transform3D(Basis(Vector3.BACK, PI * 0.5), Vector3(sx * 0.17, 0.45, 0))
		MeshKit.cylinder(cloth, xf, 0.055, 0.042, 0.15, 8, base.darkened(0.15), base, true, true)
	_cyl(trim, Vector3(0, 0.50, 0), 0.088, 0.078, 0.04, base.lerp(CREAM, 0.30), 10)
	_box(belt, Vector3(0, 0.16, 0), Vector3(0.35, 0.055, 0.21), LEATHER)
	_box(trim, Vector3(0, 0.10, 0), Vector3(0.36, 0.025, 0.22), base.lerp(CREAM, 0.3))
	_box(trim, Vector3(0, 0.34, 0.10), Vector3(0.022, 0.24, 0.010), base.lerp(CREAM, 0.30))
	_box(trim, Vector3(0.065, 0.16, 0.09), Vector3(0.07, 0.06, 0.010), base.lerp(CREAM, 0.25), Vector3(0, 0, 0.2))

static func _cloak(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var cloth := _st(mesh, _mat(tint.lerp(CLOTH, 0.4), 0.94))
	var trim := _st(mesh, _mat(tint.darkened(0.35), 0.8))
	var metal := _st(mesh, _metal(tint.lerp(Color(0.82, 0.70, 0.42), 0.5)))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 0.8))
	MeshKit.blob_smooth(cloth, Vector3(0, 0.34, 0), Vector3(0.25, 0.34, 0.10), _rng, tint.darkened(0.25), tint.lerp(CREAM, 0.12), 0.07, 9, 6)
	MeshKit.blob_smooth(trim, Vector3(0, 0.62, -0.02), Vector3(0.13, 0.11, 0.135), _rng, tint.darkened(0.4), tint, 0.06, 8, 5)
	_box(trim, Vector3(0, 0.10, 0), Vector3(0.42, 0.05, 0.18), tint.darkened(0.3))
	for sx in [-1.0, 1.0]:
		_box(trim, Vector3(sx * 0.13, 0.55, 0.06), Vector3(0.04, 0.16, 0.02), tint.lerp(CREAM, 0.18), Vector3(0, 0, sx * 0.32))
	_ball(glow, Vector3(0, 0.55, 0.10), 0.032, spec["glow"])
	if spec["id"] == "packlord_cloak":
		for i in range(5):
			var a: float = PI * (0.12 + 0.19 * float(i))
			MeshKit.blob(cloth, Vector3(cos(a) * 0.17, 0.64, sin(a) * 0.10), Vector3(0.07, 0.06, 0.07), _rng, tint, tint.lerp(IVORY, 0.5), 0.2, 5, 4)

# ---------------------------------------------------------------------------
# Consumables
# ---------------------------------------------------------------------------
static func _potion(mesh: ArrayMesh, spec: Dictionary) -> void:
	var glass := _st(mesh, _mat(Color(0.78, 0.88, 0.92), 0.06, 0.1, Color.BLACK, 0.0, 0.38))
	var liquid := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.3))
	var cork := _st(mesh, _wood())
	var label := _st(mesh, _mat(CREAM, 0.85))
	_cyl(glass, Vector3(0, 0.02, 0), 0.086, 0.086, 0.16, Color.WHITE, 10)
	_cyl(glass, Vector3(0, 0.18, 0), 0.075, 0.030, 0.065, Color.WHITE, 10)
	_cyl(glass, Vector3(0, 0.245, 0), 0.028, 0.028, 0.075, Color.WHITE, 8)
	_cyl(liquid, Vector3(0, 0.028, 0), 0.072, 0.072, 0.115, spec["glow"], 10)
	_cyl(cork, Vector3(0, 0.312, 0), 0.034, 0.030, 0.04, WOOD, 8)
	_box(label, Vector3(0, 0.105, 0.083), Vector3(0.10, 0.065, 0.006), CREAM)
	_box(cork, Vector3(0, 0.19, 0.0), Vector3(0.006, 0.05, 0.02), ROPE, Vector3(0, 0, 0.4))

static func _jar(mesh: ArrayMesh, spec: Dictionary) -> void:
	var glass := _st(mesh, _mat(Color(0.82, 0.90, 0.92), 0.06, 0.05, Color.BLACK, 0.0, 0.4))
	var jam := _st(mesh, _glow_mat(spec["glow"].lerp(Color(0.6, 0.2, 0.35), 0.55), 0.5))
	var metal := _st(mesh, _metal(Color(0.72, 0.68, 0.60)))
	var label := _st(mesh, _mat(CREAM, 0.88))
	_cyl(glass, Vector3(0, 0.02, 0), 0.090, 0.090, 0.19, Color.WHITE, 10)
	_cyl(jam, Vector3(0, 0.035, 0), 0.079, 0.079, 0.145, Color(0.55, 0.18, 0.32), 10)
	_cyl(glass, Vector3(0, 0.21, 0), 0.075, 0.055, 0.03, Color.WHITE, 10)
	_cyl(metal, Vector3(0, 0.24, 0), 0.060, 0.060, 0.035, Color(0.72, 0.68, 0.60), 10)
	_box(label, Vector3(0, 0.13, 0.088), Vector3(0.085, 0.08, 0.006), CREAM)

static func _bread(mesh: ArrayMesh, spec: Dictionary) -> void:
	var crust := _st(mesh, _mat(Color(0.66, 0.44, 0.20), 0.9))
	var score := _st(mesh, _mat(Color(0.45, 0.28, 0.13), 0.95))
	MeshKit.blob_smooth(crust, Vector3(-0.02, 0.09, 0), Vector3(0.19, 0.10, 0.12), _rng, Color(0.55, 0.34, 0.15), Color(0.78, 0.56, 0.28), 0.08, 10, 6)
	MeshKit.blob_smooth(crust, Vector3(0.14, 0.07, 0.05), Vector3(0.12, 0.075, 0.09), _rng, Color(0.52, 0.32, 0.14), Color(0.74, 0.52, 0.26), 0.08, 8, 5)
	for k in 3:
		_box(score, Vector3(-0.10 + float(k) * 0.075, 0.185, 0), Vector3(0.012, 0.012, 0.15), Color(0.42, 0.26, 0.12), Vector3(0, 0.5, 0))

static func _cheese(mesh: ArrayMesh, spec: Dictionary) -> void:
	var curd := _st(mesh, _mat(spec["tint"].lerp(Color(0.95, 0.82, 0.44), 0.7), 0.9))
	var rind := _st(mesh, _mat(spec["tint"].lerp(Color(0.85, 0.68, 0.30), 0.6), 0.92))
	# A wedge lying on its side: triangular cut face toward the viewer.
	var side := Basis(Vector3.BACK, PI * 0.5)
	MeshKit.cylinder(curd, Transform3D(side, Vector3(0.06, 0.11, 0)), 0.15, 0.15, 0.13, 3, Color.WHITE, Color.WHITE, true, true, false)
	MeshKit.cylinder(rind, Transform3D(side, Vector3(-0.008, 0.11, 0)), 0.152, 0.152, 0.016, 3, Color.WHITE, Color.WHITE, true, true, false)
	for p in [Vector3(0.035, 0.175, 0.035), Vector3(0.09, 0.14, -0.03), Vector3(0.02, 0.09, -0.07)]:
		_ball(rind, p, 0.016, Color(0.80, 0.62, 0.28), 1.0, 5, 3)

static func _bowl(mesh: ArrayMesh, spec: Dictionary) -> void:
	var bowl := _st(mesh, _mat(Color(0.62, 0.52, 0.40), 0.9))
	var stew := _st(mesh, _mat(Color(0.58, 0.34, 0.16), 0.75))
	var veg := _st(mesh, _mat(Color(0.72, 0.55, 0.22), 0.8))
	MeshKit.cylinder(bowl, Transform3D(Basis.IDENTITY, Vector3(0, 0.0, 0)), 0.13, 0.19, 0.10, 12, Color.WHITE, Color.WHITE, true, false, true)
	_cyl(stew, Vector3(0, 0.082, 0), 0.168, 0.168, 0.022, Color(0.58, 0.34, 0.16), 12)
	for i in range(4):
		var a: float = TAU * float(i) / 4.0
		_ball(veg, Vector3(cos(a) * 0.07, 0.11, sin(a) * 0.07), 0.026, Color(0.72, 0.55, 0.22), 0.5, 5, 3)

static func _berries(mesh: ArrayMesh, spec: Dictionary) -> void:
	var berry := _st(mesh, _mat(spec["glow"].lerp(Color(0.65, 0.12, 0.25), 0.65), 0.45))
	var leaf := _st(mesh, _mat(Color(0.30, 0.50, 0.22), 0.9))
	for p in [Vector3(0.0, 0.05, 0.0), Vector3(0.075, 0.045, 0.02), Vector3(-0.06, 0.05, 0.04), Vector3(0.02, 0.05, -0.07), Vector3(-0.03, 0.11, -0.01), Vector3(0.05, 0.12, 0.03)]:
		_ball(berry, p, 0.038, spec["glow"].lerp(Color(0.6, 0.1, 0.22), 0.55), 1.0, 7, 4)
	for sx in [-1.0, 1.0]:
		MeshKit.blob(leaf, Vector3(sx * 0.06, 0.145, -0.02), Vector3(0.055, 0.008, 0.028), _rng, Color(0.24, 0.42, 0.18), Color(0.42, 0.60, 0.26), 0.1, 5, 3)

static func _carrot(mesh: ArrayMesh, spec: Dictionary) -> void:
	var root := _st(mesh, _mat(Color(0.88, 0.50, 0.16), 0.8))
	var leaf := _st(mesh, _mat(Color(0.30, 0.55, 0.24), 0.9))
	_cyl(root, Vector3(0, 0.0, 0), 0.042, 0.005, 0.28, Color(0.84, 0.46, 0.14), 8)
	for k in 4:
		var a: float = TAU * float(k) / 4.0
		MeshKit.cylinder_between(leaf, Vector3(0, 0.27, 0), Vector3(cos(a) * 0.055, 0.40, sin(a) * 0.055), 0.008, 0.002, 5, Color(0.28, 0.52, 0.22), Color(0.42, 0.68, 0.30))

static func _wheat(mesh: ArrayMesh, spec: Dictionary) -> void:
	var straw := _st(mesh, _mat(Color(0.80, 0.66, 0.32), 0.9))
	var grain := _st(mesh, _mat(Color(0.90, 0.76, 0.38), 0.85))
	var band := _st(mesh, _mat(ROPE, 0.9))
	for i in range(9):
		var a: float = TAU * float(i) / 9.0
		var lean := Vector3(cos(a) * 0.05, 0.0, sin(a) * 0.05)
		MeshKit.cylinder_between(straw, Vector3(0, 0, 0), Vector3(lean.x, 0.50 + float(i % 3) * 0.03, lean.z), 0.005, 0.004, 5, Color(0.72, 0.58, 0.28), Color(0.86, 0.72, 0.36))
		_ball(grain, Vector3(lean.x, 0.53 + float(i % 3) * 0.03, lean.z), 0.020, Color(0.90, 0.76, 0.38), 1.8, 5, 3)
	_cyl(band, Vector3(0, 0.30, 0), 0.062, 0.062, 0.035, ROPE, 8)

static func _egg(mesh: ArrayMesh, spec: Dictionary) -> void:
	var shell := _st(mesh, _mat(Color(0.94, 0.90, 0.80), 0.55))
	MeshKit.blob_smooth(shell, Vector3(0, 0.10, 0), Vector3(0.080, 0.105, 0.080), _rng, Color(0.86, 0.82, 0.72), Color(0.98, 0.95, 0.88), 0.02, 9, 6)
	MeshKit.blob_smooth(shell, Vector3(0.10, 0.065, 0.05), Vector3(0.060, 0.075, 0.060), _rng, Color(0.84, 0.80, 0.70), Color(0.96, 0.93, 0.86), 0.03, 8, 5)

static func _jug(mesh: ArrayMesh, spec: Dictionary) -> void:
	var ceramic := _st(mesh, _mat(Color(0.90, 0.88, 0.80), 0.5))
	var milk := _st(mesh, _mat(Color(0.97, 0.96, 0.92), 0.6))
	var cork := _st(mesh, _wood())
	_cyl(ceramic, Vector3(0, 0, 0), 0.105, 0.105, 0.20, Color.WHITE, 10)
	_cyl(ceramic, Vector3(0, 0.20, 0), 0.095, 0.048, 0.06, Color.WHITE, 10)
	_cyl(ceramic, Vector3(0, 0.26, 0), 0.043, 0.043, 0.05, Color.WHITE, 8)
	_cyl(milk, Vector3(0, 0.30, 0), 0.042, 0.042, 0.012, Color.WHITE, 8)
	_cyl(cork, Vector3(0, 0.305, 0), 0.045, 0.040, 0.03, WOOD, 8)
	MeshKit.cylinder_between(ceramic, Vector3(0.09, 0.24, 0), Vector3(0.135, 0.14, 0), 0.017, 0.017, 6, Color.WHITE, Color.WHITE)
	MeshKit.cylinder_between(ceramic, Vector3(0.135, 0.14, 0), Vector3(0.10, 0.06, 0), 0.017, 0.017, 6, Color.WHITE, Color.WHITE)

static func _fish(mesh: ArrayMesh, spec: Dictionary, cooked: bool) -> void:
	var tint: Color = spec["tint"]
	var body_col := Color(0.74, 0.55, 0.34) if cooked else tint.lerp(Color(0.55, 0.62, 0.68), 0.35)
	var fin_col := body_col.lerp(Color(0.35, 0.42, 0.50), 0.35)
	var body := _st(mesh, _mat(body_col, 0.35 if not cooked else 0.6, 0.15))
	var fin := _st(mesh, _mat(fin_col, 0.5))
	var eye := _st(mesh, _mat(Color(0.06, 0.05, 0.05), 0.2, 0.0, Color(0.05, 0.05, 0.05), 0.05))
	var id: String = spec["id"]
	if id == "fish_puffer":
		_ball(body, Vector3(0, 0.12, 0), 0.11, body_col, 1.0, 10, 7)
		for i in range(14):
			var a: float = TAU * float(i) / 14.0
			var y: float = float(i % 3) * 0.05 - 0.05
			var dir := Vector3(cos(a), y, sin(a)).normalized()
			MeshKit.cylinder_between(fin, dir * 0.09 + Vector3(0, 0.12, 0), dir * 0.15 + Vector3(0, 0.12, 0), 0.014, 0.0, 4, fin_col, fin_col)
		_ball(eye, Vector3(0.09, 0.14, 0.03), 0.016, Color(0.08, 0.07, 0.06), 1.0, 5, 3)
		return
	MeshKit.blob_smooth(body, Vector3(0, 0.115, 0), Vector3(0.17, 0.068, 0.048), _rng, body_col.darkened(0.2), body_col.lightened(0.15), 0.03, 9, 6)
	MeshKit.blob_smooth(fin, Vector3(-0.19, 0.115, 0), Vector3(0.075, 0.075, 0.008), _rng, fin_col.darkened(0.15), fin_col.lightened(0.1), 0.08, 6, 4)
	MeshKit.blob(fin, Vector3(-0.01, 0.175, 0), Vector3(0.075, 0.035, 0.007), _rng, fin_col.darkened(0.2), fin_col, 0.08, 5, 3)
	_ball(eye, Vector3(0.115, 0.132, 0.036), 0.016, Color(0.08, 0.07, 0.06), 1.0, 5, 3)
	_ball(eye, Vector3(0.115, 0.132, -0.036), 0.016, Color(0.08, 0.07, 0.06), 1.0, 5, 3)
	if id == "fish_swordfish":
		MeshKit.cylinder_between(fin, Vector3(0.15, 0.12, 0), Vector3(0.36, 0.13, 0), 0.014, 0.002, 5, fin_col, fin_col)
	if id == "fish_angler":
		var tip := Vector3(0.11, 0.26, 0)
		MeshKit.cylinder_between(fin, Vector3(0.06, 0.17, 0), tip, 0.008, 0.005, 5, fin_col, fin_col)
		_ball(_st(mesh, _glow_mat(spec["glow"], 2.0)), tip, 0.025, spec["glow"], 1.0, 6, 4)
	if id == "fish_glowfin":
		MeshKit.blob(_st(mesh, _glow_mat(spec["glow"], 1.6)), Vector3(-0.20, 0.115, 0), Vector3(0.070, 0.070, 0.010), _rng, spec["glow"], spec["glow"], 0.06, 6, 4)
	if cooked:
		for k in 3:
			_box(fin, Vector3(-0.09 + float(k) * 0.08, 0.183, 0), Vector3(0.018, 0.006, 0.05), Color(0.35, 0.20, 0.10), Vector3(0, 0.4, 0))
		MeshKit.cylinder_between(fin, Vector3(-0.24, 0.115, 0), Vector3(0.26, 0.13, 0), 0.008, 0.008, 5, Color(0.55, 0.40, 0.22), Color(0.55, 0.40, 0.22))

# ---------------------------------------------------------------------------
# Materials and crafting
# ---------------------------------------------------------------------------
static func _ore(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var rock := _st(mesh, _mat(Color(0.40, 0.39, 0.38), 0.95))
	var vein := _st(mesh, _metal(tint))
	MeshKit.rock(rock, Vector3(0, 0.10, 0), Vector3(0.16, 0.13, 0.14), _rng, Color(0.28, 0.27, 0.26), Color(0.52, 0.50, 0.48))
	MeshKit.rock(rock, Vector3(0.13, 0.07, 0.06), Vector3(0.10, 0.09, 0.09), _rng, Color(0.28, 0.27, 0.26), Color(0.48, 0.46, 0.44))
	MeshKit.rock(rock, Vector3(-0.10, 0.06, -0.05), Vector3(0.09, 0.08, 0.10), _rng, Color(0.28, 0.27, 0.26), Color(0.46, 0.44, 0.42))
	var veins := [
		[Vector3(0.03, 0.215, 0.04), Vector3(0.085, 0.010, 0.022), Vector3(0.2, 0.5, 0.4)],
		[Vector3(-0.04, 0.155, 0.125), Vector3(0.070, 0.009, 0.018), Vector3(-0.3, 0.2, -0.4)],
		[Vector3(0.095, 0.155, -0.03), Vector3(0.060, 0.010, 0.020), Vector3(0.4, -0.3, 0.5)],
		[Vector3(-0.115, 0.10, 0.03), Vector3(0.050, 0.008, 0.016), Vector3(0.1, 0.6, -0.2)],
		[Vector3(0.06, 0.055, 0.13), Vector3(0.055, 0.008, 0.018), Vector3(-0.4, 0.1, 0.3)],
	]
	for v in veins:
		_box(vein, v[0], v[1], tint, v[2])

static func _ingot(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var metal := _st(mesh, _metal(tint))
	var dark := _st(mesh, _mat(tint.darkened(0.4), 0.4, 0.8))
	_box(metal, Vector3(0, 0.045, 0), Vector3(0.28, 0.085, 0.13), tint)
	_box(dark, Vector3(0, 0.089, 0), Vector3(0.11, 0.006, 0.06), tint.darkened(0.35))
	_box(metal, Vector3(0.03, 0.135, 0.02), Vector3(0.22, 0.07, 0.105), tint.lightened(0.05), Vector3(0, 0.16, 0))
	_box(dark, Vector3(0.03, 0.172, 0.02), Vector3(0.09, 0.005, 0.05), tint.darkened(0.35), Vector3(0, 0.16, 0))

static func _log(mesh: ArrayMesh, spec: Dictionary) -> void:
	var wood := _st(mesh, _wood(WOOD.lerp(spec["tint"], 0.25)))
	var cut := _st(mesh, _mat(Color(0.72, 0.58, 0.40), 0.9))
	var base := Basis(Vector3(0, 0, 1), PI * 0.5)
	MeshKit.cylinder(wood, Transform3D(base, Vector3(0, 0.095, 0)), 0.095, 0.088, 0.44, 9, Color(0.75, 0.75, 0.75), Color.WHITE)
	for end_x in [0.0, -0.441]:
		MeshKit.cylinder(cut, Transform3D(base, Vector3(end_x, 0.095, 0)), 0.078, 0.078, 0.008, 9, Color.WHITE, Color.WHITE)
	MeshKit.blob(wood, Vector3(0.10, 0.13, 0.06), Vector3(0.024, 0.02, 0.02), _rng, Color(0.22, 0.14, 0.08), Color(0.30, 0.20, 0.11), 0.1, 5, 3)
	MeshKit.cylinder(wood, Transform3D(base, Vector3(0.02, 0.235, 0.02)), 0.065, 0.060, 0.28, 8, Color(0.75, 0.75, 0.75), Color.WHITE)

static func _plank(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tone := _st(mesh, _wood(WOOD))
	var tone2 := _st(mesh, _wood(WOOD.lerp(LEATHER, 0.35)))
	for i in range(3):
		_box(tone if i % 2 == 0 else tone2, Vector3(0, 0.022 + float(i) * 0.042, 0), Vector3(0.50, 0.038, 0.16), Color.WHITE, Vector3(0, float(i) * 0.035 - 0.035, 0))

static func _crystal(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.15))
	var rock := _st(mesh, _mat(Color(0.34, 0.33, 0.34), 0.95))
	MeshKit.rock(rock, Vector3(0, 0.05, 0), Vector3(0.16, 0.07, 0.14), _rng, Color(0.24, 0.23, 0.24), Color(0.42, 0.40, 0.42))
	_shard(glow, Vector3(0, 0.04, 0), 0.36, 0.065, Vector3.RIGHT, 0.10, spec["glow"])
	_shard(glow, Vector3(0.09, 0.04, 0.03), 0.22, 0.045, Vector3.BACK, -0.32, spec["glow"].lerp(tint, 0.3))
	_shard(glow, Vector3(-0.08, 0.04, 0.05), 0.26, 0.040, Vector3.RIGHT, 0.38, spec["glow"].lerp(Color.WHITE, 0.2))
	_shard(glow, Vector3(0.02, 0.03, -0.09), 0.17, 0.032, Vector3.FORWARD, 0.5, spec["glow"].lerp(tint, 0.4))
	_ball(glow, Vector3(-0.01, 0.05, -0.01), 0.035, spec["glow"], 0.7, 5, 3)

static func _flower(mesh: ArrayMesh, spec: Dictionary) -> void:
	var stem := _st(mesh, _mat(Color(0.28, 0.48, 0.24), 0.9))
	var petal := _st(mesh, _glow_mat(spec["glow"], 0.65))
	var heart := _st(mesh, _mat(Color(0.95, 0.82, 0.38), 0.7))
	for k in 3:
		var a: float = TAU * float(k) / 3.0
		var top := Vector3(cos(a) * 0.07, 0.24 + float(k) * 0.035, sin(a) * 0.07)
		MeshKit.cylinder_between(stem, Vector3(cos(a) * 0.02, 0, sin(a) * 0.02), top, 0.008, 0.006, 5, Color(0.24, 0.44, 0.22), Color(0.36, 0.56, 0.28))
		for p in range(5):
			var pa: float = TAU * float(p) / 5.0
			MeshKit.blob(petal, top + Vector3(cos(pa) * 0.035, 0.012, sin(pa) * 0.035), Vector3(0.028, 0.010, 0.020), _rng, spec["glow"], spec["glow"], 0.1, 5, 3)
		_ball(heart, top, 0.016, Color(0.95, 0.82, 0.38), 1.0, 5, 3)
	for sx in [-1.0, 1.0]:
		MeshKit.blob(stem, Vector3(sx * 0.06, 0.09, 0.0), Vector3(0.045, 0.008, 0.020), _rng, Color(0.22, 0.42, 0.20), Color(0.38, 0.58, 0.28), 0.1, 5, 3)

static func _mushroom(mesh: ArrayMesh, spec: Dictionary) -> void:
	var stem := _st(mesh, _mat(Color(0.88, 0.85, 0.76), 0.85))
	var cap := _st(mesh, _glow_mat(spec["glow"].lerp(Color(0.55, 0.30, 0.60), 0.4), 1.3 if spec["id"].contains("glow") else 0.2))
	for p in [Vector3(0, 0, 0), Vector3(0.10, 0, 0.05), Vector3(-0.08, 0, 0.04)]:
		var h: float = 0.15 if p == Vector3.ZERO else 0.12
		_cyl(stem, p, 0.020, 0.015, h, Color(0.88, 0.85, 0.76), 7)
		MeshKit.blob(cap, p + Vector3(0, h, 0), Vector3(0.075, 0.040, 0.075), _rng, spec["glow"].darkened(0.3), spec["glow"], 0.08, 7, 4)

static func _moss(mesh: ArrayMesh, spec: Dictionary) -> void:
	var green := _st(mesh, _mat(spec["tint"].lerp(Color(0.28, 0.46, 0.22), 0.65), 0.95))
	var light := _st(mesh, _mat(spec["tint"].lerp(Color(0.40, 0.60, 0.30), 0.55), 0.92))
	MeshKit.blob(green, Vector3(0, 0.05, 0), Vector3(0.17, 0.07, 0.15), _rng, Color(0.20, 0.34, 0.16), Color(0.34, 0.52, 0.24), 0.18, 7, 4)
	for i in range(7):
		var a: float = TAU * float(i) / 7.0
		MeshKit.blob(light, Vector3(cos(a) * 0.10, 0.075, sin(a) * 0.09), Vector3(0.055, 0.025, 0.045), _rng, Color(0.28, 0.46, 0.20), Color(0.48, 0.66, 0.30), 0.15, 5, 3)

static func _gel(mesh: ArrayMesh, spec: Dictionary) -> void:
	var gel := _st(mesh, _mat(spec["glow"].lerp(Color(0.35, 0.75, 0.50), 0.5), 0.12, 0.0, spec["glow"], 0.7, 0.72))
	MeshKit.blob_smooth(gel, Vector3(0, 0.09, 0), Vector3(0.13, 0.11, 0.12), _rng, spec["glow"].darkened(0.2), spec["glow"].lerp(Color.WHITE, 0.2), 0.10, 8, 5)
	_ball(gel, Vector3(0.13, 0.05, 0.04), 0.045, spec["glow"], 0.9, 6, 4)
	_ball(gel, Vector3(-0.10, 0.04, -0.07), 0.032, spec["glow"], 0.9, 6, 4)

static func _pouch(mesh: ArrayMesh, spec: Dictionary) -> void:
	var cloth := _st(mesh, _mat(BURLAP, 0.95))
	var tie := _st(mesh, _mat(ROPE, 0.9))
	var seed := _st(mesh, _mat(Color(0.82, 0.68, 0.40), 0.85))
	MeshKit.blob_smooth(cloth, Vector3(0, 0.09, 0), Vector3(0.12, 0.10, 0.10), _rng, BURLAP.darkened(0.18), BURLAP.lightened(0.1), 0.08, 8, 5)
	_cyl(tie, Vector3(0, 0.185, 0), 0.048, 0.048, 0.032, ROPE, 8)
	MeshKit.blob(cloth, Vector3(0, 0.22, 0), Vector3(0.055, 0.035, 0.05), _rng, BURLAP.darkened(0.2), BURLAP, 0.15, 6, 3)
	for p in [Vector3(0.15, 0.02, 0.03), Vector3(0.18, 0.02, -0.02), Vector3(0.13, 0.035, 0.08), Vector3(0.20, 0.02, 0.05)]:
		_ball(seed, p, 0.018, Color(0.82, 0.68, 0.40), 0.7, 5, 3)

static func _sack(mesh: ArrayMesh, spec: Dictionary) -> void:
	var cloth := _st(mesh, _mat(BURLAP, 0.95))
	var tie := _st(mesh, _mat(ROPE, 0.9))
	var patch := _st(mesh, _mat(CREAM, 0.9))
	MeshKit.blob_smooth(cloth, Vector3(0, 0.14, 0), Vector3(0.17, 0.15, 0.145), _rng, BURLAP.darkened(0.2), BURLAP.lightened(0.12), 0.09, 9, 6)
	_cyl(tie, Vector3(0, 0.285, 0), 0.060, 0.060, 0.035, ROPE, 8)
	MeshKit.blob(cloth, Vector3(0, 0.32, 0), Vector3(0.07, 0.04, 0.06), _rng, BURLAP.darkened(0.1), BURLAP, 0.14, 6, 3)
	_box(patch, Vector3(0, 0.16, 0.143), Vector3(0.09, 0.08, 0.006), CREAM)

static func _bundle(mesh: ArrayMesh, spec: Dictionary) -> void:
	var silk: bool = spec["id"].contains("silk")
	var c_lo: Color = Color(0.42, 0.32, 0.58) if silk else spec["tint"].lerp(Color(0.74, 0.60, 0.30), 0.65)
	var c_hi: Color = Color(0.66, 0.56, 0.84) if silk else spec["tint"].lerp(Color(0.90, 0.78, 0.44), 0.70)
	var straw := _st(mesh, _mat(c_lo, 0.55 if silk else 0.92, 0.35 if silk else 0.0))
	var band := _st(mesh, _mat(ROPE if not silk else Color(0.30, 0.24, 0.42), 0.9))
	for i in range(12):
		var a: float = TAU * float(i) / 12.0
		var rb: float = 0.045 + 0.015 * float(i % 3)
		var rt: float = rb * 0.32
		var top := Vector3(cos(a) * rt, 0.40 + float(i % 4) * 0.018, sin(a) * rt)
		MeshKit.cylinder_between(straw, Vector3(cos(a) * rb, 0, sin(a) * rb), top, 0.013, 0.005, 5, c_lo, c_hi)
	_cyl(band, Vector3(0, 0.17, 0), 0.068, 0.068, 0.035, ROPE if not silk else Color(0.30, 0.24, 0.42), 8)
	_cyl(band, Vector3(0, 0.27, 0), 0.056, 0.056, 0.028, ROPE if not silk else Color(0.30, 0.24, 0.42), 8)

static func _pelt(mesh: ArrayMesh, spec: Dictionary) -> void:
	var fur := _st(mesh, _mat(spec["tint"].lerp(LEATHER, 0.35), 0.95))
	var inner := _st(mesh, _mat(spec["tint"].lerp(CREAM, 0.45), 0.95))
	MeshKit.blob_smooth(fur, Vector3(0, 0.035, 0), Vector3(0.26, 0.035, 0.20), _rng, spec["tint"].darkened(0.3), spec["tint"].lerp(Color.WHITE, 0.1), 0.10, 9, 4)
	for p in [Vector3(0.22, 0.03, 0.14), Vector3(-0.22, 0.03, 0.14), Vector3(0.20, 0.03, -0.15), Vector3(-0.20, 0.03, -0.15)]:
		MeshKit.blob(fur, p, Vector3(0.07, 0.025, 0.075), _rng, spec["tint"].darkened(0.3), spec["tint"], 0.15, 6, 3)
	MeshKit.blob_smooth(inner, Vector3(0, 0.068, 0.0), Vector3(0.17, 0.008, 0.12), _rng, spec["tint"].lerp(CREAM, 0.5), spec["tint"].lerp(CREAM, 0.7), 0.08, 8, 4)

static func _fur(mesh: ArrayMesh, spec: Dictionary) -> void:
	var wool := _st(mesh, _mat(spec["tint"].lerp(CREAM, 0.62), 0.98))
	var shade := _st(mesh, _mat(spec["tint"].lerp(CREAM, 0.38), 0.98))
	for i in range(8):
		var a: float = TAU * float(i) / 8.0
		var p := Vector3(cos(a) * 0.06, 0.09 + float(i % 3) * 0.028, sin(a) * 0.055)
		MeshKit.blob_smooth(wool if i % 2 == 0 else shade, p, Vector3(0.088, 0.072, 0.088), _rng, spec["tint"].lerp(CREAM, 0.42), spec["tint"].lerp(CREAM, 0.78), 0.18, 7, 5)
	MeshKit.blob_smooth(wool, Vector3(0, 0.185, 0), Vector3(0.10, 0.065, 0.10), _rng, spec["tint"].lerp(CREAM, 0.5), spec["tint"].lerp(CREAM, 0.88), 0.16, 8, 5)

static func _fang(mesh: ArrayMesh, spec: Dictionary) -> void:
	var ivory := _st(mesh, _mat(IVORY, 0.4))
	var base_col := _st(mesh, _mat(Color(0.55, 0.44, 0.32), 0.8))
	var big: bool = spec["id"].contains("alpha") or spec["id"].contains("packlord") or spec["id"].contains("tide")
	var h: float = 0.34 if big else 0.24
	for k in range(4):
		var t0: float = float(k) / 4.0
		var t1: float = float(k + 1) / 4.0
		var p0 := Vector3(0.06 * t0 * t0, h * t0, 0.03 * t0)
		var p1 := Vector3(0.06 * t1 * t1, h * t1, 0.03 * t1)
		MeshKit.cylinder_between(ivory, p0, p1, lerpf(0.055, 0.005, t0), lerpf(0.055, 0.005, t1), 7, IVORY, IVORY)
	_ball(base_col, Vector3(0, 0.0, 0), 0.07, Color(0.55, 0.44, 0.32), 0.4, 7, 4)

static func _bone(mesh: ArrayMesh, spec: Dictionary) -> void:
	var bone := _st(mesh, _mat(IVORY.lerp(Color(0.72, 0.66, 0.52), 0.35), 0.7))
	var xf := Transform3D(Basis(Vector3.BACK, PI * 0.5), Vector3(0, 0.09, 0))
	MeshKit.cylinder(bone, xf, 0.028, 0.028, 0.32, 7, IVORY, IVORY)
	for sx in [-1.0, 1.0]:
		for off in [Vector3(0, 0.035, 0.03), Vector3(0, 0.035, -0.03), Vector3(0, -0.035, 0.03), Vector3(0, -0.035, -0.03)]:
			_ball(bone, Vector3(sx * 0.16, 0.09, 0) + off * 0.9, 0.045, IVORY, 1.0, 6, 4)

static func _coins(mesh: ArrayMesh, spec: Dictionary) -> void:
	var gold := _st(mesh, _metal(Color(0.92, 0.75, 0.32)))
	var dark := _st(mesh, _mat(Color(0.60, 0.46, 0.16), 0.4, 0.8))
	for i in range(6):
		var y: float = 0.008 + float(i) * 0.017
		_cyl(gold, Vector3(float(i % 2) * 0.012 - 0.006, y, float(i % 3) * 0.008 - 0.008), 0.075, 0.075, 0.013, Color(0.92, 0.75, 0.32), 12)
	_box(dark, Vector3(0, 0.10, 0), Vector3(0.02, 0.02, 0.09), Color(0.60, 0.46, 0.16))
	var lean := Basis(Vector3.BACK, PI * 0.28)
	MeshKit.cylinder(gold, Transform3D(lean, Vector3(0.12, 0.01, 0.02)), 0.075, 0.075, 0.013, 12, Color(0.92, 0.75, 0.32), Color(0.92, 0.75, 0.32), true, true)

static func _pearl(mesh: ArrayMesh, spec: Dictionary) -> void:
	var shell := _st(mesh, _mat(Color(0.78, 0.64, 0.61), 0.55))
	var pearl := _st(mesh, _mat(Color(0.93, 0.91, 0.94), 0.10, 0.25, Color(0.55, 0.60, 0.72), 0.18))
	MeshKit.blob_smooth(shell, Vector3(0, 0.035, 0), Vector3(0.16, 0.045, 0.13), _rng, Color(0.62, 0.48, 0.48), Color(0.86, 0.74, 0.72), 0.06, 8, 4)
	MeshKit.blob_smooth(shell, Vector3(0, 0.09, -0.075), Vector3(0.15, 0.05, 0.10), _rng, Color(0.58, 0.44, 0.46), Color(0.84, 0.70, 0.70), 0.06, 8, 4)
	MeshKit.blob_smooth(pearl, Vector3(0, 0.125, 0.02), Vector3(0.085, 0.085, 0.085), _rng, Color(0.86, 0.86, 0.90), Color(0.99, 0.98, 1.0), 0.0, 10, 7)

static func _scale(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var plate := _st(mesh, _mat(tint.lerp(Color(0.62, 0.74, 0.70), 0.3), 0.20, 0.55, tint, 0.22))
	for p in [Vector3(0, 0.04, 0), Vector3(0.05, 0.075, 0.04), Vector3(-0.04, 0.11, 0.01)]:
		MeshKit.blob_smooth(plate, p, Vector3(0.10, 0.018, 0.13), _rng, tint.darkened(0.3), tint.lerp(Color.WHITE, 0.3), 0.05, 8, 4)
	_ball(_st(mesh, _metal(tint.lerp(Color(0.90, 0.95, 0.90), 0.4))), Vector3(0.0, 0.135, 0.06), 0.02, tint, 1.0, 5, 3)

static func _chitin(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var plate := _st(mesh, _mat(tint.lerp(Color(0.30, 0.26, 0.24), 0.5), 0.35, 0.25))
	var ridge := _st(mesh, _mat(tint.lerp(Color(0.62, 0.56, 0.48), 0.4), 0.3, 0.3))
	MeshKit.blob_smooth(plate, Vector3(0, 0.06, 0), Vector3(0.17, 0.05, 0.20), _rng, tint.darkened(0.5), tint.lerp(Color(0.55, 0.48, 0.40), 0.3), 0.07, 8, 4)
	for i in range(3):
		_box(ridge, Vector3(0, 0.10, -0.06 + float(i) * 0.06), Vector3(0.20 - float(i) * 0.03, 0.03, 0.02), tint.lerp(Color(0.62, 0.56, 0.48), 0.4), Vector3(0.1, 0, 0))
	for sx in [-1.0, 1.0]:
		_shard(plate, Vector3(sx * 0.11, 0.05, 0.16), 0.16, 0.030, Vector3.BACK, sx * 0.5, tint.darkened(0.2))

static func _coral(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var branch := _st(mesh, _mat(tint.lerp(Color(0.90, 0.55, 0.55), 0.45), 0.8))
	var rock := _st(mesh, _mat(Color(0.40, 0.38, 0.38), 0.95))
	MeshKit.rock(rock, Vector3(0, 0.04, 0), Vector3(0.12, 0.05, 0.11), _rng, Color(0.28, 0.27, 0.27), Color(0.46, 0.44, 0.44))
	for k in 5:
		var a: float = TAU * float(k) / 5.0
		var mid := Vector3(cos(a) * 0.09, 0.16, sin(a) * 0.09)
		var top := Vector3(cos(a) * 0.13, 0.30 + float(k % 2) * 0.05, sin(a) * 0.13)
		MeshKit.cylinder_between(branch, Vector3(cos(a) * 0.04, 0.03, sin(a) * 0.04), mid, 0.032, 0.022, 6, tint.darkened(0.2), tint)
		MeshKit.cylinder_between(branch, mid, top, 0.022, 0.010, 5, tint, tint.lerp(Color.WHITE, 0.2))
		_ball(branch, top, 0.020, tint.lerp(Color.WHITE, 0.15), 1.0, 5, 3)

static func _strap(mesh: ArrayMesh, spec: Dictionary) -> void:
	var leather := _st(mesh, _mat(LEATHER, 0.8))
	var buckle := _st(mesh, _metal(Color(0.72, 0.68, 0.52)))
	for i in range(12):
		var a0: float = TAU * float(i) / 12.0
		var a1: float = TAU * float(i + 1) / 12.0
		var p0 := Vector3(cos(a0) * 0.13, 0.03 + sin(a0) * 0.012, sin(a0) * 0.13)
		var p1 := Vector3(cos(a1) * 0.13, 0.03 + sin(a1) * 0.012, sin(a1) * 0.13)
		MeshKit.cylinder_between(leather, p0, p1, 0.016, 0.016, 5, LEATHER, LEATHER)
	_box(buckle, Vector3(0.13, 0.03, 0), Vector3(0.035, 0.045, 0.05), Color(0.72, 0.68, 0.52))

static func _rod(mesh: ArrayMesh, spec: Dictionary) -> void:
	var wood := _st(mesh, _wood(WOOD))
	var grip := _st(mesh, _mat(LEATHER, 0.86))
	var metal := _st(mesh, _metal(Color(0.62, 0.58, 0.50)))
	var line := _st(mesh, _mat(Color(0.90, 0.90, 0.85), 0.4))
	var bob := _st(mesh, _mat(Color(0.85, 0.18, 0.14), 0.35, 0.1, Color(0.85, 0.18, 0.14), 0.3))
	_cyl(wood, Vector3.ZERO, 0.022, 0.008, 1.20, WOOD, 8)
	_cyl(grip, Vector3(0, 0.06, 0), 0.028, 0.028, 0.20, LEATHER.darkened(0.15), 8)
	_cyl(metal, Vector3(0.0, 0.40, 0), 0.045, 0.045, 0.035, Color(0.62, 0.58, 0.50), 10)
	for a in [0.0, 1.2, 2.4]:
		MeshKit.cylinder_between(metal, Vector3(0, 0.55 + a * 0.12, 0), Vector3(0.035, 0.55 + a * 0.12, 0), 0.012, 0.012, 5, Color(0.62, 0.58, 0.50), Color(0.62, 0.58, 0.50))
	var p0 := Vector3(0, 1.19, 0)
	var p1 := Vector3(0.10, 1.02, 0)
	var p2 := Vector3(0.12, 0.78, 0)
	MeshKit.cylinder_between(line, p0, p1, 0.0025, 0.0025, 4, Color(0.9, 0.9, 0.85), Color(0.9, 0.9, 0.85))
	MeshKit.cylinder_between(line, p1, p2, 0.0025, 0.0025, 4, Color(0.9, 0.9, 0.85), Color(0.9, 0.9, 0.85))
	_ball(bob, p2, 0.024, Color(0.85, 0.18, 0.14), 1.0, 6, 4)

# ---------------------------------------------------------------------------
# Relics and trophies
# ---------------------------------------------------------------------------
static func _book(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var cover_col := tint.lerp(Color(0.42, 0.28, 0.16), 0.35)
	var cover := _st(mesh, _mat(cover_col, 0.55, 0.2))
	var pages := _st(mesh, _mat(CREAM, 0.92))
	var metal := _st(mesh, _metal(tint.lerp(Color(0.85, 0.72, 0.40), 0.55)))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 0.7))
	_box(cover, Vector3(0, 0.018, 0), Vector3(0.26, 0.036, 0.34), cover_col)
	_box(pages, Vector3(0, 0.046, 0), Vector3(0.245, 0.024, 0.325), CREAM)
	_box(cover, Vector3(0, 0.072, 0), Vector3(0.26, 0.028, 0.34), cover_col)
	_box(cover, Vector3(-0.115, 0.036, 0), Vector3(0.035, 0.085, 0.34), cover_col.darkened(0.2))
	for sx in [-1.0, 1.0]:
		_box(metal, Vector3(sx * 0.095, 0.09, 0), Vector3(0.05, 0.006, 0.34), tint.lerp(Color(0.85, 0.72, 0.40), 0.5))
	_box(metal, Vector3(0.11, 0.055, 0.0), Vector3(0.03, 0.055, 0.06), tint.lerp(Color(0.85, 0.72, 0.40), 0.5))
	_shard(glow, Vector3(0, 0.087, 0.0), 0.05, 0.035, Vector3.FORWARD, 0.0, spec["glow"])
	var emblem := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	for i in range(4):
		var a: float = TAU * float(i) / 4.0
		_box(emblem, Vector3(cos(a) * 0.035, 0.09, sin(a) * 0.035), Vector3(0.02, 0.004, 0.02), spec["glow"], Vector3(0, a, 0))
	if spec["id"] == "celestial_codex":
		for p in [Vector3(0.05, 0.091, 0.10), Vector3(-0.06, 0.091, -0.06), Vector3(0.07, 0.091, -0.11), Vector3(-0.03, 0.091, 0.12)]:
			_ball(emblem, p, 0.007, spec["glow"], 1.0, 5, 3)

static func _medallion(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var metal := _st(mesh, _metal(tint.lerp(Color(0.88, 0.74, 0.40), 0.5)))
	var trim := _st(mesh, _mat(tint.lerp(Color(0.95, 0.82, 0.48), 0.6), 0.3, 0.9))
	var ribbon := _st(mesh, _mat(tint.lerp(Color(0.50, 0.16, 0.20), 0.45), 0.9))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	var disc := Basis(Vector3.RIGHT, PI * 0.5)
	MeshKit.cylinder(metal, Transform3D(disc, Vector3(0, 0.20, -0.01)), 0.105, 0.105, 0.022, 14, tint.lerp(Color(0.88, 0.74, 0.40), 0.4), tint.lerp(Color(0.88, 0.74, 0.40), 0.4))
	MeshKit.cylinder(trim, Transform3D(disc, Vector3(0, 0.20, 0.012)), 0.075, 0.075, 0.006, 14, tint.lerp(Color(0.95, 0.82, 0.48), 0.5), tint.lerp(Color(0.95, 0.82, 0.48), 0.5))
	for i in range(8):
		var a: float = TAU * float(i) / 8.0
		_ball(trim, Vector3(cos(a) * 0.092, 0.20 + sin(a) * 0.092, 0.026), 0.010, tint.lerp(Color(0.95, 0.82, 0.48), 0.5), 1.0, 5, 3)
	_ball(glow, Vector3(0, 0.20, 0.03), 0.026, spec["glow"])
	for sx in [-1.0, 1.0]:
		_box(ribbon, Vector3(sx * 0.032, 0.35, -0.004), Vector3(0.045, 0.20, 0.008), tint.lerp(Color(0.50, 0.16, 0.20), 0.45), Vector3(0, 0, sx * 0.30))

static func _crown(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var metal := _st(mesh, _metal(tint.lerp(Color(0.90, 0.74, 0.36), 0.45)))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"]))
	var prev := Vector3(0.14, 0.05, 0)
	for i in range(1, 13):
		var a: float = TAU * float(i) / 12.0
		var p := Vector3(cos(a) * 0.14, 0.05 + sin(a * 0.5) * 0.006, sin(a) * 0.14)
		MeshKit.cylinder_between(metal, prev, p, 0.018, 0.018, 5, tint, tint)
		prev = p
	for i in range(6):
		var a: float = TAU * float(i) / 6.0
		var base := Vector3(cos(a) * 0.14, 0.055, sin(a) * 0.14)
		_shard(metal, base, 0.11, 0.030, Vector3.RIGHT, cos(a) * 0.25, tint.lerp(Color(0.90, 0.74, 0.36), 0.4))
		_ball(glow, base + Vector3(0, 0.10, 0), 0.018, spec["glow"], 1.0, 5, 3)
	_cyl(metal, Vector3(0, 0.055, 0), 0.15, 0.15, 0.018, tint.lerp(Color(0.90, 0.74, 0.36), 0.35), 12, false)

static func _core(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var shell := _st(mesh, _mat(tint.lerp(Color(0.22, 0.20, 0.24), 0.55), 0.6, 0.3))
	var glow := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.7))
	var band := _st(mesh, _metal(tint.lerp(Color(0.80, 0.68, 0.40), 0.4)))
	MeshKit.blob_smooth(glow, Vector3(0, 0.20, 0), Vector3(0.09, 0.09, 0.09), _rng, spec["glow"].darkened(0.1), spec["glow"].lerp(Color.WHITE, 0.35), 0.05, 10, 7)
	for i in range(3):
		var a: float = TAU * float(i) / 3.0 + 0.4
		MeshKit.rock(shell, Vector3(cos(a) * 0.13, 0.20 + sin(a) * 0.05, sin(a) * 0.12), Vector3(0.075, 0.085, 0.07), _rng, tint.darkened(0.6), tint.darkened(0.2))
		_shard(glow, Vector3(cos(a) * 0.20, 0.17 + sin(a) * 0.06, sin(a) * 0.18), 0.10, 0.026, Vector3.BACK, a, spec["glow"])
	for i in range(8):
		var a2: float = TAU * float(i) / 8.0
		var p := Vector3(cos(a2) * 0.17, 0.20, sin(a2) * 0.17)
		var p2 := Vector3(cos(a2 + TAU / 8.0) * 0.17, 0.20, sin(a2 + TAU / 8.0) * 0.17)
		MeshKit.cylinder_between(band, p, p2, 0.007, 0.007, 5, tint, tint)

static func _wisp(mesh: ArrayMesh, spec: Dictionary) -> void:
	var glow := _st(mesh, _mat(spec["glow"], 0.1, 0.0, spec["glow"], spec["energy"] * 1.3, 0.55))
	MeshKit.blob_smooth(glow, Vector3(0, 0.17, 0), Vector3(0.095, 0.11, 0.095), _rng, spec["glow"].darkened(0.1), spec["glow"].lerp(Color.WHITE, 0.4), 0.06, 10, 7)
	_ball(glow, Vector3(0.12, 0.09, 0.03), 0.035, spec["glow"], 1.0, 6, 4)
	_ball(glow, Vector3(-0.10, 0.06, -0.04), 0.026, spec["glow"], 1.0, 6, 4)
	_ball(glow, Vector3(0.04, 0.30, 0.05), 0.016, spec["glow"], 1.0, 5, 3)

static func _dust(mesh: ArrayMesh, spec: Dictionary) -> void:
	var cloth := _st(mesh, _mat(BURLAP.darkened(0.3), 0.95))
	var spark := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 1.6))
	MeshKit.blob_smooth(cloth, Vector3(0, 0.06, 0), Vector3(0.11, 0.07, 0.10), _rng, BURLAP.darkened(0.35), BURLAP, 0.09, 8, 5)
	_cyl(cloth, Vector3(0, 0.11, 0), 0.055, 0.055, 0.03, BURLAP.darkened(0.25), 8)
	for i in range(9):
		var a: float = TAU * float(i) / 9.0
		var r: float = 0.06 + 0.04 * float(i % 3) / 2.0
		_ball(spark, Vector3(cos(a) * r, 0.20 + float(i % 4) * 0.03, sin(a) * r), 0.013, spec["glow"], 1.0, 5, 3)

static func _sac(mesh: ArrayMesh, spec: Dictionary) -> void:
	var sac := _st(mesh, _mat(spec["glow"].lerp(Color(0.55, 0.78, 0.40), 0.5), 0.15, 0.0, spec["glow"], 0.9, 0.75))
	var tendril := _st(mesh, _mat(Color(0.36, 0.46, 0.26), 0.8))
	MeshKit.blob_smooth(sac, Vector3(0, 0.13, 0), Vector3(0.12, 0.14, 0.11), _rng, spec["glow"].darkened(0.2), spec["glow"].lerp(Color.WHITE, 0.3), 0.09, 9, 6)
	for p in [Vector3(0.10, 0.20, 0.03), Vector3(-0.08, 0.06, -0.05), Vector3(0.02, 0.26, -0.04)]:
		_ball(sac, p, 0.018, spec["glow"], 1.0, 5, 3)
	MeshKit.cylinder_between(tendril, Vector3(0.06, 0.02, 0.03), Vector3(0.13, 0.02, 0.10), 0.010, 0.006, 4, Color(0.36, 0.46, 0.26), Color(0.36, 0.46, 0.26))
	MeshKit.cylinder_between(tendril, Vector3(-0.05, 0.02, -0.04), Vector3(-0.13, 0.02, 0.03), 0.010, 0.006, 4, Color(0.36, 0.46, 0.26), Color(0.36, 0.46, 0.26))

static func _sapling(mesh: ArrayMesh, spec: Dictionary) -> void:
	var soil := _st(mesh, _mat(Color(0.30, 0.22, 0.16), 0.95))
	var trunk := _st(mesh, _wood(WOOD))
	var leaf := _st(mesh, _mat(Color(0.30, 0.58, 0.30), 0.8))
	var bud := _st(mesh, _glow_mat(spec["glow"], spec["energy"] * 0.8))
	MeshKit.blob(soil, Vector3(0, 0.03, 0), Vector3(0.13, 0.040, 0.12), _rng, Color(0.22, 0.16, 0.12), Color(0.38, 0.28, 0.20), 0.1, 7, 4)
	MeshKit.cylinder_between(trunk, Vector3(0, 0.04, 0), Vector3(0.02, 0.42, 0.01), 0.030, 0.014, 6, WOOD, WOOD)
	for i in range(3):
		var a: float = TAU * float(i) / 3.0 + 0.5
		var c := Vector3(cos(a) * 0.10, 0.34 + float(i) * 0.04, sin(a) * 0.10)
		MeshKit.blob_smooth(leaf, c, Vector3(0.10, 0.07, 0.10), _rng, Color(0.22, 0.46, 0.22), Color(0.42, 0.66, 0.32), 0.12, 7, 4)
		_ball(bud, c + Vector3(0, 0.06, 0), 0.018, spec["glow"], 1.0, 5, 3)

static func _chunk(mesh: ArrayMesh, spec: Dictionary) -> void:
	var tint: Color = spec["tint"]
	var rock := _st(mesh, _mat(tint.lerp(Color(0.44, 0.42, 0.40), 0.55), 0.95))
	var fleck := _st(mesh, _metal(tint))
	MeshKit.rock(rock, Vector3(0, 0.09, 0), Vector3(0.15, 0.11, 0.13), _rng, tint.darkened(0.45), tint.lerp(Color(0.55, 0.52, 0.48), 0.5))
	for p in [Vector3(0.04, 0.19, 0.03), Vector3(-0.07, 0.12, 0.08), Vector3(0.08, 0.08, -0.05)]:
		_ball(fleck, p, 0.022, tint, 0.7, 5, 3)
