# Fishing + marine spawns (uses PlayerData / skills — no separate inventory UI)
extends Node
class_name FishingSystem

var _noise: TerrainNoise
var _cast_cd: float = 0.0
var _spawn_t: float = 0.0
var fishing_active := false
var fishing_phase := ""
var fishing_player: Node3D
var fishing_timer := 0.0
var _bite_wait_time: float = 5.0
var line_tension := 0.0
var reel_progress := 0.0
var bait_id := ""
var hooked_fish_id := "fish_trout"
var _last_reel_key := 0
var _fish_ui: CanvasLayer
var _fish_status: Label
var _fish_meter: ProgressBar

func _ready() -> void:
	add_to_group("fishing")
	_noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	_spawn_batch(12)
	_spawn_marine_batch(3)

func _process(delta: float) -> void:
	if fishing_active:
		_update_fishing_ui()
		fishing_timer += delta
		if fishing_phase == "waiting" and fishing_timer >= _bite_wait_time:
			fishing_phase = "bite"
			fishing_timer = 0.0
			EventBus.toast.emit("A bite! Press SPACE to set the hook.", "success")
		elif fishing_phase == "bite" and fishing_timer > 2.8:
			_end_fishing(false, "The fish stole your bait and escaped.")
		elif fishing_phase == "fight":
			var current_load := lerpf(0.045, 0.075, TideSystem.get_current_strength())
			line_tension = clampf(line_tension + delta * current_load, 0.0, 1.2)
			if line_tension >= 1.0:
				_end_fishing(false, "The line snapped under too much tension.")
			elif reel_progress >= 1.0:
				_finish_catch()
	_cast_cd = maxf(_cast_cd - delta, 0.0)
	_spawn_t += delta
	if _spawn_t > 22.0:
		_spawn_t = 0.0
		if get_tree().get_nodes_in_group("marine_life").size() < 26:
			_spawn_near_player(3)
		if get_tree().get_nodes_in_group("marine_creatures").size() < 7:
			_spawn_marine_near_player(1)

func _spawn_batch(n: int) -> void:
	var c: Vector2 = TerrainNoise.VILLAGE_CENTER
	for i in range(n):
		var a := randf() * TAU
		var r := randf_range(28.0, 95.0)
		_try_spawn(c.x + cos(a) * r, c.y + sin(a) * r)

func _spawn_near_player(n: int) -> void:
	var player: Node3D = GameManager.player
	if player == null:
		return
	for i in range(n):
		var a := randf() * TAU
		var r := randf_range(10.0, 40.0)
		_try_spawn(player.global_position.x + cos(a) * r, player.global_position.z + sin(a) * r)

func _try_spawn(wx: float, wz: float) -> void:
	var h: float = _noise.get_height(wx, wz)
	var water_level: float = TideSystem.level_at_bed(h)
	if h > water_level - 0.2:
		return
	var fish := MarineFish.new()
	var dist: float = Vector2(wx, wz).distance_to(TerrainNoise.VILLAGE_CENTER)
	fish.is_ocean = h < -1.2 or dist > 95.0
	if fish.is_ocean:
		fish.fish_id = ["fish_mackerel", "fish_mackerel", "fish_glowfin", "fish_parrotfish", "fish_sunfish", "fish_puffer", "fish_swordfish", "fish_angler"][randi() % 8]
	else:
		fish.fish_id = ["fish_minnow", "fish_trout", "fish_bass", "fish_trout", "fish_koi"][randi() % 5]
	fish.position = Vector3(wx, clampf(water_level - 0.35, h + 0.2, water_level - 0.12), wz)
	get_parent().add_child(fish)

func _spawn_marine_batch(count: int) -> void:
	var center: Vector2 = TerrainNoise.VILLAGE_CENTER
	for i in range(count * 5):
		if get_tree().get_nodes_in_group("marine_creatures").size() >= 7:
			break
		var angle := randf() * TAU
		var radius := randf_range(70.0, 145.0)
		_try_spawn_marine_creature(center.x + cos(angle) * radius, center.y + sin(angle) * radius)

func _spawn_marine_near_player(count: int) -> void:
	var player: Node3D = GameManager.player
	if player == null:
		return
	for i in range(count * 4):
		if get_tree().get_nodes_in_group("marine_creatures").size() >= 7:
			return
		var angle := randf() * TAU
		var radius := randf_range(14.0, 36.0)
		_try_spawn_marine_creature(player.global_position.x + cos(angle) * radius, player.global_position.z + sin(angle) * radius)

func _try_spawn_marine_creature(wx: float, wz: float) -> void:
	var h: float = _noise.get_height(wx, wz)
	var dist: float = Vector2(wx, wz).distance_to(TerrainNoise.VILLAGE_CENTER)
	if h > -1.55 or dist < 52.0 or randf() > 0.42:
		return
	var choices: Array[Dictionary] = [
		{"id": "dolphin", "name": "Spinner Dolphin", "color": Color(0.38, 0.62, 0.78), "scale": 0.9},
		{"id": "sea_turtle", "name": "Green Sea Turtle", "color": Color(0.22, 0.54, 0.36), "scale": 1.0},
		{"id": "reef_ray", "name": "Blue Reef Ray", "color": Color(0.22, 0.48, 0.68), "scale": 1.0},
		{"id": "reef_shark", "name": "Reef Shark", "color": Color(0.34, 0.48, 0.59), "scale": 1.05},
		{"id": "jellyfish", "name": "Moon Jellyfish", "color": Color(0.52, 0.74, 0.96), "scale": 0.9},
		{"id": "whale_shark", "name": "Whale Shark", "color": Color(0.24, 0.46, 0.6), "scale": 1.4}
	]
	var entry: Dictionary = choices[randi_range(0, choices.size() - 1)]
	var creature := MarineCreature.new()
	creature.creature_id = str(entry["id"])
	creature.display_name = str(entry["name"])
	creature.body_color = entry["color"]
	creature.body_scale = float(entry["scale"])
	creature.position = Vector3(wx, maxf(h + 0.95, -2.8), wz)
	get_parent().add_child(creature)

func try_fish(player: Node3D) -> void:
	if _noise == null: _noise = TerrainNoise.new(GameManager.world_seed)
	if fishing_active:
		EventBus.toast.emit("Your line is already in the water.", "info")
		return
	if _cast_cd > 0.0 or player == null:
		return
	var pos: Vector3 = player.global_position
	var near_water := false
	for ox in [-2.0, 0.0, 2.0, 4.0]:
		for oz in [-2.0, 0.0, 2.0, 4.0]:
			var bed_h: float = _noise.get_height(pos.x + ox, pos.z + oz)
			if bed_h < TideSystem.level_at_bed(bed_h) + 0.35:
				near_water = true
				break
	if not near_water:
		EventBus.toast.emit("Find a river, lake or shoreline before casting.", "warning")
		return
	if PlayerData.count_item("fishing_rod") <= 0:
		EventBus.toast.emit("You need a fishing rod.", "warning")
		return
	fishing_active = true
	GameManager.push_ui_lock()
	_create_fishing_ui()
	fishing_phase = "waiting"
	fishing_player = player
	fishing_timer = 0.0
	_bite_wait_time = clampf(randf_range(3.0, 7.0) * lerpf(1.12, 0.82, TideSystem.get_current_strength()), 2.2, 7.8)
	line_tension = 0.12
	reel_progress = 0.0
	_last_reel_key = 0
	_cast_cd = 1.0
	bait_id = ""
	EventBus.toast.emit("You cast your line. 1: berry bait, 2: seaweed bait, SPACE: hook when it bites.", "info")

func _input(event: InputEvent) -> void:
	if not fishing_active or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE:
		_end_fishing(false, "You reel in and stop fishing.")
		get_viewport().set_input_as_handled()
		return
	if fishing_phase == "waiting":
		if event.keycode == KEY_1 and PlayerData.remove_item("wild_berries", 1):
			bait_id = "wild_berries"; EventBus.toast.emit("Berry bait attached.", "info")
		elif event.keycode == KEY_2 and PlayerData.remove_item("seaweed", 1):
			bait_id = "seaweed"; EventBus.toast.emit("Seaweed bait attached.", "info")
	elif fishing_phase == "bite" and event.keycode == KEY_SPACE:
		fishing_phase = "fight"; fishing_timer = 0.0; line_tension = 0.28
		EventBus.toast.emit("Fish hooked! Alternate A / D to reel. Ease off if tension climbs.", "success")
	elif fishing_phase == "fight":
		if event.keycode == KEY_A or event.keycode == KEY_D:
			var key: int = int(event.keycode)
			if _last_reel_key == 0 or key != _last_reel_key:
				reel_progress = minf(1.0, reel_progress + 0.14)
				line_tension = maxf(0.08, line_tension - 0.13)
			else:
				line_tension = minf(1.2, line_tension + 0.16)
			_last_reel_key = key
			EventBus.toast.emit("Reeling %.0f%% | line tension %.0f%%" % [reel_progress * 100.0, line_tension * 100.0], "info")
		elif event.keycode == KEY_S:
			line_tension = maxf(0.05, line_tension - 0.22)
			EventBus.toast.emit("You let the line breathe. Tension reduced.", "info")

func _create_fishing_ui() -> void:
	_fish_ui = CanvasLayer.new(); _fish_ui.layer = 28; add_child(_fish_ui)
	var panel := PanelContainer.new(); panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM); panel.position = Vector2(-220,-150); panel.size = Vector2(440,110); _fish_ui.add_child(panel)
	var box := VBoxContainer.new(); panel.add_child(box)
	_fish_status = Label.new(); _fish_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; _fish_status.autowrap_mode = TextServer.AUTOWRAP_WORD; box.add_child(_fish_status)
	_fish_meter = ProgressBar.new(); _fish_meter.min_value = 0.0; _fish_meter.max_value = 100.0; box.add_child(_fish_meter)
	_update_fishing_ui()

func _update_fishing_ui() -> void:
	if _fish_status == null or _fish_meter == null: return
	if fishing_phase == "waiting":
		_fish_status.text = "FISHING | Choose bait: 1 berries, 2 seaweed | Waiting for a bite..."
		_fish_meter.value = minf(100.0, fishing_timer / 7.0 * 100.0)
	elif fishing_phase == "bite":
		_fish_status.text = "BITE! Press SPACE to set the hook before it escapes."
		_fish_meter.value = 100.0 - minf(100.0, fishing_timer / 2.8 * 100.0)
	else:
		_fish_status.text = "REEL | Alternate A / D. Press S to release tension. Line tension: %.0f%%" % (line_tension * 100.0)
		_fish_meter.value = reel_progress * 100.0

func _finish_catch() -> void:
	var luck := 0.0
	var season := get_tree().get_first_node_in_group("seasons")
	if season: luck += (season.fish_mult() - 1.0) * 0.5
	if fishing_player and fishing_player.get("skills"):
		luck += 0.02 * float(fishing_player.skills.get_value("fishing"))
	luck += PlayerData.title_bonus("fishing")
	luck += TideSystem.get_current_strength() * 0.04
	var best: MarineFish = null
	var best_d := 14.0
	for n in get_tree().get_nodes_in_group("marine_life"):
		if n is MarineFish and fishing_player:
			var d: float = fishing_player.global_position.distance_to(n.global_position)
			if d < best_d: best_d = d; best = n
	var item_id := "fish_trout" if randf() < 0.55 else "fish_minnow"
	if best: item_id = best.try_catch(luck)
	elif randf() < 0.22 + luck: item_id = "fish_bass"
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
		MMORPGNetwork.request_authoritative_fishing_catch()
	else:
		if bait_id != "" and randf() < 0.35: PlayerData.add_item(bait_id, 1)
		if ItemDB.has_item(item_id): PlayerData.add_item(item_id, 1)
	if ElyndorRegionLife and ElyndorRegionLife.has_method("record_fishing"):
		ElyndorRegionLife.record_fishing(item_id)
	if fishing_player and fishing_player.get("skills"):
		fishing_player.skills.train("fishing", 0.55)
		fishing_player.skills.train("exploration", 0.05)
	var catch_message := "The catch is being confirmed by Elyndor's shared server." if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() else "You land a %s. Good control of the line!" % ItemDB.display_name(ItemDB.make(item_id))
	_end_fishing(true, catch_message)

func _end_fishing(_success: bool, message: String) -> void:
	fishing_active = false
	GameManager.pop_ui_lock()
	fishing_phase = ""
	if is_instance_valid(_fish_ui): _fish_ui.queue_free()
	_fish_ui = null
	_fish_status = null
	_fish_meter = null
	fishing_player = null
	fishing_timer = 0.0
	line_tension = 0.0
	reel_progress = 0.0
	EventBus.toast.emit(message, "success" if _success else "warning")
