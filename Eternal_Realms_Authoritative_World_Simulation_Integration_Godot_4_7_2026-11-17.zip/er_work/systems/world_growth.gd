# Light world growth: saplings appear and mature over time (cosmetic + choppable wood later)
extends Node
class_name WorldGrowth

var growth_factor: float = 0.15
var _tick: float = 0.0
var _noise: TerrainNoise

func _ready() -> void:
	add_to_group("world_growth")
	_noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	for i in range(5):
		_spawn_sapling_village()

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	growth_factor = clampf(0.15 + GameManager.game_time_seconds / 480.0 * 0.03, 0.0, 1.2)
	_tick += delta
	if _tick < 14.0:
		return
	_tick = 0.0
	for n in get_tree().get_nodes_in_group("sapling"):
		if n.has_method("grow"):
			n.grow(0.09 + growth_factor * 0.05)
	if get_tree().get_nodes_in_group("sapling").size() < 35 and randf() < 0.4:
		_spawn_sapling_near_player()

func _spawn_sapling_village() -> void:
	var c: Vector2 = TerrainNoise.VILLAGE_CENTER
	var a := randf() * TAU
	var r := randf_range(26.0, 55.0)
	_spawn_at(c.x + cos(a) * r, c.y + sin(a) * r)

func _spawn_sapling_near_player() -> void:
	var player = GameManager.player
	if player and randf() < 0.7:
		var a := randf() * TAU
		var r := randf_range(12.0, 38.0)
		_spawn_at(player.global_position.x + cos(a) * r, player.global_position.z + sin(a) * r)
	else:
		_spawn_sapling_village()

func _spawn_at(wx: float, wz: float) -> void:
	var h: float = _noise.get_height(wx, wz)
	if h < 1.6 or h > 12.0:
		return
	if _noise.settlement_mask(wx, wz) > 0.05:
		return
	var s := GrowingTree.new()
	var moisture := _noise.get_moisture(wx, wz)
	var temperature := _noise.get_temperature(wx, wz)
	if h > 9.0 and temperature < -0.1:
		s.species = "pine" if randf() < 0.72 else "redwood"
	elif moisture > 0.28:
		s.species = ["willow", "jungle", "broadleaf"][randi_range(0, 2)]
	elif moisture < -0.2:
		s.species = "baobab" if randf() < 0.3 else "cherry"
	else:
		s.species = ["broadleaf", "cherry", "pine", "willow"][randi_range(0, 3)]
	if randf() < 0.025:
		s.species = "redwood" if moisture > -0.1 else "baobab"
	s.position = Vector3(wx, h, wz)
	s.maturity = randf_range(0.05, 0.3)
	get_parent().add_child(s)
