extends RefCounted

## Pure regional ecology kernel. This object is called only by a worker thread.
## It receives a deep-copied snapshot and returns a new snapshot; it never touches
## Nodes, SceneTree, Resources, rendering, physics or shared mutable state.

func simulate(payload: Dictionary) -> Dictionary:
    var regions: Dictionary = payload.get("regions", {})
    var defs: Dictionary = payload.get("species_defs", {})
    var tick := int(payload.get("tick", 0))
    var season := str(payload.get("season", ""))
    var region_ids: Array = regions.keys()
    # First pass: births, maturation, natural mortality, senescence and density pressure.
    for region_id in region_ids:
        var region: Dictionary = regions[region_id]
        var species_state: Dictionary = region.get("species", {})
        var temperature := float(region.get("temperature_c", 16.0))
        var moisture := float(region.get("moisture", 0.5))
        for species_id in species_state.keys():
            var pop: Dictionary = species_state[species_id]
            var def: Dictionary = defs.get(species_id, {})
            var adults := maxf(0.0, float(pop.get("adults", 0.0)))
            var juveniles := maxf(0.0, float(pop.get("juveniles", 0.0)))
            var capacity := maxf(1.0, float(pop.get("carrying_capacity", def.get("cap", 1.0))))
            var total := adults + juveniles
            var max_age := maxf(1.0, float(def.get("max_age", 10.0)))
            var age := clampf(float(pop.get("mean_age", max_age * 0.35)), 0.0, max_age)
            var old_age_factor := clampf((age / max_age - 0.68) / 0.32, 0.0, 1.0)
            var thermal_fit := clampf(1.0 - absf(temperature - 16.0) / 52.0, 0.18, 1.0)
            var moisture_fit := clampf(0.62 + moisture * 0.42, 0.2, 1.15)
            var overcrowding := maxf(0.0, total / capacity - 0.82)
            var breeding_window := 1.0 if season in ["spring", "summer", "Spring", "Summer"] else 0.58
            var birth_rate := float(def.get("birth", 0.08))
            var births := adults * birth_rate * breeding_window * thermal_fit * moisture_fit * maxf(0.0, 1.0 - total / (capacity * 1.18))
            var maturation := juveniles * 0.18
            var hunting := maxf(0.0, float(pop.get("hunting_pressure", 0.0)))
            var natural_deaths := adults * (0.008 + old_age_factor * 0.045 + overcrowding * 0.035) + juveniles * (0.018 + overcrowding * 0.025)
            var hunted := minf(adults * 0.22, hunting * 0.16)
            var new_adults := maxf(0.0, adults + maturation - natural_deaths - hunted)
            var new_juveniles := maxf(0.0, juveniles + births - maturation - juveniles * 0.012)
            var next_age := clampf(age + 0.015 + maturation / maxf(1.0, adults) * 0.025, 0.0, max_age)
            # Cohorts grow stronger as they mature. Selection/adaptation is slow and bounded.
            var base_strength := float(def.get("strength", 1.0))
            var maturity := clampf(next_age / (max_age * 0.55), 0.18, 1.0)
            var fitness := clampf(thermal_fit * moisture_fit, 0.45, 1.12)
            var old_strength := float(pop.get("mean_strength", base_strength * 0.5))
            var adaptation := 1.0 + minf(0.12, float(pop.get("generation", 1)) * 0.0015)
            var strength_target := base_strength * maturity * fitness * adaptation
            pop["adults"] = minf(new_adults, capacity * 1.65)
            pop["juveniles"] = minf(new_juveniles, capacity * 0.85)
            pop["mean_age"] = next_age
            pop["mean_strength"] = lerpf(old_strength, strength_target, 0.035)
            pop["generation"] = int(pop.get("generation", 1)) + (1 if births >= 1.0 else 0)
            pop["hunting_pressure"] = hunting * 0.72
            pop["carrying_capacity"] = float(def.get("cap", capacity)) * thermal_fit * moisture_fit
            species_state[species_id] = pop
        var wildlife_pressure := 0.0
        var pressure_species := 0
        for species_id in species_state.keys():
            var pressure_pop: Dictionary = species_state[species_id]
            var pressure_cap := maxf(1.0, float(pressure_pop.get("carrying_capacity", 1.0)))
            var pressure_total := float(pressure_pop.get("adults", 0.0)) + float(pressure_pop.get("juveniles", 0.0))
            wildlife_pressure += maxf(0.0, pressure_total / pressure_cap - 0.82)
            pressure_species += 1
        region["wildlife_pressure"] = wildlife_pressure / maxf(1.0, float(pressure_species))
        var predator_pressure := 0.0
        var predator_biomass := 0.0
        var prey_biomass := 0.0
        for species_id in species_state.keys():
            var ecology_def: Dictionary = defs.get(species_id, {})
            var cohort: Dictionary = species_state[species_id]
            var count := float(cohort.get("adults", 0.0)) + float(cohort.get("juveniles", 0.0))
            if bool(ecology_def.get("predator", false)):
                predator_biomass += count * float(ecology_def.get("strength", 1.0))
            elif str(ecology_def.get("group", "")) != "":
                prey_biomass += count
        predator_pressure = clampf(predator_biomass / maxf(8.0, prey_biomass * 0.22 + 8.0), 0.0, 1.5)
        region["predator_pressure"] = predator_pressure
        region["predator_biomass"] = predator_biomass
        region["prey_biomass"] = prey_biomass
        region["species"] = species_state
        region["last_simulated_tick"] = tick
        region["migration_season"] = str(region.get("migration_season", ""))
        regions[region_id] = region
    # Second pass: predators consume prey. This is regional, so unloaded food webs continue.
    for region_id in region_ids:
        var region: Dictionary = regions[region_id]
        var species_state: Dictionary = region.get("species", {})
        for predator_id in species_state.keys():
            var predator_def: Dictionary = defs.get(predator_id, {})
            var prey_id := str(predator_def.get("prey", ""))
            if prey_id.is_empty() or not species_state.has(prey_id):
                continue
            var predator_count := float(species_state[predator_id].get("adults", 0.0))
            var prey: Dictionary = species_state[prey_id]
            var prey_loss := minf(float(prey.get("adults", 0.0)) * 0.08, predator_count * 0.045)
            prey["adults"] = maxf(0.0, float(prey.get("adults", 0.0)) - prey_loss)
            species_state[prey_id] = prey
        region["species"] = species_state
        regions[region_id] = region
    # Seasonal migration moves whole cohorts between compatible biome regions.
    for origin_id in region_ids:
        var origin: Dictionary = regions[origin_id]
        if season == str(origin.get("migration_season", "")):
            continue
        var origin_species: Dictionary = origin.get("species", {})
        var ox := float(origin.get("center_x", 0.0))
        var oz := float(origin.get("center_z", 0.0))
        for species_id in origin_species.keys():
            var best_id := ""
            var best_score := -INF
            for candidate_id in region_ids:
                if candidate_id == origin_id:
                    continue
                var candidate: Dictionary = regions[candidate_id]
                var candidate_species: Dictionary = candidate.get("species", {})
                if not candidate_species.has(species_id):
                    continue
                var distance := Vector2(ox, oz).distance_to(Vector2(float(candidate.get("center_x", 0.0)), float(candidate.get("center_z", 0.0))))
                if distance > 850.0:
                    continue
                var candidate_pop: Dictionary = candidate_species[species_id]
                var cap := maxf(1.0, float(candidate_pop.get("carrying_capacity", 1.0)))
                var occupancy := (float(candidate_pop.get("adults", 0.0)) + float(candidate_pop.get("juveniles", 0.0))) / cap
                var suitability := 1.0 - clampf(absf(float(candidate.get("temperature_c", 16.0)) - 16.0) / 55.0, 0.0, 1.0)
                var score := suitability * 0.55 + clampf(float(candidate.get("moisture", 0.5)), 0.0, 1.0) * 0.2 + (1.0 - clampf(occupancy, 0.0, 1.5) / 1.5) * 0.25 - distance / 4000.0
                if score > best_score:
                    best_score = score
                    best_id = str(candidate_id)
            if not best_id.is_empty():
                var source: Dictionary = origin_species[species_id]
                var source_capacity := maxf(1.0, float(source.get("carrying_capacity", 1.0)))
                var source_occupancy := (float(source.get("adults", 0.0)) + float(source.get("juveniles", 0.0))) / source_capacity
                var migration_fraction := 0.012 + clampf((source_occupancy - 0.75) * 0.055, 0.0, 0.035)
                var migrants := float(source.get("adults", 0.0)) * migration_fraction
                source["adults"] = maxf(0.0, float(source.get("adults", 0.0)) - migrants)
                origin_species[species_id] = source
                var dest_region: Dictionary = regions[best_id]
                var dest_species: Dictionary = dest_region.get("species", {})
                var dest: Dictionary = dest_species[species_id]
                dest["adults"] = float(dest.get("adults", 0.0)) + migrants
                dest_species[species_id] = dest
                dest_region["species"] = dest_species
                regions[best_id] = dest_region
        origin["species"] = origin_species
        origin["migration_season"] = season
        regions[origin_id] = origin
    return {"regions": regions, "tick": tick}

