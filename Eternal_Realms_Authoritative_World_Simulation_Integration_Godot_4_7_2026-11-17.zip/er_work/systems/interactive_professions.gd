# Hands-on cooking and experimentation. Recipes are learned from successful experiments,
# not selected from a recipe button list.
extends Node

var active := false
var phase := ""
var player: Node3D
var ingredients: Array[String] = []
var available_ingredients: Array[String] = ["fish_trout", "fish_bass", "seaweed", "moonpetal", "wild_berries"]
var action_score := 0.0
var action_count := 0
var phase_clock := 0.0
var heat := 0.5
var prep := 0.0
var _ui: CanvasLayer
var _status: Label
var _meter: ProgressBar
var _known: Array[String] = []
var _forge_recipe_id := ""
var _forge_skill: SkillSystem
var _forge_strikes := 0
var _forge_good_strikes := 0
var _last_alchemy_key := 0
var _rng := RandomNumberGenerator.new()

const DISCOVERIES := {
	"fish_trout+moonpetal": {"id":"cooked_trout", "name":"Moonpetal Trout"},
	"fish_bass+seaweed": {"id":"cooked_bass", "name":"Seaweed Bass"},
	"fish_bass+fish_trout+seaweed": {"id":"fish_stew", "name":"Riverbank Fish Stew"},
	"moonpetal+wild_berries": {"id":"moonberry_preserve", "name":"Moonberry Preserve"}
}

func _ready() -> void:
	add_to_group("interactive_professions")
	_rng.randomize()
	var saved: Variant = PlayerData.stats.get("discovered_recipes", [])
	if saved is Array:
		_known.assign(saved)

func begin_cooking(actor: Node3D) -> void:
	if active:
		return
	player = actor
	ingredients.clear()
	var found := false
	for id in available_ingredients:
		if PlayerData.count_item(id) > 0:
			found = true
	if not found:
		EventBus.toast.emit("Bring ingredients to the fire: fish, herbs, seaweed or berries.", "warning")
		return
	active = true
	GameManager.push_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	phase = "select"
	phase_clock = 0.0
	prep = 0.0
	heat = 0.45
	action_score = 0.0
	action_count = 0
	_make_ui()
	_refresh("Choose up to three ingredients. Press 1–5 to add/remove: trout, bass, seaweed, moonpetal, berries. ENTER begins preparation.")

func _begin_preparation() -> void:
	if ingredients.is_empty():
		_refresh("Choose at least one ingredient with keys 1–5, then press ENTER.")
		return
	for id in ingredients:
		if not PlayerData.remove_item(id, 1):
			_finish(false, "You no longer have the selected ingredients.")
			return
	phase = "prepare"
	phase_clock = 0.0
	_refresh("Preparing " + _ingredient_names() + ".\nAlternate A / D strokes to chop and prepare. Build quality, then begin cooking.")

func _input(event: InputEvent) -> void:
	if not active or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE:
		_finish(false, "You abandon the cooking activity.")
	elif phase == "select":
		if event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER:
			_begin_preparation()
		elif event.keycode >= KEY_1 and event.keycode <= KEY_5:
			var idx: int = int(event.keycode) - KEY_1
			var id: String = available_ingredients[idx]
			if ingredients.has(id):
				ingredients.erase(id)
			elif ingredients.size() < 3 and PlayerData.count_item(id) > ingredients.count(id):
				ingredients.append(id)
			_refresh("Selected: " + _ingredient_names() + "\n1 Trout | 2 Bass | 3 Seaweed | 4 Moonpetal | 5 Berries. ENTER to prepare.")
	elif phase == "alchemy":
		if event.keycode == KEY_Q or event.keycode == KEY_E:
			var current_key: int = int(event.keycode)
			_forge_strikes += 1
			if _last_alchemy_key == 0 or current_key != _last_alchemy_key:
				_forge_good_strikes += 1
				action_score += 0.25
			else:
				action_score -= 0.1
			_last_alchemy_key = current_key
			if _forge_strikes >= 5:
				_finish_forging()
			else:
				_refresh("Alternate Q / E to stir and stabilize the mixture. Correct alternations: %d. Step %d/5." % [_forge_good_strikes, _forge_strikes + 1])
	elif phase == "forge":
		if event.keycode == KEY_SPACE:
			var timing := absf(sin(phase_clock * 1.7))
			_forge_strikes += 1
			if timing >= 0.34 and timing <= 0.68:
				_forge_good_strikes += 1
				action_score += 0.3
			else:
				action_score -= 0.12
			if _forge_strikes >= 3:
				_finish_forging()
			else:
				_refresh("Strike %d/3. Aim for the bright timing window. Good strikes: %d. SPACE to hammer." % [_forge_strikes + 1, _forge_good_strikes])
	elif phase == "prepare":
		if event.keycode == KEY_A or event.keycode == KEY_D:
			prep = minf(1.0, prep + (0.16 if action_count == 0 or (action_count % 2 == 0) == (event.keycode == KEY_A) else 0.07))
			action_count += 1
			_refresh("Prepare the ingredients with alternating A / D strokes.\nThen press SPACE to start cooking.")
			if prep >= 0.8:
				phase = "cook"
				phase_clock = 0.0
				_refresh("Cooking! Use W to stir and E to adjust heat. Keep heat between 0.35 and 0.72.\nSPACE finishes when the food is ready.")
	elif phase == "cook":
		if event.keycode == KEY_W:
			action_score += 0.12
			action_count += 1
		elif event.keycode == KEY_E:
			heat = clampf(heat + (0.12 if heat < 0.52 else -0.12), 0.0, 1.0)
			action_score += 0.06
			action_count += 1
		elif event.keycode == KEY_SPACE:
			_finish_cooking()
		_refresh("Stir with W. Adjust heat with E. Heat: %.0f%%\nFinish with SPACE when the timer is nearly complete." % (heat * 100.0))

func _process(delta: float) -> void:
	if not active:
		return
	phase_clock += delta
	if phase == "forge" or phase == "alchemy":
		if _meter:
			_meter.value = absf(sin(phase_clock * 1.7)) * 100.0
	elif phase == "cook":
		var heat_quality := 1.0 - absf(heat - 0.54) * 1.7
		action_score += maxf(0.0, heat_quality) * delta * 0.035
		if _meter:
			_meter.value = clampf(phase_clock / 12.0 * 100.0, 0.0, 100.0)
		if phase_clock >= 14.0:
			_finish_cooking()


func begin_forging(recipe_id: String, skill_system: SkillSystem) -> bool:
	if active or not RecipeDB.RECIPES.has(recipe_id) or skill_system == null:
		return false
	var rec: Dictionary = RecipeDB.RECIPES[recipe_id]
	var skill_id := str(rec["skill"])
	if float(skill_system.get_value(skill_id)) < float(rec["min"]):
		EventBus.toast.emit("Your skill is not high enough for this work.", "warning")
		return false
	for item in rec["inputs"]:
		if PlayerData.count_item(str(item)) < int(rec["inputs"][item]):
			EventBus.toast.emit("Missing " + str(item).replace("_", " "), "warning")
			return false
	for item in rec["inputs"]:
		PlayerData.remove_item(str(item), int(rec["inputs"][item]))
	active = true
	GameManager.push_ui_lock()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	phase = "forge" if str(rec["station"]) == "forge" else "alchemy"
	phase_clock = 0.0
	_forge_recipe_id = recipe_id
	_forge_skill = skill_system
	_forge_strikes = 0
	_forge_good_strikes = 0
	_last_alchemy_key = 0
	action_score = 0.0
	_make_ui()
	if phase == "forge":
		_refresh("HOT FORGE\nThree hammer strikes. Watch the moving heat/timing meter and press SPACE when it enters the bright zone. Accurate strikes improve quality.")
	else:
		_refresh("ALCHEMY MIXING\nAlternate Q / E to stir and stabilize the mixture. Repeating the same direction destabilizes the brew.")
	return true

func _finish_forging() -> void:
	var rec: Dictionary = RecipeDB.RECIPES[_forge_recipe_id]
	var skill_id := str(rec["skill"])
	var success := _forge_good_strikes >= 2
	if success:
		var skill_value := float(_forge_skill.get_value(skill_id))
		var grade := 0
		if ItemDB.is_gear(str(rec["output"])):
			grade = ItemDB.roll_grade(skill_value + PlayerData.title_bonus("grade") + float(_forge_good_strikes - 2) * 1.2, _rng)
		if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
			MMORPGNetwork.request_authoritative_craft(_forge_recipe_id)
		else:
			PlayerData.add_item(str(rec["output"]), int(rec["count"]), grade)
			PlayerData.notify("craft", str(rec["output"]), int(rec["count"]))
		PlayerData.stats["crafted"] = int(PlayerData.stats.get("crafted", 0)) + 1
		_forge_skill.train(skill_id, float(rec["gain"]))
		EventBus.toast.emit("Work completed: " + str(rec["name"]), "success")
	else:
		_forge_skill.train(skill_id, float(rec["gain"]) * 0.35)
		EventBus.toast.emit("The work is misshapen. Your timing needs practice; some materials were lost.", "warning")
	_finish(success, "Forge work finished.")

func _finish_cooking() -> void:
	var key_parts := ingredients.duplicate()
	key_parts.sort()
	var recipe_key := "+".join(key_parts)
	var discovery: Dictionary = DISCOVERIES.get(recipe_key, {})
	var quality := clampf(prep * 0.45 + minf(action_score, 0.45) + (1.0 - absf(heat - 0.54)) * 0.10, 0.0, 1.0)
	if discovery.is_empty():
		if randf() < quality * 0.45:
			EventBus.toast.emit("Interesting combination. You record a promising cooking experiment.", "info")
		else:
			EventBus.toast.emit("The experiment is edible, but no recipe was discovered.", "warning")
		PlayerData.stats["cooking_experiments"] = int(PlayerData.stats.get("cooking_experiments", 0)) + 1
		if player and player.get("skills"):
			player.skills.train("cooking", 0.2 + quality * 0.35)
		_finish(false, "Experiment complete.")
		return
	var recipe_id := str(discovery["id"])
	if not ItemDB.has_item(recipe_id):
		_finish(false, "The recipe result is not registered in the item database.")
		return
	PlayerData.add_item(recipe_id, 1)
	if not _known.has(recipe_id):
		_known.append(recipe_id)
		PlayerData.stats["discovered_recipes"] = _known.duplicate()
		EventBus.toast.emit("Recipe discovered: " + str(discovery["name"]), "success")
	else:
		EventBus.toast.emit("Cooked " + str(discovery["name"]) + " (quality %.0f%%)." % (quality * 100.0), "success")
	if player and player.get("skills"):
		player.skills.train("cooking", 0.35 + quality * 0.65)
	PlayerData.stats["crafted"] = int(PlayerData.stats.get("crafted", 0)) + 1
	_finish(true, "Meal prepared.")

func _ingredient_names() -> String:
	var names: Array[String] = []
	for id in ingredients:
		names.append(id.replace("_", " "))
	return ", ".join(names)

func _make_ui() -> void:
	_ui = CanvasLayer.new()
	_ui.layer = 30
	add_child(_ui)
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	panel.position = Vector2(-260, -190)
	panel.size = Vector2(520, 170)
	_ui.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	panel.add_child(box)
	_status = Label.new()
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(490, 90)
	box.add_child(_status)
	_meter = ProgressBar.new()
	_meter.max_value = 100
	box.add_child(_meter)
	var hint := Label.new()
	hint.text = "ESC abandons the activity"
	hint.add_theme_font_size_override("font_size", 12)
	box.add_child(hint)

func _refresh(message: String) -> void:
	if _status:
		_status.text = "FIELD COOKING — " + phase.to_upper() + "\n" + message

func _finish(_success: bool, message: String) -> void:
	active = false
	GameManager.pop_ui_lock()
	if is_instance_valid(_ui):
		_ui.queue_free()
	_ui = null
	EventBus.toast.emit(message, "info")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
