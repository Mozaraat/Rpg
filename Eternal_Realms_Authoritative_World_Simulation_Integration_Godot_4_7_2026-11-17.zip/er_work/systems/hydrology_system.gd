extends Node

## Regional water budget with downhill routing, visible channels, flood surfaces,
## settlement water access and slow sediment accounting. Values are SI/game metres.
signal water_conditions_changed(position: Vector3, runoff_mm_h: float, flood_risk: float)
signal river_flow_changed(position: Vector3, discharge_m3_s: float)
signal settlement_water_changed(settlement_id: String, available_litres: float, flood_risk: float)

const CELL_SIZE_M: float = 64.0
const CELL_AREA_M2: float = CELL_SIZE_M * CELL_SIZE_M
const DEFAULT_SOIL_INFILTRATION_MM_H: float = 18.0
const GROUNDWATER_RECHARGE_FRACTION: float = 0.22
const MAX_ACTIVE_RADIUS: int = 5
const WORLD_DRAINAGE_MIN: Vector2i = Vector2i(-14, -14)
const WORLD_DRAINAGE_MAX: Vector2i = Vector2i(14, 14)
const DRAINAGE_CACHE_VERSION: int = 2

@export_range(0.1, 30.0, 0.1) var simulation_interval: float = 3.0
@export_range(0.001, 100.0, 0.001) var river_flow_threshold_m3_s: float = 0.015
@export_range(0.0, 1.0, 0.01) var erosion_rate: float = 0.08
@export var render_water: bool = true

var _cells: Dictionary = {}
var _water_visuals: Dictionary = {}
var _timer: float = 0.0
var _save_timer: float = 0.0
var _visual_root: Node3D
var _terrain_dirty_chunks: Dictionary = {}
var _network_sync_timer: float = 0.0
var _erosion_restore_pending: Array[Dictionary] = []
var _global_downstream: Dictionary = {}
var _global_upstream_area: Dictionary = {}
var _global_drainage_order: Array[Vector2i] = []
var _global_drainage_rank: Dictionary = {}
var _global_outlets: Dictionary = {}
var _global_terrain: TerrainNoise
var _drainage_cache_path: String = ""
var _central_backend_revision: int = 0
var _central_save_pending: bool = false

func _ready() -> void:
	add_to_group("hydrology_system")
	_visual_root = Node3D.new()
	_visual_root.name = "HydrologyVisuals"
	add_child(_visual_root)
	_global_terrain = TerrainNoise.new(GameManager.world_seed)
	_drainage_cache_path = "user://world_drainage_%d.json" % GameManager.world_seed
	_load_state()
	_load_or_generate_global_drainage()
	call_deferred("_restore_central_hydrology")

func _process(delta: float) -> void:
	if not _erosion_restore_pending.is_empty():
		var terrain_manager := get_tree().get_first_node_in_group("chunk_manager")
		if terrain_manager != null and terrain_manager.get("noise") != null:
			for saved_erosion in _erosion_restore_pending:
				var saved_pos: Vector3 = saved_erosion.position
				terrain_manager.get("noise").apply_erosion(saved_pos.x, saved_pos.z, saved_erosion.delta)
				_mark_terrain_chunks_dirty(saved_pos)
			_erosion_restore_pending.clear()
	_timer += delta
	if _timer < simulation_interval:
		return
	var elapsed := _timer
	_timer = 0.0
	var player = GameManager.player
	if player == null or not is_instance_valid(player):
		return
	if MMORPGNetwork.is_authority():
		_simulate_nearby(player.global_position, elapsed)
		_network_sync_timer += elapsed
		if MMORPGNetwork.is_online() and _network_sync_timer >= 3.0:
			_network_sync_timer = 0.0
			rpc("_receive_network_cells", _build_network_snapshot(player.global_position))
	else:
		return
	_save_timer += elapsed
	if _save_timer >= 30.0:
		_save_timer = 0.0
		_flush_terrain_rebuilds()
		_save_state()

func _cell_key(position: Vector3) -> Vector2i:
	return Vector2i(floori(position.x / CELL_SIZE_M), floori(position.z / CELL_SIZE_M))

func _cell_center(key: Vector2i) -> Vector3:
	return Vector3((float(key.x) + 0.5) * CELL_SIZE_M, 0.0, (float(key.y) + 0.5) * CELL_SIZE_M)

func _terrain_height(position: Vector3) -> float:
	var chunk_manager := get_tree().get_first_node_in_group("chunk_manager")
	if chunk_manager != null and chunk_manager.has_method("get_height"):
		return float(chunk_manager.get_height(position.x, position.z))
	if chunk_manager != null and chunk_manager.get("noise") != null:
		return float(chunk_manager.get("noise").get_height(position.x, position.z))
	return position.y

func _get_cell(position: Vector3) -> Dictionary:
	var key := _cell_key(position)
	if not _cells.has(key):
		var baseline_humidity := ClimateSystem.humidity_at(position) if is_instance_valid(ClimateSystem) else 0.5
		_cells[key] = {"soil_saturation": clampf(0.12 + baseline_humidity * 0.28, 0.0, 0.55), "groundwater_mm": 120.0, "snowpack_mm": 0.0, "surface_water_mm": 0.0, "last_runoff_mm_h": 0.0, "flood_risk": 0.0, "erosion_index": 0.0, "sediment_kg": 0.0, "discharge_m3_s": 0.0, "flow_direction": Vector3.ZERO, "rainfall_mm_h": 0.0, "water_depth_m": 0.0, "velocity_x": 0.0, "velocity_z": 0.0, "momentum_x": 0.0, "momentum_z": 0.0, "terrain_height_delta_m": 0.0}
	return _cells[key]

func _simulate_nearby(center: Vector3, delta_seconds: float) -> void:
	var origin := _cell_key(center)
	var keys: Array[Vector2i] = []
	for z in range(-MAX_ACTIVE_RADIUS, MAX_ACTIVE_RADIUS + 1):
		for x in range(-MAX_ACTIVE_RADIUS, MAX_ACTIVE_RADIUS + 1):
			var key := origin + Vector2i(x, z)
			keys.append(key)
			var cell_pos := _cell_center(key)
			update_cell(cell_pos, delta_seconds)
	# Conservative finite-volume shallow-water step. Shared face fluxes are
	# applied with equal and opposite signs, so water is redistributed rather
	# than independently invented or removed in each cell.
	_solve_shallow_water(keys, delta_seconds)
	# Route high-to-low across the active window and retain outflow in edge cells.
	# The downstream pointer is saved, so a river does not disappear at a chunk boundary.
	keys.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return int(_global_drainage_rank.get(a, 0)) < int(_global_drainage_rank.get(b, 0)))
	var routed: Dictionary = {}
	var routed_area: Dictionary = {}
	var discharges: Dictionary = {}
	for key in keys:
		var cell: Dictionary = _cells[key]
		var routed_discharge := float(cell.get("local_runoff_m3_s", 0.0)) + float(cell.get("incoming_runoff_m3_s", 0.0)) + float(routed.get(key, 0.0))
		cell["incoming_runoff_m3_s"] = 0.0
		discharges[key] = routed_discharge
		var target := get_global_downstream(key)
		cell["downstream_x"] = target.x
		cell["downstream_z"] = target.y
		cell["upstream_area_m2"] = get_global_upstream_area(_cell_center(key))
		cell["flow_direction"] = (_cell_center(target) - _cell_center(key)).normalized() if target != key else Vector3.ZERO
		_cells[key] = cell
		if target != key:
			if keys.has(target):
				routed[target] = float(routed.get(target, 0.0)) + routed_discharge
				routed_area[target] = float(routed_area.get(target, 0.0)) + float(cell.upstream_area_m2)
			else:
				var target_cell := _get_cell(_cell_center(target))
				target_cell["incoming_runoff_m3_s"] = float(target_cell.get("incoming_runoff_m3_s", 0.0)) + routed_discharge
				_cells[target] = target_cell

	for key in keys:
		var cell: Dictionary = _cells[key]
		var discharge := float(discharges.get(key, 0.0))
		var catchment_area := float(cell.get("upstream_area_m2", CELL_AREA_M2))
		var rainfall_rate := float(cell.get("rainfall_mm_h", 0.0))
		var local_rain_volume := rainfall_rate / 1000.0 / 3600.0 * CELL_AREA_M2
		var local_runoff_fraction := clampf(float(cell.get("local_runoff_m3_s", 0.0)) / maxf(local_rain_volume, 0.000001), 0.0, 1.0)
		var catchment_runoff := rainfall_rate / 1000.0 / 3600.0 * catchment_area * local_runoff_fraction
		var spring_baseflow := maxf(0.0, float(cell.get("groundwater_mm", 0.0)) - 180.0) * CELL_AREA_M2 * 0.00000001
		discharge = maxf(discharge, catchment_runoff + spring_baseflow)
		cell.discharge_m3_s = discharge
		var pos := _cell_center(key)
		var low_neighbor := get_global_downstream(key)
		var valley_factor := clampf((_terrain_height(pos) - _terrain_height(_cell_center(low_neighbor))) / 4.0, 0.0, 1.0)
		var flood_storage_mm := 22.0 + (1.0 - valley_factor) * 65.0
		cell.flood_risk = clampf(float(cell.surface_water_mm) / flood_storage_mm + discharge / 14.0, 0.0, 1.0)
		_cells[key] = cell
		if discharge >= river_flow_threshold_m3_s:
			river_flow_changed.emit(pos, discharge)
			_update_water_visual(key, pos, discharge, float(cell.flood_risk))
		elif float(cell.flood_risk) >= 0.22:
			_update_water_visual(key, pos, 0.0, float(cell.flood_risk))
		else:
			_remove_water_visual(key)
	_update_settlement_water()
	var player_state := get_water_state(center)
	water_conditions_changed.emit(center, float(player_state.get("last_runoff_mm_h", 0.0)), float(player_state.get("flood_risk", 0.0)))

## Two-dimensional depth-averaged shallow-water solver on the active grid.
## Conserved state is (h, h*u, h*v); Rusanov face fluxes are shared by both
## neighbours. This captures gravity-driven flow, inertia, wetting/drying and
## terrain forcing. It is a coarse 64 m heightfield model, not wave/turbulence CFD.
func _solve_shallow_water(keys: Array[Vector2i], delta_seconds: float) -> void:
	if keys.is_empty() or delta_seconds <= 0.0:
		return
	var states: Dictionary = {}
	for key in keys:
		var cell: Dictionary = _cells.get(key, {})
		var depth := maxf(0.0, float(cell.get("water_depth_m", 0.0)))
		var velocity_x := float(cell.get("velocity_x", 0.0))
		var velocity_z := float(cell.get("velocity_z", 0.0))
		if depth < 0.0005:
			depth = 0.0
			velocity_x = 0.0
			velocity_z = 0.0
		states[key] = Vector3(depth, depth * velocity_x, depth * velocity_z)
	var remaining := delta_seconds
	var safety_steps := 0
	# Substep the entire elapsed interval instead of silently dropping time when
	# the CFL stability limit is shorter than the world simulation tick.
	while remaining > 0.00001 and safety_steps < 64:
		safety_steps += 1
		var max_wave_speed := 0.5
		for state_value in states.values():
			var state: Vector3 = state_value
			var depth := maxf(0.0, state.x)
			var speed := Vector2(state.y, state.z).length() / maxf(depth, 0.0005)
			max_wave_speed = maxf(max_wave_speed, speed + sqrt(9.81 * depth))
		var dt := minf(remaining, 0.42 * CELL_SIZE_M / max_wave_speed)
		var changes: Dictionary = {}
		for key in keys:
			changes[key] = Vector3.ZERO
		# Each internal face is evaluated once and applies equal/opposite fluxes.
		for key in keys:
			var right := key + Vector2i(1, 0)
			var down := key + Vector2i(0, 1)
			if states.has(right):
				var flux_x := _shallow_water_face_flux(states[key], states[right], true)
				var left_change: Vector3 = changes[key]
				var right_change: Vector3 = changes[right]
				changes[key] = left_change - flux_x * (dt / CELL_SIZE_M)
				changes[right] = right_change + flux_x * (dt / CELL_SIZE_M)
			if states.has(down):
				var flux_z := _shallow_water_face_flux(states[key], states[down], false)
				var upper_change: Vector3 = changes[key]
				var lower_change: Vector3 = changes[down]
				changes[key] = upper_change - flux_z * (dt / CELL_SIZE_M)
				changes[down] = lower_change + flux_z * (dt / CELL_SIZE_M)
		for key in keys:
			var q: Vector3 = states[key]
			q += changes[key]
			var depth := maxf(0.0, q.x)
			if depth > 0.0005:
				var pos := _cell_center(key)
				var bed_l := _terrain_height(pos + Vector3(-CELL_SIZE_M, 0.0, 0.0))
				var bed_r := _terrain_height(pos + Vector3(CELL_SIZE_M, 0.0, 0.0))
				var bed_u := _terrain_height(pos + Vector3(0.0, 0.0, -CELL_SIZE_M))
				var bed_d := _terrain_height(pos + Vector3(0.0, 0.0, CELL_SIZE_M))
				var bed_gradient := Vector2((bed_r - bed_l) / (2.0 * CELL_SIZE_M), (bed_d - bed_u) / (2.0 * CELL_SIZE_M))
				q.y -= 9.81 * depth * bed_gradient.x * dt
				q.z -= 9.81 * depth * bed_gradient.y * dt
				var speed := Vector2(q.y, q.z).length() / maxf(depth, 0.0005)
				var friction := 1.0 / (1.0 + dt * (0.035 + 0.018 * speed))
				q.y *= friction
				q.z *= friction
			states[key] = q
		else:
			states[key] = Vector3.ZERO
		remaining -= dt
	for key in keys:
		var q: Vector3 = states[key]
		var depth := maxf(0.0, q.x)
		var cell: Dictionary = _cells[key]
		if depth > 0.0005:
			var velocity := Vector2(q.y, q.z) / depth
			cell.water_depth_m = depth
			cell.surface_water_mm = depth * 1000.0
			cell.velocity_x = velocity.x
			cell.velocity_z = velocity.y
			cell.momentum_x = q.y * 1000.0
			cell.momentum_z = q.z * 1000.0
		else:
			cell.water_depth_m = 0.0
			cell.surface_water_mm = 0.0
			cell.velocity_x = 0.0
			cell.velocity_z = 0.0
			cell.momentum_x = 0.0
			cell.momentum_z = 0.0
		_cells[key] = cell

func _shallow_water_face_flux(left: Vector3, right: Vector3, x_axis: bool) -> Vector3:
	const GRAVITY: float = 9.81
	var hl := maxf(0.0, left.x)
	var hr := maxf(0.0, right.x)
	var ul := left.y / maxf(hl, 0.0005)
	var vl := left.z / maxf(hl, 0.0005)
	var ur := right.y / maxf(hr, 0.0005)
	var vr := right.z / maxf(hr, 0.0005)
	var cl := sqrt(GRAVITY * hl)
	var cr := sqrt(GRAVITY * hr)
	var fl: Vector3
	var fr: Vector3
	var wave_speed: float
	if x_axis:
		fl = Vector3(left.y, left.y * ul + 0.5 * GRAVITY * hl * hl, left.y * vl)
		fr = Vector3(right.y, right.y * ur + 0.5 * GRAVITY * hr * hr, right.y * vr)
		wave_speed = maxf(absf(ul) + cl, absf(ur) + cr)
	else:
		fl = Vector3(left.z, left.z * ul, left.z * vl + 0.5 * GRAVITY * hl * hl)
		fr = Vector3(right.z, right.z * ur, right.z * vr + 0.5 * GRAVITY * hr * hr)
		wave_speed = maxf(absf(vl) + cl, absf(vr) + cr)
	return (fl + fr) * 0.5 - (right - left) * (0.5 * wave_speed)

func update_cell(position: Vector3, delta_seconds: float) -> Dictionary:
	var key := _cell_key(position)
	var cell := _get_cell(position)
	var terrain_elevation := _terrain_height(position)
	var climate_position := Vector3(position.x, terrain_elevation, position.z)
	var climate := ClimateSystem.sample_at(climate_position)
	var precipitation_mm_h := float(climate.get("rainfall_mm_h", 0.0))
	var weather_node := get_tree().get_first_node_in_group("weather")
	if weather_node != null and weather_node.has_method("precipitation_multiplier"):
		precipitation_mm_h *= float(weather_node.precipitation_multiplier())
	var hours := maxf(0.0, delta_seconds) / 3600.0
	# The authored alpine height scale is compressed for playable traversal, so
	# apply an additional summit cooling term to the snowpack energy balance.
	# This lets high ridges store winter precipitation and release it as spring flow.
	var effective_temperature := float(climate.get("temperature_c", 18.0)) - maxf(0.0, terrain_elevation - 42.0) * 0.55
	var snowpack := maxf(0.0, float(cell.get("snowpack_mm", 0.0)))
	var snowfall_mm_h := precipitation_mm_h if effective_temperature <= 0.0 else 0.0
	var rainfall_mm_h := precipitation_mm_h if effective_temperature > 0.0 else 0.0
	snowpack += snowfall_mm_h * hours
	var snowmelt_mm_h := 0.0
	if effective_temperature > 0.0 and snowpack > 0.0 and hours > 0.0:
		snowmelt_mm_h = minf(snowpack / hours, effective_temperature * 1.8)
		snowpack = maxf(0.0, snowpack - snowmelt_mm_h * hours)
	cell.snowpack_mm = snowpack
	var liquid_input_mm_h := rainfall_mm_h + snowmelt_mm_h
	var slope := slope_degrees_at(position)
	var saturation := float(cell.soil_saturation)
	var runoff_fraction := PhysicalWorldSystem.runoff_fraction(liquid_input_mm_h, DEFAULT_SOIL_INFILTRATION_MM_H, slope, saturation)
	var runoff_mm_h := liquid_input_mm_h * runoff_fraction
	var infiltration_mm_h := liquid_input_mm_h - runoff_mm_h
	var evap_mm_h := maxf(0.0, effective_temperature + 5.0) * 0.012 * (1.0 - float(climate.humidity))
	var previous_surface := float(cell.surface_water_mm)
	cell.surface_water_mm = maxf(0.0, previous_surface + runoff_mm_h * hours - evap_mm_h * hours)
	cell.water_depth_m = float(cell.surface_water_mm) / 1000.0
	# Velocity and momentum are advanced together by _solve_shallow_water().
	# This update only handles local rain/infiltration/evaporation source terms.
	cell.soil_saturation = clampf(saturation + infiltration_mm_h * hours / 120.0 - evap_mm_h * hours / 180.0, 0.0, 1.0)
	cell.groundwater_mm = clampf(float(cell.groundwater_mm) + infiltration_mm_h * hours * GROUNDWATER_RECHARGE_FRACTION - evap_mm_h * hours * 0.03, 0.0, 1000.0)
	var local_runoff_m3_s := runoff_mm_h / 1000.0 / 3600.0 * CELL_AREA_M2
	cell.last_runoff_mm_h = runoff_mm_h
	cell.local_runoff_m3_s = local_runoff_m3_s
	cell.flood_risk = clampf(float(cell.surface_water_mm) / 70.0 + local_runoff_m3_s / 0.12, 0.0, 1.0)
	cell.rainfall_mm_h = liquid_input_mm_h
	cell.snowmelt_mm_h = snowmelt_mm_h
	cell.flow_direction = flow_direction_at(position)
	var excess_mm := maxf(0.0, runoff_mm_h - DEFAULT_SOIL_INFILTRATION_MM_H)
	var erosion_delta := excess_mm * sin(deg_to_rad(slope)) * erosion_rate * hours * 0.0008
	cell.erosion_index = clampf(float(cell.erosion_index) + erosion_delta, 0.0, 1.0)
	cell.sediment_kg = float(cell.sediment_kg) + erosion_delta * CELL_AREA_M2 * 1600.0
	# Erosion is fed back into the same deterministic heightfield used by terrain chunks.
	var chunk_manager := get_tree().get_first_node_in_group("chunk_manager")
	if erosion_delta > 0.000001:
		var height_change := -erosion_delta * 0.08
		cell.terrain_height_delta_m = float(cell.get("terrain_height_delta_m", 0.0)) + height_change
		if chunk_manager != null and chunk_manager.get("noise") != null:
			var shared_noise = chunk_manager.get("noise")
			if shared_noise.has_method("apply_erosion"):
				shared_noise.apply_erosion(position.x, position.z, height_change)
				_mark_terrain_chunks_dirty(position)
	_cells[key] = cell
	return cell.duplicate(true)

## The drainage graph is generated for the complete authored world footprint,
## independent of player position. Cells outside this footprint use deterministic
## downhill routing as an extension until the world bounds are expanded.
func _load_or_generate_global_drainage() -> void:
	if FileAccess.file_exists(_drainage_cache_path):
		var file := FileAccess.open(_drainage_cache_path, FileAccess.READ)
		if file != null:
			var parsed: Variant = JSON.parse_string(file.get_as_text())
			file.close()
			if typeof(parsed) == TYPE_DICTIONARY and int(parsed.get("version", 0)) == DRAINAGE_CACHE_VERSION and int(parsed.get("seed", -1)) == GameManager.world_seed:
				_restore_drainage_graph(parsed)
				return
	_generate_global_drainage()
	_save_global_drainage()

func _generate_global_drainage() -> void:
	_global_downstream.clear()
	_global_upstream_area.clear()
	_global_drainage_order.clear()
	_global_drainage_rank.clear()
	_global_outlets.clear()
	var visited: Dictionary = {}
	var filled_height: Dictionary = {}
	var frontier: Array[Vector2i] = []
	# Priority-flood starts at every sea cell and world-edge outlet. It fills
	# enclosed depressions to their spill elevation, preventing accidental
	# one-cell pits from breaking a watershed into disconnected fragments.
	for z in range(WORLD_DRAINAGE_MIN.y, WORLD_DRAINAGE_MAX.y + 1):
		for x in range(WORLD_DRAINAGE_MIN.x, WORLD_DRAINAGE_MAX.x + 1):
			var key := Vector2i(x, z)
			var height := _global_height(key)
			var is_edge := x == WORLD_DRAINAGE_MIN.x or x == WORLD_DRAINAGE_MAX.x or z == WORLD_DRAINAGE_MIN.y or z == WORLD_DRAINAGE_MAX.y
			if height <= Constants.WATER_LEVEL or is_edge:
				visited[key] = true
				filled_height[key] = height
				_global_downstream[key] = key
				_global_upstream_area[key] = CELL_AREA_M2
				_global_outlets[key] = {"height_m": height, "kind": "ocean" if height <= Constants.WATER_LEVEL else "world_edge"}
				frontier.append(key)
	# Expand from outlets toward higher ground. Each unvisited cell drains to the
	# already-visited neighbour that gives it the lowest filled spill elevation.
	while not frontier.is_empty():
		var best_index := 0
		var best_fill := INF
		for i in range(frontier.size()):
			var candidate_key: Vector2i = frontier[i]
			var candidate_fill := float(filled_height.get(candidate_key, INF))
			if candidate_fill < best_fill:
				best_fill = candidate_fill
				best_index = i
		var current: Vector2i = frontier[best_index]
		frontier.remove_at(best_index)
		for offset in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1), Vector2i(1,1), Vector2i(-1,-1), Vector2i(1,-1), Vector2i(-1,1)]:
			var neighbour := current + offset
			if neighbour.x < WORLD_DRAINAGE_MIN.x or neighbour.x > WORLD_DRAINAGE_MAX.x or neighbour.y < WORLD_DRAINAGE_MIN.y or neighbour.y > WORLD_DRAINAGE_MAX.y or visited.has(neighbour):
				continue
			visited[neighbour] = true
			var raw_height := _global_height(neighbour)
			filled_height[neighbour] = maxf(raw_height, best_fill + 0.001)
			_global_downstream[neighbour] = current
			_global_upstream_area[neighbour] = CELL_AREA_M2
			frontier.append(neighbour)
	# Accumulate contributing area from headwaters toward the outlets.
	var ordered_keys: Array[Vector2i] = []
	for key in _global_downstream.keys():
		ordered_keys.append(key)
	ordered_keys.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return float(filled_height.get(a, _global_height(a))) > float(filled_height.get(b, _global_height(b))))
	for key in ordered_keys:
		_global_drainage_rank[key] = _global_drainage_order.size()
		_global_drainage_order.append(key)
		var target: Vector2i = _global_downstream.get(key, key)
		if target != key:
			_global_upstream_area[target] = float(_global_upstream_area.get(target, CELL_AREA_M2)) + float(_global_upstream_area.get(key, CELL_AREA_M2))

func _global_height(key: Vector2i) -> float:
	var center := _cell_center(key)
	if _global_terrain != null:
		return _global_terrain.get_height(center.x, center.z)
	return _terrain_height(center)

func get_global_downstream(key: Vector2i) -> Vector2i:
	if _global_downstream.has(key):
		return _global_downstream[key]
	return _lowest_neighbour(key)

func get_global_upstream_area(position: Vector3) -> float:
	var key := _cell_key(position)
	if _global_upstream_area.has(key):
		return float(_global_upstream_area[key])
	return estimate_upstream_area(position)

func get_drainage_outlet(position: Vector3) -> Dictionary:
	var key := _cell_key(position)
	var visited: Dictionary = {}
	for _step in range(4096):
		if visited.has(key):
			return {"cell": key, "kind": "closed_basin"}
		visited[key] = true
		var next_key := get_global_downstream(key)
		if next_key == key:
			return {"cell": key, "kind": str(_global_outlets.get(key, {}).get("kind", "local_sink"))}
		key = next_key
	return {"cell": key, "kind": "long_drainage_path"}

func _save_global_drainage() -> void:
	var links: Array = []
	for key in _global_drainage_order:
		var target: Vector2i = _global_downstream[key]
		links.append([key.x, key.y, target.x, target.y, float(_global_upstream_area.get(key, CELL_AREA_M2))])
	var file := FileAccess.open(_drainage_cache_path, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"version": DRAINAGE_CACHE_VERSION, "seed": GameManager.world_seed, "links": links}))
		file.close()

func _restore_drainage_graph(data: Dictionary) -> void:
	_global_downstream.clear()
	_global_upstream_area.clear()
	_global_drainage_order.clear()
	_global_drainage_rank.clear()
	_global_outlets.clear()
	for link in data.get("links", []):
		if not (link is Array) or link.size() < 5:
			continue
		var key := Vector2i(int(link[0]), int(link[1]))
		_global_downstream[key] = Vector2i(int(link[2]), int(link[3]))
		_global_upstream_area[key] = float(link[4])
		_global_drainage_rank[key] = _global_drainage_order.size()
		_global_drainage_order.append(key)
	for key in _global_downstream.keys():
		if _global_downstream[key] == key:
			_global_outlets[key] = {"kind": "ocean" if _global_height(key) <= Constants.WATER_LEVEL else "world_edge"}

func _mark_terrain_chunks_dirty(position: Vector3) -> void:
	var size := int(Constants.CHUNK_SIZE)
	var cx := floori(position.x / size)
	var cz := floori(position.z / size)
	# Include neighbours because the erosion kernel spans cell boundaries.
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			_terrain_dirty_chunks[Vector2i(cx + dx, cz + dz)] = true

func _lowest_neighbour(key: Vector2i) -> Vector2i:
	var best := key
	var best_height := _terrain_height(_cell_center(key))
	for offset in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1), Vector2i(1, 1), Vector2i(-1, -1), Vector2i(1, -1), Vector2i(-1, 1)]:
		var candidate := key + offset
		var h := _terrain_height(_cell_center(candidate))
		if h < best_height - 0.01:
			best_height = h
			best = candidate
	return best

func slope_degrees_at(position: Vector3) -> float:
	var spacing := 8.0
	var left := _terrain_height(position + Vector3(-spacing, 0.0, 0.0))
	var right := _terrain_height(position + Vector3(spacing, 0.0, 0.0))
	var north := _terrain_height(position + Vector3(0.0, 0.0, -spacing))
	var south := _terrain_height(position + Vector3(0.0, 0.0, spacing))
	return rad_to_deg(atan(sqrt(pow((right - left) / (2.0 * spacing), 2.0) + pow((south - north) / (2.0 * spacing), 2.0))))

func flow_direction_at(position: Vector3) -> Vector3:
	var spacing := 8.0
	var dx := _terrain_height(position + Vector3(spacing, 0.0, 0.0)) - _terrain_height(position + Vector3(-spacing, 0.0, 0.0))
	var dz := _terrain_height(position + Vector3(0.0, 0.0, spacing)) - _terrain_height(position + Vector3(0.0, 0.0, -spacing))
	return Vector3(-dx, 0.0, -dz).normalized()

func estimate_upstream_area(position: Vector3) -> float:
	var key := _cell_key(position)
	var visited: Dictionary = {}
	var area := CELL_AREA_M2
	var frontier: Array[Vector2i] = [key]
	# Trace persisted downstream links backwards through known neighbouring cells.
	for step in range(256):
		if frontier.is_empty():
			break
		var current: Vector2i = frontier.pop_back()
		if visited.has(current):
			continue
		visited[current] = true
		for offset in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1), Vector2i(1,1), Vector2i(-1,-1), Vector2i(1,-1), Vector2i(-1,1)]:
			var candidate := current + offset
			if visited.has(candidate) or not _cells.has(candidate):
				continue
			var upstream: Dictionary = _cells[candidate]
			if int(upstream.get("downstream_x", 2147483647)) == current.x and int(upstream.get("downstream_z", 2147483647)) == current.y:
				area += CELL_AREA_M2
				frontier.append(candidate)
	return area

func _flush_terrain_rebuilds() -> void:
	if _terrain_dirty_chunks.is_empty():
		return
	var manager := get_tree().get_first_node_in_group("chunk_manager")
	if manager != null and manager.has_method("refresh_chunks"):
		manager.refresh_chunks(_terrain_dirty_chunks.keys())
	_terrain_dirty_chunks.clear()

func _update_water_visual(key: Vector2i, pos: Vector3, discharge: float, flood_risk: float) -> void:
	if not render_water or _visual_root == null:
		return
	var root: Node3D = _water_visuals.get(key)
	if root == null or not is_instance_valid(root):
		root = Node3D.new()
		root.name = "WaterCell_%d_%d" % [key.x, key.y]
		_visual_root.add_child(root)
		_water_visuals[key] = root
		var water := MeshInstance3D.new()
		water.name = "Surface"
		var mesh := PlaneMesh.new()
		mesh.size = Vector2(CELL_SIZE_M * 0.96, CELL_SIZE_M * 0.96)
		mesh.subdivide_width = 4
		mesh.subdivide_depth = 4
		water.mesh = mesh
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.08, 0.34, 0.48, 0.66)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.roughness = 0.22
		water.material_override = mat
		root.add_child(water)
	var height := _terrain_height(pos)
	var cell: Dictionary = _cells.get(key, {})
	var depth := clampf(float(cell.get("water_depth_m", 0.0)) + flood_risk * 0.08, 0.025, 2.5)
	var contributing_area := float(cell.get("upstream_area_m2", CELL_AREA_M2))
	var flow_width := clampf(1.8 + sqrt(maxf(0.0, contributing_area)) * 0.018 + discharge * 0.6, 2.0, CELL_SIZE_M * 0.7)
	root.position = Vector3(pos.x, height + depth, pos.z)
	var flow_direction: Vector3 = cell.get("flow_direction", Vector3.ZERO)
	root.rotation.y = atan2(flow_direction.x, flow_direction.z)
	root.scale = Vector3(flow_width / (CELL_SIZE_M * 0.96), 1.0, 1.0)
	root.visible = true

func _remove_water_visual(key: Vector2i) -> void:
	if _water_visuals.has(key):
		var node: Node = _water_visuals[key]
		if is_instance_valid(node): node.queue_free()
		_water_visuals.erase(key)

func _update_settlement_water() -> void:
	var growth := get_tree().get_first_node_in_group("settlement_growth")
	if growth == null or typeof(growth.get("settlements")) != TYPE_DICTIONARY:
		return
	var settlements: Dictionary = growth.get("settlements")
	for id in settlements.keys():
		var data: Dictionary = settlements[id]
		var center: Vector2 = data.get("center", Vector2.ZERO)
		var pos := Vector3(center.x, _terrain_height(Vector3(center.x, 0.0, center.y)), center.y)
		update_cell(pos, simulation_interval)
		var cell := _get_cell(pos)
		var population := maxf(1.0, float(data.get("population", 1)))
		var safe_groundwater_l := maxf(0.0, float(cell.groundwater_mm) - 30.0) * CELL_AREA_M2 * 0.35
		var surface_l := maxf(0.0, float(cell.surface_water_mm) - 5.0) * CELL_AREA_M2 * 0.2
		var daily_demand_l := population * 35.0
		var storage_capacity_l := 5000.0 + float(data.get("level", 0)) * 2500.0
		var cistern_l := float(data.get("water_storage_l", 0.0))
		var local_climate := ClimateSystem.sample_at(pos)
		var roof_area_m2 := 80.0 + float(data.get("buildings", 0)) * 35.0
		var captured_l := float(local_climate.get("rainfall_mm_h", 0.0)) * roof_area_m2 / 1000.0 * (simulation_interval / 3600.0) * 0.82
		cistern_l = clampf(cistern_l + captured_l, 0.0, storage_capacity_l)
		var interval_demand_l := daily_demand_l * simulation_interval / 86400.0
		var cistern_use_l := minf(cistern_l, interval_demand_l)
		cistern_l -= cistern_use_l
		var aquifer_use_l := maxf(0.0, interval_demand_l - cistern_use_l)
		cell.groundwater_mm = maxf(0.0, float(cell.groundwater_mm) - aquifer_use_l / maxf(CELL_AREA_M2 * 0.35, 1.0) * 1000.0)
		var available_l := safe_groundwater_l + surface_l * 0.15 + cistern_l
		data["untreated_surface_water_l"] = surface_l
		var reserve_target_l := daily_demand_l * 2.0
		data["water_storage_l"] = cistern_l
		data["water_available_l"] = available_l
		data["water_demand_l_per_day"] = daily_demand_l
		data["water_stress"] = clampf(1.0 - available_l / maxf(reserve_target_l, 1.0), 0.0, 1.0)
		data["water_source"] = "rain_cistern_and_groundwater" if cistern_l > 0.0 else ("groundwater" if safe_groundwater_l > 0.0 else "surface_water")
		_cells[_cell_key(pos)] = cell
		data["flood_risk"] = float(cell.flood_risk)
		settlements[id] = data
		settlement_water_changed.emit(str(id), available_l, float(cell.flood_risk))
	growth.set("settlements", settlements)

func _build_network_snapshot(center: Vector3) -> Array:
	var origin := _cell_key(center)
	var records: Array = []
	for z in range(-MAX_ACTIVE_RADIUS, MAX_ACTIVE_RADIUS + 1):
		for x in range(-MAX_ACTIVE_RADIUS, MAX_ACTIVE_RADIUS + 1):
			var key := origin + Vector2i(x, z)
			if not _cells.has(key):
				continue
			var cell: Dictionary = _cells[key]
			records.append({"x": key.x, "z": key.y, "soil_saturation": float(cell.soil_saturation), "groundwater_mm": float(cell.groundwater_mm), "snowpack_mm": float(cell.get("snowpack_mm", 0.0)), "surface_water_mm": float(cell.surface_water_mm), "flood_risk": float(cell.flood_risk), "discharge_m3_s": float(cell.discharge_m3_s), "erosion_index": float(cell.erosion_index), "sediment_kg": float(cell.sediment_kg), "downstream_x": int(cell.get("downstream_x", 2147483647)), "downstream_z": int(cell.get("downstream_z", 2147483647)), "upstream_area_m2": float(cell.get("upstream_area_m2", CELL_AREA_M2)), "water_depth_m": float(cell.get("water_depth_m", 0.0)), "velocity_x": float(cell.get("velocity_x", 0.0)), "velocity_z": float(cell.get("velocity_z", 0.0)), "momentum_x": float(cell.get("momentum_x", 0.0)), "momentum_z": float(cell.get("momentum_z", 0.0))})
	return records

@rpc("authority", "call_remote", "unreliable_ordered")
func _receive_network_cells(records: Array) -> void:
	if MMORPGNetwork.is_authority():
		return
	for record in records:
		if typeof(record) != TYPE_DICTIONARY:
			continue
		var key := Vector2i(int(record.get("x", 0)), int(record.get("z", 0)))
		var cell := _get_cell(_cell_center(key))
		for field in ["soil_saturation", "groundwater_mm", "snowpack_mm", "surface_water_mm", "flood_risk", "discharge_m3_s", "erosion_index", "sediment_kg", "downstream_x", "downstream_z", "upstream_area_m2", "water_depth_m", "velocity_x", "velocity_z", "momentum_x", "momentum_z"]:
			if record.has(field):
				cell[field] = record[field]
		_cells[key] = cell

func _save_state() -> void:
	var records: Array = []
	for key in _cells.keys():
		var cell: Dictionary = _cells[key]
		records.append({
			"x": key.x, "z": key.y,
			"soil_saturation": float(cell.get("soil_saturation", 0.25)),
			"groundwater_mm": float(cell.get("groundwater_mm", 120.0)),
			"snowpack_mm": float(cell.get("snowpack_mm", 0.0)),
			"surface_water_mm": float(cell.get("surface_water_mm", 0.0)),
			"last_runoff_mm_h": float(cell.get("last_runoff_mm_h", 0.0)),
			"flood_risk": float(cell.get("flood_risk", 0.0)),
			"erosion_index": float(cell.get("erosion_index", 0.0)),
			"sediment_kg": float(cell.get("sediment_kg", 0.0)),
			"discharge_m3_s": float(cell.get("discharge_m3_s", 0.0)),
			"rainfall_mm_h": float(cell.get("rainfall_mm_h", 0.0)),
			"downstream_x": int(cell.get("downstream_x", 2147483647)),
			"downstream_z": int(cell.get("downstream_z", 2147483647)),
			"upstream_area_m2": float(cell.get("upstream_area_m2", CELL_AREA_M2)),
			"incoming_runoff_m3_s": float(cell.get("incoming_runoff_m3_s", 0.0)),
			"terrain_height_delta_m": float(cell.get("terrain_height_delta_m", 0.0)),
			"water_depth_m": float(cell.get("water_depth_m", 0.0)), "velocity_x": float(cell.get("velocity_x", 0.0)), "velocity_z": float(cell.get("velocity_z", 0.0)),
			"momentum_x": float(cell.get("momentum_x", 0.0)), "momentum_z": float(cell.get("momentum_z", 0.0))
		})
	var file := FileAccess.open("user://regional_hydrology.json", FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(records))
		file.close()
	call_deferred("_persist_central_hydrology", records)

func _restore_central_hydrology() -> void:
	if not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured():
		return
	var response: Dictionary = await CentralBackend.server_load_region_entities("world-hydrology")
	if not bool(response.get("ok", false)):
		push_warning("Central hydrology restore unavailable; using local world snapshot: %s" % str(response.get("error", response.get("status", "unknown"))))
		return
	var body: Dictionary = response.get("body", {})
	var rows: Variant = body.get("entities", body.get("items", []))
	if not rows is Array:
		return
	var expected_id := "hydrology_world_%d" % GameManager.world_seed
	for row in rows:
		if not row is Dictionary or str(row.get("entity_id", "")) != expected_id:
			continue
		var state: Variant = row.get("entity_state", {})
		if not state is Dictionary:
			return
		_central_backend_revision = int(row.get("revision", 0))
		var remote_cells: Variant = state.get("cells", [])
		if remote_cells is Array:
			_erosion_restore_pending.clear()
			for record in remote_cells:
				if not record is Dictionary:
					continue
				var key := Vector2i(int(record.get("x", 0)), int(record.get("z", 0)))
				_cells[key] = _cell_from_record(record)
				var erosion_delta := float(record.get("terrain_height_delta_m", 0.0))
				if absf(erosion_delta) > 0.000001:
					_erosion_restore_pending.append({"position": _cell_center(key), "delta": erosion_delta})
		return

func _cell_from_record(record: Dictionary) -> Dictionary:
	return {
		"soil_saturation": float(record.get("soil_saturation", 0.25)), "groundwater_mm": float(record.get("groundwater_mm", 120.0)),
		"snowpack_mm": float(record.get("snowpack_mm", 0.0)), "surface_water_mm": float(record.get("surface_water_mm", 0.0)), "last_runoff_mm_h": float(record.get("last_runoff_mm_h", 0.0)),
		"flood_risk": float(record.get("flood_risk", 0.0)), "erosion_index": float(record.get("erosion_index", 0.0)),
		"sediment_kg": float(record.get("sediment_kg", 0.0)), "discharge_m3_s": float(record.get("discharge_m3_s", 0.0)),
		"rainfall_mm_h": float(record.get("rainfall_mm_h", 0.0)), "local_runoff_m3_s": 0.0, "flow_direction": Vector3.ZERO,
		"downstream_x": int(record.get("downstream_x", 2147483647)), "downstream_z": int(record.get("downstream_z", 2147483647)),
		"upstream_area_m2": float(record.get("upstream_area_m2", CELL_AREA_M2)), "incoming_runoff_m3_s": float(record.get("incoming_runoff_m3_s", 0.0)),
		"terrain_height_delta_m": float(record.get("terrain_height_delta_m", 0.0)),
		"water_depth_m": float(record.get("water_depth_m", float(record.get("surface_water_mm", 0.0)) / 1000.0)),
		"velocity_x": float(record.get("velocity_x", 0.0)), "velocity_z": float(record.get("velocity_z", 0.0)),
		"momentum_x": float(record.get("momentum_x", 0.0)), "momentum_z": float(record.get("momentum_z", 0.0))
	}

func _persist_central_hydrology(records: Array) -> void:
	if _central_save_pending or not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured() or records.is_empty():
		return
	_central_save_pending = true
	var entity_id := "hydrology_world_%d" % GameManager.world_seed
	var snapshot := {"seed": GameManager.world_seed, "cell_size_m": CELL_SIZE_M, "cells": records, "drainage_cache_version": DRAINAGE_CACHE_VERSION}
	var result: Dictionary = await CentralBackend.server_save_world_entity(entity_id, "hydrology", "world-hydrology", _central_backend_revision, snapshot)
	if bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		_central_backend_revision = int(body.get("revision", _central_backend_revision + 1))
	else:
		push_warning("Central hydrology snapshot save failed: %s" % str(result.get("error", result.get("status", "unknown"))))
	_central_save_pending = false

func _load_state() -> void:
	if not FileAccess.file_exists("user://regional_hydrology.json"):
		return
	var file := FileAccess.open("user://regional_hydrology.json", FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_ARRAY:
		return
	for record in parsed:
		if typeof(record) != TYPE_DICTIONARY:
			continue
		var key := Vector2i(int(record.get("x", 0)), int(record.get("z", 0)))
		_cells[key] = _cell_from_record(record)
		var restored_position := _cell_center(key)
		var erosion_delta := float(record.get("terrain_height_delta_m", 0.0))
		if absf(erosion_delta) > 0.000001:
			_erosion_restore_pending.append({"position": restored_position, "delta": erosion_delta})

func get_water_state(position: Vector3) -> Dictionary:
	return _get_cell(position).duplicate(true)

func get_flood_risk(position: Vector3) -> float:
	return float(_get_cell(position).flood_risk)

func get_groundwater_mm(position: Vector3) -> float:
	return float(_get_cell(position).groundwater_mm)

func get_soil_moisture(position: Vector3) -> float:
	return float(_get_cell(position).soil_saturation)

func add_soil_moisture(position: Vector3, amount: float) -> void:
	var cell := _get_cell(position)
	cell.soil_saturation = clampf(float(cell.get("soil_saturation", 0.25)) + maxf(0.0, amount), 0.0, 1.0)
	_cells[_cell_key(position)] = cell

func get_stream_flow_m3_s(position: Vector3) -> float:
	return float(_get_cell(position).get("discharge_m3_s", 0.0))

func get_erosion_index(position: Vector3) -> float:
	return float(_get_cell(position).erosion_index)

func get_sediment_kg(position: Vector3) -> float:
	return float(_get_cell(position).sediment_kg)

func get_settlement_water_report(settlement_id: String) -> Dictionary:
	var growth := get_tree().get_first_node_in_group("settlement_growth")
	if growth == null or typeof(growth.get("settlements")) != TYPE_DICTIONARY:
		return {}
	var settlements: Dictionary = growth.get("settlements")
	return (settlements.get(settlement_id, {}) as Dictionary).duplicate(true)
