# Shared noise + biome logic used by all chunks, vegetation and settlements.
# Real Coder: Single source of truth for terrain data - everything that needs the
# ground height (chunks, NPC placement, buildings, enemy spawns) asks this class.
class_name TerrainNoise
extends RefCounted

# --- Authored places -------------------------------------------------------
# The terrain is gently flattened under each settlement so buildings always sit
# on solid ground instead of floating or sinking (a flat plateau, then a smooth blend).
const START_CENTER: Vector2 = Vector2(0.0, -20.0)

const VILLAGE_CENTER: Vector2 = Vector2(-25.0, -30.0)
const SPIRE_CENTER: Vector2 = Vector2(-250.0, -200.0)
const VILLAGE_HEIGHT: float = 3.4
const SPIRE_HEIGHT: float = 9.5

const SETTLEMENTS: Array = [
	# [center, height, flat radius, blend radius]
	[Vector2(-25.0, -30.0), 3.4, 27.0, 56.0],
	[Vector2(-250.0, -200.0), 9.5, 21.0, 48.0],
]

# Painted dirt / cobble paths: [from, to, half width]. A degenerate segment is a disc.
const PATHS: Array = [
	[Vector2(-25.0, -30.0), Vector2(-25.0, -30.0), 7.6],     # village plaza
	[Vector2(-25.0, -30.0), Vector2(-25.0, -6.0), 2.2],       # south entrance
	[Vector2(-25.0, -30.0), Vector2(-39.0, -39.0), 1.7],      # to house A
	[Vector2(-25.0, -30.0), Vector2(-13.0, -40.0), 1.7],      # to house B
	[Vector2(-25.0, -30.0), Vector2(-38.0, -20.0), 1.7],      # to house C
	[Vector2(-25.0, -30.0), Vector2(-12.0, -21.0), 1.7],      # to house D
	[Vector2(-25.0, -30.0), Vector2(-25.0, -50.0), 1.8],      # to the farm
	[Vector2(-25.0, -30.0), Vector2(-112.0, -82.0), 2.0],    # old road to the Frostveil crossing
	[Vector2(-112.0, -82.0), Vector2(-178.0, -130.0), 1.8], # winding mountain approach
	[Vector2(-178.0, -130.0), Vector2(-250.0, -200.0), 1.8], # causeway to the remote Spire
	[Vector2(-250.0, -200.0), Vector2(-250.0, -200.0), 14.2], # remote spire courtyard
	[Vector2(-250.0, -200.0), Vector2(-302.0, -235.0), 1.8], # Frostveil ridge trail
	[Vector2(118.0, -104.0), Vector2(168.0, -72.0), 2.0],    # ridge watch road
	[Vector2(-25.0, -30.0), Vector2(-92.0, 42.0), 2.3],      # western woodland road
	[Vector2(-92.0, 42.0), Vector2(-156.0, 86.0), 2.0],     # marsh causeway
	[Vector2(-25.0, -30.0), Vector2(72.0, 112.0), 2.1],     # eastern trade road
]

var world_seed: int = 42
var height_noise: FastNoiseLite
var detail_noise: FastNoiseLite
var moisture_noise: FastNoiseLite
var temperature_noise: FastNoiseLite
var forest_noise: FastNoiseLite
var ridge_noise: FastNoiseLite
var path_noise: FastNoiseLite
var height_scale: float = 23.5

# Roads are graded into the shared heightfield: the mountain ridges must not cut
# straight across an authored route, so each corridor is flattened and its
# along-route profile is smoothed and grade-limited.
const ROAD_MAX_GRADE: float = 0.14
const ROAD_SAMPLE_STEP: float = 3.0
const ROAD_FLOOR: float = 1.2
const ROAD_SHOULDER: float = 2.4
const ROAD_MAX_SHOULDER: float = 9.0
const ROAD_FORD_BED: float = -0.28
# The eastern trade road fords/crosses the Heartlands river here; the timber
# bridge deck is aligned with the road direction, not the river axis.
const BRIDGE_CENTER: Vector2 = Vector2(43.4, 70.1)
const BRIDGE_DIR: Vector2 = Vector2(0.5639, 0.8258)
const BRIDGE_HALF_SPAN: float = 15.0

var _road_profiles: Array = []
var bridge_deck_y: float = 0.0
var _erosion_height_deltas: Dictionary = {}

enum Biome { OCEAN, BEACH, PLAINS, FOREST, HILLS, MOUNTAIN, SNOW, SWAMP, DESERT, AUTUMN_WOOD, VOLCANIC, RAINFOREST, JUNGLE, TAIGA, TUNDRA, SAVANNA, MEDITERRANEAN }

# Hand-authored geographic regions layered over the seeded terrain field.
# Each entry shares coordinates with the atlas, biome classifier and live chunks.
const CONTINENTS: Array = [
	{"name": "Elyndor Mainland", "center": Vector2(-20.0, 0.0), "rx": 650.0, "rz": 540.0},
	{"name": "Frostveil Continent", "center": Vector2(-250.0, -200.0), "rx": 132.0, "rz": 116.0},
	{"name": "Cinderwake Continent", "center": Vector2(220.0, 150.0), "rx": 48.0, "rz": 42.0},
]

const REGIONS: Array = [
	{"name": "Greenveil Rainforest", "center": Vector2(-450.0, 120.0), "rx": 112.0, "rz": 94.0, "biome": 11},
	{"name": "Thornwild Jungle", "center": Vector2(420.0, -60.0), "rx": 118.0, "rz": 102.0, "biome": 12},
	{"name": "Frostveil Continent", "center": Vector2(-250.0, -200.0), "rx": 118.0, "rz": 104.0, "biome": 5},
	{"name": "Cinderwake Continent", "center": Vector2(220.0, 150.0), "rx": 48.0, "rz": 42.0, "biome": 10},
	{"name": "Mirrorwater Basin", "center": Vector2(47.0, -9.0), "rx": 38.0, "rz": 31.0, "biome": 2},
	{"name": "Elyndor Heartlands", "center": Vector2(-25.0, -30.0), "rx": 62.0, "rz": 58.0, "biome": 2},
	{"name": "Whispering Woods", "center": Vector2(-112.0, 12.0), "rx": 82.0, "rz": 76.0, "biome": 3},
	{"name": "Amberleaf Glade", "center": Vector2(18.0, -112.0), "rx": 72.0, "rz": 58.0, "biome": 9},
	{"name": "Ironback Range", "center": Vector2(132.0, -104.0), "rx": 88.0, "rz": 72.0, "biome": 5},
	{"name": "Mirefen Wetlands", "center": Vector2(-150.0, 112.0), "rx": 72.0, "rz": 64.0, "biome": 7},
	{"name": "Sunscorch Expanse", "center": Vector2(148.0, 104.0), "rx": 78.0, "rz": 68.0, "biome": 8},
	{"name": "Emberfall Reach", "center": Vector2(206.0, -8.0), "rx": 54.0, "rz": 76.0, "biome": 10},
]

func _init(seed_value: int = 42) -> void:
	world_seed = seed_value
	height_noise = _make_noise(seed_value, 0.0065, 5, 2.05, 0.5)
	detail_noise = _make_noise(seed_value + 5, 0.045, 3, 2.0, 0.5)
	moisture_noise = _make_noise(seed_value + 17, 0.010, 3, 2.0, 0.5)
	temperature_noise = _make_noise(seed_value + 31, 0.007, 3, 2.0, 0.5)
	forest_noise = _make_noise(seed_value + 47, 0.016, 3, 2.0, 0.5)
	ridge_noise = _make_noise(seed_value + 73, 0.0038, 4, 2.15, 0.52)
	path_noise = _make_noise(seed_value + 61, 0.18, 2, 2.0, 0.5)
	_build_road_profiles()

func _make_noise(s: int, freq: float, octaves: int, lac: float, gain: float) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = s
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX
	n.frequency = freq
	n.fractal_octaves = octaves
	n.fractal_lacunarity = lac
	n.fractal_gain = gain
	return n

# ---------------------------------------------------------------------------
# Height
# ---------------------------------------------------------------------------
func get_height(x: float, z: float) -> float:
	var height := _apply_roads(x, z, _base_height(x, z))
	return height + _erosion_height_at(x, z)

## Applies a persistent, small terrain-height change to the shared heightfield.
## Negative values represent erosion; positive values represent deposited sediment.
func apply_erosion(x: float, z: float, height_delta_m: float) -> void:
	if absf(height_delta_m) < 0.0000001:
		return
	var key := Vector2i(roundi(x / 8.0), roundi(z / 8.0))
	_erosion_height_deltas[key] = clampf(float(_erosion_height_deltas.get(key, 0.0)) + height_delta_m, -2.5, 1.5)

func deposit_sediment(x: float, z: float, height_delta_m: float) -> void:
	apply_erosion(x, z, absf(height_delta_m))

func _erosion_height_at(x: float, z: float) -> float:
	var result := 0.0
	var cell := Vector2i(roundi(x / 8.0), roundi(z / 8.0))
	for oz in range(-1, 2):
		for ox in range(-1, 2):
			var key := cell + Vector2i(ox, oz)
			if not _erosion_height_deltas.has(key):
				continue
			var distance := Vector2(x, z).distance_to(Vector2(float(key.x), float(key.y)) * 8.0)
			var weight := exp(-distance * distance / 96.0)
			result += float(_erosion_height_deltas[key]) * weight
	return result

func _base_height(x: float, z: float) -> float:
	var h: float = height_noise.get_noise_2d(x, z) * height_scale
	# Guarantee a green homeland around the start; open ocean / mountains further out.
	var distance_from_home := Vector2(x, z).distance_to(START_CENTER)
	var land: float = 1.0 - smoothstep(180.0, 620.0, distance_from_home)
	h += land * 6.5
	# Ridged highlands form long, distant mountain chains instead of isolated low hills.
	# The relief fades out around the homeland so the starting settlement remains gentle.
	var mountain_belt := smoothstep(145.0, 310.0, distance_from_home)
	var ridge := 1.0 - absf(ridge_noise.get_noise_2d(x, z))
	h += pow(clampf(ridge, 0.0, 1.0), 2.6) * 31.0 * mountain_belt
	# Orographic ranges are broad uplifted belts with narrow, high ridgelines.
	# The relief profile creates foothills first, then steep alpine terrain and
	# isolated summit massifs rather than a field of equally tall random hills.
	var ironback_weight := get_region_weight(x, z, "Ironback Range")
	var frostveil_weight := get_region_weight(x, z, "Frostveil Continent")
	var range_spine := pow(clampf(ridge, 0.0, 1.0), 1.65)
	var massif_noise := 0.5 + 0.5 * height_noise.get_noise_2d(x * 0.42 + 91.0, z * 0.42 - 37.0)
	var ironback_pass := 1.0 - 0.72 * (1.0 - smoothstep(12.0, 30.0, Vector2(x, z).distance_to(Vector2(132.0, -104.0))))
	var frostveil_pass := 1.0 - 0.62 * (1.0 - smoothstep(15.0, 36.0, Vector2(x, z).distance_to(Vector2(-250.0, -200.0))))
	h += ironback_weight * (18.0 + range_spine * (42.0 + massif_noise * 58.0)) * ironback_pass
	h += frostveil_weight * (22.0 + range_spine * (48.0 + massif_noise * 76.0)) * frostveil_pass
	# Broad mountain walls create real route choices between distant regions.
	var outer_ridge := 1.0 - absf(ridge_noise.get_noise_2d(x + 173.0, z - 91.0))
	var farland_weight := smoothstep(170.0, 300.0, distance_from_home)
	h += pow(clampf(outer_ridge, 0.0, 1.0), 2.1) * 17.0 * farland_weight
	# Two distant landmasses are separated from the mainland by depressed sea channels.
	for island in [
		{"center": Vector2(-250.0, -200.0), "radius": 132.0, "elevation": 14.0},
		{"center": Vector2(220.0, 150.0), "radius": 48.0, "elevation": 8.5},
	]:
		var island_distance: float = Vector2(x, z).distance_to(island["center"])
		var island_land: float = 1.0 - smoothstep(float(island["radius"]) * 0.72, float(island["radius"]), island_distance)
		var island_height: float = float(island["elevation"]) + maxf(0.0, ridge) * 7.0 + height_noise.get_noise_2d(x * 0.7, z * 0.7) * 2.2
		h = lerpf(h, island_height, island_land)
		var sea_gap: float = smoothstep(float(island["radius"]) * 0.98, float(island["radius"]) * 1.12, island_distance)
		sea_gap *= 1.0 - smoothstep(float(island["radius"]) * 1.25, float(island["radius"]) * 1.55, island_distance)
		h = lerpf(h, -3.2, sea_gap * 0.96)
	# Island elevation shaping above intentionally establishes coastlines first;
	# restore Frostveil's tectonic massif afterward so its mountain chain is not
	# flattened by the island landform blend.
	h += frostveil_weight * (22.0 + range_spine * (48.0 + massif_noise * 76.0)) * frostveil_pass
	# The authored equatorial regions are humid lowland basins ringed by the
	# mountain belt. Without a relief override they land on the high ranges and
	# read as snowfields rather than rainforest and jungle.
	for tropical in [
		{"name": "Greenveil Rainforest", "base": 2.6},
		{"name": "Thornwild Jungle", "base": 3.0},
	]:
		var tropic: float = get_region_weight(x, z, tropical["name"])
		if tropic > 0.0:
			var rolling: float = height_noise.get_noise_2d(x * 0.7, z * 0.7) * 2.1 + detail_noise.get_noise_2d(x, z) * 0.7
			h = lerpf(h, float(tropical["base"]) + rolling, tropic * 0.94)
	# Shallow sea floor, taller peaks (both continuous - no cliffs at the seam).
	if h < 0.0:
		h *= 0.45
	elif h > 9.0:
		h = 9.0 + (h - 9.0) * 1.85
	h += detail_noise.get_noise_2d(x, z) * 0.9
	# The waterfall river is part of the same height field as streamed chunks.
	# Its shallow channel continues well beyond the landmark water meshes so the
	# riverbed, bank heights and chunk collision remain continuous as chunks load.
	var river_distance := _dist_to_segment(Vector2(x, z), Vector2(42.0, -8.0), Vector2(42.0, 95.0))
	var river_mask := 1.0 - smoothstep(3.8, 10.5, river_distance)
	var river_bed := -0.82 + clampf((z + 8.0) / 103.0, 0.0, 1.0) * 0.14
	h = lerpf(h, river_bed, river_mask)
	# Two additional winding river systems cut across the distant wilderness.
	# Their continuous beds stream with the terrain and become natural chokepoints.
	var river_two_distance := minf(
		_dist_to_segment(Vector2(x, z), Vector2(-360.0, -230.0), Vector2(-230.0, -105.0)),
		minf(_dist_to_segment(Vector2(x, z), Vector2(-230.0, -105.0), Vector2(-65.0, 8.0)),
		_dist_to_segment(Vector2(x, z), Vector2(-65.0, 8.0), Vector2(155.0, 185.0))))
	var river_two_mask := 1.0 - smoothstep(3.2, 9.2, river_two_distance)
	# Full-strength carve at the channel core: a partial lerp leaves the bed above
	# the water plane wherever the underlying terrain is high (dry sand rivers).
	h = lerpf(h, -0.76, river_two_mask)
	var river_three_distance := minf(
		_dist_to_segment(Vector2(x, z), Vector2(-310.0, 285.0), Vector2(-155.0, 180.0)),
		minf(_dist_to_segment(Vector2(x, z), Vector2(-155.0, 180.0), Vector2(28.0, 52.0)),
		_dist_to_segment(Vector2(x, z), Vector2(28.0, 52.0), Vector2(250.0, -110.0))))
	var river_three_mask := 1.0 - smoothstep(3.0, 8.5, river_three_distance)
	h = lerpf(h, -0.79, river_three_mask)
	# Tropical streams wind through the rainforest and jungle basins, giving the
	# humid regions a water spine and natural clearings in the canopy.
	var tropical_streams: Array = [
		[Vector2(-520.0, 55.0), Vector2(-478.0, 92.0), Vector2(-452.0, 130.0), Vector2(-418.0, 158.0), Vector2(-396.0, 196.0)],
		[Vector2(350.0, -135.0), Vector2(382.0, -95.0), Vector2(410.0, -62.0), Vector2(445.0, -30.0), Vector2(478.0, 8.0)],
	]
	for stream in tropical_streams:
		var stream_distance := INF
		for i in range(stream.size() - 1):
			stream_distance = minf(stream_distance, _dist_to_segment(Vector2(x, z), stream[i], stream[i + 1]))
		if stream_distance < 8.5:
			var stream_mask := 1.0 - smoothstep(2.6, 8.5, stream_distance)
			h = lerpf(h, -0.55, stream_mask)
	# A narrow natural causeway links the mainland road to Frostveil across the sea channel.
	# It remains a chokepoint: the surrounding water and mountain walls are still barriers.
	var causeway_distance := minf(
		_dist_to_segment(Vector2(x, z), Vector2(-25.0, -30.0), Vector2(-112.0, -82.0)),
		minf(_dist_to_segment(Vector2(x, z), Vector2(-112.0, -82.0), Vector2(-178.0, -130.0)),
		_dist_to_segment(Vector2(x, z), Vector2(-178.0, -130.0), Vector2(-250.0, -200.0))))
	var causeway_mask := 1.0 - smoothstep(6.0, 11.0, causeway_distance)
	h = lerpf(h, maxf(h, 1.85), causeway_mask)
	# Mirror Pond's north headwall: the waterfall needs a real bluff to pour from
	# and a feeder channel along its top, not a sheet rising out of flat water.
	var bluff_width := 1.0 - smoothstep(10.0, 20.0, absf(x - 42.0))
	var bluff_north := 1.0 - smoothstep(-25.0, -23.0, z)
	h = lerpf(h, maxf(h, 8.4), bluff_width * bluff_north * 0.96)
	var feeder_x := 1.0 - smoothstep(2.4, 5.2, absf(x - 42.0))
	var feeder_z := smoothstep(-56.0, -48.0, z) * (1.0 - smoothstep(-25.5, -24.0, z))
	h = lerpf(h, 6.55, feeder_x * feeder_z * bluff_north * 0.95)
	# Mirror Pond is a real submerged basin, not a flat water decal over dry ground.
	var lake_dx: float = (x - 47.0) / 15.0
	var lake_dz: float = (z + 9.0) / 12.0
	var lake_radius := sqrt(lake_dx * lake_dx + lake_dz * lake_dz)
	var lake_mask := 1.0 - smoothstep(0.72, 1.12, lake_radius)
	h = lerpf(h, -0.95, lake_mask * 0.98)
	return _apply_settlements(x, z, h)

func _apply_settlements(x: float, z: float, h: float) -> float:
	var p := Vector2(x, z)
	for s in SETTLEMENTS:
		var d: float = p.distance_to(s[0])
		var t: float = 1.0 - smoothstep(s[2], s[3], d)
		if t > 0.0:
			h = lerpf(h, s[1], t)
	return h

## 1.0 inside a settlement's flat area, fading to 0 just outside. Used to keep wild vegetation out.
func settlement_mask(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var m: float = 0.0
	for s in SETTLEMENTS:
		var d: float = p.distance_to(s[0])
		m = maxf(m, 1.0 - smoothstep(s[2] - 2.0, s[2] + 7.0, d))
	return m

# ---------------------------------------------------------------------------
# Roads
# ---------------------------------------------------------------------------
## Precomputes a grade-limited elevation profile per authored road segment so a
## corridor can be carved through ridges instead of draping the path over them.
func _build_road_profiles() -> void:
	_road_profiles.clear()
	for seg in PATHS:
		var a: Vector2 = seg[0]
		var b: Vector2 = seg[1]
		var half: float = float(seg[2])
		if half > 5.0:
			continue # plazas and courtyards are flattened by their settlements
		var length: float = a.distance_to(b)
		if length < 1.0:
			continue
		var count: int = maxi(2, int(ceil(length / ROAD_SAMPLE_STEP)))
		var step_length: float = length / float(count)
		var heights := PackedFloat32Array()
		heights.resize(count + 1)
		var fords := PackedByteArray()
		fords.resize(count + 1)
		for i in range(count + 1):
			var p: Vector2 = a.lerp(b, float(i) / float(count))
			var ground: float = _base_height(p.x, p.y)
			# Water crossings stay water: the road dips to a shallow ford bed
			# instead of filling the channel up to dry road grade. Deep marsh and
			# sea beds are causeways, not fords.
			fords[i] = 1 if ground < -0.05 and ground > -1.3 else 0
			heights[i] = maxf(ground, ROAD_FORD_BED) if fords[i] == 1 else maxf(ground, ROAD_FLOOR)
		var ford_near := PackedByteArray()
		ford_near.resize(count + 1)
		for i in range(count + 1):
			for j in range(maxi(0, i - 2), mini(count, i + 2) + 1):
				if fords[j] == 1:
					ford_near[i] = 1
		# The bridge span is pinned to a deck height cleared above the water; the
		# settle passes then grade the approaches into it from both banks.
		var span_start: int = -1
		var span_end: int = -1
		for i in range(count + 1):
			var p: Vector2 = a.lerp(b, float(i) / float(count))
			if p.distance_to(BRIDGE_CENTER) <= BRIDGE_HALF_SPAN:
				if span_start < 0:
					span_start = i
				span_end = i
		if span_start >= 0:
			var pa: Vector2 = a.lerp(b, float(span_start) / float(count))
			var pb: Vector2 = a.lerp(b, float(span_end) / float(count))
			var deck: float = maxf(_base_height(pa.x, pa.y), _base_height(pb.x, pb.y)) + 1.15
			bridge_deck_y = deck
			for i in range(span_start, span_end + 1):
				heights[i] = deck
				fords[i] = 0
		# Junctions must agree, so both ends stay pinned to their ground height.
		# When the endpoints differ by more than the normal grade allows, the
		# segment becomes a steady ramp instead of a cliff at one end.
		var start_height: float = heights[0]
		var end_height: float = heights[count]
		var grade: float = maxf(ROAD_MAX_GRADE, absf(end_height - start_height) / length)
		var max_delta: float = grade * step_length
		heights = _settle_road_profile(heights, count, max_delta, span_start, span_end)
		for _pass in range(2):
			var prev := heights.duplicate()
			heights[0] = start_height
			heights[count] = end_height
			for i in range(1, count):
				if i >= span_start and i <= span_end:
					continue
				heights[i] = (prev[i - 1] + prev[i] * 2.0 + prev[i + 1]) * 0.25
		for i in range(count + 1):
			if ford_near[i] == 0 and not (i >= span_start and i <= span_end):
				heights[i] = maxf(heights[i], ROAD_FLOOR)
		heights[0] = start_height
		heights[count] = end_height
		heights = _settle_road_profile(heights, count, max_delta, span_start, span_end)
		for i in range(count + 1):
			if fords[i] == 1:
				heights[i] = ROAD_FORD_BED
		# Grade the ford edges back up to road level so crossings read as shallow
		# ramps, not vertical sandbar walls damming the channel.
		for f in range(count + 1):
			if fords[f] == 0:
				continue
			for k in range(1, 5):
				for s in [-1, 1]:
					var i: int = f + s * k
					if i >= 0 and i <= count and fords[i] == 0 and not (i >= span_start and i <= span_end):
						heights[i] = minf(heights[i], ROAD_FORD_BED + float(k) * max_delta)
		_road_profiles.append({"a": a, "b": b, "half": half, "heights": heights})

## Enforces the maximum grade between neighbouring samples while leaving both
## endpoints untouched, so connected segments always meet at the same height.
func _settle_road_profile(heights: PackedFloat32Array, count: int, max_delta: float, pin_start: int = -1, pin_end: int = -1) -> PackedFloat32Array:
	for iteration in range(32):
		for i in range(1, count):
			if i >= pin_start and i <= pin_end:
				continue
			heights[i] = clampf(heights[i], heights[i - 1] - max_delta, heights[i - 1] + max_delta)
		for i in range(count - 1, 0, -1):
			if i >= pin_start and i <= pin_end:
				continue
			heights[i] = clampf(heights[i], heights[i + 1] - max_delta, heights[i + 1] + max_delta)
	return heights

## Carves the road corridor into the terrain: flat across the painted width,
## then a proportional cut/fill shoulder that lets ridges fall away naturally.
func _apply_roads(x: float, z: float, h: float) -> float:
	var p := Vector2(x, z)
	if h < 0.05:
		var bl: Vector2 = bridge_local(p)
		if absf(bl.x) <= 10.0 and absf(bl.y) <= 4.6:
			return h  # water flows free under the deck; no embankment dam
	var best_distance: float = INF
	var best_height: float = 0.0
	var best_half: float = 0.0
	for road in _road_profiles:
		var a: Vector2 = road["a"]
		var ab: Vector2 = road["b"] - a
		var len2: float = ab.length_squared()
		var t: float = clampf((p - a).dot(ab) / len2, 0.0, 1.0)
		var d: float = p.distance_to(a + ab * t)
		if d >= best_distance:
			continue
		best_distance = d
		best_half = float(road["half"])
		var heights: PackedFloat32Array = road["heights"]
		var f: float = t * float(heights.size() - 1)
		var i: int = clampi(int(f), 0, heights.size() - 2)
		best_height = lerpf(heights[i], heights[i + 1], f - float(i))
	if best_distance == INF:
		return h
	var inner: float = best_half + ROAD_SHOULDER
	if best_distance >= inner:
		var shoulder: float = clampf(absf(h - best_height) * 1.4, 2.5, ROAD_MAX_SHOULDER)
		if best_distance >= inner + shoulder:
			return h
		# Embankments must not bury a live channel: the fill target dives to the
		# ford bed as the natural ground submerges, keeping water continuous.
		var target: float = best_height
		if h < 0.0:
			target = lerpf(best_height, ROAD_FORD_BED, clampf(-h / 0.35, 0.0, 1.0))
		return lerpf(h, target, 1.0 - smoothstep(inner, inner + shoulder, best_distance))
	return best_height

func get_path_amount(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var wob: float = path_noise.get_noise_2d(x, z) * 0.9
	var best: float = 0.0
	for seg in PATHS:
		var d: float = _dist_to_segment(p, seg[0], seg[1]) + wob
		best = maxf(best, 1.0 - smoothstep(seg[2], seg[2] + 1.3, d))
	return best

func _dist_to_segment(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var len2: float = ab.length_squared()
	if len2 < 0.0001:
		return p.distance_to(a)
	var t: float = clampf((p - a).dot(ab) / len2, 0.0, 1.0)
	return p.distance_to(a + ab * t)

## Deck elevation shared by the road profile and the settlement builder so the
## road grade, abutments and walkable deck all meet at the same height.
func bridge_deck_height() -> float:
	if bridge_deck_y > 0.0:
		return bridge_deck_y
	var a: Vector2 = BRIDGE_CENTER - BRIDGE_DIR * BRIDGE_HALF_SPAN
	var b: Vector2 = BRIDGE_CENTER + BRIDGE_DIR * BRIDGE_HALF_SPAN
	return maxf(maxf(_base_height(a.x, a.y), _base_height(b.x, b.y)) + 0.24, Constants.WATER_LEVEL + 1.15)

func bridge_local(p: Vector2) -> Vector2:
	var d: Vector2 = p - BRIDGE_CENTER
	return Vector2(d.dot(BRIDGE_DIR), d.x * BRIDGE_DIR.y - d.y * BRIDGE_DIR.x)

## Coarse bake of the shared heightfield. The water shader reads it to attenuate
## the ocean tide by bed depth: inland streams and lakes must not drain at low tide.
func build_height_map(res: int = 256, extent: float = 1400.0) -> ImageTexture:
	var img := Image.create(res, res, false, Image.FORMAT_RF)
	var step: float = 2.0 * extent / float(res)
	for iy in range(res):
		var z: float = -extent + (float(iy) + 0.5) * step
		for ix in range(res):
			var x: float = -extent + (float(ix) + 0.5) * step
			img.set_pixel(ix, iy, Color(get_height(x, z), 0.0, 0.0, 1.0))
	return ImageTexture.create_from_image(img)

# ---------------------------------------------------------------------------
# Climate / biomes
# ---------------------------------------------------------------------------
func get_moisture(x: float, z: float) -> float:
	return moisture_noise.get_noise_2d(x, z)

func get_temperature(x: float, z: float) -> float:
	# Normalised climate temperature with an elevation lapse rate. High ridges
	# are colder than nearby valleys even at the same latitude.
	var elevation := maxf(0.0, get_height(x, z))
	return temperature_noise.get_noise_2d(x, z) - maxf(0.0, elevation - 12.0) * 0.009

## 0..1 how wooded this spot is.
func get_forest_density(x: float, z: float, h: float) -> float:
	var n: float = forest_noise.get_noise_2d(x, z) + moisture_noise.get_noise_2d(x, z) * 0.35
	var d: float = smoothstep(-0.05, 0.4, n)
	d *= 1.0 - smoothstep(12.0, 19.0, h)
	d *= smoothstep(1.3, 2.6, h)
	# The old-growth and wetland regions have deliberately denser canopy cover.
	d = maxf(d, get_region_weight(x, z, "Whispering Woods") * 0.78)
	d = maxf(d, get_region_weight(x, z, "Mirefen Wetlands") * 0.58)
	d = maxf(d, get_region_weight(x, z, "Amberleaf Glade") * 0.38)
	d = maxf(d, get_region_weight(x, z, "Greenveil Rainforest") * 0.96)
	d = maxf(d, get_region_weight(x, z, "Thornwild Jungle") * 0.90)
	return d

func get_region_weight(x: float, z: float, region_name: String) -> float:
	for region in REGIONS:
		if str(region["name"]) != region_name:
			continue
		var c: Vector2 = region["center"]
		var nx: float = (x - c.x) / float(region["rx"])
		var nz: float = (z - c.y) / float(region["rz"])
		var radial := sqrt(nx * nx + nz * nz)
		return 1.0 - smoothstep(0.72, 1.0, radial)
	return 0.0

func get_region_name(x: float, z: float) -> String:
	var p := Vector2(x, z)
	for region in REGIONS:
		var c: Vector2 = region["center"]
		var nx: float = (p.x - c.x) / float(region["rx"])
		var nz: float = (p.y - c.y) / float(region["rz"])
		if nx * nx + nz * nz <= 1.0:
			return str(region["name"])
	return "The Uncharted Wilds"

func get_region_anchor_data() -> Array:
	return REGIONS.duplicate(true)

func get_continent_data() -> Array:
	return CONTINENTS.duplicate(true)

func get_biome(x: float, z: float, height: float) -> Biome:
	var temp := temperature_noise.get_noise_2d(x, z) - maxf(0.0, height - 12.0) * 0.009
	var moisture := get_moisture(x, z)
	if height < Constants.WATER_LEVEL:
		return Biome.OCEAN
	if height < 1.3:
		return Biome.BEACH
	# Altitude bands are deliberately distinct: low rolling hills, montane
	# forest, alpine rock, then permanent snow/ice on the coldest highest peaks.
	if height >= 72.0 and temp < 0.48:
		return Biome.SNOW
	if height >= 48.0:
		return Biome.MOUNTAIN
	if height >= 27.0:
		return Biome.HILLS
	var region_name := get_region_name(x, z)
	if region_name != "The Uncharted Wilds":
		match region_name:
			"Greenveil Rainforest": return Biome.RAINFOREST
			"Thornwild Jungle": return Biome.JUNGLE
			"Frostveil Continent": return Biome.TAIGA if temp < 0.12 and moisture > -0.35 else Biome.MOUNTAIN
			"Cinderwake Continent", "Emberfall Reach": return Biome.VOLCANIC
			"Elyndor Heartlands": return Biome.PLAINS
			"Whispering Woods": return Biome.FOREST
			"Mirrorwater Basin": return Biome.PLAINS
			"Amberleaf Glade": return Biome.AUTUMN_WOOD
			"Ironback Range": return Biome.TAIGA if temp < 0.08 else Biome.FOREST
			"Mirefen Wetlands": return Biome.SWAMP
			"Sunscorch Expanse": return Biome.DESERT if moisture < -0.15 else Biome.SAVANNA
	if temp < -0.35:
		return Biome.TUNDRA
	if temp < -0.08 and moisture > -0.35:
		return Biome.TAIGA
	if moisture > 0.62 and temp > 0.18:
		return Biome.JUNGLE
	if moisture > 0.48 and height < 5.0:
		return Biome.SWAMP
	if moisture > 0.48 and temp > 0.12:
		return Biome.RAINFOREST
	if temp > 0.48 and moisture < -0.32:
		return Biome.DESERT
	if temp > 0.28 and moisture < -0.05:
		return Biome.SAVANNA
	if temp > 0.10 and moisture > -0.1 and moisture < 0.28:
		return Biome.MEDITERRANEAN
	if get_forest_density(x, z, height) > 0.45:
		return Biome.AUTUMN_WOOD if temp < -0.12 else Biome.FOREST
	return Biome.PLAINS

## Base ground tint (sRGB). The terrain shader adds rock / sand / snow / path detail on top.
## alpha channel = how much "path" is painted here.
func get_ground_color(x: float, z: float, h: float) -> Color:
	var m: float = clampf(moisture_noise.get_noise_2d(x, z) * 0.9 + 0.5, 0.0, 1.0)
	var dry := Color(0.47, 0.46, 0.25)
	var lush := Color(0.27, 0.40, 0.18)
	var forest_floor := Color(0.16, 0.29, 0.11)
	var c: Color = dry.lerp(lush, m)
	var f: float = get_forest_density(x, z, h)
	c = c.lerp(forest_floor, f * 0.68)
	# Leaf litter and exposed soil break up the forest floor.
	c = c.lerp(Color(0.30, 0.24, 0.13), f * smoothstep(0.55, 0.9, moisture_noise.get_noise_2d(x * 2.3, z * 2.3)) * 0.28)
	c = c.lerp(Color(0.37, 0.40, 0.22), smoothstep(6.5, 11.5, h))
	var biome := get_biome(x, z, h)
	match biome:
		Biome.SWAMP: c = c.lerp(Color(0.18, 0.30, 0.20), 0.72)
		Biome.DESERT: c = c.lerp(Color(0.72, 0.57, 0.32), 0.82)
		Biome.AUTUMN_WOOD: c = c.lerp(Color(0.58, 0.31, 0.12), 0.38)
		Biome.VOLCANIC: c = c.lerp(Color(0.20, 0.17, 0.16), 0.78)
		Biome.RAINFOREST: c = c.lerp(Color(0.08, 0.25, 0.12), 0.78)
		Biome.JUNGLE: c = c.lerp(Color(0.06, 0.20, 0.10), 0.84)
		Biome.TAIGA: c = c.lerp(Color(0.22, 0.31, 0.24), 0.72)
		Biome.TUNDRA: c = c.lerp(Color(0.48, 0.49, 0.40), 0.72)
		Biome.SAVANNA: c = c.lerp(Color(0.62, 0.55, 0.27), 0.78)
		Biome.MEDITERRANEAN: c = c.lerp(Color(0.43, 0.42, 0.22), 0.65)
	c.a = get_path_amount(x, z)
	return c
