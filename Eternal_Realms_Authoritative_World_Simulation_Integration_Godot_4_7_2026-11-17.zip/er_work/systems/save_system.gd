# Save / Load System
# Real Coder: Simple, versioned, JSON-based, easy to extend
extends Node

const SAVE_VERSION: int = 11
const SAVE_PATH: String = "user://eternal_realms_save.json"

signal save_completed(success: bool)
signal load_completed(success: bool)

func save_game() -> void:
	var player = GameManager.player
	if player == null:
		push_warning("[SaveSystem] No player to save")
		save_completed.emit(false)
		return

	var data := {
		"version": SAVE_VERSION,
		"timestamp": Time.get_unix_time_from_system(),
		"player": {
			"position": {
				"x": player.global_position.x,
				"y": player.global_position.y,
				"z": player.global_position.z
			},
			"rotation_y": player.rotation.y,
			"age": player.current_age,
			"health": player.health.current_health if player.health else 100.0,
			"max_health": player.health.max_health if player.health else 100.0
		},
		"skills": {},
		"progress": PlayerData.to_dict(),
		"reputation": _get_reputation_state(),
		"world_seed": GameManager.world_seed,
		"game_time_seconds": GameManager.game_time_seconds,
		"time_of_day": _get_time_of_day(),
		"dungeon": _get_dungeon_state(),
		"dungeon_campaign": _get_dungeon_campaign_state(),
		"environment": _get_environment_state(),
		"underwater_world": _get_underwater_state()
	}

	# Skills (decimal values, Entropia-style)
	if player.skills:
		data["skills"] = player.skills.to_dict()

	var json := JSON.stringify(data, "\t")
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("[SaveSystem] Failed to open save file for writing")
		save_completed.emit(false)
		return

	file.store_string(json)
	file.close()
	print("[SaveSystem] Game saved successfully")
	EventBus.toast.emit("Game saved", "info")
	save_completed.emit(true)

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		print("[SaveSystem] No save file found")
		load_completed.emit(false)
		return

	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		push_error("[SaveSystem] Failed to open save file")
		load_completed.emit(false)
		return

	var json_text := file.get_as_text()
	file.close()

	var data = JSON.parse_string(json_text)
	if data == null or typeof(data) != TYPE_DICTIONARY:
		push_error("[SaveSystem] Corrupted save data")
		load_completed.emit(false)
		return

	if data.get("version", 0) != SAVE_VERSION:
		push_warning("[SaveSystem] Save version mismatch - attempting load anyway")

	var player = GameManager.player
	if player == null:
		load_completed.emit(false)
		return

	if data.has("progress") and data["progress"] is Dictionary:
		PlayerData.from_dict(data["progress"])

	var campaign_system: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
	if campaign_system and campaign_system.has_method("restore_from_save") and data.get("dungeon_campaign", {}) is Dictionary:
		campaign_system.restore_from_save(data.get("dungeon_campaign", {}))

	# Restore dungeon context before position. Otherwise a saved underground
	# position is treated as an overworld fall and swimming location on load.
	var dungeon = get_tree().get_first_node_in_group("dungeon")
	var dungeon_value: Variant = data.get("dungeon", {})
	var dungeon_state: Dictionary = dungeon_value if dungeon_value is Dictionary else {}
	var restored_inside_dungeon: bool = dungeon != null and bool(dungeon_state.get("inside", false))
	if dungeon and dungeon.has_method("restore_from_save"):
		dungeon.restore_from_save(dungeon_state)
	var player_value: Variant = data.get("player", {})
	var player_data: Dictionary = player_value if player_value is Dictionary else {}
	if not restored_inside_dungeon:
		var position_value: Variant = player_data.get("position", {})
		var pos: Dictionary = position_value if position_value is Dictionary else {}
		if pos:
			player.global_position = Vector3(float(pos.get("x", 0.0)), float(pos.get("y", 10.0)), float(pos.get("z", 0.0)))
	if player_data.has("rotation_y"):
		player.rotation.y = float(player_data.get("rotation_y", 0.0))

	# Age
	player.current_age = float(player_data.get("age", Constants.STARTING_AGE))
	player.previous_age = player.current_age

	# Progress: inventory, equipment, gold, quests, titles
	if not bool(PlayerData.stats.get("starter_farm_pack", false)):
		PlayerData.add_item("wheat_seed", 6)
		PlayerData.add_item("carrot_seed", 4)
		PlayerData.add_item("berry_seed", 3)
		PlayerData.add_item("hay", 5)
		PlayerData.add_item("wood_log", 12)
		PlayerData.stats["starter_farm_pack"] = true
	if PlayerBuildingSystem and PlayerBuildingSystem.has_method("restore_from_player_data"):
		PlayerBuildingSystem.restore_from_player_data()
	if FarmingSystem and FarmingSystem.has_method("restore_from_player_data"):
		FarmingSystem.restore_from_player_data()
	if AnimalHusbandrySystem and AnimalHusbandrySystem.has_method("refresh_from_player_data"):
		AnimalHusbandrySystem.refresh_from_player_data()
	if PlayerBusinessSystem and PlayerBusinessSystem.has_method("refresh_from_player_data"):
		PlayerBusinessSystem.refresh_from_player_data()
	if TamingMountSystem and TamingMountSystem.has_method("refresh_from_player_data"):
		TamingMountSystem.refresh_from_player_data()
	if LivingWorldSystem and LivingWorldSystem.has_method("refresh_from_player_data"):
		LivingWorldSystem.refresh_from_player_data()
	var reputation: Node = get_tree().get_first_node_in_group("reputation")
	if reputation and reputation.has_method("from_save") and data.get("reputation", {}) is Dictionary:
		reputation.from_save(data.get("reputation", {}))
	var environment: Node = get_tree().get_first_node_in_group("environment_world")
	if environment and environment.has_method("restore_from_save") and data.get("environment", {}) is Dictionary:
		environment.restore_from_save(data.get("environment", {}))
	var underwater: Node = get_tree().get_first_node_in_group("underwater_exploration")
	if underwater and underwater.has_method("restore_from_save"):
		var underwater_state: Variant = data.get("underwater_world", {})
		underwater.restore_from_save(underwater_state if underwater_state is Dictionary else {})
	var saved_skills: Variant = data.get("skills", {})
	if player.skills and saved_skills is Dictionary:
		player.skills.from_dict(saved_skills)
	if player.has_method("refresh_stats"):
		player.refresh_stats()
		if player.health:
			player.health.current_health = clampf(float(player_data.get("health", player.health.max_health)), 0.0, player.health.max_health)
			player.health.is_dead = player.health.current_health <= 0.0
			player.health.health_changed.emit(player.health.current_health, player.health.max_health)

	# World time
	GameManager.game_time_seconds = data.get("game_time_seconds", 0.0)
	var cycle = get_tree().get_first_node_in_group("day_night")
	if cycle and data.has("time_of_day"):
		cycle.time_of_day = float(data["time_of_day"])
	if player.has_method("refresh_age_visuals"):
		player.refresh_age_visuals()
	player.velocity = Vector3.ZERO
	if player.health and player.health.is_dead:
		GameManager.current_state = GameManager.GameState.PLAYING
		player.health.died.emit(null)

	print("[SaveSystem] Game loaded successfully")
	EventBus.toast.emit("Game loaded", "info")
	load_completed.emit(true)

func _get_reputation_state() -> Dictionary:
	var reputation: Node = get_tree().get_first_node_in_group("reputation")
	if reputation and reputation.has_method("to_save"):
		return reputation.to_save()
	return {}

func _get_dungeon_campaign_state() -> Dictionary:
	var campaign_system: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
	if campaign_system and campaign_system.has_method("get_save_state"):
		return campaign_system.get_save_state()
	return {}

func _get_underwater_state() -> Dictionary:
	var underwater: Node = get_tree().get_first_node_in_group("underwater_exploration")
	if underwater and underwater.has_method("get_save_state"):
		return underwater.get_save_state()
	return {"revision": 0, "sites": {}, "populations": {}}

func _get_environment_state() -> Dictionary:
	var environment: Node = get_tree().get_first_node_in_group("environment_world")
	if environment and environment.has_method("get_save_state"):
		return environment.get_save_state()
	return {}

func _get_dungeon_state() -> Dictionary:
	var dungeon = get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("get_save_state"):
		return dungeon.get_save_state()
	return {"inside": false, "current_floor": 0, "deepest_cleared": 0}

func _get_time_of_day() -> float:
	var cycle = get_tree().get_first_node_in_group("day_night")
	if cycle:
		return cycle.time_of_day
	return 0.35

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(SAVE_PATH)
		print("[SaveSystem] Save deleted")
