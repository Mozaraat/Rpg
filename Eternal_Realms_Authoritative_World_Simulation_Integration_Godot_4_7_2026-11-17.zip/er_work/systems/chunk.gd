# Single terrain chunk.
# Built in small stages (terrain -> props -> grass bands) so ChunkManager can spread the
# work over several frames and streaming never causes a visible hitch.
class_name Chunk
extends StaticBody3D

const GRASS_BANDS: int = 4
const GRASS_CELL: float = 1.25

var chunk_pos: Vector2i
var noise: TerrainNoise
var terrain_material: Material
var res: int = Constants.CHUNK_RES
var step: float = 2.0
var stride: int = 0
var heights: PackedFloat32Array = PackedFloat32Array()   # (res+3)^2, 1 vertex border for seamless normals
var colors: PackedColorArray = PackedColorArray()        # (res+1)^2
var stage: int = 0
var done: bool = false

var _origin: Vector3 = Vector3.ZERO
var _grass_rng: RandomNumberGenerator
var _grass_x: Array[Transform3D] = []
var _grass_t: PackedColorArray = PackedColorArray()
var _flower_x: Array[Transform3D] = []
var _flower_t: PackedColorArray = PackedColorArray()
var _loose_rocks: int = 0

static var _tree_shape: CylinderShape3D = null

func setup(pos: Vector2i, terrain_noise: TerrainNoise, mat: Material) -> void:
	chunk_pos = pos
	noise = terrain_noise
	terrain_material = mat
	name = "Chunk_%d_%d" % [pos.x, pos.y]
	collision_layer = Constants.LAYER_WORLD
	collision_mask = 0
	_origin = Vector3(pos.x * Constants.CHUNK_SIZE, 0, pos.y * Constants.CHUNK_SIZE)
	position = _origin
	step = float(Constants.CHUNK_SIZE) / float(res)
	stride = res + 3

## Runs the next build stage. Returns true when the chunk is completely built.
func advance() -> bool:
	if stage == 0:
		_build_terrain()
	elif stage == 1:
		_build_props()
	else:
		var band: int = stage - 2
		_build_grass_band(band)
		if band == GRASS_BANDS - 1:
			_finish_grass()
	stage += 1
	done = stage >= 2 + GRASS_BANDS
	return done

# ---------------------------------------------------------------------------
# Terrain
# ---------------------------------------------------------------------------
func _build_terrain() -> void:
	heights.resize(stride * stride)
	for gz in range(stride):
		for gx in range(stride):
			var wx: float = _origin.x + float(gx - 1) * step
			var wz: float = _origin.z + float(gz - 1) * step
			heights[gz * stride + gx] = noise.get_height(wx, wz)

	var vcount: int = (res + 1) * (res + 1)
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var cols := PackedColorArray()
	verts.resize(vcount)
	normals.resize(vcount)
	cols.resize(vcount)
	for z in range(res + 1):
		for x in range(res + 1):
			var gi: int = (z + 1) * stride + (x + 1)
			var h: float = heights[gi]
			var vi: int = z * (res + 1) + x
			verts[vi] = Vector3(float(x) * step, h, float(z) * step)
			# Normals come from the shared height grid, so chunk borders match exactly.
			normals[vi] = Vector3(heights[gi - 1] - heights[gi + 1], 2.0 * step, heights[gi - stride] - heights[gi + stride]).normalized()
			cols[vi] = noise.get_ground_color(_origin.x + float(x) * step, _origin.z + float(z) * step, h)
	colors = cols

	var indices := PackedInt32Array()
	indices.resize(res * res * 6)
	var k: int = 0
	for z in range(res):
		for x in range(res):
			var i: int = z * (res + 1) + x
			indices[k] = i
			indices[k + 1] = i + 1
			indices[k + 2] = i + res + 1
			indices[k + 3] = i + 1
			indices[k + 4] = i + res + 2
			indices[k + 5] = i + res + 1
			k += 6

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	var mi := MeshInstance3D.new()
	mi.name = "Terrain"
	mi.mesh = mesh
	mi.material_override = terrain_material
	add_child(mi)

	var col := CollisionShape3D.new()
	col.name = "TerrainCollision"
	col.shape = mesh.create_trimesh_shape()
	add_child(col)

## Ground height at a chunk-local position (bilinear on the shared grid).
func height_local(lx: float, lz: float) -> float:
	var fx: float = clampf(lx / step, 0.0, float(res) - 0.001)
	var fz: float = clampf(lz / step, 0.0, float(res) - 0.001)
	var ix: int = int(fx)
	var iz: int = int(fz)
	var tx: float = fx - float(ix)
	var tz: float = fz - float(iz)
	var i: int = (iz + 1) * stride + (ix + 1)
	return lerpf(lerpf(heights[i], heights[i + 1], tx), lerpf(heights[i + stride], heights[i + stride + 1], tx), tz)

func normal_y_local(lx: float, lz: float) -> float:
	var dx: float = (height_local(lx + step, lz) - height_local(lx - step, lz)) / (2.0 * step)
	var dz: float = (height_local(lx, lz + step) - height_local(lx, lz - step)) / (2.0 * step)
	return 1.0 / sqrt(1.0 + dx * dx + dz * dz)

func color_local(lx: float, lz: float) -> Color:
	var ix: int = clampi(int(roundf(lx / step)), 0, res)
	var iz: int = clampi(int(roundf(lz / step)), 0, res)
	return colors[iz * (res + 1) + ix]

# ---------------------------------------------------------------------------
# Trees, bushes, rocks
# ---------------------------------------------------------------------------
func _build_props() -> void:
	var size: float = float(Constants.CHUNK_SIZE)
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector3i(chunk_pos.x, chunk_pos.y, noise.world_seed))

	var tree_species: Array[String] = ["broadleaf", "pine", "redwood", "willow", "baobab", "cherry", "jungle", "deadwood"]
	var tree_x: Dictionary = {}
	var tree_t: Dictionary = {}
	for species in tree_species:
		var empty_transforms: Array[Transform3D] = []
		tree_x[species] = empty_transforms
		tree_t[species] = PackedColorArray()
	var bush_x: Array[Transform3D] = []
	var bush_t := PackedColorArray()
	var rock_x: Array[Transform3D] = []
	var rock_t := PackedColorArray()
	_loose_rocks = 0

	if _tree_shape == null:
		_tree_shape = CylinderShape3D.new()
		_tree_shape.radius = 0.38
		_tree_shape.height = 4.0

	var cell: float = 7.0
	var n: int = int(ceil(size / cell))
	for cz in range(n):
		for cx in range(n):
			var lx: float = (float(cx) + rng.randf_range(0.2, 0.8)) * cell
			var lz: float = (float(cz) + rng.randf_range(0.2, 0.8)) * cell
			var roll: float = rng.randf()
			var roll2: float = rng.randf()
			var yaw: float = rng.randf() * TAU
			var scl: float = rng.randf_range(0.82, 1.42)
			var tint_v: float = rng.randf_range(0.82, 1.18)
			if lx >= size or lz >= size:
				continue
			var wx: float = _origin.x + lx
			var wz: float = _origin.z + lz
			var h: float = height_local(lx, lz)
			if h < 1.3 or h > 17.0:
				continue
			if noise.settlement_mask(wx, wz) > 0.02:
				continue
			if noise.get_path_amount(wx, wz) > 0.05:
				continue
			var ny: float = normal_y_local(lx, lz)
			var base := Vector3(lx, h - 0.15, lz)
			var tint := Color(tint_v * rng.randf_range(0.92, 1.08), tint_v, tint_v * rng.randf_range(0.85, 1.05), 1.0)

			# Steep ground gets boulders instead of trees
			if ny < 0.82:
				if roll < 0.35:
					var rs: float = rng.randf_range(0.8, 2.2)
					_add_rock(rock_x, rock_t, base, yaw, rs, rng)
				continue

			var f: float = noise.get_forest_density(wx, wz, h)
			var density: float = maxf(f * 0.92, 0.04 if h < 9.0 else 0.0)
			if roll < density:
				var temp: float = noise.get_temperature(wx, wz)
				var moisture: float = noise.get_moisture(wx, wz)
				var species: String = "broadleaf"
				if h > 12.0 and temp < 0.05:
					species = "pine" if roll2 < 0.72 else "deadwood"
				elif h > 8.5 or temp < -0.12:
					species = "pine" if roll2 < 0.78 else "redwood"
				elif moisture > 0.28:
					species = ["willow", "jungle", "baobab", "broadleaf"][rng.randi_range(0, 3)]
				elif moisture < -0.22:
					species = "baobab" if roll2 < 0.32 else ("cherry" if roll2 < 0.48 else "broadleaf")
				else:
					species = ["broadleaf", "cherry", "pine", "willow"][rng.randi_range(0, 3)]
				# Regional flora gives each territory a distinct silhouette at ground level.
				var region_name := noise.get_region_name(wx, wz)
				match region_name:
					"Greenveil Rainforest":
						species = "jungle" if roll2 < 0.72 else "redwood"
					"Thornwild Jungle":
						species = "jungle" if roll2 < 0.82 else "baobab"
					"Frostveil Continent":
						species = "pine" if roll2 < 0.72 else "deadwood"
					"Cinderwake Continent":
						species = "deadwood" if roll2 < 0.68 else "baobab"
					"Whispering Woods":
						species = "redwood" if roll2 < 0.30 else ("willow" if roll2 < 0.62 else "broadleaf")
					"Mirefen Wetlands":
						species = "willow" if roll2 < 0.68 else "jungle"
					"Mirrorwater Basin":
						species = "willow" if roll2 < 0.58 else "cherry"
					"Amberleaf Glade":
						species = "cherry" if roll2 < 0.64 else "willow"
					"Ironback Range":
						species = "pine" if roll2 < 0.78 else "deadwood"
				var giant_roll: float = rng.randf()
				var scale_value: float = rng.randf_range(0.82, 1.42)
				# Keep the immediate village sightline clear of world-tree trunks.
				var near_village: bool = Vector2(wx, wz).length() < 95.0
				if giant_roll < 0.045 and not near_village:
					species = "redwood" if moisture > -0.1 else "baobab"
					scale_value = rng.randf_range(1.6, 2.35)
				elif giant_roll < 0.13:
					scale_value = rng.randf_range(1.35, 1.8)
				var xf := Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * scale_value), base)
				tree_x[species].append(xf)
				tree_t[species].append(tint)
				var tc := CollisionShape3D.new()
				var trunk_shape := CylinderShape3D.new()
				var trunk_radius := 0.38
				var trunk_height := 6.0
				if species == "redwood": trunk_radius = 0.95; trunk_height = 18.0
				elif species == "baobab": trunk_radius = 1.25; trunk_height = 5.5
				elif species == "pine": trunk_radius = 0.36; trunk_height = 6.5
				elif species == "willow": trunk_radius = 0.38; trunk_height = 4.2
				elif species == "jungle": trunk_radius = 0.58; trunk_height = 6.0
				elif species == "cherry": trunk_radius = 0.30; trunk_height = 4.0
				elif species == "deadwood": trunk_radius = 0.35; trunk_height = 4.5
				trunk_shape.radius = trunk_radius * scale_value
				trunk_shape.height = trunk_height * scale_value
				tc.shape = trunk_shape
				tc.position = Vector3(lx, h + trunk_shape.height * 0.5, lz)
				add_child(tc)
			elif roll < density + 0.12 and f > 0.15:
				var bx := Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * rng.randf_range(0.8, 1.5)), base)
				bush_x.append(bx)
				bush_t.append(tint)
			elif roll > 0.965 or (h > 9.0 and roll > 0.9):
				_add_rock(rock_x, rock_t, base, yaw, rng.randf_range(0.6, 1.8), rng)

	for species in tree_species:
		var species_transforms: Array[Transform3D] = tree_x[species]
		var species_tints: PackedColorArray = tree_t[species]
		_attach(species, species_transforms, species_tints, 520.0, true)
	_attach("bush", bush_x, bush_t, 130.0, false)
	_attach("rock", rock_x, rock_t, 300.0, true)
	_build_regional_landmarks(rng, size)
	_build_landscape_features(rng, size)
	_build_chunk_resources(rng, size)
	_build_ground_detail(rng, size)
	_build_elyndor_biome_detail(rng, size)
	_build_riverbank_detail(rng, size)
	_build_roadside_detail(rng, size)
	# Paths are painted by the terrain shader at a much finer scale than the old
	# flat road ribbon, which caused z-fighting and a visible hand-drawn band.
	# _build_road_surface(size)


# Ground-level detail: shoreline pebbles and reeds, forest ferns, fallen logs,
# stumps and scattered stones. Placed on a coarse grid so the extra MultiMeshes
# stay cheap while the ground no longer reads as a bare green sheet.
func _build_ground_detail(rng: RandomNumberGenerator, size: float) -> void:
	var pebble_x: Array[Transform3D] = []
	var pebble_t := PackedColorArray()
	var reed_x: Array[Transform3D] = []
	var reed_t := PackedColorArray()
	var fern_x: Array[Transform3D] = []
	var fern_t := PackedColorArray()
	var log_x: Array[Transform3D] = []
	var log_t := PackedColorArray()
	var stump_x: Array[Transform3D] = []
	var stump_t := PackedColorArray()
	var cell := 7.5
	var n: int = int(ceil(size / cell))
	for cz in range(n):
		for cx in range(n):
			var lx: float = (float(cx) + rng.randf_range(0.15, 0.85)) * cell
			var lz: float = (float(cz) + rng.randf_range(0.15, 0.85)) * cell
			if lx >= size or lz >= size:
				continue
			var h: float = height_local(lx, lz)
			if h < 0.30:
				continue
			var ny: float = normal_y_local(lx, lz)
			if ny < 0.78:
				continue
			var wx: float = _origin.x + lx
			var wz: float = _origin.z + lz
			if noise.settlement_mask(wx, wz) > 0.03 or noise.get_path_amount(wx, wz) > 0.06:
				continue
			var gc: Color = color_local(lx, lz)
			var moisture: float = noise.get_moisture(wx, wz)
			var forest: float = noise.get_forest_density(wx, wz, h)
			var base := Vector3(lx, h - 0.02, lz)
			var yaw: float = rng.randf() * TAU

			# Shoreline: rounded stones and reed beds.
			if h < 2.7:
				if rng.randf() < 0.50:
					var s: float = rng.randf_range(0.55, 1.35)
					pebble_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * s), base))
					var v: float = rng.randf_range(0.82, 1.12)
					pebble_t.append(Color(v, v * 0.97, v * 0.92, 1.0))
				if h < 2.05 and moisture > -0.08 and rng.randf() < 0.38:
					var rs: float = rng.randf_range(0.85, 1.5)
					reed_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * rs), base))
					reed_t.append(Color(clampf(gc.r * 1.5, 0.35, 1.35), clampf(gc.g * 1.8, 0.45, 1.5), clampf(gc.b * 1.4, 0.3, 1.2), 1.0))

			# Forest floor: ferns, deadfall and the occasional stump.
			if forest > 0.28 and h > 2.0:
				if rng.randf() < 0.55:
					var fs: float = rng.randf_range(0.75, 1.45)
					fern_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * fs), base))
					fern_t.append(Color(clampf(gc.r * 1.45, 0.35, 1.3), clampf(gc.g * 1.7, 0.45, 1.45), clampf(gc.b * 1.3, 0.3, 1.15), 1.0))
				if rng.randf() < 0.030:
					var ls: float = rng.randf_range(0.75, 1.30)
					log_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ls), base))
					var lv: float = rng.randf_range(0.82, 1.05)
					log_t.append(Color(lv, lv * 0.97, lv * 0.92, 1.0))
				elif rng.randf() < 0.028:
					var ss: float = rng.randf_range(0.75, 1.20)
					stump_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ss), base))
					var sv: float = rng.randf_range(0.82, 1.05)
					stump_t.append(Color(sv, sv * 0.97, sv * 0.92, 1.0))
				if rng.randf() < 0.07:
					var ps: float = rng.randf_range(0.5, 1.1)
					pebble_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ps), base))
					var pv: float = rng.randf_range(0.75, 1.0)
					pebble_t.append(Color(pv, pv * 0.98, pv * 0.94, 1.0))
			elif ny > 0.92 and rng.randf() < 0.055:
				var ms: float = rng.randf_range(0.45, 1.0)
				pebble_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ms), base))
				var mv: float = rng.randf_range(0.78, 1.05)
				pebble_t.append(Color(mv, mv * 0.97, mv * 0.93, 1.0))

	_attach("pebble", pebble_x, pebble_t, 48.0, false)
	_attach("reed", reed_x, reed_t, 78.0, false)
	_attach("fern", fern_x, fern_t, 62.0, false)
	_attach("log", log_x, log_t, 90.0, true)
	_attach("stump", stump_x, stump_t, 78.0, true)



# Elyndor's first-exploration ring receives a denser, hand-authored-feeling
# ground layer: meadow flowers, woodland fungi, fern beds and scattered stones.
# Deterministic chunk seeds keep the same details after unload/reload.
func _build_elyndor_biome_detail(rng: RandomNumberGenerator, size: float) -> void:
	var center := Vector2(_origin.x + size * 0.5, _origin.z + size * 0.5)
	if center.distance_to(TerrainNoise.VILLAGE_CENTER) > 185.0:
		return
	var flower_x: Array[Transform3D] = []
	var flower_t := PackedColorArray()
	var mushroom_x: Array[Transform3D] = []
	var mushroom_t := PackedColorArray()
	var fern_x: Array[Transform3D] = []
	var fern_t := PackedColorArray()
	var stone_x: Array[Transform3D] = []
	var stone_t := PackedColorArray()
	var cell := 6.0
	var n := int(ceil(size / cell))
	var flower_colors: Array[Color] = [Color(0.96, 0.82, 0.48), Color(0.82, 0.48, 0.58), Color(0.66, 0.62, 0.88), Color(0.92, 0.90, 0.76)]
	for cz in range(n):
		for cx in range(n):
			var lx := (float(cx) + rng.randf_range(0.12, 0.88)) * cell
			var lz := (float(cz) + rng.randf_range(0.12, 0.88)) * cell
			if lx >= size or lz >= size:
				continue
			var wx := _origin.x + lx
			var wz := _origin.z + lz
			var h := height_local(lx, lz)
			if h < 1.2 or h > 12.0 or normal_y_local(lx, lz) < 0.84:
				continue
			if noise.settlement_mask(wx, wz) > 0.02 or noise.get_path_amount(wx, wz) > 0.10:
				continue
			var forest := noise.get_forest_density(wx, wz, h)
			var biome := noise.get_biome(wx, wz, h)
			var base := Vector3(lx, h - 0.015, lz)
			var yaw := rng.randf() * TAU
			if forest > 0.22 and rng.randf() < 0.48:
				var fs := rng.randf_range(0.75, 1.35)
				fern_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * fs), base))
				fern_t.append(Color(0.78, rng.randf_range(0.88, 1.12), 0.76, 1.0))
				if rng.randf() < 0.12:
					var ms := rng.randf_range(0.55, 0.95)
					mushroom_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ms), base))
					mushroom_t.append(Color(0.95, rng.randf_range(0.58, 0.9), 0.58, 1.0))
			elif biome == TerrainNoise.Biome.PLAINS or biome == TerrainNoise.Biome.AUTUMN_WOOD:
				if rng.randf() < 0.28:
					var fs := rng.randf_range(0.65, 1.2)
					flower_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * fs), base))
					flower_t.append(flower_colors[rng.randi_range(0, flower_colors.size() - 1)])
			if rng.randf() < 0.075:
				var rs := rng.randf_range(0.45, 0.9)
				stone_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * rs), base))
				var shade := rng.randf_range(0.78, 1.08)
				stone_t.append(Color(shade, shade * 0.98, shade * 0.94, 1.0))
	_attach("flower", flower_x, flower_t, 42.0, false)
	_attach("mushroom", mushroom_x, mushroom_t, 32.0, false)
	_attach("fern", fern_x, fern_t, 54.0, false)
	_attach("pebble", stone_x, stone_t, 38.0, false)

# The Heartlands river gets visible bank dressing in the same streamed chunks
# as its terrain: reed clusters on the wet edge and rounded stones above water.
func _build_riverbank_detail(rng: RandomNumberGenerator, size: float) -> void:
	var reeds: Array[Transform3D] = []
	var reed_tints := PackedColorArray()
	var stones: Array[Transform3D] = []
	var stone_tints := PackedColorArray()
	var cell := 5.0
	var n := int(ceil(size / cell))
	for cz in range(n):
		for cx in range(n):
			var lx := (float(cx) + rng.randf_range(0.18, 0.82)) * cell
			var lz := (float(cz) + rng.randf_range(0.18, 0.82)) * cell
			if lx >= size or lz >= size:
				continue
			var wx := _origin.x + lx
			var wz := _origin.z + lz
			if wz < -12.0 or wz > 102.0:
				continue
			var river_edge := absf(wx - 42.0)
			if river_edge < 4.8 or river_edge > 10.5:
				continue
			if noise.get_path_amount(wx, wz) > 0.05:
				continue
			var h := height_local(lx, lz)
			if h < 0.15 or h > 3.8 or normal_y_local(lx, lz) < 0.84:
				continue
			var base := Vector3(lx, h - 0.015, lz)
			var yaw := rng.randf() * TAU
			if rng.randf() < 0.58:
				var rs := rng.randf_range(0.75, 1.35)
				reeds.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * rs), base))
				reed_tints.append(Color(0.82, rng.randf_range(0.92, 1.12), 0.72, 1.0))
			else:
				var ss := rng.randf_range(0.45, 1.05)
				stones.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * ss), base))
				var shade := rng.randf_range(0.72, 1.0)
				stone_tints.append(Color(shade, shade * 0.98, shade * 0.94, 1.0))
	_attach("reed", reeds, reed_tints, 72.0, false)
	_attach("pebble", stones, stone_tints, 64.0, false)

# Small verge stones make the shader-painted trade paths read as maintained
# routes through grass rather than bare procedural strips.
func _build_roadside_detail(rng: RandomNumberGenerator, size: float) -> void:
	var transforms: Array[Transform3D] = []
	var tints := PackedColorArray()
	var candidates: Array[Vector3] = []
	var cell := 6.5
	var n := int(ceil(size / cell))
	for cz in range(n):
		for cx in range(n):
			var lx := (float(cx) + rng.randf()) * cell
			var lz := (float(cz) + rng.randf()) * cell
			if lx >= size or lz >= size:
				continue
			var wx := _origin.x + lx
			var wz := _origin.z + lz
			var path_amount := noise.get_path_amount(wx, wz)
			if path_amount < 0.12 or path_amount > 0.68:
				continue
			var h := height_local(lx, lz)
			if h < 1.0 or normal_y_local(lx, lz) < 0.86:
				continue
			if candidates.size() < 8 and rng.randf() < 0.22:
				candidates.append(Vector3(lx, h - 0.03, lz))
			if rng.randf() > 0.24:
				continue
			var scale_value := rng.randf_range(0.38, 0.72)
			transforms.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * scale_value), Vector3(lx, h - 0.01, lz)))
			var shade := rng.randf_range(0.76, 1.02)
			tints.append(Color(shade, shade * 0.98, shade * 0.93, 1.0))
	_attach("pebble", transforms, tints, 44.0, false)
	# Occasional rune-carved waystones mark the maintained trade routes.
	if not candidates.is_empty() and rng.randf() < 0.38:
		var waystones: Array[Transform3D] = []
		var way_tints := PackedColorArray()
		var p: Vector3 = candidates[rng.randi() % candidates.size()]
		waystones.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.85, 1.15)), p))
		way_tints.append(Color(1, 1, 1, 1))
		_attach("waystone", waystones, way_tints, 95.0, true)


func _build_road_surface(size: float) -> void:
	# Physical dirt/cobble ribbon follows the same authored path field painted by terrain.
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var indices := PackedInt32Array()
	var cell := 2.0
	var steps := int(ceil(size / cell))
	for z in range(steps):
		for x in range(steps):
			var lx := float(x) * cell + cell * 0.5
			var lz := float(z) * cell + cell * 0.5
			var wx := _origin.x + lx
			var wz := _origin.z + lz
			if noise.get_path_amount(wx, wz) < 0.32:
				continue
			var start := verts.size()
			var points := [Vector2(float(x) * cell, float(z) * cell), Vector2(minf(size, float(x + 1) * cell), float(z) * cell), Vector2(float(x) * cell, minf(size, float(z + 1) * cell)), Vector2(minf(size, float(x + 1) * cell), minf(size, float(z + 1) * cell))]
			for point in points:
				var h := height_local(point.x, point.y) + 0.045
				verts.append(Vector3(point.x, h, point.y))
				norms.append(Vector3.UP)
				cols.append(Color(0.34, 0.27, 0.18, 1.0))
			indices.append_array(PackedInt32Array([start, start + 2, start + 1, start + 1, start + 2, start + 3]))
	if verts.is_empty():
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = indices
	var road_mesh := ArrayMesh.new()
	road_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var road := MeshInstance3D.new()
	road.name = "RoadSurface"
	road.mesh = road_mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.32, 0.25, 0.17)
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	road.material_override = mat
	road.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(road)

func _build_chunk_resources(rng: RandomNumberGenerator, size: float) -> void:
	# Resource nodes stream with the terrain, so distant biomes remain gatherable
	# instead of the world becoming empty after leaving the starting valley.
	var center := Vector2(_origin.x + size * 0.5, _origin.z + size * 0.5)
	if center.distance_to(TerrainNoise.VILLAGE_CENTER) < 82.0:
		return # The authored starting region has its own carefully placed resource fields.
	var placed := 0
	var target := rng.randi_range(2, 4)
	for attempt in range(24):
		if placed >= target:
			break
		var lx := rng.randf_range(4.0, size - 4.0)
		var lz := rng.randf_range(4.0, size - 4.0)
		var wx := _origin.x + lx
		var wz := _origin.z + lz
		var h := height_local(lx, lz)
		if h < 0.8 or normal_y_local(lx, lz) < 0.72 or noise.settlement_mask(wx, wz) > 0.02 or noise.get_path_amount(wx, wz) > 0.08:
			continue
		var biome := noise.get_biome(wx, wz, h)
		var kind := "herb"
		match biome:
			TerrainNoise.Biome.MOUNTAIN, TerrainNoise.Biome.SNOW, TerrainNoise.Biome.TUNDRA:
				kind = ["ore", "silver", "gold", "sulfur", "crystal"][rng.randi_range(0, 4)]
			TerrainNoise.Biome.TAIGA:
				kind = ["pine_resin", "mushroom", "herb", "iron_ore"][rng.randi_range(0, 3)]
			TerrainNoise.Biome.SAVANNA:
				kind = ["dry_herb", "hide", "copper", "salt"][rng.randi_range(0, 3)]
			TerrainNoise.Biome.MEDITERRANEAN:
				kind = ["olive", "herb", "berry", "copper"][rng.randi_range(0, 3)]
			TerrainNoise.Biome.BEACH:
				kind = "salt" if rng.randf() < 0.55 else "copper"
			TerrainNoise.Biome.FOREST, TerrainNoise.Biome.AUTUMN_WOOD:
				kind = ["mushroom", "berry", "herb", "tree_willow", "amber"][rng.randi_range(0, 4)]
			TerrainNoise.Biome.RAINFOREST:
				kind = ["orchid", "mushroom", "tree_jungle", "amber", "herb"][rng.randi_range(0, 4)]
			TerrainNoise.Biome.JUNGLE:
				kind = ["orchid", "mushroom", "tree_jungle", "berry", "herb"][rng.randi_range(0, 4)]
			TerrainNoise.Biome.SWAMP:
				kind = ["peat", "orchid", "mushroom", "tree_willow"][rng.randi_range(0, 3)]
			TerrainNoise.Biome.DESERT:
				kind = "cactus" if rng.randf() < 0.72 else "salt"
			TerrainNoise.Biome.VOLCANIC:
				kind = "obsidian" if rng.randf() < 0.6 else "sulfur"
			TerrainNoise.Biome.HILLS:
				kind = ["ore", "copper", "silver", "tree_redwood"][rng.randi_range(0, 3)]
			_:
				kind = "berry" if rng.randf() < 0.5 else "herb"
		var node := ResourceNode.new()
		node.kind = kind
		node.position = Vector3(lx, h, lz)
		add_child(node)
		placed += 1



# Landmark pass: hero trees, layered escarpments, cave mouths, waterfalls and
# low-cost distant mountain silhouettes. Deterministic per chunk for streaming.
func _build_landscape_features(rng: RandomNumberGenerator, size: float) -> void:
	var feature_root := Node3D.new()
	feature_root.name = "LandscapeFeatures"
	add_child(feature_root)
	# A small number of fully articulated hero trees break up repeated forest rows.
	if rng.randf() < 0.42:
		var lx := rng.randf_range(10.0, size - 10.0)
		var lz := rng.randf_range(10.0, size - 10.0)
		var h := height_local(lx, lz)
		var hero_wx := _origin.x + lx
		var hero_wz := _origin.z + lz
		if normal_y_local(lx, lz) > 0.88 and h > 1.5 and h < 13.0 and Vector2(hero_wx, hero_wz).length() > 80.0 and noise.get_path_amount(hero_wx, hero_wz) < 0.05 and noise.get_forest_density(hero_wx, hero_wz, h) > 0.18:
			var hero := HeroTreeRig.new()
			var moisture := noise.get_moisture(hero_wx, hero_wz)
			var species := "redwood" if moisture > -0.05 else "baobab"
			if h > 10.0: species = "pine"
			hero.configure(species, rng.randf_range(1.0, 1.7))
			hero.position = Vector3(lx, h, lz)
			feature_root.add_child(hero)
	# Steep slopes receive stacked cliff shelves that follow the actual height field.
	var steep_candidates: Array[Vector2] = []
	for i in range(18):
		var px := rng.randf_range(5.0, size - 5.0)
		var pz := rng.randf_range(5.0, size - 5.0)
		if normal_y_local(px, pz) < 0.72 and noise.get_path_amount(_origin.x + px, _origin.z + pz) < 0.05:
			steep_candidates.append(Vector2(px, pz))
	for p in steep_candidates.slice(0, mini(steep_candidates.size(), 4)):
		_add_cliff_shelf(feature_root, p.x, p.y, rng)
	# Cave mouths are rare, readable landmarks on the side of a hill.
	if rng.randf() < 0.16:
		var cx := rng.randf_range(8.0, size - 8.0)
		var cz := rng.randf_range(8.0, size - 8.0)
		if normal_y_local(cx, cz) < 0.88 and noise.get_path_amount(_origin.x + cx, _origin.z + cz) < 0.05:
			_add_cave_mouth(feature_root, cx, cz, rng)
	# Major waterfalls are authored against known river sources and basins by
	# EnvironmentalExploration. Do not place random waterfall cards from a local
	# five-metre height sample: that creates disconnected sheets on arbitrary slopes.
	# Distant mountain silhouettes are supplied by the streamed terrain heightfield.
	# Avoid detached low-poly prism peaks that looked like floating props.

func _add_cliff_shelf(root: Node3D, x: float, z: float, rng: RandomNumberGenerator) -> void:
	var h := height_local(x, z)
	for tier in range(3):
		var rock := MeshInstance3D.new()
		rock.mesh = VegetationKit.get_mesh("rock")
		var sx := rng.randf_range(1.55, 2.7)
		var sy := rng.randf_range(1.25, 2.0)
		var sz := rng.randf_range(1.5, 2.65)
		rock.scale = Vector3(sx, sy, sz)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.46, 0.43, 0.38).lerp(Color(0.30, 0.28, 0.25), rng.randf() * 0.7)
		mat.roughness = 0.98
		rock.material_override = mat
		var rock_position := Vector3(x + rng.randf_range(-1.2, 1.2), 0.0, z + float(tier) * 0.8)
		# Seat each tier on the terrain at its own offset so shelves hug the slope
		# instead of floating on a flat plane above it.
		rock_position.y = height_local(rock_position.x, rock_position.z) - sy * 0.55 + float(tier) * 0.45
		if noise.get_path_amount(_origin.x + rock_position.x, _origin.z + rock_position.z) > 0.04:
			continue
		rock.position = rock_position
		rock.rotation = Vector3(rng.randf_range(-0.12, 0.12), rng.randf() * TAU, rng.randf_range(-0.16, 0.16))
		root.add_child(rock)
		var rock_body := StaticBody3D.new()
		rock_body.name = "CliffRockCollision"
		rock_body.position = rock_position
		rock_body.rotation = rock.rotation
		rock_body.collision_layer = Constants.LAYER_WORLD
		rock_body.collision_mask = 0
		var rock_collision := CollisionShape3D.new()
		var rock_shape := BoxShape3D.new()
		rock_shape.size = Vector3(sx * 1.35, sy * 0.9, sz * 1.35)
		rock_collision.shape = rock_shape
		rock_collision.position.y = sy * 0.38
		rock_body.add_child(rock_collision)
		root.add_child(rock_body)

func _add_cave_mouth(root: Node3D, x: float, z: float, rng: RandomNumberGenerator) -> void:
	var cave := Node3D.new()
	cave.name = "CaveEntrance"
	cave.position = Vector3(x, height_local(x, z) + 0.05, z)
	cave.rotation.y = rng.randf() * TAU
	root.add_child(cave)
	var dark := MeshInstance3D.new()
	var opening := SphereMesh.new()
	opening.radius = 2.0
	opening.height = 3.8
	dark.mesh = opening
	var black := StandardMaterial3D.new()
	black.albedo_color = Color(0.012, 0.016, 0.022)
	black.roughness = 1.0
	dark.material_override = black
	dark.position.y = 1.7
	dark.scale = Vector3(1.0, 0.82, 0.24)
	cave.add_child(dark)
	for side in [-1.0, 1.0]:
		var pillar := MeshInstance3D.new()
		var pm := CylinderMesh.new()
		pm.top_radius = 0.28
		pm.bottom_radius = 0.72
		pm.height = 3.2
		pillar.mesh = pm
		pillar.position = Vector3(side * 1.8, 1.45, 0.0)
		pillar.material_override = _landmark_rock_material(rng)
		cave.add_child(pillar)
	var lintel := MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(4.0, 0.8, 1.0)
	lintel.mesh = lm
	lintel.position = Vector3(0, 3.25, 0)
	lintel.material_override = _landmark_rock_material(rng)
	cave.add_child(lintel)

func _add_distant_peak(root: Node3D, x: float, z: float, rng: RandomNumberGenerator) -> void:
	var peak := MeshInstance3D.new()
	var prism := PrismMesh.new()
	prism.size = Vector3(rng.randf_range(16.0, 26.0), rng.randf_range(20.0, 38.0), rng.randf_range(13.0, 22.0))
	peak.mesh = prism
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.29, 0.35, 0.40, 0.78)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 1.0
	peak.material_override = mat
	peak.position = Vector3(x, height_local(x, z) + prism.size.y * 0.38, z)
	peak.rotation.y = rng.randf() * TAU
	peak.visibility_range_begin = 45.0
	peak.visibility_range_end = 260.0
	peak.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	root.add_child(peak)

func _landmark_rock_material(rng: RandomNumberGenerator) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.27, 0.28, 0.27).lerp(Color(0.46, 0.41, 0.34), rng.randf() * 0.7)
	mat.roughness = 0.98
	return mat

func _build_regional_landmarks(rng: RandomNumberGenerator, size: float) -> void:
	# Small biome-specific silhouettes break up the repeated tree/rock palette.
	var local_center: Vector2 = Vector2(_origin.x + size * 0.5, _origin.z + size * 0.5)
	var kind: String = "meadow"
	if local_center.y < -72.0 and local_center.x < -25.0:
		kind = "mountain"
	elif local_center.x > 28.0 and local_center.y > -35.0:
		kind = "coast"
	elif local_center.x < -42.0 and local_center.y > -65.0:
		kind = "forest"
	elif local_center.x > 25.0 and local_center.y < -35.0:
		kind = "spire"
	var transforms: Array[Transform3D] = []
	var colors := PackedColorArray()
	var count: int = 0
	match kind:
		"mountain": count = 0 # The actual mountain range is generated by the shared heightfield.
		"coast": count = 4
		"forest": count = 5
		"spire": count = 6
		_: count = 2
	for i in range(count):
		var lx: float = rng.randf_range(5.0, size - 5.0)
		var lz: float = rng.randf_range(5.0, size - 5.0)
		var h: float = height_local(lx, lz)
		if h < 1.5 or h > 17.0 or noise.settlement_mask(_origin.x + lx, _origin.z + lz) > 0.02 or noise.get_path_amount(_origin.x + lx, _origin.z + lz) > 0.05:
			continue
		var yaw: float = rng.randf() * TAU
		var scl: Vector3 = Vector3.ONE
		var tint: Color = Color(0.5, 0.5, 0.5)
		match kind:
			"mountain":
				scl = Vector3(rng.randf_range(2.0, 4.2), rng.randf_range(9.0, 18.0), rng.randf_range(2.0, 4.2))
				tint = Color(0.42, 0.48, 0.53)
			"coast":
				scl = Vector3(1.6, 0.25, 0.65)
				tint = Color(0.66, 0.59, 0.43)
			"forest":
				scl = Vector3(0.55, rng.randf_range(2.0, 3.8), 0.55)
				tint = Color(0.26, 0.31, 0.24)
			"spire":
				scl = Vector3(0.38, rng.randf_range(1.0, 1.9), 0.38)
				tint = Color(0.42, 0.62, 0.9)
			_: 
				scl = Vector3(0.55, 0.65, 0.55)
				tint = Color(0.55, 0.65, 0.35)
		var xf := Transform3D(Basis(Vector3.UP, yaw).scaled(scl), Vector3(lx, h + scl.y * 0.55, lz))
		transforms.append(xf)
		colors.append(tint)
	if transforms.is_empty():
		return
	var mesh: Mesh
	if kind == "coast":
		var driftwood := BoxMesh.new()
		driftwood.size = Vector3(1.0, 0.16, 0.22)
		mesh = driftwood
	elif kind == "mountain":
		var peak := PrismMesh.new()
		peak.size = Vector3(1.2, 5.0, 1.2)
		mesh = peak
	else:
		var crystal := PrismMesh.new()
		crystal.size = Vector3(0.7, 1.0, 0.7)
		mesh = crystal
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = mesh
	mm.instance_count = transforms.size()
	for i in range(transforms.size()):
		mm.set_instance_transform(i, transforms[i])
		mm.set_instance_color(i, colors[i])
	var mi := MultiMeshInstance3D.new()
	mi.name = "Regional_%s_Landmarks" % kind.capitalize()
	mi.multimesh = mm
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.78
	if kind == "spire":
		mat.emission_enabled = true
		mat.emission = Color(0.16, 0.28, 0.5)
		mat.emission_energy_multiplier = 0.45
	mi.material_override = mat
	add_child(mi)

func _add_rock(xs: Array[Transform3D], ts: PackedColorArray, base: Vector3, yaw: float, rs: float, rng: RandomNumberGenerator) -> void:
	var b := Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, rng.randf_range(-0.15, 0.15))
	b = b.scaled(Vector3(rs, rs * rng.randf_range(0.7, 1.1), rs * rng.randf_range(0.8, 1.2)))
	var xf := Transform3D(b, base + Vector3(0, -0.12 * rs, 0))
	var v: float = rng.randf_range(0.85, 1.15)
	var tint := Color(v, v, v * 0.98, 1.0)
	# A few large boulders per chunk are real rigid masses instead of scenery,
	# so they tumble downhill or get shoved when something hits them.
	if _loose_rocks < 4 and rs >= 0.9:
		_loose_rocks += 1
		_spawn_loose_rock(xf, rs, tint)
		return
	# Static boulders sit deeper so their downhill edge never hovers over a slope.
	xs.append(Transform3D(b, base + Vector3(0, -0.32 * rs, 0)))
	ts.append(tint)
	var sc := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = maxf(0.28, 0.72 * rs)
	sc.shape = sp
	sc.position = base + Vector3(0, 0.34 * rs, 0)
	add_child(sc)

func _spawn_loose_rock(xf: Transform3D, rs: float, tint: Color) -> void:
	var radius: float = maxf(0.3, 0.62 * rs)
	var rb := RigidBody3D.new()
	rb.collision_layer = Constants.LAYER_WORLD
	rb.collision_mask = Constants.LAYER_WORLD | Constants.LAYER_PLAYER | Constants.LAYER_NPC | Constants.LAYER_CREATURE
	rb.linear_damp = 0.2
	rb.angular_damp = 0.35
	rb.continuous_cd = true
	var pm := PhysicsMaterial.new()
	pm.friction = 1.0
	pm.bounce = 0.02
	rb.physics_material_override = pm
	var cs := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = radius
	cs.shape = sphere
	rb.add_child(cs)
	rb.mass = maxf(70.0, 90.0 * rs * rs * rs)
	var mesh: MultiMeshInstance3D = VegetationKit.make_multimesh("rock",
		[Transform3D(xf.basis, Vector3(0, -0.12 * rs - radius, 0))], PackedColorArray([tint]), 0.0, true)
	rb.add_child(mesh)
	add_child(rb)
	rb.position = xf.origin + Vector3(0, radius + 0.12 * rs + 0.16, 0)

func _attach(kind: String, xs: Array[Transform3D], ts: PackedColorArray, vis_end: float, shadows: bool) -> void:
	if xs.is_empty():
		return
	var mmi := VegetationKit.make_multimesh(kind, xs, ts, vis_end, shadows)
	mmi.name = kind.capitalize()
	add_child(mmi)

# ---------------------------------------------------------------------------
# Grass + flowers (several small bands so no frame pays for the whole chunk)
# ---------------------------------------------------------------------------
func _build_grass_band(band: int) -> void:
	if _grass_rng == null:
		_grass_rng = RandomNumberGenerator.new()
		_grass_rng.seed = hash(Vector3i(chunk_pos.x * 31 + 7, chunk_pos.y * 17 + 3, noise.world_seed))
	var size: float = float(Constants.CHUNK_SIZE)
	var n: int = int(ceil(size / GRASS_CELL))
	var rows_per_band: int = int(ceil(float(n) / float(GRASS_BANDS)))
	var z0: int = band * rows_per_band
	var z1: int = mini(z0 + rows_per_band, n)
	var rng: RandomNumberGenerator = _grass_rng
	var flower_palette: Array[Color] = [
		Color(1.0, 1.0, 1.0), Color(1.0, 0.85, 0.2), Color(0.95, 0.4, 0.55),
		Color(0.55, 0.45, 0.95), Color(1.0, 0.55, 0.2),
	]
	for cz in range(z0, z1):
		for cx in range(n):
			var lx: float = (float(cx) + rng.randf()) * GRASS_CELL
			var lz: float = (float(cz) + rng.randf()) * GRASS_CELL
			var roll: float = rng.randf()
			var yaw: float = rng.randf() * TAU
			var scl: float = rng.randf_range(0.55, 1.0)
			var jit: float = rng.randf_range(0.85, 1.15)
			if lx >= size or lz >= size:
				continue
			var h: float = height_local(lx, lz)
			if h < 1.15 or h > 11.5:
				continue
			var ny: float = normal_y_local(lx, lz)
			if ny < 0.80:
				continue
			var wx: float = _origin.x + lx
			var wz: float = _origin.z + lz
			var gc: Color = color_local(lx, lz)
			if gc.a > 0.3:
				continue  # on a path
			var p: float = 0.9 * smoothstep(1.15, 2.2, h) * smoothstep(0.80, 0.92, ny) * (1.0 - smoothstep(8.5, 11.5, h))
			if roll > p:
				continue
			var base := Vector3(lx, h - 0.02, lz)
			var tint := Color(clampf(gc.r * 2.0 * jit, 0.5, 1.6), clampf(gc.g * 1.9 * jit, 0.5, 1.6), clampf(gc.b * 2.0 * jit, 0.4, 1.4), 1.0)
			_grass_x.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3.ONE * scl), base))
			_grass_t.append(tint)
			# Occasional wildflower clump in meadows
			if rng.randf() < 0.05 and h > 1.8 and ny > 0.9:
				var fc: Color = flower_palette[rng.randi() % flower_palette.size()]
				for k in range(3):
					var off := Vector3(rng.randf_range(-0.35, 0.35), 0, rng.randf_range(-0.35, 0.35))
					var fb := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * rng.randf_range(0.9, 1.5))
					_flower_x.append(Transform3D(fb, base + off))
					_flower_t.append(fc)

func _finish_grass() -> void:
	_attach("grass", _grass_x, _grass_t, 58.0, false)
	_attach("flower", _flower_x, _flower_t, 48.0, false)
	_grass_x = []
	_grass_t = PackedColorArray()
	_flower_x = []
	_flower_t = PackedColorArray()
