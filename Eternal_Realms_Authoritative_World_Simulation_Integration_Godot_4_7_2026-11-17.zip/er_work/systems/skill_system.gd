# SkillSystem - Entropia-style progression, built around THIS game.
# * No player level. Every skill is a decimal value that only grows by USING it.
# * Gains slow down as a skill rises (diminishing returns).
# * Professions are weighted groups of skills - your "class" is whatever you actually do.
class_name SkillSystem
extends Node

signal skill_changed(skill_id: String, value: float, delta: float)
signal rank_up(skill_id: String, rank_name: String)
signal technique_discovered(technique_id: String, technique_name: String)

const SKILLS: Dictionary = {
	# Combat
	"swordsmanship": {"name": "Swordsmanship", "cat": "Combat", "desc": "Master one-handed and two-handed blades."},
	"axe_mastery": {"name": "Axe Mastery", "cat": "Combat", "desc": "Improve axe damage and unlock armour-breaking attacks."},
	"dagger_mastery": {"name": "Dagger Mastery", "cat": "Combat", "desc": "Improve dagger damage, critical strikes and quick attacks."},
	"spear_mastery": {"name": "Spear Mastery", "cat": "Combat", "desc": "Improve reach, thrust damage and control of space."},
	"blunt_mastery": {"name": "Blunt Weapon Mastery", "cat": "Combat", "desc": "Improve hammers, maces and stagger attacks."},
	"archery": {"name": "Archery", "cat": "Combat", "desc": "Improve bow damage, accuracy and ranged techniques."},
	"elemental_magic": {"name": "Elemental Magic", "cat": "Combat", "desc": "Improve elemental staves, wands and spell attacks."},
	"fire_affinity": {"name": "Fire Affinity", "cat": "Cultivation", "desc": "Develop heat, flame shaping and explosive force."},
	"water_affinity": {"name": "Water Affinity", "cat": "Cultivation", "desc": "Develop fluid control, healing and adaptability."},
	"wind_affinity": {"name": "Wind Affinity", "cat": "Cultivation", "desc": "Develop movement, pressure and ranged control."},
	"earth_affinity": {"name": "Earth Affinity", "cat": "Cultivation", "desc": "Develop stone shaping, stability and defence."},
	"lightning_affinity": {"name": "Lightning Affinity", "cat": "Cultivation", "desc": "Develop speed, conduction and focused bursts."},
	"ice_affinity": {"name": "Ice Affinity", "cat": "Cultivation", "desc": "Develop frost, restraint and precision."},
	"dual_wield": {"name": "Dual Wielding", "cat": "Combat", "desc": "Improve paired weapon techniques and off-hand control."},
	"precision": {"name": "Precision", "cat": "Combat", "desc": "Critical strike chance. Grows from landing hits."},
	"evasion": {"name": "Evasion", "cat": "Combat", "desc": "Chance to dodge blows. Grows when enemies attack you."},
	"vitality": {"name": "Vitality", "cat": "Combat", "desc": "Maximum health. Grows when you take punishment."},
	# Body & World
	"agility": {"name": "Agility", "cat": "Body", "desc": "Movement speed. Grows as you run and jump."},
	"stealth": {"name": "Stealth", "cat": "Body", "desc": "Reduce detection while moving quietly and using cover."},
	"exploration": {"name": "Exploration", "cat": "Body", "desc": "Discover places, walk far. Boosts discovery rewards."},
	# Gathering
	"mining": {"name": "Mining", "cat": "Gathering", "desc": "Success chance and yield when mining ore."},
	"woodcutting": {"name": "Woodcutting", "cat": "Gathering", "desc": "Success chance and yield when felling trees."},
	"herbalism": {"name": "Herbalism", "cat": "Gathering", "desc": "Success chance and yield when picking herbs."},
	"fishing": {"name": "Fishing", "cat": "Gathering", "desc": "Catch river and ocean fish near water."},
	"farming": {"name": "Farming", "cat": "Gathering", "desc": "Cultivate crops, tend plots and improve harvest quality."},
	"marine_lore": {"name": "Marine Lore", "cat": "Exploration", "desc": "Identify marine species, migration patterns and coastal resources."},
	"tracking": {"name": "Tracking", "cat": "Exploration", "desc": "Read animal tracks, direction, age and movement through the wilderness."},
	"archaeology": {"name": "Archaeology", "cat": "Wisdom & Knowledge", "desc": "Recover histories and artefacts by examining ruins and inscriptions."},
	"cooking": {"name": "Cooking", "cat": "Crafting", "desc": "Prepare food at a campfire for better meals."},
	"enchanting": {"name": "Enchanting", "cat": "Crafting", "desc": "Imbue gear with minor magic."},
	"swimming": {"name": "Swimming", "cat": "Body", "desc": "Move faster in water."},
	"shield": {"name": "Shield", "cat": "Combat", "desc": "Block and mitigate incoming blows."},
	"unarmed": {"name": "Unarmed", "cat": "Combat", "desc": "Fist fighting when no weapon is equipped."},
	"dungeon_delving": {"name": "Dungeon Delving", "cat": "Exploration", "desc": "Earned by exploring floors, finding secrets and surviving the labyrinth."},
	"monster_lore": {"name": "Monster Lore", "cat": "Combat", "desc": "Learn enemy weaknesses by defeating creatures in the depths."},
	"arcane_attunement": {"name": "Arcane Attunement", "cat": "Cultivation", "desc": "Sense and harmonise with ambient spiritual energy."},
	"cultivation": {"name": "Cultivation", "cat": "Cultivation", "desc": "Refine internal energy through controlled circulation and breakthrough practice."},
	"spiritual_sense": {"name": "Spiritual Sense", "cat": "Cultivation", "desc": "Notice hidden energy traces, formations and unusual presences."},
	# Mind and insight are earned through study, interpretation and meaningful choices.
	"wisdom": {"name": "Wisdom", "cat": "Wisdom & Knowledge", "desc": "Read situations, recognise patterns, weigh consequences and make sound judgements."},
	"knowledge": {"name": "Knowledge", "cat": "Wisdom & Knowledge", "desc": "Understand lore, languages, creatures, materials, techniques and ancient systems."},
	"observation": {"name": "Observation", "cat": "Wisdom & Knowledge", "desc": "Notice tracks, hidden mechanisms, enemy tells and details others overlook."},
	"appraisal": {"name": "Appraisal", "cat": "Wisdom & Knowledge", "desc": "Identify creatures, resources, quality, value and hidden properties by careful inspection."},
	"ancient_lore": {"name": "Ancient Lore", "cat": "Wisdom & Knowledge", "desc": "Interpret inscriptions, forgotten histories and lost cultivation methods."},
	"compassion": {"name": "Compassion", "cat": "Wisdom & Knowledge", "desc": "Earned by helping captives, protecting others and choosing aid over exploitation."},
	# Crafting
	"smithing": {"name": "Smithing", "cat": "Crafting", "desc": "Forging success and better item grades."},
	"alchemy": {"name": "Alchemy", "cat": "Crafting", "desc": "Brewing success and potion potency."},
	# Trade
	"bartering": {"name": "Bartering", "cat": "Trade", "desc": "Better prices when buying and selling."},
}

const CATEGORY_ORDER: Array = ["Combat", "Body", "Cultivation", "Gathering", "Crafting", "Trade", "Exploration", "Wisdom & Knowledge"]

const RANKS: Array = [
	[0.0, "Untrained"], [3.0, "Novice"], [10.0, "Apprentice"], [25.0, "Adept"],
	[50.0, "Expert"], [80.0, "Master"], [120.0, "Grandmaster"],
]

const PROFESSIONS: Dictionary = {
	"Swordsman": {"swordsmanship": 0.5, "precision": 0.3, "evasion": 0.2},
	"Survivor": {"vitality": 0.6, "evasion": 0.2, "agility": 0.2},
	"Miner": {"mining": 0.8, "vitality": 0.2},
	"Woodsman": {"woodcutting": 0.8, "agility": 0.2},
	"Herbalist": {"herbalism": 0.8, "alchemy": 0.2},
	"Blacksmith": {"smithing": 0.7, "mining": 0.3},
	"Alchemist": {"alchemy": 0.7, "herbalism": 0.3},
	"Merchant": {"bartering": 1.0},
	"Explorer": {"exploration": 0.6, "agility": 0.4},
	"Fisher": {"fishing": 0.8, "exploration": 0.2},
	"Farmer": {"farming": 0.8, "herbalism": 0.2},
	"Cook": {"cooking": 0.8, "herbalism": 0.2},
	"Enchanter": {"enchanting": 0.7, "alchemy": 0.3},
	"Guardian": {"shield": 0.6, "vitality": 0.4},
	"Berserker": {"axe_mastery": 0.6, "vitality": 0.2, "evasion": 0.2},
	"Duelist": {"dagger_mastery": 0.45, "dual_wield": 0.35, "precision": 0.2},
	"Lancer": {"spear_mastery": 0.7, "agility": 0.3},
	"Archer": {"archery": 0.7, "precision": 0.2, "agility": 0.1},
	"Battlemage": {"elemental_magic": 0.6, "arcane_attunement": 0.3, "vitality": 0.1},
	"Naturalist": {"tracking": 0.28, "marine_lore": 0.25, "observation": 0.22, "herbalism": 0.15, "exploration": 0.1},
	"Archaeologist": {"archaeology": 0.42, "ancient_lore": 0.28, "knowledge": 0.2, "wisdom": 0.1},
	"Appraiser": {"appraisal": 0.55, "observation": 0.25, "bartering": 0.2},
	"Spiritual Adept": {"cultivation": 0.4, "spiritual_sense": 0.25, "arcane_attunement": 0.2, "wisdom": 0.15},
}


# Cultivation is a slow discipline with many mutually distinct traditions.
# Progress is earned through the relevant play loop; no character class is forced.
const CULTIVATION_PATHS: Dictionary = {
	"body_refinement": {"name":"Body Refinement", "focus":"Vitality, endurance and close combat", "skills":["cultivation", "vitality", "unarmed"]},
	"sword_intent": {"name":"Sword Intent", "focus":"Precision, weapon flow and blade mastery", "skills":["cultivation", "swordsmanship", "precision"]},
	"elemental_core": {"name":"Elemental Core", "focus":"Elemental magic and arcane attunement", "skills":["cultivation", "elemental_magic", "arcane_attunement"]},
	"flame_path": {"name":"Crimson Flame Path", "focus":"Fire affinity, pressure and destructive release", "skills":["cultivation", "fire_affinity", "elemental_magic"]},
	"tide_path": {"name":"Azure Tide Path", "focus":"Water affinity, restoration and flowing defence", "skills":["cultivation", "water_affinity", "swimming"]},
	"gale_path": {"name":"Gale Path", "focus":"Wind affinity, movement and ranged control", "skills":["cultivation", "wind_affinity", "agility"]},
	"stone_path": {"name":"Mountain Root Path", "focus":"Earth affinity, endurance and stability", "skills":["cultivation", "earth_affinity", "vitality"]},
	"storm_path": {"name":"Storm Vein Path", "focus":"Lightning affinity, speed and focused power", "skills":["cultivation", "lightning_affinity", "precision"]},
	"frost_path": {"name":"Frost Lotus Path", "focus":"Ice affinity, control and precise technique", "skills":["cultivation", "ice_affinity", "observation"]},
	"spirit_sense": {"name":"Spirit Sense", "focus":"Perception, hidden energies and ancient knowledge", "skills":["cultivation", "spiritual_sense", "observation"]},
	"shadow_step": {"name":"Shadow Step", "focus":"Stealth, agility and dagger techniques", "skills":["cultivation", "stealth", "dagger_mastery"]},
	"nature_harmony": {"name":"Nature Harmony", "focus":"Herbalism, survival and living ecosystems", "skills":["cultivation", "herbalism", "tracking"]},
	"flowing_water": {"name":"Flowing Water", "focus":"Swimming, adaptability and defensive movement", "skills":["cultivation", "swimming", "evasion"]}
}

func cultivation_path_progress(path_id: String) -> float:
	if not CULTIVATION_PATHS.has(path_id):
		return 0.0
	var total: float = 0.0
	var ids: Array = CULTIVATION_PATHS[path_id]["skills"]
	for sid in ids:
		total += get_value(str(sid))
	return total / float(ids.size())

func available_cultivation_paths() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for path_id in CULTIVATION_PATHS.keys():
		var data: Dictionary = CULTIVATION_PATHS[path_id].duplicate(true)
		data["id"] = path_id
		data["progress"] = cultivation_path_progress(str(path_id))
		if float(data["progress"]) >= 0.5:
			out.append(data)
	return out

# Realm advancement is deliberately slow and uses real training plus meridian
# conditioning. It is not a level-up menu and never forces a single path.
const CULTIVATION_REALMS: Array[Dictionary] = [
	{"name":"Mortal Foundation", "cultivation":0.0, "meridians":0, "capacity":0.0},
	{"name":"Qi Gathering", "cultivation":2.0, "meridians":1, "capacity":8.0},
	{"name":"Foundation Establishment", "cultivation":8.0, "meridians":3, "capacity":14.0},
	{"name":"Core Formation", "cultivation":18.0, "meridians":5, "capacity":22.0},
	{"name":"Nascent Soul", "cultivation":32.0, "meridians":7, "capacity":32.0},
	{"name":"Soul Transformation", "cultivation":50.0, "meridians":8, "capacity":46.0},
	{"name":"Ascendant Immortal", "cultivation":85.0, "meridians":8, "capacity":64.0}
]
const REALM_LIFESPANS: Array[float] = [80.0, 120.0, 200.0, 500.0, 1000.0, 2500.0, INF]

const ELEMENTS: Array[String] = ["fire", "water", "wind", "earth", "lightning", "ice"]
const ELEMENT_SKILLS: Dictionary = {
	"fire":"fire_affinity", "water":"water_affinity", "wind":"wind_affinity",
	"earth":"earth_affinity", "lightning":"lightning_affinity", "ice":"ice_affinity"
}
const MERIDIAN_REQUIREMENTS: Dictionary = {
	"central_vessel":{"name":"Central Vessel", "skill":"cultivation", "threshold":2.0},
	"heart_meridian":{"name":"Heart Meridian", "skill":"fire_affinity", "threshold":2.0},
	"kidney_meridian":{"name":"Kidney Meridian", "skill":"water_affinity", "threshold":2.0},
	"lung_meridian":{"name":"Lung Meridian", "skill":"wind_affinity", "threshold":2.0},
	"spleen_meridian":{"name":"Spleen Meridian", "skill":"earth_affinity", "threshold":2.0},
	"thunder_gate":{"name":"Thunder Gate", "skill":"lightning_affinity", "threshold":2.0},
	"ice_marrow":{"name":"Ice Marrow Gate", "skill":"ice_affinity", "threshold":2.0},
	"spirit_gate":{"name":"Spirit Gate", "skill":"spiritual_sense", "threshold":3.0}
}
const ELEMENTAL_FORMS: Dictionary = {
	"fire":{"basic":"Ember Lance", "adept":"Cinder Serpent", "master":"Solar Rupture"},
	"water":{"basic":"Tidal Needle", "adept":"Rising Current", "master":"Moonwell Renewal"},
	"wind":{"basic":"Gale Edge", "adept":"Crosswind Spiral", "master":"Skybreaker Vortex"},
	"earth":{"basic":"Stone Spear", "adept":"Faultline Fist", "master":"Mountainheart Bastion"},
	"lightning":{"basic":"Spark Javelin", "adept":"Chain Arc", "master":"Storm Dragon"},
	"ice":{"basic":"Frost Shard", "adept":"Rime Bind", "master":"Winter Crown"}
}

const CULTIVATION_TECHNIQUES: Dictionary = {
	"still_mind": {"name":"Still-Mind Breathing", "skill":"cultivation", "threshold":2.0, "realm":1, "path":""},
	"iron_skin_breath": {"name":"Iron-Skin Breathing", "skill":"vitality", "threshold":3.0, "realm":1, "path":"body_refinement"},
	"flame_resonance": {"name":"Crimson Flame Resonance", "skill":"fire_affinity", "threshold":4.0, "realm":1, "path":"flame_path"},
	"tide_recovery": {"name":"Moon-Tide Recovery", "skill":"water_affinity", "threshold":4.0, "realm":1, "path":"tide_path"},
	"gale_footwork": {"name":"Gale-Step Footwork", "skill":"wind_affinity", "threshold":4.0, "realm":1, "path":"gale_path"},
	"stone_heart": {"name":"Stone-Heart Stance", "skill":"earth_affinity", "threshold":4.0, "realm":1, "path":"stone_path"},
	"storm_chain": {"name":"Storm Meridian Chain", "skill":"lightning_affinity", "threshold":4.0, "realm":1, "path":"storm_path"},
	"frost_prison": {"name":"Frost-Lotus Prison", "skill":"ice_affinity", "threshold":4.0, "realm":1, "path":"frost_path"},
	"shadow_breath": {"name":"Silent Shadow Breath", "skill":"stealth", "threshold":2.0, "realm":1, "path":"shadow_step"},
	"spirit_sight": {"name":"Spirit-Vein Sight", "skill":"spiritual_sense", "threshold":2.0, "realm":1, "path":"spirit_sense"},
	"meridian_spiral": {"name":"Eightfold Meridian Spiral", "skill":"arcane_attunement", "threshold":5.0, "realm":2, "path":"elemental_core"},
	"blade_intent": {"name":"Unbroken Blade Intent", "skill":"swordsmanship", "threshold":4.0, "realm":1, "path":"sword_intent"},
	"living_root": {"name":"Living Root Communion", "skill":"herbalism", "threshold":4.0, "realm":1, "path":"nature_harmony"},
	"flowing_breath": {"name":"Flowing-Breath Swimming Art", "skill":"swimming", "threshold":4.0, "realm":1, "path":"flowing_water"},
	# Deeper forms are learned slowly through repeated practical use and higher realms.
	"phoenix_reversal": {"name":"Phoenix Reversal Scripture", "skill":"fire_affinity", "threshold":12.0, "realm":2, "path":"flame_path"},
	"sunforge_palm": {"name":"Sunforge Palm", "skill":"elemental_magic", "threshold":18.0, "realm":3, "path":"flame_path"},
	"deepcurrent_guard": {"name":"Deepcurrent Guard", "skill":"water_affinity", "threshold":12.0, "realm":2, "path":"tide_path"},
	"moonwell_step": {"name":"Moonwell Step", "skill":"swimming", "threshold":14.0, "realm":3, "path":"tide_path"},
	"empty_sky_stride": {"name":"Empty-Sky Stride", "skill":"agility", "threshold":12.0, "realm":2, "path":"gale_path"},
	"ninefold_gale": {"name":"Ninefold Gale Formation", "skill":"wind_affinity", "threshold":18.0, "realm":3, "path":"gale_path"},
	"granite_meridian": {"name":"Granite Meridian Body", "skill":"vitality", "threshold":12.0, "realm":2, "path":"stone_path"},
	"mountain_anchor": {"name":"Mountain-Anchor Seal", "skill":"earth_affinity", "threshold":18.0, "realm":3, "path":"stone_path"},
	"thunderheart_pulse": {"name":"Thunderheart Pulse", "skill":"lightning_affinity", "threshold":12.0, "realm":2, "path":"storm_path"},
	"sky_lattice": {"name":"Sky-Lattice Meridian Art", "skill":"precision", "threshold":18.0, "realm":3, "path":"storm_path"},
	"frost_mirror_body": {"name":"Frost-Mirror Body", "skill":"ice_affinity", "threshold":12.0, "realm":2, "path":"frost_path"},
	"white_lotus_seal": {"name":"White Lotus Sealing Art", "skill":"observation", "threshold":18.0, "realm":3, "path":"frost_path"},
	"silent_river_step": {"name":"Silent River Step", "skill":"stealth", "threshold":10.0, "realm":2, "path":"shadow_step"},
	"veil_of_stillness": {"name":"Veil of Stillness", "skill":"dagger_mastery", "threshold":16.0, "realm":3, "path":"shadow_step"},
	"spirit_thread_sense": {"name":"Spirit-Thread Sense", "skill":"spiritual_sense", "threshold":10.0, "realm":2, "path":"spirit_sense"},
	"formation_eye": {"name":"Formation-Eye Survey", "skill":"observation", "threshold":16.0, "realm":3, "path":"spirit_sense"},
	"root_bloom_cycle": {"name":"Root-Bloom Cycle", "skill":"herbalism", "threshold":10.0, "realm":2, "path":"nature_harmony"},
	"beast_breath_link": {"name":"Beast-Breath Communion", "skill":"tracking", "threshold":16.0, "realm":3, "path":"nature_harmony"}
}

var cultivation_state: Dictionary = {
	"realm_index":0,
	"meridians":{},
	"spiritual_root":"Unawakened",
	"active_path":"",
	"breakthrough_attempts":0,
	"breakthrough_failures":0,
	"techniques":{},
	"sealed_techniques":{}
}

func cultivation_realm_index() -> int:
	return clampi(int(cultivation_state.get("realm_index", 0)), 0, CULTIVATION_REALMS.size() - 1)

func lifespan_years() -> float:
	var realm := cultivation_realm_index() if CultivationDiscovery.is_cultivation_unlocked() else 0
	return REALM_LIFESPANS[realm]

func cultivation_realm_name() -> String:
	return str(CULTIVATION_REALMS[cultivation_realm_index()].get("name", "Mortal Foundation"))

func meridian_count() -> int:
	var opened: Variant = cultivation_state.get("meridians", {})
	if not opened is Dictionary:
		return 0
	var total := 0
	for value in opened.values():
		if bool(value):
			total += 1
	return total

func is_meridian_open(meridian_id: String) -> bool:
	var opened: Variant = cultivation_state.get("meridians", {})
	return opened is Dictionary and bool(opened.get(meridian_id, false))

func refresh_meridian_unlocks() -> Array[String]:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return []
	var opened: Dictionary = cultivation_state.get("meridians", {}).duplicate()
	var newly_opened: Array[String] = []
	for meridian_id in MERIDIAN_REQUIREMENTS.keys():
		if bool(opened.get(meridian_id, false)):
			continue
		var requirement: Dictionary = MERIDIAN_REQUIREMENTS[meridian_id]
		if get_value(str(requirement.skill)) >= float(requirement.threshold):
			opened[meridian_id] = true
			newly_opened.append(str(meridian_id))
	cultivation_state["meridians"] = opened
	for meridian_id in newly_opened:
		var data: Dictionary = MERIDIAN_REQUIREMENTS[meridian_id]
		EventBus.toast.emit("Meridian opened: %s" % str(data.name), "levelup")
		EventBus.activity.emit("Opened the %s through disciplined circulation" % str(data.name), "cultivation")
	return newly_opened

func has_cultivation_technique(technique_id: String) -> bool:
	var learned: Variant = cultivation_state.get("techniques", {})
	return learned is Dictionary and bool(learned.get(technique_id, false))

func cultivation_technique_count() -> int:
	var learned: Variant = cultivation_state.get("techniques", {})
	if not learned is Dictionary:
		return 0
	var total: int = 0
	for value in learned.values():
		if bool(value):
			total += 1
	return total

func is_cultivation_technique_active(technique_id: String) -> bool:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return false
	if not has_cultivation_technique(technique_id):
		return false
	var data: Dictionary = CULTIVATION_TECHNIQUES.get(technique_id, {})
	var required_path: String = str(data.get("path", ""))
	return required_path == "" or str(cultivation_state.get("active_path", "")) == required_path

func refresh_cultivation_techniques() -> Array[String]:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return []
	var learned_value: Variant = cultivation_state.get("techniques", {})
	var learned: Dictionary = learned_value.duplicate() if learned_value is Dictionary else {}
	var unlocked: Array[String] = []
	for technique_id in CULTIVATION_TECHNIQUES.keys():
		if bool(learned.get(technique_id, false)):
			continue
		var requirement: Dictionary = CULTIVATION_TECHNIQUES[technique_id]
		var rare_gate: Dictionary = TECHNIQUE_REQUIREMENTS.get(technique_id, {})
		if bool(rare_gate.get("rare", false)) and not discovered_techniques.has(technique_id):
			continue
		if cultivation_realm_index() < int(requirement.get("realm", 0)):
			continue
		if get_value(str(requirement.get("skill", "cultivation"))) < float(requirement.get("threshold", 0.0)):
			continue
		var path_id: String = str(requirement.get("path", ""))
		if path_id != "" and cultivation_path_progress(path_id) < 0.5:
			continue
		learned[technique_id] = true
		unlocked.append(str(technique_id))
	cultivation_state["techniques"] = learned
	for technique_id in unlocked:
		var data: Dictionary = CULTIVATION_TECHNIQUES[technique_id]
		EventBus.toast.emit("Cultivation technique learned: %s" % str(data.get("name", technique_id)), "levelup")
		EventBus.activity.emit("Learned %s through cultivation practice" % str(data.get("name", technique_id)), "cultivation")
	return unlocked

func breakthrough_requirement() -> Dictionary:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return {"available":false, "reason":"You have not discovered and earned a legitimate cultivation method."}
	var next_index: int = cultivation_realm_index() + 1
	if next_index >= CULTIVATION_REALMS.size():
		return {"available":false, "reason":"The highest known realm has been reached."}
	var requirement: Dictionary = CULTIVATION_REALMS[next_index]
	var cultivation_value: float = get_value("cultivation")
	var needed_skill: float = float(requirement.get("cultivation", 0.0))
	var needed_meridians: int = int(requirement.get("meridians", 0))
	if cultivation_value < needed_skill:
		return {"available":false, "reason":"Cultivation %.1f / %.1f" % [cultivation_value, needed_skill]}
	if meridian_count() < needed_meridians:
		return {"available":false, "reason":"Meridians %d / %d" % [meridian_count(), needed_meridians]}
	return {"available":true, "realm":str(requirement.get("name", "Unknown")), "index":next_index}

func complete_breakthrough(success: bool) -> void:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return
	cultivation_state["breakthrough_attempts"] = int(cultivation_state.get("breakthrough_attempts", 0)) + 1
	if success:
		cultivation_state["realm_index"] = mini(cultivation_realm_index() + 1, CULTIVATION_REALMS.size() - 1)
		if str(cultivation_state.get("spiritual_root", "Unawakened")) == "Unawakened":
			cultivation_state["spiritual_root"] = determine_spiritual_root()
		refresh_cultivation_techniques()
	else:
		cultivation_state["breakthrough_failures"] = int(cultivation_state.get("breakthrough_failures", 0)) + 1

func determine_spiritual_root() -> String:
	var ranked: Array[Dictionary] = []
	for element in ELEMENTS:
		var skill_id: String = str(ELEMENT_SKILLS[element])
		ranked.append({"element":element, "value":get_value(skill_id)})
	ranked.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a.value) > float(b.value))
	if ranked.is_empty() or float(ranked[0].value) < 1.0:
		return "Balanced Root"
	var first: String = str(ranked[0].element)
	var first_value: float = float(ranked[0].value)
	if ranked.size() > 1 and float(ranked[1].value) >= first_value * 0.82 and float(ranked[1].value) >= 1.0:
		return "%s-%s Dual Root" % [first.capitalize(), str(ranked[1].element).capitalize()]
	if first_value >= 12.0:
		return "Pure %s Root" % first.capitalize()
	return "%s Root" % first.capitalize()

func elemental_root_multiplier(element: String) -> float:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return 1.0
	var root: String = str(cultivation_state.get("spiritual_root", "" )).to_lower()
	if root.begins_with("pure ") and root.contains(element):
		return 1.18
	if root.contains("dual") and root.contains(element):
		return 1.08
	return 1.0

func get_elemental_form(element: String) -> String:
	var forms: Dictionary = ELEMENTAL_FORMS.get(element, {})
	if forms.is_empty():
		return "Arcane Bolt"
	var skill_id: String = str(ELEMENT_SKILLS.get(element, "elemental_magic"))
	var affinity: float = get_value(skill_id)
	if affinity >= 25.0:
		return str(forms.get("master", forms.get("basic", "Arcane Bolt")))
	if affinity >= 8.0:
		return str(forms.get("adept", forms.get("basic", "Arcane Bolt")))
	return str(forms.get("basic", "Arcane Bolt"))

func set_active_cultivation_path(path_id: String) -> bool:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return false
	if not CULTIVATION_PATHS.has(path_id):
		return false
	cultivation_state["active_path"] = path_id
	return true

func active_cultivation_path_name() -> String:
	var path_id: String = str(cultivation_state.get("active_path", ""))
	return str(CULTIVATION_PATHS.get(path_id, {}).get("name", "Uncommitted"))

func cycle_cultivation_path(direction: int = 1) -> String:
	var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
	if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
		return ""
	var choices: Array[String] = []
	for path_id in CULTIVATION_PATHS.keys():
		if cultivation_path_progress(str(path_id)) >= 0.5:
			choices.append(str(path_id))
	if choices.is_empty():
		return ""
	var current: String = str(cultivation_state.get("active_path", ""))
	var index: int = choices.find(current)
	index = posmod(index + direction, choices.size())
	cultivation_state["active_path"] = choices[index]
	return active_cultivation_path_name()

var values: Dictionary = {}
var known_skills: Dictionary = {}
var _ability_cooldowns: Dictionary = {}
var discovered_techniques: Dictionary = {}
var discovered_traits: Dictionary = {}
var technique_practice: Dictionary = {}

# Techniques are knowledge, not level-up rewards. They must be discovered from
# teachers, manuals, ruins or earned through a deliberate combat feat.
const TECHNIQUE_REQUIREMENTS: Dictionary = {
	"cleave": {"skill":"swordsmanship", "minimum":3.0, "description":"A committed sweeping cut."},
	"heavy_strike": {"skill":"swordsmanship", "minimum":12.0, "description":"A focused strike that commits the whole body."},
	"shadow_flurry": {"skill":"dagger_mastery", "minimum":3.0, "description":"A rapid sequence built around footwork."},
	"sundering_chop": {"skill":"axe_mastery", "minimum":3.0, "description":"A deliberate blow aimed at a weak point."},
	"piercing_thrust": {"skill":"spear_mastery", "minimum":3.0, "description":"A long-reaching thrust using precise alignment."},
	"groundbreaker": {"skill":"blunt_mastery", "minimum":3.0, "description":"A grounded impact that transfers weight."},
	"piercing_shot": {"skill":"archery", "minimum":3.0, "description":"A controlled shot through a narrow opening."},
	"arcane_burst": {"skill":"elemental_magic", "minimum":3.0, "description":"A shaped release of gathered elemental energy."},
	"riposte": {"skill":"shield", "minimum":0.3, "description":"A counterattack opened by a perfectly timed guard."},
	"eclipse_counter": {"skill":"swordsmanship", "minimum":28.0, "secondary_skill":"precision", "secondary_minimum":12.0, "rare":true, "description":"A patient blade form that turns an enemy's commitment into a decisive counter-cut."},
	"dragon_piercer": {"skill":"spear_mastery", "minimum":24.0, "secondary_skill":"agility", "secondary_minimum":8.0, "rare":true, "description":"A long, aligned thrust that carries force through a narrow line."},
	"starfall_burst": {"skill":"elemental_magic", "minimum":24.0, "secondary_skill":"arcane_attunement", "secondary_minimum":10.0, "rare":true, "description":"A multi-stage release that fractures into a focused astral detonation."},
	"void_step": {"skill":"dagger_mastery", "minimum":20.0, "secondary_skill":"stealth", "secondary_minimum":12.0, "rare":true, "description":"A silent repositioning cut that strikes from the edge of an enemy's awareness."},
	"sunforge_palm": {"skill":"elemental_magic", "minimum":18.0, "secondary_skill":"fire_affinity", "secondary_minimum":10.0, "realm_min":3, "rare":true, "description":"A focused flame palm that compresses heat into a devastating close-range burst."},
	"moonwell_step": {"skill":"swimming", "minimum":14.0, "secondary_skill":"water_affinity", "secondary_minimum":8.0, "realm_min":3, "rare":true, "description":"A fluid repositioning art that carries the cultivator through water and around hostile strikes."},
	"sky_lattice": {"skill":"precision", "minimum":18.0, "secondary_skill":"lightning_affinity", "secondary_minimum":10.0, "realm_min":3, "rare":true, "description":"A precise lightning formation that links marked targets through a meridian lattice."},
	"veil_of_stillness": {"skill":"dagger_mastery", "minimum":16.0, "secondary_skill":"stealth", "secondary_minimum":10.0, "realm_min":3, "rare":true, "description":"A silent stillness form that suppresses the final trace before a decisive strike."},
	"beast_breath_link": {"skill":"tracking", "minimum":16.0, "secondary_skill":"herbalism", "secondary_minimum":8.0, "realm_min":3, "rare":true, "description":"A communion form that reads and briefly synchronises with the breath of spirit beasts."}
}

# Traits are earned through play, never selected from a fixed class menu.
const TRAITS: Dictionary = {
	"blade_veteran": {"name": "Blade Veteran", "skill": "swordsmanship", "threshold": 25.0, "desc": "+4% sword damage", "bonus": "sword_damage"},
	"sunderer": {"name": "Sunderer", "skill": "axe_mastery", "threshold": 25.0, "desc": "+4% axe damage", "bonus": "axe_damage"},
	"quickdraw": {"name": "Quickdraw", "skill": "dagger_mastery", "threshold": 25.0, "desc": "+4% dagger damage", "bonus": "dagger_damage"},
	"lancer": {"name": "Lancer", "skill": "spear_mastery", "threshold": 25.0, "desc": "+4% spear damage", "bonus": "spear_damage"},
	"impact_adept": {"name": "Impact Adept", "skill": "blunt_mastery", "threshold": 25.0, "desc": "+4% blunt damage", "bonus": "blunt_damage"},
	"deadeye": {"name": "Deadeye", "skill": "archery", "threshold": 25.0, "desc": "+4% bow damage and +3% critical chance", "bonus": "bow_damage"},
	"arcane_conduit": {"name": "Arcane Conduit", "skill": "elemental_magic", "threshold": 25.0, "desc": "+5% staff and wand damage", "bonus": "magic_damage"},
	"iron_body": {"name": "Iron Body", "skill": "vitality", "threshold": 25.0, "desc": "+12 maximum health", "bonus": "health"},
	"fleetfoot": {"name": "Fleetfoot", "skill": "agility", "threshold": 25.0, "desc": "+2.5% movement speed", "bonus": "speed"},
	"field_medic": {"name": "Field Medic", "skill": "alchemy", "threshold": 25.0, "desc": "+12% potion healing", "bonus": "healing"},
	"gatherers_instinct": {"name": "Gatherer's Instinct", "skill": "herbalism", "threshold": 25.0, "desc": "+4% gathering yield and success", "bonus": "gathering"},
	"deep_delver": {"name": "Deep Delver", "skill": "dungeon_delving", "threshold": 25.0, "desc": "+5% dungeon treasure luck", "bonus": "loot_luck"}
}

const TECHNIQUE_NAMES: Dictionary = {
	"cleave": "Cleave", "heavy_strike": "Heavy Strike", "shadow_flurry": "Shadow Flurry", "riposte": "Riposte",
	"sundering_chop": "Sundering Chop", "piercing_thrust": "Piercing Thrust",
	"groundbreaker": "Groundbreaker", "piercing_shot": "Piercing Shot", "arcane_burst": "Arcane Burst",
	"eclipse_counter": "Eclipse Counter", "dragon_piercer": "Dragon Piercer",
	"starfall_burst": "Starfall Burst", "void_step": "Void Step"
}

func _ready() -> void:
	reset()
	print("[SkillSystem] Initialized with %d skills" % values.size())

func reset() -> void:
	_ability_cooldowns.clear()
	discovered_techniques.clear()
	discovered_traits.clear()
	technique_practice.clear()
	known_skills.clear()
	cultivation_state = {
		"realm_index":0,
		"meridians":{},
		"spiritual_root":"Unawakened",
		"active_path":"",
		"breakthrough_attempts":0,
		"breakthrough_failures":0,
		"techniques":{},
		"sealed_techniques":{}
	}
	values.clear()
	for id in SKILLS.keys():
		values[id] = 0.0

## A skill is not granted at character creation. It becomes known through
## practice, instruction, a manual or a meaningful discovery.
func is_skill_discovered(id: String) -> bool:
	return bool(known_skills.get(id, false))

func discover_skill(id: String, source: String = "discovery") -> bool:
	if not SKILLS.has(id) or is_skill_discovered(id):
		return false
	known_skills[id] = true
	var skill_name: String = str(SKILLS[id].get("name", id))
	EventBus.activity.emit("Discovered %s: %s" % [skill_name, source], "skill")
	EventBus.toast.emit("Skill discovered: %s" % skill_name, "levelup")
	return true

## Train a skill by use. Returns the points actually gained.
func train(id: String, amount: float, quiet: bool = false) -> float:
	if amount <= 0.0 or not values.has(id):
		return 0.0
	# Cultivation itself cannot be trained before a legitimate method is acquired.
	# Elemental magic and ordinary RPG skills remain usable by every character.
	if id == "cultivation" or id == "arcane_attunement":
		var discovery: Node = get_node_or_null("/root/CultivationDiscovery")
		if discovery != null and not bool(discovery.call("is_cultivation_unlocked")):
			return 0.0
	if not is_skill_discovered(id):
		discover_skill(id, "learned through first practical use")
	var old: float = values[id]
	var gain: float = amount / (1.0 + old * 0.012)
	values[id] = old + gain
	if id in ["cultivation", "vitality", "swordsmanship", "herbalism", "swimming", "fire_affinity", "water_affinity", "wind_affinity", "earth_affinity", "lightning_affinity", "ice_affinity", "stealth", "spiritual_sense", "arcane_attunement"]:
		refresh_cultivation_techniques()
	var sealed_value: Variant = cultivation_state.get("sealed_techniques", {})
	if sealed_value is Dictionary and not sealed_value.is_empty():
		refresh_sealed_techniques()
	var old_rank: String = rank_name_for(old)
	var new_rank: String = rank_name_for(values[id])
	skill_changed.emit(id, values[id], gain)
	if not quiet and gain >= 0.02:
		EventBus.activity.emit("%s +%.2f  (%.2f)" % [SKILLS[id]["name"], gain, values[id]], "skill")
	_check_trait_unlocks(id, old, values[id])
	if new_rank != old_rank:
		rank_up.emit(id, new_rank)
		EventBus.player_leveled_skill.emit(id, int(values[id]))
		EventBus.toast.emit("%s is now %s!" % [SKILLS[id]["name"], new_rank], "levelup")
	return gain

func get_value(id: String) -> float:
	return float(values.get(id, 0.0))

func _check_trait_unlocks(skill_id: String, old_value: float, new_value: float) -> void:
	for id in values.keys():
		if float(values[id]) > 0.0:
			known_skills[id] = true
	for trait_id in TRAITS.keys():
		var trait_data: Dictionary = TRAITS[trait_id]
		if str(trait_data.skill) != skill_id or old_value >= float(trait_data.threshold) or new_value < float(trait_data.threshold):
			continue
		if discovered_traits.has(trait_id):
			continue
		discovered_traits[trait_id] = true
		var trait_name: String = str(trait_data.name)
		EventBus.toast.emit("Trait unlocked: %s" % trait_name, "levelup")
		EventBus.activity.emit("Mastery trait learned: %s — %s" % [trait_name, str(trait_data.desc)], "skill")

func has_trait(trait_id: String) -> bool:
	return bool(discovered_traits.get(trait_id, false))

func trait_bonus(bonus_id: String) -> float:
	match bonus_id:
		"sword_damage": return 0.04 if has_trait("blade_veteran") else 0.0
		"axe_damage": return 0.04 if has_trait("sunderer") else 0.0
		"dagger_damage": return 0.04 if has_trait("quickdraw") else 0.0
		"spear_damage": return 0.04 if has_trait("lancer") else 0.0
		"blunt_damage": return 0.04 if has_trait("impact_adept") else 0.0
		"bow_damage": return 0.04 if has_trait("deadeye") else 0.0
		"bow_crit": return 0.03 if has_trait("deadeye") else 0.0
		"magic_damage": return 0.05 if has_trait("arcane_conduit") else 0.0
		"health": return 12.0 if has_trait("iron_body") else 0.0
		"speed": return 0.025 if has_trait("fleetfoot") else 0.0
		"healing": return 0.12 if has_trait("field_medic") else 0.0
		"gathering": return 0.04 if has_trait("gatherers_instinct") else 0.0
		"loot_luck": return 0.05 if has_trait("deep_delver") else 0.0
	return 0.0

func attribute_summary() -> Dictionary:
	# Five readable RPG attributes are derived from what the character actually practises.
	return {
		"Might": _weighted_attribute(["swordsmanship", "axe_mastery", "blunt_mastery", "spear_mastery"]),
		"Finesse": _weighted_attribute(["dagger_mastery", "archery", "precision", "agility"]),
		"Endurance": _weighted_attribute(["vitality", "shield", "swimming"]),
		"Intellect": _weighted_attribute(["elemental_magic", "arcane_attunement", "cultivation", "spiritual_sense", "enchanting", "alchemy", "knowledge", "ancient_lore"]),
		"Wisdom": _weighted_attribute(["wisdom", "observation", "ancient_lore"]),
		"Survival": _weighted_attribute(["exploration", "mining", "woodcutting", "herbalism", "fishing"])
	}

func _weighted_attribute(skill_ids: Array) -> float:
	if skill_ids.is_empty():
		return 0.0
	var total: float = 0.0
	for skill_id in skill_ids:
		total += get_value(str(skill_id))
	return total / float(skill_ids.size())

static func rank_name_for(v: float) -> String:
	var name_out: String = RANKS[0][1]
	for r in RANKS:
		if v >= float(r[0]):
			name_out = r[1]
	return name_out

func get_rank_name(id: String) -> String:
	return rank_name_for(get_value(id))

## 0..1 progress toward the next rank.
func rank_progress(id: String) -> float:
	var v: float = get_value(id)
	for i in range(RANKS.size() - 1):
		var lo: float = RANKS[i][0]
		var hi: float = RANKS[i + 1][0]
		if v >= lo and v < hi:
			return (v - lo) / (hi - lo)
	return 1.0

func profession_value(prof: String) -> float:
	var total: float = 0.0
	var weights: Dictionary = PROFESSIONS[prof]
	for sid in weights.keys():
		total += get_value(sid) * float(weights[sid])
	return total

# --- Earned active combat abilities ----------------------------------------
func available_abilities() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if get_value("swordsmanship") >= 10.0 and has_discovered_technique("cleave"):
		out.append({"id": "cleave", "name": "Cleave", "description": "A wide blade sweep.", "cooldown": 8.0, "weapon_class": "sword"})
	if get_value("swordsmanship") >= 25.0 and has_discovered_technique("heavy_strike"):
		out.append({"id": "heavy_strike", "name": "Heavy Strike", "description": "A powerful focused blade blow.", "cooldown": 12.0, "weapon_class": "sword"})
	if get_value("dagger_mastery") >= 10.0 and has_discovered_technique("shadow_flurry"):
		out.append({"id": "shadow_flurry", "name": "Shadow Flurry", "description": "A rapid sequence of dagger strikes.", "cooldown": 9.0, "weapon_class": "dagger"})
	if get_value("axe_mastery") >= 10.0 and has_discovered_technique("sundering_chop"):
		out.append({"id": "sundering_chop", "name": "Sundering Chop", "description": "A heavy armour-breaking blow.", "cooldown": 11.0, "weapon_class": "axe"})
	if get_value("spear_mastery") >= 10.0 and has_discovered_technique("piercing_thrust"):
		out.append({"id": "piercing_thrust", "name": "Piercing Thrust", "description": "A long-reaching focused thrust.", "cooldown": 8.0, "weapon_class": "spear"})
	if get_value("blunt_mastery") >= 10.0 and has_discovered_technique("groundbreaker"):
		out.append({"id": "groundbreaker", "name": "Groundbreaker", "description": "A crushing impact around the wielder.", "cooldown": 14.0, "weapon_class": "blunt"})
	if get_value("archery") >= 10.0 and has_discovered_technique("piercing_shot"):
		out.append({"id": "piercing_shot", "name": "Piercing Shot", "description": "A focused long-range arrow.", "cooldown": 7.0, "weapon_class": "bow"})
	if (get_value("elemental_magic") >= 10.0 or get_value("arcane_attunement") >= 10.0) and has_discovered_technique("arcane_burst"):
		out.append({"id": "arcane_burst", "name": "Arcane Burst", "description": "A magical shockwave.", "cooldown": 16.0, "weapon_class": "staff"})
	if get_value("swordsmanship") >= 28.0 and has_discovered_technique("eclipse_counter"):
		out.append({"id":"eclipse_counter", "name":"Eclipse Counter", "description":"A decisive counter-cut with a tight follow-through.", "cooldown":19.0, "weapon_class":"sword"})
	if get_value("spear_mastery") >= 24.0 and has_discovered_technique("dragon_piercer"):
		out.append({"id":"dragon_piercer", "name":"Dragon Piercer", "description":"A long, aligned thrust that reaches through a narrow line.", "cooldown":17.0, "weapon_class":"spear"})
	if get_value("elemental_magic") >= 24.0 and has_discovered_technique("starfall_burst"):
		out.append({"id":"starfall_burst", "name":"Starfall Burst", "description":"An astral detonation shaped by elemental mastery.", "cooldown":22.0, "weapon_class":"staff"})
	if get_value("dagger_mastery") >= 20.0 and has_discovered_technique("void_step"):
		out.append({"id":"void_step", "name":"Void Step", "description":"A silent cut from an unexpected angle.", "cooldown":16.0, "weapon_class":"dagger"})
	return out


## Techniques emerge from combat rhythm. No hotkey or menu activation is required.
## A third consecutive hit can trigger a trained technique; deeper mastery
## allows stronger flow techniques later in a chain.
func try_flow_technique(weapon_class: String, combo_count: int) -> String:
	# Techniques are learned by reaching mastery, then physically performed by
	# maintaining a successful combat rhythm. No ability button is involved.
	if combo_count < 3:
		return ""
	var skill_id: String = weapon_skill_id(weapon_class)
	var mastery: float = get_value(skill_id)
	if mastery < 3.0:
		return ""
	var technique_id: String = ""
	match weapon_class:
		"sword":
			if mastery >= 28.0 and combo_count >= 6 and has_discovered_technique("eclipse_counter"):
				technique_id = "eclipse_counter"
			else:
				technique_id = "heavy_strike" if mastery >= 25.0 and combo_count >= 5 else "cleave"
		"dagger": technique_id = "void_step" if mastery >= 20.0 and combo_count >= 5 and has_discovered_technique("void_step") else "shadow_flurry"
		"axe": technique_id = "sundering_chop"
		"spear": technique_id = "dragon_piercer" if mastery >= 24.0 and combo_count >= 5 and has_discovered_technique("dragon_piercer") else "piercing_thrust"
		"blunt": technique_id = "groundbreaker"
		"bow": technique_id = "piercing_shot"
		"staff", "wand": technique_id = "starfall_burst" if mastery >= 24.0 and combo_count >= 5 and has_discovered_technique("starfall_burst") else "arcane_burst"
	if technique_id == "" or not has_discovered_technique(technique_id):
		return ""
	var now: float = Time.get_ticks_msec() / 1000.0
	var cooldowns: Dictionary = {"cleave": 8.0, "heavy_strike": 12.0, "shadow_flurry": 9.0, "sundering_chop": 11.0, "piercing_thrust": 8.0, "groundbreaker": 14.0, "piercing_shot": 7.0, "arcane_burst": 16.0, "eclipse_counter": 19.0, "dragon_piercer": 17.0, "starfall_burst": 22.0, "void_step": 16.0}
	var cooldown: float = float(cooldowns.get(technique_id, 8.0))
	if now < float(_ability_cooldowns.get(technique_id, 0.0)):
		return ""
	_ability_cooldowns[technique_id] = now + cooldown
	return technique_id

## Ancient records can preserve a rare technique before the character has
## enough practical mastery to understand it. The record persists with saves.
func seal_rare_technique(technique_id: String, source: String = "ancient record") -> bool:
	if not TECHNIQUE_REQUIREMENTS.has(technique_id) or discovered_techniques.has(technique_id):
		return false
	var requirement: Dictionary = TECHNIQUE_REQUIREMENTS[technique_id]
	if not bool(requirement.get("rare", false)):
		return false
	var sealed_value: Variant = cultivation_state.get("sealed_techniques", {})
	var sealed: Dictionary = sealed_value.duplicate(true) if sealed_value is Dictionary else {}
	if sealed.has(technique_id):
		return false
	sealed[technique_id] = source
	cultivation_state["sealed_techniques"] = sealed
	var technique_name: String = str(TECHNIQUE_NAMES.get(technique_id, technique_id.replace("_", " ").capitalize()))
	EventBus.activity.emit("Recorded sealed technique: %s (%s)" % [technique_name, source], "exploration")
	EventBus.toast.emit("Ancient technique recorded: %s. Its meaning will emerge through practice." % technique_name, "discovery")
	refresh_sealed_techniques()
	return true

func sealed_technique_count() -> int:
	var sealed_value: Variant = cultivation_state.get("sealed_techniques", {})
	return sealed_value.size() if sealed_value is Dictionary else 0

func refresh_sealed_techniques() -> Array[String]:
	var sealed_value: Variant = cultivation_state.get("sealed_techniques", {})
	if not sealed_value is Dictionary:
		return []
	var sealed: Dictionary = sealed_value.duplicate(true)
	var understood: Array[String] = []
	for technique_variant in sealed.keys():
		var technique_id: String = str(technique_variant)
		if discovered_techniques.has(technique_id):
			sealed.erase(technique_id)
			continue
		var requirement: Dictionary = TECHNIQUE_REQUIREMENTS.get(technique_id, {})
		if requirement.is_empty() or not bool(requirement.get("rare", false)):
			sealed.erase(technique_id)
			continue
		if cultivation_realm_index() < int(requirement.get("realm_min", 0)):
			continue
		var primary_skill: String = str(requirement.get("skill", ""))
		var secondary_skill: String = str(requirement.get("secondary_skill", ""))
		var primary_ready: bool = get_value(primary_skill) >= float(requirement.get("minimum", 0.0))
		var secondary_ready: bool = secondary_skill == "" or get_value(secondary_skill) >= float(requirement.get("secondary_minimum", 0.0))
		if primary_ready and secondary_ready:
			if discover_technique(technique_id, str(sealed[technique_id])):
				understood.append(technique_id)
				sealed.erase(technique_id)
	cultivation_state["sealed_techniques"] = sealed
	return understood

func discover_technique(technique_id: String, source: String = "unknown") -> bool:
	if technique_id == "" or discovered_techniques.has(technique_id):
		return false
	if not TECHNIQUE_REQUIREMENTS.has(technique_id):
		return false
	var req: Dictionary = TECHNIQUE_REQUIREMENTS[technique_id]
	if cultivation_realm_index() < int(req.get("realm_min", 0)):
		EventBus.toast.emit("Your cultivation realm is not yet strong enough to decipher this form.", "warning")
		return false
	var skill_id: String = str(req.get("skill", ""))
	var secondary_skill: String = str(req.get("secondary_skill", ""))
	if get_value(skill_id) < float(req.get("minimum", 0.0)) or (secondary_skill != "" and get_value(secondary_skill) < float(req.get("secondary_minimum", 0.0))):
		EventBus.toast.emit("You lack the practical experience to understand this technique", "warning")
		return false
	discovered_techniques[technique_id] = {"source": source, "learned_at": Time.get_unix_time_from_system(), "rare": bool(req.get("rare", false))}
	technique_practice[technique_id] = 0
	if CULTIVATION_TECHNIQUES.has(technique_id):
		var cultivation_learned: Dictionary = cultivation_state.get("techniques", {}).duplicate(true)
		cultivation_learned[technique_id] = true
		cultivation_state["techniques"] = cultivation_learned
	var technique_name: String = str(TECHNIQUE_NAMES.get(technique_id, technique_id.replace("_", " ").capitalize()))
	technique_discovered.emit(technique_id, technique_name)
	var sealed_value: Variant = cultivation_state.get("sealed_techniques", {})
	if sealed_value is Dictionary and sealed_value.has(technique_id):
		var remaining_sealed: Dictionary = sealed_value.duplicate(true)
		remaining_sealed.erase(technique_id)
		cultivation_state["sealed_techniques"] = remaining_sealed
	EventBus.activity.emit("Technique knowledge acquired: %s (%s)" % [technique_name, source], "skill")
	EventBus.toast.emit("Technique discovered: %s — practise to master it" % technique_name, "levelup")
	return true

func record_technique_practice(technique_id: String, successful: bool) -> void:
	if not has_discovered_technique(technique_id) or not successful:
		return
	var count: int = int(technique_practice.get(technique_id, 0)) + 1
	technique_practice[technique_id] = count
	if count == 1 or count == 5 or count == 15 or count == 30:
		var stage: String = "First execution" if count == 1 else ("Developing control" if count == 5 else ("Reliable execution" if count == 15 else "Technique refined"))
		EventBus.activity.emit("%s: %s (%d successful uses)" % [stage, TECHNIQUE_NAMES.get(technique_id, technique_id), count], "skill")

func technique_practice_count(technique_id: String) -> int:
	return int(technique_practice.get(technique_id, 0))

func has_discovered_technique(technique_id: String) -> bool:
	return discovered_techniques.has(technique_id)

func refund_flow_technique(technique_id: String) -> void:
	if technique_id != "":
		_ability_cooldowns.erase(technique_id)

## Legacy compatibility only. Gameplay does not call this; techniques flow from actions.
func use_best_ability() -> String:
	var abilities: Array[Dictionary] = available_abilities()
	if abilities.is_empty():
		return ""
	var equipped: Dictionary = PlayerData.equipment.get("weapon", {})
	var weapon_id: String = str(equipped.get("id", ""))
	var weapon_class: String = str(ItemDB.def(weapon_id).get("weapon_class", "sword"))
	for i in range(abilities.size() - 1, -1, -1):
		var ability: Dictionary = abilities[i]
		var ability_class: String = str(ability.get("weapon_class", ""))
		if ability_class != weapon_class and not (ability_class == "staff" and weapon_class == "wand"):
			continue
		var id: String = str(ability.id)
		if float(_ability_cooldowns.get(id, 0.0)) > Time.get_ticks_msec() / 1000.0:
			return ""
		_ability_cooldowns[id] = Time.get_ticks_msec() / 1000.0 + float(ability.cooldown)
		return id
	return ""

func weapon_skill_id(weapon_class: String) -> String:
	var mapping: Dictionary = {"sword": "swordsmanship", "dagger": "dagger_mastery", "axe": "axe_mastery", "spear": "spear_mastery", "blunt": "blunt_mastery", "bow": "archery", "staff": "elemental_magic", "wand": "elemental_magic"}
	return str(mapping.get(weapon_class, "swordsmanship"))

func weapon_damage_mult(skill_id: String) -> float:
	var mastery: float = get_value(skill_id)
	if skill_id == "dagger_mastery":
		mastery += get_value("dual_wield") * 0.5
	var trait_bonus_value: float = 0.0
	match skill_id:
		"swordsmanship": trait_bonus_value += trait_bonus("sword_damage")
		"axe_mastery": trait_bonus_value += trait_bonus("axe_damage")
		"dagger_mastery": trait_bonus_value += trait_bonus("dagger_damage")
		"spear_mastery": trait_bonus_value += trait_bonus("spear_damage")
		"blunt_mastery": trait_bonus_value += trait_bonus("blunt_damage")
		"archery": trait_bonus_value += trait_bonus("bow_damage")
		"elemental_magic": trait_bonus_value += trait_bonus("magic_damage")
	return (1.0 + 0.012 * mastery + trait_bonus_value) * (1.0 + PlayerData.title_bonus("dmg"))

# --- Derived stats (skills + title bonuses) --------------------------------
func damage_mult() -> float:
	var equipped: Dictionary = PlayerData.equipment.get("weapon", {})
	var weapon_id: String = str(equipped.get("id", ""))
	var weapon_class: String = str(ItemDB.def(weapon_id).get("weapon_class", "sword"))
	return weapon_damage_mult(weapon_skill_id(weapon_class))

func crit_chance() -> float:
	return clampf(0.04 + get_value("precision") * 0.004 + PlayerData.title_bonus("crit"), 0.0, 0.6)

func ranged_crit_bonus() -> float:
	return trait_bonus("bow_crit")

func dodge_chance() -> float:
	return clampf(get_value("evasion") * 0.004, 0.0, 0.35)

func max_health() -> float:
	return 100.0 + get_value("vitality") * 3.0 + PlayerData.title_bonus("hp") + trait_bonus("health")

func speed_mult() -> float:
	return 1.0 + minf(get_value("agility") * 0.003, 0.25) + PlayerData.title_bonus("speed") + trait_bonus("speed")

func barter_rate() -> float:
	return clampf(get_value("bartering") * 0.004, 0.0, 0.30)

func gather_bonus(skill_id: String) -> float:
	return minf(get_value(skill_id) * 0.012, 0.45) + PlayerData.title_bonus("gather") + trait_bonus("gathering")

# --- Persistence ------------------------------------------------------------
func to_dict() -> Dictionary:
	var result: Dictionary = values.duplicate()
	result["__discovered_techniques"] = discovered_techniques.duplicate()
	result["__discovered_traits"] = discovered_traits.duplicate()
	result["__technique_practice"] = technique_practice.duplicate()
	result["__known_skills"] = known_skills.duplicate()
	result["__cultivation_state"] = cultivation_state.duplicate(true)
	return result

func from_dict(d: Dictionary) -> void:
	reset()
	var saved_cultivation: Variant = d.get("__cultivation_state", {})
	if saved_cultivation is Dictionary:
		var merged_cultivation: Dictionary = cultivation_state.duplicate(true)
		for state_key in saved_cultivation.keys():
			merged_cultivation[state_key] = saved_cultivation[state_key]
		cultivation_state = merged_cultivation
	var saved_techniques: Variant = d.get("__discovered_techniques", {})
	if saved_techniques is Dictionary:
		discovered_techniques = saved_techniques.duplicate()
	var saved_known: Variant = d.get("__known_skills", {})
	if saved_known is Dictionary:
		known_skills = saved_known.duplicate()
	var saved_practice: Variant = d.get("__technique_practice", {})
	if saved_practice is Dictionary:
		technique_practice = saved_practice.duplicate()
	var saved_traits: Variant = d.get("__discovered_traits", {})
	if saved_traits is Dictionary:
		discovered_traits = saved_traits.duplicate()
	for id in d.keys():
		if values.has(id):
			values[id] = float(d[id])
	for id in values.keys():
		if float(values[id]) > 0.0:
			known_skills[id] = true
	for trait_id in TRAITS.keys():
		var trait_data: Dictionary = TRAITS[trait_id]
		if get_value(str(trait_data.skill)) >= float(trait_data.threshold):
			discovered_traits[trait_id] = true
	for id in values.keys():
		skill_changed.emit(id, values[id], 0.0)
	refresh_meridian_unlocks()
	refresh_cultivation_techniques()
	refresh_sealed_techniques()
