extends Node

## Regional climate approximation: seasons, lapse rate, humidity, wind and precipitation.
## This is a game-scale climate model, not a global atmospheric fluid solver.

signal climate_sampled(position: Vector3, temperature_c: float, humidity_fraction: float, rainfall_mm_h: float, wind: Vector3)

const DAYS_PER_YEAR: float = 360.0
const FREEZING_C: float = 0.0
const SEA_LEVEL_TEMP_C: float = 18.0
const LAPSE_RATE_C_PER_KM: float = 6.5

@export_range(0.0, 1.0, 0.01) var seasonal_temperature_swing_c: float = 11.0
@export_range(0.0, 1.0, 0.01) var base_humidity: float = 0.62
@export_range(0.0, 100.0, 0.5) var base_rainfall_mm_h: float = 1.5
@export_range(0.0, 30.0, 0.5) var prevailing_wind_m_s: float = 3.5

var season_name: String = "Spring"
var season_progress: float = 0.0
var _sample_timer: float = 0.0

func _ready() -> void:
	add_to_group("climate_system")

func _process(delta: float) -> void:
	_sample_timer += delta
	if _sample_timer >= 3.0:
		_sample_timer = 0.0
		_update_season()
		var player = GameManager.player
		if player != null and is_instance_valid(player):
			var sample := sample_at(player.global_position)
			PhysicalWorldSystem.air_temperature_c = float(sample.temperature_c)
			PhysicalWorldSystem.humidity = float(sample.humidity)
			PhysicalWorldSystem.wind_velocity = sample.wind
			PhysicalWorldSystem.pressure_kpa = PhysicalWorldSystem.pressure_at_altitude(player.global_position.y, float(sample.temperature_c))
			PhysicalWorldSystem.air_density = PhysicalWorldSystem.air_density_at(player.global_position.y, float(sample.temperature_c))
			climate_sampled.emit(player.global_position, float(sample.temperature_c), float(sample.humidity), float(sample.rainfall_mm_h), sample.wind)

func get_world_day() -> float:
	return float(LivingWorldSystem.get_world_day()) if is_instance_valid(LivingWorldSystem) else 0.0

func _update_season() -> void:
	var day_of_year := fposmod(get_world_day(), DAYS_PER_YEAR)
	season_progress = day_of_year / DAYS_PER_YEAR
	var season_index := int(floor(day_of_year / (DAYS_PER_YEAR / 4.0)))
	var seasons := ["Spring", "Summer", "Autumn", "Winter"]
	season_name = str(seasons[clampi(season_index, 0, 3)])

## Returns a climate snapshot in Celsius, fractional humidity and mm/hour.
func sample_at(position: Vector3) -> Dictionary:
	var day_of_year := fposmod(get_world_day(), DAYS_PER_YEAR)
	var annual_phase := TAU * day_of_year / DAYS_PER_YEAR
	# Northern/southern hemisphere sign is based on world Z; equatorial areas have weaker seasons.
	var hemisphere := 1.0 if position.z >= 0.0 else -1.0
	var latitude_factor := clampf(absf(position.z) / 12000.0, 0.0, 1.0)
	var seasonal := cos(annual_phase) * seasonal_temperature_swing_c * latitude_factor * hemisphere
	var day_node := get_tree().get_first_node_in_group("day_night")
	var time_of_day := float(day_node.get("time_of_day")) if day_node != null else 0.5
	var daily := 4.0 * sin((time_of_day - 0.25) * TAU)
	var altitude_cooling := maxf(0.0, position.y) / 1000.0 * LAPSE_RATE_C_PER_KM
	var temperature := SEA_LEVEL_TEMP_C + seasonal + daily - altitude_cooling
	var wind := PhysicalWorldSystem.wind_at(position, get_world_day())
	var orographic_lift := clampf(maxf(0.0, wind.y) * 0.0 + maxf(0.0, position.y) / 2500.0, 0.0, 0.28)
	var humidity := clampf(base_humidity + 0.12 * sin(annual_phase + position.x / 8000.0) - orographic_lift * 0.25, 0.05, 1.0)
	var rain_factor := 0.35 + humidity * 1.1
	var seasonal_rain := 0.65 + 0.35 * sin(annual_phase + position.x / 9000.0)
	var rainfall := maxf(0.0, base_rainfall_mm_h * rain_factor * seasonal_rain)
	return {"temperature_c": temperature, "humidity": humidity, "rainfall_mm_h": rainfall, "wind": wind, "season": season_name}

func temperature_at(position: Vector3) -> float:
	return float(sample_at(position).temperature_c)

func humidity_at(position: Vector3) -> float:
	return float(sample_at(position).humidity)

func rainfall_at(position: Vector3) -> float:
	return float(sample_at(position).rainfall_mm_h)

func get_season_name() -> String:
	_update_season()
	return season_name
