# Simulates slow-moving faction pressure in the ten dungeon civilizations.
extends Node

signal conflict_shifted(culture_id: String, pressure: int)
var _tick := 0.0

func _ready() -> void:
 add_to_group("faction_conflict_system")

func _process(delta: float) -> void:
 if GameManager.current_state != GameManager.GameState.PLAYING: return
 _tick += delta
 if _tick < 75.0: return
 _tick = 0.0
 var culture_index := clampi(floori(float(PlayerData.stats.get("deepest_dungeon_floor", 0)) / 10.0), 0, CivilizationSocieties.CULTURES.size() - 1)
 var culture: Dictionary = CivilizationSocieties.CULTURES[culture_index]
 var id := str(culture.id)
 var key := "faction_conflict_pressure_" + id
 var pressure := int(PlayerData.stats.get(key, 20))
 pressure = clampi(pressure + (1 if randf() < 0.65 else -1), 0, 100)
 PlayerData.stats[key] = pressure
 if pressure >= 35 and randf() < 0.18:
  EventBus.activity.emit("Faction tensions rise in %s: %s" % [culture.name, culture.conflict], "world")
 elif pressure <= 8:
  EventBus.activity.emit("A fragile peace settles over %s" % culture.name, "world")
 conflict_shifted.emit(id, pressure)

func pressure_for(culture_id: String) -> int:
 return int(PlayerData.stats.get("faction_conflict_pressure_" + culture_id, 20))
