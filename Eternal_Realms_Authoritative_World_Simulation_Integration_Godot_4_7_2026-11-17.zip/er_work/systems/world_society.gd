# World society: shared rumours, local incidents and NPC knowledge.
# NPCs talk about events they plausibly know through their work and faction ties.
extends Node
class_name WorldSociety

const INCIDENTS: Array[Dictionary] = [
	{"id":"caravan_delay", "title":"A delayed caravan", "area":"the Old Road", "detail":"A merchant caravan has missed its usual arrival. Guards say the road is unsafe, while traders suspect someone is buying up supplies."},
	{"id":"herb_bloom", "title":"An unusual herb bloom", "area":"the Whispering Woods", "detail":"Moonpetal has been blooming in places where it normally never grows. Herbalists are arguing over what changed in the soil."},
	{"id":"beast_migration", "title":"Beasts on the move", "area":"the Ironback slopes", "detail":"Hunters have found fresh tracks leading down from the high slopes. Something has disturbed the creatures deeper in the mountains."},
	{"id":"spire_signal", "title":"A signal from the Spire", "area":"the Arcane Spire", "detail":"The Spire's crystal flashed three times after midnight. Apprentices have been sent out to look for matching traces of energy."},
	{"id":"fishing_tide", "title":"The strange tide", "area":"Mirror Pond", "detail":"Fishers have reported warm currents and schools gathering near the deep water. A few refuse to cast their nets there after sunset."}
]

var current_incident: Dictionary = {}
var incident_age: float = 0.0
var incident_duration: float = 210.0
var incident_number: int = 0
var _last_rumour_by_npc: Dictionary = {}

func _ready() -> void:
	add_to_group("world_society")
	_roll_incident()

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	incident_age += delta
	if incident_age >= incident_duration:
		_roll_incident()

func _roll_incident() -> void:
	incident_number += 1
	incident_age = 0.0
	var index := (incident_number - 1) % INCIDENTS.size()
	current_incident = INCIDENTS[index].duplicate(true)
	EventBus.activity.emit("World rumour: %s near %s" % [current_incident.get("title", "Unknown incident"), current_incident.get("area", "the wilds")], "world")

func get_npc_rumour(npc_name: String, role: String, affinity: int = 0, region_id: String = "") -> Array[String]:
	var incident_id := str(current_incident.get("id", ""))
	var previous := str(_last_rumour_by_npc.get(npc_name, ""))
	var opening := "I heard something while I was working."
	if affinity >= 20:
		opening = "Since we've got to know each other, I'll tell you what I've heard."
	elif affinity <= -20:
		opening = "Don't go repeating this. I don't know you well enough."
	var detail := str(current_incident.get("detail", "The roads have been unusually quiet."))
	var area := str(current_incident.get("area", "the wilds"))
	if region_id != "":
		var regional: Dictionary = WorldLifeSimulation.get_region_report(region_id)
		var active_event: Dictionary = regional.get("event", {})
		if not active_event.is_empty():
			incident_id = str(active_event.get("id", incident_id))
			detail = str(active_event.get("detail", detail))
			area = str(regional.get("name", area))
		elif str(regional.get("last_change", "")) != "":
			detail = str(regional.get("last_change", detail))
			area = str(regional.get("name", area))
	match role:
		"farmer", "herbalist":
			detail = "From the fields and gatherers: " + detail
		"smith":
			detail = "Carters and miners brought word: " + detail
		"merchant":
			detail = "Trade has been affected: " + detail
		"mage":
			detail = "The scholars have been discussing this: " + detail
		"guard":
			detail = "The patrols have noticed: " + detail
	if previous == incident_id:
		return [opening, "I already told you what I know. The talk is still about %s, out near %s." % [str(current_incident.get("title", "the disturbance")), area]]
	_last_rumour_by_npc[npc_name] = incident_id
	return [opening, detail, "If you investigate, ask around when you get there. People rarely agree on what they saw."]

func get_personal_story(npc_name: String, role: String, affinity: int = 0) -> Array[String]:
	var trust_line := "I keep most things to myself."
	if affinity >= 15:
		trust_line = "You've earned a little of my trust. Here's something about me."
	elif affinity <= -10:
		trust_line = "I don't see why I should tell you anything personal."
	match npc_name:
		"Elara": return [trust_line, "I started helping travellers after a wounded hunter was brought to my door. I still keep spare remedies ready, even when the village stores run low."]
		"Borin": return [trust_line, "This land belonged to my family long before Elyndor had a name. I worry that the younger folk think soil and seasons can be rushed."]
		"Gorrim the Smith": return [trust_line, "A weapon is more than its metal. I can tell who made a blade by the way its balance settles in the hand. One day I want to forge something that outlives me."]
		"Old Man Thoren": return [trust_line, "I have seen maps that show roads where there is now only forest. The world forgets its own history unless someone goes looking."]
		"Mira": return [trust_line, "I trade in stories as much as goods. A traveller's rumour can be worth more than a chest of coins, if you know who needs to hear it."]
		"Archmage Lira": return [trust_line, "The Spire studies what lies beyond ordinary senses. Power without restraint is merely another kind of disaster."]
		"Apprentice Kael": return [trust_line, "I want to become a field researcher, not spend my whole life copying other people's notes. I just need to prove I can be trusted outside the tower."]
		_: return [trust_line, "I have my own work, worries and plans. Most people do. Ask around and you'll learn this village is full of stories."]
