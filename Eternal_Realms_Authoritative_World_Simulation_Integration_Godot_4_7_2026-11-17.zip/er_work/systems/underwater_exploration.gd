# Procedural underwater sites, survival pressure and breathable refuges.
extends Node3D
class_name UnderwaterExploration

const SITE_SPACING := 180.0
const SITE_LOAD_RADIUS := 145.0
const OXYGEN_SECONDS := 105.0
const PRESSURE_SAFE_DEPTH := 28.0
const PRESSURE_DAMAGE_INTERVAL := 2.5
const UNDERWATER_CACHE = preload("res://entities/underwater_cache.gd")

var _terrain: TerrainNoise
var _loaded_sites: Dictionary = {}
var _player_clocks: Dictionary = {}
var _pressure_clocks: Dictionary = {}
var _hud: CanvasLayer
var _status: Label
var _refresh_clock := 0.0
# Site-keyed world state: depletion, treasure ownership, boss lifecycle and marine populations.
var _persistent_sites: Dictionary = {}
var _aquatic_populations: Dictionary = {}
var _state_revision: int = 0 # Legacy local-save revision; never used for server concurrency.
var _site_revisions: Dictionary = {}
var _hydration_complete: bool = false
var _hydration_failed: bool = false
var _site_save_busy: Dictionary = {}
var _site_save_pending: Dictionary = {}

func _ready() -> void:
	add_to_group("underwater_exploration")
	_terrain = TerrainNoise.new(GameManager.world_seed)
	_build_status_ui()
	if WorldDeploymentGuard.production_mode and MMORPGNetwork.is_authority():
		if CentralBackend.is_configured():
			await _hydrate_persistent_sites()
		else:
			_hydration_failed = true
			push_error("Central backend is not configured; underwater site generation is blocked in production.")
	else:
		_hydration_complete = true

func _process(delta: float) -> void:
	if not _hydration_complete:
		return
	var players := get_tree().get_nodes_in_group("player")
	for value in players:
		if value is Node3D and is_instance_valid(value):
			_process_diver(value as Node3D, delta)
	_refresh_clock += delta
	if _refresh_clock >= 4.0:
		_refresh_clock = 0.0
		var player: Node3D = GameManager.player as Node3D if GameManager.player is Node3D else null
		if player:
			_load_sites_near(player.global_position)
			_update_status(player)
			_prune_distant_sites(player.global_position)
			_simulate_aquatic_populations()
			_retry_pending_site_saves()

func _process_diver(player: Node3D, delta: float) -> void:
	var key := player.get_instance_id()
	if not player.has_method("get"):
		return
	var in_dungeon := get_tree().get_first_node_in_group("dungeon_active") != null
	if in_dungeon or not bool(player.get("is_swimming")):
		_player_clocks[key] = OXYGEN_SECONDS
		_pressure_clocks[key] = 0.0
		player.set_meta("underwater_oxygen", OXYGEN_SECONDS)
		return
	var depth := maxf(0.0, TideSystem.level_at(player.global_position.x, player.global_position.z) - player.global_position.y)
	var safe := _is_in_air_refuge(player.global_position)
	var oxygen := float(player.get_meta("underwater_oxygen", OXYGEN_SECONDS))
	if depth < 1.8 or safe:
		oxygen = minf(OXYGEN_SECONDS, oxygen + delta * (2.8 if safe else 4.0))
	else:
		oxygen = maxf(0.0, oxygen - delta * (1.0 + maxf(0.0, depth - 12.0) * 0.012))
	player.set_meta("underwater_oxygen", oxygen)
	_player_clocks[key] = oxygen
	if oxygen <= 0.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		if player.has_method("take_damage"):
			player.take_damage(5.0 * delta, self)
	var resistance := float(player.get_meta("pressure_resistance_m", 0.0))
	var excess_depth := depth - PRESSURE_SAFE_DEPTH - resistance
	if excess_depth > 0.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		var pressure_clock := float(_pressure_clocks.get(key, 0.0)) + delta
		if pressure_clock >= PRESSURE_DAMAGE_INTERVAL:
			pressure_clock = 0.0
			if player.has_method("take_damage"):
				player.take_damage(minf(12.0, 2.0 + excess_depth * 0.18), self)
				EventBus.toast.emit("Crushing water pressure! Ascend or find a protected diving suit.", "warning")
		_pressure_clocks[key] = pressure_clock
	else:
		_pressure_clocks[key] = 0.0

func _is_in_air_refuge(pos: Vector3) -> bool:
	for refuge in get_tree().get_nodes_in_group("underwater_air_refuge"):
		if refuge is Node3D and refuge.global_position.distance_to(pos) < float(refuge.get_meta("refuge_radius", 5.0)):
			return true
	return false

func _load_sites_near(pos: Vector3) -> void:
	if not _hydration_complete:
		return
	var gx := floori(pos.x / SITE_SPACING)
	var gz := floori(pos.z / SITE_SPACING)
	for x in range(gx - 1, gx + 2):
		for z in range(gz - 1, gz + 2):
			var key := "%d:%d" % [x, z]
			if _loaded_sites.has(key):
				continue
			var rng := RandomNumberGenerator.new()
			rng.seed = hash("%s:%s:%s" % [GameManager.world_seed, x, z])
			var wx := float(x) * SITE_SPACING + rng.randf_range(24.0, SITE_SPACING - 24.0)
			var wz := float(z) * SITE_SPACING + rng.randf_range(24.0, SITE_SPACING - 24.0)
			var bed := _terrain.get_height(wx, wz)
			var depth := TideSystem.current_level - bed
			if depth < 5.5 or Vector2(wx, wz).distance_to(TerrainNoise.VILLAGE_CENTER) < 95.0:
				_loaded_sites[key] = null
				continue
			var site := _build_site(Vector3(wx, bed, wz), depth, rng, key)
			add_child(site)
			_loaded_sites[key] = site
			_restore_site_entities(site, key)
			_ensure_population(key, site_type_for_depth(depth))

func _build_site(origin: Vector3, depth: float, rng: RandomNumberGenerator, site_id: String) -> Node3D:
	var root := Node3D.new()
	root.name = "UnderseaSite_%s" % ("Trench" if depth > 24.0 else ("Ruins" if rng.randf() < 0.38 else "Reef"))
	root.position = origin
	root.set_meta("persistent_site_id", site_id)
	var site_roll := rng.randf()
	var site_type := "trench" if depth > 24.0 else ("cave" if site_roll < 0.22 else ("ruins" if site_roll < 0.52 else "reef"))
	root.set_meta("underwater_site_type", site_type)
	match site_type:
		"reef":
			for i in range(18):
				var angle := rng.randf() * TAU
				var radius := rng.randf_range(2.0, 13.0)
				var height := rng.randf_range(1.2, 5.5)
				var coral := _make_rock(Color(0.12 + rng.randf() * 0.55, 0.18 + rng.randf() * 0.38, 0.35 + rng.randf() * 0.5), Vector3(rng.randf_range(0.5, 1.4), height, rng.randf_range(0.5, 1.4)))
				coral.position = Vector3(cos(angle) * radius, height * 0.5, sin(angle) * radius)
				root.add_child(coral)
			for i in range(8):
				var fish := _make_rock(Color(0.9, 0.56, 0.2), Vector3(0.22, 0.16, 0.55))
				fish.position = Vector3(rng.randf_range(-8.0, 8.0), rng.randf_range(1.5, 5.0), rng.randf_range(-8.0, 8.0))
				root.add_child(fish)
			for i in range(10):
				var kelp := _make_rock(Color(0.08, 0.34, 0.22), Vector3(0.16, rng.randf_range(2.5, 5.5), 0.16))
				kelp.position = Vector3(rng.randf_range(-12.0, 12.0), kelp.scale.y * 0.5, rng.randf_range(-12.0, 12.0))
				root.add_child(kelp)
		"cave":
			var cave_stone := _mat(Color(0.16, 0.22, 0.27))
			for side in [-1.0, 1.0]:
				var wall := _make_rock(Color(0.13, 0.19, 0.24), Vector3(3.2, 7.0, 3.8))
				wall.position = Vector3(side * 4.0, 3.0, -1.5)
				root.add_child(wall)
			var arch := _box(Vector3(10.0, 1.8, 3.0), cave_stone)
			arch.position = Vector3(0.0, 6.0, -1.5)
			root.add_child(arch)
			# Three chambers linked by visible tunnel runs; all remain inside the water column.
			for chamber in range(3):
				var cz := -float(chamber) * 11.0
				for side in [-1.0, 1.0]:
					var chamber_wall := _box(Vector3(0.65, 5.0, 9.0), cave_stone)
					chamber_wall.position = Vector3(side * 5.4, 2.5, cz)
					root.add_child(chamber_wall)
				var roof := _box(Vector3(11.4, 0.7, 9.0), cave_stone)
				roof.position = Vector3(0.0, 5.2, cz)
				root.add_child(roof)
			for tunnel in range(2):
				var tz := -5.5 - float(tunnel) * 11.0
				for side in [-1.0, 1.0]:
					var tunnel_wall := _box(Vector3(0.65, 4.6, 12.0), cave_stone)
					tunnel_wall.position = Vector3(side * 2.3, 2.3, tz)
					root.add_child(tunnel_wall)
				var tunnel_roof := _box(Vector3(5.0, 0.65, 12.0), cave_stone)
				tunnel_roof.position = Vector3(0.0, 4.8, tz)
				root.add_child(tunnel_roof)
			for i in range(9):
				var crystal := _make_rock(Color(0.16, 0.72, 0.9), Vector3(0.3, rng.randf_range(0.8, 1.8), 0.3), true)
				crystal.position = Vector3(rng.randf_range(-3.0, 3.0), rng.randf_range(1.0, 3.0), rng.randf_range(-23.0, -3.0))
				root.add_child(crystal)
			_add_air_refuge(root, Vector3(0.0, 3.2, -8.0), 5.2)
			_add_air_refuge(root, Vector3(0.0, 3.2, -20.0), 4.2)
			_add_resource(root, Vector3(-2.5, 1.0, -5.0), "abyssal_relic", 1, "Luminous relic")
			_add_resource(root, Vector3(2.5, 0.8, -17.0), "pearl", 2, "Pearl oyster")
		"ruins":
			var stone := _mat(Color(0.30, 0.36, 0.38))
			for i in range(4):
				var pillar := _box(Vector3(1.0, rng.randf_range(3.0, 6.0), 1.0), stone)
				pillar.position = Vector3(cos(float(i) * PI * 0.5) * 5.0, pillar.scale.y * 0.5, sin(float(i) * PI * 0.5) * 5.0)
				root.add_child(pillar)
			var lintel := _box(Vector3(12.0, 0.8, 1.2), stone)
			lintel.position.y = 5.0
			root.add_child(lintel)
			var glow := _make_rock(Color(0.12, 0.75, 0.9), Vector3(0.7, 1.0, 0.7), true)
			glow.position = Vector3(0.0, 1.2, 0.0)
			root.add_child(glow)
			_add_air_refuge(root, Vector3(0.0, 2.0, 0.0), 4.8)
			_add_resource(root, Vector3(3.0, 0.8, 2.0), "abyssal_relic", 1, "Ancient relic")
			_add_treasure(root, Vector3(0.0, 0.7, -5.0))
		"trench":
			for i in range(9):
				var spike := _make_rock(Color(0.12, 0.16, 0.22), Vector3(rng.randf_range(1.0, 2.8), rng.randf_range(5.0, 12.0), rng.randf_range(1.0, 2.8)))
				spike.position = Vector3(rng.randf_range(-16.0, 16.0), spike.scale.y * 0.5, rng.randf_range(-16.0, 16.0))
				root.add_child(spike)
			var beacon := _make_rock(Color(0.16, 0.68, 1.0), Vector3(0.8, 3.0, 0.8), true)
			beacon.position = Vector3(0.0, 3.0, 0.0)
			root.add_child(beacon)
			# Lair ring and guarded cache mark a deep-sea boss arena.
			for i in range(8):
				var pillar := _make_rock(Color(0.10, 0.18, 0.28), Vector3(1.4, rng.randf_range(5.0, 8.0), 1.4))
				var angle := TAU * float(i) / 8.0
				pillar.position = Vector3(cos(angle) * 12.0, pillar.scale.y * 0.5, sin(angle) * 12.0)
				root.add_child(pillar)
			_add_treasure(root, Vector3(0.0, 0.8, -9.0))
			_add_resource(root, Vector3(-5.0, 1.0, 5.0), "abyssal_relic", 2, "Abyssal crystal")
			_spawn_lair_boss(root, origin, depth)
	# Every generated location receives a small, biome-appropriate harvest cluster.
	if site_type == "reef":
		_add_resource(root, Vector3(4.0, 0.7, 3.0), "coral_fragment", 2, "Living coral")
		_add_resource(root, Vector3(-4.0, 0.6, -2.0), "seaweed", 3, "Kelp fronds")
	return root



func _spawn_lair_boss(parent: Node3D, origin: Vector3, depth: float) -> void:
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return
	for existing in get_tree().get_nodes_in_group("marine_hostile"):
		if is_instance_valid(existing) and existing is Node3D and (existing as Node3D).global_position.distance_to(origin) < 80.0:
			return
	var boss := MarineCreature.new()
	boss.creature_id = "deep_sea_kraken" if depth > 34.0 else "abyssal_leviathan"
	boss.display_name = "The Drowned Sovereign" if depth > 34.0 else "Abyssal Leviathan"
	boss.body_color = Color(0.12, 0.22, 0.42) if depth > 34.0 else Color(0.16, 0.34, 0.48)
	boss.body_scale = 2.8 if depth > 34.0 else 2.15
	boss.is_hostile = true
	boss.is_deep_boss = true
	boss.max_health = 1800.0 if depth > 34.0 else 950.0
	boss.current_health = boss.max_health
	boss.attack_damage = 24.0 if depth > 34.0 else 17.0
	boss.attack_range = 8.0 if depth > 34.0 else 6.0
	boss.swim_speed = 3.0 if depth > 34.0 else 2.5
	boss.position = Vector3(0.0, 8.0, 0.0)
	boss.set_meta("underwater_lair_boss", true)
	boss.set_meta("persistent_boss_id", str(parent.get_meta("persistent_site_id", "")) + ":boss")
	boss.tree_exiting.connect(_on_lair_boss_exiting.bind(boss))
	parent.add_child(boss)

func _add_resource(parent: Node3D, local_pos: Vector3, item: String, count: int, title: String) -> void:
	var node := UNDERWATER_CACHE.new() as Node3D
	node.set("persistent_key", str(parent.get_meta("persistent_site_id", "")) + ":resource:" + item + ":" + str(local_pos))
	node.name = "Underwater_%s" % item
	node.set("item_id", item)
	node.set("amount", count)
	node.set("display_name", title)
	node.position = local_pos
	parent.add_child(node)

func _add_treasure(parent: Node3D, local_pos: Vector3) -> void:
	var node := UNDERWATER_CACHE.new() as Node3D
	node.set("persistent_key", str(parent.get_meta("persistent_site_id", "")) + ":treasure:" + str(local_pos))
	node.name = "SunkenAncientCache"
	node.set("is_treasure", true)
	node.set("display_name", "Sunken ancient cache")
	node.position = local_pos
	parent.add_child(node)

func _add_air_refuge(parent: Node3D, local_pos: Vector3, radius: float) -> void:
	var refuge := Area3D.new()
	refuge.name = "AncientAirPocket"
	refuge.position = local_pos
	refuge.set_meta("refuge_radius", radius)
	refuge.add_to_group("underwater_air_refuge")
	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new(); sphere.radius = radius
	shape.shape = sphere
	refuge.add_child(shape)
	parent.add_child(refuge)

func _make_rock(color: Color, size: Vector3, emissive: bool = false) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var sphere := SphereMesh.new(); sphere.radius = 0.5; sphere.height = 1.0; sphere.radial_segments = 10; sphere.rings = 6
	mesh.mesh = sphere
	mesh.scale = size
	mesh.material_override = _mat(color, emissive)
	return mesh

func _box(size: Vector3, material: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new(); var box := BoxMesh.new(); box.size = size
	mesh.mesh = box; mesh.material_override = material
	return mesh

func _mat(color: Color, emissive: bool = false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.82
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.6
	return material

func _prune_distant_sites(pos: Vector3) -> void:
	for key in _loaded_sites.keys():
		var site: Variant = _loaded_sites[key]
		if site == null:
			continue
		if not is_instance_valid(site):
			_loaded_sites.erase(key)
		elif (site as Node3D).global_position.distance_to(pos) > SITE_LOAD_RADIUS * 2.0:
			(site as Node3D).queue_free()
			_loaded_sites.erase(key)

func _build_status_ui() -> void:
	_hud = CanvasLayer.new(); _hud.layer = 24; add_child(_hud)
	_status = Label.new(); _status.position = Vector2(22.0, 178.0); _status.add_theme_font_size_override("font_size", 15)
	_status.add_theme_color_override("font_color", Color(0.65, 0.88, 1.0)); _status.add_theme_color_override("font_shadow_color", Color(0.02, 0.08, 0.13, 0.95)); _status.add_theme_constant_override("shadow_offset_x", 1); _status.add_theme_constant_override("shadow_offset_y", 1)
	_status.visible = false; _hud.add_child(_status)

func _update_status(player: Node3D) -> void:
	if _status == null: return
	var depth := maxf(0.0, TideSystem.level_at(player.global_position.x, player.global_position.z) - player.global_position.y)
	_status.visible = bool(player.get("is_swimming"))
	if _status.visible:
		var oxygen := float(player.get_meta("underwater_oxygen", OXYGEN_SECONDS))
		var pressure := 101.3 + depth * 10.1
		_status.text = "DIVE STATUS  |  Depth: %.1f m  |  Pressure: %.0f kPa  |  Oxygen: %ds" % [depth, pressure, ceili(oxygen)]


func site_type_for_depth(depth: float) -> String:
	return "trench" if depth > 24.0 else "reef"

func _ensure_population(site_id: String, habitat: String) -> void:
	if _aquatic_populations.has(site_id):
		return
	var seed_value: int = abs(hash("%s:%s:marine" % [GameManager.world_seed, site_id]))
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	_aquatic_populations[site_id] = {"habitat": habitat, "fish": rng.randi_range(18, 42), "juveniles": rng.randi_range(3, 10), "health": 1.0, "last_simulated": Time.get_unix_time_from_system(), "revision": 1}
	var site_state: Dictionary = _persistent_sites.get(site_id, {"resources": {}, "boss": {}})
	site_state["population"] = _aquatic_populations[site_id].duplicate(true)
	_persistent_sites[site_id] = site_state
	_persist_site_to_server(site_id, site_state)

func _restore_site_entities(site: Node3D, site_id: String) -> void:
	var site_state: Dictionary = _persistent_sites.get(site_id, {})
	var saved_population: Variant = site_state.get("population", {})
	if saved_population is Dictionary and not saved_population.is_empty():
		_aquatic_populations[site_id] = saved_population.duplicate(true)
	for child in site.get_children():
		if child is UnderwaterCache:
			var cache := child as UnderwaterCache
			var saved: Dictionary = site_state.get("resources", {}).get(cache.persistent_key, {})
			cache.restore_persistent_state(saved)
		elif child is MarineCreature and bool(child.get_meta("underwater_lair_boss", false)):
			var boss_key := site_id + ":boss"
			var boss_state: Dictionary = site_state.get("boss", {})
			if str(boss_state.get("status", "alive")) == "defeated":
				child.queue_free()

func record_underwater_resource(key: String, item_id: String, amount: int, is_treasure: bool) -> void:
	if key.is_empty():
		return
	var site_id := key.get_slice(":resource:", 0) if key.contains(":resource:") else key.get_slice(":treasure:", 0)
	var state: Dictionary = _persistent_sites.get(site_id, {"resources": {}, "boss": {}})
	var resources: Dictionary = state.get("resources", {})
	resources[key] = {"claimed": true, "item_id": item_id, "amount": amount, "treasure": is_treasure, "claimed_at": Time.get_unix_time_from_system()}
	state["resources"] = resources
	_persistent_sites[site_id] = state
	_state_revision += 1
	_persist_site_to_server(site_id, state)

func _on_lair_boss_exiting(boss: Node) -> void:
	if not is_instance_valid(boss) or not bool(boss.get_meta("underwater_lair_boss", false)):
		return
	var boss_key := str(boss.get_meta("persistent_boss_id", ""))
	if boss_key.is_empty() or float(boss.get("current_health")) > 0.0:
		return
	var site_id := boss_key.trim_suffix(":boss")
	var state: Dictionary = _persistent_sites.get(site_id, {"resources": {}})
	state["boss"] = {"status": "defeated", "defeated_at": Time.get_unix_time_from_system(), "boss_id": str(boss.get("creature_id"))}
	_persistent_sites[site_id] = state
	_state_revision += 1
	_persist_site_to_server(site_id, state)

func _hydrate_persistent_sites() -> void:
	var response: Dictionary = await CentralBackend.server_load_world_entities("underwater_site")
	if not bool(response.get("ok", false)):
		_hydration_failed = true
		push_error("Underwater world hydration failed; procedural site generation is blocked to prevent overwriting persistent discoveries.")
		return
	var body: Dictionary = response.get("body", {})
	for row_variant in body.get("entities", []):
		if not row_variant is Dictionary:
			continue
		var row: Dictionary = row_variant
		var region := str(row.get("region_id", ""))
		if not region.begins_with("underwater_"):
			continue
		var site_id := region.trim_prefix("underwater_")
		var state: Variant = row.get("entity_state", {})
		if site_id.is_empty() or not state is Dictionary:
			continue
		_persistent_sites[site_id] = state.duplicate(true)
		_site_revisions[site_id] = int(row.get("revision", 0))
		var population: Variant = state.get("population", {})
		if population is Dictionary and not population.is_empty():
			_aquatic_populations[site_id] = population.duplicate(true)
	_hydration_complete = true
	_broadcast_shared_underwater_state()

func _persist_site_to_server(site_id: String, state: Dictionary) -> void:
	if MMORPGNetwork.is_online() and MMORPGNetwork.is_authority():
		_broadcast_underwater_site_state(site_id, state)
	if not WorldDeploymentGuard.production_mode or not MMORPGNetwork.is_authority() or not CentralBackend.is_configured():
		return
	var normalized_state := state.duplicate(true)
	if _aquatic_populations.has(site_id) and not normalized_state.has("population"):
		normalized_state["population"] = _aquatic_populations[site_id].duplicate(true)
	normalized_state["site_id"] = site_id
	if _site_save_busy.get(site_id, false):
		_site_save_pending[site_id] = normalized_state
		return
	_site_save_busy[site_id] = true
	var next_state := normalized_state
	while true:
		var revision := int(_site_revisions.get(site_id, 0))
		var stable_id := MMORPGNetwork._stable_world_uuid("%s:underwater-site:%s" % [MMORPGNetwork.SINGLE_WORLD_ID, site_id])
		var payload := next_state.duplicate(true)
		var key := (stable_id + ":" + JSON.stringify(payload).sha256_text()).sha256_text()
		var result: Dictionary = await CentralBackend.server_save_world_entity(stable_id, "underwater_site", "underwater_%s" % site_id, revision, payload, key)
		if bool(result.get("ok", false)):
			_site_revisions[site_id] = int(result.get("body", {}).get("revision", revision))
		else:
			_site_save_pending[site_id] = next_state.duplicate(true)
			push_warning("Underwater site save failed for %s; latest state remains queued for retry: %s" % [site_id, str(result.get("error", result.get("status", "unknown")))])
			break
		if not _site_save_pending.has(site_id):
			break
		next_state = _site_save_pending[site_id]
		_site_save_pending.erase(site_id)
	_site_save_busy.erase(site_id)


func _retry_pending_site_saves() -> void:
	if _site_save_pending.is_empty():
		return
	var pending_ids: Array = _site_save_pending.keys()
	for site_id_variant in pending_ids:
		var site_id := str(site_id_variant)
		if _site_save_busy.get(site_id, false):
			continue
		var queued: Dictionary = _site_save_pending[site_id]
		_site_save_pending.erase(site_id)
		_persist_site_to_server(site_id, queued)


func _broadcast_shared_underwater_state() -> void:
	if not MMORPGNetwork.is_online() or not MMORPGNetwork.is_authority():
		return
	rpc("apply_shared_underwater_snapshot", _persistent_sites.duplicate(true), _aquatic_populations.duplicate(true))

func _broadcast_underwater_site_state(site_id: String, state: Dictionary) -> void:
	if not MMORPGNetwork.is_online() or not MMORPGNetwork.is_authority():
		return
	var population: Dictionary = _aquatic_populations.get(site_id, {}).duplicate(true)
	rpc("apply_shared_underwater_site", site_id, state.duplicate(true), population)

@rpc("authority", "call_remote", "reliable")
func apply_shared_underwater_site(site_id: String, state: Dictionary, population: Dictionary) -> void:
	if MMORPGNetwork.is_authority():
		return
	_persistent_sites[site_id] = state.duplicate(true)
	if not population.is_empty():
		_aquatic_populations[site_id] = population.duplicate(true)
	var site: Variant = _loaded_sites.get(site_id)
	if site is Node3D:
		_restore_site_entities(site, site_id)

func send_snapshot_to_peer(peer_id: int) -> void:
	if not MMORPGNetwork.is_online() or not MMORPGNetwork.is_authority() or peer_id <= 1:
		return
	rpc_id(peer_id, "apply_shared_underwater_snapshot", _persistent_sites.duplicate(true), _aquatic_populations.duplicate(true))

@rpc("authority", "call_remote", "reliable")
func apply_shared_underwater_snapshot(sites: Dictionary, populations: Dictionary) -> void:
	if MMORPGNetwork.is_authority():
		return
	_persistent_sites = sites.duplicate(true)
	_aquatic_populations = populations.duplicate(true)
	for site_id_variant in _loaded_sites.keys():
		var site_id := str(site_id_variant)
		var site: Variant = _loaded_sites[site_id]
		if site is Node3D:
			_restore_site_entities(site, site_id)

func get_save_state() -> Dictionary:
	return {"revision": _state_revision, "site_revisions": _site_revisions.duplicate(true), "sites": _persistent_sites.duplicate(true), "populations": _aquatic_populations.duplicate(true)}

func restore_from_save(data: Dictionary) -> void:
	_persistent_sites = data.get("sites", {}).duplicate(true) if data.get("sites", {}) is Dictionary else {}
	_aquatic_populations = data.get("populations", {}).duplicate(true) if data.get("populations", {}) is Dictionary else {}
	_state_revision = int(data.get("revision", 0))
	_site_revisions = data.get("site_revisions", {}).duplicate(true) if data.get("site_revisions", {}) is Dictionary else {}
	for key in _loaded_sites.keys():
		var site: Variant = _loaded_sites[key]
		if site is Node3D:
			_restore_site_entities(site, str(key))


func _simulate_aquatic_populations() -> void:
	var now := Time.get_unix_time_from_system()
	for site_id in _aquatic_populations.keys():
		var population: Dictionary = _aquatic_populations[site_id]
		var elapsed := clampf(float(now) - float(population.get("last_simulated", now)), 0.0, 86400.0 * 30.0)
		if elapsed < 60.0:
			continue
		var fish := int(population.get("fish", 20))
		var juveniles := int(population.get("juveniles", 4))
		var health := clampf(float(population.get("health", 1.0)), 0.0, 1.0)
		var seasons := floori(elapsed / 3600.0)
		# Bounded logistic growth with habitat stress and juvenile recruitment.
		for _step in range(mini(seasons, 24)):
			var carrying_capacity := 70 if str(population.get("habitat", "reef")) == "reef" else 42
			var growth := int(round(float(fish) * 0.018 * health * (1.0 - float(fish) / float(carrying_capacity))))
			fish = clampi(fish + growth + int(juveniles / 8), 0, carrying_capacity)
			juveniles = clampi(juveniles + int(fish * 0.025) - int(juveniles * 0.08), 0, 30)
		population["fish"] = fish
		population["juveniles"] = juveniles
		population["last_simulated"] = now
		population["revision"] = int(population.get("revision", 0)) + 1
		_aquatic_populations[site_id] = population
		var site_state: Dictionary = _persistent_sites.get(site_id, {"resources": {}, "boss": {}})
		site_state["population"] = population
		_persistent_sites[site_id] = site_state
		_state_revision += 1
		_persist_site_to_server(site_id, site_state)
