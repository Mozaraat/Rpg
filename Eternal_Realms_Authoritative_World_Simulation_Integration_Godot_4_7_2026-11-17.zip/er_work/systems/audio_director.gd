# Procedural ambience beds. Small looping WAVs are generated at runtime, so the
# world has audible atmosphere without requiring external copyrighted assets.
extends Node
class_name AudioDirector

var _players: Dictionary = {}
var _current: String = ""
var _fade_tweens: Dictionary = {}

func _ready() -> void:
	add_to_group("audio")
	for id in ["village", "wilds", "night", "boss", "dungeon", "rain"]:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		p.volume_db = -24.0
		add_child(p)
		_players[id] = p
		_assign_tone(p, id)
	_current = "village"
	_players["village"].play()

func _process(_delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	var want: String = _detect()
	if want != _current:
		_crossfade(_current, want)
		_current = want
	var w = get_tree().get_first_node_in_group("weather")
	var raining: bool = w != null and str(w.get("kind")) in ["rain", "storm"]
	var rp: AudioStreamPlayer = _players["rain"]
	if raining and not rp.playing:
		rp.volume_db = -29.0
		rp.play()
	elif not raining and rp.playing:
		rp.stop()

func _detect() -> String:
	var p = GameManager.player
	if p == null:
		return "village"
	if get_tree().get_first_node_in_group("dungeon_active"):
		return "dungeon"
	for e in get_tree().get_nodes_in_group("enemy"):
		if e is Node3D and e.get("is_boss") and bool(e.is_boss) and p.global_position.distance_to(e.global_position) < 28.0:
			return "boss"
	var dn = get_tree().get_first_node_in_group("day_night")
	if dn and not bool(dn.is_day):
		return "night"
	var d: float = Vector2(p.global_position.x, p.global_position.z).distance_to(TerrainNoise.VILLAGE_CENTER)
	return "village" if d < 40.0 else "wilds"

func _crossfade(from_id: String, to_id: String) -> void:
	if _players.has(to_id):
		var incoming: AudioStreamPlayer = _players[to_id]
		incoming.volume_db = -42.0
		if not incoming.playing:
			incoming.play()
			_fade_volume(to_id, -23.0, 1.8, false)
	if _players.has(from_id):
		_fade_volume(from_id, -42.0, 1.8, true)
	EventBus.activity.emit("Ambience shifts: %s" % to_id, "world")

func _fade_volume(id: String, target_db: float, duration: float, stop_after: bool) -> void:
	if _fade_tweens.has(id) and is_instance_valid(_fade_tweens[id]):
		_fade_tweens[id].kill()
	var player: AudioStreamPlayer = _players[id]
	var tw: Tween = create_tween()
	_fade_tweens[id] = tw
	tw.tween_property(player, "volume_db", target_db, duration).set_trans(Tween.TRANS_SINE)
	if stop_after:
		tw.tween_callback(player.stop)

func _assign_tone(player: AudioStreamPlayer, id: String) -> void:
	# A seamless 2-second stereo loop with layered, deliberately quiet tones.
	const RATE: int = 22050
	const SECONDS: int = 2
	var bytes := PackedByteArray()
	bytes.resize(RATE * SECONDS * 2)
	var seed_value: int = absi(id.hash())
	var base_freq: float = 92.0 + float(seed_value % 90)
	var amplitude: float = 0.055 if id != "boss" else 0.075
	for i in range(RATE * SECONDS):
		var t: float = float(i) / float(RATE)
		var swell: float = 0.72 + 0.28 * sin(TAU * t / SECONDS)
		var sample: float = sin(TAU * base_freq * t) * 0.48
		sample += sin(TAU * base_freq * 1.503 * t) * 0.20
		sample += sin(TAU * base_freq * 2.01 * t) * 0.10
		if id == "rain" or id == "wilds":
			sample += sin(TAU * (base_freq * 5.2) * t) * 0.08
		if id == "night":
			sample += sin(TAU * 660.0 * t) * 0.025 * sin(TAU * 0.5 * t)
		if id == "boss":
			sample += sin(TAU * 48.0 * t) * 0.22
		var value: int = int(clampf(sample * amplitude * swell, -1.0, 1.0) * 32767.0)
		bytes.encode_s16(i * 2, value)
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
	wav.loop_begin = 0
	wav.loop_end = RATE * SECONDS
	player.stream = wav
