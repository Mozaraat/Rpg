extends Node

var businesses: Array[Dictionary] = []
var settlements: Array[Dictionary] = []
var _clock := 0.0
func _ready() -> void:
    add_to_group("player_businesses")
    var saved: Variant = PlayerData.stats.get("owned_businesses", [])
    if saved is Array: businesses.assign(saved)
    var saved_settlements: Variant = PlayerData.stats.get("player_settlements", [])
    if saved_settlements is Array: settlements.assign(saved_settlements)

func refresh_from_player_data() -> void:
    var saved: Variant = PlayerData.stats.get("owned_businesses", [])
    businesses.clear()
    if saved is Array: businesses.assign(saved)
    var saved_settlements: Variant = PlayerData.stats.get("player_settlements", [])
    settlements.clear()
    if saved_settlements is Array: settlements.assign(saved_settlements)

func _input(event: InputEvent) -> void:
    if GameManager.input_locked or not (event is InputEventKey) or not event.pressed or event.echo: return
    if event.keycode == KEY_F6: open_business()
    elif event.keycode == KEY_F8: inspect_settlement()
    elif event.keycode == KEY_F7:
        if invest(10): EventBus.toast.emit("You invest 10 gold in your business.", "success")
        else: EventBus.toast.emit("Not enough gold or no business to invest in.", "warning")

func _process(delta: float) -> void:
    _clock += delta
    if _clock < 90.0: return
    _clock = 0.0
    for shop in businesses:
        var kind := str(shop.get("kind", "market"))
        var input_id := "wheat" if kind == "bakery" else ("wood_log" if kind == "carpenter" else "milk")
        var output_id := "flour" if kind == "bakery" else ("wood_plank" if kind == "carpenter" else "cheese")
        if kind == "market":
            var sale_items := ["bread", "flour", "wood_plank", "egg", "milk", "wool", "fish_trout", "carrot", "farm_berries", "wheat", "fish_bass", "fish_mackerel"]
            for sale_id in sale_items:
                if PlayerData.remove_item(sale_id, 1):
                    var unit_value := int(ItemDB.def(sale_id).get("value", 4))
                    shop["stock"] = int(shop.get("stock", 0)) + 1
                    shop["sales"] = int(shop.get("sales", 0)) + 1
                    PlayerData.add_gold(maxi(1, int(float(unit_value) * 0.7)))
                    break
        elif kind == "bakery":
            if PlayerData.count_item("flour") > 0 and PlayerData.remove_item("flour", 1):
                PlayerData.add_item("bread", 1)
                shop["stock"] = int(shop.get("stock", 0)) + 1
            elif PlayerData.count_item("wheat") > 0 and PlayerData.remove_item("wheat", 1):
                PlayerData.add_item("flour", 1)
                shop["stock"] = int(shop.get("stock", 0)) + 1
        elif PlayerData.count_item(input_id) > 0 and PlayerData.remove_item(input_id, 1):
            PlayerData.add_item(output_id, 1)
            shop["stock"] = int(shop.get("stock", 0)) + 1
        if int(shop.get("stock", 0)) > 0 and kind != "market":
            shop["sales"] = int(shop.get("sales", 0)) + 1
            PlayerData.add_gold(2 + int(shop.get("level", 1)))
            shop["stock"] = int(shop.get("stock", 0)) - 1
    _update_settlements()
    PlayerData.stats["owned_businesses"] = businesses.duplicate(true)
    PlayerData.stats["player_settlements"] = settlements.duplicate(true)

func open_business() -> void:
    if businesses.is_empty():
        EventBus.toast.emit("Build a market stall or workshop, then register it here. F6 manages your businesses.", "info")
        return
    var shop: Dictionary = businesses[0]
    shop["level"] = int(shop.get("level",1))
    EventBus.toast.emit("%s | Level %d | Stock %d | Sales %d. Supply goods to keep production moving." % [str(shop.get("name","Your Business")), int(shop.level), int(shop.get("stock",0)), int(shop.get("sales",0))], "info")

func register_business(kind: String, name: String = "") -> void:
    if not ["market","bakery","carpenter","dairy"].has(kind): return
    businesses.append({"kind":kind,"name":name if name != "" else kind.capitalize(),"level":1,"stock":0,"sales":0,"capital":0})
    PlayerData.stats["owned_businesses"] = businesses.duplicate(true)
    EventBus.toast.emit("Business registered: " + businesses[-1].name, "success")

func register_settlement(position: Vector3, settlement_name: String = "Hearthstead") -> void:
    for settlement in settlements:
        var existing := Vector3(float(settlement.get("x",0.0)),float(settlement.get("y",0.0)),float(settlement.get("z",0.0)))
        if existing.distance_to(position) < 80.0:
            EventBus.toast.emit("This area is already part of %s." % str(settlement.get("name","your settlement")), "info")
            return
    settlements.append({"name":settlement_name,"x":position.x,"y":position.y,"z":position.z,"level":1,"structures":1,"population":0})
    PlayerData.stats["player_settlements"] = settlements.duplicate(true)
    EventBus.toast.emit("Settlement founded: %s. Build within its territory to help it grow." % settlement_name, "success")

func _update_settlements() -> void:
    for settlement in settlements:
        var center := Vector3(float(settlement.get("x",0.0)),float(settlement.get("y",0.0)),float(settlement.get("z",0.0)))
        var count := 0
        for node in get_tree().get_nodes_in_group("player_built"):
            if node is Node3D and (node as Node3D).global_position.distance_to(center) <= 55.0: count += 1
        var old_level := int(settlement.get("level",1))
        settlement["structures"] = count
        settlement["level"] = maxi(1, 1 + int(count / 5))
        if int(settlement["level"]) > old_level:
            EventBus.toast.emit("%s has grown to settlement level %d." % [str(settlement.get("name","Settlement")), int(settlement["level"])], "success")
    PlayerData.stats["player_settlements"] = settlements.duplicate(true)

func inspect_settlement() -> void:
    if settlements.is_empty():
        EventBus.toast.emit("Build a settlement hall to claim and grow a new settlement.", "info")
        return
    var settlement: Dictionary = settlements[0]
    EventBus.toast.emit("%s | Level %d | %d structures | Build roads, homes and workshops within 55 metres." % [str(settlement.get("name","Settlement")),int(settlement.get("level",1)),int(settlement.get("structures",1))], "info")

func invest(amount: int) -> bool:
    if businesses.is_empty() or amount <= 0 or not PlayerData.spend_gold(amount): return false
    businesses[0]["capital"] = int(businesses[0].get("capital",0)) + amount
    if int(businesses[0]["capital"]) >= 50:
        businesses[0]["capital"] = 0; businesses[0]["level"] = int(businesses[0].get("level",1)) + 1
        EventBus.toast.emit("Your business expanded to level %d." % int(businesses[0].level), "success")
    PlayerData.stats["owned_businesses"] = businesses.duplicate(true)
    return true
