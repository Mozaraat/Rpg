# AmbientLife - things that make the world feel inhabited:
# chickens in the village, rabbits in the meadows, birds circling overhead, butterflies by day.
extends Node3D
class_name AmbientLife

var noise: TerrainNoise
var _birds: Array[Node3D] = []
var _bird_data: Array[Dictionary] = []
var _perched: Array[Node3D] = []
var _perched_data: Array[Dictionary] = []
var _butterflies: Array[Node3D] = []
var _bfly_data: Array[Dictionary] = []
var _t: float = 0.0
var _day_node: Node = null

func _ready() -> void:
	noise = TerrainNoise.new(GameManager.world_seed)
	_spawn_chickens()
	_spawn_rabbits()
	_spawn_large_wildlife()
	_spawn_birds()
	_spawn_perched_birds()
	_spawn_butterflies()
	print("[AmbientLife] Critters, birds and butterflies ready")

func _ground(x: float, z: float) -> float:
	return noise.get_height(x, z)

func _spawn_chickens() -> void:
	var vc: Vector2 = TerrainNoise.VILLAGE_CENTER
	var clusters: Array[Vector2] = [vc + Vector2(5.0, -17.5), vc + Vector2(-5.5, 14.5), vc + Vector2(9.0, 12.0)]
	for c in clusters:
		for i in range(3):
			var p: Vector2 = c + Vector2(randf_range(-2.5, 2.5), randf_range(-2.5, 2.5))
			var ch := Critter.new()
			ch.kind = "chicken"
			ch.position = Vector3(p.x, _ground(p.x, p.y) + 0.1, p.y)
			add_child(ch)

func _spawn_rabbits() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = GameManager.world_seed + 99
	var placed: int = 0
	var tries: int = 0
	while placed < 8 and tries < 300:
		tries += 1
		var p: Vector2 = Vector2(12, -25) + Vector2(rng.randf_range(-30, 30), rng.randf_range(-30, 30))
		if rng.randf() < 0.4:
			p = Vector2(-60, -15) + Vector2(rng.randf_range(-25, 25), rng.randf_range(-25, 25))
		if p.x < -115.0 or p.x > 55.0 or p.y < -115.0 or p.y > 55.0:
			continue
		var h: float = _ground(p.x, p.y)
		if h < 2.0 or h > 7.0 or noise.settlement_mask(p.x, p.y) > 0.05:
			continue
		var r := Critter.new()
		r.kind = "rabbit"
		r.position = Vector3(p.x, h + 0.2, p.y)
		add_child(r)
		placed += 1

func _spawn_large_wildlife() -> void:
	var species := ["deer", "wolf", "boar"]
	var rng := RandomNumberGenerator.new(); rng.seed = GameManager.world_seed + 771
	for kind in species:
		var placed := 0; var tries := 0
		while placed < 3 and tries < 100:
			tries += 1
			var center := Vector2(-55, -35) if kind == "wolf" else Vector2(20, -60)
			var p := center + Vector2(rng.randf_range(-35,35), rng.randf_range(-35,35))
			var h := _ground(p.x,p.y)
			if h < 2.0 or h > 9.0 or noise.settlement_mask(p.x,p.y) > 0.04: continue
			var animal := Critter.new(); animal.kind = kind; animal.position = Vector3(p.x,h+0.2,p.y); add_child(animal); placed += 1

# --- Birds ---------------------------------------------------------------
func _make_bird() -> Node3D:
	var b := Node3D.new()
	var body_m := StandardMaterial3D.new()
	body_m.albedo_color = Color(0.12, 0.12, 0.14)
	body_m.roughness = 0.8
	var body := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.22
	sm.height = 0.44
	sm.radial_segments = 8
	sm.rings = 4
	body.mesh = sm
	body.scale = Vector3(0.6, 0.55, 1.5)
	body.material_override = body_m
	b.add_child(body)
	for s in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.name = "WingL" if s < 0.0 else "WingR"
		b.add_child(pivot)
		var w := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.9, 0.03, 0.34)
		w.mesh = bm
		w.material_override = body_m
		w.position = Vector3(s * 0.45, 0, 0)
		pivot.add_child(w)
	b.scale = Vector3.ONE * 1.6
	return b

func _spawn_birds() -> void:
	var centers: Array[Vector2] = [TerrainNoise.VILLAGE_CENTER, TerrainNoise.SPIRE_CENTER]
	for ci in range(centers.size()):
		for i in range(6):
			var b: Node3D = _make_bird()
			add_child(b)
			_birds.append(b)
			_bird_data.append({"c": centers[ci], "r": randf_range(25.0, 60.0), "h": randf_range(24.0, 44.0),
				"a": randf() * TAU, "w": randf_range(0.12, 0.22) * (1.0 if randf() < 0.5 else -1.0),
				"flap": randf_range(7.0, 11.0), "ph": randf() * TAU})

# --- Perched birds --------------------------------------------------------
# A few birds roost on village landmarks by day so the square feels lived in.
func _spawn_perched_birds() -> void:
	var vc: Vector2 = TerrainNoise.VILLAGE_CENTER
	var spots: Array = [
		[Vector2(2.3, 1.2), 1.1, 2.2],
		[Vector2(-9.0, 2.9), 3.3, 0.2],
		[Vector2(2.5, 11.4), 2.32, PI],
		[Vector2(6.7, 6.2), 3.16, 0.0],
	]
	for s in spots:
		var local: Vector2 = s[0]
		var p: Vector2 = vc + local
		var b := _make_bird()
		b.scale = Vector3.ONE * 1.25
		add_child(b)
		b.position = Vector3(p.x, _ground(p.x, p.y) + float(s[1]), p.y)
		b.rotation.y = float(s[2])
		_perched.append(b)
		_perched_data.append({"base": b.position, "yaw": float(s[2]), "ph": randf() * TAU})

# --- Butterflies ---------------------------------------------------------
func _spawn_butterflies() -> void:
	var cols: Array[Color] = [Color(1.0, 0.85, 0.25), Color(0.95, 0.5, 0.2), Color(0.5, 0.7, 1.0), Color(0.95, 0.95, 0.95), Color(0.9, 0.45, 0.7)]
	for i in range(12):
		var b := Node3D.new()
		var m := StandardMaterial3D.new()
		m.albedo_color = cols[i % cols.size()]
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.roughness = 0.9
		for s in [-1.0, 1.0]:
			var pivot := Node3D.new()
			pivot.name = "WingL" if s < 0.0 else "WingR"
			b.add_child(pivot)
			var w := MeshInstance3D.new()
			var q := QuadMesh.new()
			q.size = Vector2(0.14, 0.12)
			w.mesh = q
			w.material_override = m
			w.rotation.x = -PI * 0.5
			w.position = Vector3(s * 0.07, 0, 0)
			pivot.add_child(w)
		b.visible = false
		add_child(b)
		_butterflies.append(b)
		_bfly_data.append({"pos": Vector3.ZERO, "ph": randf() * TAU, "sp": randf_range(0.6, 1.2), "alive": false})

func _process(delta: float) -> void:
	_t += delta
	if _day_node == null:
		_day_node = get_tree().get_first_node_in_group("day_night")
	var is_day: bool = true
	if _day_node:
		is_day = _day_node.is_day and _day_node.get_sun_direction().y > 0.12
	_update_birds(delta, is_day)
	_update_perched_birds(is_day)
	_update_butterflies(delta, is_day)

func _update_birds(delta: float, is_day: bool) -> void:
	for i in range(_birds.size()):
		var b: Node3D = _birds[i]
		b.visible = is_day
		if not is_day:
			continue
		var d: Dictionary = _bird_data[i]
		d["a"] = float(d["a"]) + float(d["w"]) * delta
		var c: Vector2 = d["c"]
		var a: float = d["a"]
		var r: float = float(d["r"]) + sin(_t * 0.2 + float(d["ph"])) * 6.0
		var pos := Vector3(c.x + cos(a) * r, float(d["h"]) + sin(_t * 0.5 + float(d["ph"])) * 2.0, c.y + sin(a) * r)
		var tangent := Vector3(-sin(a), 0, cos(a)) * signf(float(d["w"]))
		b.global_position = pos
		b.look_at(pos + tangent, Vector3.UP)
		b.rotation.z += 0.25 * signf(float(d["w"]))   # bank into the turn
		var flap: float = sin(_t * float(d["flap"]) + float(d["ph"])) * 0.7
		(b.get_node("WingL") as Node3D).rotation.z = flap
		(b.get_node("WingR") as Node3D).rotation.z = -flap

func _update_perched_birds(is_day: bool) -> void:
	for i in range(_perched.size()):
		var b: Node3D = _perched[i]
		b.visible = is_day
		if not is_day:
			continue
		var d: Dictionary = _perched_data[i]
		var base: Vector3 = d["base"]
		var ph: float = d["ph"]
		var hop: float = maxf(0.0, sin(_t * 1.1 + ph) - 0.94) * 2.2
		b.global_position = Vector3(base.x, base.y + hop, base.z)
		b.rotation.y = float(d["yaw"]) + sin(_t * 0.34 + ph) * 0.32
		var wing: float = sin(_t * 2.3 + ph) * 0.07
		(b.get_node("WingL") as Node3D).rotation.z = wing
		(b.get_node("WingR") as Node3D).rotation.z = -wing

func _update_butterflies(delta: float, is_day: bool) -> void:
	var player: Node3D = GameManager.player
	if player == null:
		return
	var pp: Vector3 = player.global_position
	for i in range(_butterflies.size()):
		var b: Node3D = _butterflies[i]
		var d: Dictionary = _bfly_data[i]
		if not is_day:
			b.visible = false
			d["alive"] = false
			continue
		var pos: Vector3 = d["pos"]
		if not bool(d["alive"]) or Vector2(pos.x - pp.x, pos.z - pp.z).length() > 34.0:
			# (re)place somewhere in a nearby meadow
			for t in range(8):
				var p := Vector2(pp.x + randf_range(-28.0, 28.0), pp.z + randf_range(-28.0, 28.0))
				var h: float = _ground(p.x, p.y)
				if h > 1.8 and h < 8.0 and noise.get_forest_density(p.x, p.y, h) < 0.6:
					d["pos"] = Vector3(p.x, h + 1.2, p.y)
					d["alive"] = true
					b.visible = true
					break
			continue
		var ph: float = d["ph"]
		var sp: float = d["sp"]
		var drift := Vector3(sin(_t * 0.7 * sp + ph) * 0.9, 0, cos(_t * 0.55 * sp + ph * 1.3) * 0.9)
		pos += drift * delta
		var h2: float = _ground(pos.x, pos.z)
		pos.y = lerpf(pos.y, h2 + 1.1 + sin(_t * 1.6 * sp + ph) * 0.5, clampf(delta * 2.0, 0.0, 1.0))
		d["pos"] = pos
		b.global_position = pos
		b.rotation.y = atan2(drift.x, drift.z)
		var flap: float = sin(_t * 18.0 + ph) * 0.9
		(b.get_node("WingL") as Node3D).rotation.z = flap
		(b.get_node("WingR") as Node3D).rotation.z = -flap
