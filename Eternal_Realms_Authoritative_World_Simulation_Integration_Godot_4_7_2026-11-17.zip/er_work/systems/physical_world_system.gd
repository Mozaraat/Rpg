extends Node

## Shared, metre-based physical model for the overworld.
## Gameplay systems can query these laws instead of inventing local constants.
## This is a practical real-time approximation, not a CFD or climate simulator.

signal environment_sampled(air_temperature_c: float, pressure_kpa: float, wind: Vector3)

const STANDARD_GRAVITY: float = 9.80665
const SEA_LEVEL_AIR_DENSITY: float = 1.225
const SEA_LEVEL_PRESSURE_KPA: float = 101.325
const DRY_AIR_GAS_CONSTANT: float = 287.05
const WATER_DENSITY: float = 1000.0
const AIR_SPECIFIC_HEAT: float = 1005.0
const WATER_SPECIFIC_HEAT: float = 4184.0
const LATENT_HEAT_VAPORIZATION: float = 2256000.0
const FREEZING_POINT_C: float = 0.0
const BOILING_POINT_SEA_LEVEL_C: float = 100.0

@export_range(0.0, 0.02, 0.0001) var gravity_height_gradient: float = 0.000003
@export_range(0.0, 0.2, 0.001) var base_wind_speed_m_s: float = 3.5
@export_range(0.0, 1.0, 0.01) var wind_gustiness: float = 0.22
@export_range(0.0, 1.0, 0.01) var humidity: float = 0.62

var air_temperature_c: float = 18.0
var pressure_kpa: float = SEA_LEVEL_PRESSURE_KPA
var air_density: float = SEA_LEVEL_AIR_DENSITY
var wind_velocity: Vector3 = Vector3.ZERO
var _sample_clock: float = 0.0
var _world_seed: int = 73421

func _ready() -> void:
	add_to_group("physical_world")
	var seed_value: Variant = ProjectSettings.get_setting("application/config/name", "Eternal Realms")
	_world_seed = hash(str(seed_value))
	_sample_environment()

func _process(delta: float) -> void:
	_sample_clock += delta
	if _sample_clock >= 2.0:
		_sample_clock = 0.0
		_sample_environment()

## Gravity weakens very slightly with altitude, as it does on Earth.
func gravity_at(position: Vector3 = Vector3.ZERO) -> float:
	return STANDARD_GRAVITY * maxf(0.5, 1.0 - maxf(position.y, 0.0) * gravity_height_gradient)

## Barometric pressure approximation for the lower atmosphere (troposphere).
func pressure_at_altitude(altitude_m: float, temperature_c: float = 15.0) -> float:
	var kelvin := maxf(180.0, temperature_c + 273.15)
	var lapse_temperature := maxf(180.0, kelvin - 0.0065 * maxf(altitude_m, 0.0))
	var exponent := 5.25588
	return SEA_LEVEL_PRESSURE_KPA * pow(lapse_temperature / kelvin, exponent)

func air_density_at(altitude_m: float, temperature_c: float = 15.0) -> float:
	var pressure_pa := pressure_at_altitude(altitude_m, temperature_c) * 1000.0
	var kelvin := maxf(150.0, temperature_c + 273.15 - 0.0065 * maxf(altitude_m, 0.0))
	return pressure_pa / (DRY_AIR_GAS_CONSTANT * kelvin)

## Quadratic aerodynamic drag: F = 1/2 rho Cd A v^2, opposite motion.
func aerodynamic_drag(velocity: Vector3, drag_coefficient: float, frontal_area_m2: float, altitude_m: float = 0.0) -> Vector3:
	var relative_speed := velocity.length()
	if relative_speed <= 0.0001:
		return Vector3.ZERO
	var density := air_density_at(altitude_m, air_temperature_c)
	var magnitude := 0.5 * density * maxf(0.0, drag_coefficient) * maxf(0.0, frontal_area_m2) * relative_speed * relative_speed
	return -velocity.normalized() * magnitude

## Archimedes' principle. Returns upward force in newtons.
func buoyancy_force(displaced_volume_m3: float, fluid_density_kg_m3: float = WATER_DENSITY) -> float:
	return maxf(0.0, displaced_volume_m3) * maxf(0.0, fluid_density_kg_m3) * STANDARD_GRAVITY

## Linearized Newton cooling; positive result means heat flows into the object.
func heat_exchange_watts(object_temp_c: float, ambient_temp_c: float, heat_transfer_w_m2k: float, area_m2: float) -> float:
	return (ambient_temp_c - object_temp_c) * maxf(0.0, heat_transfer_w_m2k) * maxf(0.0, area_m2)

func temperature_after_exchange(object_temp_c: float, ambient_temp_c: float, heat_transfer_w_m2k: float, area_m2: float, mass_kg: float, specific_heat_j_kgk: float, delta: float) -> float:
	if mass_kg <= 0.0 or specific_heat_j_kgk <= 0.0:
		return object_temp_c
	var watts := heat_exchange_watts(object_temp_c, ambient_temp_c, heat_transfer_w_m2k, area_m2)
	return object_temp_c + watts * maxf(0.0, delta) / (mass_kg * specific_heat_j_kgk)

func water_phase_at(temperature_c: float, local_pressure_kpa: float = SEA_LEVEL_PRESSURE_KPA) -> String:
	if temperature_c <= FREEZING_POINT_C:
		return "ice"
	var boiling_point := BOILING_POINT_SEA_LEVEL_C + 27.0 * log(maxf(1.0, local_pressure_kpa) / SEA_LEVEL_PRESSURE_KPA)
	if temperature_c >= boiling_point:
		return "vapour"
	return "liquid"

## Simple infiltration/runoff partition. Values are fractions, not litres.
func runoff_fraction(rainfall_mm_h: float, soil_infiltration_mm_h: float, slope_degrees: float, soil_saturation: float) -> float:
	var rain := maxf(0.0, rainfall_mm_h)
	var capacity := maxf(0.0, soil_infiltration_mm_h) * (1.0 - clampf(soil_saturation, 0.0, 1.0))
	var excess := 1.0 - minf(1.0, capacity / maxf(0.001, rain))
	var slope_factor := clampf(sin(deg_to_rad(clampf(slope_degrees, 0.0, 60.0))) * 1.8, 0.0, 0.85)
	return clampf(excess + (1.0 - excess) * slope_factor, 0.0, 1.0)

## Deterministic regional wind sample; same world-time input gives same result.
func wind_at(position: Vector3, world_day: float = 0.0) -> Vector3:
	var regional_angle := float(hash(Vector2i(roundi(position.x / 256.0), roundi(position.z / 256.0)) + Vector2i(_world_seed, 0)) % 6283) / 1000.0
	var time_angle := world_day * TAU / 3.0 + regional_angle
	var speed := base_wind_speed_m_s * (1.0 + wind_gustiness * sin(time_angle * 2.17))
	return Vector3(cos(time_angle), 0.0, sin(time_angle)) * speed

func _sample_environment() -> void:
	var player_node = GameManager.player
	var sample_position := player_node.global_position if player_node != null else Vector3.ZERO
	var climate_node := get_node_or_null("/root/ClimateSystem")
	if climate_node != null and climate_node.has_method("sample_at"):
		var climate: Dictionary = climate_node.sample_at(sample_position)
		air_temperature_c = float(climate.get("temperature_c", air_temperature_c))
		humidity = float(climate.get("humidity", humidity))
		wind_velocity = climate.get("wind", wind_at(sample_position))
	else:
		var day_node := get_tree().get_first_node_in_group("day_night")
		if day_node != null and day_node.get("time_of_day") != null:
			var day_phase := float(day_node.get("time_of_day"))
			air_temperature_c = 16.0 + 7.0 * sin((day_phase - 0.25) * TAU)
		var world_day := float(LivingWorldSystem.get_world_day()) if is_instance_valid(LivingWorldSystem) else 0.0
		wind_velocity = wind_at(sample_position, world_day)
	pressure_kpa = pressure_at_altitude(sample_position.y, air_temperature_c)
	air_density = air_density_at(sample_position.y, air_temperature_c)
	environment_sampled.emit(air_temperature_c, pressure_kpa, wind_velocity)
