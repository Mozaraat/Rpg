# Rain, fog, storms — visual + light gameplay modifiers
extends Node
class_name WeatherSystem

signal weather_changed(kind: String)

var kind: String = "clear"  # clear, rain, fog, storm
var _timer: float = 40.0
var _particles: CPUParticles3D
var _fog_strength: float = 0.0

func _ready() -> void:
	add_to_group("weather")
	await get_tree().process_frame
	_build_particles()

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_timer -= delta
	if _timer <= 0.0:
		_timer = randf_range(50.0, 120.0)
		_roll()
	_follow_player()
	_apply_env(delta)

func _roll() -> void:
	var r := randf()
	var next := "clear"
	if r < 0.45:
		next = "clear"
	elif r < 0.7:
		next = "rain"
	elif r < 0.88:
		next = "fog"
	else:
		next = "storm"
	if next == kind:
		return
	kind = next
	weather_changed.emit(kind)
	EventBus.toast.emit("Weather: %s" % kind.capitalize(), "info")
	_update_particles()

func _build_particles() -> void:
	_particles = CPUParticles3D.new()
	_particles.emitting = false
	_particles.amount = 400
	_particles.lifetime = 1.2
	_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_particles.emission_box_extents = Vector3(28, 1, 28)
	_particles.direction = Vector3(0.15, -1, 0.05)
	_particles.spread = 8.0
	_particles.initial_velocity_min = 4.0
	_particles.initial_velocity_max = 9.0
	_particles.gravity = Vector3(0, -9.80665, 0)
	var mesh := SphereMesh.new()
	mesh.radius = 0.03
	mesh.height = 0.06
	_particles.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.7, 0.8, 1.0, 0.6)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_particles.material_override = mat
	add_child(_particles)

func _update_particles() -> void:
	if _particles == null:
		return
	match kind:
		"rain", "storm":
			_particles.emitting = true
			_particles.amount = 700 if kind == "storm" else 350
			_particles.initial_velocity_min = 6.0 if kind == "storm" else 4.0
			_particles.initial_velocity_max = 11.0 if kind == "storm" else 9.0
		_:
			_particles.emitting = false

func _follow_player() -> void:
	var p = GameManager.player
	if p and _particles:
		_particles.global_position = p.global_position + Vector3(0, 12, 0)
		var wind: Vector3 = PhysicalWorldSystem.wind_velocity
		_particles.direction = Vector3(wind.x, -1.0, wind.z).normalized()

func _apply_env(_delta: float) -> void:
	var target: float = 0.0
	if kind == "fog":
		target = 0.55
	elif kind == "storm":
		target = 0.35
	elif kind == "rain":
		target = 0.15
	_fog_strength = lerpf(_fog_strength, target, 0.02)
	var env_node = get_tree().get_first_node_in_group("day_night")
	if env_node and env_node.get("environment"):
		var e: Environment = env_node.environment
		if e:
			# Do not stomp the base atmosphere owned by DayNightCycle. Weather only
			# thickens the existing fog and pulls the far plane in; clear weather
			# leaves the daylight haze exactly as authored.
			if kind == "clear" and _fog_strength < 0.02:
				e.fog_depth_end = 360.0
			else:
				e.fog_depth_end = lerpf(360.0, 165.0, _fog_strength)
				e.fog_density = lerpf(0.82, 1.65, _fog_strength)

## Couples visible weather to the hydrology water budget.
func precipitation_multiplier() -> float:
	match kind:
		"rain": return 5.0
		"storm": return 18.0
		"fog": return 0.03
		_: return 0.01

func combat_mult() -> float:
	match kind:
		"storm": return 0.95  # slightly harder to fight
		"fog": return 0.9
		_: return 1.0

func gather_mult() -> float:
	match kind:
		"rain": return 1.05
		"storm": return 0.85
		_: return 1.0
