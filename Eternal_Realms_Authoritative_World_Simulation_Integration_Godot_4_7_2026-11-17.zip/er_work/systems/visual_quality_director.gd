## Bridges the main-world graphics preset to the active day/night environment.
## DayNightCycle owns the live sky and weather atmosphere; this node must not replace it.
extends Node

@export_enum("Cinematic", "High", "Balanced", "Performance") var quality_preset: String = "High"

func _ready() -> void:
	call_deferred("_apply_environment")

func apply_quality_preset(preset: String) -> void:
	if not ["Cinematic", "High", "Balanced", "Performance"].has(preset):
		return
	quality_preset = preset
	_apply_environment()

func _apply_environment() -> void:
	var cycle := get_parent().get_node_or_null("DayNightCycle")
	if cycle == null or not cycle.has_method("apply_quality"):
		return
	var quality_map := {"Performance": 0, "Balanced": 1, "High": 2, "Cinematic": 3}
	cycle.apply_quality(int(quality_map[quality_preset]))
