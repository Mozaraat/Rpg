# Points of interest: shrines, ruins, rare nodes
extends Node3D
class_name POISystem

var noise: TerrainNoise

func _ready() -> void:
	add_to_group("poi")
	noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	_place_all()

func _place_all() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = GameManager.world_seed + 777
	_place_shrine(Vector2(-40, -50), "Forest Shrine")
	_place_shrine(Vector2(25, -85), "Lakeside Shrine")
	_place_ruin(Vector2(-70, -70), "Old Watch Ruin")
	_place_ruin(Vector2(55, -30), "Broken Arch")
	_place_rare_node(Vector2(-10, -95), "Crystal Vein")
	_place_rare_node(Vector2(35, 10), "Moonpetal Grove")
	_place_spiritual_landmarks()
	print("[POI] Shrines, ruins, rare nodes and spiritual landmarks placed")

func _place_spiritual_landmarks() -> void:
	var landmarks: Array[Dictionary] = [
		{"id":"ember_vein","name":"Ember Vein Crucible","element":"fire","pos":Vector2(-118, 48),"color":Color(1.0, 0.34, 0.12),"lore":"A warm pulse travels through the stone. The fire here is disciplined, not wild.","technique":"starfall_burst"},
		{"id":"tideglass_well","name":"Tideglass Heartwell","element":"water","pos":Vector2(83, -6),"color":Color(0.16, 0.68, 1.0),"lore":"Water remembers every shape it has held. Your breath begins to follow its rhythm.","technique":""},
		{"id":"gale_sky_seal","name":"Gale Sky-Seal","element":"wind","pos":Vector2(-32, -122),"color":Color(0.48, 0.95, 0.77),"lore":"A current circles the stones without disturbing the grass. Your movements feel lighter.","technique":"void_step"},
		{"id":"mountain_root","name":"Mountain Root Pillar","element":"earth","pos":Vector2(108, 66),"color":Color(0.74, 0.54, 0.31),"lore":"Deep roots bind the rock below. Stand quietly and feel the weight settle through your feet.","technique":"dragon_piercer"},
		{"id":"stormscar_obelisk","name":"Stormscar Obelisk","element":"lightning","pos":Vector2(-116, -94),"color":Color(1.0, 0.88, 0.28),"lore":"The stone hums with a distant storm. A single clear intention can carry force like lightning.","technique":"eclipse_counter"},
		{"id":"frost_lotus_pool","name":"Frost Lotus Pool","element":"ice","pos":Vector2(82, -112),"color":Color(0.62, 0.88, 1.0),"lore":"The still water does not freeze. It holds the silence between one thought and the next.","technique":""}
	]
	for spec in landmarks:
		var landmark := SpiritualLandmark.new()
		landmark.name = str(spec.id).capitalize()
		landmark.landmark_id = str(spec.id)
		landmark.landmark_name = str(spec.name)
		landmark.element = str(spec.element)
		landmark.glow_color = spec.color
		landmark.lore = str(spec.lore)
		landmark.rare_technique = str(spec.technique)
		landmark.position = Vector3(spec.pos.x, _ground(spec.pos.x, spec.pos.y), spec.pos.y)
		add_child(landmark)

func _ground(x: float, z: float) -> float:
	return noise.get_height(x, z)

func _place_shrine(xz: Vector2, label: String) -> void:
	var n := Area3D.new()
	n.name = label
	n.position = Vector3(xz.x, _ground(xz.x, xz.y), xz.y)
	n.add_to_group("poi_shrine")
	n.add_to_group("interactable")
	n.set_meta("poi_type", "shrine")
	n.set_meta("poi_name", label)
	n.set_meta("interact_range", 3.5)
	var mesh := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.35
	cyl.bottom_radius = 0.5
	cyl.height = 1.6
	mesh.mesh = cyl
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.7, 0.75, 0.85)
	mat.emission_enabled = true
	mat.emission = Color(0.4, 0.6, 1.0)
	mat.emission_energy_multiplier = 0.8
	mesh.material_override = mat
	mesh.position.y = 0.8
	n.add_child(mesh)
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.2
	cs.shape = sh
	n.add_child(cs)
	# duck-typed interact
	n.set_script(load("res://entities/poi_interact.gd"))
	add_child(n)

func _place_ruin(xz: Vector2, label: String) -> void:
	var n := Node3D.new()
	n.name = label
	n.position = Vector3(xz.x, _ground(xz.x, xz.y), xz.y)
	n.add_to_group("poi_ruin")
	n.set_meta("poi_name", label)
	for i in range(3):
		var m := MeshInstance3D.new()
		var b := BoxMesh.new()
		b.size = Vector3(1.2 + randf(), 1.0 + randf() * 1.5, 0.5)
		m.mesh = b
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.45, 0.42, 0.38)
		m.material_override = mat
		m.position = Vector3(randf_range(-2, 2), b.size.y * 0.5, randf_range(-2, 2))
		m.rotation.y = randf() * TAU
		n.add_child(m)
	add_child(n)

func _place_rare_node(xz: Vector2, label: String) -> void:
	var node := ResourceNode.new()
	node.kind = "herb" if "Moon" in label else "ore"
	node.position = Vector3(xz.x, _ground(xz.x, xz.y), xz.y)
	node.name = label
	node.set_meta("rare_poi", true)
	add_child(node)

func get_map_markers() -> Array:
	var out: Array = []
	for n in get_tree().get_nodes_in_group("poi_shrine"):
		if n is Node3D:
			out.append({"name": str(n.get_meta("poi_name", n.name)), "pos": Vector2(n.global_position.x, n.global_position.z), "kind": "poi", "title": "Shrine", "color": Color(0.5, 0.7, 1.0)})
	for n in get_tree().get_nodes_in_group("poi_ruin"):
		if n is Node3D:
			out.append({"name": str(n.get_meta("poi_name", n.name)), "pos": Vector2(n.global_position.x, n.global_position.z), "kind": "poi", "title": "Ruin", "color": Color(0.7, 0.55, 0.4)})
	for n in get_tree().get_nodes_in_group("spirit_landmark"):
		if n is Node3D:
			out.append({"name": str(n.get("landmark_name")), "pos": Vector2(n.global_position.x, n.global_position.z), "kind": "spirit", "title": str(n.get("element")).capitalize() + " Resonance", "color": n.get("glow_color")})
	return out
