# Persistent single-player guild foundation. Network identity/transport can be attached later.
extends Node

signal guild_changed(guild: Dictionary)
signal membership_changed(guild_id: String, role: String)
signal guild_notice(message: String)

const SAVE_PATH: String = "user://guild_profile.json"
const LEAVE_COOLDOWN_SECONDS: int = 7 * 24 * 60 * 60
var guilds: Dictionary = {}
var my_guild_id: String = ""
var join_blocked_until: int = 0
var player_name: String = "You"

func _ready() -> void:
	_load()

func create_guild(guild_name: String, description: String = "", emblem: String = "⚔") -> bool:
	var clean_name := guild_name.strip_edges()
	if clean_name.length() < 3 or clean_name.length() > 24 or not my_guild_id.is_empty() or is_join_locked():
		return false
	var id := "G-%d-%04d" % [int(Time.get_unix_time_from_system()), randi_range(1000, 9999)]
	guilds[id] = {"id": id, "name": clean_name, "description": description.substr(0, 160), "emblem": emblem, "leader": player_name, "members": {player_name: {"role": "leader", "joined": int(Time.get_unix_time_from_system())}}, "requests": [], "created": int(Time.get_unix_time_from_system()), "level": 1, "renown": 0, "dungeon_records": []}
	my_guild_id = id
	_save()
	_emit()
	return true

func request_to_join(guild_id: String, applicant: String = "You") -> bool:
	if not guilds.has(guild_id) or not my_guild_id.is_empty() or is_join_locked():
		return false
	var g: Dictionary = guilds[guild_id]
	if not g.requests.has(applicant) and not g.members.has(applicant):
		g.requests.append(applicant)
		_save()
		guild_notice.emit("Guild application submitted")
		guild_changed.emit(g.duplicate(true))
	return true

func accept_member(guild_id: String, applicant: String) -> bool:
	if not guilds.has(guild_id) or my_guild_id != guild_id or not _has_permission("invite"):
		return false
	var g: Dictionary = guilds[guild_id]
	if not g.requests.has(applicant):
		return false
	g.requests.erase(applicant)
	g.members[applicant] = {"role": "member", "joined": int(Time.get_unix_time_from_system())}
	_save()
	guild_changed.emit(g.duplicate(true))
	return true

func invite_member(guild_id: String, member_name: String) -> bool:
	if not guilds.has(guild_id) or my_guild_id != guild_id or not _has_permission("invite"):
		return false
	var g: Dictionary = guilds[guild_id]
	if g.members.size() >= 50 or g.members.has(member_name):
		return false
	g.members[member_name] = {"role": "member", "joined": int(Time.get_unix_time_from_system())}
	_save()
	guild_changed.emit(g.duplicate(true))
	return true

func set_member_role(member_name: String, new_role: String) -> bool:
	if my_guild_id.is_empty() or not guilds.has(my_guild_id) or not _has_permission("manage"):
		return false
	if new_role not in ["officer", "member"] or not guilds[my_guild_id].members.has(member_name) or member_name == player_name:
		return false
	guilds[my_guild_id].members[member_name].role = new_role
	_save()
	_emit()
	return true

func remove_member(member_name: String) -> bool:
	if my_guild_id.is_empty() or not guilds.has(my_guild_id) or not _has_permission("manage") or member_name == player_name:
		return false
	var members: Dictionary = guilds[my_guild_id].members
	if not members.has(member_name):
		return false
	members.erase(member_name)
	_save()
	_emit()
	return true

func leave_guild() -> bool:
	if my_guild_id.is_empty() or not guilds.has(my_guild_id):
		return false
	var old_id := my_guild_id
	var g: Dictionary = guilds[old_id]
	g.members.erase(player_name)
	if g.members.is_empty():
		guilds.erase(old_id)
	else:
		if str(g.leader) == player_name:
			var next_leader: String = str(g.members.keys()[0])
			g.leader = next_leader
			var promoted: Dictionary = g.members[next_leader].duplicate(true)
			promoted["role"] = "leader"
			g.members[next_leader] = promoted
	my_guild_id = ""
	join_blocked_until = int(Time.get_unix_time_from_system()) + LEAVE_COOLDOWN_SECONDS
	_save()
	membership_changed.emit("", "")
	guild_notice.emit("You left your guild. You may join another in 7 days.")
	return true

func is_join_locked() -> bool:
	return int(Time.get_unix_time_from_system()) < join_blocked_until

func cooldown_remaining_seconds() -> int:
	return maxi(join_blocked_until - int(Time.get_unix_time_from_system()), 0)

func current_guild() -> Dictionary:
	return guilds.get(my_guild_id, {}).duplicate(true)

func add_renown(amount: int, reason: String = "") -> void:
	if my_guild_id.is_empty() or not guilds.has(my_guild_id) or amount <= 0:
		return
	var g: Dictionary = guilds[my_guild_id]
	g.renown = int(g.get("renown", 0)) + amount
	g.level = 1 + int(int(g.renown) / 1000)
	if reason != "":
		g.dungeon_records.append({"reason": reason, "renown": amount, "time": int(Time.get_unix_time_from_system())})
	_save()
	_emit()

func _has_permission(action: String) -> bool:
	var g: Dictionary = guilds.get(my_guild_id, {})
	var role: String = str(g.get("members", {}).get(player_name, {}).get("role", ""))
	return role == "leader" or (role == "officer" and action == "invite")

func _emit() -> void:
	var g := current_guild()
	guild_changed.emit(g)
	membership_changed.emit(my_guild_id, str(g.get("members", {}).get(player_name, {}).get("role", "")))

func _save() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({"guilds": guilds, "my_guild_id": my_guild_id, "join_blocked_until": join_blocked_until, "player_name": player_name}, "\t"))
		f.close()

func _load() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not f:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		guilds = parsed.get("guilds", {})
		my_guild_id = str(parsed.get("my_guild_id", ""))
		join_blocked_until = int(parsed.get("join_blocked_until", 0))
		player_name = str(parsed.get("player_name", "You"))
