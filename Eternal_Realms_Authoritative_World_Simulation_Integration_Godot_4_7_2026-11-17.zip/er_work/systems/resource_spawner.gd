# Scatters gatherable resources around the starting region (deterministic per world seed).
extends Node3D
class_name ResourceSpawner

var noise: TerrainNoise

func _ready() -> void:
	noise = TerrainNoise.new(GameManager.world_seed)
	var rng := RandomNumberGenerator.new()
	rng.seed = GameManager.world_seed * 7 + 13
	var vc: Vector2 = TerrainNoise.VILLAGE_CENTER
	var sc: Vector2 = TerrainNoise.SPIRE_CENTER
	# Iron ore: rocky hills near the Spire and up in the mountains
	_scatter(rng, "ore", 6, sc, 24.0, 55.0, 5.0, 14.0, 0.0, 1.0)
	_scatter(rng, "ore", 6, Vector2(-55, -98), 0.0, 32.0, 4.0, 16.0, 0.0, 1.0)
	_scatter(rng, "ore", 2, vc, 40.0, 70.0, 3.5, 10.0, 0.0, 1.0)
	# Copper ore: lower hills and river banks
	_scatter(rng, "copper", 5, vc, 25.0, 65.0, 2.0, 9.0, 0.0, 1.0)
	_scatter(rng, "copper", 4, Vector2(-40, -60), 10.0, 40.0, 2.5, 11.0, 0.0, 1.0)
	# Trees: forest around the village
	_scatter(rng, "tree", 14, vc, 30.0, 75.0, 2.0, 8.0, 0.55, 1.0)
	# Moonpetal, berries and mushrooms: distinct forage niches.
	_scatter(rng, "herb", 10, Vector2(12, -25), 0.0, 24.0, 1.8, 6.0, 0.0, 0.5)
	_scatter(rng, "herb", 8, vc, 30.0, 75.0, 1.8, 6.0, 0.0, 0.6)
	_scatter(rng, "mushroom", 12, Vector2(-72, -58), 8.0, 35.0, 1.5, 8.0, 0.35, 1.0)
	_scatter(rng, "berry", 10, Vector2(-62, -24), 8.0, 34.0, 1.5, 7.0, 0.15, 0.75)
	# Precious and volatile deposits in the higher, rougher country.
	_scatter(rng, "silver", 4, Vector2(-55, -98), 8.0, 34.0, 7.0, 18.0, 0.0, 1.0)
	_scatter(rng, "gold", 3, Vector2(-68, -92), 8.0, 32.0, 10.0, 22.0, 0.0, 1.0)
	_scatter(rng, "sulfur", 4, sc, 18.0, 48.0, 5.0, 16.0, 0.0, 1.0)
	_scatter(rng, "crystal", 4, Vector2(4, -92), 10.0, 35.0, 5.0, 18.0, 0.0, 1.0)
	_scatter(rng, "salt", 5, Vector2(42, -12), 8.0, 34.0, 0.5, 4.0, 0.0, 0.6)
	# Harvestable landmark trees with distinct silhouettes and valuable timber.
	_scatter(rng, "tree_redwood", 3, Vector2(-75, -58), 6.0, 25.0, 2.0, 9.0, 0.25, 1.0)
	_scatter(rng, "tree_willow", 3, Vector2(-8, -75), 5.0, 24.0, 1.5, 6.0, 0.2, 1.0)
	_scatter(rng, "tree_baobab", 2, Vector2(15, 5), 4.0, 22.0, 1.5, 7.0, 0.0, 0.35)
	_scatter(rng, "tree_cherry", 3, Vector2(-60, -12), 5.0, 24.0, 1.5, 7.0, 0.0, 0.7)
	_scatter(rng, "tree_jungle", 3, Vector2(-82, -35), 6.0, 24.0, 2.0, 8.0, 0.35, 1.0)
	print("[ResourceSpawner] Gather nodes placed: %d" % get_child_count())

func _scatter(rng: RandomNumberGenerator, kind: String, count: int, center: Vector2, r_min: float, r_max: float,
		h_min: float, h_max: float, f_min: float, f_max: float) -> void:
	var placed: int = 0
	var tries: int = 0
	while placed < count and tries < 400:
		tries += 1
		var a: float = rng.randf() * TAU
		var r: float = rng.randf_range(r_min, r_max)
		var p: Vector2 = center + Vector2(cos(a), sin(a)) * r
		# stay inside the area that has collision at start-up
		if p.x < -520.0 or p.x > 520.0 or p.y < -520.0 or p.y > 520.0:
			continue
		var h: float = noise.get_height(p.x, p.y)
		if h < h_min or h > h_max or noise.settlement_mask(p.x, p.y) > 0.02 or noise.get_path_amount(p.x, p.y) > 0.05:
			continue
		var f: float = noise.get_forest_density(p.x, p.y, h)
		if f < f_min or f > f_max:
			continue
		var dx: float = (noise.get_height(p.x + 1.5, p.y) - noise.get_height(p.x - 1.5, p.y)) / 3.0
		var dz: float = (noise.get_height(p.x, p.y + 1.5) - noise.get_height(p.x, p.y - 1.5)) / 3.0
		if sqrt(dx * dx + dz * dz) > 0.6:
			continue
		var node := ResourceNode.new()
		node.kind = kind
		node.position = Vector3(p.x, h, p.y)
		add_child(node)
		placed += 1
