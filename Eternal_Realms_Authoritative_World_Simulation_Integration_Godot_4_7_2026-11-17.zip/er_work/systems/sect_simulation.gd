# Living cultivation sects, masters, inheritances and regional rivalries.
# Persistent state is stored in PlayerData.stats so it follows the existing save pipeline.
extends Node

signal sect_event(message: String)
signal inheritance_discovered(inheritance_id: String)
signal sect_rank_changed(rank: String)

const DISCIPLE_RANKS: Array[String] = ["Outer Disciple", "Inner Disciple", "Core Disciple", "True Disciple", "Elder", "Sect Master"]
const EXAM_TRIALS: Array[String] = ["insight", "endurance", "combat", "formation"]

const SECTS: Array[Dictionary] = [
	{"id":"azure_sword_hall", "name":"Azure Sword Hall", "region":"Elyndor Heartlands", "path":"sword_intent", "master":"Master Shen Rui", "realm":3, "technique":"blade_intent", "rival":"crimson_pavilion", "teaching":"Sword Intent"},
	{"id":"crimson_pavilion", "name":"Crimson Phoenix Pavilion", "region":"Emberfall Reach", "path":"flame_path", "master":"Elder Yan Huo", "realm":4, "technique":"phoenix_reversal", "rival":"azure_sword_hall", "teaching":"Crimson Flame"},
	{"id":"stillwater_monastery", "name":"Stillwater Monastery", "region":"Mirrorwater Basin", "path":"tide_path", "master":"Abbess Lian", "realm":3, "technique":"deepcurrent_guard", "rival":"stormspire_order", "teaching":"Azure Tide"},
	{"id":"stormspire_order", "name":"Stormspire Order", "region":"Ironback Range", "path":"storm_path", "master":"Lord Qiao Lei", "realm":4, "technique":"thunderheart_pulse", "rival":"stillwater_monastery", "teaching":"Storm Vein"},
	{"id":"veiled_moon_covenant", "name":"Veiled Moon Covenant", "region":"Whispering Woods", "path":"shadow_step", "master":"Warden Yue", "realm":3, "technique":"silent_river_step", "rival":"rootbound_circle", "teaching":"Shadow Step"},
	{"id":"rootbound_circle", "name":"Rootbound Circle", "region":"Amberleaf Glade", "path":"nature_harmony", "master":"Grandmother Moss", "realm":3, "technique":"root_bloom_cycle", "rival":"veiled_moon_covenant", "teaching":"Nature Harmony"}
]

const INHERITANCES: Dictionary = {
	"broken_sword_legacy":{"name":"Legacy of the Broken Sword","path":"sword_intent","technique":"eclipse_counter","region":"Elyndor Heartlands","clue":"A split monument behind the old eastern watchtower","minimum_realm":2},
	"phoenix_ash_scripture":{"name":"Scripture of Phoenix Ash","path":"flame_path","technique":"sunforge_palm","region":"Emberfall Reach","clue":"A sealed furnace chamber beneath the abandoned kiln","minimum_realm":3},
	"moonwell_scroll":{"name":"Moonwell Scroll","path":"tide_path","technique":"moonwell_step","region":"Mirrorwater Basin","clue":"A submerged shrine beneath the moonlit waterfall","minimum_realm":2},
	"silent_footprint_manual":{"name":"Manual of the Silent Footprint","path":"shadow_step","technique":"veil_of_stillness","region":"Whispering Woods","clue":"A hidden cache revealed by following old assassin marks","minimum_realm":3},
	"sky_lattice_tablet":{"name":"Sky-Lattice Tablet","path":"storm_path","technique":"sky_lattice","region":"Ironback Range","clue":"A lightning-scarred observatory at the highest ridge","minimum_realm":3},
	"root_breath_codex":{"name":"Codex of Root and Breath","path":"nature_harmony","technique":"beast_breath_link","region":"Amberleaf Glade","clue":"An overgrown sanctuary guarded by an ancient spirit beast","minimum_realm":2}
}

var _tick: float = 0.0

func _ready() -> void:
	add_to_group("sect_simulation")
	if not PlayerData.stats.has("sect_state"):
		PlayerData.stats["sect_state"] = {"joined":"", "standing":{}, "relations":{}, "conflict":{}, "known_inheritances":{}, "master_lessons":{}, "disciple_rank":"", "exam_progress":{}, "master_routes":{}, "sect_territory":{}, "war_history":[], "inheritance_progress":{}, "sect_reputation":{}, "disciples":{}, "master_expeditions":{}, "dao_comprehension":{}, "ascension_trials":{}, "player_sect":{}, "battle_reports":[], "territory_pressure":{}}

func _state() -> Dictionary:
	var value: Variant = PlayerData.stats.get("sect_state", {})
	if not value is Dictionary:
		value = {}
	PlayerData.stats["sect_state"] = value
	return value

func sects_in_region(region: String) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for sect in SECTS:
		if str(sect.get("region", "")).to_lower() == region.to_lower():
			result.append(sect.duplicate(true))
	return result

func standing(sect_id: String) -> int:
	var s := _state()
	var values: Dictionary = s.get("standing", {})
	return int(values.get(sect_id, 0))

func change_standing(sect_id: String, amount: int) -> int:
	if not _sect_exists(sect_id):
		return 0
	var s := _state()
	var values: Dictionary = s.get("standing", {}).duplicate(true)
	values[sect_id] = clampi(int(values.get(sect_id, 0)) + amount, -100, 100)
	s["standing"] = values
	PlayerData.stats["sect_state"] = s
	return int(values[sect_id])

func join_sect(sect_id: String) -> bool:
	if not _sect_exists(sect_id):
		return false
	var s := _state()
	if int(s.get("standing", {}).get(sect_id, 0)) < 10:
		EventBus.toast.emit("Earn the sect's trust before requesting entry.", "info")
		return false
	var changed_sect: bool = str(s.get("joined", "")) != sect_id
	s["joined"] = sect_id
	PlayerData.stats["sect_state"] = s
	if changed_sect:
		WorldLifeSimulation.record_player_joined_sect(sect_id)
	EventBus.activity.emit("You have entered %s as an outer disciple" % _sect_name(sect_id), "cultivation")
	return true

func request_master_lesson(sect_id: String) -> bool:
	var sect := _sect_data(sect_id)
	if sect.is_empty():
		return false
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null or not skill.has_method("cultivation_realm_index"):
		return false
	if int(skill.cultivation_realm_index()) < int(sect.get("realm", 0)) - 1 or standing(sect_id) < 25:
		EventBus.toast.emit("The master requires a higher realm and trusted standing.", "info")
		return false
	var lessons: Dictionary = _state().get("master_lessons", {}).duplicate(true)
	var technique_id := str(sect.get("technique", ""))
	if bool(lessons.get(technique_id, false)):
		EventBus.toast.emit("You have already received this master's lesson.", "info")
		return false
	var learned: Dictionary = skill.cultivation_state.get("techniques", {}).duplicate(true)
	learned[technique_id] = true
	skill.cultivation_state["techniques"] = learned
	lessons[technique_id] = true
	var s := _state()
	s["master_lessons"] = lessons
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("%s taught you %s" % [str(sect.get("master", "")), str(sect.get("teaching", ""))], "cultivation")
	return true

func discover_inheritance(inheritance_id: String) -> bool:
	if not INHERITANCES.has(inheritance_id):
		return false
	var s := _state()
	var known: Dictionary = s.get("known_inheritances", {}).duplicate(true)
	if bool(known.get(inheritance_id, false)):
		return false
	var inheritance: Dictionary = INHERITANCES[inheritance_id]
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null or int(skill.cultivation_realm_index()) < int(inheritance.minimum_realm):
		EventBus.toast.emit("The inheritance's pressure overwhelms your current cultivation realm.", "info")
		return false
	known[inheritance_id] = true
	s["known_inheritances"] = known
	PlayerData.stats["sect_state"] = s
	var learned: Dictionary = skill.cultivation_state.get("techniques", {}).duplicate(true)
	learned[str(inheritance.technique)] = true
	skill.cultivation_state["techniques"] = learned
	inheritance_discovered.emit(inheritance_id)
	EventBus.toast.emit("Secret inheritance discovered: %s" % str(inheritance.name), "levelup")
	EventBus.activity.emit("You deciphered %s: %s" % [str(inheritance.name), str(inheritance.clue)], "discovery")
	return true

func record_exploration_discovery(region: String, landmark_id: String = "") -> Array[String]:
	var found: Array[String] = []
	for inheritance_id in INHERITANCES.keys():
		var data: Dictionary = INHERITANCES[inheritance_id]
		if str(data.get("region", "")).to_lower() != region.to_lower():
			continue
		var clue_words: PackedStringArray = str(data.get("clue", "")).to_lower().split(" ")
		var match_found: bool = landmark_id == str(inheritance_id)
		for word in clue_words:
			if word.length() >= 6 and landmark_id.to_lower().contains(word):
				match_found = true
		if match_found and begin_inheritance_trial(str(inheritance_id)):
			found.append(str(inheritance_id))
	return found

func set_rival_relation(sect_a: String, sect_b: String, value: int) -> void:
	var s := _state()
	var relations: Dictionary = s.get("relations", {}).duplicate(true)
	relations[sect_a + "::" + sect_b] = clampi(value, -100, 100)
	relations[sect_b + "::" + sect_a] = clampi(value, -100, 100)
	s["relations"] = relations
	PlayerData.stats["sect_state"] = s

func relation(sect_a: String, sect_b: String) -> int:
	return int(_state().get("relations", {}).get(sect_a + "::" + sect_b, -20))

# Recruitment is a staged examination. Progress is persistent and each trial is explicit.
func begin_recruitment(sect_id: String) -> bool:
	if not _sect_exists(sect_id):
		return false
	var s := _state()
	var exams: Dictionary = s.get("exam_progress", {}).duplicate(true)
	if bool(exams.get(sect_id + "::complete", false)):
		return true
	exams[sect_id] = {"stage":0, "started":true}
	s["exam_progress"] = exams
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("You registered for the %s recruitment examination" % _sect_name(sect_id), "cultivation")
	return true

func complete_recruitment_trial(sect_id: String, trial_id: String) -> bool:
	if not _sect_exists(sect_id) or not EXAM_TRIALS.has(trial_id):
		return false
	var s := _state()
	var exams: Dictionary = s.get("exam_progress", {}).duplicate(true)
	var entry: Dictionary = exams.get(sect_id, {})
	if entry.is_empty() or bool(exams.get(sect_id + "::complete", false)):
		return false
	var stage := int(entry.get("stage", 0))
	if stage >= EXAM_TRIALS.size() or EXAM_TRIALS[stage] != trial_id:
		EventBus.toast.emit("The examination must be completed in its proper order.", "info")
		return false
	entry["stage"] = stage + 1
	exams[sect_id] = entry
	if int(entry["stage"]) >= EXAM_TRIALS.size():
		exams[sect_id + "::complete"] = true
		var standing_values: Dictionary = s.get("standing", {}).duplicate(true)
		standing_values[sect_id] = maxi(int(standing_values.get(sect_id, 0)), 15)
		s["standing"] = standing_values
		s["joined"] = sect_id
		s["disciple_rank"] = "Outer Disciple"
		EventBus.activity.emit("You passed the %s examination. The sect recognizes you as an Outer Disciple." % _sect_name(sect_id), "cultivation")
		WorldLifeSimulation.record_player_joined_sect(sect_id)
	else:
		EventBus.toast.emit("Examination trial passed: %s" % trial_id.replace("_", " ").capitalize(), "success")
	s["exam_progress"] = exams
	PlayerData.stats["sect_state"] = s
	return true

func advance_disciple_rank() -> bool:
	var s := _state()
	var sect_id := str(s.get("joined", ""))
	if sect_id == "": return false
	var rank := str(s.get("disciple_rank", "Outer Disciple"))
	var idx := DISCIPLE_RANKS.find(rank)
	if idx < 0 or idx >= DISCIPLE_RANKS.size() - 1: return false
	var required := [15, 30, 50, 70, 90]
	if standing(sect_id) < required[idx]:
		EventBus.toast.emit("Your sect standing is not yet sufficient for advancement.", "info")
		return false
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null or int(skill.cultivation_realm_index()) < mini(idx + 1, 5):
		EventBus.toast.emit("Your cultivation foundation must deepen before promotion.", "info")
		return false
	s["disciple_rank"] = DISCIPLE_RANKS[idx + 1]
	PlayerData.stats["sect_state"] = s
	sect_rank_changed.emit(str(s["disciple_rank"]))
	EventBus.activity.emit("Your sect promoted you to %s" % str(s["disciple_rank"]), "cultivation")
	return true

func record_master_encounter(sect_id: String, location: String) -> void:
	if not _sect_exists(sect_id): return
	var s := _state()
	var routes: Dictionary = s.get("master_routes", {}).duplicate(true)
	routes[sect_id] = {"last_location":location, "last_seen":Time.get_unix_time_from_system(), "journey_seed":randi()}
	s["master_routes"] = routes
	PlayerData.stats["sect_state"] = s

func master_is_away(sect_id: String) -> bool:
	var route: Dictionary = _state().get("master_routes", {}).get(sect_id, {})
	if route.is_empty(): return false
	return Time.get_unix_time_from_system() - int(route.get("last_seen", 0)) > 86400

func form_sect_alliance(sect_a: String, sect_b: String) -> bool:
	if not _sect_exists(sect_a) or not _sect_exists(sect_b) or sect_a == sect_b: return false
	var s := _state()
	var relations: Dictionary = s.get("relations", {}).duplicate(true)
	relations[sect_a + "::" + sect_b] = 75
	relations[sect_b + "::" + sect_a] = 75
	s["relations"] = relations
	var pressure: Dictionary = s.get("conflict", {}).duplicate(true)
	pressure[sect_a + "::" + sect_b] = 0
	pressure[sect_b + "::" + sect_a] = 0
	s["conflict"] = pressure
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("Alliance formed between %s and %s" % [_sect_name(sect_a), _sect_name(sect_b)], "world")
	return true

func negotiate_peace(sect_a: String, sect_b: String) -> bool:
	if not _sect_exists(sect_a) or not _sect_exists(sect_b) or sect_a == sect_b: return false
	var s := _state()
	var pressure: Dictionary = s.get("conflict", {}).duplicate(true)
	pressure[sect_a + "::" + sect_b] = 15
	pressure[sect_b + "::" + sect_a] = 15
	s["conflict"] = pressure
	var relations: Dictionary = s.get("relations", {}).duplicate(true)
	relations[sect_a + "::" + sect_b] = 10
	relations[sect_b + "::" + sect_a] = 10
	s["relations"] = relations
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("A peace accord was reached between %s and %s" % [_sect_name(sect_a), _sect_name(sect_b)], "world")
	return true

func declare_sect_war(sect_a: String, sect_b: String) -> bool:
	if not _sect_exists(sect_a) or not _sect_exists(sect_b) or sect_a == sect_b: return false
	var s := _state()
	var pressure: Dictionary = s.get("conflict", {}).duplicate(true)
	pressure[sect_a + "::" + sect_b] = 100
	pressure[sect_b + "::" + sect_a] = 100
	var relations: Dictionary = s.get("relations", {}).duplicate(true)
	relations[sect_a + "::" + sect_b] = -100
	relations[sect_b + "::" + sect_a] = -100
	s["relations"] = relations
	s["conflict"] = pressure
	var history: Array = s.get("war_history", []).duplicate(true)
	history.append({"a":sect_a, "b":sect_b, "time":Time.get_unix_time_from_system(), "status":"active"})
	s["war_history"] = history
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("War declared: %s and %s" % [_sect_name(sect_a), _sect_name(sect_b)], "world")
	return true

func claim_sect_territory(sect_id: String, territory_id: String) -> bool:
	if not _sect_exists(sect_id) or territory_id.strip_edges() == "": return false
	var s := _state()
	var territory: Dictionary = s.get("sect_territory", {}).duplicate(true)
	territory[territory_id] = sect_id
	s["sect_territory"] = territory
	PlayerData.stats["sect_state"] = s
	EventBus.activity.emit("%s secured territory: %s" % [_sect_name(sect_id), territory_id.replace("_", " ")], "world")
	return true

func begin_inheritance_trial(inheritance_id: String) -> bool:
	if not INHERITANCES.has(inheritance_id): return false
	var s := _state()
	var progress: Dictionary = s.get("inheritance_progress", {}).duplicate(true)
	if bool(s.get("known_inheritances", {}).get(inheritance_id, false)): return false
	var data: Dictionary = INHERITANCES[inheritance_id]
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null or int(skill.cultivation_realm_index()) < int(data.get("minimum_realm", 0)):
		EventBus.toast.emit("Your foundation is not strong enough to withstand this inheritance.", "info")
		return false
	var entry: Dictionary = progress.get(inheritance_id, {"stage":0, "proof":[]})
	entry["stage"] = mini(int(entry.get("stage", 0)) + 1, 3)
	progress[inheritance_id] = entry
	s["inheritance_progress"] = progress
	PlayerData.stats["sect_state"] = s
	if int(entry["stage"]) >= 3:
		return discover_inheritance(inheritance_id)
	EventBus.activity.emit("Inheritance trial %d of 3 completed: %s" % [int(entry["stage"]), str(data.get("name", "Unknown inheritance"))], "discovery")
	return true

func sect_world_report() -> Dictionary:
	var s := _state()
	return {"joined":str(s.get("joined", "")), "rank":str(s.get("disciple_rank", "Unaffiliated")), "territories":s.get("sect_territory", {}).duplicate(true), "wars":s.get("war_history", []).duplicate(true), "inheritances":s.get("inheritance_progress", {}).duplicate(true), "disciples":s.get("disciples", {}).duplicate(true), "master_expeditions":s.get("master_expeditions", {}).duplicate(true), "dao_comprehension":s.get("dao_comprehension", {}).duplicate(true), "player_sect":s.get("player_sect", {}).duplicate(true), "battles":s.get("battle_reports", []).duplicate(true)}

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_tick += delta
	if _tick < 180.0:
		return
	_tick = 0.0
	_simulate_rivalries()
	_simulate_autonomous_sects()

# Persistent world simulation: masters travel, disciples progress, and wars alter borders.
func _simulate_autonomous_sects() -> void:
	var s := _state()
	var now := Time.get_unix_time_from_system()
	var disciples: Dictionary = s.get("disciples", {}).duplicate(true)
	var expeditions: Dictionary = s.get("master_expeditions", {}).duplicate(true)
	var territories: Dictionary = s.get("sect_territory", {}).duplicate(true)
	var pressure: Dictionary = s.get("territory_pressure", {}).duplicate(true)
	var battles: Array = s.get("battle_reports", []).duplicate(true)
	var active_sects: Array = SECTS.duplicate(true)
	var own_sect: Dictionary = s.get("player_sect", {})
	if not own_sect.is_empty():
		active_sects.append({"id":str(own_sect.get("id", "")), "name":str(own_sect.get("name", "Player Sect")), "master":"You", "realm":5})
	for sect in active_sects:
		var id := str(sect.get("id", ""))
		var master: Dictionary = expeditions.get(id, {})
		if master.is_empty() or now >= int(master.get("return_at", 0)):
			var destinations: Array[String] = ["ancient ruins", "spirit-vein valley", "monster frontier", "lost library"]
			var destination := destinations[randi_range(0, destinations.size() - 1)]
			expeditions[id] = {"destination":destination, "departed_at":now, "return_at":now + randi_range(240, 720), "status":"exploring", "discoveries":randi_range(0, 2)}
			if randf() < 0.35: EventBus.activity.emit("%s departed on an expedition to the %s" % [str(sect.get("master", "")), destination], "world")
		else:
			master["status"] = "returning" if now + 90 >= int(master.get("return_at", 0)) else "exploring"
			expeditions[id] = master
		var roster: Array = disciples.get(id, []).duplicate(true)
		if roster.is_empty():
			for n in range(3): roster.append({"name":"%s Disciple %02d" % [str(sect.get("name", "Unknown sect")), n + 1], "rank":"Outer Disciple", "cultivation":1, "training":0, "rivalry":0, "loyalty":60})
		else:
			for disciple in roster:
				disciple["training"] = mini(int(disciple.get("training", 0)) + randi_range(1, 4), 100)
				if int(disciple["training"]) >= 100 and int(disciple.get("cultivation", 1)) < 5:
					disciple["cultivation"] = int(disciple.get("cultivation", 1)) + 1; disciple["training"] = 0
					disciple["rank"] = "Inner Disciple" if int(disciple["cultivation"]) >= 2 else str(disciple.get("rank", "Outer Disciple"))
					EventBus.activity.emit("%s advanced through sect training" % str(disciple.get("name", "A disciple")), "cultivation")
				if randf() < 0.08: disciple["rivalry"] = clampi(int(disciple.get("rivalry", 0)) + randi_range(2, 8), 0, 100)
				if randf() < 0.04: disciple["loyalty"] = clampi(int(disciple.get("loyalty", 60)) + randi_range(-5, 4), 0, 100)
		disciples[id] = roster
	var wars: Array = s.get("war_history", []).duplicate(true)
	for war in wars:
		if str(war.get("status", "")) != "active": continue
		var a := str(war.get("a", "")); var b := str(war.get("b", ""))
		if not _sect_exists(a) or not _sect_exists(b): continue
		var key := a + "::" + b; var battle_time := int(war.get("next_battle_at", 0))
		if battle_time == 0: war["next_battle_at"] = now + randi_range(180, 420)
		elif now >= battle_time:
			var score_a := _sect_strength(a) + randi_range(-15, 15); var score_b := _sect_strength(b) + randi_range(-15, 15)
			var winner := a if score_a >= score_b else b; var loser := b if winner == a else a
			var territory_id := str(war.get("contested_territory", "borderlands_" + a + "_" + b))
			territories[territory_id] = winner; pressure[key] = maxi(0, int(pressure.get(key, 100)) - 12)
			war["next_battle_at"] = now + randi_range(240, 600); war["last_winner"] = winner
			var front_hash: int = absi(hash(a + "::" + b))
			var front_x := float((front_hash % 280) - 140)
			var front_z := float(((front_hash / 17) % 240) - 120)
			battles.append({"time":now, "a":a, "b":b, "winner":winner, "loser":loser, "territory":territory_id, "strength_a":score_a, "strength_b":score_b, "front_xz":Vector2(front_x, front_z)})
			EventBus.activity.emit("Sect battle: %s defeated %s and seized %s" % [_sect_name(winner), _sect_name(loser), territory_id.replace("_", " ")], "world")
			if int(pressure[key]) <= 10: war["status"] = "exhausted"
	battles = battles.slice(maxi(0, battles.size() - 30))
	s["disciples"] = disciples; s["master_expeditions"] = expeditions; s["sect_territory"] = territories
	s["territory_pressure"] = pressure; s["war_history"] = wars; s["battle_reports"] = battles
	PlayerData.stats["sect_state"] = s

func _sect_strength(sect_id: String) -> int:
	var data := _sect_data(sect_id); var roster: Array = _state().get("disciples", {}).get(sect_id, [])
	var total := int(data.get("realm", 1)) * 12 + roster.size() * 3
	for member in roster: total += int(member.get("cultivation", 1)) * 2
	return total

func found_player_sect(sect_name: String, dao_path: String = "") -> bool:
	var clean := sect_name.strip_edges()
	if clean.length() < 3 or clean.length() > 32: EventBus.toast.emit("Choose a sect name between 3 and 32 characters.", "info"); return false
	var s := _state()
	if not (s.get("player_sect", {}) as Dictionary).is_empty(): EventBus.toast.emit("You have already founded a sect.", "info"); return false
	if int(PlayerData.stats.get("built_structures", 0)) < 3: EventBus.toast.emit("Build at least three structures for your headquarters first.", "info"); return false
	var id := "player_sect_" + str(abs(hash(clean.to_lower())))
	s["player_sect"] = {"id":id, "name":clean, "dao_path":dao_path, "founded_at":Time.get_unix_time_from_system(), "level":1, "reputation":0, "headquarters_built":true}
	s["joined"] = id; s["disciple_rank"] = "Sect Master"
	s["standing"] = s.get("standing", {}).duplicate(true); s["standing"][id] = 50
	s["disciples"] = s.get("disciples", {}).duplicate(true); s["disciples"][id] = []
	PlayerData.stats["sect_state"] = s
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
		MMORPGNetwork.request_register_player_sect(id, clean)
	EventBus.activity.emit("You founded %s. Your cultivation sect is now recognized." % clean, "world")
	return true

func recruit_to_player_sect(name: String, dao_affinity: String = "") -> bool:
	var s := _state(); var own: Dictionary = s.get("player_sect", {})
	if own.is_empty() or name.strip_edges().is_empty(): return false
	var id := str(own.id); var roster: Array = s.get("disciples", {}).get(id, []).duplicate(true)
	for member in roster:
		if str(member.get("name", "")).to_lower() == name.strip_edges().to_lower(): return false
	roster.append({"name":name.strip_edges(), "rank":"Outer Disciple", "cultivation":1, "training":0, "rivalry":0, "loyalty":65, "dao_affinity":dao_affinity})
	var all: Dictionary = s.get("disciples", {}).duplicate(true); all[id] = roster; s["disciples"] = all
	PlayerData.stats["sect_state"] = s; EventBus.activity.emit("%s joined %s as an outer disciple" % [name, str(own.name)], "world"); return true

func contribute_dao_comprehension(dao_path: String, insight: int = 1) -> int:
	if dao_path.strip_edges().is_empty(): return 0
	var s := _state(); var dao: Dictionary = s.get("dao_comprehension", {}).duplicate(true)
	var entry: Dictionary = dao.get(dao_path, {"insight":0, "stage":0})
	entry["insight"] = maxi(0, int(entry.get("insight", 0)) + maxi(1, insight))
	var thresholds := [10, 30, 65, 110, 180]; var stage := 0
	for threshold in thresholds:
		if int(entry["insight"]) >= threshold: stage += 1
	entry["stage"] = stage; dao[dao_path] = entry; s["dao_comprehension"] = dao; PlayerData.stats["sect_state"] = s
	if stage > int(entry.get("announced_stage", 0)):
		entry["announced_stage"] = stage; dao[dao_path] = entry; s["dao_comprehension"] = dao; PlayerData.stats["sect_state"] = s
		EventBus.activity.emit("Your comprehension of %s deepened to insight stage %d" % [dao_path.replace("_", " "), stage], "cultivation")
	return stage

func attempt_immortal_ascension() -> bool:
	var s := _state(); var dao: Dictionary = s.get("dao_comprehension", {}); var best_stage := 0
	for path in dao: best_stage = maxi(best_stage, int(dao[path].get("stage", 0)))
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null or int(skill.cultivation_realm_index()) < 5 or best_stage < 4: EventBus.toast.emit("Ascension requires a profound cultivation realm and Dao comprehension stage four.", "info"); return false
	var trials: Dictionary = s.get("ascension_trials", {}).duplicate(true); var progress := int(trials.get("progress", 0)) + 1
	trials["progress"] = progress; trials["last_attempt"] = Time.get_unix_time_from_system(); s["ascension_trials"] = trials; PlayerData.stats["sect_state"] = s
	if progress < 3: EventBus.activity.emit("Heavenly tribulation trial %d of 3 endured" % progress, "cultivation"); return false
	PlayerData.stats["immortal_ascended"] = true; EventBus.activity.emit("You have transcended mortality and ascended to immortality!", "levelup"); return true

func _simulate_rivalries() -> void:
	var s := _state()
	var pressure: Dictionary = s.get("conflict", {}).duplicate(true)
	for sect in SECTS:
		var id := str(sect.get("id", ""))
		var rival := str(sect.get("rival", ""))
		var key := id + "::" + rival
		var value := int(pressure.get(key, 20))
		value = clampi(value + (1 if randf() < 0.55 else -1), 0, 100)
		pressure[key] = value
		if value >= 70 and randf() < 0.12:
			EventBus.activity.emit("Sect conflict escalates: %s and %s contest their border" % [_sect_name(id), _sect_name(rival)], "world")
		elif value <= 8 and randf() < 0.08:
			EventBus.activity.emit("A temporary truce forms between %s and %s" % [_sect_name(id), _sect_name(rival)], "world")
	s["conflict"] = pressure
	PlayerData.stats["sect_state"] = s

func _sect_exists(sect_id: String) -> bool:
	return not _sect_data(sect_id).is_empty()

func _sect_data(sect_id: String) -> Dictionary:
	for sect in SECTS:
		if str(sect.get("id", "")) == sect_id:
			return sect
	var own: Dictionary = _state().get("player_sect", {})
	if str(own.get("id", "")) == sect_id:
		return {"id":sect_id, "name":str(own.get("name", "Player Sect")), "region":"Player Headquarters", "path":str(own.get("dao_path", "")), "master":"You", "realm":5, "technique":"", "rival":"", "teaching":""}
	return {}

func _sect_name(sect_id: String) -> String:
	return str(_sect_data(sect_id).get("name", sect_id.capitalize()))

func faction_report() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for sect in SECTS:
		var rival := str(sect.get("rival", ""))
		result.append({"id":str(sect.get("id", "")), "name":str(sect.get("name", "Unknown sect")), "master":str(sect.get("master", "")), "region":str(sect.get("region", "")), "standing":standing(str(sect.get("id", ""))), "rival":_sect_name(rival), "tension":int(_state().get("conflict", {}).get(str(sect.get("id", "")) + "::" + rival, 20))})
	var own: Dictionary = _state().get("player_sect", {})
	if not own.is_empty():
		result.append({"id":str(own.get("id", "")), "name":str(own.get("name", "Player Sect")), "master":"You", "region":"Player Headquarters", "standing":standing(str(own.get("id", ""))), "rival":"None", "tension":0})
	return result
