# NPC jobs that change the world: farm yield, shop restock, guard patrols
extends Node
class_name NPCJobs

var _timer: float = 5.0
var _hunter_evidence: Dictionary = {}
var _logistics_timer: float = 24.0

func _ready() -> void:
	add_to_group("npc_jobs")

func _process(delta: float) -> void:
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = 12.0
	_logistics_timer -= 12.0
	_run_jobs()
	if _logistics_timer <= 0.0:
		_logistics_timer = 36.0
		_dispatch_village_delivery()

func _run_jobs() -> void:
	for n in get_tree().get_nodes_in_group("npc"):
		if not is_instance_valid(n):
			continue
		var role: String = str(n.get("role"))
		var nm: String = str(n.get("npc_name"))
		if role == "child" or bool(n.get("_is_child")):
			continue
		match role:
			"farmer":
				_farmer_job(n)
			"smith", "craftsman":
				_smith_job(n)
			"merchant":
				_merchant_job(n)
			"hunter", "ranger":
				_hunter_job(n)
			"guard", "soldier", "mercenary":
				_guard_job(n)
			"adventurer":
				_adventurer_job(n)
			"herbalist", "scholar", "fisher":
				_civilian_specialist_job(n, role)
			"villager":
				if "Guard" in nm:
					_guard_job(n)

func _dispatch_village_delivery() -> void:
	var farmers: Array = []
	var merchants: Array = []
	for candidate in get_tree().get_nodes_in_group("npc"):
		if not is_instance_valid(candidate) or not candidate is NPC:
			continue
		if str(candidate.get("role")) == "farmer" and not candidate.has_active_delivery():
			farmers.append(candidate)
		elif str(candidate.get("role")) == "merchant":
			merchants.append(candidate)
	if farmers.is_empty() or merchants.is_empty():
		return
	for farmer_variant in farmers:
		var farmer := farmer_variant as NPC
		var best_merchant: NPC = null
		var best_distance: float = 90.0
		for merchant_variant in merchants:
			var merchant := merchant_variant as NPC
			var distance: float = farmer.global_position.distance_to(merchant.global_position)
			if distance < best_distance:
				best_distance = distance
				best_merchant = merchant
		if best_merchant == null:
			continue
		var business_id := LivingWorldSystem.business_id_for_owner(best_merchant.npc_name)
		if business_id.is_empty():
			continue
		var region_id := WorldLifeSimulation.region_id_at(farmer.global_position.x, farmer.global_position.z)
		if region_id.is_empty():
			region_id = "elyndor"
		# The farm creates the goods first; the merchant receives them only when
		# the physical carrier reaches the stall.
		var target: Vector3 = best_merchant.global_position + Vector3(1.8, 0.0, 1.2)
		if farmer.start_goods_delivery(target, business_id, "grain", 2, 180.0):
			WorldLifeSimulation.record_local_production(region_id, "food", 2.0)
			EventBus.activity.emit("%s sets out with farm goods for %s" % [farmer.npc_name, best_merchant.npc_name], "world")
			break

func _farmer_job(n: Node) -> void:
	# Seasonal crop bonus into world activity
	var season = get_tree().get_first_node_in_group("seasons")
	var mult: float = season.gather_mult() if season else 1.0
	if randf() < 0.35 * mult:
		if n.has_method("set_work_pose"):
			n.set_work_pose("tend")
		if randf() < 0.35 and n.has_method("set_carrying_goods"):
			n.set_carrying_goods(18.0)
		EventBus.activity.emit("%s tends the fields" % str(n.get("npc_name")), "world")
		var region_id := WorldLifeSimulation.region_id_at(float(n.global_position.x), float(n.global_position.z))
		if region_id == "": region_id = "elyndor"
		WorldLifeSimulation.record_local_production(region_id, "food", 2.0 * mult)
		var sg = get_tree().get_first_node_in_group("settlement_growth")
		if sg:
			sg.add_progress("elyndor", 0.6 * mult)

func _smith_job(n: Node) -> void:
	# Restock a few forge-related shop ideas via activity + gold sink flavor
	if randf() < 0.3:
		if n.has_method("set_work_pose"):
			n.set_work_pose("smith")
		var forge_id := LivingWorldSystem.business_id_for_owner(str(n.get("npc_name")))
		if forge_id != "":
			LivingWorldSystem.restock_business(forge_id, 1)
		EventBus.activity.emit("%s hammers a fresh piece of iron" % str(n.get("npc_name")), "world")
		# Soft restock: ensure player can always buy ore/ingot if Mira-style
		var panel = get_tree().get_first_node_in_group("station_panel")
		# no direct stock list mutation required — flag for shops
		if not PlayerData.stats.has("smith_restocks"):
			PlayerData.stats["smith_restocks"] = 0
		PlayerData.stats["smith_restocks"] = int(PlayerData.stats["smith_restocks"]) + 1

func _merchant_job(n: Node) -> void:
	if randf() < 0.25:
		if n.has_method("set_work_pose"):
			n.set_work_pose("trade")
		if n.has_method("set_carrying_goods"):
			n.set_carrying_goods(14.0)
		var business_id := LivingWorldSystem.business_id_for_owner(str(n.get("npc_name")))
		if business_id != "":
			LivingWorldSystem.restock_business(business_id, 1)
		var region_id := WorldLifeSimulation.region_id_at(float(n.global_position.x), float(n.global_position.z))
		if region_id == "": region_id = "elyndor"
		WorldLifeSimulation.record_market_sale(region_id, "food", 0.35)
		EventBus.activity.emit("%s arranges fresh goods on the stall" % str(n.get("npc_name")), "world")
		PlayerData.stats["merchant_restocks"] = int(PlayerData.stats.get("merchant_restocks", 0)) + 1

func _hunter_job(n: Node) -> void:
	# Hunters range beyond the village edge and periodically pause to read tracks.
	var hunter := n as NPC
	if hunter == null:
		return
	hunter.wander_radius = maxf(hunter.wander_radius, 34.0)
	if hunter.has_method("set_work_pose"):
		hunter.set_work_pose("track")
	var nearest: Node3D = null
	var nearest_distance := 34.0
	for animal in get_tree().get_nodes_in_group("critter"):
		if not is_instance_valid(animal) or not animal is Node3D:
			continue
		var distance := hunter.global_position.distance_to((animal as Node3D).global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest = animal as Node3D
	if nearest:
		var track_position := nearest.global_position + Vector3(2.0, 0.0, 2.0)
		hunter.set_hunt_target(track_position, 5.0)
		_spawn_hunter_evidence(hunter, track_position)
		EventBus.activity.emit("%s follows fresh tracks beyond the village" % hunter.npc_name, "world")

func _spawn_hunter_evidence(hunter: NPC, target: Vector3) -> void:
	var key := str(hunter.get_instance_id())
	var existing: Node3D = _hunter_evidence.get(key) as Node3D
	if is_instance_valid(existing):
		return
	var evidence := Node3D.new()
	evidence.name = "HunterTrailAndSnare"
	evidence.set_meta("hunter_evidence", true)
	get_tree().current_scene.add_child(evidence)
	evidence.global_position = target
	var earth := StandardMaterial3D.new()
	earth.albedo_color = Color(0.19, 0.14, 0.10)
	earth.roughness = 1.0
	var rope := StandardMaterial3D.new()
	rope.albedo_color = Color(0.48, 0.38, 0.22)
	rope.roughness = 0.95
	for i in range(4):
		var print_mesh := MeshInstance3D.new()
		var print_shape := SphereMesh.new()
		print_shape.radius = 0.12
		print_shape.height = 0.035
		print_mesh.mesh = print_shape
		print_mesh.material_override = earth
		print_mesh.position = Vector3(-0.55 + float(i) * 0.34, 0.025, 0.42 if i % 2 == 0 else -0.05)
		print_mesh.scale = Vector3(1.0, 0.22, 1.45)
		evidence.add_child(print_mesh)
	var trap_area := Area3D.new()
	trap_area.name = "WildlifeSnareTrigger"
	trap_area.collision_layer = 0
	trap_area.collision_mask = Constants.LAYER_CREATURE
	trap_area.position = Vector3(-1.25, 0.28, -1.25)
	var trap_shape := CollisionShape3D.new()
	var trap_sphere := SphereShape3D.new()
	trap_sphere.radius = 1.45
	trap_shape.shape = trap_sphere
	trap_area.add_child(trap_shape)
	trap_area.body_entered.connect(_on_hunter_trap_body_entered.bind(hunter, evidence, key))
	evidence.add_child(trap_area)
	for side in [-1.0, 1.0]:
		var stake := MeshInstance3D.new()
		var stake_mesh := CylinderMesh.new()
		stake_mesh.top_radius = 0.035
		stake_mesh.bottom_radius = 0.055
		stake_mesh.height = 0.42
		stake.mesh = stake_mesh
		stake.material_override = rope
		stake.position = Vector3(side * 0.42, 0.2, -0.8)
		stake.rotation.z = side * 0.18
		evidence.add_child(stake)
	var line := MeshInstance3D.new()
	var line_mesh := BoxMesh.new()
	line_mesh.size = Vector3(0.9, 0.035, 0.035)
	line.mesh = line_mesh
	line.material_override = rope
	line.position = Vector3(0, 0.28, -0.8)
	evidence.add_child(line)
	var marker := Label3D.new()
	marker.text = "TRACKS / SNARE"
	marker.font_size = 18
	marker.outline_size = 5
	marker.position.y = 0.72
	marker.modulate = Color(0.82, 0.74, 0.55)
	evidence.add_child(marker)
	_hunter_evidence[key] = evidence
	var evidence_id: int = evidence.get_instance_id()
	get_tree().create_timer(95.0).timeout.connect(func():
		var live: Node = instance_from_id(evidence_id) as Node
		if live: live.queue_free()
		_hunter_evidence.erase(key)
	)

func _on_hunter_trap_body_entered(body: Node3D, hunter: NPC, evidence: Node3D, key: String) -> void:
	if not body is Critter or not is_instance_valid(body):
		return
	var animal := body as Critter
	if animal.kind not in ["rabbit", "deer", "boar", "chicken"]:
		return
	if animal.has_method("become_carcass"):
		animal.become_carcass()
	WorldLifeSimulation.record_hunt_kill(animal.global_position.x, animal.global_position.z, str(animal.kind), 1)
	if is_instance_valid(evidence):
		evidence.queue_free()
	_hunter_evidence.erase(key)
	if is_instance_valid(hunter):
		hunter.set_work_pose("track")
		hunter.set_hunt_target(hunter.home_center, 22.0)
	PlayerData.stats["hunter_deliveries"] = int(PlayerData.stats.get("hunter_deliveries", 0)) + 1
	var growth := get_tree().get_first_node_in_group("settlement_growth")
	if growth and growth.has_method("add_progress"):
		growth.add_progress("elyndor", 0.35)
	EventBus.toast.emit("A hunter's snare caught a %s. The hunter is returning to the settlement." % animal.kind, "world")

func _adventurer_job(n: Node) -> void:
	if randf() < 0.16:
		if n.has_method("set_work_pose"):
			n.set_work_pose("track")
		EventBus.activity.emit("%s studies the roads and prepares for a dangerous expedition" % str(n.get("npc_name")), "world")
		var life: Dictionary = LivingWorldSystem.get_npc_life(str(n.get("npc_name")))
		life["adventurer_experience"] = float(life.get("adventurer_experience", 0.0)) + 0.1
		LivingWorldSystem.npc_lives[str(n.get("npc_name"))] = life

func _civilian_specialist_job(n: Node, profession: String) -> void:
	if randf() > 0.22: return
	var region_id := WorldLifeSimulation.region_id_at(float(n.global_position.x), float(n.global_position.z))
	if region_id.is_empty(): region_id = "elyndor"
	var pose := "gather" if profession == "herbalist" else ("read" if profession == "scholar" else "track")
	if n.has_method("set_work_pose"): n.set_work_pose(pose)
	if profession == "herbalist":
		WorldLifeSimulation.record_local_production(region_id, "herbs", 0.6)
	elif profession == "scholar":
		WorldLifeSimulation.record_local_resource_production(region_id, "spirit_motes", 0.35)
	else:
		WorldLifeSimulation.record_local_resource_production(region_id, "fish", 0.6)
	EventBus.activity.emit("%s works as a %s" % [str(n.get("npc_name")), profession], "world")

func _guard_job(n: Node) -> void:
	# Extra roam impulse
	if "will_state" in n:
		n.will_state = 1  # WANDER
	if randf() < 0.2:
		EventBus.activity.emit("%s patrols the road" % str(n.get("npc_name")), "world")
