# Physical battlefield presentation for persistent sect wars.
extends Node3D

const UNIT_COUNT := 8
const TICK_SECONDS := 8.0
var _tick := 0.0
var _active_key := ""
var _units: Array[Dictionary] = []
var _battle_root: Node3D
var _expedition_root: Node3D
var _travellers: Array[Dictionary] = []
var _rng := RandomNumberGenerator.new()
var _siege_tick := 0.0
var _siege_hits := 0
var _gate_health := 100.0
var _gate_node: Node3D
var _fortification_segments: Array[Dictionary] = []
var _siege_engine_nodes: Array[Node3D] = []
var _civilians: Array[Dictionary] = []
var _rescued_count := 0
var _commander_cooldown := 0.0
var _battle_active := false
var _command_mode := "advance"
var _command_target := Vector3.ZERO
var _commander_personalities := [
	{"name":"Shen Rui","personality":"Disciplined tactician","realm":"Core Formation","technique":"Azure Sword Array","ability":"formation"},
	{"name":"Yan Huo","personality":"Fierce and protective","realm":"Nascent Soul","technique":"Phoenix Reversal","ability":"phoenix"}
]

func _ready() -> void:
	add_to_group("sect_battlefield")
	_rng.randomize()
	_battle_root = Node3D.new()
	_battle_root.name = "ActiveSectBattle"
	add_child(_battle_root)
	_expedition_root = Node3D.new()
	_expedition_root.name = "TravellingSectMasters"
	add_child(_expedition_root)

func _unhandled_input(event: InputEvent) -> void:
	if not _battle_active or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_G:
			_command_mode = "advance"
			EventBus.toast.emit("Army order: Advance and engage", "info")
			get_viewport().set_input_as_handled()
		KEY_H:
			_command_mode = "hold"
			EventBus.toast.emit("Army order: Hold formation", "info")
			get_viewport().set_input_as_handled()
		KEY_J:
			_command_mode = "follow"
			EventBus.toast.emit("Army order: Regroup on your position", "info")
			get_viewport().set_input_as_handled()
		KEY_1, KEY_2, KEY_3, KEY_4:
			var orders := {KEY_1:"balanced", KEY_2:"archers", KEY_3:"charge", KEY_4:"defensive"}
			_command_mode = str(orders[event.keycode])
			EventBus.toast.emit("Army formation: %s" % _command_mode.capitalize(), "info")
			get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_tick += delta
	if _tick >= TICK_SECONDS:
		_tick = 0.0
		_sync_battle()
		_sync_master_expeditions()
	_step_units(delta)
	_step_travellers(delta)
	_step_siege(delta)
	_step_commanders(delta)
	_handle_rescue_interaction()

func _sync_battle() -> void:
	var state: Dictionary = PlayerData.stats.get("sect_state", {})
	var wars: Array = state.get("war_history", [])
	var active: Dictionary = {}
	for war in wars:
		if str(war.get("status", "")) == "active":
			active = war
			break
	if active.is_empty():
		_clear_battle()
		return
	var key := str(active.get("a", "")) + "::" + str(active.get("b", ""))
	if key == _active_key:
		return
	_clear_battle()
	_active_key = key
	var front: Vector2 = active.get("front_xz", Vector2.ZERO)
	if not active.has("front_xz"):
		var player: Node3D = GameManager.player as Node3D
		var origin := Vector2.ZERO if player == null else Vector2(player.global_position.x, player.global_position.z)
		front = origin + Vector2(38.0, 24.0)
		active["front_xz"] = front
		var state_copy: Dictionary = state.duplicate(true)
		var wars_copy: Array = state_copy.get("war_history", []).duplicate(true)
		for wi in range(wars_copy.size()):
			if str(wars_copy[wi].get("a", "")) + "::" + str(wars_copy[wi].get("b", "")) == key:
				wars_copy[wi]["front_xz"] = front
		state_copy["war_history"] = wars_copy
		PlayerData.stats["sect_state"] = state_copy
	var anchor := _battle_anchor(key, front)
	_battle_active = true
	_gate_health = 100.0
	_siege_tick = 0.0
	_siege_hits = 0
	_rescued_count = 0
	_civilians.clear()
	_fortification_segments.clear()
	_siege_engine_nodes.clear()
	_build_siege(anchor)
	_spawn_siege_engines(anchor)
	_spawn_civilians(anchor)
	_spawn_army(str(active.get("a", "")), anchor + Vector3(-13, 0, 0), Color(0.22, 0.48, 0.95), true)
	_spawn_army(str(active.get("b", "")), anchor + Vector3(13, 0, 0), Color(0.88, 0.24, 0.19), false)
	_spawn_commander(0, anchor + Vector3(-17, 0, -5), Color(0.55, 0.78, 1.0))
	_spawn_commander(1, anchor + Vector3(17, 0, 5), Color(1.0, 0.55, 0.42))
	EventBus.activity.emit("Scouts report a physical battlefield forming between %s and %s" % [str(active.get("a", "")).replace("_", " "), str(active.get("b", "")).replace("_", " ")], "world")
	EventBus.toast.emit("Command allied army: G advance, H hold, J regroup; 1 balanced, 2 archers, 3 charge, 4 defensive", "info")

func _battle_anchor(key: String, front: Vector2) -> Vector3:
	var x := front.x
	var z := front.y
	var noise := TerrainNoise.new(GameManager.world_seed)
	return Vector3(x, noise.get_height(x, z) + 0.15, z)

func _sync_master_expeditions() -> void:
	var state: Dictionary = PlayerData.stats.get("sect_state", {})
	var expeditions: Dictionary = state.get("master_expeditions", {})
	for sect_id in expeditions.keys():
		var journey: Dictionary = expeditions[sect_id]
		var found := false
		for traveller in _travellers:
			if str(traveller.sect) == str(sect_id):
				found = true
				traveller.destination = _expedition_target(str(sect_id), journey)
				break
		if found: continue
		var seed_value: int = absi(hash(str(sect_id)))
		var start := Vector2(float((seed_value % 220) - 110), float(((seed_value / 13) % 180) - 90))
		var destination := _expedition_target(str(sect_id), journey)
		var traveller_node := Node3D.new()
		traveller_node.name = "Master_" + str(sect_id)
		var model := CharacterModel.new()
		model.name = "CharacterModel"
		traveller_node.add_child(model)
		model.build({"asset": "wizard", "robe": true, "asset_tint": Color(1.0, 0.91, 0.72), "held": "staff"})
		model.set_motion(0.4)
		var noise := TerrainNoise.new(GameManager.world_seed)
		traveller_node.position = Vector3(start.x, noise.get_height(start.x, start.y), start.y)
		_expedition_root.add_child(traveller_node)
		_travellers.append({"sect":str(sect_id),"node":traveller_node,"destination":destination,"returning":str(journey.get("status", "")) == "returning"})

func _expedition_target(sect_id: String, journey: Dictionary) -> Vector2:
	var seed_value: int = absi(hash(sect_id + str(journey.get("destination", ""))))
	return Vector2(float((seed_value % 250) - 125), float(((seed_value / 19) % 220) - 110))

func _step_travellers(delta: float) -> void:
	var noise := TerrainNoise.new(GameManager.world_seed)
	for traveller in _travellers:
		var actor: Node3D = traveller.node
		if not is_instance_valid(actor): continue
		var dest: Vector2 = traveller.destination
		var current := Vector2(actor.position.x, actor.position.z)
		var direction := dest - current
		if direction.length() < 1.5:
			traveller.returning = not bool(traveller.returning)
			traveller.destination = Vector2(-dest.x * 0.55, -dest.y * 0.55) if traveller.returning else _expedition_target(str(traveller.sect), PlayerData.stats.get("sect_state", {}).get("master_expeditions", {}).get(str(traveller.sect), {}))
			continue
		var step := direction.normalized() * minf(delta * 1.1, direction.length())
		var next_pos := current + step
		actor.position = Vector3(next_pos.x, noise.get_height(next_pos.x, next_pos.y), next_pos.y)
		actor.look_at(Vector3(dest.x, actor.position.y, dest.y))

func _spawn_army(sect_id: String, origin: Vector3, tint: Color, left: bool) -> void:
	var name := sect_id.replace("_", " ").capitalize()
	var roles := ["infantry", "infantry", "infantry", "infantry", "archer", "archer", "spellcaster", "vanguard"]
	for i in range(roles.size()):
		var role: String = roles[i]
		var soldier := Node3D.new()
		soldier.name = "%s_%s_%02d" % [sect_id, role, i]
		var model := CharacterModel.new()
		model.name = "CharacterModel"
		soldier.add_child(model)
		var asset := "wizard" if role == "spellcaster" else ("elf" if role == "archer" else "samurai")
		var held := "staff" if role == "spellcaster" else ("bow" if role == "archer" else "sword")
		model.build({"asset": asset, "asset_tint": tint.lightened(0.65), "held": held})
		var row := i / 4; var col := i % 4
		soldier.position = origin + Vector3(float(col-2)*1.6,0,float(row)*2.0-2.0)
		_battle_root.add_child(soldier)
		var hp := 125.0 if role == "vanguard" else 85.0 if role == "archer" else 100.0
		_units.append({"node":soldier,"team":0 if left else 1,"hp":hp,"cooldown":_rng.randf_range(0.2,1.2),"phase":_rng.randf_range(0.0,TAU),"sect":name,"role":role,"attack_bonus":0.0,"home":soldier.position})

func _step_units(delta: float) -> void:
	if _units.size() < 2:
		return
	for unit in _units:
		var node: Node3D = unit.node
		if not is_instance_valid(node) or float(unit.hp) <= 0.0:
			if is_instance_valid(node): node.visible = false
			continue
		if int(unit.team) == 0 and _command_mode == "follow" and not bool(unit.get("commander", false)):
			var player_actor: Node3D = GameManager.player as Node3D
			if player_actor and node.global_position.distance_to(player_actor.global_position) > 5.0:
				var rally_dir := player_actor.global_position - node.global_position; rally_dir.y = 0.0
				node.global_position += rally_dir.normalized() * minf(delta * 2.4, rally_dir.length() - 4.0)
		var target: Dictionary = _nearest_enemy(unit)
		if target.is_empty():
			(node.get_node("CharacterModel") as CharacterModel).set_motion(0.0)
			continue
		var enemy: Node3D = target.node
		var offset := enemy.global_position - node.global_position
		offset.y = 0
		var distance := offset.length()
		unit.cooldown = maxf(0.0, float(unit.cooldown) - delta)
		var role := str(unit.get("role", "infantry"))
		var attack_range := 9.0 if role == "archer" else 11.0 if role == "spellcaster" else 1.55
		var commanded_hold := int(unit.team) == 0 and _command_mode in ["hold", "defensive", "archers"]
		if distance <= attack_range or commanded_hold:
			(node.get_node("CharacterModel") as CharacterModel).set_motion(0.0)
		if distance > attack_range:
			if commanded_hold:
				continue
			var direction := offset.normalized()
			var speed := 3.8 if role == "vanguard" else 1.8
			node.global_position += direction * minf(delta * speed, distance - attack_range * 0.82)
			node.look_at(Vector3(enemy.global_position.x, node.global_position.y, enemy.global_position.z))
			(node.get_node("CharacterModel") as CharacterModel).set_motion(0.55)
		elif float(unit.cooldown) <= 0.0:
			var strike_damage := _rng.randf_range(7.0, 15.0) + float(unit.get("attack_bonus", 0.0))
			if role == "archer": strike_damage *= 0.78
			elif role == "spellcaster": strike_damage *= 1.25
			elif role == "vanguard": strike_damage *= 1.65 if _command_mode == "charge" else 1.35
			if int(unit.team) == 0 and _command_mode == "charge": strike_damage *= 1.18
			target.hp = maxf(0.0, float(target.hp) - strike_damage)
			unit.cooldown = _rng.randf_range(0.7, 1.4)
			var model := node.get_node("CharacterModel") as CharacterModel
			model.set_motion(0.0)
			model.play_attack()
			if float(target.hp) <= 0.0 and target.node is Node3D:
				target.node.visible = false

func _nearest_enemy(unit: Dictionary) -> Dictionary:
	var best: Dictionary = {}
	var best_dist := INF
	var source: Node3D = unit.node
	for candidate in _units:
		if int(candidate.team) == int(unit.team) or float(candidate.hp) <= 0.0:
			continue
		var other: Node3D = candidate.node
		if not is_instance_valid(other): continue
		var d := source.global_position.distance_squared_to(other.global_position)
		if d < best_dist:
			best_dist = d
			best = candidate
	return best

func _build_siege(anchor: Vector3) -> void:
	# A small defensible outpost makes the encounter read as a siege, not a duel arena.
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.34, 0.32, 0.29)
	material.roughness = 0.94
	_fortification_segments.clear()
	var wall_specs: Array[Dictionary] = [
		{"offset":Vector3(-4.5, 1.2, 0.0), "size":Vector3(0.5, 2.4, 7.0)},
		{"offset":Vector3(4.5, 1.2, 0.0), "size":Vector3(0.5, 2.4, 7.0)},
		{"offset":Vector3(0.0, 1.2, -3.5), "size":Vector3(9.0, 2.4, 0.5)},
		{"offset":Vector3(-3.35, 1.2, 3.5), "size":Vector3(2.3, 2.4, 0.5)},
		{"offset":Vector3(3.35, 1.2, 3.5), "size":Vector3(2.3, 2.4, 0.5)}
	]
	for spec in wall_specs:
		var wall := MeshInstance3D.new()
		var wall_mesh := BoxMesh.new()
		wall_mesh.size = spec.size
		wall.mesh = wall_mesh
		wall.position = anchor + spec.offset
		wall.material_override = material
		var wall_body := StaticBody3D.new()
		var wall_collision := CollisionShape3D.new()
		var wall_shape := BoxShape3D.new(); wall_shape.size = spec.size
		wall_collision.shape = wall_shape; wall_body.add_child(wall_collision); wall.add_child(wall_body)
		_battle_root.add_child(wall)
		_fortification_segments.append({"node":wall,"hp":65.0})
	# Four raised corner towers and a separate destructible gate make the outpost readable.
	var gate := MeshInstance3D.new()
	var gate_mesh := BoxMesh.new()
	gate_mesh.size = Vector3(3.2, 1.8, 0.45)
	gate.mesh = gate_mesh
	gate.position = anchor + Vector3(0, 0.9, 3.55)
	var gate_mat := StandardMaterial3D.new()
	gate_mat.albedo_color = Color(0.24, 0.13, 0.07)
	gate_mat.metallic = 0.12
	gate.material_override = gate_mat
	var gate_body := StaticBody3D.new()
	var gate_collision := CollisionShape3D.new(); var gate_shape := BoxShape3D.new(); gate_shape.size = gate_mesh.size; gate_collision.shape = gate_shape; gate_body.add_child(gate_collision); gate.add_child(gate_body)
	_battle_root.add_child(gate)
	_gate_node = gate
	for x in [-4.5, 4.5]:
		for z in [-3.5, 3.5]:
			var tower := MeshInstance3D.new()
			var tower_mesh := CylinderMesh.new()
			tower_mesh.top_radius = 0.65
			tower_mesh.bottom_radius = 0.85
			tower_mesh.height = 4.5
			tower.mesh = tower_mesh
			tower.position = anchor + Vector3(x, 2.25, z)
			tower.material_override = material
			_battle_root.add_child(tower)


func _spawn_commander(team: int, position_3d: Vector3, tint: Color) -> void:
	var commander := Node3D.new()
	commander.name = "SectCommander_%d" % team
	commander.position = position_3d
	var model := CharacterModel.new()
	model.name = "CharacterModel"
	commander.add_child(model)
	model.build({"asset": "samurai", "asset_tint": tint.lightened(0.65), "held": "sword", "scale": 1.08})
	var mat := StandardMaterial3D.new()
	mat.albedo_color = tint
	mat.metallic = 0.35
	var banner := MeshInstance3D.new()
	var banner_mesh := BoxMesh.new()
	banner_mesh.size = Vector3(0.12, 2.4, 0.9)
	banner.mesh = banner_mesh
	banner.position = Vector3(0, 2.45, 0.35)
	banner.material_override = mat
	commander.add_child(banner)
	_battle_root.add_child(commander)
	var identity: Dictionary = _commander_personalities[team]
	var title := Label3D.new(); title.text = "%s | %s\n%s\n%s" % [identity.name, identity.personality, identity.realm, identity.technique]; title.font_size = 28; title.position.y = 3.8; title.billboard = BaseMaterial3D.BILLBOARD_ENABLED; commander.add_child(title)
	_units.append({"node":commander,"team":team,"hp":340.0,"cooldown":1.0,"phase":0.0,"sect":"Commander","commander":true,"weapon":banner,"attack_bonus":0.0,"personality":identity.personality,"realm":identity.realm,"signature":identity.technique,"ability":identity.ability})

func _spawn_siege_engines(anchor: Vector3) -> void:
	for side in [-1.0, 1.0]:
		var engine := Node3D.new()
		engine.name = "SiegeEngine_Ram" if side < 0 else "SiegeEngine_Catapult"
		engine.position = anchor + Vector3(side * 12.0, 0, -9.0)
		var frame := MeshInstance3D.new()
		var frame_mesh := BoxMesh.new()
		frame_mesh.size = Vector3(2.8, 1.8, 3.8)
		frame.mesh = frame_mesh
		var wood := StandardMaterial3D.new()
		wood.albedo_color = Color(0.28, 0.17, 0.09)
		frame.material_override = wood
		frame.position.y = 1.0
		engine.add_child(frame)
		if side > 0:
			var arm := MeshInstance3D.new()
			var arm_mesh := BoxMesh.new()
			arm_mesh.size = Vector3(0.18, 3.8, 0.18)
			arm.mesh = arm_mesh
			arm.position = Vector3(0, 2.3, 0)
			arm.rotation.z = -0.65
			arm.material_override = wood
			engine.add_child(arm)
		_battle_root.add_child(engine)
		_siege_engine_nodes.append(engine)
		var ladder := Node3D.new(); ladder.name = "SiegeLadder_%s" % str(side)
		ladder.position = anchor + Vector3(side * 6.0, 0.0, 2.5)
		var ladder_mat := StandardMaterial3D.new(); ladder_mat.albedo_color = Color(0.38,0.24,0.12)
		var rail_mesh := BoxMesh.new(); rail_mesh.size = Vector3(0.12,3.4,0.12)
		for rail_x in [-0.42, 0.42]:
			var rail := MeshInstance3D.new(); rail.mesh = rail_mesh; rail.position = Vector3(rail_x,1.7,-0.35); rail.rotation.x = -0.28; rail.material_override = ladder_mat; ladder.add_child(rail)
		for rung in range(7):
			var rung_node := MeshInstance3D.new(); var rung_mesh := BoxMesh.new(); rung_mesh.size = Vector3(0.9,0.09,0.12); rung_node.mesh = rung_mesh; rung_node.position = Vector3(0,float(rung)*0.48,0); rung_node.material_override = ladder_mat; ladder.add_child(rung_node)
		_battle_root.add_child(ladder)

func _spawn_civilians(anchor: Vector3) -> void:
	for i in range(4):
		var civilian := Node3D.new()
		civilian.name = "Evacuee_%02d" % i
		var model := CharacterModel.new()
		model.name = "CharacterModel"
		civilian.add_child(model)
		model.build({"asset": "farmer" if i % 2 == 0 else "woman", "held": "none"})
		civilian.position = anchor + Vector3(_rng.randf_range(-5, 5), 0, _rng.randf_range(5, 9))
		_battle_root.add_child(civilian)
		_civilians.append({"node":civilian,"rescued":false})
	EventBus.activity.emit("Battlefield rescue quest: approach trapped civilians and press E to escort them to safety", "quest")

func _step_siege(delta: float) -> void:
	if not _battle_active or not is_instance_valid(_gate_node):
		return
	# Siege pressure advances while the player is close enough to witness and influence the assault.
	var player_actor: Node3D = GameManager.player as Node3D
	if player_actor == null or player_actor.global_position.distance_to(_gate_node.global_position) > 85.0:
		return
	_siege_tick += delta
	if _siege_tick < 7.0 or _gate_health <= 0.0:
		return
	_siege_tick = 0.0
	_siege_hits += 1
	_gate_health = maxf(0.0, _gate_health - 18.0)
	for wall_record in _fortification_segments:
		if float(wall_record.get("hp", 0.0)) <= 0.0:
			continue
		wall_record["hp"] = maxf(0.0, float(wall_record.get("hp", 0.0)) - 24.0)
		if float(wall_record["hp"]) <= 0.0:
			var damaged_wall: Node3D = wall_record.node
			damaged_wall.visible = false
			for wall_body in damaged_wall.get_children():
				if wall_body is StaticBody3D: wall_body.collision_layer = 0; wall_body.collision_mask = 0
			EventBus.activity.emit("A section of the outpost wall collapsed under siege fire", "world")
	for engine in _siege_engine_nodes:
		if is_instance_valid(engine):
			var engine_tween := create_tween()
			engine_tween.tween_property(engine, "position:z", engine.position.z + 0.45, 0.12)
			engine_tween.tween_property(engine, "position:z", engine.position.z - 0.45, 0.18)
	var hit_tween := create_tween()
	hit_tween.tween_property(_gate_node, "position:y", _gate_node.position.y + 0.35, 0.08)
	hit_tween.tween_property(_gate_node, "position:y", _gate_node.position.y - 0.35, 0.12)
	if _gate_health <= 0.0:
		for gate_body in _gate_node.get_children():
			if gate_body is StaticBody3D: gate_body.collision_layer = 0; gate_body.collision_mask = 0
		_gate_node.rotation.y = PI * 0.5
		_gate_node.position.y = 0.8
		EventBus.activity.emit("The siege ram smashed through the outpost gate", "world")
		EventBus.toast.emit("Fortification gate destroyed!", "warning")
		_record_castle_capture()

func _record_castle_capture() -> void:
	var state: Dictionary = PlayerData.stats.get("sect_state", {}).duplicate(true)
	var wars: Array = state.get("war_history", []).duplicate(true)
	var ownership: Dictionary = state.get("settlement_ownership", {}).duplicate(true)
	for i in range(wars.size()):
		var war: Dictionary = wars[i]
		if str(war.get("status", "")) != "active": continue
		var winner := str(war.get("a", "")); var loser := str(war.get("b", ""))
		ownership[loser] = {"owner":winner,"captured":true,"banner":winner,"architecture_style":"conqueror"}
		war["status"] = "won"; war["winner"] = winner; war["captured_settlement"] = loser; wars[i] = war
		_apply_capture_visual(loser, winner)
		EventBus.activity.emit("%s captured %s. Its territory now flies the victor's banner." % [winner.replace("_"," ").capitalize(), loser.replace("_"," ").capitalize()], "world")
		break
	state["war_history"] = wars; state["settlement_ownership"] = ownership; PlayerData.stats["sect_state"] = state

func _apply_capture_visual(defeated_sect: String, victor_sect: String) -> void:
	var world := get_tree().current_scene
	if world == null: return
	var root := world.find_child("Sect_" + defeated_sect, true, false) as Node3D
	if root == null: return
	var palette := {"azure_sword_hall":Color(0.22,0.48,0.95),"crimson_pavilion":Color(0.88,0.24,0.19),"stillwater_monastery":Color(0.18,0.65,0.78),"stormspire_order":Color(0.62,0.45,0.92),"veiled_moon_covenant":Color(0.36,0.32,0.58),"rootbound_circle":Color(0.28,0.62,0.32)}
	var new_color: Color = palette.get(victor_sect, Color(0.78,0.68,0.32))
	for child in root.get_children():
		if child is MeshInstance3D and child.name.to_lower().contains("banner"):
			var mat := StandardMaterial3D.new(); mat.albedo_color = new_color; mat.emission_enabled = true; mat.emission = new_color * 0.2; child.material_override = mat
	var marker := MeshInstance3D.new(); var flag := BoxMesh.new(); flag.size = Vector3(0.14,4.8,2.4); marker.mesh = flag; marker.position = Vector3(0,6.0,-2.0); var flag_mat := StandardMaterial3D.new(); flag_mat.albedo_color = new_color; marker.material_override = flag_mat; root.add_child(marker)
	root.set_meta("occupied_by", victor_sect)
	for descendant in root.find_children("*", "MeshInstance3D", true, false):
		if descendant == marker: continue
		var original := descendant.material_override as StandardMaterial3D
		if original:
			var rebuilt := original.duplicate() as StandardMaterial3D
			rebuilt.albedo_color = rebuilt.albedo_color.lerp(new_color, 0.28)
			descendant.material_override = rebuilt

func _step_commanders(delta: float) -> void:
	_commander_cooldown = maxf(0.0, _commander_cooldown - delta)
	if _commander_cooldown > 0.0:
		return
	_commander_cooldown = 12.0
	for commander in _units:
		if not bool(commander.get("commander", false)) or float(commander.hp) <= 0.0:
			continue
		var commander_node: Node3D = commander.node
		for ally in _units:
			if int(ally.team) != int(commander.team) or float(ally.hp) <= 0.0 or bool(ally.get("commander", false)):
				continue
			var ally_node: Node3D = ally.node
			if commander_node.global_position.distance_to(ally_node.global_position) < 13.0:
				if int(commander.team) == 0:
					ally.attack_bonus = 5.0
					ally.cooldown = maxf(0.15, float(ally.cooldown) - 0.45)
				else:
					ally.hp = minf(100.0, float(ally.hp) + 22.0)
					ally.cooldown = maxf(0.15, float(ally.cooldown) - 0.2)
		if int(commander.team) == 0:
			EventBus.activity.emit("Shen Rui (%s) unleashed Azure Sword Array" % str(commander.realm), "world")
		else:
			EventBus.activity.emit("Yan Huo (%s) invoked Phoenix Reversal" % str(commander.realm), "world")

func _handle_rescue_interaction() -> void:
	if not _battle_active or not Input.is_action_just_pressed("interact"):
		return
	var player: Node3D = GameManager.player as Node3D
	if player == null:
		return
	if is_instance_valid(_gate_node) and player.global_position.distance_to(_gate_node.global_position) <= 4.5:
		if _command_mode in ["hold", "defensive"]:
			_gate_health = minf(100.0, _gate_health + 22.0)
			EventBus.toast.emit("You reinforce the gate! Fortification integrity: %d%%" % int(_gate_health), "success")
		else:
			_gate_health = maxf(0.0, _gate_health - 22.0)
			EventBus.toast.emit("You strike the castle gate! Integrity: %d%%" % int(_gate_health), "warning")
			if _gate_health <= 0.0:
				_gate_node.rotation.y = PI * 0.5
				for gate_body in _gate_node.get_children():
					if gate_body is StaticBody3D: gate_body.collision_layer = 0; gate_body.collision_mask = 0
				EventBus.activity.emit("The player personally breached the castle gate", "quest")
				_record_castle_capture()
		return
	for civilian in _civilians:
		if bool(civilian.rescued):
			continue
		var actor: Node3D = civilian.node
		if not is_instance_valid(actor) or player.global_position.distance_to(actor.global_position) > 4.0:
			continue
		civilian.rescued = true
		_rescued_count += 1
		actor.visible = false
		PlayerData.stats["sect_war_rescued_civilians"] = int(PlayerData.stats.get("sect_war_rescued_civilians", 0)) + 1
		EventBus.toast.emit("Civilian escorted to safety (%d/4)" % _rescued_count, "success")
		if _rescued_count >= 4:
			PlayerData.stats["sect_war_rescue_complete"] = true
			EventBus.activity.emit("Battlefield evacuation complete: all civilians reached safety", "quest")
			var growth := get_tree().get_first_node_in_group("settlement_growth")
			if growth and growth.has_method("reward_war_relief"):
				growth.reward_war_relief(25.0)
		break

func _clear_battle() -> void:
	_active_key = ""
	_battle_active = false
	_units.clear()
	_civilians.clear()
	_fortification_segments.clear()
	_siege_engine_nodes.clear()
	_gate_node = null
	if is_instance_valid(_battle_root):
		for child in _battle_root.get_children(): child.queue_free()
