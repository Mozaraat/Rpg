# Random world events that "arrive" as you play
extends Node
class_name SceneDirector

var _timer: float = 20.0
var _noise: TerrainNoise
var _last_event: String = ""

func _ready() -> void:
	add_to_group("scene_director")
	_noise = TerrainNoise.new(GameManager.world_seed)

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = randf_range(45.0, 90.0)
	_try_event()

func _try_event() -> void:
	var kills: int = int(PlayerData.stats.get("kills", 0))
	if kills < 4:
		return
	var region: String = _current_region()
	var roll: float = randf()
	var id: String = ""
	if region == "mountains" and roll < 0.42:
		id = "stonefall"
	elif region == "coast" and roll < 0.42:
		id = "high_tide"
	elif region == "woods" and roll < 0.42:
		id = "old_growth_hunt"
	elif region == "spire" and roll < 0.42:
		id = "arcane_surge"
	elif roll < 0.28:
		id = "slime_surge"
	elif roll < 0.5:
		id = "wolf_pack"
	elif roll < 0.68:
		id = "bandit_patrol"
	elif roll < 0.82:
		id = "merchant_rumor"
	else:
		id = "night_omen" if _is_night() else "clear_skies"
	if id == _last_event:
		return
	_last_event = id
	match id:
		"slime_surge":
			_announce("A slime surge boils up from the meadows!", "Slime Surge")
			_spawn_near_player("slime", 3)
		"wolf_pack":
			_announce("Howls rise — a wolf pack is on the move.", "Wolf Pack")
			_spawn_monsters_near("grey_wolf", 2)
		"bandit_patrol":
			_announce("Bandits patrol the Old Road. The trade route is threatened.", "Bandit Patrol")
			_spawn_monsters_near("bandit", 2)
			var rep = get_tree().get_first_node_in_group("reputation")
			if rep:
				rep.add_rep("bandits", -2)
		"merchant_rumor":
			EventBus.toast.emit("Word spreads of rare goods in Elyndor.", "info")
			EventBus.activity.emit("Rumor: Merchants restocked.", "world")
		"night_omen":
			_announce("The night feels watched... wisps gather nearby.", "Night Omen")
			_spawn_monsters_near("night_wisp", 2)
		"stonefall":
			_announce("The mountain shakes. Stone crawlers emerge from the scree.", "Stonefall")
			_spawn_monsters_near("stone_crawler", 2)
		"high_tide":
			_announce("The tide surges unnaturally. Something moves beneath the water.", "High Tide")
			_spawn_monsters_near("tide_serpent", 1)
		"old_growth_hunt":
			_announce("The old forest stirs. An unusually large pack is hunting.", "Old Growth Hunt")
			_spawn_monsters_near("grey_wolf", 3)
		"arcane_surge":
			_announce("The Arcane Spire flashes. Night wisps gather around the leyline.", "Arcane Surge")
			_spawn_monsters_near("night_wisp", 3)
		"clear_skies":
			EventBus.toast.emit("A fair wind passes over the land.", "info")

func _announce(message: String, event_name: String) -> void:
	EventBus.toast.emit(message, "scene")
	EventBus.activity.emit("World event: %s" % event_name, "world")

func _current_region() -> String:
	var p: Node3D = GameManager.player as Node3D
	if p == null:
		return "meadows"
	var x: float = p.global_position.x
	var z: float = p.global_position.z
	if z < -72.0 and x < -25.0:
		return "mountains"
	if x > 28.0 and z > -35.0:
		return "coast"
	if x < -42.0 and z > -65.0:
		return "woods"
	if x > 25.0 and z < -35.0:
		return "spire"
	return "meadows"

func _is_night() -> bool:
	var dn = get_tree().get_first_node_in_group("day_night")
	if dn:
		return not bool(dn.is_day)
	return false

func _spawn_near_player(_kind: String, n: int) -> void:
	# Slimes via enemy spawner if present
	var sp = get_tree().get_first_node_in_group("enemy_spawner")
	if sp and sp.has_method("_spawn"):
		for i in range(n):
			sp._spawn(true)

func _spawn_monsters_near(id: String, n: int) -> void:
	var bd = get_tree().get_first_node_in_group("boss_director")
	if bd == null or not bd.has_method("_spawn_monster"):
		return
	var props: Dictionary = {}
	match id:
		"grey_wolf":
			props = {"display_name": "Grey Wolf", "max_hp": 55.0, "damage": 11.0, "body_color": Color(0.42, 0.42, 0.48), "move_speed": 4.6, "xp_train": 0.55, "gold_min": 3, "gold_max": 12}
		"bandit":
			props = {"display_name": "Road Bandit", "max_hp": 70.0, "damage": 14.0, "body_color": Color(0.45, 0.28, 0.22), "move_speed": 3.8, "xp_train": 0.65, "gold_min": 6, "gold_max": 18}
		"night_wisp":
			props = {"display_name": "Night Wisp", "max_hp": 40.0, "damage": 13.0, "body_color": Color(0.45, 0.7, 1.0), "move_speed": 3.2, "xp_train": 0.7, "gold_min": 4, "gold_max": 14, "aggro_range": 16.0}
		"stone_crawler":
			props = {"display_name": "Stone Crawler", "max_hp": 90.0, "damage": 16.0, "body_color": Color(0.5, 0.45, 0.35), "move_speed": 2.8, "xp_train": 0.75, "gold_min": 8, "gold_max": 20}
		"tide_serpent":
			props = {"display_name": "Tide Serpent", "max_hp": 150.0, "damage": 20.0, "body_color": Color(0.15, 0.45, 0.55), "move_speed": 3.0, "xp_train": 1.0, "gold_min": 18, "gold_max": 35, "aggro_range": 22.0, "attack_range": 2.6}
		_:
			return
	for i in range(n):
		bd._spawn_monster(id, false, props)
