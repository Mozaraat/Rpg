# Field appraisal: identify creatures, resources, structures and hidden properties.
extends Node

signal appraisal_completed(title: String, details: Array[String], quality: float)

func appraise(player: CharacterBody3D) -> void:
	if player == null or not player.has_node("CameraPivot/SpringArm3D/Camera3D"):
		return
	var camera := player.get_node("CameraPivot/SpringArm3D/Camera3D") as Camera3D
	var origin := camera.global_position
	var target := origin + -camera.global_transform.basis.z * 24.0
	var query := PhysicsRayQueryParameters3D.create(origin, target)
	query.collision_mask = Constants.LAYER_WORLD | Constants.LAYER_NPC | Constants.LAYER_CREATURE
	query.exclude = [player.get_rid()]
	var hit: Dictionary = player.get_world_3d().direct_space_state.intersect_ray(query)
	var subject: Node3D = hit.get("collider") as Node3D
	# Ground and generic world collision can occlude an inspectable target; only
	# accept a ray hit when it is a known gameplay subject, then use proximity fallback.
	if subject != null and not (subject is ResourceNode or subject is Monster or subject is Slime or subject is Critter or subject.is_in_group("interactable") or subject.is_in_group("enemy")):
		subject = null
	if subject == null:
		subject = _nearest_subject(player, 7.0)
	if subject == null:
		EventBus.toast.emit("No subject in appraisal range", "info")
		return
	var skill_system := player.get_node_or_null("SkillSystem") as SkillSystem
	var value: float = skill_system.get_value("appraisal") if skill_system else 0.0
	var quality := clampf(0.25 + value / 90.0, 0.25, 1.0)
	var details: Array[String] = []
	var title := str(subject.name)
	if subject is Monster: title = (subject as Monster).display_name
	elif subject is Slime: title = "Slime"
	elif subject is Critter: title = (subject as Critter).kind.capitalize()
	if subject is ResourceNode:
		var resource := subject as ResourceNode
		var cfg: Dictionary = ResourceNode.CONFIGS.get(resource.kind, {})
		title = str(cfg.get("label", resource.kind.capitalize()))
		details.append("Category: harvestable resource")
		details.append("Material: %s" % str(cfg.get("item", "unknown")).replace("_", " "))
		details.append("Remaining yield: %d" % int(resource.charges))
		if quality >= 0.5: details.append("Regrowth: %s seconds" % int(cfg.get("respawn", 0)))
	elif subject is Critter:
		details.append("Classification: wild animal")
		details.append("Behaviour: %s" % ("predatory" if (subject as Critter).kind in ["wolf", "boar"] else "skittish / passive"))
	elif subject.is_in_group("enemy") or subject.is_in_group("colossal_beast"):
		title = str(subject.name)
		if subject is Monster: title = (subject as Monster).display_name
		elif subject is Slime: title = "Slime"
		details.append("Classification: %s" % ("colossal creature" if subject.is_in_group("colossal_beast") else "hostile creature"))
		if quality >= 0.4 and subject.has_node("HealthComponent"):
			var hp: HealthComponent = subject.get_node("HealthComponent")
			details.append("Vitality: %.0f / %.0f" % [hp.current_health, hp.max_health])
		if quality >= 0.65:
			details.append("Temperament: territorial / aggressive")
		if quality >= 0.85: details.append("Weakness study: observe its wind-up and attack recovery")
	else:
		details.append("Structure: %s" % subject.get_class())
		details.append("Distance: %.1f metres" % player.global_position.distance_to(subject.global_position))
	if quality >= 0.95: details.append("Expert insight: appraisal reveals uncommon traits and hidden affordances")
	if skill_system:
		skill_system.train("appraisal", 0.18 + (0.12 if quality > 0.7 else 0.0))
	PlayerData.stats["appraisals"] = int(PlayerData.stats.get("appraisals", 0)) + 1
	appraisal_completed.emit(title, details, quality)
	EventBus.activity.emit("Appraised: %s" % title, "discovery")
	for detail in details:
		EventBus.activity.emit("  • %s" % detail, "discovery")
	EventBus.toast.emit("Appraised %s — %s detail" % [title, "expert" if quality >= 0.85 else "useful" if quality >= 0.5 else "basic"], "info")

func _nearest_subject(player: Node3D, max_distance: float) -> Node3D:
	var best: Node3D = null
	var best_distance := max_distance
	for group_name in ["enemy", "interactable", "colossal_beast", "critter", "npc"]:
		for node in get_tree().get_nodes_in_group(group_name):
			if not node is Node3D: continue
			var distance: float = player.global_position.distance_to((node as Node3D).global_position)
			if distance < best_distance:
				best_distance = distance
				best = node as Node3D
	return best
