# VegetationKit - procedurally modelled trees, bushes, rocks, grass, flowers and
# ground cover. Meshes are built once (static cache) and instanced with MultiMesh
# by each Chunk, so visual richness costs geometry but almost no draw calls.
class_name VegetationKit
extends RefCounted

static var _meshes: Dictionary = {}
static var _mats: Dictionary = {}
static var baobab_branch_ends: Array[Vector3] = []

static func get_mesh(kind: String) -> ArrayMesh:
	if _meshes.has(kind):
		return _meshes[kind]
	var m: ArrayMesh
	match kind:
		"broadleaf": m = _build_broadleaf()
		"pine": m = _build_pine()
		"redwood": m = _build_redwood()
		"willow": m = _build_willow()
		"baobab": m = _build_baobab()
		"cherry": m = _build_cherry()
		"jungle": m = _build_jungle()
		"deadwood": m = _build_deadwood()
		"bush": m = _build_bush()
		"rock": m = _build_rock()
		"crystal": m = _build_crystal()
		"ore_vein": m = _build_ore_vein()
		"mushroom": m = _build_mushroom()
		"grass": m = _build_grass()
		"flower": m = _build_flower()
		"crop": m = _build_crop()
		"fern": m = _build_fern()
		"reed": m = _build_reed()
		"log": m = _build_log()
		"stump": m = _build_stump()
		"pebble": m = _build_pebble()
		"waystone": m = _build_waystone()
		_: m = ArrayMesh.new()
	_meshes[kind] = m
	return m

static func _foliage_material(sway: float, sway_h: float, speed: float = 1.3,
		rough: float = 0.85, translucency: float = 0.25, detail: float = 1.0,
		ao: float = 0.85, leaf_scale: float = 3.4) -> ShaderMaterial:
	var key: String = "f_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f" % [sway, sway_h, speed, rough, translucency, detail, ao, leaf_scale]
	if _mats.has(key):
		return _mats[key]
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/foliage.gdshader")
	m.set_shader_parameter("sway_amount", sway)
	m.set_shader_parameter("sway_height", sway_h)
	m.set_shader_parameter("wind_speed", speed)
	m.set_shader_parameter("roughness_value", rough)
	m.set_shader_parameter("translucency", translucency)
	m.set_shader_parameter("detail_amount", detail)
	m.set_shader_parameter("ao_strength", ao)
	m.set_shader_parameter("leaf_scale", leaf_scale)
	_mats[key] = m
	return m

static func _make_bark_grain() -> Texture2D:
	var image := Image.create(64, 64, false, Image.FORMAT_RGB8)
	for y in range(64):
		for x in range(64):
			var grain := 0.66 + 0.16 * sin(float(x) * 1.7 + sin(float(y) * 0.28) * 2.2) + 0.09 * sin(float(x) * 0.31 + float(y) * 0.13)
			var knot := 0.06 * sin(float(x) * 0.09 + float(y) * 0.4)
			var v: float = clampf(grain + knot, 0.0, 1.0)
			image.set_pixel(x, y, Color(v, v * 0.94, v * 0.82))
	return ImageTexture.create_from_image(image)

# ---------------------------------------------------------------------------
# Leaf-card support
#
# Canopies are still cheap lumpy blobs, but crossed alpha-tested cards carrying
# a procedural leaf-cluster texture give them a ragged, readable silhouette.
# The texture is generated once and shared by every tree of a species.
# ---------------------------------------------------------------------------
static func _make_leaf_texture(needle: bool) -> Texture2D:
	var key: String = "leaftex_needle" if needle else "leaftex_broad"
	if _mats.has(key):
		return _mats[key]
	var size := 128
	var img := Image.create(size, size, true, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rng := _rng(9401 if needle else 9317)
	var cx := float(size) * 0.5
	var cy := float(size) * 0.5
	var count: int = 190 if needle else 92
	for i in range(count):
		# Denser toward the middle, with a few stragglers at the rim.
		var ang := rng.randf() * TAU
		var dist := sqrt(rng.randf()) * float(size) * 0.455
		var px := cx + cos(ang) * dist
		var py := cy + sin(ang) * dist
		var length: float = rng.randf_range(8.0, 18.0) if not needle else rng.randf_range(9.0, 23.0)
		var width: float = rng.randf_range(3.0, 5.6) if not needle else rng.randf_range(0.8, 1.7)
		var rot: float = ang + rng.randf_range(-0.6, 0.6) if needle else rng.randf() * TAU
		var bright := rng.randf_range(0.78, 1.0)
		var col := Color(bright, bright * rng.randf_range(0.96, 1.03), bright * rng.randf_range(0.80, 0.94), 1.0)
		var ca := cos(rot)
		var sa := sin(rot)
		var ext: float = length + width * 2.2
		var x0: int = maxi(0, int(px - ext))
		var x1: int = mini(size - 1, int(px + ext))
		var y0: int = maxi(0, int(py - ext))
		var y1: int = mini(size - 1, int(py + ext))
		for y in range(y0, y1 + 1):
			for x in range(x0, x1 + 1):
				var dx := float(x) + 0.5 - px
				var dy := float(y) + 0.5 - py
				var u := dx * ca + dy * sa
				var v := -dx * sa + dy * ca
				var t := u / length
				if t < -1.03 or t > 1.03:
					continue
				var taper := 1.0 - t * t
				if taper <= 0.0:
					continue
				var halfw: float = width * pow(taper, 0.62)
				if halfw < 0.35:
					continue
				var a := clampf((halfw - absf(v)) / 1.35, 0.0, 1.0)
				if a <= 0.01:
					continue
				# leaf vein: subtly darker along the centre
				var shade: float = 1.0 - 0.18 * (1.0 - smoothstep(0.0, 0.9, absf(v)))
				img.set_pixel(x, y, Color(col.r * shade, col.g * shade, col.b * shade, a))
	img.generate_mipmaps()
	var tex := ImageTexture.create_from_image(img)
	_mats[key] = tex
	return tex

static func _leaf_card_material(needle: bool, tint_a: Color, tint_b: Color,
		sway: float, sway_h: float, speed: float) -> ShaderMaterial:
	var key: String = "card_%s_%s_%s_%.3f_%.3f_%.3f" % [needle, tint_a.to_html(), tint_b.to_html(), sway, sway_h, speed]
	if _mats.has(key):
		return _mats[key]
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/leaf_card.gdshader")
	m.set_shader_parameter("leaf_texture", _make_leaf_texture(needle))
	m.set_shader_parameter("tint_a", tint_a)
	m.set_shader_parameter("tint_b", tint_b)
	m.set_shader_parameter("sway_amount", sway)
	m.set_shader_parameter("sway_height", sway_h)
	m.set_shader_parameter("wind_speed", speed)
	m.set_shader_parameter("translucency", 0.68 if needle else 0.52)
	m.set_shader_parameter("roughness_value", 0.80)
	_mats[key] = m
	return m

## Builds crossed leaf cards on the outer surface of one or more ellipsoid
## clusters. `clusters` entries are [centre: Vector3, radii: Vector3].
static func _add_leaf_cards(st: SurfaceTool, clusters: Array, rng: RandomNumberGenerator,
		per_cluster: int, size_mul: float) -> void:
	for ci in range(clusters.size()):
		var c: Array = clusters[ci]
		var centre: Vector3 = c[0]
		var radii: Vector3 = c[1]
		var avg_r: float = (radii.x + radii.y + radii.z) / 3.0
		for i in range(per_cluster):
			var dir := Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-0.35, 1.0), rng.randf_range(-1.0, 1.0))
			if dir.length_squared() < 0.001:
				dir = Vector3.UP
			dir = dir.normalized()
			# Push the card slightly outside the blob so it breaks the silhouette.
			var p: Vector3 = centre + dir * radii * rng.randf_range(0.92, 1.06)
			var n: Vector3 = dir
			var t := Vector3.UP.cross(n)
			if t.length_squared() < 0.01:
				t = Vector3.RIGHT
			t = t.normalized().rotated(n, rng.randf() * TAU)
			var b: Vector3 = n.cross(t).normalized()
			var s: float = rng.randf_range(0.55, 1.0) * size_mul * maxf(avg_r, 0.35)
			var q0: Vector3 = p - t * s * 0.5 - b * s * 0.5
			var q1: Vector3 = p + t * s * 0.5 - b * s * 0.5
			var q2: Vector3 = p + t * s * 0.5 + b * s * 0.5
			var q3: Vector3 = p - t * s * 0.5 + b * s * 0.5
			MeshKit.flat_quad(st, q0, q1, q2, q3, n)
			# Second, perpendicular card gives the cluster volume from every angle.
			var t2: Vector3 = b
			var b2: Vector3 = n.cross(b).normalized()
			MeshKit.flat_quad(st, p - t2 * s * 0.5 - b2 * s * 0.5, p + t2 * s * 0.5 - b2 * s * 0.5,
				p + t2 * s * 0.5 + b2 * s * 0.5, p - t2 * s * 0.5 + b2 * s * 0.5, n)

## Pine/redwood branch sprays. Each tier gets radial needle cards that feather
## the hard cone edge without adding thousands of tiny branch meshes.
static func _add_conifer_sprays(st: SurfaceTool, tiers: Array, rng: RandomNumberGenerator,
		per_tier: int, width_mul: float) -> void:
	for ti in range(tiers.size()):
		var tier: Array = tiers[ti]
		var base_y: float = tier[0]
		var rad: float = tier[1]
		var height: float = tier[2]
		var y: float = base_y + height * 0.32
		for i in range(per_tier):
			var a: float = TAU * float(i) / float(per_tier) + rng.randf_range(-0.12, 0.12) + float(ti) * 0.41
			var radial := Vector3(cos(a), 0.0, sin(a))
			var tangent := Vector3(-sin(a), 0.0, cos(a))
			var p: Vector3 = radial * rad * rng.randf_range(0.82, 0.98) + Vector3(0, y + rng.randf_range(-0.12, 0.12), 0)
			var s: float = rad * width_mul * rng.randf_range(0.95, 1.35)
			var drop: float = height * rng.randf_range(0.28, 0.52)
			# Horizontal spray (seen from above), normal mostly up.
			MeshKit.flat_quad(st,
				p - tangent * s * 0.5 - radial * s * 0.35 + Vector3(0, -drop * 0.25, 0),
				p + tangent * s * 0.5 - radial * s * 0.35 + Vector3(0, -drop * 0.25, 0),
				p + tangent * s * 0.5 + radial * s * 0.55 + Vector3(0, -drop * 0.55, 0),
				p - tangent * s * 0.5 + radial * s * 0.55 + Vector3(0, -drop * 0.55, 0),
				Vector3(0, 0.8, 0) + radial * 0.2)
			# Vertical fan (seen from the side), normal pointing outward.
			MeshKit.flat_quad(st,
				p - tangent * s * 0.55,
				p + tangent * s * 0.55,
				p + tangent * s * 0.35 + Vector3(0, -drop, 0),
				p - tangent * s * 0.35 + Vector3(0, -drop, 0),
				radial)

static func _trunk_material() -> ShaderMaterial:
	if _mats.has("trunk"):
		return _mats["trunk"]
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/bark.gdshader")
	_mats["trunk"] = m
	return m

static func _bark_material(tint: Color) -> ShaderMaterial:
	var key := "bark_%s" % tint.to_html()
	if _mats.has(key):
		return _mats[key]
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/bark.gdshader")
	m.set_shader_parameter("moss_amount", 0.30)
	_mats[key] = m
	return m

static func _mushroom_material() -> StandardMaterial3D:
	if _mats.has("mushroom"):
		return _mats["mushroom"]
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	m.roughness = 0.72
	m.emission_enabled = true
	m.emission = Color(0.18, 0.05, 0.05)
	m.emission_energy_multiplier = 0.18
	_mats["mushroom"] = m
	return m

static func _rng(seed_value: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	return r

# ---------------------------------------------------------------------------
# Trees
# ---------------------------------------------------------------------------
static func _build_broadleaf() -> ArrayMesh:
	var rng := _rng(11)
	var mesh := ArrayMesh.new()
	var bark_dark := Color(0.17, 0.11, 0.07)
	var bark_light := Color(0.33, 0.23, 0.14)
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.25, 0), 0.36, 0.24, 1.15, 9, bark_dark, bark_light)
	MeshKit.cylinder_at(trunk, Vector3(0, 0.78, 0), 0.24, 0.13, 2.35, 8, bark_light, bark_dark.lerp(bark_light, 0.55))
	# three limbs reaching into the canopy
	MeshKit.cylinder_between(trunk, Vector3(0.05, 2.45, 0.02), Vector3(1.15, 3.35, 0.28), 0.10, 0.045, 6, bark_light, bark_light)
	MeshKit.cylinder_between(trunk, Vector3(-0.04, 2.25, 0.03), Vector3(-1.05, 3.15, -0.35), 0.095, 0.042, 6, bark_light, bark_light)
	MeshKit.cylinder_between(trunk, Vector3(0.0, 2.7, -0.03), Vector3(0.18, 3.55, -1.05), 0.08, 0.038, 6, bark_light, bark_light)
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaf := SurfaceTool.new()
	leaf.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.055, 0.18, 0.040)
	var hi := Color(0.31, 0.55, 0.14)
	var mid := lo.lerp(hi, 0.55)
	# broad crown: overlapping soft masses, denser at the top and lighter at the rim
	var clusters: Array = [
		[Vector3(0.0, 4.15, 0.0), Vector3(1.65, 1.30, 1.65)],
		[Vector3(1.25, 3.55, 0.25), Vector3(1.20, 1.00, 1.15)],
		[Vector3(-1.20, 3.65, -0.30), Vector3(1.25, 1.00, 1.15)],
		[Vector3(0.25, 3.45, -1.20), Vector3(1.10, 0.90, 1.05)],
		[Vector3(-0.20, 3.55, 1.15), Vector3(1.12, 0.92, 1.05)],
		[Vector3(0.75, 4.65, -0.55), Vector3(1.05, 0.85, 1.00)],
		[Vector3(-0.80, 4.55, 0.65), Vector3(1.08, 0.88, 1.00)],
		[Vector3(0.12, 5.05, 0.08), Vector3(0.95, 0.80, 0.95)],
		[Vector3(1.65, 4.25, -0.85), Vector3(0.80, 0.68, 0.80)],
		[Vector3(-1.55, 4.30, 0.55), Vector3(0.82, 0.70, 0.82)],
	]
	for c in clusters:
		var p: Vector3 = c[0]
		var r: Vector3 = c[1]
		# The solid core is deliberately smaller than the card shell: it supplies
		# occlusion/shadow mass, while the cards create the actual silhouette.
		MeshKit.blob_smooth(leaf, p, r * 0.62, rng, lo, hi, 0.18, 8, 5)
	# darker interior masses add depth without extra draw calls
	MeshKit.blob_smooth(leaf, Vector3(0.25, 3.9, 0.1), Vector3(1.05, 0.9, 1.05), rng, lo.darkened(0.25), mid, 0.16, 7, 4)
	MeshKit.blob_smooth(leaf, Vector3(-0.35, 4.2, -0.3), Vector3(0.9, 0.8, 0.9), rng, lo.darkened(0.2), mid, 0.16, 7, 4)
	leaf.set_material(_foliage_material(0.075, 5.8, 1.15, 0.86, 0.30, 1.0, 0.9, 3.1))
	leaf.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_leaf_cards(cards, clusters, rng, 14, 1.22)
	cards.set_material(_leaf_card_material(false, Color(0.16, 0.30, 0.10), Color(0.42, 0.62, 0.20), 0.075, 5.8, 1.15))
	cards.commit(mesh)
	return mesh

static func _build_pine() -> ArrayMesh:
	var rng := _rng(23)
	var mesh := ArrayMesh.new()
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.25, 0), 0.36, 0.10, 7.0, 7, Color(0.16, 0.10, 0.06), Color(0.28, 0.18, 0.10))
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaf := SurfaceTool.new()
	leaf.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.035, 0.13, 0.065)
	var hi := Color(0.14, 0.34, 0.16)
	# irregular stacked skirts; each tier is rotated and slightly off-centre
	var tiers: Array = [
		[1.15, 1.85, 2.25], [2.25, 1.55, 2.10], [3.30, 1.28, 1.95],
		[4.30, 1.00, 1.80], [5.20, 0.72, 1.65], [5.95, 0.46, 1.45],
	]
	for i in range(tiers.size()):
		var t: Array = tiers[i]
		var base_y: float = t[0]
		var r: float = t[1]
		var h: float = t[2]
		var yaw: float = rng.randf() * TAU
		var off := Vector3(cos(yaw) * 0.08, 0.0, sin(yaw) * 0.08)
		var xf := Transform3D(Basis(Vector3.UP, yaw), Vector3(off.x, base_y, off.z))
		MeshKit.cylinder(leaf, xf, r * 0.78, 0.0, h, 9, lo, hi, true, false, true)
		# a smaller inner skirt breaks up the cone silhouette
		if i < 4:
			MeshKit.cylinder(leaf, Transform3D(Basis(Vector3.UP, yaw + 0.7), Vector3(off.x, base_y + 0.25, off.z)), r * 0.42, 0.0, h * 0.9, 7, lo.darkened(0.12), lo.lerp(hi, 0.4), true, false, true)
	leaf.set_material(_foliage_material(0.055, 7.5, 1.0, 0.88, 0.24, 0.9, 0.92, 4.3))
	leaf.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_conifer_sprays(cards, tiers, rng, 14, 1.18)
	cards.set_material(_leaf_card_material(true, Color(0.055, 0.20, 0.09), Color(0.20, 0.44, 0.18), 0.055, 7.5, 1.0))
	cards.commit(mesh)
	return mesh

static func _build_redwood() -> ArrayMesh:
	var rng := _rng(101)
	var mesh := ArrayMesh.new()
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, 2.8, 0), 0.92, 0.46, 12.5, 11, Color(0.18, 0.11, 0.075), Color(0.37, 0.24, 0.15))
	MeshKit.cylinder_at(trunk, Vector3(0, 9.2, 0), 0.46, 0.12, 6.6, 9, Color(0.28, 0.18, 0.10), Color(0.42, 0.27, 0.16))
	# buttress roots flare out into the soil
	for i in range(8):
		var a := TAU * float(i) / 8.0
		var outer := Vector3(cos(a) * 1.55, -0.05, sin(a) * 1.55)
		MeshKit.cylinder_between(trunk, Vector3(cos(a) * 0.42, 0.55, sin(a) * 0.42), outer, 0.40, 0.05, 7, Color(0.20, 0.13, 0.085), Color(0.32, 0.21, 0.13))
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaves := SurfaceTool.new()
	leaves.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.028, 0.15, 0.070)
	var hi := Color(0.115, 0.36, 0.145)
	# layered crown from ~7 m to the spire; broad skirts lower down
	var layers: Array = [
		[7.0, 2.65, 1.65], [8.3, 2.30, 1.55], [9.5, 1.98, 1.45],
		[10.6, 1.68, 1.35], [11.6, 1.40, 1.28], [12.5, 1.14, 1.18],
		[13.3, 0.90, 1.08], [14.0, 0.68, 0.98], [14.6, 0.46, 0.88],
		[15.1, 0.34, 0.80], [15.5, 0.20, 0.72],
	]
	for i in range(layers.size()):
		var l: Array = layers[i]
		var y: float = l[0]
		var r: float = l[1]
		var h: float = l[2]
		var yaw := TAU * float(i) * 0.37
		for k in range(2):
			var a := yaw + float(k) * PI
			MeshKit.blob_smooth(leaves, Vector3(cos(a) * r * 0.35, y, sin(a) * r * 0.35), Vector3(r, h, r) * 0.68, rng, lo, hi, 0.15, 7, 4)
	leaves.set_material(_foliage_material(0.035, 16.0, 0.85, 0.88, 0.26, 0.9, 0.94, 3.8))
	leaves.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	var card_clusters: Array = []
	for i in range(layers.size()):
		var l2: Array = layers[i]
		var y2: float = l2[0]
		var r2: float = l2[1]
		var h2: float = l2[2]
		var yaw2 := TAU * float(i) * 0.37
		for k2 in range(2):
			var a2 := yaw2 + float(k2) * PI
			card_clusters.append([Vector3(cos(a2) * r2 * 0.35, y2, sin(a2) * r2 * 0.35), Vector3(r2, h2, r2)])
	_add_leaf_cards(cards, card_clusters, rng, 7, 0.95)
	cards.set_material(_leaf_card_material(true, Color(0.05, 0.22, 0.09), Color(0.16, 0.42, 0.16), 0.035, 16.0, 0.85))
	cards.commit(mesh)
	return mesh

static func _build_willow() -> ArrayMesh:
	var rng := _rng(103)
	var mesh := ArrayMesh.new()
	var bark_lo := Color(0.21, 0.14, 0.09)
	var bark_hi := Color(0.37, 0.26, 0.15)
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.1, 0), 0.44, 0.24, 1.2, 8, bark_lo, bark_hi)
	MeshKit.cylinder_at(trunk, Vector3(0, 0.95, 0), 0.24, 0.15, 2.5, 8, bark_hi, bark_lo.lerp(bark_hi, 0.5))
	for i in range(5):
		var a := TAU * float(i) / 5.0
		MeshKit.cylinder_between(trunk, Vector3(cos(a) * 0.12, 2.7, sin(a) * 0.12), Vector3(cos(a) * 1.25, 3.55, sin(a) * 1.25), 0.11, 0.045, 5, bark_hi, bark_hi)
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaves := SurfaceTool.new()
	leaves.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.09, 0.24, 0.06)
	var hi := Color(0.40, 0.62, 0.20)
	# broad crown plus long cascading strands
	MeshKit.blob_smooth(leaves, Vector3(0, 4.0, 0), Vector3(1.95, 0.85, 1.95) * 0.68, rng, lo, hi, 0.17, 8, 5)
	var willow_clusters: Array = [[Vector3(0, 4.0, 0), Vector3(1.95, 0.85, 1.95)]]
	for i in range(12):
		var a := TAU * float(i) / 12.0
		var rad := rng.randf_range(1.35, 2.25)
		var top := Vector3(cos(a) * rad * 0.55, 4.05, sin(a) * rad * 0.55)
		var bottom := Vector3(cos(a) * rad, 1.25 + rng.randf_range(-0.15, 0.35), sin(a) * rad)
		MeshKit.cylinder_between(leaves, top, bottom, 0.045, 0.018, 4, lo, lo, false)
		MeshKit.blob_smooth(leaves, bottom + Vector3(0, 0.25, 0), Vector3(0.34, 0.62, 0.34) * 0.8, rng, lo, hi, 0.20, 6, 4)
		MeshKit.blob_smooth(leaves, bottom.lerp(top, 0.45), Vector3(0.28, 0.48, 0.28) * 0.8, rng, lo, hi, 0.20, 6, 4)
		willow_clusters.append([bottom + Vector3(0, 0.25, 0), Vector3(0.36, 0.62, 0.36)])
		willow_clusters.append([bottom.lerp(top, 0.45), Vector3(0.30, 0.48, 0.30)])
	leaves.set_material(_foliage_material(0.16, 4.2, 1.2, 0.86, 0.32, 1.0, 0.88, 2.7))
	leaves.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_leaf_cards(cards, willow_clusters, rng, 7, 1.32)
	cards.set_material(_leaf_card_material(false, Color(0.24, 0.38, 0.11), Color(0.52, 0.70, 0.24), 0.16, 4.2, 1.2))
	cards.commit(mesh)
	return mesh

static func _build_baobab() -> ArrayMesh:
	var rng := _rng(107)
	var mesh := ArrayMesh.new()
	var bark_lo := Color(0.22, 0.155, 0.105)
	var bark_hi := Color(0.46, 0.32, 0.21)
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.2, 0), 1.28, 0.82, 4.6, 11, bark_lo, bark_hi)
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaves := SurfaceTool.new()
	leaves.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.18, 0.30, 0.075)
	var hi := Color(0.48, 0.58, 0.16)
	var baobab_clusters: Array = []
	for i in range(6):
		var a := TAU * float(i) / 6.0
		var start := Vector3(cos(a) * 0.52, 3.15, sin(a) * 0.52)
		var end := Vector3(cos(a) * rng.randf_range(1.8, 2.4), rng.randf_range(4.8, 5.6), sin(a) * rng.randf_range(1.8, 2.4))
		baobab_branch_ends.append(end)
		MeshKit.cylinder_between(leaves, start, end, 0.30, 0.085, 6, bark_hi, bark_hi)
		MeshKit.blob_smooth(leaves, end, Vector3(1.05, 0.70, 1.05) * 0.7, rng, lo, hi, 0.20, 7, 4)
		MeshKit.blob_smooth(leaves, end + Vector3(cos(a + 0.8) * 0.55, 0.35, sin(a + 0.8) * 0.55), Vector3(0.72, 0.55, 0.72) * 0.7, rng, lo, hi, 0.20, 6, 4)
		baobab_clusters.append([end, Vector3(1.05, 0.70, 1.05)])
		baobab_clusters.append([end + Vector3(cos(a + 0.8) * 0.55, 0.35, sin(a + 0.8) * 0.55), Vector3(0.72, 0.55, 0.72)])
	leaves.set_material(_foliage_material(0.09, 6.0, 1.0, 0.87, 0.26, 1.0, 0.9, 3.5))
	leaves.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_leaf_cards(cards, baobab_clusters, rng, 7, 1.24)
	cards.set_material(_leaf_card_material(false, Color(0.24, 0.36, 0.10), Color(0.55, 0.62, 0.20), 0.09, 6.0, 1.0))
	cards.commit(mesh)
	return mesh

static func _build_cherry() -> ArrayMesh:
	var rng := _rng(109)
	var mesh := ArrayMesh.new()
	var bark_lo := Color(0.20, 0.115, 0.10)
	var bark_hi := Color(0.40, 0.255, 0.21)
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.1, 0), 0.34, 0.20, 1.25, 8, bark_lo, bark_hi)
	MeshKit.cylinder_at(trunk, Vector3(0.04, 1.1, 0.02), 0.20, 0.11, 2.35, 7, bark_hi, bark_lo.lerp(bark_hi, 0.5))
	for i in range(4):
		var a := TAU * float(i) / 4.0 + 0.4
		MeshKit.cylinder_between(trunk, Vector3(cos(a) * 0.08, 2.2, sin(a) * 0.08), Vector3(cos(a) * 1.15, 3.2, sin(a) * 1.15), 0.09, 0.035, 5, bark_hi, bark_hi)
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaves := SurfaceTool.new()
	leaves.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.31, 0.125, 0.175)
	var hi := Color(0.80, 0.49, 0.56)
	var cherry_clusters: Array = []
	for i in range(9):
		var a := TAU * float(i) / 9.0
		var rad := rng.randf_range(0.65, 1.55)
		var p := Vector3(cos(a) * rad, rng.randf_range(3.0, 4.35), sin(a) * rad)
		var r := rng.randf_range(0.55, 0.95)
		MeshKit.blob_smooth(leaves, p, Vector3(r, r * 0.82, r) * 0.68, rng, lo, hi, 0.22, 7, 4)
		cherry_clusters.append([p, Vector3(r, r * 0.82, r)])
	MeshKit.blob_smooth(leaves, Vector3(0, 4.45, 0), Vector3(0.82, 0.68, 0.82) * 0.68, rng, lo.lerp(hi, 0.4), hi, 0.18, 7, 4)
	cherry_clusters.append([Vector3(0, 4.45, 0), Vector3(0.82, 0.68, 0.82)])
	leaves.set_material(_foliage_material(0.12, 5.0, 1.35, 0.84, 0.34, 1.0, 0.86, 3.0))
	leaves.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_leaf_cards(cards, cherry_clusters, rng, 8, 1.16)
	cards.set_material(_leaf_card_material(false, Color(0.46, 0.23, 0.29), Color(0.84, 0.57, 0.64), 0.12, 5.0, 1.35))
	cards.commit(mesh)
	return mesh

static func _build_jungle() -> ArrayMesh:
	var rng := _rng(113)
	var mesh := ArrayMesh.new()
	var bark_lo := Color(0.15, 0.105, 0.065)
	var bark_hi := Color(0.32, 0.21, 0.105)
	var trunk := SurfaceTool.new()
	trunk.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(trunk, Vector3(0, -0.2, 0), 0.60, 0.26, 5.6, 9, bark_lo, bark_hi)
	for i in range(5):
		var a := TAU * float(i) / 5.0
		MeshKit.cylinder_between(trunk, Vector3(cos(a) * 0.30, 0.8, sin(a) * 0.30), Vector3(cos(a) * 1.35, 0.0, sin(a) * 1.35), 0.30, 0.03, 6, bark_lo, bark_lo)
	trunk.set_material(_trunk_material())
	trunk.commit(mesh)

	var leaves := SurfaceTool.new()
	leaves.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.035, 0.17, 0.065)
	var hi := Color(0.16, 0.46, 0.17)
	var jungle_clusters: Array = []
	for i in range(7):
		var a := TAU * float(i) / 7.0
		var rad := rng.randf_range(0.75, 1.7)
		var p := Vector3(cos(a) * rad, rng.randf_range(4.7, 5.9), sin(a) * rad)
		MeshKit.blob_smooth(leaves, p, Vector3(1.15, 0.58, 1.05) * 0.66, rng, lo, hi, 0.22, 8, 5)
		jungle_clusters.append([p, Vector3(1.15, 0.58, 1.05)])
	MeshKit.blob_smooth(leaves, Vector3(0, 6.15, 0), Vector3(1.25, 0.62, 1.15) * 0.66, rng, lo, hi, 0.18, 8, 4)
	jungle_clusters.append([Vector3(0, 6.15, 0), Vector3(1.25, 0.62, 1.15)])
	# hanging vines under the canopy
	for i in range(9):
		var a := TAU * float(i) / 9.0
		var top := Vector3(cos(a) * rng.randf_range(0.8, 1.7), 5.15, sin(a) * rng.randf_range(0.8, 1.7))
		MeshKit.cylinder_between(leaves, top, top + Vector3(rng.randf_range(-0.15, 0.15), -rng.randf_range(1.2, 2.6), rng.randf_range(-0.15, 0.15)), 0.026, 0.012, 4, lo, lo, false)
	leaves.set_material(_foliage_material(0.10, 6.6, 1.45, 0.86, 0.32, 1.0, 0.9, 3.6))
	leaves.commit(mesh)

	var cards := SurfaceTool.new()
	cards.begin(Mesh.PRIMITIVE_TRIANGLES)
	_add_leaf_cards(cards, jungle_clusters, rng, 8, 1.46)
	cards.set_material(_leaf_card_material(false, Color(0.08, 0.26, 0.11), Color(0.26, 0.54, 0.20), 0.10, 6.6, 1.45))
	cards.commit(mesh)
	return mesh

static func _build_deadwood() -> ArrayMesh:
	var mesh := ArrayMesh.new()
	var bark := Color(0.20, 0.165, 0.13)
	var bark_hi := Color(0.37, 0.31, 0.23)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(st, Vector3(0, -0.2, 0), 0.36, 0.16, 4.1, 7, bark, bark_hi)
	# splayed, broken limbs (the old build left these pointing straight up)
	var limbs: Array = [
		[Vector3(0.0, 2.1, 0.0), Vector3(1.6, 3.2, 0.35)],
		[Vector3(0.0, 2.6, 0.0), Vector3(-1.25, 3.9, -0.5)],
		[Vector3(0.0, 3.0, 0.0), Vector3(0.55, 4.6, -1.2)],
		[Vector3(0.0, 1.55, 0.0), Vector3(-1.15, 1.2, 0.95)],
	]
	for l in limbs:
		var a: Vector3 = l[0]
		var b: Vector3 = l[1]
		MeshKit.cylinder_between(st, a, b, 0.13, 0.025, 5, bark_hi, bark)
	st.set_material(_bark_material(Color(1, 1, 1)))
	st.commit(mesh)
	return mesh

# ---------------------------------------------------------------------------
# Ground cover and props
# ---------------------------------------------------------------------------
static func _build_bush() -> ArrayMesh:
	var rng := _rng(37)
	var mesh := ArrayMesh.new()
	var leaf := SurfaceTool.new()
	leaf.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.065, 0.20, 0.045)
	var hi := Color(0.30, 0.54, 0.12)
	var blobs: Array = [
		[0.0, 0.50, 0.0, 0.82, 0.60, 0.80],
		[0.58, 0.40, 0.20, 0.56, 0.45, 0.55],
		[-0.52, 0.38, -0.22, 0.60, 0.46, 0.56],
		[0.15, 0.72, -0.32, 0.48, 0.40, 0.48],
		[-0.15, 0.65, 0.42, 0.50, 0.42, 0.50],
	]
	for b in blobs:
		MeshKit.blob_smooth(leaf, Vector3(b[0], b[1], b[2]), Vector3(b[3], b[4], b[5]), rng, lo, hi, 0.22, 7, 5)
	leaf.set_material(_foliage_material(0.055, 1.0, 1.35, 0.88, 0.26, 0.9, 0.9, 3.9))
	leaf.commit(mesh)
	return mesh

static func _build_fern() -> ArrayMesh:
	var rng := _rng(211)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.055, 0.19, 0.045)
	var hi := Color(0.28, 0.52, 0.12)
	var up := Vector3.UP
	for i in range(7):
		var a := TAU * float(i) / 7.0 + rng.randf() * 0.25
		var dir := Vector3(cos(a), 0, sin(a))
		var side := Vector3(-dir.z, 0, dir.x)
		var base := dir * 0.03
		var tip := dir * rng.randf_range(0.55, 0.95) + Vector3(0, rng.randf_range(0.32, 0.55), 0)
		var mid := base.lerp(tip, 0.5) + side * 0.03
		# central rib
		MeshKit.cylinder_between(st, base, tip, 0.012, 0.004, 3, lo, hi, true)
		# paired leaflets as small angled blades
		for k in range(4):
			var t := 0.22 + float(k) * 0.18
			var p := base.lerp(tip, t) + side * sin(PI * t) * 0.10
			var leaf_len := (1.0 - t) * 0.28
			var l0 := p
			var l1 := p + side * leaf_len + Vector3(0, 0.02, 0)
			var l2 := p + dir * 0.06 + Vector3(0, 0.035, 0)
			MeshKit.flat_tri(st, l0, l1, l2, up, lo, hi, hi)
			var l3 := p - side * leaf_len + Vector3(0, 0.02, 0)
			MeshKit.flat_tri(st, l0, l2, l3, up, lo, hi, hi)
	st.set_material(_foliage_material(0.035, 0.7, 1.5, 0.9, 0.24, 1.0, 0.9, 5.0))
	st.commit(mesh)
	return mesh

static func _build_reed() -> ArrayMesh:
	var rng := _rng(223)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.10, 0.20, 0.055)
	var hi := Color(0.38, 0.52, 0.19)
	var up := Vector3.UP
	for i in range(9):
		var a := rng.randf() * TAU
		var dist := rng.randf_range(0.0, 0.22)
		var base := Vector3(cos(a) * dist, 0, sin(a) * dist)
		var h := rng.randf_range(0.7, 1.35)
		var lean := Vector3(cos(a + 1.2), 0, sin(a + 1.2)) * rng.randf_range(0.05, 0.22)
		var side := Vector3(cos(a), 0, sin(a)) * 0.018
		var m := base + Vector3(0, h * 0.55, 0) + lean * 0.4
		var t := base + Vector3(0, h, 0) + lean
		MeshKit.flat_tri(st, base - side, base + side, m + side * 0.6, up, lo, lo, hi.lerp(lo, 0.3))
		MeshKit.flat_tri(st, base - side, m + side * 0.6, m - side * 0.6, up, lo, hi.lerp(lo, 0.3), hi.lerp(lo, 0.3))
		MeshKit.flat_tri(st, m - side * 0.6, m + side * 0.6, t, up, hi.lerp(lo, 0.3), hi.lerp(lo, 0.3), hi)
		# seed head
		if rng.randf() < 0.35:
			MeshKit.blob_smooth(st, t + Vector3(0, 0.05, 0), Vector3(0.035, 0.10, 0.035), rng, Color(0.32, 0.24, 0.12), Color(0.52, 0.40, 0.20), 0.15, 5, 3)
	st.set_material(_foliage_material(0.09, 1.2, 1.6, 0.9, 0.3, 1.0, 0.85, 6.0))
	st.commit(mesh)
	return mesh

static func _build_rock() -> ArrayMesh:
	var rng := _rng(53)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.24, 0.235, 0.225)
	var hi := Color(0.52, 0.50, 0.46)
	MeshKit.rock(st, Vector3(0, 0.42, 0), Vector3(1.0, 0.72, 0.90), rng, lo, hi)
	MeshKit.rock(st, Vector3(0.88, 0.23, 0.28), Vector3(0.52, 0.38, 0.47), rng, lo, hi)
	MeshKit.rock(st, Vector3(-0.45, 0.18, -0.42), Vector3(0.38, 0.28, 0.34), rng, lo.darkened(0.1), hi)
	st.set_material(_foliage_material(0.0, 1.0, 1.0, 0.94, 0.0, 0.55, 0.5, 5.0))
	st.commit(mesh)
	return mesh

static func _build_pebble() -> ArrayMesh:
	var rng := _rng(59)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.26, 0.245, 0.22)
	var hi := Color(0.50, 0.475, 0.43)
	for i in range(4):
		var a := TAU * float(i) / 4.0 + rng.randf() * 0.5
		var rad := rng.randf_range(0.05, 0.19)
		MeshKit.rock(st, Vector3(cos(a) * 0.14, 0.03, sin(a) * 0.14), Vector3(rad, rad * 0.55, rad * 0.9), rng, lo, hi)
	st.set_material(_foliage_material(0.0, 1.0, 1.0, 0.9, 0.0, 0.3, 0.4, 6.0))
	st.commit(mesh)
	return mesh

static func _build_waystone() -> ArrayMesh:
	var rng := _rng(311)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.30, 0.30, 0.29)
	var hi := Color(0.60, 0.58, 0.53)
	MeshKit.rock(st, Vector3(0, 0.55, 0), Vector3(0.40, 1.02, 0.32), rng, lo, hi)
	MeshKit.rock(st, Vector3(0.33, 0.11, 0.15), Vector3(0.19, 0.11, 0.15), rng, lo, hi)
	MeshKit.rock(st, Vector3(-0.29, 0.09, -0.1), Vector3(0.15, 0.09, 0.13), rng, lo, hi)
	# Weathered rune band: pale inlay slabs on the road-facing side.
	var rune := Color(0.52, 0.68, 0.78)
	for i in range(4):
		var y := 0.42 + float(i) * 0.26
		var w := 0.15 if i % 2 == 0 else 0.1
		MeshKit.box_at(st, Vector3(-0.05, y, 0.33), Vector3(w, 0.045, 0.03), rune, rune)
	for i in range(3):
		MeshKit.box_at(st, Vector3(0.0, 0.48 + float(i) * 0.24, 0.33), Vector3(0.035, 0.13, 0.03), rune, rune)
	MeshKit.blob_smooth(st, Vector3(0.12, 0.05, 0.19), Vector3(0.27, 0.06, 0.19), rng, Color(0.1, 0.2, 0.06), Color(0.2, 0.34, 0.1), 0.22, 6, 3)
	st.set_material(_foliage_material(0.0, 1.0, 1.0, 0.94, 0.0, 0.45, 0.45, 5.0))
	st.commit(mesh)
	return mesh

static func _build_log() -> ArrayMesh:
	var rng := _rng(227)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var bark_lo := Color(0.18, 0.13, 0.09)
	var bark_hi := Color(0.36, 0.26, 0.16)
	var a := Vector3(-1.15, 0.24, 0.0)
	var b := Vector3(1.15, 0.30, 0.06)
	MeshKit.cylinder_between(st, a, b, 0.29, 0.24, 9, bark_lo, bark_hi)
	# exposed cut ends (disc aligned with the log axis)
	MeshKit.cylinder(st, Transform3D(Basis(Quaternion(Vector3.UP, Vector3.RIGHT)), b), 0.24, 0.24, 0.02, 9, Color(0.62, 0.52, 0.34), Color(0.72, 0.62, 0.42))
	MeshKit.cylinder(st, Transform3D(Basis(Quaternion(Vector3.UP, Vector3.LEFT)), a), 0.29, 0.29, 0.02, 9, Color(0.62, 0.52, 0.34), Color(0.72, 0.62, 0.42))
	# moss on the upper surface
	for i in range(5):
		var p := a.lerp(b, rng.randf())
		MeshKit.blob_smooth(st, p + Vector3(0, 0.22, 0), Vector3(rng.randf_range(0.16, 0.30), 0.07, rng.randf_range(0.14, 0.24)), rng, Color(0.08, 0.18, 0.05), Color(0.22, 0.36, 0.10), 0.22, 6, 3)
	st.set_material(_trunk_material())
	st.commit(mesh)
	return mesh

static func _build_stump() -> ArrayMesh:
	var rng := _rng(229)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var bark_lo := Color(0.19, 0.14, 0.10)
	var bark_hi := Color(0.36, 0.27, 0.18)
	MeshKit.cylinder_at(st, Vector3(0, 0.0, 0), 0.36, 0.30, 0.55, 9, bark_lo, bark_hi)
	MeshKit.cylinder_at(st, Vector3(0, 0.55, 0), 0.29, 0.26, 0.03, 9, Color(0.62, 0.52, 0.35), Color(0.72, 0.62, 0.44))
	for i in range(5):
		var a := TAU * float(i) / 5.0
		MeshKit.cylinder_between(st, Vector3(cos(a) * 0.28, 0.16, sin(a) * 0.28), Vector3(cos(a) * 0.62, -0.02, sin(a) * 0.62), 0.10, 0.02, 5, bark_lo, bark_lo)
	MeshKit.blob_smooth(st, Vector3(0, 0.06, 0), Vector3(0.34, 0.05, 0.34), rng, Color(0.08, 0.16, 0.05), Color(0.20, 0.30, 0.09), 0.25, 7, 3)
	st.set_material(_trunk_material())
	st.commit(mesh)
	return mesh

static func _build_crystal() -> ArrayMesh:
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(6):
		var a := TAU * float(i) / 6.0
		var xf := Transform3D(Basis(Vector3.UP, a).scaled(Vector3(0.42, 1.0 + float(i % 3) * 0.32, 0.42)), Vector3(cos(a) * 0.42, 0.42, sin(a) * 0.42))
		MeshKit.cylinder(st, xf, 0.52, 0.0, 1.75, 6, Color(0.14, 0.42, 0.62), Color(0.48, 0.88, 1.0), true, false, false)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(1, 1, 1, 0.82)
	mat.metallic = 0.22
	mat.roughness = 0.14
	mat.emission_enabled = true
	mat.emission = Color(0.10, 0.40, 0.72)
	mat.emission_energy_multiplier = 1.15
	st.set_material(mat)
	st.commit(mesh)
	return mesh

static func _build_ore_vein() -> ArrayMesh:
	var rng := _rng(127)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.rock(st, Vector3(0, 0.52, 0), Vector3(1.20, 0.82, 1.02), rng, Color(0.20, 0.22, 0.26), Color(0.45, 0.47, 0.51))
	for i in range(10):
		var a := TAU * float(i) / 10.0
		MeshKit.blob_smooth(st, Vector3(cos(a) * 0.78, rng.randf_range(0.32, 1.05), sin(a) * 0.78), Vector3(0.16, 0.24, 0.16), rng, Color(0.55, 0.25, 0.08), Color(1.0, 0.66, 0.20), 0.12, 5, 3)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 0.38
	mat.emission_enabled = true
	mat.emission = Color(0.48, 0.18, 0.03)
	mat.emission_energy_multiplier = 0.42
	st.set_material(mat)
	st.commit(mesh)
	return mesh

static func _build_mushroom() -> ArrayMesh:
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var stem := Color(0.74, 0.68, 0.52)
	MeshKit.cylinder_at(st, Vector3(0, 0.24, 0), 0.095, 0.075, 0.52, 7, stem.darkened(0.15), stem)
	MeshKit.blob_smooth(st, Vector3(0, 0.62, 0), Vector3(0.44, 0.20, 0.44), _rng(131), Color(0.42, 0.09, 0.12), Color(0.92, 0.38, 0.28), 0.14, 8, 4)
	# pale gills under the cap
	MeshKit.cylinder_at(st, Vector3(0, 0.545, 0), 0.34, 0.34, 0.02, 8, Color(0.80, 0.66, 0.55), Color(0.86, 0.72, 0.60))
	st.set_material(_mushroom_material())
	st.commit(mesh)
	return mesh

static func _build_grass() -> ArrayMesh:
	var rng := _rng(71)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var base := Color(0.135, 0.290, 0.080, 0.45)
	var tip := Color(0.370, 0.535, 0.185, 0.45)
	var up := Vector3.UP
	for i in range(17):
		var ang: float = rng.randf() * TAU
		var dist: float = rng.randf_range(0.0, 0.42)
		var origin := Vector3(cos(ang) * dist, 0, sin(ang) * dist)
		var yaw: float = rng.randf() * PI
		var side := Vector3(cos(yaw), 0, sin(yaw)) * rng.randf_range(0.021, 0.040)
		var h: float = rng.randf_range(0.20, 0.46)
		var lean := Vector3(cos(yaw + 1.57), 0, sin(yaw + 1.57)) * rng.randf_range(0.03, 0.18)
		var mid_lean := lean * 0.35
		var b0: Vector3 = origin - side
		var b1: Vector3 = origin + side
		var m0: Vector3 = origin + Vector3(0, h * 0.55, 0) + mid_lean - side * 0.62
		var m1: Vector3 = origin + Vector3(0, h * 0.55, 0) + mid_lean + side * 0.62
		var t: Vector3 = origin + Vector3(0, h, 0) + lean
		var mc: Color = base.lerp(tip, 0.52)
		MeshKit.tri_core(st, b0, b1, m1, up, up, up, base, base, mc, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
		MeshKit.tri_core(st, b0, m1, m0, up, up, up, base, mc, mc, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
		MeshKit.tri_core(st, m0, m1, t, up, up, up, mc, mc, tip, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	st.set_material(_foliage_material(0.20, 0.55, 1.6, 0.92, 0.38, 1.0, 0.34, 8.0))
	st.commit(mesh)
	return mesh

static func _build_flower() -> ArrayMesh:
	var rng := _rng(89)
	var mesh := ArrayMesh.new()
	var stem := SurfaceTool.new()
	stem.begin(Mesh.PRIMITIVE_TRIANGLES)
	var green := Color(0.13, 0.38, 0.09, 0.0)
	MeshKit.cylinder_at(stem, Vector3(0, 0, 0), 0.012, 0.009, 0.31, 5, green, green)
	MeshKit.blob_smooth(stem, Vector3(0.05, 0.10, 0), Vector3(0.06, 0.014, 0.028), rng, green, green, 0.1, 5, 3, 0.0)
	# five petals around a small eye
	var white := Color(1, 1, 1, 1)
	for i in range(5):
		var a := TAU * float(i) / 5.0
		MeshKit.blob_smooth(stem, Vector3(cos(a) * 0.055, 0.345, sin(a) * 0.055), Vector3(0.052, 0.020, 0.052), rng, white, white, 0.12, 6, 3, 1.0)
	var eye := Color(0.95, 0.72, 0.08, 0.0)
	MeshKit.blob_smooth(stem, Vector3(0, 0.352, 0), Vector3(0.032, 0.022, 0.032), rng, eye, eye, 0.05, 5, 3, 0.0)
	stem.set_material(_foliage_material(0.10, 0.38, 1.7, 0.82, 0.2, 0.8, 0.5, 9.0))
	stem.commit(mesh)
	return mesh

static func _build_crop() -> ArrayMesh:
	var rng := _rng(97)
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.075, 0.24, 0.05)
	var hi := Color(0.40, 0.66, 0.15)
	for i in range(6):
		var a: float = TAU * float(i) / 6.0
		var p := Vector3(cos(a) * 0.15, 0.16, sin(a) * 0.15)
		MeshKit.blob_smooth(st, p, Vector3(0.19, 0.20, 0.19), rng, lo, hi, 0.22, 6, 4)
	MeshKit.blob_smooth(st, Vector3(0, 0.30, 0), Vector3(0.22, 0.26, 0.22), rng, lo, hi, 0.20, 6, 4)
	st.set_material(_foliage_material(0.045, 0.55, 1.5, 0.88, 0.28, 1.0, 0.75, 5.5))
	st.commit(mesh)
	return mesh

# Convenience: MultiMeshInstance3D from transforms + per-instance tints
static func make_multimesh(kind: String, xforms: Array[Transform3D], tints: PackedColorArray,
		vis_end: float = 0.0, cast_shadows: bool = true) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_custom_data = true
	mm.mesh = get_mesh(kind)
	mm.instance_count = xforms.size()
	for i in range(xforms.size()):
		mm.set_instance_transform(i, xforms[i])
		mm.set_instance_custom_data(i, tints[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if vis_end > 0.0:
		mmi.visibility_range_end = vis_end
		mmi.visibility_range_end_margin = vis_end * 0.12
		mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	return mmi
