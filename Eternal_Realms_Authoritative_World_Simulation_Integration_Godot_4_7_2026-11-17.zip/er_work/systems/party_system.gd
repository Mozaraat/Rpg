# Temporary local party manager. Kept transport-agnostic for future online play.
extends Node

signal party_changed(party: Dictionary)
const MAX_PARTY_SIZE: int = 20
var party_id: String = ""
var leader_id: String = "local_player"
var members: Array[Dictionary] = []
var hunting_target: String = ""
var active: bool = false

func create_party(player_name: String = "You") -> bool:
	if active:
		return false
	party_id = "P-%d-%04d" % [int(Time.get_unix_time_from_system()), randi_range(1000, 9999)]
	leader_id = "local_player"
	members = [{"id": leader_id, "name": player_name, "role": "leader", "ready": true, "online": true}]
	hunting_target = ""
	active = true
	_emit()
	return true

func invite_local_member(member_id: String, member_name: String) -> bool:
	if not active or members.size() >= MAX_PARTY_SIZE or member_id.strip_edges() == "":
		return false
	for m in members:
		if str(m.id) == member_id:
			return false
	members.append({"id": member_id, "name": member_name, "role": "member", "ready": false, "online": true})
	_emit()
	return true

func set_ready(member_id: String, ready: bool) -> void:
	for i in range(members.size()):
		if str(members[i].id) == member_id:
			members[i].ready = ready
	_emit()

func set_hunting_target(target: String) -> void:
	hunting_target = target
	_emit()

func remove_member(member_id: String) -> void:
	for i in range(members.size() - 1, -1, -1):
		if str(members[i].id) == member_id and member_id != leader_id:
			members.remove_at(i)
	_emit()

func disband_party() -> void:
	active = false
	party_id = ""
	members.clear()
	hunting_target = ""
	_emit()

func get_snapshot() -> Dictionary:
	return {"active": active, "party_id": party_id, "leader_id": leader_id, "members": members.duplicate(true), "hunting_target": hunting_target}

func _emit() -> void:
	party_changed.emit(get_snapshot())

func apply_network_party(payload: Dictionary) -> void:
	active = true
	party_id = str(payload.get("party_id", ""))
	leader_id = str(payload.get("leader", ""))
	members.clear()
	var ids: Array = payload.get("members", [])
	var names: Array = payload.get("names", [])
	for i in range(ids.size()):
		var peer_id: int = int(ids[i])
		var member_name: String = str(names[i]) if i < names.size() else "Cultivator %d" % peer_id
		members.append({"id": str(peer_id), "name": member_name, "role": "leader" if peer_id == int(payload.get("leader", -1)) else "member", "ready": true, "online": true})
	_emit()

func invite_online_peer(peer_id: int) -> void:
	MMORPGNetwork.invite_to_party(peer_id)

func accept_online_invite(invite_id: String) -> void:
	MMORPGNetwork.accept_party_invite(invite_id)

func leave_online_party() -> void:
	MMORPGNetwork.leave_server_party()

func create_online_party(player_name: String = "You") -> bool:
	if MMORPGNetwork.is_online():
		if multiplayer.is_server():
			MMORPGNetwork.create_server_party(1)
			return true
		MMORPGNetwork.rpc_id(1, "server_create_party")
		return true
	return create_party(player_name)
