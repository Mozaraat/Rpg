# Elyndor's regional director: habitat-aware wildlife and a persistent field-to-depths journal.
# Keeps the first-region loop connected without replacing the existing quest, inventory,
# profession, settlement, or dungeon systems.
extends Node

const JOURNAL_KEY := "elyndor_field_journal"
const MAX_WILDLIFE := 22
const SPAWN_INTERVAL := 18.0
const SPECIES_BY_BIOME := {
    TerrainNoise.Biome.OCEAN: [],
    TerrainNoise.Biome.BEACH: ["shorebird", "red_fox"],
    TerrainNoise.Biome.PLAINS: ["rabbit", "red_deer", "wild_boar", "red_fox", "shorebird"],
    TerrainNoise.Biome.FOREST: ["rabbit", "red_deer", "wild_boar", "red_fox", "grey_wolf", "brown_bear", "lynx", "river_otter"],
    TerrainNoise.Biome.HILLS: ["red_deer", "wild_boar", "red_fox", "grey_wolf", "mountain_goat", "elk"],
    TerrainNoise.Biome.MOUNTAIN: ["mountain_goat", "snow_leopard", "grey_wolf", "brown_bear"],
    TerrainNoise.Biome.SNOW: ["arctic_hare", "snow_fox", "snow_leopard", "tundra_muskox"],
    TerrainNoise.Biome.SWAMP: ["marsh_deer", "marsh_crocodile", "marsh_heron", "river_otter", "wild_boar"],
    TerrainNoise.Biome.DESERT: ["desert_gazelle", "sand_cat", "hyena", "vulture"],
    TerrainNoise.Biome.AUTUMN_WOOD: ["red_deer", "rabbit", "red_fox", "wild_boar", "brown_bear"],
    TerrainNoise.Biome.VOLCANIC: ["ash_goat", "ember_lizard", "vulture"],
    TerrainNoise.Biome.RAINFOREST: ["tapir", "jaguar", "monkey", "marsh_heron", "river_otter"],
    TerrainNoise.Biome.JUNGLE: ["tapir", "jaguar", "monkey", "marsh_crocodile", "marsh_heron"],
    TerrainNoise.Biome.TAIGA: ["elk", "lynx", "brown_bear", "grey_wolf", "snow_fox", "river_otter"],
    TerrainNoise.Biome.TUNDRA: ["arctic_hare", "snow_fox", "tundra_muskox", "snow_leopard"],
    TerrainNoise.Biome.SAVANNA: ["desert_gazelle", "hyena", "savanna_elephant", "savanna_lion", "vulture"],
    TerrainNoise.Biome.MEDITERRANEAN: ["rabbit", "red_deer", "red_fox", "wild_boar", "shorebird"]
}

var _terrain: TerrainNoise
var _spawn_clock := 0.0
var _journal: Dictionary = {}
var _rng := RandomNumberGenerator.new()
var _last_region := ""

func _ready() -> void:
    add_to_group("elyndor_region_life")
    _terrain = TerrainNoise.new(GameManager.world_seed)
    _rng.seed = GameManager.world_seed + 91827
    var saved: Variant = PlayerData.stats.get(JOURNAL_KEY, {})
    _journal = saved.duplicate(true) if saved is Dictionary else {}
    for key in ["harvested", "hunted", "fished", "crafted", "regions_seen", "dungeon_floors"]:
        if not _journal.has(key): _journal[key] = 0
    for key in ["harvested_items", "hunted_species", "fish_caught", "crafted_items", "regions"]:
        if not (_journal.get(key, {}) is Dictionary):
            _journal[key] = {}
    _save_journal()
    EventBus.entity_died.connect(_on_entity_died)

func _process(delta: float) -> void:
    if GameManager.current_state != GameManager.GameState.PLAYING: return
    _spawn_clock += delta
    if _spawn_clock < SPAWN_INTERVAL: return
    _spawn_clock = 0.0
    _maintain_habitat_population()

func _save_journal() -> void:
    PlayerData.stats[JOURNAL_KEY] = _journal.duplicate(true)

func get_field_journal() -> Dictionary:
    return _journal.duplicate(true)

func record_harvest(item_id: String, amount: int = 1) -> void:
    var gained := maxi(amount, 1)
    _journal["harvested"] = int(_journal.get("harvested", 0)) + gained
    var by_item: Dictionary = _journal.get("harvested_items", {})
    by_item[item_id] = int(by_item.get(item_id, 0)) + gained
    _journal["harvested_items"] = by_item
    # PlayerData.add_item() already reports successful collection to quests.
    # Do not notify again here or one harvest advances collect objectives twice.
    _save_journal()
    if is_instance_valid(GuildContracts):
        GuildContracts.record_progress("gather", gained)
    _check_milestones()

func record_fishing(item_id: String) -> void:
    _journal["fished"] = int(_journal.get("fished", 0)) + 1
    var catches: Dictionary = _journal.get("fish_caught", {})
    catches[item_id] = int(catches.get(item_id, 0)) + 1
    _journal["fish_caught"] = catches
    PlayerData.notify("fish", item_id, 1)
    _save_journal()
    if is_instance_valid(GuildContracts):
        GuildContracts.record_progress("fish", 1)
    _check_milestones()

func record_crafting(item_id: String, amount: int = 1) -> void:
    var made := maxi(amount, 1)
    _journal["crafted"] = int(_journal.get("crafted", 0)) + made
    var recipes: Dictionary = _journal.get("crafted_items", {})
    recipes[item_id] = int(recipes.get(item_id, 0)) + made
    _journal["crafted_items"] = recipes
    _save_journal()
    if is_instance_valid(GuildContracts):
        GuildContracts.record_progress("craft", made)
    _check_milestones()

func record_dungeon_floor(floor_number: int) -> void:
    var previous := int(_journal.get("dungeon_floors", 0))
    _journal["dungeon_floors"] = maxi(previous, floor_number)
    _save_journal()
    if floor_number > previous and is_instance_valid(GuildContracts):
        GuildContracts.record_progress("dungeon", 1)

func _on_entity_died(entity: Node) -> void:
    if entity == null or not is_instance_valid(entity): return
    # Only count hostile creatures/monsters. Other entities may emit the shared
    # death signal for scripted cleanup and must not inflate hunting milestones.
    if not entity.is_in_group("enemy"):
        return
    _journal["hunted"] = int(_journal.get("hunted", 0)) + 1
    var species := str(entity.name)
    for property_info in entity.get_property_list():
        if str(property_info.get("name", "")) == "monster_id":
            species = str(entity.get("monster_id"))
            break
    var hunted: Dictionary = _journal.get("hunted_species", {})
    hunted[species] = int(hunted.get(species, 0)) + 1
    _journal["hunted_species"] = hunted
    _save_journal()
    _check_milestones()

func on_region_discovered(region_name: String) -> void:
    _journal["regions_seen"] = int(_journal.get("regions_seen", 0)) + 1
    _last_region = region_name
    var discovered: Dictionary = _journal.get("regions", {})
    discovered[region_name] = true
    _journal["regions"] = discovered
    _save_journal()
    if is_instance_valid(GuildContracts):
        GuildContracts.record_progress("explore", 1)
    EventBus.activity.emit("Field journal updated: %s" % region_name, "exploration")
    _check_milestones()

func _check_milestones() -> void:
    var flags: Dictionary = _journal.get("milestones", {})
    var checks := [
        {"id":"field_hand", "title":"Field Hand", "ok":int(_journal.get("harvested", 0)) >= 8, "detail":"Gather 8 regional resources"},
        {"id":"stalker", "title":"Heartlands Stalker", "ok":int(_journal.get("hunted", 0)) >= 5, "detail":"Hunt 5 creatures or monsters"},
        {"id":"angler", "title":"Waterside Regular", "ok":int(_journal.get("fished", 0)) >= 3, "detail":"Land 3 fish"},
        {"id":"artisan", "title":"Practical Artisan", "ok":int(_journal.get("crafted", 0)) >= 5, "detail":"Craft 5 items"},
        {"id":"wayfarer", "title":"Elyndor Wayfarer", "ok":int(_journal.get("regions_seen", 0)) >= 4, "detail":"Discover 4 regions"}
    ]
    for milestone in checks:
        var id: String = str(milestone.get("id", ""))
        if bool(milestone.get("ok", false)) and not bool(flags.get(id, false)):
            flags[id] = true
            EventBus.toast.emit("Field milestone: %s" % milestone.get("title", "Field milestone"), "levelup")
            EventBus.activity.emit("%s — %s" % [milestone.get("title", "Field milestone"), milestone.get("detail", "")], "journal")
    _journal["milestones"] = flags
    _save_journal()

func get_expedition_readiness() -> Dictionary:
    var milestones: Dictionary = _journal.get("milestones", {})
    var score := 0
    for id in ["field_hand", "stalker", "angler", "artisan", "wayfarer"]:
        if bool(milestones.get(id, false)): score += 1
    return {"score":score, "out_of":5, "recommended":score >= 3,
        "message":"Ready for a prepared expedition" if score >= 3 else "Explore, hunt, fish and craft before descending"}

func _maintain_habitat_population() -> void:
    var player: Node3D = GameManager.player
    if player == null or not is_instance_valid(player) or get_tree().current_scene == null: return
    # Manage only wildlife created by this director; authored village animals
    # remain untouched. Remove distant ambient animals so new habitats populate
    # as the player travels instead of exhausting one global spawn cap.
    var current := get_tree().get_nodes_in_group("elyndor_spawned_wildlife")
    for animal_node in current:
        if not is_instance_valid(animal_node) or not animal_node is Node3D:
            continue
        var wildlife := animal_node as Node3D
        if wildlife.global_position.distance_to(player.global_position) > 105.0:
            wildlife.queue_free()
    var pressure := LivingEcosystem.get_wildlife_pressure_at(player.global_position)
    # Unmanaged populations push more wildlife into nearby loaded habitats.
    # Hunting reduces regional pressure over subsequent simulation ticks.
    var local_wildlife_cap := MAX_WILDLIFE + int(round(pressure * 24.0))
    current = get_tree().get_nodes_in_group("elyndor_spawned_wildlife")
    if current.size() < local_wildlife_cap:
        _maintain_aquatic_population(player, local_wildlife_cap - current.size())
    current = get_tree().get_nodes_in_group("elyndor_spawned_wildlife")
    if current.size() >= local_wildlife_cap: return
    var spawned := 0
    for attempt in range(18):
        if current.size() + spawned >= local_wildlife_cap or spawned >= 4: break
        var angle := _rng.randf() * TAU
        var radius := _rng.randf_range(24.0, 62.0)
        var x := player.global_position.x + cos(angle) * radius
        var z := player.global_position.z + sin(angle) * radius
        var height := _terrain.get_height(x, z)
        if height <= Constants.WATER_LEVEL + 0.6: continue
        var biome := _terrain.get_biome(x, z, height)
        var species: Array = SPECIES_BY_BIOME.get(biome, ["rabbit", "deer"])
        if species.is_empty(): continue
        var animal := Critter.new()
        animal.kind = str(species[_rng.randi_range(0, species.size() - 1)])
        # Set the transform before add_child(): Critter._ready() records its
        # home position, so adding it at the origin first breaks its habitat leash.
        animal.position = Vector3(x, height + 0.12, z)
        animal.add_to_group("elyndor_spawned_wildlife")
        get_tree().current_scene.add_child(animal)
        spawned += 1


## Small, capped schools of visible fish are created only around loaded water.
## Their long-term population remains in the regional ecology worker.
func _maintain_aquatic_population(player: Node3D, available_slots: int) -> void:
    if available_slots <= 0:
        return
    var current_fish := get_tree().get_nodes_in_group("elyndor_spawned_marine_life")
    if current_fish.size() >= 5:
        return
    var to_spawn := mini(2, mini(5 - current_fish.size(), available_slots))
    var spawned := 0
    for attempt in range(18):
        if spawned >= to_spawn:
            break
        var angle := _rng.randf() * TAU
        var radius := _rng.randf_range(18.0, 68.0)
        var x := player.global_position.x + cos(angle) * radius
        var z := player.global_position.z + sin(angle) * radius
        var bed := _terrain.get_height(x, z)
        if bed > Constants.WATER_LEVEL - 0.8:
            continue
        var water_surface := TideSystem.level_at_bed(bed)
        var fish := MarineFish.new()
        fish.is_ocean = bed < -1.2
        if fish.is_ocean:
            var ocean_species := ["fish_mackerel", "fish_glowfin", "fish_parrotfish", "fish_sunfish", "fish_puffer"]
            fish.fish_id = ocean_species[_rng.randi_range(0, ocean_species.size() - 1)]
        else:
            var river_species := ["fish_minnow", "fish_trout", "fish_bass", "fish_koi"]
            fish.fish_id = river_species[_rng.randi_range(0, river_species.size() - 1)]
        fish.position = Vector3(x, water_surface - _rng.randf_range(0.35, 1.1), z)
        fish.add_to_group("elyndor_spawned_wildlife")
        fish.add_to_group("elyndor_spawned_marine_life")
        get_tree().current_scene.add_child(fish)
        spawned += 1
