# VFX - small helpers that build CPU particle effects in code (no texture assets needed).
class_name VFX
extends RefCounted

static func _particle_mesh(radius: float, additive: bool, segs: int = 6) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = radius
	m.height = radius * 2.0
	m.radial_segments = segs
	m.rings = maxi(segs / 2, 3)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if additive:
		mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.material = mat
	return m

static func _fade_ramp(c0: Color, c1: Color) -> Gradient:
	var g := Gradient.new()
	g.colors = PackedColorArray([c0, c1])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	return g

static func _shrink_curve() -> Curve:
	var c := Curve.new()
	c.add_point(Vector2(0, 1))
	c.add_point(Vector2(1, 0))
	return c

static func _grow_curve() -> Curve:
	var c := Curve.new()
	c.add_point(Vector2(0, 0.4))
	c.add_point(Vector2(1, 1.6))
	return c

## One-shot spark burst (hits, deaths). Frees itself.
static func burst(parent: Node, pos: Vector3, color: Color, amount: int = 14, speed: float = 5.0, size: float = 0.06) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = 0.45
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -9.8, 0)
	p.mesh = _particle_mesh(size, true)
	p.color = color
	p.scale_amount_curve = _shrink_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	var tree: SceneTree = parent.get_tree()
	if tree:
		# bound to p itself, so it is dropped automatically if p is freed first
		tree.create_timer(1.2).timeout.connect(p.queue_free)

static func smoke(parent: Node3D, pos: Vector3) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = 14
	p.lifetime = 5.0
	p.direction = Vector3.UP
	p.spread = 12.0
	p.initial_velocity_min = 0.5
	p.initial_velocity_max = 0.9
	p.gravity = Vector3(0.25, 0.1, 0.1)
	p.mesh = _particle_mesh(0.22, false, 6)
	p.color_ramp = _fade_ramp(Color(0.75, 0.75, 0.78, 0.45), Color(0.6, 0.6, 0.65, 0.0))
	p.scale_amount_curve = _grow_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.position = pos
	parent.add_child(p)
	return p

static func fire(parent: Node3D, pos: Vector3, scale_f: float = 1.0) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = 22
	p.lifetime = 0.8
	p.direction = Vector3.UP
	p.spread = 18.0
	p.initial_velocity_min = 0.6 * scale_f
	p.initial_velocity_max = 1.3 * scale_f
	p.gravity = Vector3(0, 0.5, 0)
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.12 * scale_f
	p.mesh = _particle_mesh(0.11 * scale_f, true, 6)
	p.color_ramp = _fade_ramp(Color(1.0, 0.75, 0.25, 1.0), Color(1.0, 0.15, 0.02, 0.0))
	p.scale_amount_curve = _shrink_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.position = pos
	parent.add_child(p)
	return p

static func fountain_spray(parent: Node3D, pos: Vector3) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = 60
	p.lifetime = 1.4
	p.direction = Vector3.UP
	p.spread = 14.0
	p.initial_velocity_min = 3.2
	p.initial_velocity_max = 4.2
	p.gravity = Vector3(0, -9.8, 0)
	p.mesh = _particle_mesh(0.04, false, 5)
	p.color = Color(0.7, 0.88, 1.0, 0.8)
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.position = pos
	parent.add_child(p)
	return p

## Drifting night-time fireflies in a box around `parent`.
static func fireflies(parent: Node3D) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.name = "Fireflies"
	p.amount = 80
	p.lifetime = 7.0
	p.local_coords = false
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(28, 3, 28)
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = 0.15
	p.initial_velocity_max = 0.5
	p.gravity = Vector3.ZERO
	p.mesh = _particle_mesh(0.035, true, 5)
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0.7, 1.0, 0.3, 0.0), Color(0.8, 1.0, 0.35, 1.0), Color(0.7, 1.0, 0.3, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	p.color_ramp = g
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.emitting = false
	parent.add_child(p)
	return p


## Expanding emissive impact ring for heavy techniques, perfect guards and boss impacts.
static func impact_ring(parent: Node3D, pos: Vector3, color: Color, radius: float = 2.0) -> void:
	var torus := TorusMesh.new()
	torus.inner_radius = 0.72
	torus.outer_radius = 0.86
	torus.rings = 8
	torus.ring_segments = 20
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 2.2
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	torus.material = mat
	var ring := MeshInstance3D.new()
	ring.mesh = torus
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ring.global_position = pos + Vector3.UP * 0.08
	ring.rotation.x = PI * 0.5
	ring.scale = Vector3.ONE * 0.25
	parent.add_child(ring)
	var tw := parent.create_tween()
	tw.set_parallel(true)
	tw.tween_property(ring, "scale", Vector3.ONE * radius, 0.34).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.34)
	tw.chain().tween_callback(ring.queue_free)


## Short directional particle sweep for weapon contact. Kept separate from the
## authored blade arc so hits read clearly without covering the whole screen.
static func weapon_sweep(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, landed: bool = false) -> void:
	var p := CPUParticles3D.new()
	p.name = "WeaponSweepVFX"
	p.one_shot = true
	p.amount = 20 if landed else 11
	p.lifetime = 0.24
	p.explosiveness = 0.92
	p.direction = direction.normalized() if direction.length_squared() > 0.001 else Vector3.FORWARD
	p.spread = 34.0
	p.initial_velocity_min = 2.2 if landed else 1.4
	p.initial_velocity_max = 5.0 if landed else 3.0
	p.gravity = Vector3(0.0, -1.8, 0.0)
	p.mesh = _particle_mesh(0.035 if landed else 0.025, true, 5)
	p.color_ramp = _fade_ramp(color.lightened(0.35), Color(color.r, color.g, color.b, 0.0))
	p.scale_amount_curve = _shrink_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	var tree := parent.get_tree()
	if tree:
		tree.create_timer(0.8).timeout.connect(p.queue_free)

## Low-cost ground contact puff for heavy landings and large creature impacts.
static func dust_puff(parent: Node3D, pos: Vector3, strength: float = 1.0) -> void:
	var p := CPUParticles3D.new()
	p.name = "GroundDustVFX"
	p.one_shot = true
	p.amount = clampi(int(14.0 * strength), 8, 36)
	p.lifetime = 0.62
	p.explosiveness = 0.82
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	p.emission_ring_radius = 0.22
	p.emission_ring_height = 0.08
	p.direction = Vector3.UP
	p.spread = 72.0
	p.initial_velocity_min = 0.55 * strength
	p.initial_velocity_max = 1.7 * strength
	p.gravity = Vector3(0.0, -1.5, 0.0)
	p.mesh = _particle_mesh(0.10, false, 5)
	p.color_ramp = _fade_ramp(Color(0.48, 0.40, 0.30, 0.42), Color(0.34, 0.30, 0.25, 0.0))
	p.scale_amount_curve = _grow_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.global_position = pos + Vector3.UP * 0.08
	p.emitting = true
	var tree := parent.get_tree()
	if tree:
		tree.create_timer(1.0).timeout.connect(p.queue_free)

## Sparse drifting pollen/dust, repositioned around the player by DayNightCycle.
static func ambient_drift(parent: Node3D) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.name = "AmbientPollen"
	p.amount = 38
	p.lifetime = 10.0
	p.local_coords = false
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(20.0, 5.0, 20.0)
	p.direction = Vector3(0.2, 0.18, 0.0)
	p.spread = 34.0
	p.initial_velocity_min = 0.035
	p.initial_velocity_max = 0.12
	p.gravity = Vector3(0.015, 0.012, 0.0)
	p.mesh = _particle_mesh(0.025, true, 5)
	p.color_ramp = _fade_ramp(Color(0.88, 0.78, 0.52, 0.0), Color(0.92, 0.84, 0.64, 0.42))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	p.emitting = true
	parent.add_child(p)
	return p


## Persistent short tail behind moving arrows and spells. Local-coordinates are
## disabled so emitted particles remain in the world as the projectile advances.
static func projectile_trail(parent: Node3D, color: Color) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.name = "ProjectileTrailVFX"
	p.amount = 26
	p.lifetime = 0.34
	p.local_coords = false
	p.direction = Vector3.BACK
	p.spread = 22.0
	p.initial_velocity_min = 0.18
	p.initial_velocity_max = 0.72
	p.gravity = Vector3.ZERO
	p.mesh = _particle_mesh(0.045, true, 5)
	p.color_ramp = _fade_ramp(color.lightened(0.3), Color(color.r, color.g, color.b, 0.0))
	p.scale_amount_curve = _shrink_curve()
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.emitting = true
	return p
