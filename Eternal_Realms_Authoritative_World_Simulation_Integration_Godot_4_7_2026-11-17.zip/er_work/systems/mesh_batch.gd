# MeshBatch - collects geometry per material name, then commits ONE ArrayMesh
# (one draw call per material, one MeshInstance3D per building).
class_name MeshBatch
extends RefCounted

var _tools: Dictionary = {}

func surface(material_name: String) -> SurfaceTool:
	if not _tools.has(material_name):
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		_tools[material_name] = st
	return _tools[material_name]

func is_empty() -> bool:
	return _tools.is_empty()

## material_lookup: Callable(String) -> Material
func commit(material_lookup: Callable, with_tangents: bool = true) -> ArrayMesh:
	var mesh := ArrayMesh.new()
	for key in _tools.keys():
		var st: SurfaceTool = _tools[key]
		if with_tangents:
			st.generate_tangents()
		st.set_material(material_lookup.call(key))
		st.commit(mesh)
	return mesh
