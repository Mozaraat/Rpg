extends Node

signal business_changed(business_id: String, stock: Dictionary)
signal world_event_started(event_id: String, title: String)
signal family_bond_changed(family_id: String, bond: int)

const BUSINESS_SEEDS := {
    "elyndor_market": {"name":"Elyndor General Market", "owner":"Mira", "stock":{"healing_potion":5,"fish_mackerel":8,"leather_strip":4,"wood_log":8,"iron_ore":6,"iron_ingot":3,"cloth_tunic":2}, "specialty":"provisions"},
    "elyndor_forge": {"name":"Gorrim's Forge", "owner":"Gorrim the Smith", "stock":{"iron_ore":8,"iron_ingot":5,"wood_log":4}, "specialty":"metalwork"},
    "spire_apothecary": {"name":"Spire Apothecary", "owner":"Archmage Lira", "stock":{"healing_potion":7,"moonberry_preserve":4}, "specialty":"alchemy"}
}
const EVENTS := [
    {"id":"caravan_arrival", "title":"The Merchant Caravan Arrives", "detail":"A guarded caravan has reached Elyndor. Market shelves are being replenished.", "color":Color(0.82,0.62,0.28), "guards":2},
    {"id":"festival", "title":"The Lantern Festival", "detail":"Families gather beneath lanterns while musicians and traders fill the square.", "color":Color(0.95,0.72,0.34), "guards":1},
    {"id":"faction_patrol", "title":"Faction Patrol in the Outskirts", "detail":"A faction patrol is questioning travellers. Your reputation may change their welcome.", "color":Color(0.55,0.68,0.82), "guards":3},
    {"id":"relief_convoy", "title":"A Relief Convoy Needs Help", "detail":"Workers are unloading food and timber for families affected by recent shortages.", "color":Color(0.46,0.78,0.55), "guards":1}
]
var businesses: Dictionary = {}
var family_bonds: Dictionary = {}
var _business_tick := 0.0
var _event_tick := 0.0
var _active_event: Dictionary = {}
var _event_root: Node3D
var _event_remaining := 0.0
var _rng := RandomNumberGenerator.new()
var npc_lives: Dictionary = {}
var households: Dictionary = {}
var _last_day_phase := -1.0
var _world_day := 0
var _child_spawn_check := 0.0
var expeditions: Dictionary = {}
var society_history: Array[Dictionary] = []
var _shared_dirty := false
var _shared_change_serial := 0
var _shared_timer := 0.0
var _visit_timer := 0.0
var _last_player_region := ""
var _settlement_visit_days: Dictionary = {}
var _last_world_timestamp := 0
var _backend_revision := 0
var _backend_save_busy := false
const GAME_DAY_SECONDS := 480.0
const ADULT_AGE_DAYS := 18 * 365
const RETIREMENT_AGE_DAYS := 68 * 365
const MAX_OFFLINE_DAYS := 3650
const SOCIETY_ENTITY_ID := "5b690461-8f11-0398-deaf-cde5aa1050a1"
const DEFENCE_ROLES := ["guard", "soldier", "ranger", "hunter", "adventurer", "mercenary", "swordsman"]
const NPC_SCENE := preload("res://scenes/npc.tscn")

func _ready() -> void:
    add_to_group("living_world")
    _rng.seed = GameManager.world_seed + 7731
    _restore_state()
    call_deferred("_restore_shared_society")

func _process(delta: float) -> void:
    if GameManager.current_state != GameManager.GameState.PLAYING: return
    _business_tick += delta
    _event_tick += delta
    _child_spawn_check += delta
    _shared_timer += delta
    _visit_timer += delta
    _update_world_day()
    if _child_spawn_check >= 18.0:
        _child_spawn_check = 0.0
        _ensure_living_residents()
    if _business_tick >= 90.0:
        _business_tick = 0.0
        _restock_businesses()
    if _visit_timer >= 5.0:
        _visit_timer = 0.0
        _check_player_settlement_visit()
    if _shared_dirty and _shared_timer >= 25.0:
        _shared_timer = 0.0
        _persist_shared_society()
    if _event_remaining > 0.0:
        _event_remaining -= delta
        if _event_remaining <= 0.0: _clear_event()
    if _event_tick >= 145.0 and _active_event.is_empty():
        _event_tick = 0.0
        if _rng.randf() < 0.82: _start_world_event()

func _restore_state() -> void:
    var saved: Variant = PlayerData.stats.get("living_businesses", {})
    businesses = saved.duplicate(true) if saved is Dictionary and not saved.is_empty() else BUSINESS_SEEDS.duplicate(true)
    for id in BUSINESS_SEEDS:
        if not businesses.has(id): businesses[id] = BUSINESS_SEEDS[id].duplicate(true)
        if not businesses[id].has("region_id") or str(businesses[id].get("region_id", "")) == "arcane_spire":
            businesses[id]["region_id"] = "mirrorwater" if id == "spire_apothecary" else "elyndor"
    var bonds: Variant = PlayerData.stats.get("family_bonds", {})
    family_bonds = bonds.duplicate(true) if bonds is Dictionary else {}
    var saved_lives: Variant = PlayerData.stats.get("npc_lives", {})
    npc_lives = saved_lives.duplicate(true) if saved_lives is Dictionary else {}
    var saved_households: Variant = PlayerData.stats.get("npc_households", {})
    households = saved_households.duplicate(true) if saved_households is Dictionary else {}
    var saved_expeditions: Variant = PlayerData.stats.get("npc_expeditions", {})
    expeditions = saved_expeditions.duplicate(true) if saved_expeditions is Dictionary else {}
    var saved_history: Variant = PlayerData.stats.get("npc_society_history", [])
    society_history.clear()
    if saved_history is Array:
        for entry in saved_history:
            if entry is Dictionary: society_history.append(entry.duplicate(true))
    var visits: Variant = PlayerData.stats.get("npc_settlement_visits", {})
    _settlement_visit_days = visits.duplicate(true) if visits is Dictionary else {}
    _world_day = int(PlayerData.stats.get("npc_world_day", 0))
    _last_world_timestamp = int(PlayerData.stats.get("npc_world_timestamp", Time.get_unix_time_from_system()))
    _save_player_snapshot_only()

func refresh_from_player_data() -> void:
    var saved: Variant = PlayerData.stats.get("living_businesses", {})
    if saved is Dictionary and not saved.is_empty():
        businesses = saved.duplicate(true)
    var bonds: Variant = PlayerData.stats.get("family_bonds", {})
    family_bonds = bonds.duplicate(true) if bonds is Dictionary else {}
    var saved_lives: Variant = PlayerData.stats.get("npc_lives", {})
    npc_lives = saved_lives.duplicate(true) if saved_lives is Dictionary else {}
    var saved_households: Variant = PlayerData.stats.get("npc_households", {})
    households = saved_households.duplicate(true) if saved_households is Dictionary else {}
    var saved_expeditions: Variant = PlayerData.stats.get("npc_expeditions", {})
    expeditions = saved_expeditions.duplicate(true) if saved_expeditions is Dictionary else {}
    _world_day = int(PlayerData.stats.get("npc_world_day", _world_day))
    for id in BUSINESS_SEEDS:
        if not businesses.has(id): businesses[id] = BUSINESS_SEEDS[id].duplicate(true)
        if not businesses[id].has("region_id") or str(businesses[id].get("region_id", "")) == "arcane_spire":
            businesses[id]["region_id"] = "mirrorwater" if id == "spire_apothecary" else "elyndor"

func _save_state() -> void:
    PlayerData.stats["living_businesses"] = businesses.duplicate(true)
    PlayerData.stats["family_bonds"] = family_bonds.duplicate(true)
    PlayerData.stats["npc_lives"] = npc_lives.duplicate(true)
    PlayerData.stats["npc_households"] = households.duplicate(true)
    PlayerData.stats["npc_expeditions"] = expeditions.duplicate(true)
    PlayerData.stats["npc_society_history"] = society_history.duplicate(true)
    PlayerData.stats["npc_settlement_visits"] = _settlement_visit_days.duplicate(true)
    PlayerData.stats["npc_world_day"] = _world_day
    PlayerData.stats["npc_world_timestamp"] = Time.get_unix_time_from_system()
    _last_world_timestamp = int(PlayerData.stats["npc_world_timestamp"])
    _shared_change_serial += 1
    _shared_dirty = true

func _society_payload() -> Dictionary:
    return {
        "schema_version": 2,
        "world_day": _world_day,
        "saved_at_unix": Time.get_unix_time_from_system(),
        "businesses": businesses.duplicate(true),
        "family_bonds": family_bonds.duplicate(true),
        "npc_lives": npc_lives.duplicate(true),
        "households": households.duplicate(true),
        "expeditions": expeditions.duplicate(true),
        "history": society_history.duplicate(true),
        "settlement_visits": _settlement_visit_days.duplicate(true)
    }

func _apply_society_payload(payload: Dictionary, allow_older_day: bool = false) -> void:
    if int(payload.get("schema_version", 0)) < 1: return
    var saved_day := int(payload.get("world_day", _world_day))
    if saved_day < _world_day and not allow_older_day: return
    _world_day = saved_day
    _last_world_timestamp = int(payload.get("saved_at_unix", _last_world_timestamp))
    var next_businesses: Variant = payload.get("businesses", {})
    var next_bonds: Variant = payload.get("family_bonds", {})
    var next_lives: Variant = payload.get("npc_lives", {})
    var next_households: Variant = payload.get("households", {})
    var next_expeditions: Variant = payload.get("expeditions", {})
    var next_history: Variant = payload.get("history", [])
    if next_businesses is Dictionary and not next_businesses.is_empty(): businesses = next_businesses.duplicate(true)
    if next_bonds is Dictionary: family_bonds = next_bonds.duplicate(true)
    if next_lives is Dictionary: npc_lives = next_lives.duplicate(true)
    if next_households is Dictionary: households = next_households.duplicate(true)
    if next_expeditions is Dictionary: expeditions = next_expeditions.duplicate(true)
    if next_history is Array:
        society_history.clear()
        for entry in next_history:
            if entry is Dictionary: society_history.append(entry.duplicate(true))
    var visits: Variant = payload.get("settlement_visits", {})
    if visits is Dictionary: _settlement_visit_days = visits.duplicate(true)
    _shared_dirty = false
    _save_player_snapshot_only()
    for resident in get_tree().get_nodes_in_group("npc"):
        var resident_life: Dictionary = npc_lives.get(str(resident.get("npc_name")), {})
        if not resident_life.is_empty() and resident.has_method("apply_life_record"):
            resident.apply_life_record(resident_life)

func _save_player_snapshot_only() -> void:
    PlayerData.stats["living_businesses"] = businesses.duplicate(true)
    PlayerData.stats["family_bonds"] = family_bonds.duplicate(true)
    PlayerData.stats["npc_lives"] = npc_lives.duplicate(true)
    PlayerData.stats["npc_households"] = households.duplicate(true)
    PlayerData.stats["npc_expeditions"] = expeditions.duplicate(true)
    PlayerData.stats["npc_society_history"] = society_history.duplicate(true)
    PlayerData.stats["npc_settlement_visits"] = _settlement_visit_days.duplicate(true)
    PlayerData.stats["npc_world_day"] = _world_day

func _restore_shared_society() -> void:
    if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
        return
    if WorldDeploymentGuard.production_mode and MMORPGNetwork.is_authority() and CentralBackend.is_configured():
        var response: Dictionary = await CentralBackend.server_load_region_entities("elyndor")
        if bool(response.get("ok", false)):
            var data: Dictionary = response.get("body", {})
            var rows: Variant = data.get("entities", data.get("items", []))
            if rows is Array:
                for row in rows:
                    if not row is Dictionary: continue
                    if str(row.get("entity_id", "")) == SOCIETY_ENTITY_ID:
                        var state: Variant = row.get("entity_state", {})
                        if state is Dictionary: _apply_society_payload(state, true)
                        _backend_revision = int(row.get("revision", 0))
                        break
    else:
        var shared: Variant = MMORPGWorldState.get_world_value("societies", "npc_lifecycle", {})
        if shared is Dictionary and not shared.is_empty(): _apply_society_payload(shared)
    _catch_up_offline_days()
    _ensure_living_residents()

func _catch_up_offline_days() -> void:
    var now := int(Time.get_unix_time_from_system())
    if _last_world_timestamp <= 0:
        _last_world_timestamp = now
        return
    var elapsed := maxi(0, now - _last_world_timestamp)
    var days := clampi(int(floor(float(elapsed) / GAME_DAY_SECONDS)), 0, MAX_OFFLINE_DAYS)
    if days > 0:
        for _day in range(days):
            _world_day += 1
            _advance_households_one_day()
        _record_history("world_catchup", "The world continued without you", "%d days of settlement life passed while this world was unattended" % days, "elyndor")
    _last_world_timestamp = now
    _save_state()

func _persist_shared_society() -> void:
    if not _shared_dirty: return
    var payload := _society_payload()
    var save_serial := _shared_change_serial
    if WorldDeploymentGuard.production_mode:
        if not MMORPGNetwork.is_authority() or not CentralBackend.is_configured() or _backend_save_busy: return
        _backend_save_busy = true
        var result: Dictionary = await CentralBackend.server_save_world_entity(SOCIETY_ENTITY_ID, "npc_society", "elyndor", _backend_revision, payload)
        _backend_save_busy = false
        if bool(result.get("ok", false)):
            var saved_body: Dictionary = result.get("body", {})
            _backend_revision = int(saved_body.get("revision", _backend_revision + 1))
            _shared_dirty = _shared_change_serial != save_serial
        else:
            push_warning("[LivingWorldSystem] Shared society database save failed; changes remain queued for retry.")
    else:
        if MMORPGWorldState.set_world_value("societies", "npc_lifecycle", payload):
            _shared_dirty = _shared_change_serial != save_serial
    if MMORPGNetwork.is_online() and MMORPGNetwork.is_authority():
        rpc("apply_shared_society_snapshot", payload)

@rpc("authority", "call_remote", "reliable")
func apply_shared_society_snapshot(payload: Dictionary) -> void:
    if MMORPGNetwork.is_authority(): return
    _apply_society_payload(payload, true)

func get_business_stock(business_id: String) -> Dictionary:
    return businesses.get(business_id, {}).get("stock", {}).duplicate(true)

func business_id_for_owner(owner_name: String) -> String:
    for id in businesses:
        if str(businesses[id].get("owner", "")) == owner_name:
            return str(id)
    return ""

func mark_business_backend_provisioned(owner_name: String) -> void:
    var business_id := business_id_for_owner(owner_name)
    if business_id.is_empty(): return
    businesses[business_id]["backend_provisioned"] = true
    _save_state()

func get_business_record_for_owner(owner_name: String) -> Dictionary:
    var business_id := business_id_for_owner(owner_name)
    if business_id.is_empty(): return {}
    return businesses[business_id].duplicate(true)

func has_stock(business_id: String, item_id: String, quantity: int = 1) -> bool:
    if business_id == "": return true
    return int(get_business_stock(business_id).get(item_id, 0)) >= quantity

func get_price_multiplier(business_id: String) -> float:
    if business_id == "": return 1.0
    var stock: Dictionary = get_business_stock(business_id)
    var total := 0
    for key in stock: total += int(stock[key])
    if total <= 3: return 1.3
    if total >= 20: return 0.88
    return 1.0

func record_purchase(business_id: String, item_id: String, quantity: int = 1) -> bool:
    if not businesses.has(business_id) or quantity <= 0: return false
    var stock: Dictionary = businesses[business_id].get("stock", {})
    var available := int(stock.get(item_id, 0))
    if available < quantity:
        EventBus.toast.emit("That item is out of stock. Check back after the next caravan.", "warning")
        return false
    stock[item_id] = available - quantity
    businesses[business_id]["stock"] = stock
    _save_state(); business_changed.emit(business_id, stock)
    return true


func record_business_delivery(business_id: String, item_id: String, quantity: int) -> bool:
    if not businesses.has(business_id) or item_id.is_empty() or quantity <= 0:
        return false
    var stock: Dictionary = businesses[business_id].get("stock", {})
    stock[item_id] = int(stock.get(item_id, 0)) + quantity
    businesses[business_id]["stock"] = stock
    businesses[business_id]["last_delivery"] = {"item_id": item_id, "quantity": quantity, "time": Time.get_unix_time_from_system()}
    _save_state()
    business_changed.emit(business_id, stock)
    return true

func register_npc(npc_name: String, role: String, position: Vector3, is_child: bool = false) -> void:
    if npc_name.is_empty(): return
    var record: Dictionary = npc_lives.get(npc_name, {})
    if not record.is_empty() and not bool(record.get("alive", true)):
        return
    if record.is_empty():
        var region_id := WorldLifeSimulation.region_id_at(position.x, position.z)
        if region_id.is_empty(): region_id = "elyndor"
        record = {
            "name":npc_name, "role":role, "age_days":0 if is_child else 9125,
            "partner":"", "household":"", "alive":true, "children":[],
            "home":[position.x, position.y, position.z], "region_id":region_id,
            "adventurer_experience":0, "work_experience":0, "generated":false,
            "born_day":_world_day if is_child else _world_day - 9125,
            "profession_chosen":not is_child and role != "villager"
        }
    else:
        if str(record.get("role", "")) in ["", "villager"] and role != "child":
            record["role"] = role
            if role == "villager": record["profession_chosen"] = false
        var saved_home: Variant = record.get("home", [])
        if not saved_home is Array or saved_home.size() < 3:
            record["home"] = [position.x, position.y, position.z]
        if not record.has("region_id"):
            var region_id := WorldLifeSimulation.region_id_at(position.x, position.z)
            record["region_id"] = region_id if not region_id.is_empty() else "elyndor"
        record["age_days"] = maxi(0, int(record.get("age_days", 0)))
    record["last_seen_day"] = _world_day
    npc_lives[npc_name] = record
    _save_state()

func get_npc_life(npc_name: String) -> Dictionary:
    var record: Variant = npc_lives.get(npc_name, {})
    return record.duplicate(true) if record is Dictionary else {}

func get_world_day() -> int:
    return _world_day

func record_npc_casualty(npc_name: String, cause: String = "combat") -> void:
    if not npc_lives.has(npc_name): return
    var record: Dictionary = npc_lives[npc_name]
    if not bool(record.get("alive", true)): return
    record["alive"] = false
    record["death_day"] = _world_day
    record["death_cause"] = cause
    npc_lives[npc_name] = record
    _refresh_loaded_npc(npc_name, record)
    var partner_name := str(record.get("partner", ""))
    if not partner_name.is_empty() and npc_lives.has(partner_name):
        var surviving_partner: Dictionary = npc_lives[partner_name]
        if bool(surviving_partner.get("alive", true)):
            surviving_partner["partner"] = ""
            npc_lives[partner_name] = surviving_partner
            _record_history("widowhood", "%s is now alone" % partner_name, "%s lost their partner %s" % [partner_name, npc_name], str(surviving_partner.get("region_id", "elyndor")))
    _transfer_business_after_loss(npc_name)
    _record_history("death", "%s has died" % npc_name, "%s died during %s" % [npc_name, cause], str(record.get("region_id", "elyndor")))
    EventBus.activity.emit("%s has died during %s" % [npc_name, cause], "world")
    _save_state()

func _record_history(kind: String, title: String, detail: String, region_id: String) -> void:
    society_history.append({"day":_world_day, "kind":kind, "title":title, "detail":detail, "region_id":region_id})
    while society_history.size() > 80: society_history.pop_front()
    _shared_change_serial += 1
    _shared_dirty = true

func _transfer_business_after_loss(owner_name: String) -> void:
    for business_id in businesses.keys():
        var business: Dictionary = businesses[business_id]
        if str(business.get("owner", "")) != owner_name: continue
        var successor := ""
        var owner_life: Dictionary = npc_lives.get(owner_name, {})
        var household_id := str(owner_life.get("household", ""))
        if households.has(household_id):
            var family: Dictionary = households[household_id]
            var candidates: Array = family.get("members", []) + family.get("children", [])
            for candidate in candidates:
                var life: Dictionary = npc_lives.get(str(candidate), {})
                if str(candidate) != owner_name and bool(life.get("alive", true)) and int(life.get("age_days", 0)) >= ADULT_AGE_DAYS:
                    successor = str(candidate)
                    break
        if successor.is_empty():
            for candidate_name in npc_lives.keys():
                var life: Dictionary = npc_lives[candidate_name]
                if bool(life.get("alive", true)) and str(life.get("region_id", "elyndor")) == str(business.get("region_id", "elyndor")) and str(life.get("role", "")) in ["merchant", "smith", "craftsman"] and str(candidate_name) != owner_name:
                    successor = str(candidate_name)
                    break
        if not successor.is_empty():
            business["owner"] = successor
            business["inherited_day"] = _world_day
            business["closed"] = false
            businesses[business_id] = business
            var successor_life: Dictionary = npc_lives.get(successor, {})
            var specialty := str(business.get("specialty", ""))
            var new_role := "merchant" if specialty in ["provisions", "trade"] else ("smith" if specialty == "metalwork" else "craftsman")
            successor_life["role"] = new_role
            successor_life["profession_chosen"] = true
            npc_lives[successor] = successor_life
            _refresh_loaded_npc(successor, successor_life)
            _record_history("business_inheritance", "%s inherits %s" % [successor, str(business.get("name", business_id))], "%s takes over the business after %s's death" % [successor, owner_name], str(business.get("region_id", "elyndor")))
        else:
            business["closed"] = true
            business["closed_day"] = _world_day
            businesses[business_id] = business
            _record_history("business_closed", "%s closes" % str(business.get("name", business_id)), "No eligible successor remained to operate the business", str(business.get("region_id", "elyndor")))

func _update_world_day() -> void:
    if MMORPGNetwork.is_online() and not multiplayer.is_server(): return
    var day_node := get_tree().get_first_node_in_group("day_night")
    if day_node == null: return
    var phase := float(day_node.get("time_of_day"))
    if _last_day_phase >= 0.0 and phase < _last_day_phase - 0.5:
        _world_day += 1
        _advance_households_one_day()
    _last_day_phase = phase

func _simulate_npc_relationships() -> void:
    if MMORPGNetwork.is_online() and not multiplayer.is_server(): return
    var eligible: Array[String] = []
    for npc_name in npc_lives.keys():
        var life: Dictionary = npc_lives[npc_name]
        if not bool(life.get("alive", true)) or int(life.get("age_days", 0)) < ADULT_AGE_DAYS or not str(life.get("partner", "")).is_empty(): continue
        if str(life.get("role", "")) in ["child", "elder", "" ]: continue
        eligible.append(str(npc_name))
    var relationship_chance := minf(0.008, 0.0018 * float(eligible.size()) / 12.0)
    if eligible.size() < 2 or _rng.randf() > relationship_chance: return
    eligible.shuffle()
    for i in range(eligible.size()):
        var first_name := eligible[i]
        var first: Dictionary = npc_lives[first_name]
        var first_home: Array = first.get("home", [0.0, 0.0, 0.0])
        for j in range(i + 1, eligible.size()):
            var second_name := eligible[j]
            var second: Dictionary = npc_lives[second_name]
            var first_household := str(first.get("household", ""))
            if not first_household.is_empty() and first_household == str(second.get("household", "")): continue
            if str(first.get("region_id", "elyndor")) != str(second.get("region_id", "elyndor")): continue
            if int(second.get("age_days", 0)) >= RETIREMENT_AGE_DAYS: continue
            var second_home: Array = second.get("home", [0.0, 0.0, 0.0])
            if first_home.size() < 3 or second_home.size() < 3: continue
            var distance := Vector2(float(first_home[0]) - float(second_home[0]), float(first_home[2]) - float(second_home[2])).length()
            if distance <= 95.0:
                _form_npc_marriage(first_name, second_name)
                return

func _detach_npc_from_previous_household(npc_name: String) -> void:
    var previous_id := str(npc_lives.get(npc_name, {}).get("household", ""))
    if previous_id.is_empty() or not households.has(previous_id): return
    var previous: Dictionary = households[previous_id]
    var members: Array = previous.get("members", []).duplicate()
    var children: Array = previous.get("children", []).duplicate()
    members.erase(npc_name)
    children.erase(npc_name)
    previous["members"] = members
    previous["children"] = children
    var departed: Array = previous.get("departed_members", []).duplicate()
    if npc_name not in departed: departed.append(npc_name)
    previous["departed_members"] = departed
    households[previous_id] = previous

func _form_npc_marriage(first: String, second: String) -> void:
    if first == second or not npc_lives.has(first) or not npc_lives.has(second): return
    if not bool(npc_lives[first].get("alive", true)) or not bool(npc_lives[second].get("alive", true)): return
    if str(npc_lives[first].get("partner", "")) != "" or str(npc_lives[second].get("partner", "")) != "": return
    _detach_npc_from_previous_household(first)
    _detach_npc_from_previous_household(second)
    var household_id := "household_%s_%s" % [str(mini(first.hash(), second.hash())), str(maxi(first.hash(), second.hash()))]
    npc_lives[first]["partner"] = second
    npc_lives[second]["partner"] = first
    npc_lives[first]["household"] = household_id
    npc_lives[second]["household"] = household_id
    var home: Array = npc_lives[first].get("home", [0.0, 0.0, 0.0]).duplicate()
    var region_id := str(npc_lives[first].get("region_id", "elyndor"))
    households[household_id] = {"members":[first, second], "children":[], "formed_day":_world_day, "last_birth_day":_world_day, "home":home, "region_id":region_id}
    _record_history("marriage", "%s and %s form a household" % [first, second], "%s and %s have chosen to build a family together" % [first, second], region_id)
    _save_state()
    EventBus.activity.emit("%s and %s have chosen to marry" % [first, second], "world")

func _advance_households_one_day() -> void:
    for npc_name in npc_lives.keys():
        var life: Dictionary = npc_lives[npc_name]
        if not bool(life.get("alive", true)): continue
        var previous_age := int(life.get("age_days", 0))
        var age_days := previous_age + 1
        life["age_days"] = age_days
        if (previous_age < ADULT_AGE_DAYS and age_days >= ADULT_AGE_DAYS) or (age_days >= ADULT_AGE_DAYS and not bool(life.get("profession_chosen", false))):
            _choose_adult_profession(str(npc_name), life)
        elif age_days >= RETIREMENT_AGE_DAYS and str(life.get("role", "")) not in ["elder", "child"] and _rng.randf() < 0.0005:
            var old_role := str(life.get("role", "villager"))
            life["retired_profession"] = old_role
            life["role"] = "elder"
            _record_history("retirement", "%s retires as an elder" % str(npc_name), "%s steps back from %s duties" % [str(npc_name), old_role], str(life.get("region_id", "elyndor")))
            _refresh_loaded_npc(str(npc_name), life)
        if age_days >= 70 * 365:
            var risk := clampf(0.000015 + float(age_days - 70 * 365) / (365.0 * 100000.0), 0.000015, 0.00065)
            if _rng.randf() < risk:
                call_deferred("record_npc_casualty", str(npc_name), "old age")
        npc_lives[npc_name] = life
        if age_days < ADULT_AGE_DAYS and age_days % 90 == 0:
            _refresh_loaded_npc(str(npc_name), life)
    _simulate_npc_relationships()
    for household_id in households.keys():
        var home: Dictionary = households[household_id]
        var members: Array = home.get("members", [])
        if members.size() < 2: continue
        var eligible_parents := 0
        for member in members:
            var parent: Dictionary = npc_lives.get(str(member), {})
            if bool(parent.get("alive", false)) and int(parent.get("age_days", 0)) >= ADULT_AGE_DAYS and int(parent.get("age_days", 0)) <= 45 * 365:
                eligible_parents += 1
        if eligible_parents < 2: continue
        if _world_day - int(home.get("formed_day", _world_day)) < 365: continue
        if _world_day - int(home.get("last_birth_day", -10000)) < 3 * 365: continue
        if _rng.randf() > 0.0009: continue
        var children: Array = home.get("children", [])
        var child_number := children.size() + 1
        var child_name := "%s Child %d" % [str(members[0]), child_number]
        children.append(child_name)
        home["children"] = children
        home["last_birth_day"] = _world_day
        households[household_id] = home
        npc_lives[child_name] = {
            "name":child_name, "role":"child", "age_days":0, "partner":"", "household":household_id,
            "alive":true, "children":[], "home":home.get("home", [0.0,0.0,0.0]).duplicate(),
            "region_id":str(home.get("region_id", "elyndor")), "last_seen_day":_world_day,
            "born_day":_world_day, "generated":true, "profession_chosen":false
        }
        _record_history("birth", "%s is born" % child_name, "%s joins the %s household" % [child_name, household_id], str(home.get("region_id", "elyndor")))
        EventBus.activity.emit("A child has been born into the %s household" % household_id, "world")
    _advance_expeditions_one_day()
    if _world_day > 0 and _world_day % 365 == 0:
        _consider_household_migration()
        _schedule_expedition()
    _save_state()

func _choose_adult_profession(npc_name: String, life: Dictionary) -> void:
    var parent_role := ""
    var household_id := str(life.get("household", ""))
    if households.has(household_id):
        var members: Array = households[household_id].get("members", [])
        if not members.is_empty(): parent_role = str(npc_lives.get(str(members[0]), {}).get("role", ""))
    var options := ["farmer", "guard", "hunter", "merchant", "smith", "craftsman", "adventurer", "herbalist", "scholar", "fisher"]
    var weights := [0.16, 0.13, 0.15, 0.10, 0.10, 0.10, 0.12, 0.06, 0.04, 0.04]
    if parent_role in options:
        var parent_index := options.find(parent_role)
        weights[parent_index] += 0.10
    var total := 0.0
    for weight in weights: total += float(weight)
    var roll := _rng.randf() * total
    var chosen := "farmer"
    for i in range(options.size()):
        roll -= float(weights[i])
        if roll <= 0.0:
            chosen = str(options[i])
            break
    life["role"] = chosen
    life["profession_chosen"] = true
    life["profession_day"] = _world_day
    life["work_experience"] = float(life.get("work_experience", 0.0)) + 1.0
    life["generated"] = bool(life.get("generated", false))
    var region_id := str(life.get("region_id", "elyndor"))
    npc_lives[npc_name] = life
    _ensure_profession_business(npc_name, chosen, region_id)
    _record_history("profession", "%s becomes a %s" % [npc_name, chosen], "%s reaches adulthood and chooses a life as a %s" % [npc_name, chosen], region_id)
    _refresh_loaded_npc(npc_name, life)
    EventBus.activity.emit("%s has grown up and become a %s" % [npc_name, chosen], "world")

func _ensure_profession_business(npc_name: String, profession: String, region_id: String) -> void:
    if profession not in ["merchant", "smith", "craftsman"]: return
    if not business_id_for_owner(npc_name).is_empty(): return
    var suffix := str(absi(npc_name.hash())).pad_zeros(6)
    var business_id := "resident_%s" % suffix
    var title := "%s's %s" % [npc_name, "Market Stall" if profession == "merchant" else "Workshop"]
    businesses[business_id] = {"name":title, "owner":npc_name, "region_id":region_id, "specialty":"trade" if profession == "merchant" else "craft", "stock":{"wood_log":2,"iron_ingot":1,"healing_potion":1}, "opened_day":_world_day, "closed":false}
    _record_history("business_opened", "%s opens %s" % [npc_name, title], "%s establishes a new local business" % npc_name, region_id)

func _refresh_loaded_npc(npc_name: String, life: Dictionary) -> void:
    for resident in get_tree().get_nodes_in_group("npc"):
        if str(resident.get("npc_name")) == npc_name and resident.has_method("apply_life_record"):
            resident.apply_life_record(life)
            break

func _schedule_expedition() -> void:
    if _rng.randf() > 0.38: return
    var candidates: Array[String] = []
    for npc_name in npc_lives.keys():
        var life: Dictionary = npc_lives[npc_name]
        if not bool(life.get("alive", true)) or int(life.get("age_days", 0)) < ADULT_AGE_DAYS: continue
        if str(life.get("role", "")) not in ["adventurer", "hunter", "ranger", "guard", "soldier"]: continue
        if not str(life.get("expedition_id", "")).is_empty(): continue
        candidates.append(str(npc_name))
    if candidates.is_empty(): return
    candidates.shuffle()
    var origin_region := str(npc_lives[candidates[0]].get("region_id", "elyndor"))
    var regional_candidates: Array[String] = []
    for candidate in candidates:
        if str(npc_lives[candidate].get("region_id", "elyndor")) == origin_region:
            regional_candidates.append(candidate)
    candidates = regional_candidates
    var party_size := mini(candidates.size(), _rng.randi_range(1, 3))
    var party: Array[String] = []
    for i in range(party_size): party.append(candidates[i])
    var neighbors: Array[String] = WorldLifeSimulation.get_region_neighbors(origin_region)
    var destination := origin_region if neighbors.is_empty() else neighbors[_rng.randi_range(0, neighbors.size() - 1)]
    var expedition_id := "exp_%d_%d" % [_world_day, absi(_rng.randi())]
    var duration := _rng.randi_range(4, 12)
    var expedition := {"id":expedition_id, "party":party, "origin":origin_region, "destination":destination, "depart_day":_world_day, "return_day":_world_day + duration, "danger":_rng.randf_range(0.18, 0.72), "status":"travelling"}
    expeditions[expedition_id] = expedition
    for member in party:
        npc_lives[member]["expedition_id"] = expedition_id
        npc_lives[member]["location_state"] = "on_expedition"
        npc_lives[member]["mobile"] = true
        var target: Vector3 = WorldLifeSimulation.get_safe_region_location(destination)
        if target == Vector3.ZERO:
            target = WorldLifeSimulation.get_region_center(destination)
        for resident in get_tree().get_nodes_in_group("npc"):
            if str(resident.get("npc_name")) == member and resident.has_method("begin_expedition_journey"):
                resident.begin_expedition_journey(target)
                break
    _record_history("expedition_departure", "An expedition leaves for %s" % destination, "%s set out from %s towards %s" % [", ".join(party), origin_region, destination], origin_region)
    EventBus.activity.emit("%s have departed on an expedition to %s" % [", ".join(party), destination], "world")

func _advance_expeditions_one_day() -> void:
    for expedition_id in expeditions.keys():
        var expedition: Dictionary = expeditions[expedition_id]
        if int(expedition.get("return_day", 0)) > _world_day: continue
        var party: Array = expedition.get("party", [])
        var destination := str(expedition.get("destination", "unknown"))
        var danger := float(expedition.get("danger", 0.4))
        var alive_count := 0
        var experience_total := 0.0
        for member in party:
            var life: Dictionary = npc_lives.get(str(member), {})
            if bool(life.get("alive", false)):
                alive_count += 1
                experience_total += float(life.get("adventurer_experience", 0.0)) + float(life.get("work_experience", 0.0))
        var success_chance := clampf(0.48 + float(alive_count) * 0.08 + experience_total * 0.012 - danger * 0.48, 0.12, 0.94)
        var success := _rng.randf() < success_chance
        var deaths: Array[String] = []
        for member in party:
            var life: Dictionary = npc_lives.get(str(member), {})
            if not bool(life.get("alive", false)): continue
            var death_chance := danger * (0.23 if not success else 0.035)
            if _rng.randf() < death_chance:
                deaths.append(str(member))
            else:
                life["adventurer_experience"] = float(life.get("adventurer_experience", 0.0)) + (2.0 if success else 0.6)
                life["expedition_id"] = ""
                life["location_state"] = "home"
                life["region_id"] = str(expedition.get("origin", "elyndor"))
                life["mobile"] = true
                npc_lives[str(member)] = life
                var home: Array = life.get("home", [0.0, 0.0, 0.0])
                if home.size() >= 3:
                    var home_pos := Vector3(float(home[0]), float(home[1]), float(home[2]))
                    for resident in get_tree().get_nodes_in_group("npc"):
                        if str(resident.get("npc_name")) == str(member) and resident.has_method("return_from_expedition_journey"):
                            resident.return_from_expedition_journey(home_pos)
                            break
        for dead_member in deaths:
            record_npc_casualty(dead_member, "expedition in %s" % destination)
        if success:
            var region_resource := "ore" if destination in ["ironback", "emberfall", "cinderwake"] else ("herbs" if destination in ["amberleaf", "whispering_woods", "greenveil"] else "food")
            WorldLifeSimulation.record_local_production(destination, region_resource, float(maxi(1, alive_count)) * _rng.randf_range(0.8, 2.2))
        var summary := "The expedition to %s returned successfully" % destination if success else "The expedition to %s suffered a defeat" % destination
        if not deaths.is_empty(): summary += "; %s were lost" % ", ".join(deaths)
        _record_history("expedition_return", summary, summary, str(expedition.get("origin", "elyndor")))
        EventBus.activity.emit(summary, "world")
        expeditions.erase(expedition_id)

func _consider_household_migration() -> void:
    for household_id in households.keys():
        if _rng.randf() > 0.05: continue
        var household: Dictionary = households[household_id]
        var current_region := str(household.get("region_id", "elyndor"))
        var household_members: Array = household.get("members", []) + household.get("children", [])
        var travelling_member := false
        for member in household_members:
            var member_life: Dictionary = npc_lives.get(str(member), {})
            if not str(member_life.get("expedition_id", "")).is_empty():
                travelling_member = true
                break
        if travelling_member: continue
        var neighbors: Array[String] = WorldLifeSimulation.get_region_neighbors(current_region)
        if neighbors.is_empty(): continue
        var destination := neighbors[_rng.randi_range(0, neighbors.size() - 1)]
        var center: Vector3 = WorldLifeSimulation.get_safe_region_location(destination)
        if center == Vector3.ZERO: continue
        var members: Array = household_members
        for member in members:
            if not npc_lives.has(str(member)) or not bool(npc_lives[str(member)].get("alive", true)): continue
            var life: Dictionary = npc_lives[str(member)]
            life["region_id"] = destination
            life["home"] = [center.x, center.y, center.z]
            life["location_state"] = "migrating"
            life["mobile"] = true
            npc_lives[str(member)] = life
            for resident in get_tree().get_nodes_in_group("npc"):
                if str(resident.get("npc_name")) == str(member) and resident.has_method("begin_expedition_journey"):
                    resident.begin_migration_journey(center)
                    break
        household["region_id"] = destination
        household["home"] = [center.x, center.y, center.z]
        household["migrated_day"] = _world_day
        households[household_id] = household
        for business_id in businesses.keys():
            var business: Dictionary = businesses[business_id]
            if str(business.get("owner", "")) in members and str(business.get("region_id", current_region)) == current_region:
                business["region_id"] = destination
                business["relocated_day"] = _world_day
                businesses[business_id] = business
                _record_history("business_relocated", "%s moves with its family" % str(business.get("name", business_id)), "The business relocates from %s to %s with its owner" % [current_region, destination], destination)
        _record_history("migration", "%s migrates to %s" % [household_id, destination], "The household leaves %s and settles in %s" % [current_region, destination], destination)
        EventBus.activity.emit("A family has left %s for %s" % [current_region, destination], "world")
        break

func _ensure_living_residents() -> void:
    if MMORPGNetwork.is_online() and not multiplayer.is_server(): return
    var scene := get_tree().current_scene
    var player: Node3D = GameManager.player
    if scene == null or player == null: return
    var existing_names: Dictionary = {}
    for existing in get_tree().get_nodes_in_group("npc"):
        existing_names[str(existing.get("npc_name"))] = true
    var spawned := 0
    for name_variant in npc_lives.keys():
        var name := str(name_variant)
        var record: Dictionary = npc_lives[name]
        if not bool(record.get("alive", true)): continue
        if not bool(record.get("generated", false)) and not bool(record.get("mobile", false)) and str(record.get("role", "")) != "child": continue
        if str(record.get("location_state", "home")) == "on_expedition": continue
        if existing_names.has(name): continue
        var home: Array = record.get("home", [0.0, 0.0, 0.0])
        if home.size() < 3: continue
        var home_position := Vector3(float(home[0]), float(home[1]), float(home[2]))
        if player.global_position.distance_to(home_position) > 220.0: continue
        var resident := NPC_SCENE.instantiate() as NPC
        resident.npc_name = name
        resident.role = str(record.get("role", "villager"))
        resident.set_meta("generated_life_record", true)
        resident.position = home_position + Vector3(_rng.randf_range(-2.5, 2.5), 0.0, _rng.randf_range(-2.5, 2.5))
        scene.add_child(resident)
        existing_names[name] = true
        spawned += 1
        if MMORPGNetwork.is_online() and multiplayer.is_server():
            resident.set_meta("mmo_world_entity_id", "world-npc-%08X" % absi(name.hash()))
            MMORPGNetwork.broadcast_world_npc_spawn(resident)
        if spawned >= 18: break

func _ensure_child_residents() -> void:
    _ensure_living_residents()

func _check_player_settlement_visit() -> void:
    var player: Node3D = GameManager.player
    if player == null: return
    var region_id := WorldLifeSimulation.region_id_at(player.global_position.x, player.global_position.z)
    if region_id == "": return
    if region_id != _last_player_region:
        _last_player_region = region_id
        var last_visit := int(_settlement_visit_days.get(region_id, -1))
        if last_visit >= 0 and _world_day - last_visit >= 30:
            var events: Array[Dictionary] = get_recent_settlement_history(region_id, last_visit)
            var report := get_settlement_report(region_id)
            var elapsed := _world_day - last_visit
            EventBus.activity.emit("%s has changed during your absence (%d world days). Population: %d; defenders: %d; families: %d; businesses: %d; expeditions away: %d." % [str(report.get("name", region_id)), elapsed, int(report.get("population", 0)), int(report.get("defenders", 0)), int(report.get("families", 0)), int(report.get("businesses", 0)), int(report.get("active_expeditions", 0))], "world")
            for i in range(mini(3, events.size())):
                EventBus.activity.emit(str(events[i].get("title", "Settlement changed")), "world")
            EventBus.toast.emit("The settlement has changed while you were away", "info")
        _settlement_visit_days[region_id] = _world_day
        _save_state()

func complete_npc_migration(npc_name: String) -> void:
    if not npc_lives.has(npc_name): return
    var life: Dictionary = npc_lives[npc_name]
    life["location_state"] = "home"
    var position: Vector3 = Vector3.ZERO
    for resident in get_tree().get_nodes_in_group("npc"):
        if str(resident.get("npc_name")) == npc_name and resident is Node3D:
            position = (resident as Node3D).global_position
            break
    life["home"] = [position.x, position.y, position.z]
    npc_lives[npc_name] = life
    _save_state()

func get_settlement_report(region_id: String) -> Dictionary:
    var role_counts: Dictionary = {}
    var population := 0
    var defenders := 0
    var family_count := 0
    var active_expeditions := 0
    for npc_name in npc_lives.keys():
        var life: Dictionary = npc_lives[npc_name]
        if not bool(life.get("alive", true)) or str(life.get("region_id", "elyndor")) != region_id: continue
        if str(life.get("location_state", "home")) == "on_expedition": continue
        population += 1
        var role := str(life.get("role", "villager"))
        role_counts[role] = int(role_counts.get(role, 0)) + 1
        if role in DEFENCE_ROLES: defenders += 1
    for expedition_id in expeditions.keys():
        if str(expeditions[expedition_id].get("origin", "elyndor")) == region_id:
            active_expeditions += 1
    for household_id in households.keys():
        var household: Dictionary = households[household_id]
        if str(household.get("region_id", "elyndor")) != region_id: continue
        var living_members := 0
        for member in household.get("members", []) + household.get("children", []):
            if bool(npc_lives.get(str(member), {}).get("alive", false)):
                living_members += 1
        if living_members > 0: family_count += 1
    var business_count := 0
    for business_id in businesses.keys():
        if str(businesses[business_id].get("region_id", "elyndor")) == region_id and not bool(businesses[business_id].get("closed", false)): business_count += 1
    return {"id":region_id, "name":"Elyndor" if region_id == "elyndor" else region_id.replace("_", " ").capitalize(), "population":population, "defenders":defenders, "families":family_count, "businesses":business_count, "active_expeditions":active_expeditions, "professions":role_counts}

func get_recent_settlement_history(region_id: String, after_day: int = -1) -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for entry in society_history:
        if str(entry.get("region_id", "elyndor")) == region_id and int(entry.get("day", 0)) > after_day:
            result.append(entry.duplicate(true))
    result.reverse()
    return result

func get_family_bond(family_id: String) -> int:
    return int(family_bonds.get(family_id, 0))

func change_family_bond(family_id: String, amount: int) -> void:
    family_bonds[family_id] = clampi(get_family_bond(family_id) + amount, -100, 100)
    _save_state(); family_bond_changed.emit(family_id, get_family_bond(family_id))

func relationship_line(family_id: String) -> String:
    var bond := get_family_bond(family_id)
    if bond >= 40: return "Your household is regarded as a trusted friend of this family."
    if bond <= -25: return "This household remembers your past disagreement and remains guarded."
    return "The family knows your name, but trust is still being earned."

func help_family(family_id: String) -> void:
    change_family_bond(family_id, 5)
    EventBus.toast.emit("The %s household appreciates your help" % family_id, "success")

func restock_business(business_id: String, amount: int = 1) -> bool:
    if not businesses.has(business_id) or amount <= 0:
        return false
    if WorldDeploymentGuard.production_mode and MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
        return false
    var stock: Dictionary = businesses[business_id].get("stock", {}).duplicate(true)
    for item_id in stock.keys():
        stock[item_id] = mini(30, int(stock[item_id]) + amount)
    businesses[business_id]["stock"] = stock
    _save_state()
    business_changed.emit(business_id, stock)
    return true

func _restock_businesses() -> void:
    if WorldDeploymentGuard.production_mode and MMORPGNetwork.is_online():
        if MMORPGNetwork.is_authority():
            MMORPGNetwork.restock_shared_merchants()
        return
    for id in businesses:
        if bool(businesses[id].get("closed", false)): continue
        var stock: Dictionary = businesses[id].get("stock", {})
        for item_id in stock:
            stock[item_id] = mini(30, int(stock[item_id]) + _rng.randi_range(1, 3))
        businesses[id]["stock"] = stock
        business_changed.emit(str(id), stock)
    _save_state()

func _start_world_event() -> void:
    if get_tree().current_scene == null: return
    _clear_event()
    var event: Dictionary = EVENTS[_rng.randi_range(0, EVENTS.size()-1)].duplicate(true)
    _active_event = event
    _event_remaining = 95.0
    _spawn_event_dressing(event)
    world_event_started.emit(str(event.id), str(event.title))
    EventBus.activity.emit("WORLD EVENT: %s" % event.title, "world")
    EventBus.toast.emit("%s — look for the gathering in Elyndor" % event.title, "info")
    if str(event.id) == "caravan_arrival":
        _restock_businesses()
    elif str(event.id) == "relief_convoy":
        var growth := get_tree().get_first_node_in_group("settlement_growth")
        if growth and growth.has_method("add_progress"): growth.add_progress("elyndor", 10.0, "relief convoy")

func _spawn_event_dressing(event: Dictionary) -> void:
    var scene := get_tree().current_scene
    if scene == null: return
    _event_root = Node3D.new()
    _event_root.name = "VisibleWorldEvent_" + str(event.id)
    _event_root.set_script(preload("res://entities/world_event_visual.gd"))
    scene.add_child(_event_root)
    var center: Vector2 = TerrainNoise.VILLAGE_CENTER
    var noise := TerrainNoise.new(GameManager.world_seed)
    var ground := noise.get_height(center.x + 17.0, center.y + 8.0)
    _event_root.global_position = Vector3(center.x + 17.0, ground, center.y + 8.0)
    var accent := StandardMaterial3D.new()
    accent.albedo_color = event.color
    accent.metallic = 0.22; accent.roughness = 0.48
    var pole := MeshInstance3D.new(); var pole_mesh := CylinderMesh.new(); pole_mesh.top_radius = 0.045; pole_mesh.bottom_radius = 0.07; pole_mesh.height = 4.2; pole.mesh = pole_mesh
    var wood := StandardMaterial3D.new(); wood.albedo_color = Color(0.24,0.15,0.09); pole.material_override = wood; pole.position.y = 2.1; _event_root.add_child(pole)
    var banner := MeshInstance3D.new(); banner.name = "Banner"; var banner_mesh := BoxMesh.new(); banner_mesh.size = Vector3(1.25,0.85,0.06); banner.mesh = banner_mesh; banner.material_override = accent; banner.position = Vector3(0.62,3.25,0); _event_root.add_child(banner)
    var sign := Label3D.new(); sign.text = str(event.title).to_upper(); sign.font_size = 30; sign.outline_size = 8; sign.position = Vector3(0,4.55,0); sign.modulate = event.color; sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED; _event_root.add_child(sign)
    for i in range(3):
        var crate := MeshInstance3D.new(); var cm := BoxMesh.new(); cm.size = Vector3(0.9,0.75,0.8); crate.mesh = cm; crate.material_override = wood; crate.position = Vector3(-1.6 + float(i)*1.0,0.38,1.0); _event_root.add_child(crate)
    var light := OmniLight3D.new(); light.name = "EventLight"; light.light_color = event.color; light.light_energy = 1.2; light.omni_range = 8.0; light.position = Vector3(0,2.0,1.7); _event_root.add_child(light)
    var npc_scene: PackedScene = load("res://scenes/npc.tscn")
    if npc_scene:
        var count := int(event.get("guards", 1)) + 1
        for i in range(count):
            var npc := npc_scene.instantiate() as NPC
            if npc == null: continue
            npc.npc_name = ("Caravan Guard " if i < int(event.get("guards",1)) else "Travelling Merchant ") + str(i+1)
            npc.role = "guard" if i < int(event.get("guards",1)) else "merchant"
            npc.free_will = true
            npc.position = Vector3(-2.0 + float(i)*1.45, 0.0, 2.4 + float(i%2)*1.0)
            npc.home_center = _event_root.global_position + npc.position
            npc.wander_radius = 3.5
            npc.set_meta("transient_npc", true)
            _event_root.add_child(npc)

func _clear_event() -> void:
    if is_instance_valid(_event_root): _event_root.queue_free()
    _event_root = null
    _active_event.clear()

func get_active_event() -> Dictionary:
    return _active_event.duplicate(true)
