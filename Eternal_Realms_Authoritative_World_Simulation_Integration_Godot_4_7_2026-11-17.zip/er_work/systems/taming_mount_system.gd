# Companion bonds, mount progression and tack. Companion records are persisted in PlayerData.stats.
extends Node

signal companion_changed(creature_id: String, mounted: bool)
signal bond_changed(creature_id: String, bond: int)

var companions: Array[Dictionary] = []
var active_companion: Dictionary = {}
var mounted: bool = false
var mount_visual: Node3D
var _mount_anim_time := 0.0
var _mount_legs: Array[Node3D] = []
var _mount_body: Node3D

const SPECIES := {
	"rabbit": {"name": "Meadow Hare", "food": "fish_mackerel", "chance": 0.72, "speed": 1.12, "color": Color(0.58, 0.39, 0.23)},
	"chicken": {"name": "Field Runner", "food": "fish_mackerel", "chance": 0.85, "speed": 1.05, "color": Color(0.88, 0.82, 0.68)},
	"deer": {"name": "Grove Stag", "food": "fish_mackerel", "chance": 0.48, "speed": 1.55, "color": Color(0.52, 0.32, 0.17)},
	"wolf": {"name": "Frostfang Wolf", "food": "fish_mackerel", "chance": 0.42, "speed": 1.62, "color": Color(0.38, 0.43, 0.49)},
	"boar": {"name": "Ironhide Boar", "food": "fish_mackerel", "chance": 0.55, "speed": 1.35, "color": Color(0.34, 0.22, 0.16)}
}

func _ready() -> void:
	add_to_group("taming_mount_system")
	var saved: Variant = PlayerData.stats.get("companions", [])
	if saved is Array:
		for entry in saved:
			if entry is Dictionary:
				companions.append(entry.duplicate(true))
	if not companions.is_empty():
		var active_id := str(PlayerData.stats.get("active_companion_id", ""))
		active_companion = companions[0].duplicate(true)
		for entry in companions:
			if str(entry.get("id", "")) == active_id:
				active_companion = entry.duplicate(true)
				break

func refresh_from_player_data() -> void:
	companions.clear()
	var saved: Variant = PlayerData.stats.get("companions", [])
	if saved is Array:
		for entry in saved:
			if entry is Dictionary:
				companions.append(entry.duplicate(true))
	active_companion.clear()
	if companions.is_empty():
		return
	var active_id := str(PlayerData.stats.get("active_companion_id", ""))
	active_companion = companions[0].duplicate(true)
	for entry in companions:
		if str(entry.get("id", "")) == active_id:
			active_companion = entry.duplicate(true)
			break

func _process(delta: float) -> void:
	if not mounted or not is_instance_valid(mount_visual):
		return
	var player := get_tree().get_first_node_in_group("player") as CharacterBody3D
	if player == null:
		return
	_mount_anim_time += delta * (5.0 if player.velocity.length() > 0.35 else 1.7)
	var target := player.global_position - player.global_transform.basis.z * 1.15 + Vector3.UP * 0.02
	mount_visual.global_position = mount_visual.global_position.lerp(target, clampf(delta * 8.0, 0.0, 1.0))
	mount_visual.global_rotation.y = lerp_angle(mount_visual.global_rotation.y, player.global_rotation.y, delta * 6.0)
	if is_instance_valid(_mount_body): _mount_body.position.y = 0.7 + sin(_mount_anim_time * 2.0) * (0.025 if player.velocity.length() < 0.35 else 0.075)
	for i in range(_mount_legs.size()):
		if is_instance_valid(_mount_legs[i]): _mount_legs[i].rotation.x = sin(_mount_anim_time + float(i % 2) * PI) * (0.08 if player.velocity.length() < 0.35 else 0.52)

func handle_mount_input(player: Node3D) -> void:
	if mounted:
		toggle_mount(player)
		return
	var nearby_tameable := false
	for node in get_tree().get_nodes_in_group("critter"):
		var creature := node as Node3D
		if creature == null or not is_instance_valid(creature):
			continue
		if player.global_position.distance_to(creature.global_position) <= 5.0 and SPECIES.has(str(creature.get("kind"))):
			nearby_tameable = true
			break
	if nearby_tameable:
		tame_nearest(player)
	elif not active_companion.is_empty():
		toggle_mount(player)
	else:
		EventBus.toast.emit("Approach a wild animal to tame your first companion", "info")

func tame_nearest(player: Node3D) -> void:
	var best: Node3D = null
	var best_dist := 5.0
	for node in get_tree().get_nodes_in_group("critter"):
		var creature := node as Node3D
		if creature == null or not is_instance_valid(creature):
			continue
		var distance := player.global_position.distance_to(creature.global_position)
		if distance < best_dist:
			best = creature
			best_dist = distance
	if best == null:
		EventBus.toast.emit("Approach a wild animal within five metres", "info")
		return
	var kind := str(best.get("kind"))
	if not SPECIES.has(kind):
		EventBus.toast.emit("This creature cannot be tamed", "warning")
		return
	var spec: Dictionary = SPECIES[kind]
	if not PlayerData.remove_item(str(spec.get("food", "fish_mackerel")), 1):
		EventBus.toast.emit("Taming requires a Mackerel offering", "warning")
		return
	if randf() > float(spec.get("chance", 0.0)):
		EventBus.toast.emit("The animal backs away. Approach slowly and try again", "info")
		return
	var entry := {
		"id": "%s_%d" % [kind, Time.get_ticks_msec()],
		"kind": kind,
		"name": str(spec.get("name", "Companion")),
		"bond": 1,
		"level": 1,
		"saddle": false,
		"armor": false
	}
	companions.append(entry)
	active_companion = entry.duplicate(true)
	_save_companions()
	best.queue_free()
	EventBus.toast.emit("%s is bonded with you! Press F to summon or mount" % spec.get("name", "Companion"), "success")
	EventBus.activity.emit("Tamed %s" % spec.get("name", "Companion"), "world")
	companion_changed.emit(str(entry.get("id", "")), false)

func toggle_mount(player: Node3D) -> void:
	if active_companion.is_empty():
		EventBus.toast.emit("Tame a wild animal first", "info")
		return
	mounted = not mounted
	if mounted:
		_spawn_mount_visual(player)
		EventBus.toast.emit("Mounted %s — F to dismount" % str(active_companion.get("name", "Companion")), "success")
	else:
		if is_instance_valid(mount_visual):
			mount_visual.queue_free()
		mount_visual = null
		EventBus.toast.emit("Dismounted", "info")
	companion_changed.emit(str(active_companion.get("id", "")), mounted)

func select_next_companion() -> void:
	if companions.is_empty():
		EventBus.toast.emit("Your stable is empty", "info")
		return
	var current_id := str(active_companion.get("id", ""))
	var current_index := 0
	for i in range(companions.size()):
		if str(companions[i].get("id", "")) == current_id:
			current_index = i
			break
	active_companion = companions[(current_index + 1) % companions.size()].duplicate(true)
	_save_companions()
	if mounted:
		var player := get_tree().get_first_node_in_group("player") as Node3D
		if player != null: _spawn_mount_visual(player)
	EventBus.toast.emit("Active companion: %s" % str(active_companion.get("name", "Companion")), "info")

func breed_active() -> void:
	if companions.size() >= 8:
		EventBus.toast.emit("Your stable is full. Release a companion before breeding again.", "warning")
		return
	if active_companion.is_empty():
		EventBus.toast.emit("You need an active companion first", "info")
		return
	var partner: Dictionary = {}
	for entry in companions:
		if str(entry.get("id", "")) == str(active_companion.get("id", "")): continue
		if str(entry.get("kind", "")) == str(active_companion.get("kind", "")) and int(entry.get("bond", 0)) >= 35:
			partner = entry
			break
	if partner.is_empty():
		EventBus.toast.emit("You need a second same-species companion with bond 35 or higher", "info")
		return
	if int(active_companion.get("bond", 0)) < 35:
		EventBus.toast.emit("Your active companion needs bond 35 before breeding", "info")
		return
	if not PlayerData.remove_item("fish_mackerel", 3):
		EventBus.toast.emit("Breeding care requires 3 Mackerel", "warning")
		return
	var kind := str(active_companion.get("kind", "rabbit"))
	var spec: Dictionary = SPECIES.get(kind, SPECIES["rabbit"])
	var offspring := {"id":"%s_%d" % [kind, Time.get_ticks_msec()], "kind":kind, "name":str(spec.get("name", "Companion")) + " Calf", "bond":5, "level":1, "saddle":false, "armor":false, "offspring":true}
	companions.append(offspring)
	_save_companions()
	EventBus.toast.emit("A new %s has joined your stable!" % offspring.get("name", "Companion"), "success")
	EventBus.activity.emit("Bred companion: %s" % offspring.get("name", "Companion"), "world")

func care_active() -> void:
	if active_companion.is_empty():
		EventBus.toast.emit("You have no companion to care for", "info")
		return
	if not PlayerData.remove_item("fish_mackerel", 1):
		EventBus.toast.emit("Care requires a Mackerel treat", "warning")
		return
	active_companion["bond"] = mini(100, int(active_companion.get("bond", 1)) + 8)
	if int(active_companion.get("bond", 1)) >= 20:
		active_companion["level"] = maxi(2, int(active_companion.get("level", 1)))
	if int(active_companion.get("bond", 1)) >= 60:
		active_companion["level"] = maxi(3, int(active_companion.get("level", 1)))
	_write_active()
	bond_changed.emit(str(active_companion.get("id", "")), int(active_companion.get("bond", 1)))
	EventBus.toast.emit("Bond with %s increased to %d" % [active_companion.get("name", "companion"), active_companion.get("bond", 1)], "success")

func equip_tack(kind: String) -> void:
	if active_companion.is_empty():
		EventBus.toast.emit("Tame a mount first", "info")
		return
	if kind == "saddle":
		if bool(active_companion.get("saddle", false)):
			EventBus.toast.emit("Your mount already has a saddle", "info")
			return
		if not PlayerData.remove_item("leather_strip", 2):
			EventBus.toast.emit("A saddle requires 2 Leather Strips", "warning")
			return
		active_companion["saddle"] = true
	elif kind == "armor":
		if bool(active_companion.get("armor", false)):
			EventBus.toast.emit("Your mount already has barding", "info")
			return
		if not PlayerData.remove_item("iron_ingot", 3):
			EventBus.toast.emit("Mount barding requires 3 Iron Ingots", "warning")
			return
		active_companion["armor"] = true
	else:
		return
	_write_active()
	if mounted:
		var player := get_tree().get_first_node_in_group("player") as CharacterBody3D
		if player != null:
			_spawn_mount_visual(player)
	EventBus.toast.emit("Mount %s equipped" % kind, "success")

func movement_multiplier() -> float:
	if not mounted or active_companion.is_empty():
		return 1.0
	var spec: Dictionary = SPECIES.get(str(active_companion.get("kind", "rabbit")), SPECIES["rabbit"])
	var level_bonus := 1.0 + float(int(active_companion.get("level", 1)) - 1) * 0.06
	var bond_bonus := 1.0 + float(int(active_companion.get("bond", 1))) / 500.0
	var saddle_bonus := 1.12 if bool(active_companion.get("saddle", false)) else 1.0
	return float(spec.speed) * level_bonus * bond_bonus * saddle_bonus

func _write_active() -> void:
	for i in range(companions.size()):
		if str(companions[i].get("id", "")) == str(active_companion.get("id", "")):
			companions[i] = active_companion.duplicate(true)
	_save_companions()

func _save_companions() -> void:
	PlayerData.stats["companions"] = companions.duplicate(true)
	PlayerData.stats["active_companion_id"] = str(active_companion.get("id", ""))

func _spawn_mount_visual(player: Node3D) -> void:
	if is_instance_valid(mount_visual):
		mount_visual.queue_free()
	mount_visual = Node3D.new()
	mount_visual.name = "CompanionMountVisual"
	_mount_legs.clear()
	_mount_body = null
	var spec: Dictionary = SPECIES.get(str(active_companion.get("kind", "rabbit")), SPECIES["rabbit"])
	var material := StandardMaterial3D.new()
	material.albedo_color = spec.color
	material.roughness = 0.86
	var body := MeshInstance3D.new()
	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.43
	body_mesh.height = 1.45
	body.mesh = body_mesh
	body.material_override = material
	body.rotation.x = PI * 0.5
	body.position.y = 0.7
	_mount_body = body
	mount_visual.add_child(body)
	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.27
	head_mesh.height = 0.54
	head.mesh = head_mesh
	head.material_override = material
	head.position = Vector3(0, 1.0, -0.52)
	mount_visual.add_child(head)
	for side in [-1.0, 1.0]:
		for fore_aft in [0.28, -0.28]:
			var leg := MeshInstance3D.new()
			var leg_mesh := CylinderMesh.new()
			leg_mesh.top_radius = 0.07
			leg_mesh.bottom_radius = 0.09
			leg_mesh.height = 0.62
			leg.mesh = leg_mesh
			leg.material_override = material
			leg.position = Vector3(side * 0.23, 0.3, fore_aft)
			mount_visual.add_child(leg)
			_mount_legs.append(leg)
	if bool(active_companion.get("armor", false)):
		var plates := MeshInstance3D.new()
		var plate_mesh := BoxMesh.new()
		plate_mesh.size = Vector3(0.76, 0.22, 0.78)
		plates.mesh = plate_mesh
		var steel := StandardMaterial3D.new()
		steel.albedo_color = Color(0.38, 0.43, 0.49)
		steel.metallic = 0.72
		steel.roughness = 0.38
		plates.material_override = steel
		plates.position = Vector3(0, 0.82, 0.02)
		mount_visual.add_child(plates)
	if bool(active_companion.get("saddle", false)):
		var saddle := MeshInstance3D.new()
		var saddle_mesh := BoxMesh.new()
		saddle_mesh.size = Vector3(0.62, 0.12, 0.55)
		saddle.mesh = saddle_mesh
		var leather := StandardMaterial3D.new()
		leather.albedo_color = Color(0.18, 0.08, 0.035)
		saddle.material_override = leather
		saddle.position = Vector3(0, 1.1, 0.02)
		mount_visual.add_child(saddle)
	player.get_parent().add_child(mount_visual)
	mount_visual.global_position = player.global_position - player.global_transform.basis.z * 1.15
