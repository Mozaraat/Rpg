# Boss & unique monster arrivals — does not replace normal slime spawns.
# Triggers based on kill count, time of day, and game time so threats "arrive".
extends Node
class_name BossDirector

const MONSTER_SCENE = preload("res://scenes/monster.tscn")

var noise: TerrainNoise
var _alive_uniques: Dictionary = {}  # id -> bool
var _boss_alive: Dictionary = {}
var _check_timer: float = 0.0
var _announce_cd: float = 0.0
var _unique_cd: Dictionary = {}
var _boss_respawn_at: Dictionary = {}
var _boss_respawn_epoch: Dictionary = {}
var _boss_restore_complete: bool = false

func _ready() -> void:
	add_to_group("boss_director")
	noise = TerrainNoise.new(GameManager.world_seed)
	EventBus.entity_died.connect(_on_entity_died)
	if MMORPGNetwork.is_online() and multiplayer.is_server() and WorldDeploymentGuard.production_mode:
		await _restore_persistent_bosses()
	_boss_restore_complete = true

func _process(delta: float) -> void:
	if not _boss_restore_complete:
		return
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		return # The server alone decides which shared-world threats exist.
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	if get_tree().get_first_node_in_group("dungeon_active"):
		return  # player is inside the Depths — no overworld arrivals

	_check_timer += delta
	_announce_cd = maxf(_announce_cd - delta, 0.0)
	if _check_timer < 4.0:
		return
	_check_timer = 0.0
	_evaluate_arrivals()

func _evaluate_arrivals() -> void:
	var kills: int = int(PlayerData.stats.get("kills", 0))
	var tsec: float = GameManager.game_time_seconds
	var dn = get_tree().get_first_node_in_group("day_night")
	var is_night: bool = false
	if dn:
		is_night = not bool(dn.is_day)

	# Unique field monsters (not bosses) — arrive as world progresses
	if kills >= 3:
		_try_spawn_unique("grey_wolf", false, {
			"display_name": "Grey Wolf", "max_hp": 55.0, "damage": 11.0,
			"body_color": Color(0.42, 0.42, 0.48), "move_speed": 4.6, "xp_train": 0.55,
			"gold_min": 3, "gold_max": 12
		}, 2)
	if kills >= 6:
		_try_spawn_unique("bandit", false, {
			"display_name": "Road Bandit", "max_hp": 70.0, "damage": 14.0,
			"body_color": Color(0.45, 0.28, 0.22), "move_speed": 3.8, "xp_train": 0.65,
			"gold_min": 6, "gold_max": 18
		}, 2)
	if kills >= 8 and is_night:
		_try_spawn_unique("night_wisp", false, {
			"display_name": "Night Wisp", "max_hp": 40.0, "damage": 13.0,
			"body_color": Color(0.45, 0.7, 1.0), "move_speed": 3.2, "xp_train": 0.7,
			"gold_min": 4, "gold_max": 14, "aggro_range": 16.0
		}, 2)
	if kills >= 12:
		_try_spawn_unique("stone_crawler", false, {
			"display_name": "Stone Crawler", "max_hp": 90.0, "damage": 16.0,
			"body_color": Color(0.5, 0.45, 0.35), "move_speed": 2.8, "xp_train": 0.75,
			"gold_min": 8, "gold_max": 20
		}, 1)

	# Bosses arrive once — stronger, announced
	if kills >= 10 and tsec > 180.0:
		_try_spawn_boss("king_slime", {
			"display_name": "King Slime", "max_hp": 220.0, "damage": 18.0,
			"body_color": Color(0.25, 0.75, 0.4), "move_speed": 2.6, "xp_train": 1.5,
			"gold_min": 40, "gold_max": 80, "aggro_range": 18.0, "attack_range": 2.4
		}, "A massive slime is rising near the eastern flats...")
	if kills >= 18 and tsec > 360.0:
		_try_spawn_boss("alpha_wolf", {
			"display_name": "Alpha Wolf", "max_hp": 260.0, "damage": 22.0,
			"body_color": Color(0.2, 0.2, 0.25), "move_speed": 5.0, "xp_train": 1.8,
			"gold_min": 50, "gold_max": 95, "aggro_range": 20.0
		}, "Howls echo from the treeline — an Alpha has claimed the woods.")
	if kills >= 25 and tsec > 480.0:
		_try_spawn_boss("bandit_warlord", {
			"display_name": "Bandit Warlord", "max_hp": 320.0, "damage": 26.0,
			"body_color": Color(0.35, 0.15, 0.12), "move_speed": 3.5, "xp_train": 2.0,
			"gold_min": 70, "gold_max": 120, "aggro_range": 16.0
		}, "The Bandit Warlord rides the Old Road. Caravans are not safe.")
	if kills >= 30 and tsec > 600.0:
		_try_spawn_boss("tide_serpent", {
			"display_name": "Tide Serpent", "max_hp": 380.0, "damage": 28.0,
			"body_color": Color(0.15, 0.45, 0.55), "move_speed": 3.0, "xp_train": 2.2,
			"gold_min": 80, "gold_max": 140, "aggro_range": 22.0, "attack_range": 2.6
		}, "Waves thrash beyond the shore — the Tide Serpent has arrived.")

func _try_spawn_unique(id: String, boss: bool, props: Dictionary, max_alive: int) -> void:
	var count: int = 0
	for c in get_children():
		if c is Monster and str(c.monster_id) == id and c.state != Monster.State.DEAD:
			count += 1
	if count >= max_alive:
		return
	var now: float = GameManager.game_time_seconds
	if float(_unique_cd.get(id, -999.0)) + 90.0 > now:
		return
	_unique_cd[id] = now
	_spawn_monster(id, boss, props)

func _try_spawn_boss(id: String, props: Dictionary, announce: String) -> void:
	if GameManager.game_time_seconds < float(_boss_respawn_at.get(id, 0.0)):
		return
	if _boss_alive.get(id, false):
		return
	# Check if still alive in tree
	for n in get_tree().get_nodes_in_group("boss"):
		if n is Monster and n.monster_id == id:
			_boss_alive[id] = true
			return
	_boss_alive[id] = true
	_spawn_monster(id, true, props)
	if _announce_cd <= 0.0:
		EventBus.toast.emit(announce, "scene")
		EventBus.activity.emit(announce, "world")
		_announce_cd = 8.0

func _spawn_monster(id: String, boss: bool, props: Dictionary) -> void:
	var pos: Vector3 = _find_spawn_pos(boss)
	if pos == Vector3.ZERO:
		return
	var m: Monster = MONSTER_SCENE.instantiate()
	m.monster_id = id
	m.is_boss = boss
	m.display_name = str(props.get("display_name", id.capitalize()))
	m.max_hp = float(props.get("max_hp", 60.0))
	m.damage = float(props.get("damage", 12.0))
	m.body_color = props.get("body_color", Color(0.5, 0.5, 0.5))
	m.move_speed = float(props.get("move_speed", 4.0))
	m.xp_train = float(props.get("xp_train", 0.5))
	m.gold_min = int(props.get("gold_min", 3))
	m.gold_max = int(props.get("gold_max", 12))
	m.aggro_range = float(props.get("aggro_range", 14.0))
	m.attack_range = float(props.get("attack_range", 2.0))
	if not boss and randf() < 0.12:
		m.growth_rank = 1
	elif not boss and randf() < 0.03:
		m.growth_rank = 2
	m.position = pos
	if boss:
		m.scale = Vector3.ONE * 1.35
	add_child(m)
	if boss and MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.persist_world_boss_state(id, "elyndor_heartlands", {"status": "alive", "monster_id": id, "display_name": m.display_name, "position": [pos.x, pos.y, pos.z], "health": m.max_hp, "max_health": m.max_hp, "damage": m.damage, "move_speed": m.move_speed, "xp_train": m.xp_train, "gold_min": m.gold_min, "gold_max": m.gold_max, "aggro_range": m.aggro_range, "attack_range": m.attack_range, "leash_range": m.leash_range, "body_color": [m.body_color.r, m.body_color.g, m.body_color.b], "spawned_at": Time.get_unix_time_from_system()})
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.broadcast_world_monster_spawn(m)
	if not boss:
		EventBus.activity.emit("%s sighted in the wilds" % m.display_name, "world")

func _find_spawn_pos(boss: bool) -> Vector3:
	var c: Vector2 = TerrainNoise.VILLAGE_CENTER
	var player = GameManager.player
	for attempt in range(35):
		var a: float = randf() * TAU
		var r: float = randf_range(40.0, 95.0) if not boss else randf_range(50.0, 110.0)
		var p: Vector2 = c + Vector2(cos(a), sin(a)) * r
		if player and boss and attempt < 10:
			# Prefer somewhat near player for first boss encounters so they're findable
			var pa: float = randf() * TAU
			var pr: float = randf_range(35.0, 70.0)
			p = Vector2(player.global_position.x, player.global_position.z) + Vector2(cos(pa), sin(pa)) * pr
		if p.x < -130.0 or p.x > 70.0 or p.y < -130.0 or p.y > 70.0:
			continue
		var h: float = noise.get_height(p.x, p.y)
		if h < 1.5 or h > 10.0:
			continue
		if noise.settlement_mask(p.x, p.y) > 0.04:
			continue
		return Vector3(p.x, h + 0.8, p.y)
	return Vector3.ZERO

func _restore_persistent_bosses() -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured() or not multiplayer.is_server():
		return
	var result: Dictionary = await CentralBackend.server_load_bosses()
	if not bool(result.get("ok", false)):
		push_warning("Persistent boss restore failed: %s" % str(result.get("error", result.get("status", "unknown"))))
		return
	var body: Dictionary = result.get("body", {})
	for row_variant in body.get("bosses", []):
		if not row_variant is Dictionary: continue
		var row: Dictionary = row_variant
		var state: Dictionary = row.get("encounter_state", {}) if row.get("encounter_state", {}) is Dictionary else {}
		var boss_key := str(row.get("boss_definition_id", state.get("monster_id", "")))
		var monster_id := str(state.get("monster_id", boss_key))
		var is_world_boss := bool(state.get("world_boss", false))
		if boss_key.is_empty() or monster_id.is_empty(): continue
		if str(state.get("status", "")) == "defeated":
			var defeated_at := int(state.get("defeated_at", 0))
			var delay := int(state.get("respawn_delay_seconds", 420))
			var respawn_epoch := defeated_at + delay
			if is_world_boss:
				_boss_respawn_epoch[boss_key] = respawn_epoch
			else:
				var remaining := maxi(0, respawn_epoch - int(Time.get_unix_time_from_system()))
				_boss_respawn_at[boss_key] = GameManager.game_time_seconds + float(remaining)
				_boss_alive[boss_key] = false
			continue
		if str(state.get("status", "")) != "alive": continue
		var already_alive := false
		for existing in get_tree().get_nodes_in_group("boss"):
			if not existing is Monster or existing.state == Monster.State.DEAD: continue
			if is_world_boss and str(existing.get_meta("world_boss_id", "")) == boss_key:
				already_alive = true
			elif not is_world_boss and str(existing.monster_id) == monster_id:
				already_alive = true
			if already_alive: break
		if already_alive:
			_boss_alive[boss_key] = true
			continue
		var position_data: Array = state.get("position", [])
		if position_data.size() < 3: continue
		var monster: Monster = MONSTER_SCENE.instantiate()
		monster.monster_id = monster_id
		monster.is_boss = true
		monster.display_name = str(state.get("display_name", monster_id.capitalize()))
		monster.max_hp = float(state.get("max_health", 220.0))
		monster.damage = float(state.get("damage", 18.0))
		monster.move_speed = float(state.get("move_speed", 3.0))
		monster.xp_train = float(state.get("xp_train", 1.0))
		monster.gold_min = int(state.get("gold_min", 0))
		monster.gold_max = int(state.get("gold_max", 0))
		monster.aggro_range = float(state.get("aggro_range", 18.0))
		monster.attack_range = float(state.get("attack_range", 2.4))
		monster.leash_range = float(state.get("leash_range", 55.0))
		var color_data: Array = state.get("body_color", [0.5, 0.5, 0.5])
		if color_data.size() >= 3:
			monster.body_color = Color(float(color_data[0]), float(color_data[1]), float(color_data[2]))
		monster.position = Vector3(float(position_data[0]), float(position_data[1]), float(position_data[2]))
		monster.scale = Vector3.ONE * float(state.get("scale", 1.35))
		if is_world_boss:
			monster.set_meta("world_boss", true)
			monster.set_meta("world_boss_id", boss_key)
			monster.set_meta("world_boss_region", str(row.get("region_id", "elyndor")))
			monster.set_meta("raid_boss", true)
			monster.set_meta("raid_floor", -1)
			monster.set_meta("dungeon_signature_pattern", str(state.get("pattern", "ring_slam")))
			monster.set_meta("legendary_reward_id", str(state.get("reward", "runebound_core")))
			monster.set_meta("ecology_apex", true)
		_boss_alive[boss_key] = true
		add_child(monster)
		MMORPGNetwork.broadcast_world_monster_spawn(monster)

func _on_entity_died(entity: Node) -> void:
	if not (entity is Monster) or not entity.is_boss:
		return
	var defeated_at := int(Time.get_unix_time_from_system())
	if bool(entity.get_meta("world_boss", false)):
		var boss_key := str(entity.get_meta("world_boss_id", entity.monster_id))
		var region_id := str(entity.get_meta("world_boss_region", "elyndor"))
		_boss_alive[boss_key] = false
		_boss_respawn_epoch[boss_key] = defeated_at + 900
		if MMORPGNetwork.is_online() and multiplayer.is_server():
			MMORPGNetwork.persist_world_boss_state(boss_key, region_id, {"status": "defeated", "world_boss": true, "world_boss_id": boss_key, "monster_id": str(entity.monster_id), "display_name": str(entity.display_name), "defeated_at": defeated_at, "respawn_delay_seconds": 900})
		return
	var unique_id := str(entity.monster_id)
	_boss_alive[unique_id] = false
	_boss_respawn_at[unique_id] = GameManager.game_time_seconds + 420.0
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.persist_world_boss_state(unique_id, "elyndor_heartlands", {"status": "defeated", "monster_id": unique_id, "display_name": str(entity.display_name), "defeated_at": defeated_at, "respawn_delay_seconds": 420})
	get_tree().create_timer(420.0).timeout.connect(func() -> void:
		_boss_alive[unique_id] = false
	)

## Spawns a migration group at a supplied region anchor. Region simulation determines
## when the group appears; this director only handles safe world placement.
func spawn_ecology_group(monster_id: String, count: int, center: Vector2, radius: float = 24.0, region_id: String = "", territory_faction_id: String = "") -> int:
	var spawned: int = 0
	var props: Dictionary = _ecology_properties(monster_id)
	for index in range(clampi(count, 1, 8)):
		var pos: Vector3 = _find_region_spawn_pos(center, radius, region_id)
		if pos == Vector3.ZERO:
			continue
		var monster: Monster = MONSTER_SCENE.instantiate()
		monster.monster_id = monster_id
		monster.display_name = str(props.get("display_name", monster_id.replace("_", " ").capitalize()))
		monster.max_hp = float(props.get("max_hp", 70.0))
		monster.damage = float(props.get("damage", 14.0))
		monster.body_color = props.get("body_color", Color(0.42, 0.48, 0.42))
		monster.move_speed = float(props.get("move_speed", 3.6))
		monster.xp_train = float(props.get("xp_train", 0.7))
		monster.set_meta("ecology_spawn", true)
		monster.set_meta("ecology_region", region_id)
		if territory_faction_id != "":
			monster.set_meta("territory_faction_id", territory_faction_id)
			monster.set_meta("pack_id", territory_faction_id)
		monster.position = pos
		add_child(monster)
		if MMORPGNetwork.is_online() and multiplayer.is_server():
			MMORPGNetwork.broadcast_world_monster_spawn(monster)
		spawned += 1
	return spawned


## Regional predator conflicts are visible skirmishes, not only population changes.
## Opposing packs use the same autonomous combat loop as dungeon factions.
func spawn_territorial_conflict(region_id: String, first_species: String, second_species: String, center: Vector2) -> int:
	var total: int = 0
	total += spawn_ecology_group(first_species, 2, center + Vector2(-10.0, 0.0), 18.0, region_id, "wild_pack_a")
	total += spawn_ecology_group(second_species, 2, center + Vector2(10.0, 0.0), 18.0, region_id, "wild_pack_b")
	return total

## Regional apex encounters are unique, authoritative bosses. Metadata is attached
## before add_child so Monster._ready can initialise its raid-pattern behaviour.
func spawn_world_boss(boss_id: String, profile: Dictionary, center: Vector2, region_id: String) -> bool:
	if Time.get_unix_time_from_system() < float(_boss_respawn_epoch.get(boss_id, 0)):
		return false
	for existing in get_tree().get_nodes_in_group("boss"):
		if existing is Monster and str(existing.get_meta("world_boss_id", "")) == boss_id and existing.state != Monster.State.DEAD:
			return false
	var pos: Vector3 = _find_region_spawn_pos(center, 46.0, region_id)
	if pos == Vector3.ZERO:
		return false
	var monster: Monster = MONSTER_SCENE.instantiate()
	monster.monster_id = str(profile.get("monster_id", "stone_crawler"))
	monster.is_boss = true
	monster.display_name = str(profile.get("name", "Regional Apex"))
	monster.max_hp = float(profile.get("hp", 900.0))
	monster.damage = float(profile.get("damage", 34.0))
	var color_value: Variant = profile.get("color", [0.65, 0.55, 0.4])
	if color_value is Array and color_value.size() >= 3:
		monster.body_color = Color(float(color_value[0]), float(color_value[1]), float(color_value[2]))
	monster.move_speed = 3.8
	monster.xp_train = 2.8
	monster.gold_min = 180
	monster.gold_max = 320
	monster.aggro_range = 30.0
	monster.attack_range = 3.6
	monster.leash_range = 110.0
	monster.scale = Vector3.ONE * 1.72
	monster.set_meta("raid_boss", true)
	monster.set_meta("raid_floor", -1)
	monster.set_meta("dungeon_signature_pattern", str(profile.get("pattern", "ring_slam")))
	monster.set_meta("world_boss", true)
	monster.set_meta("world_boss_id", boss_id)
	monster.set_meta("world_boss_region", region_id)
	monster.set_meta("legendary_reward_id", str(profile.get("reward", "runebound_core")))
	monster.set_meta("ecology_apex", true)
	monster.position = pos
	add_child(monster)
	_boss_alive[boss_id] = true
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.persist_world_boss_state(boss_id, region_id, {"status": "alive", "world_boss": true, "world_boss_id": boss_id, "monster_id": str(monster.monster_id), "display_name": str(monster.display_name), "position": [pos.x, pos.y, pos.z], "health": monster.max_hp, "max_health": monster.max_hp, "damage": monster.damage, "move_speed": monster.move_speed, "xp_train": monster.xp_train, "gold_min": monster.gold_min, "gold_max": monster.gold_max, "aggro_range": monster.aggro_range, "attack_range": monster.attack_range, "leash_range": monster.leash_range, "body_color": [monster.body_color.r, monster.body_color.g, monster.body_color.b], "scale": 1.72, "pattern": str(profile.get("pattern", "ring_slam")), "reward": str(profile.get("reward", "runebound_core")), "spawned_at": Time.get_unix_time_from_system()})
		MMORPGNetwork.broadcast_world_monster_spawn(monster)
	var announcement: String = "%s has awakened in %s!" % [monster.display_name, region_id.replace("_", " ").capitalize()]
	EventBus.toast.emit(announcement, "scene")
	EventBus.activity.emit(announcement, "world")
	return true

func _find_region_spawn_pos(center: Vector2, radius: float, region_id: String) -> Vector3:
	for attempt in range(55):
		var angle: float = randf() * TAU
		var distance: float = randf_range(maxf(12.0, radius * 0.35), maxf(18.0, radius))
		var point: Vector2 = center + Vector2(cos(angle), sin(angle)) * distance
		var height: float = noise.get_height(point.x, point.y)
		if height < 1.4 or height > 18.0:
			continue
		if noise.settlement_mask(point.x, point.y) > 0.04:
			continue
		if region_id != "" and WorldLifeSimulation.region_id_at(point.x, point.y) != region_id:
			continue
		return Vector3(point.x, height + 0.8, point.y)
	return Vector3.ZERO

func _ecology_properties(monster_id: String) -> Dictionary:
	match monster_id:
		"frost_lynx": return {"display_name":"Frost Lynx","max_hp":115.0,"damage":22.0,"body_color":Color(0.55,0.76,0.9),"move_speed":4.6}
		"cinder_hound": return {"display_name":"Cinder Hound","max_hp":105.0,"damage":21.0,"body_color":Color(0.75,0.28,0.16),"move_speed":4.4}
		"reef_crab": return {"display_name":"Reef Crab","max_hp":92.0,"damage":16.0,"body_color":Color(0.25,0.62,0.68),"move_speed":2.5}
		"fungal_stalker": return {"display_name":"Fungal Stalker","max_hp":125.0,"damage":18.0,"body_color":Color(0.42,0.58,0.32),"move_speed":3.0}
		"stone_crawler": return {"display_name":"Stone Crawler","max_hp":150.0,"damage":20.0,"body_color":Color(0.48,0.44,0.38),"move_speed":2.4}
		_: return {"display_name":monster_id.replace("_", " ").capitalize(),"max_hp":82.0,"damage":15.0,"body_color":Color(0.45,0.48,0.42),"move_speed":3.4}
