# BuildingKit - materials + procedural models for houses, towers and props.
# Everything is generated from MeshKit primitives into one mesh per building, using the
# procedural building shader (stone / planks / plaster / tiles / thatch / cobble ...).
class_name BuildingKit
extends RefCounted

static var _mats: Dictionary = {}
static var glass_mat: StandardMaterial3D
static var lantern_mat: StandardMaterial3D
static var arcane_mat: StandardMaterial3D
static var crystal_mat: StandardMaterial3D

# ---------------------------------------------------------------------------
# Materials
# ---------------------------------------------------------------------------
static func get_material(mat_name: String) -> Material:
	if _mats.has(mat_name):
		return _mats[mat_name]
	var m: Material = _create_material(mat_name)
	_mats[mat_name] = m
	return m

static func _sm(pattern: int, a: Color, b: Color, c: Color = Color(0.15, 0.14, 0.13), rough: float = 0.88, bump: float = 1.0) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/building.gdshader")
	m.set_shader_parameter("pattern", pattern)
	m.set_shader_parameter("color_a", a)
	m.set_shader_parameter("color_b", b)
	m.set_shader_parameter("color_c", c)
	m.set_shader_parameter("rough", rough)
	m.set_shader_parameter("bump_strength", bump)
	return m

static func _std(c: Color, rough: float = 0.6, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m

static func _create_material(n: String) -> Material:
	match n:
		"stone": return _sm(0, Color(0.58, 0.56, 0.52), Color(0.42, 0.40, 0.37), Color(0.22, 0.21, 0.20))
		"stone_blue": return _sm(0, Color(0.48, 0.51, 0.60), Color(0.34, 0.37, 0.46), Color(0.19, 0.20, 0.25))
		"plaster_cream": return _sm(2, Color(0.90, 0.84, 0.70), Color(0.78, 0.70, 0.56), Color.BLACK, 0.92, 0.6)
		"plaster_white": return _sm(2, Color(0.92, 0.91, 0.88), Color(0.80, 0.79, 0.77), Color.BLACK, 0.92, 0.6)
		"plaster_rose": return _sm(2, Color(0.88, 0.70, 0.62), Color(0.76, 0.57, 0.50), Color.BLACK, 0.92, 0.6)
		"plaster_blue": return _sm(2, Color(0.60, 0.68, 0.88), Color(0.46, 0.54, 0.78), Color.BLACK, 0.9, 0.6)
		"wood": return _sm(1, Color(0.55, 0.37, 0.21), Color(0.38, 0.24, 0.13), Color(0.12, 0.08, 0.05), 0.8)
		"wood_dark": return _sm(1, Color(0.30, 0.19, 0.10), Color(0.20, 0.12, 0.06), Color(0.08, 0.05, 0.03), 0.8)
		"roof_clay": return _sm(3, Color(0.72, 0.31, 0.19), Color(0.52, 0.20, 0.12), Color.BLACK, 0.8, 1.4)
		"roof_brown": return _sm(3, Color(0.42, 0.28, 0.20), Color(0.30, 0.19, 0.14), Color.BLACK, 0.8, 1.4)
		"roof_blue": return _sm(3, Color(0.26, 0.34, 0.62), Color(0.15, 0.20, 0.44), Color.BLACK, 0.55, 1.4)
		"thatch": return _sm(4, Color(0.80, 0.64, 0.32), Color(0.52, 0.38, 0.16), Color.BLACK, 0.95, 1.2)
		"hay": return _sm(4, Color(0.88, 0.74, 0.30), Color(0.66, 0.50, 0.18), Color.BLACK, 0.95, 1.0)
		"cobble": return _sm(5, Color(0.58, 0.55, 0.50), Color(0.43, 0.41, 0.38), Color(0.20, 0.19, 0.18), 0.9)
		"cobble_blue": return _sm(5, Color(0.50, 0.51, 0.55), Color(0.36, 0.37, 0.41), Color(0.19, 0.20, 0.23), 0.8)
		"cloth_red": return _sm(6, Color(0.80, 0.16, 0.12), Color(0.95, 0.90, 0.80), Color.BLACK, 0.9, 0.4)
		"cloth_blue": return _sm(6, Color(0.18, 0.34, 0.75), Color(0.95, 0.92, 0.85), Color.BLACK, 0.9, 0.4)
		"soil": return _sm(2, Color(0.26, 0.16, 0.09), Color(0.17, 0.10, 0.06), Color.BLACK, 1.0, 1.5)
		"fruit": return _sm(2, Color(1, 1, 1), Color(0.92, 0.92, 0.92), Color.BLACK, 0.5, 0.2)
		"iron": return _std(Color(0.14, 0.14, 0.16), 0.5, 0.8)
		"gold": return _std(Color(0.95, 0.74, 0.25), 0.3, 0.95)
		"water_basin":
			var w := _std(Color(0.10, 0.50, 0.62, 0.82), 0.04)
			w.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			w.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
			return w
		"glass":
			glass_mat = _std(Color(0.10, 0.14, 0.20), 0.08, 0.4)
			glass_mat.emission_enabled = true
			glass_mat.emission = Color(1.0, 0.72, 0.35)
			glass_mat.emission_energy_multiplier = 0.0
			return glass_mat
		"lantern":
			lantern_mat = _std(Color(0.9, 0.7, 0.3), 0.4)
			lantern_mat.emission_enabled = true
			lantern_mat.emission = Color(1.0, 0.65, 0.25)
			lantern_mat.emission_energy_multiplier = 0.4
			return lantern_mat
		"arcane":
			arcane_mat = _std(Color(0.25, 0.20, 0.45), 0.15, 0.2)
			arcane_mat.emission_enabled = true
			arcane_mat.emission = Color(0.55, 0.40, 1.0)
			arcane_mat.emission_energy_multiplier = 2.2
			return arcane_mat
		"potion", "potion_blue", "potion_red":
			var pc: Color = Color(0.25, 0.95, 0.45)
			if n == "potion_blue":
				pc = Color(0.35, 0.6, 1.0)
			elif n == "potion_red":
				pc = Color(1.0, 0.35, 0.4)
			var pm: StandardMaterial3D = _std(Color(pc.r, pc.g, pc.b, 0.85), 0.1)
			pm.emission_enabled = true
			pm.emission = pc
			pm.emission_energy_multiplier = 1.6
			return pm
		"crystal":
			crystal_mat = _std(Color(0.45, 0.65, 1.0), 0.08, 0.0)
			crystal_mat.emission_enabled = true
			crystal_mat.emission = Color(0.35, 0.60, 1.0)
			crystal_mat.emission_energy_multiplier = 3.0
			return crystal_mat
	return _std(Color(1, 0, 1))

## 0 = day, 1 = full night. Windows and lanterns glow when it is dark.
static func set_night_glow(f: float) -> void:
	get_material("glass")
	get_material("lantern")
	glass_mat.emission_energy_multiplier = f * 2.0
	lantern_mat.emission_energy_multiplier = 0.35 + f * 2.6

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
static func _finish(b: MeshBatch, shapes: Array, node_name: String) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.collision_layer = Constants.LAYER_WORLD
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	mi.name = "Mesh"
	mi.mesh = b.commit(BuildingKit.get_material)
	body.add_child(mi)
	for s in shapes:
		var cs := CollisionShape3D.new()
		cs.shape = s[1]
		cs.transform = s[0]
		body.add_child(cs)
	return body

static func _box_shape(size: Vector3, pos: Vector3, yaw: float = 0.0) -> Array:
	var s := BoxShape3D.new()
	s.size = size
	return [Transform3D(Basis(Vector3.UP, yaw), pos), s]

static func _cyl_shape(radius: float, height: float, pos: Vector3) -> Array:
	var s := CylinderShape3D.new()
	s.radius = radius
	s.height = height
	return [Transform3D(Basis.IDENTITY, pos), s]

static func _box_shape_xf(size: Vector3, xform: Transform3D) -> Array:
	var s := BoxShape3D.new()
	s.size = size
	return [xform, s]

static func _bx(st: SurfaceTool, base: Transform3D, off: Vector3, size: Vector3, cb: Color = Color.WHITE, ct: Color = Color.WHITE) -> void:
	MeshKit.box(st, Transform3D(base.basis, base * off), size, cb, ct)

static func add_light(parent: Node3D, pos: Vector3, color: Color, energy: float, light_range: float, flicker: float = 0.0, always_on: bool = false) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = color
	l.omni_range = light_range
	l.omni_attenuation = 1.4
	l.shadow_enabled = false
	l.light_specular = 0.4
	if always_on:
		l.light_energy = energy
	else:
		l.light_energy = 0.0
		l.set_meta("base_energy", energy)
		l.set_meta("flicker", flicker)
		l.add_to_group("night_lights")
	parent.add_child(l)
	return l

# ---------------------------------------------------------------------------
# House (door faces local +Z)
# ---------------------------------------------------------------------------
static func _window(b: MeshBatch, base: Transform3D, at: Vector3) -> void:
	var wood: SurfaceTool = b.surface("wood_dark")
	var wood_l: SurfaceTool = b.surface("wood")
	var glass: SurfaceTool = b.surface("glass")
	var stone: SurfaceTool = b.surface("stone")
	_bx(wood, base, at + Vector3(0, 0, 0.03), Vector3(1.0, 1.08, 0.14))
	_bx(glass, base, at + Vector3(0, 0, 0.07), Vector3(0.8, 0.88, 0.12))
	_bx(wood, base, at + Vector3(0, 0, 0.12), Vector3(0.06, 0.9, 0.1))
	_bx(wood, base, at + Vector3(0, 0, 0.12), Vector3(0.82, 0.06, 0.1))
	_bx(wood_l, base, at + Vector3(-0.68, 0, 0.06), Vector3(0.34, 1.0, 0.07))
	_bx(wood_l, base, at + Vector3(0.68, 0, 0.06), Vector3(0.34, 1.0, 0.07))
	_bx(stone, base, at + Vector3(0, -0.6, 0.12), Vector3(1.3, 0.09, 0.3))

static func make_house(w: float, d: float, wall_h: float, wall_mat: String, roof_mat: String, tint: Color) -> Node3D:
	var root := Node3D.new()
	root.name = "House"
	var b := MeshBatch.new()
	var h0: float = 0.45
	var stone: SurfaceTool = b.surface("stone")
	var plaster: SurfaceTool = b.surface(wall_mat)
	var wood: SurfaceTool = b.surface("wood_dark")
	var wood_l: SurfaceTool = b.surface("wood")
	var roof: SurfaceTool = b.surface(roof_mat)
	var lantern: SurfaceTool = b.surface("lantern")
	var dark := Color(0.62, 0.62, 0.62)

	MeshKit.box_at(stone, Vector3(0, (h0 - 0.8) * 0.5, 0), Vector3(w + 0.25, h0 + 0.8, d + 0.25), dark, Color.WHITE)
	MeshKit.box_at(plaster, Vector3(0, h0 + wall_h * 0.5, 0), Vector3(w, wall_h, d), tint * 0.72, tint)

	# Timber frame
	var top_y: float = h0 + wall_h
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			MeshKit.box_at(wood, Vector3(sx * w * 0.5, h0 + wall_h * 0.5, sz * d * 0.5), Vector3(0.26, wall_h + 0.1, 0.26))
	for sz in [-1.0, 1.0]:
		MeshKit.box_at(wood, Vector3(0, top_y - 0.1, sz * d * 0.5), Vector3(w + 0.26, 0.24, 0.24))
		MeshKit.box_at(wood, Vector3(0, h0 + wall_h * 0.5, sz * d * 0.5 + sz * 0.02), Vector3(w, 0.14, 0.14))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(wood, Vector3(sx * w * 0.5, top_y - 0.1, 0), Vector3(0.24, 0.24, d + 0.26))
		MeshKit.box_at(wood, Vector3(sx * w * 0.5 + sx * 0.02, h0 + wall_h * 0.5, 0), Vector3(0.14, 0.14, d))

	# Door + windows (front = +Z)
	var door_x: float = w * 0.2 if w < 6.0 else 0.0
	var win_xs: Array[float] = []
	if w < 6.0:
		win_xs.append(-w * 0.27)
	else:
		win_xs.append(-w * 0.3)
		win_xs.append(w * 0.3)
	var front := Transform3D(Basis.IDENTITY, Vector3(0, 0, d * 0.5))
	var back := Transform3D(Basis(Vector3.UP, PI), Vector3(0, 0, -d * 0.5))
	var right := Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(w * 0.5, 0, 0))
	var left := Transform3D(Basis(Vector3.UP, -PI * 0.5), Vector3(-w * 0.5, 0, 0))
	var win_y: float = h0 + wall_h * 0.58
	for wx in win_xs:
		_window(b, front, Vector3(wx, win_y, 0))
	_window(b, back, Vector3(-w * 0.2, win_y, 0))
	_window(b, back, Vector3(w * 0.2, win_y, 0))
	_window(b, right, Vector3(0, win_y, 0))
	_window(b, left, Vector3(0, win_y, 0))
	# studs on the front/back between openings
	var xs: float = -w * 0.5 + 1.2
	while xs < w * 0.5 - 0.6:
		var blocked: bool = absf(xs - door_x) < 0.95
		for wx in win_xs:
			if absf(xs - wx) < 0.9:
				blocked = true
		if not blocked:
			MeshKit.box_at(wood, Vector3(xs, h0 + wall_h * 0.5, d * 0.5 + 0.03), Vector3(0.12, wall_h - 0.2, 0.1))
		xs += 1.5

	_bx(wood, front, Vector3(door_x, h0 + 1.1, 0.04), Vector3(1.3, 2.25, 0.16))
	_bx(wood_l, front, Vector3(door_x, h0 + 1.0, 0.11), Vector3(0.98, 2.0, 0.1))
	_bx(b.surface("gold"), front, Vector3(door_x + 0.35, h0 + 1.0, 0.18), Vector3(0.07, 0.07, 0.06))
	MeshKit.box_at(stone, Vector3(door_x, h0 - 0.14, d * 0.5 + 0.5), Vector3(1.9, 0.34, 0.8), dark, Color.WHITE)
	_bx(lantern, front, Vector3(door_x + 1.2, h0 + 2.1, 0.2), Vector3(0.2, 0.32, 0.2))
	_bx(wood, front, Vector3(door_x + 1.2, h0 + 2.35, 0.12), Vector3(0.05, 0.06, 0.2))

	# Roof (ridge along X)
	var ang: float = 0.62
	var half: float = d * 0.5 + 0.55
	var rise: float = half * tan(ang)
	var slab_len: float = half / cos(ang) + 0.1
	for s in [-1.0, 1.0]:
		var bas := Basis(Vector3.RIGHT, s * ang)
		var normal: Vector3 = bas * Vector3.UP
		var center := Vector3(0, top_y + rise * 0.5, s * half * 0.5) + normal * 0.08
		MeshKit.box(roof, Transform3D(bas, center), Vector3(w + 1.1, 0.16, slab_len), Color.WHITE, Color.WHITE)
	var ridge_y: float = top_y + rise
	MeshKit.box_at(wood, Vector3(0, ridge_y + 0.06, 0), Vector3(w + 1.15, 0.18, 0.36))
	# gable ends
	var gh: float = (d * 0.5) * tan(ang)
	for sx in [-1.0, 1.0]:
		var xp: float = sx * w * 0.5
		MeshKit.flat_tri(plaster, Vector3(xp, top_y, -d * 0.5), Vector3(xp, top_y, d * 0.5), Vector3(xp, top_y + gh, 0),
			Vector3(sx, 0, 0), tint, tint, tint, Vector2(0, 0), Vector2(d, 0), Vector2(d * 0.5, gh))
		MeshKit.box_at(wood, Vector3(xp + sx * 0.02, top_y + gh * 0.33, 0), Vector3(0.1, 0.12, d * 0.66))

	# Chimney
	var cx: float = w * 0.5 - 0.95
	var ch_top: float = ridge_y + 0.95
	MeshKit.box_at(stone, Vector3(cx, (top_y - 0.3 + ch_top) * 0.5, 0), Vector3(0.75, ch_top - top_y + 0.3, 0.75), dark, Color.WHITE)
	MeshKit.box_at(stone, Vector3(cx, ch_top + 0.06, 0), Vector3(0.95, 0.14, 0.95))

	# Compound collider: walls plus the actual pitched roof and chimney, so thrown
	# objects, falling trunks and projectiles land on the real silhouette.
	var shapes: Array = [_box_shape(Vector3(w + 0.25, wall_h + h0 + 0.8, d + 0.25), Vector3(0, (wall_h + h0 - 0.8) * 0.5 + 0.4, 0))]
	for sgn in [-1.0, 1.0]:
		var bas := Basis(Vector3.RIGHT, sgn * ang)
		var normal: Vector3 = bas * Vector3.UP
		var center := Vector3(0, top_y + rise * 0.5, sgn * half * 0.5) + normal * 0.08
		shapes.append(_box_shape_xf(Vector3(w + 1.1, 0.16, slab_len), Transform3D(bas, center)))
	shapes.append(_box_shape_xf(Vector3(0.75, ch_top - top_y + 0.3, 0.75), Transform3D(Basis.IDENTITY, Vector3(cx, (top_y - 0.3 + ch_top) * 0.5, 0))))
	shapes.append(_box_shape_xf(Vector3(0.95, 0.14, 0.95), Transform3D(Basis.IDENTITY, Vector3(cx, ch_top + 0.06, 0))))
	var body: StaticBody3D = _finish(b, shapes, "Body")
	root.add_child(body)
	VFX.smoke(root, Vector3(cx, ch_top + 0.25, 0))
	add_light(root, Vector3(door_x + 1.2, h0 + 2.1, d * 0.5 + 0.8), Color(1.0, 0.65, 0.3), 2.0, 9.0, 0.06)
	return root

# ---------------------------------------------------------------------------
# Props
# ---------------------------------------------------------------------------
static func make_lamp_post() -> Node3D:
	var root := Node3D.new()
	root.name = "LampPost"
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood_dark")
	var iron: SurfaceTool = b.surface("iron")
	var lan: SurfaceTool = b.surface("lantern")
	MeshKit.cylinder_at(wood, Vector3.ZERO, 0.14, 0.09, 3.3, 8, Color(0.6, 0.6, 0.6), Color.WHITE)
	MeshKit.cylinder_at(b.surface("stone"), Vector3.ZERO, 0.28, 0.2, 0.35, 8)
	MeshKit.box_at(wood, Vector3(0.28, 3.1, 0), Vector3(0.6, 0.08, 0.08))
	MeshKit.box_at(lan, Vector3(0.55, 2.88, 0), Vector3(0.24, 0.36, 0.24))
	MeshKit.cylinder_at(iron, Vector3(0.55, 3.06, 0), 0.2, 0.0, 0.22, 4, Color.WHITE, Color.WHITE)
	root.add_child(_finish(b, [_cyl_shape(0.15, 3.3, Vector3(0, 1.65, 0))], "Body"))
	add_light(root, Vector3(0.55, 2.8, 0), Color(1.0, 0.7, 0.35), 2.6, 15.0, 0.08)
	return root

static func make_barrel() -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var iron: SurfaceTool = b.surface("iron")
	MeshKit.cylinder_at(wood, Vector3.ZERO, 0.3, 0.37, 0.48, 10, Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.cylinder_at(wood, Vector3(0, 0.48, 0), 0.37, 0.3, 0.48, 10, Color.WHITE, Color.WHITE)
	MeshKit.cylinder_at(iron, Vector3(0, 0.12, 0), 0.34, 0.345, 0.06, 10)
	MeshKit.cylinder_at(iron, Vector3(0, 0.78, 0), 0.345, 0.34, 0.06, 10)
	return _finish(b, [_cyl_shape(0.37, 0.96, Vector3(0, 0.48, 0))], "Barrel")

static func make_crate(sz: float = 0.9) -> Node3D:
	var b := MeshBatch.new()
	MeshKit.box_at(b.surface("wood"), Vector3(0, sz * 0.45, 0), Vector3(sz, sz * 0.9, sz), Color(0.7, 0.7, 0.7), Color.WHITE)
	for sx in [-1.0, 1.0]:
		for sz2 in [-1.0, 1.0]:
			MeshKit.box_at(b.surface("wood_dark"), Vector3(sx * sz * 0.5, sz * 0.45, sz2 * sz * 0.5), Vector3(0.1, sz * 0.92, 0.1))
	return _finish(b, [_box_shape(Vector3(sz, sz * 0.9, sz), Vector3(0, sz * 0.45, 0))], "Crate")

static func make_hay_bale() -> Node3D:
	var b := MeshBatch.new()
	var xf := Transform3D(Basis(Vector3(0, 0, 1), PI * 0.5), Vector3(0.55, 0.5, 0))
	MeshKit.cylinder(b.surface("hay"), xf, 0.5, 0.5, 1.1, 10, Color(0.8, 0.8, 0.8), Color.WHITE)
	MeshKit.box_at(b.surface("wood_dark"), Vector3(0, 0.5, 0), Vector3(1.12, 0.05, 0.05))
	return _finish(b, [_box_shape(Vector3(1.1, 1.0, 1.0), Vector3(0, 0.5, 0))], "Hay")

static func make_well() -> Node3D:
	var b := MeshBatch.new()
	var stone: SurfaceTool = b.surface("stone")
	var wood: SurfaceTool = b.surface("wood_dark")
	var roof: SurfaceTool = b.surface("roof_brown")
	for i in range(10):
		var a: float = TAU * float(i) / 10.0
		var xf := Transform3D(Basis(Vector3.UP, -(a + PI * 0.5)), Vector3(cos(a) * 0.95, 0.5, sin(a) * 0.95))
		MeshKit.box(stone, xf, Vector3(0.7, 1.0, 0.42), Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.cylinder_at(b.surface("water_basin"), Vector3(0, 0.45, 0), 0.8, 0.8, 0.04, 12)
	for s in [-1.0, 1.0]:
		MeshKit.box_at(wood, Vector3(s * 1.0, 1.5, 0), Vector3(0.16, 3.0, 0.16))
	MeshKit.box_at(wood, Vector3(0, 2.6, 0), Vector3(2.1, 0.14, 0.14))
	for s in [-1.0, 1.0]:
		var bas := Basis(Vector3(0, 0, 1), -s * 0.7)
		MeshKit.box(roof, Transform3D(bas, Vector3(s * 0.62, 3.05, 0)), Vector3(1.7, 0.1, 2.0))
	MeshKit.cylinder_at(wood, Vector3(0, 1.6, 0), 0.04, 0.04, 1.0, 5)
	MeshKit.cylinder_at(wood, Vector3(0.0, 1.55, 0), 0.2, 0.17, 0.2, 8)
	return _finish(b, [_cyl_shape(1.25, 1.0, Vector3(0, 0.5, 0))], "Well")

static func make_market_stall(cloth: String) -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dk: SurfaceTool = b.surface("wood_dark")
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	MeshKit.box_at(wood, Vector3(0, 0.45, 0), Vector3(2.5, 0.9, 1.1), Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.box_at(dk, Vector3(0, 0.93, 0), Vector3(2.6, 0.08, 1.2))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(dk, Vector3(sx * 1.25, 1.3, -0.5), Vector3(0.12, 2.6, 0.12))
		MeshKit.box_at(dk, Vector3(sx * 1.25, 1.1, 0.5), Vector3(0.12, 2.2, 0.12))
	var tilt := Basis(Vector3.RIGHT, -0.28)
	MeshKit.box(b.surface(cloth), Transform3D(tilt, Vector3(0, 2.55, 0.05)), Vector3(2.9, 0.07, 1.7))
	var fruit: SurfaceTool = b.surface("fruit")
	var colors: Array[Color] = [Color(0.85, 0.15, 0.1), Color(0.95, 0.65, 0.1), Color(0.4, 0.7, 0.15), Color(0.8, 0.3, 0.5)]
	for i in range(9):
		var c: Color = colors[i % colors.size()]
		MeshKit.blob(fruit, Vector3(-1.0 + float(i % 5) * 0.5, 1.07, -0.22 + float(i / 5) * 0.42), Vector3(0.15, 0.13, 0.15), rng, c.darkened(0.2), c, 0.1, 6, 4)
	return _finish(b, [_box_shape(Vector3(2.6, 1.0, 1.2), Vector3(0, 0.5, 0))], "Stall")

static func make_scarecrow() -> Node3D:
	var b := MeshBatch.new()
	var rng := RandomNumberGenerator.new()
	rng.seed = 9
	var wood: SurfaceTool = b.surface("wood_dark")
	MeshKit.cylinder_at(wood, Vector3.ZERO, 0.06, 0.05, 2.5, 6)
	MeshKit.box_at(wood, Vector3(0, 1.75, 0), Vector3(1.7, 0.08, 0.08))
	MeshKit.blob(b.surface("hay"), Vector3(0, 1.45, 0), Vector3(0.3, 0.5, 0.22), rng, Color(0.7, 0.7, 0.7), Color.WHITE, 0.1)
	MeshKit.blob(b.surface("hay"), Vector3(-0.8, 1.72, 0), Vector3(0.14, 0.1, 0.1), rng, Color.WHITE, Color.WHITE, 0.2)
	MeshKit.blob(b.surface("hay"), Vector3(0.8, 1.72, 0), Vector3(0.14, 0.1, 0.1), rng, Color.WHITE, Color.WHITE, 0.2)
	MeshKit.blob(b.surface("plaster_cream"), Vector3(0, 2.1, 0), Vector3(0.22, 0.24, 0.22), rng, Color.WHITE, Color.WHITE, 0.05)
	MeshKit.cylinder_at(wood, Vector3(0, 2.28, 0), 0.4, 0.4, 0.03, 10)
	MeshKit.cylinder_at(b.surface("roof_brown"), Vector3(0, 2.3, 0), 0.22, 0.12, 0.32, 8)
	for sx in [-1.0, 1.0]:
		MeshKit.blob(wood, Vector3(sx * 0.08, 2.14, -0.2), Vector3(0.03, 0.03, 0.02), rng, Color.BLACK, Color.BLACK, 0.0, 5, 3)
	return _finish(b, [_cyl_shape(0.3, 2.4, Vector3(0, 1.2, 0))], "Scarecrow")

static func make_fence(length: float) -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var n: int = maxi(int(round(length / 1.6)), 1)
	var gap: float = length / float(n)
	for i in range(n + 1):
		MeshKit.box_at(wood, Vector3(-length * 0.5 + gap * float(i), 0.5, 0), Vector3(0.13, 1.0, 0.13), Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.box_at(wood, Vector3(0, 0.82, 0), Vector3(length, 0.1, 0.07))
	MeshKit.box_at(wood, Vector3(0, 0.45, 0), Vector3(length, 0.1, 0.07))
	return _finish(b, [_box_shape(Vector3(length, 1.0, 0.2), Vector3(0, 0.5, 0))], "Fence")

static func make_bench() -> Node3D:
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dk: SurfaceTool = b.surface("wood_dark")
	MeshKit.box_at(wood, Vector3(0, 0.5, 0), Vector3(1.8, 0.09, 0.5))
	MeshKit.box_at(wood, Vector3(0, 0.95, 0.24), Vector3(1.8, 0.4, 0.06))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(dk, Vector3(sx * 0.8, 0.25, 0), Vector3(0.08, 0.5, 0.45))
		MeshKit.box_at(dk, Vector3(sx * 0.8, 0.75, 0.24), Vector3(0.08, 0.9, 0.08))
	return _finish(b, [_box_shape(Vector3(1.8, 0.9, 0.5), Vector3(0, 0.45, 0))], "Bench")

static func make_notice_board() -> Node3D:
	var b := MeshBatch.new()
	var dk: SurfaceTool = b.surface("wood_dark")
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(dk, Vector3(sx * 0.9, 1.1, 0), Vector3(0.14, 2.2, 0.14))
	MeshKit.box_at(b.surface("wood"), Vector3(0, 1.5, 0), Vector3(1.9, 1.1, 0.08))
	MeshKit.box_at(dk, Vector3(0, 2.15, 0), Vector3(2.2, 0.16, 0.3))
	var paper: SurfaceTool = b.surface("plaster_cream")
	MeshKit.box_at(paper, Vector3(-0.5, 1.5, 0.06), Vector3(0.5, 0.65, 0.02))
	MeshKit.box_at(paper, Vector3(0.25, 1.65, 0.06), Vector3(0.45, 0.5, 0.02))
	MeshKit.box_at(paper, Vector3(0.45, 1.2, 0.06), Vector3(0.4, 0.4, 0.02))
	return _finish(b, [_box_shape(Vector3(2.0, 2.2, 0.3), Vector3(0, 1.1, 0))], "NoticeBoard")

static func make_fountain() -> Node3D:
	var root := Node3D.new()
	root.name = "Fountain"
	var b := MeshBatch.new()
	var stone: SurfaceTool = b.surface("stone")
	MeshKit.cylinder_at(stone, Vector3.ZERO, 2.7, 2.6, 0.5, 20, Color(0.7, 0.7, 0.7), Color.WHITE)
	for i in range(14):
		var a: float = TAU * float(i) / 14.0
		var xf := Transform3D(Basis(Vector3.UP, -(a + PI * 0.5)), Vector3(cos(a) * 2.5, 0.68, sin(a) * 2.5))
		MeshKit.box(stone, xf, Vector3(1.25, 0.36, 0.45), Color(0.8, 0.8, 0.8), Color.WHITE)
	MeshKit.cylinder_at(b.surface("water_basin"), Vector3(0, 0.46, 0), 2.35, 2.35, 0.04, 20)
	MeshKit.cylinder_at(stone, Vector3(0, 0.5, 0), 0.6, 0.42, 1.2, 12)
	MeshKit.cylinder_at(stone, Vector3(0, 1.55, 0), 0.35, 1.15, 0.4, 14, Color.WHITE, Color.WHITE, true)
	MeshKit.cylinder_at(b.surface("water_basin"), Vector3(0, 1.92, 0), 0.95, 0.95, 0.03, 14)
	MeshKit.cylinder_at(stone, Vector3(0, 1.9, 0), 0.3, 0.2, 0.8, 8)
	root.add_child(_finish(b, [_cyl_shape(2.7, 1.1, Vector3(0, 0.55, 0))], "Body"))
	var crystal := MeshInstance3D.new()
	crystal.mesh = make_crystal_mesh(0.22, 0.7)
	crystal.position = Vector3(0, 3.2, 0)
	var am := AmbientMotion.new()
	am.spin_speed = 0.8
	am.bob_height = 0.12
	am.position = Vector3(0, 3.2, 0)
	crystal.position = Vector3.ZERO
	am.add_child(crystal)
	root.add_child(am)
	add_light(root, Vector3(0, 3.4, 0), Color(0.5, 0.7, 1.0), 1.6, 12.0, 0.0)
	VFX.fountain_spray(root, Vector3(0, 2.75, 0))
	return root

static func make_crystal_mesh(radius: float, half_height: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder(st, Transform3D(Basis.IDENTITY, Vector3(0, 0, 0)), radius, 0.0, half_height, 6, Color.WHITE, Color.WHITE, false, false, false)
	MeshKit.cylinder(st, Transform3D(Basis(Vector3.RIGHT, PI), Vector3(0, 0, 0)), radius, 0.0, half_height * 0.75, 6, Color.WHITE, Color.WHITE, false, false, false)
	st.set_material(get_material("crystal"))
	return st.commit()

static func make_crop_field(width: float, depth: float) -> Node3D:
	var root := Node3D.new()
	root.name = "CropField"
	var b := MeshBatch.new()
	MeshKit.box_at(b.surface("soil"), Vector3(0, 0.03, 0), Vector3(width, 0.12, depth), Color(0.7, 0.7, 0.7), Color.WHITE)
	var rows: int = int(depth / 1.1)
	for r in range(rows):
		var z: float = -depth * 0.5 + 0.7 + float(r) * 1.1
		MeshKit.box_at(b.surface("soil"), Vector3(0, 0.14, z), Vector3(width - 0.4, 0.14, 0.55), Color.WHITE, Color(1.15, 1.15, 1.15))
	var body := StaticBody3D.new()
	var mi := MeshInstance3D.new()
	mi.mesh = b.commit(BuildingKit.get_material)
	body.add_child(mi)
	body.collision_layer = Constants.LAYER_WORLD
	root.add_child(body)
	var xs: Array[Transform3D] = []
	var ts := PackedColorArray()
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for r in range(rows):
		var z2: float = -depth * 0.5 + 0.7 + float(r) * 1.1
		var x: float = -width * 0.5 + 0.7
		while x < width * 0.5 - 0.5:
			var sc: float = rng.randf_range(0.9, 1.35)
			xs.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * sc), Vector3(x, 0.2, z2)))
			var v: float = rng.randf_range(0.85, 1.2)
			ts.append(Color(v, v, v, 1))
			x += 0.75
	var crops: MultiMeshInstance3D = VegetationKit.make_multimesh("crop", xs, ts, 120.0, false)
	root.add_child(crops)
	return root

# ---------------------------------------------------------------------------
# Arcane Spire (origin = centre of the courtyard, on the plateau)
# ---------------------------------------------------------------------------
static func _arcane_windows(b: MeshBatch, y: float, radius: float, count: int, skip_gate: bool) -> void:
	var glass: SurfaceTool = b.surface("arcane")
	var wood: SurfaceTool = b.surface("stone")
	for i in range(count):
		var a: float = TAU * (float(i) + 0.5) / float(count)
		if skip_gate and absf(angle_difference(a, PI * 0.5)) < 0.5:
			continue
		var base := Transform3D(Basis(Vector3.UP, PI * 0.5 - a), Vector3(cos(a) * radius, y, sin(a) * radius))
		_bx(wood, base, Vector3(0, 0, 0.0), Vector3(0.95, 1.75, 0.3))
		_bx(glass, base, Vector3(0, 0, 0.1), Vector3(0.6, 1.4, 0.2))

static func make_spire() -> Node3D:
	var root := Node3D.new()
	root.name = "SpireBuildings"
	var b := MeshBatch.new()
	var stone: SurfaceTool = b.surface("stone_blue")
	var trim: SurfaceTool = b.surface("stone")
	var roof: SurfaceTool = b.surface("roof_blue")
	var gold: SurfaceTool = b.surface("gold")
	var shapes: Array = []
	var dk := Color(0.7, 0.7, 0.7)

	# Courtyard paving
	MeshKit.cylinder_at(b.surface("cobble_blue"), Vector3(0, -0.4, 0), 15.6, 15.6, 0.48, 40)

	# Main tower: three tiers, balconies, cone roof, finial
	MeshKit.cylinder_at(stone, Vector3(0, 0, 0), 5.2, 4.5, 9.0, 18, dk, Color.WHITE)
	MeshKit.cylinder_at(trim, Vector3(0, 9.0, 0), 5.7, 5.7, 0.45, 18)
	MeshKit.cylinder_at(stone, Vector3(0, 9.45, 0), 3.8, 3.3, 7.0, 16)
	MeshKit.cylinder_at(trim, Vector3(0, 16.45, 0), 4.3, 4.3, 0.4, 16)
	MeshKit.cylinder_at(stone, Vector3(0, 16.85, 0), 2.5, 2.2, 5.2, 14)
	MeshKit.cylinder_at(trim, Vector3(0, 22.05, 0), 3.1, 3.1, 0.35, 14)
	MeshKit.cylinder_at(roof, Vector3(0, 22.4, 0), 3.0, 0.0, 7.5, 14, Color.WHITE, Color.WHITE, false)
	MeshKit.cylinder_at(gold, Vector3(0, 29.8, 0), 0.06, 0.03, 1.6, 6)
	MeshKit.blob(gold, Vector3(0, 29.9, 0), Vector3(0.28, 0.28, 0.28), RandomNumberGenerator.new(), Color.WHITE, Color.WHITE, 0.0, 8, 6, 0.0)
	# crenellations on the first balcony
	for i in range(18):
		var a: float = TAU * float(i) / 18.0
		var xf := Transform3D(Basis(Vector3.UP, -(a + PI * 0.5)), Vector3(cos(a) * 5.45, 9.45 + 0.35, sin(a) * 5.45))
		MeshKit.box(trim, xf, Vector3(1.0, 0.7, 0.45))
	_arcane_windows(b, 4.2, 4.9, 7, true)
	_arcane_windows(b, 12.4, 3.6, 6, false)
	_arcane_windows(b, 19.2, 2.3, 5, false)
	# Great doors
	var door := Transform3D(Basis.IDENTITY, Vector3(0, 0, 5.0))
	_bx(b.surface("wood_dark"), door, Vector3(0, 1.8, 0.1), Vector3(2.9, 3.8, 0.5))
	_bx(b.surface("wood"), door, Vector3(0, 1.7, 0.3), Vector3(2.4, 3.4, 0.2))
	_bx(gold, door, Vector3(0, 1.8, 0.45), Vector3(0.12, 0.3, 0.08))
	shapes.append(_cyl_shape(5.0, 22.0, Vector3(0, 11.0, 0)))

	# Wings with towers + connecting halls
	for s in [-1.0, 1.0]:
		var wc := Vector3(s * 11.5, 0, -5.0)
		MeshKit.cylinder_at(stone, wc, 2.7, 2.4, 10.5, 14, dk, Color.WHITE)
		MeshKit.cylinder_at(trim, wc + Vector3(0, 10.5, 0), 3.2, 3.2, 0.35, 14)
		MeshKit.cylinder_at(roof, wc + Vector3(0, 10.85, 0), 3.2, 0.0, 5.5, 14, Color.WHITE, Color.WHITE, false)
		MeshKit.cylinder_at(gold, wc + Vector3(0, 16.2, 0), 0.05, 0.03, 1.1, 6)
		_arcane_windows_at(b, wc, 5.0, 2.55, 4)
		_arcane_windows_at(b, wc, 8.6, 2.45, 4)
		shapes.append(_cyl_shape(2.7, 10.5, wc + Vector3(0, 5.25, 0)))
		# hall
		var hall := Vector3(s * 6.6, 0, -2.4)
		MeshKit.box_at(stone, hall + Vector3(0, 2.4, 0), Vector3(5.2, 4.8, 4.2), dk, Color.WHITE)
		MeshKit.box_at(trim, hall + Vector3(0, 4.95, 0), Vector3(5.6, 0.4, 4.6))
		for k in range(5):
			MeshKit.box_at(trim, hall + Vector3(-2.2 + float(k) * 1.1, 5.4, 2.2), Vector3(0.7, 0.6, 0.4))
		_bx(b.surface("arcane"), Transform3D(Basis.IDENTITY, hall + Vector3(0, 0, 2.1)), Vector3(-1.2, 2.8, 0.05), Vector3(0.8, 1.6, 0.15))
		_bx(b.surface("arcane"), Transform3D(Basis.IDENTITY, hall + Vector3(0, 0, 2.1)), Vector3(1.2, 2.8, 0.05), Vector3(0.8, 1.6, 0.15))
		shapes.append(_box_shape(Vector3(5.2, 4.8, 4.2), hall + Vector3(0, 2.4, 0)))

	# Courtyard wall ring with a gate at +Z
	var segs: int = 30
	for i in range(segs):
		var a2: float = TAU * (float(i) + 0.5) / float(segs)
		if absf(angle_difference(a2, PI * 0.5)) < 0.2:
			continue
		var cpos := Vector3(cos(a2) * 15.0, 0.0, sin(a2) * 15.0)
		var yaw: float = -(a2 + PI * 0.5)
		var xf2 := Transform3D(Basis(Vector3.UP, yaw), cpos + Vector3(0, 0.9, 0))
		MeshKit.box(stone, xf2, Vector3(3.2, 1.8, 0.75), dk, Color.WHITE)
		MeshKit.box(trim, Transform3D(Basis(Vector3.UP, yaw), cpos + Vector3(0, 1.85, 0)), Vector3(3.3, 0.18, 0.95))
		var tangent := Vector3(-sin(a2), 0, cos(a2))
		for off in [-0.9, 0.9]:
			MeshKit.box(trim, Transform3D(Basis(Vector3.UP, yaw), cpos + tangent * off + Vector3(0, 2.25, 0)), Vector3(0.9, 0.62, 0.62))
		shapes.append(_box_shape(Vector3(3.2, 1.8, 0.75), cpos + Vector3(0, 0.9, 0), yaw))
	for s2 in [-1.0, 1.0]:
		var gp := Vector3(s2 * 2.6, 0, 15.0)
		MeshKit.cylinder_at(stone, gp, 0.85, 0.7, 5.6, 10, dk, Color.WHITE)
		MeshKit.cylinder_at(trim, gp + Vector3(0, 5.6, 0), 1.05, 1.05, 0.3, 10)
		MeshKit.cylinder_at(roof, gp + Vector3(0, 5.9, 0), 1.15, 0.0, 1.6, 10, Color.WHITE, Color.WHITE, false)
		shapes.append(_cyl_shape(0.85, 5.6, gp + Vector3(0, 2.8, 0)))
	MeshKit.box_at(stone, Vector3(0, 5.1, 15.0), Vector3(4.4, 1.0, 1.0), dk, Color.WHITE)
	MeshKit.box_at(b.surface("arcane"), Vector3(0, 5.1, 15.55), Vector3(1.2, 0.5, 0.12))
	root.add_child(_finish(b, shapes, "Body"))

	# Braziers by the gate
	for s3 in [-1.0, 1.0]:
		var bb := MeshBatch.new()
		MeshKit.cylinder_at(bb.surface("stone"), Vector3.ZERO, 0.35, 0.28, 1.0, 8)
		MeshKit.cylinder_at(bb.surface("iron"), Vector3(0, 1.0, 0), 0.34, 0.5, 0.3, 10)
		var br: StaticBody3D = _finish(bb, [_cyl_shape(0.4, 1.3, Vector3(0, 0.65, 0))], "Brazier")
		br.position = Vector3(s3 * 5.2, 0, 17.5)
		root.add_child(br)
		VFX.fire(br, Vector3(0, 1.35, 0), 1.3)
		add_light(br, Vector3(0, 1.8, 0), Color(1.0, 0.55, 0.2), 3.0, 14.0, 0.25)

	# Floating guardian crystal above the tower
	var core := AmbientMotion.new()
	core.name = "CoreCrystal"
	core.position = Vector3(0, 36.5, 0)
	core.spin_speed = 0.35
	core.bob_height = 0.6
	core.bob_speed = 0.9
	var cm := MeshInstance3D.new()
	cm.mesh = make_crystal_mesh(1.3, 2.4)
	core.add_child(cm)
	root.add_child(core)
	var orbit := AmbientMotion.new()
	orbit.name = "Orbit"
	orbit.position = Vector3(0, 36.5, 0)
	orbit.spin_speed = -0.6
	root.add_child(orbit)
	for i in range(6):
		var ang: float = TAU * float(i) / 6.0
		var mi := MeshInstance3D.new()
		mi.mesh = make_crystal_mesh(0.28, 0.55)
		mi.position = Vector3(cos(ang) * 4.2, sin(ang * 3.0) * 0.8, sin(ang) * 4.2)
		orbit.add_child(mi)
	add_light(root, Vector3(0, 36.5, 0), Color(0.45, 0.6, 1.0), 4.0, 60.0, 0.0, true)
	add_light(root, Vector3(0, 6.0, 9.0), Color(0.55, 0.45, 1.0), 2.5, 24.0, 0.0, true)
	return root

static func _arcane_windows_at(b: MeshBatch, center: Vector3, y: float, radius: float, count: int) -> void:
	var glass: SurfaceTool = b.surface("arcane")
	var trim: SurfaceTool = b.surface("stone")
	for i in range(count):
		var a: float = TAU * (float(i) + 0.25) / float(count)
		var base := Transform3D(Basis(Vector3.UP, PI * 0.5 - a), center + Vector3(cos(a) * radius, y, sin(a) * radius))
		_bx(trim, base, Vector3.ZERO, Vector3(0.8, 1.6, 0.28))
		_bx(glass, base, Vector3(0, 0, 0.09), Vector3(0.5, 1.25, 0.2))


# ---------------------------------------------------------------------------
# Smithy (open-fronted shed, +Z is the open side) and alchemy table
# ---------------------------------------------------------------------------
static func make_smithy() -> Node3D:
	var root := Node3D.new()
	root.name = "Smithy"
	var b := MeshBatch.new()
	var stone: SurfaceTool = b.surface("stone")
	var wood: SurfaceTool = b.surface("wood_dark")
	var wood_l: SurfaceTool = b.surface("wood")
	var roof: SurfaceTool = b.surface("roof_brown")
	var iron: SurfaceTool = b.surface("iron")
	var shapes: Array = []
	var dk := Color(0.65, 0.65, 0.65)

	MeshKit.box_at(b.surface("cobble"), Vector3(0, -0.05, 0), Vector3(6.8, 0.3, 5.8))
	# walls: full back wall, half side walls
	MeshKit.box_at(stone, Vector3(0, 1.6, -2.6), Vector3(6.4, 3.2, 0.5), dk, Color.WHITE)
	shapes.append(_box_shape(Vector3(6.4, 3.2, 0.5), Vector3(0, 1.6, -2.6)))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(stone, Vector3(sx * 3.05, 0.65, -0.3), Vector3(0.5, 1.3, 4.4), dk, Color.WHITE)
		shapes.append(_box_shape(Vector3(0.5, 1.3, 4.4), Vector3(sx * 3.05, 0.65, -0.3)))
		MeshKit.box_at(wood, Vector3(sx * 3.05, 1.6, 2.4), Vector3(0.3, 3.2, 0.3))
		MeshKit.box_at(wood, Vector3(sx * 3.05, 2.05, -0.3), Vector3(0.28, 2.1, 0.28))
		shapes.append(_cyl_shape(0.2, 3.2, Vector3(sx * 3.05, 1.6, 2.4)))
	MeshKit.box_at(wood, Vector3(0, 3.1, 2.4), Vector3(6.5, 0.3, 0.3))
	# roof (ridge along X)
	var ang: float = 0.5
	var half: float = 3.1
	var rise: float = half * tan(ang)
	var slab: float = half / cos(ang) + 0.1
	for sgn in [-1.0, 1.0]:
		var bas := Basis(Vector3.RIGHT, sgn * ang)
		var nrm: Vector3 = bas * Vector3.UP
		MeshKit.box(roof, Transform3D(bas, Vector3(0, 3.2 + rise * 0.5, sgn * half * 0.5 - 0.1) + nrm * 0.08), Vector3(7.4, 0.18, slab))
	MeshKit.box_at(wood, Vector3(0, 3.2 + rise + 0.05, -0.1), Vector3(7.4, 0.2, 0.4))
	# gable ends
	for sx2 in [-1.0, 1.0]:
		MeshKit.flat_tri(wood_l, Vector3(sx2 * 3.2, 3.2, -3.0), Vector3(sx2 * 3.2, 3.2, 3.0), Vector3(sx2 * 3.2, 3.2 + rise * 0.95, 0),
			Vector3(sx2, 0, 0), Color.WHITE, Color.WHITE, Color.WHITE, Vector2(0, 0), Vector2(6, 0), Vector2(3, rise))

	# forge (back right) with chimney through the roof
	MeshKit.box_at(stone, Vector3(1.5, 0.6, -1.6), Vector3(2.0, 1.2, 1.4), dk, Color.WHITE)
	MeshKit.box_at(stone, Vector3(1.5, 1.35, -1.8), Vector3(1.6, 0.3, 1.0))
	MeshKit.box_at(stone, Vector3(1.5, 3.3, -2.15), Vector3(0.8, 4.6, 0.8), dk, Color.WHITE)
	MeshKit.box_at(stone, Vector3(1.5, 5.65, -2.15), Vector3(1.0, 0.16, 1.0))
	MeshKit.box_at(b.surface("lantern"), Vector3(1.5, 0.75, -0.88), Vector3(1.1, 0.5, 0.06))
	MeshKit.box_at(iron, Vector3(1.5, 1.52, -1.8), Vector3(1.8, 0.06, 1.2))
	shapes.append(_box_shape(Vector3(2.0, 1.4, 1.4), Vector3(1.5, 0.7, -1.6)))
	# bellows + coal
	MeshKit.box_at(wood_l, Vector3(2.9, 0.5, -1.0), Vector3(0.5, 0.4, 0.7))
	var rng := RandomNumberGenerator.new()
	rng.seed = 21
	for i in range(8):
		MeshKit.blob(iron, Vector3(0.2 + rng.randf() * 0.6, 0.1, -1.8 + rng.randf() * 0.6), Vector3(0.14, 0.1, 0.14), rng, Color.WHITE, Color.WHITE, 0.3, 5, 3)
	# anvil on a stump
	MeshKit.cylinder_at(wood_l, Vector3(-0.4, 0.0, -0.2), 0.36, 0.3, 0.55, 8)
	MeshKit.box_at(iron, Vector3(-0.4, 0.66, -0.2), Vector3(0.36, 0.2, 0.8))
	MeshKit.box_at(iron, Vector3(-0.4, 0.82, -0.2), Vector3(0.3, 0.12, 0.55))
	MeshKit.box_at(iron, Vector3(-0.4, 0.76, 0.34), Vector3(0.14, 0.1, 0.3))
	shapes.append(_cyl_shape(0.45, 0.9, Vector3(-0.4, 0.45, -0.2)))
	# weapon rack on the back wall
	MeshKit.box_at(wood, Vector3(-1.6, 1.7, -2.28), Vector3(2.2, 0.12, 0.1))
	MeshKit.box_at(wood, Vector3(-1.6, 1.2, -2.28), Vector3(2.2, 0.12, 0.1))
	for i in range(4):
		MeshKit.box_at(iron, Vector3(-2.4 + float(i) * 0.55, 1.5, -2.22), Vector3(0.07, 1.0, 0.02))
		MeshKit.box_at(b.surface("gold"), Vector3(-2.4 + float(i) * 0.55, 1.05, -2.22), Vector3(0.22, 0.04, 0.04))
	# tool shelf shadow-box & hanging lanterns
	for sx3 in [-1.0, 1.0]:
		MeshKit.box_at(b.surface("lantern"), Vector3(sx3 * 3.05, 2.5, 2.55), Vector3(0.22, 0.34, 0.22))
	root.add_child(_finish(b, shapes, "Body"))
	var barrel: Node3D = make_barrel()
	barrel.position = Vector3(-2.3, 0, -1.7)
	root.add_child(barrel)
	VFX.fire(root, Vector3(1.5, 0.75, -1.2), 1.1)
	VFX.smoke(root, Vector3(1.5, 5.9, -2.15))
	add_light(root, Vector3(1.5, 1.1, -0.6), Color(1.0, 0.55, 0.2), 3.0, 12.0, 0.0, true)
	add_light(root, Vector3(-3.05, 2.4, 2.6), Color(1.0, 0.7, 0.35), 1.8, 9.0, 0.06)
	return root

static func make_alchemy_table() -> Node3D:
	var root := Node3D.new()
	root.name = "AlchemyTable"
	var b := MeshBatch.new()
	var wood: SurfaceTool = b.surface("wood")
	var dk: SurfaceTool = b.surface("wood_dark")
	var rng := RandomNumberGenerator.new()
	rng.seed = 33
	MeshKit.box_at(wood, Vector3(0, 0.45, 0), Vector3(2.4, 0.9, 1.0), Color(0.7, 0.7, 0.7), Color.WHITE)
	MeshKit.box_at(dk, Vector3(0, 0.93, 0), Vector3(2.5, 0.08, 1.1))
	# shelf behind
	MeshKit.box_at(dk, Vector3(0, 1.9, -0.6), Vector3(2.4, 0.08, 0.35))
	for sx in [-1.0, 1.0]:
		MeshKit.box_at(dk, Vector3(sx * 1.15, 1.2, -0.6), Vector3(0.1, 2.4, 0.1))
	var names: Array[String] = ["potion", "potion_blue", "potion_red", "potion", "potion_blue"]
	for i in range(5):
		var m: String = names[i]
		MeshKit.blob(b.surface(m), Vector3(-0.9 + float(i) * 0.45, 1.1, 0.15 - float(i % 2) * 0.25), Vector3(0.1, 0.14, 0.1), rng, Color.WHITE, Color.WHITE, 0.05, 7, 4)
		MeshKit.cylinder_at(b.surface("wood"), Vector3(-0.9 + float(i) * 0.45, 1.22, 0.15 - float(i % 2) * 0.25), 0.03, 0.03, 0.1, 6)
	for i in range(4):
		MeshKit.blob(b.surface(names[(i + 2) % 5]), Vector3(-0.8 + float(i) * 0.55, 2.05, -0.6), Vector3(0.09, 0.12, 0.09), rng, Color.WHITE, Color.WHITE, 0.05, 6, 4)
	MeshKit.cylinder_at(b.surface("stone"), Vector3(0.95, 0.97, 0.1), 0.14, 0.1, 0.12, 8)   # mortar
	MeshKit.box_at(b.surface("cloth_red"), Vector3(0.4, 0.99, 0.3), Vector3(0.3, 0.04, 0.22))   # book
	# cauldron beside the table
	MeshKit.cylinder_at(b.surface("iron"), Vector3(1.9, 0.0, 0.2), 0.5, 0.72, 0.85, 12)
	MeshKit.cylinder_at(b.surface("potion"), Vector3(1.9, 0.78, 0.2), 0.62, 0.62, 0.04, 12)
	for sx2 in [-1.0, 1.0]:
		MeshKit.box_at(b.surface("iron"), Vector3(1.9 + sx2 * 0.45, 0.2, 0.2 + sx2 * 0.45), Vector3(0.08, 0.4, 0.08))
	var body: StaticBody3D = _finish(b, [_box_shape(Vector3(2.5, 0.95, 1.1), Vector3(0, 0.47, 0)), _cyl_shape(0.7, 0.9, Vector3(1.9, 0.45, 0.2))], "Body")
	root.add_child(body)
	var bub: CPUParticles3D = VFX.fountain_spray(root, Vector3(1.9, 0.85, 0.2))
	bub.amount = 14
	bub.initial_velocity_min = 0.5
	bub.initial_velocity_max = 1.1
	bub.spread = 30.0
	bub.gravity = Vector3(0, -2.5, 0)
	bub.color = Color(0.4, 1.0, 0.55, 0.9)
	add_light(root, Vector3(1.9, 1.3, 0.2), Color(0.35, 1.0, 0.5), 0.9, 6.0, 0.08, true)
	return root
