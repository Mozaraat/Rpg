extends Node

## Shared-world persistence boundary.
## Development sessions may use an atomic local JSON snapshot. Production
## authoritative servers hydrate and commit section/key entities through PostgreSQL.

const SCHEMA_VERSION: int = 1
const WORLD_FILE: String = "user://mmorpg_world_state.json"
const CHARACTER_DIR: String = "user://mmorpg_characters"
const CENTRAL_ENTITY_KIND: String = "world_state"
const CENTRAL_RETRY_SECONDS: float = 5.0

var world_id: String = "eternal-realms-one-world"
var revision: int = 0
var world_state: Dictionary = {}
var central_hydration_complete: bool = false
var central_hydration_error: String = ""

var _loaded: bool = false
var _central_entity_revisions: Dictionary = {}
var _pending_central_writes: Dictionary = {}
var _central_flush_running: bool = false
var _central_retry_clock: float = 0.0
var _replication_dirty: bool = false
var _replication_clock: float = 0.0
var _last_replicated_revision: int = -1

func _ready() -> void:
	load_world_state()

func _process(delta: float) -> void:
	if MMORPGNetwork.is_online() and multiplayer.is_server() and _replication_dirty:
		_replication_clock += delta
		if _replication_clock >= 0.5:
			_replication_clock = 0.0
			_replication_dirty = false
			if revision != _last_replicated_revision:
				MMORPGNetwork.broadcast_shared_world_state()
				_last_replicated_revision = revision
	if not WorldDeploymentGuard.production_mode or _pending_central_writes.is_empty() or _central_flush_running:
		return
	_central_retry_clock -= delta
	if _central_retry_clock <= 0.0:
		_central_retry_clock = CENTRAL_RETRY_SECONDS
		_flush_central_writes()

## Must complete after the global lease is acquired and before the server listens.
## A failed read is fatal: never boot a production world from stale local JSON.
func hydrate_central_world_entities() -> bool:
	if not WorldDeploymentGuard.production_mode:
		central_hydration_complete = true
		return true
	if not CentralBackend.is_configured():
		central_hydration_error = "Central HTTPS backend is not configured."
		return false
	var response: Dictionary = await CentralBackend.server_load_world_entities(CENTRAL_ENTITY_KIND)
	if not bool(response.get("ok", false)):
		central_hydration_error = str(response.get("error", response.get("status", "World-state hydration failed")))
		push_error("[MMORPGWorldState] Central hydration failed: %s" % central_hydration_error)
		return false
	var body: Dictionary = response.get("body", {})
	var entities: Variant = body.get("entities", [])
	if not entities is Array:
		central_hydration_error = "Backend returned an invalid world entity collection."
		return false
	world_state = {"regions": {}, "territories": {}, "economy": {}, "campaigns": {}}
	_central_entity_revisions.clear()
	_pending_central_writes.clear()
	revision = 0
	for entity_variant in entities:
		if not entity_variant is Dictionary:
			continue
		var entity: Dictionary = entity_variant
		var entity_id: String = str(entity.get("entity_id", ""))
		var entity_revision: int = int(entity.get("revision", 0))
		var state_variant: Variant = entity.get("entity_state", {})
		if entity_id.is_empty() or not state_variant is Dictionary:
			continue
		var state: Dictionary = state_variant
		var section: String = str(state.get("section", ""))
		var key: String = str(state.get("key", ""))
		if section.is_empty() or key.is_empty() or not state.has("value"):
			continue
		if not world_state.has(section):
			world_state[section] = {}
		if not world_state[section] is Dictionary:
			continue
		var section_state: Dictionary = world_state[section]
		section_state[key] = _deep_copy(state["value"])
		world_state[section] = section_state
		_central_entity_revisions[entity_id] = entity_revision
		revision = maxi(revision, entity_revision)
	world_id = MMORPGNetwork.SINGLE_WORLD_ID
	_loaded = true
	central_hydration_error = ""
	central_hydration_complete = true
	return true

func load_world_state() -> bool:
	if WorldDeploymentGuard.production_mode:
		# Production data is populated only by hydrate_central_world_entities().
		world_state = {"regions": {}, "territories": {}, "economy": {}, "campaigns": {}}
		revision = 0
		_loaded = true
		return true
	if not FileAccess.file_exists(WORLD_FILE):
		world_state = {"regions": {}, "territories": {}, "economy": {}, "campaigns": {}}
		revision = 0
		_loaded = true
		return true
	var file := FileAccess.open(WORLD_FILE, FileAccess.READ)
	if file == null:
		push_error("[MMORPGWorldState] Cannot read world state: %s" % FileAccess.get_open_error())
		return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("[MMORPGWorldState] Invalid world-state JSON")
		return false
	var payload: Dictionary = parsed
	if int(payload.get("schema_version", -1)) != SCHEMA_VERSION:
		push_error("[MMORPGWorldState] Unsupported world-state schema")
		return false
	world_id = MMORPGNetwork.SINGLE_WORLD_ID
	revision = int(payload.get("revision", 0))
	world_state = payload.get("state", {}) as Dictionary
	_loaded = true
	return true

func get_world_value(section: String, key: String, fallback: Variant = null) -> Variant:
	var section_value: Variant = world_state.get(section, {})
	if typeof(section_value) != TYPE_DICTIONARY:
		return fallback
	var section_data: Dictionary = section_value
	return section_data.get(key, fallback)

func set_world_value(section: String, key: String, value: Variant) -> bool:
	return commit_world_changes([{"section": section, "key": key, "value": value}])

## Applies related changes to the in-memory snapshot. Production changes are
## queued as independent revisioned PostgreSQL entities and retried on failure.
func commit_world_changes(changes: Array) -> bool:
	if not _can_commit() or changes.is_empty():
		return false
	var previous_state: Dictionary = world_state.duplicate(true)
	var previous_revision: int = revision
	var next_state: Dictionary = world_state.duplicate(true)
	var validated: Array[Dictionary] = []
	for change_variant in changes:
		if typeof(change_variant) != TYPE_DICTIONARY:
			return false
		var change: Dictionary = change_variant
		var section: String = str(change.get("section", ""))
		var key: String = str(change.get("key", ""))
		if section.is_empty() or key.is_empty() or not change.has("value"):
			return false
		if not next_state.has(section):
			next_state[section] = {}
		if typeof(next_state[section]) != TYPE_DICTIONARY:
			return false
		var section_data: Dictionary = next_state[section]
		section_data[key] = _deep_copy(change["value"])
		next_state[section] = section_data
		validated.append({"section": section, "key": key, "value": _deep_copy(change["value"])})
	world_state = next_state
	revision += 1
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		_replication_dirty = true
	if WorldDeploymentGuard.production_mode:
		for change in validated:
			_queue_central_entity_write(str(change["section"]), str(change["key"]), change["value"])
		if not _central_flush_running:
			_flush_central_writes()
		return true
	if save_world_state():
		return true
	world_state = previous_state
	revision = previous_revision
	return false

func save_world_state() -> bool:
	if WorldDeploymentGuard.production_mode:
		return false
	if not _can_commit():
		return false
	var directory: String = ProjectSettings.globalize_path(WORLD_FILE.get_base_dir())
	if not DirAccess.dir_exists_absolute(directory):
		DirAccess.make_dir_recursive_absolute(directory)
	var payload := {
		"schema_version": SCHEMA_VERSION,
		"world_id": world_id,
		"revision": revision,
		"saved_at_unix": Time.get_unix_time_from_system(),
		"state": world_state
	}
	var temporary_path: String = WORLD_FILE + ".tmp"
	var file := FileAccess.open(temporary_path, FileAccess.WRITE)
	if file == null:
		push_error("[MMORPGWorldState] Cannot write temporary state file")
		return false
	file.store_string(JSON.stringify(payload, "\t"))
	file.flush()
	file.close()
	var absolute_temp: String = ProjectSettings.globalize_path(temporary_path)
	var absolute_final: String = ProjectSettings.globalize_path(WORLD_FILE)
	if FileAccess.file_exists(WORLD_FILE):
		var remove_error: Error = DirAccess.remove_absolute(absolute_final)
		if remove_error != OK:
			push_error("[MMORPGWorldState] Could not replace previous world state")
			return false
	var rename_error: Error = DirAccess.rename_absolute(absolute_temp, absolute_final)
	if rename_error != OK:
		push_error("[MMORPGWorldState] State file replacement failed: %s" % error_string(rename_error))
		return false
	return true

func save_character_snapshot(character_id: String, snapshot: Dictionary) -> bool:
	if not _can_commit() or character_id.strip_edges().is_empty():
		return false
	if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(CHARACTER_DIR)):
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(CHARACTER_DIR))
	var safe_id: String = character_id.validate_filename()
	var path: String = CHARACTER_DIR.path_join(safe_id + ".json")
	var file := FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify({"schema_version": SCHEMA_VERSION, "character_id": safe_id, "saved_at_unix": Time.get_unix_time_from_system(), "snapshot": snapshot}, "\t"))
	file.flush()
	file.close()
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	return DirAccess.rename_absolute(ProjectSettings.globalize_path(path + ".tmp"), ProjectSettings.globalize_path(path)) == OK

func _queue_central_entity_write(section: String, key: String, value: Variant) -> void:
	var entity_id: String = _stable_entity_uuid(section, key)
	var entity_revision: int = int(_central_entity_revisions.get(entity_id, 0))
	if _pending_central_writes.has(entity_id):
		entity_revision = int(_pending_central_writes[entity_id].get("revision", entity_revision))
	_pending_central_writes[entity_id] = {
		"entity_id": entity_id,
		"entity_kind": CENTRAL_ENTITY_KIND,
		"region_id": section,
		"revision": entity_revision,
		"entity_state": {"section": section, "key": key, "value": _deep_copy(value)}
	}

func _flush_central_writes() -> void:
	if _central_flush_running or not WorldDeploymentGuard.production_mode or not MMORPGNetwork.server_mode:
		return
	_central_flush_running = true
	while not _pending_central_writes.is_empty():
		var entity_id: String = str(_pending_central_writes.keys()[0])
		var entry: Dictionary = _pending_central_writes[entity_id].duplicate(true)
		_pending_central_writes.erase(entity_id)
		var result: Dictionary = await CentralBackend.server_save_world_entity(
			entity_id,
			str(entry["entity_kind"]),
			str(entry["region_id"]),
			int(entry["revision"]),
			entry["entity_state"]
		)
		if not bool(result.get("ok", false)):
			if not _pending_central_writes.has(entity_id):
				_pending_central_writes[entity_id] = entry
			push_warning("[MMORPGWorldState] Central entity write queued for retry: %s" % str(result.get("error", result.get("status", "unknown"))))
			_central_retry_clock = CENTRAL_RETRY_SECONDS
			break
		var response_body: Dictionary = result.get("body", {})
		var next_revision: int = int(response_body.get("revision", int(entry["revision"]) + 1))
		_central_entity_revisions[entity_id] = next_revision
		if _pending_central_writes.has(entity_id):
			var newer: Dictionary = _pending_central_writes[entity_id]
			newer["revision"] = next_revision
			_pending_central_writes[entity_id] = newer
	_central_flush_running = false

func _stable_entity_uuid(section: String, key: String) -> String:
	var digest: String = (MMORPGNetwork.SINGLE_WORLD_ID + "|" + section + "|" + key).md5_text()
	return "%s-%s-%s-%s-%s" % [digest.substr(0, 8), digest.substr(8, 4), digest.substr(12, 4), digest.substr(16, 4), digest.substr(20, 12)]

func _deep_copy(value: Variant) -> Variant:
	if value is Dictionary or value is Array:
		return value.duplicate(true)
	return value

func _can_commit() -> bool:
	if WorldDeploymentGuard.production_mode:
		return central_hydration_complete and MMORPGNetwork.server_mode
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		return false
	return true

## Sends a complete revisioned world snapshot to a newly authenticated peer.
func send_snapshot_to_peer(peer_id: int) -> void:
	if MMORPGNetwork.is_online() and multiplayer.is_server() and peer_id > 1:
		MMORPGNetwork.send_shared_world_state_to_peer(peer_id)

## Explicitly drains queued central writes; deployment shutdown should await this.
func flush_central_writes() -> bool:
	if not WorldDeploymentGuard.production_mode:
		return true
	if _central_flush_running:
		while _central_flush_running:
			await get_tree().process_frame
		return _pending_central_writes.is_empty()
	if _pending_central_writes.is_empty():
		return true
	await _flush_central_writes()
	return _pending_central_writes.is_empty()
