# Living settlements: progress Elyndor toward a city, spawn extra villagers, found new villages.
extends Node
class_name SettlementGrowth

signal settlement_leveled(settlement_id: String, new_level: int, title: String)
signal village_founded(settlement_id: String, display_name: String)

const LEVEL_TITLES := ["Camp", "Hamlet", "Village", "Town", "City"]
# progress thresholds to reach level 1..4
const THRESHOLDS := [0, 40, 120, 280, 520]

const VILLAGER_NAMES := [
	"Renn", "Sola", "Piet", "Anya", "Dorn", "Lina", "Hale", "Tessa",
	"Maro", "Ivy", "Cade", "Nessa", "Jori", "Wren", "Finn", "Kira"
]
const VILLAGER_ROLES := ["villager", "farmer", "merchant", "villager", "farmer"]

var noise: TerrainNoise
var settlements: Dictionary = {}  # id -> {name, level, progress, center, root_path, population}
var _tick: float = 0.0
var _found_sites: Array = []  # candidate Vector2 for new villages
var _applied_war_reports: Dictionary = {}

func _ready() -> void:
	add_to_group("settlement_growth")
	noise = TerrainNoise.new(GameManager.world_seed)
	await get_tree().process_frame
	await get_tree().process_frame
	_register_existing()
	_prepare_found_sites()

func _register_existing() -> void:
	settlements["elyndor"] = {
		"name": "Elyndor",
		"level": 2,  # starts as a Village
		"progress": 80.0,
		"center": TerrainNoise.VILLAGE_CENTER,
		"population": 5,
		"buildings": 0,
		"flood_protection": 0.15,
		"water_available_l": 0.0,
		"water_stress": 0.0,
		"flood_risk": 0.0,
	}
	settlements["arcane_spire"] = {
		"name": "Arcane Spire",
		"level": 1,
		"progress": 30.0,
		"center": TerrainNoise.SPIRE_CENTER,
		"population": 2,
		"buildings": 0,
		"flood_protection": 0.25,
		"water_available_l": 0.0,
		"water_stress": 0.0,
		"flood_risk": 0.0,
	}
	# Count named NPCs already in world
	var n: int = 0
	for node in get_tree().get_nodes_in_group("npc"):
		n += 1
	if n > 0:
		settlements["elyndor"]["population"] = maxi(5, n - 2)

func _prepare_found_sites() -> void:
	# New settlements are deliberately expedition-distance from existing towns.
	# Sites are sampled across the expanded mainland rather than clustered around Elyndor.
	var rng := RandomNumberGenerator.new()
	rng.seed = GameManager.world_seed + 404
	var anchors: Array[Vector2] = [TerrainNoise.VILLAGE_CENTER, TerrainNoise.SPIRE_CENTER]
	var accepted: Array[Vector2] = []
	var attempts := 0
	while accepted.size() < 8 and attempts < 900:
		attempts += 1
		var angle := rng.randf() * TAU
		var radius := rng.randf_range(300.0, 500.0)
		var candidate := TerrainNoise.VILLAGE_CENTER + Vector2(cos(angle), sin(angle)) * radius
		var h: float = noise.get_height(candidate.x, candidate.y)
		if h < 2.0 or h > 15.5:
			continue
		if noise.settlement_mask(candidate.x, candidate.y) > 0.08:
			continue
		if noise.get_path_amount(candidate.x, candidate.y) > 0.05:
			continue
		var dx := (noise.get_height(candidate.x + 2.0, candidate.y) - noise.get_height(candidate.x - 2.0, candidate.y)) / 4.0
		var dz := (noise.get_height(candidate.x, candidate.y + 2.0) - noise.get_height(candidate.x, candidate.y - 2.0)) / 4.0
		if sqrt(dx * dx + dz * dz) > 0.42:
			continue
		var spaced := true
		for anchor in anchors:
			if candidate.distance_to(anchor) < 260.0:
				spaced = false
				break
		for other in accepted:
			if candidate.distance_to(other) < 260.0:
				spaced = false
				break
		if not spaced:
			continue
		anchors.append(candidate)
		accepted.append(candidate)
	_found_sites.append_array(accepted)

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	_tick += delta
	if _tick < 8.0:
		return
	_tick = 0.0
	_passive_progress()
	_apply_sect_war_consequences()
	_recover_war_damaged_settlements()
	_apply_environmental_stress()
	_try_level_up("elyndor")
	_try_found_village()



func _apply_environmental_stress() -> void:
	# Settlements suffer when water is unsafe or flooding repeatedly damages low ground.
	for settlement_id in settlements.keys():
		var settlement: Dictionary = settlements[settlement_id]
		var flood := float(settlement.get("flood_risk", 0.0))
		var water_stress := float(settlement.get("water_stress", 0.0))
		var protection := clampf(float(settlement.get("flood_protection", 0.0)), 0.0, 0.9)
		var effective_flood := flood * (1.0 - protection)
		if effective_flood > 0.72:
			settlement["progress"] = maxf(0.0, float(settlement.get("progress", 0.0)) - effective_flood * 1.8)
			settlement["building_damage"] = clampf(float(settlement.get("building_damage", 0.0)) + effective_flood * 0.012, 0.0, 1.0)
		if water_stress > 0.75:
			settlement["population"] = maxi(0, int(settlement.get("population", 0)) - (1 if randf() < 0.04 else 0))
			settlement["progress"] = maxf(0.0, float(settlement.get("progress", 0.0)) - water_stress * 0.35)
		settlement["flood_protection"] = minf(0.9, protection + (0.00015 if int(settlement.get("level", 0)) >= 2 else 0.00005))
		settlements[settlement_id] = settlement

func invest_flood_protection(settlement_id: String, amount: float) -> bool:
	if not settlements.has(settlement_id) or amount <= 0.0:
		return false
	var settlement: Dictionary = settlements[settlement_id]
	settlement["flood_protection"] = clampf(float(settlement.get("flood_protection", 0.0)) + amount, 0.0, 0.9)
	settlements[settlement_id] = settlement
	return true

func _apply_sect_war_consequences() -> void:
	var sect_state: Dictionary = PlayerData.stats.get("sect_state", {})
	var reports: Array = sect_state.get("battle_reports", [])
	for report in reports:
		var report_id := str(report.get("time", 0)) + "::" + str(report.get("territory", ""))
		if _applied_war_reports.has(report_id):
			continue
		_applied_war_reports[report_id] = true
		var front: Vector2 = report.get("front_xz", Vector2(9999, 9999))
		for settlement_id in settlements.keys():
			var settlement: Dictionary = settlements[settlement_id]
			var center: Vector2 = settlement.get("center", Vector2.ZERO)
			if center.distance_to(front) > 78.0:
				continue
			settlement["population"] = maxi(0, int(settlement.get("population", 0)) - 1)
			settlement["progress"] = maxf(0.0, float(settlement.get("progress", 0.0)) - 10.0)
			settlement["war_unrest"] = mini(100, int(settlement.get("war_unrest", 0)) + 20)
			EventBus.activity.emit("The sect war near %s disrupted trade and displaced villagers" % str(settlement.get("name", settlement_id)), "world")
			EventBus.toast.emit("%s suffers from nearby sect warfare" % str(settlement.get("name", settlement_id)), "warning")


func _recover_war_damaged_settlements() -> void:
	# Peace gradually restores trade, confidence and civic development after a battle.
	for settlement_id in settlements.keys():
		var settlement: Dictionary = settlements[settlement_id]
		var unrest := int(settlement.get("war_unrest", 0))
		if unrest <= 0:
			continue
		settlement["war_unrest"] = maxi(0, unrest - 2)
		settlement["progress"] = minf(520.0, float(settlement.get("progress", 0.0)) + 0.8)
		if int(settlement["war_unrest"]) == 0:
			EventBus.activity.emit("%s has recovered from the sect war and trade is returning" % str(settlement.get("name", settlement_id)), "world")

func reward_war_relief(progress_amount: float) -> void:
	for settlement_id in settlements.keys():
		var settlement: Dictionary = settlements[settlement_id]
		settlement["war_unrest"] = maxi(0, int(settlement.get("war_unrest", 0)) - 15)
		settlement["progress"] = minf(520.0, float(settlement.get("progress", 0.0)) + progress_amount)
		settlement["population"] = int(settlement.get("population", 0)) + 1
		EventBus.activity.emit("Relief supplies helped rebuild %s" % str(settlement.get("name", settlement_id)), "world")
	EventBus.toast.emit("Settlement relief delivered: development and population restored", "success")

func add_progress(settlement_id: String, amount: float, reason: String = "") -> void:
	if not settlements.has(settlement_id):
		return
	settlements[settlement_id]["progress"] = float(settlements[settlement_id]["progress"]) + amount
	if reason != "" and amount >= 5.0:
		EventBus.activity.emit("%s grows (+%.0f progress)" % [settlements[settlement_id]["name"], amount], "world")
	_try_level_up(settlement_id)

func _passive_progress() -> void:
	# Villagers living their lives slowly advance the settlement
	var kills: int = int(PlayerData.stats.get("kills", 0))
	var gathered: int = int(PlayerData.stats.get("gathered", 0))
	var crafted: int = int(PlayerData.stats.get("crafted", 0))
	# Soft passive based on player activity totals
	var bonus: float = 0.4 + mini(float(kills) * 0.02, 2.0) + mini(float(gathered) * 0.01, 1.5)
	add_progress("elyndor", bonus * 0.15)
	if kills > 15:
		add_progress("arcane_spire", 0.08)

func _try_level_up(id: String) -> void:
	if not settlements.has(id):
		return
	var s: Dictionary = settlements[id]
	var lvl: int = int(s["level"])
	if lvl >= 4:
		return
	var need: float = float(THRESHOLDS[lvl + 1])
	if float(s["progress"]) < need:
		return
	s["level"] = lvl + 1
	var title: String = LEVEL_TITLES[int(s["level"])]
	settlement_leveled.emit(id, int(s["level"]), title)
	EventBus.toast.emit("%s is now a %s!" % [str(s["name"]), title], "levelup")
	EventBus.activity.emit("%s advanced to %s" % [str(s["name"]), title], "world")
	_expand_settlement(id)

func _expand_settlement(id: String) -> void:
	var s: Dictionary = settlements[id]
	var center: Vector2 = s["center"]
	var level: int = int(s["level"])
	var parent: Node = get_tree().current_scene
	if parent == null:
		return
	# Add houses
	var house_count: int = 1 + level
	for i in range(house_count):
		var a: float = randf() * TAU
		var r: float = 12.0 + float(level) * 4.0 + randf() * 8.0
		var p: Vector2 = center + Vector2(cos(a), sin(a)) * r
		var h: float = noise.get_height(p.x, p.y)
		if h < 1.2 or h > 11.0:
			continue
		var house: Node3D = BuildingKit.make_house(5.5 + randf(), 5.0 + randf(), 2.6, "plaster", "thatch", Color(0.85, 0.8, 0.7))
		house.position = Vector3(p.x, h, p.y)
		house.rotation.y = randf() * TAU
		parent.add_child(house)
		s["buildings"] = int(s["buildings"]) + 1
	# Add free-will villagers
	var new_folk: int = 2 + level
	for i in range(new_folk):
		_spawn_free_villager(center, str(s["name"]))
	s["population"] = int(s["population"]) + new_folk
	EventBus.toast.emit("%s gained homes and new villagers" % str(s["name"]), "info")

func _spawn_free_villager(center: Vector2, town_name: String) -> void:
	var parent: Node = get_tree().current_scene
	if parent == null:
		return
	var a: float = randf() * TAU
	var r: float = randf_range(4.0, 18.0)
	var p: Vector2 = center + Vector2(cos(a), sin(a)) * r
	var h: float = noise.get_height(p.x, p.y)
	var npc: NPC = preload("res://scenes/npc.tscn").instantiate()
	var nm: String = VILLAGER_NAMES[randi() % VILLAGER_NAMES.size()] + " of " + town_name.split(" ")[0]
	# Avoid exact duplicate names by suffix
	nm = VILLAGER_NAMES[randi() % VILLAGER_NAMES.size()] + " " + ["Ash", "Brook", "Hill", "Field", "Lane"][randi() % 5]
	npc.npc_name = nm
	npc.role = VILLAGER_ROLES[randi() % VILLAGER_ROLES.size()]
	npc.dialogue_lines = PackedStringArray([
		"Life in %s keeps moving." % town_name,
		"I walk where the day takes me.",
		"The settlement grows when we work together."
	])
	npc.free_will = true
	npc.home_center = Vector3(center.x, h, center.y)
	npc.wander_radius = 22.0
	# Light schedule around home so they still sleep
	var home_xz := Vector2(p.x, p.y)
	npc.schedule = [
		{"h": 6.0, "pos": home_xz + Vector2(randf_range(-4, 4), randf_range(-4, 4)), "sleep": false},
		{"h": 12.0, "pos": home_xz + Vector2(randf_range(-8, 8), randf_range(-8, 8)), "sleep": false},
		{"h": 18.0, "pos": center + Vector2(randf_range(-6, 6), randf_range(-6, 6)), "sleep": false},
		{"h": 21.0, "pos": home_xz, "sleep": true},
	]
	npc.position = Vector3(p.x, h + 0.1, p.y)
	parent.add_child(npc)

func _try_found_village() -> void:
	# After Elyndor becomes a Town (level 3), chance to found a new village
	if int(settlements.get("elyndor", {}).get("level", 0)) < 3:
		return
	if settlements.size() >= 5:
		return
	if _found_sites.is_empty():
		return
	if randf() > 0.12:
		return
	var site: Vector2 = _found_sites.pop_front()
	_found_new_village(site)

func _found_new_village(center: Vector2) -> void:
	# Re-check spacing at commit time; settlements must never appear as neighbouring hamlets.
	for existing in settlements.values():
		var existing_center: Vector2 = existing.get("center", Vector2.ZERO)
		if center.distance_to(existing_center) < 260.0:
			return
	var parent: Node = get_tree().current_scene
	if parent == null:
		return
	var names := ["Rivermead", "Oakwatch", "Goldhollow", "Mistford", "Stonebridge", "Windmere"]
	var used: Array = []
	for k in settlements.keys():
		used.append(str(settlements[k]["name"]))
	var display: String = names[randi() % names.size()]
	for n in names:
		if n not in used:
			display = n
			break
	var id: String = display.to_lower()
	var h: float = noise.get_height(center.x, center.y)
	var root := Node3D.new()
	root.name = display + "Village"
	root.position = Vector3(center.x, h, center.y)
	parent.add_child(root)
	# Core buildings
	for i in range(3):
		var a: float = float(i) * TAU / 3.0
		var hp: Vector2 = Vector2(cos(a), sin(a)) * 8.0
		var house: Node3D = BuildingKit.make_house(5.2, 4.8, 2.5, "plaster", "thatch", Color(0.8, 0.75, 0.65))
		house.position = Vector3(hp.x, noise.get_height(center.x + hp.x, center.y + hp.y) - h, hp.y)
		root.add_child(house)
	# Fountain center
	var fountain: Node3D = BuildingKit.make_fountain()
	fountain.position = Vector3(0, 0, 0)
	root.add_child(fountain)
	settlements[id] = {
		"name": display,
		"level": 1,
		"progress": 10.0,
		"center": center,
		"population": 0,
		"buildings": 3,
	}
	for i in range(4):
		_spawn_free_villager(center, display)
	settlements[id]["population"] = 4
	village_founded.emit(id, display)
	EventBus.toast.emit("A new village rises: %s!" % display, "levelup")
	EventBus.activity.emit("Founded settlement: %s" % display, "world")
	var rep = get_tree().get_first_node_in_group("reputation")
	if rep:
		rep.add_rep("elyndor", 3)

func get_level_title(id: String) -> String:
	if not settlements.has(id):
		return "Unknown"
	return LEVEL_TITLES[clampi(int(settlements[id]["level"]), 0, LEVEL_TITLES.size() - 1)]

func to_save() -> Dictionary:
	return {"settlements": settlements.duplicate(true)}

func from_save(data: Dictionary) -> void:
	if data.has("settlements"):
		settlements = data["settlements"]
