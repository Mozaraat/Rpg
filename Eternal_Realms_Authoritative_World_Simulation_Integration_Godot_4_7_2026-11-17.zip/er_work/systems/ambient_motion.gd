# AmbientMotion - spins and/or bobs a node (floating crystals, books, orbiting gems).
class_name AmbientMotion
extends Node3D

@export var spin_speed: float = 0.0     # radians / second around Y
@export var bob_height: float = 0.0
@export var bob_speed: float = 1.0

var _base_y: float = 0.0
var _phase: float = 0.0

func _ready() -> void:
	_base_y = position.y
	_phase = randf() * TAU

func _process(delta: float) -> void:
	rotate_y(spin_speed * delta)
	if bob_height > 0.0:
		_phase += delta * bob_speed
		position.y = _base_y + sin(_phase) * bob_height
