extends Node

## Multi-floor legacy expeditions. Archive fragments are collected in separate
## civilization layers; a matching guardian must be defeated before a manual unlocks.

signal inheritance_progress_changed(sect_id: String, report: Dictionary)
signal inheritance_completed(sect_id: String, technique_id: String)

const QUESTS: Dictionary = {
	"azure_sword_hall":{"title":"The Shattered Azure Edict","archive_floors":[5,15],"guardian_floor":20,"technique":"eclipse_counter","reward":"runebound_core","lore":"The old Sword Hall split its art into two fragments so no single heir could claim the counterstroke."},
	"crimson_pavilion":{"title":"The Ashen Phoenix Testament","archive_floors":[15,25],"guardian_floor":30,"technique":"sunforge_palm","reward":"dragonbone","lore":"The Phoenix elders hid their final palm within a furnace scripture guarded by a reborn flame."},
	"stillwater_monastery":{"title":"The Moonwell Sutra","archive_floors":[25,35],"guardian_floor":40,"technique":"moonwell_step","reward":"heart_of_depths","lore":"The Monastery's footwork was written around the rhythm of a tide that no longer reaches the surface."},
	"stormspire_order":{"title":"The Sky-Lattice Record","archive_floors":[35,45],"guardian_floor":50,"technique":"sky_lattice","reward":"celestial_codex","lore":"A storm formation was encoded in three constellations and a final lightning seal."},
	"veiled_moon_covenant":{"title":"The Silent River Testament","archive_floors":[45,55],"guardian_floor":60,"technique":"veil_of_stillness","reward":"voidsilk","lore":"The Covenant's vanished assassins left a manual that teaches absence rather than speed."},
	"rootbound_circle":{"title":"The First Root Codex","archive_floors":[55,65],"guardian_floor":70,"technique":"beast_breath_link","reward":"ancient_scale","lore":"The first Rootbound keeper learned to share breath with the great spirit beasts."}
}

func _ready() -> void:
	add_to_group("ancient_inheritance_system")
	if not PlayerData.stats.has("ancient_inheritance_quests"):
		PlayerData.stats["ancient_inheritance_quests"] = {}
	if not PlayerData.stats.has("ancient_archive_discoveries"):
		PlayerData.stats["ancient_archive_discoveries"] = {}
	if not PlayerData.stats.has("ancient_boss_floors"):
		PlayerData.stats["ancient_boss_floors"] = []

func start_sect_legacy(sect_id: String) -> bool:
	if not QUESTS.has(sect_id):
		return false
	var sect_state: Dictionary = PlayerData.stats.get("sect_state", {})
	if str(sect_state.get("joined", "")) != sect_id:
		EventBus.toast.emit("The master only entrusts this legacy to a sworn disciple of the sect.", "warning")
		return false
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill == null:
		return false
	var quests: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).duplicate(true)
	var existing: Dictionary = quests.get(sect_id, {})
	if bool(existing.get("completed", false)):
		EventBus.toast.emit("You have already completed this sect's ancient legacy.", "info")
		return false
	if bool(existing.get("started", false)):
		EventBus.toast.emit("Your legacy expedition is already recorded. The Field Journal holds its clues.", "info")
		return true
	var config: Dictionary = QUESTS[sect_id]
	var known_archives: Dictionary = PlayerData.stats.get("ancient_archive_discoveries", {})
	var collected: Dictionary = {}
	for floor_number in config.archive_floors:
		collected[str(floor_number)] = known_archives.has("archive_%03d" % int(floor_number))
	var boss_floors: Array = PlayerData.stats.get("ancient_boss_floors", [])
	existing = {"started":true,"completed":false,"archive_fragments":collected,"guardian_defeated":boss_floors.has(int(config.guardian_floor)),"started_at":Time.get_unix_time_from_system()}
	quests[sect_id] = existing
	PlayerData.stats["ancient_inheritance_quests"] = quests
	EventBus.activity.emit("Legacy expedition begun: %s. Search the listed dungeon floors for two archive fragments." % str(config.title), "quest")
	EventBus.toast.emit("A multi-floor inheritance has been added to your Field Journal.", "levelup")
	inheritance_progress_changed.emit(sect_id, get_quest_report(sect_id))
	_try_complete(sect_id)
	return true

func record_floor_entered(floor_number: int) -> void:
	var visited: Array = PlayerData.stats.get("ancient_floors_visited", []).duplicate()
	if not visited.has(floor_number):
		visited.append(floor_number)
		PlayerData.stats["ancient_floors_visited"] = visited
	for sect_id in QUESTS.keys():
		var report: Dictionary = get_quest_report(str(sect_id))
		var progress: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).get(str(sect_id), {})
		var fragments: Dictionary = progress.get("archive_fragments", {})
		if bool(report.get("started", false)) and report.get("archive_floors", []).has(floor_number) and not bool(fragments.get(str(floor_number), false)):
			EventBus.toast.emit("The architecture matches a fragment described by your sect master.", "discovery")

func record_archive_fragment(floor_number: int, archive_id: String) -> bool:
	var discovered: Dictionary = PlayerData.stats.get("ancient_archive_discoveries", {}).duplicate(true)
	if discovered.has(archive_id):
		EventBus.toast.emit("You have already transcribed this archive fragment.", "info")
		return false
	discovered[archive_id] = {"floor":floor_number,"found_at":Time.get_unix_time_from_system()}
	PlayerData.stats["ancient_archive_discoveries"] = discovered
	CultivationDiscovery.record_clue("archive_%s" % archive_id, "Ancient civilization archive", "A recovered archive preserves knowledge of spiritual principles.")
	var player: Node3D = GameManager.player
	if player and player.get("skills") != null:
		player.skills.train("ancient_lore", 1.2)
		player.skills.train("knowledge", 0.9)
		player.skills.train("wisdom", 0.55)
		player.skills.train("dungeon_delving", 0.6)
	PlayerData.add_item("rune_fragment", 1)
	EventBus.activity.emit("Ancient archive fragment recovered on Floor %d" % floor_number, "discovery")
	for sect_id in QUESTS.keys():
		var config: Dictionary = QUESTS[sect_id]
		if not config.archive_floors.has(floor_number):
			continue
		var quests: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).duplicate(true)
		var progress: Dictionary = quests.get(sect_id, {})
		if bool(progress.get("started", false)) and not bool(progress.get("completed", false)):
			var fragments: Dictionary = progress.get("archive_fragments", {}).duplicate(true)
			fragments[str(floor_number)] = true
			progress["archive_fragments"] = fragments
			quests[sect_id] = progress
			PlayerData.stats["ancient_inheritance_quests"] = quests
			inheritance_progress_changed.emit(str(sect_id), get_quest_report(str(sect_id)))
			_try_complete(str(sect_id))
	return true

func record_floor_boss_defeated(floor_number: int) -> void:
	var cleared: Array = PlayerData.stats.get("ancient_boss_floors", []).duplicate()
	if not cleared.has(floor_number):
		cleared.append(floor_number)
		PlayerData.stats["ancient_boss_floors"] = cleared
	for sect_id in QUESTS.keys():
		var config: Dictionary = QUESTS[sect_id]
		if int(config.guardian_floor) != floor_number:
			continue
		var quests: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).duplicate(true)
		var progress: Dictionary = quests.get(sect_id, {})
		if bool(progress.get("started", false)):
			progress["guardian_defeated"] = true
			quests[sect_id] = progress
			PlayerData.stats["ancient_inheritance_quests"] = quests
			_try_complete(str(sect_id))

func get_quest_report(sect_id: String) -> Dictionary:
	if not QUESTS.has(sect_id):
		return {}
	var config: Dictionary = QUESTS[sect_id]
	var progress: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).get(sect_id, {})
	var fragments: Dictionary = progress.get("archive_fragments", {})
	var collected: int = 0
	for floor_number in config.archive_floors:
		if bool(fragments.get(str(floor_number), false)):
			collected += 1
	return {"sect_id":sect_id,"title":str(config.title),"started":bool(progress.get("started", false)),"completed":bool(progress.get("completed", false)),"archive_floors":config.archive_floors.duplicate(),"fragments_collected":collected,"fragments_required":config.archive_floors.size(),"guardian_floor":int(config.guardian_floor),"guardian_defeated":bool(progress.get("guardian_defeated", false)),"technique":str(config.technique),"lore":str(config.lore)}

func active_quest_report() -> Dictionary:
	var joined: String = str(PlayerData.stats.get("sect_state", {}).get("joined", ""))
	if joined == "" or not QUESTS.has(joined):
		return {}
	return get_quest_report(joined)

func _try_complete(sect_id: String) -> void:
	var report: Dictionary = get_quest_report(sect_id)
	if not bool(report.get("started", false)) or bool(report.get("completed", false)):
		return
	if int(report.get("fragments_collected", 0)) < int(report.get("fragments_required", 0)) or not bool(report.get("guardian_defeated", false)):
		return
	var config: Dictionary = QUESTS[sect_id]
	var quests: Dictionary = PlayerData.stats.get("ancient_inheritance_quests", {}).duplicate(true)
	var progress: Dictionary = quests.get(sect_id, {})
	progress["completed"] = true
	progress["completed_at"] = Time.get_unix_time_from_system()
	quests[sect_id] = progress
	PlayerData.stats["ancient_inheritance_quests"] = quests
	var skill: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
	if skill and skill.has_method("seal_rare_technique"):
		skill.seal_rare_technique(str(config.technique), str(config.title))
	elif skill and skill.has_method("discover_technique"):
		skill.discover_technique(str(config.technique), str(config.title))
	var reward_id: String = str(config.reward)
	if ItemDB.has_item(reward_id):
		PlayerData.add_item(reward_id, 1, 2)
	SectSimulation.change_standing(sect_id, 20)
	EventBus.toast.emit("INHERITANCE RESTORED — %s" % str(config.title), "levelup")
	EventBus.activity.emit("The lost %s has been reconstructed. Its technique is now available for study." % str(config.title), "cultivation")
	inheritance_completed.emit(sect_id, str(config.technique))
	inheritance_progress_changed.emit(sect_id, get_quest_report(sect_id))
