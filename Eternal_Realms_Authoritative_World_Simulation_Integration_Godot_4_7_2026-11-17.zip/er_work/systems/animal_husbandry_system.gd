# Player-owned livestock with visible procedural animal actors and persistent husbandry data.
extends Node

var pens: Array[Dictionary] = []
var visual_animals: Array[Dictionary] = []
var _clock := 0.0
var _anim_clock := 0.0

func _ready() -> void:
    add_to_group("animal_husbandry")
    var saved: Variant = PlayerData.stats.get("livestock", [])
    if saved is Array: pens.assign(saved)
    call_deferred("_rebuild_animals")

func _input(event: InputEvent) -> void:
    if GameManager.input_locked or not (event is InputEventKey) or not event.pressed or event.echo: return
    if event.keycode == KEY_O: feed_nearest()
    elif event.keycode == KEY_I: care_nearest()
    elif event.keycode == KEY_K: breed_nearest()
    if event.keycode in [KEY_O, KEY_I, KEY_K]: get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
    _clock += delta
    _anim_clock += delta
    for visual in visual_animals:
        var root: Node3D = visual.get("root")
        if is_instance_valid(root):
            root.position.y = float(visual.get("base_y", root.position.y)) + sin(_anim_clock * 2.0 + float(visual.get("phase", 0.0))) * 0.025
            var legs: Array = visual.get("legs", [])
            for i in range(legs.size()):
                var leg: Node3D = legs[i]
                if is_instance_valid(leg): leg.rotation.x = sin(_anim_clock * 2.5 + float(i % 2) * PI) * 0.045
    if _clock < 60.0: return
    _clock = 0.0
    for animal in pens:
        animal["needs"] = minf(100.0, float(animal.get("needs", 50.0)) + 8.0)
        animal["production"] = float(animal.get("production", 0.0)) + (0.18 if float(animal.get("needs", 0.0)) < 75.0 else 0.05)
        if float(animal["production"]) >= 1.0:
            var product := _product_for(str(animal.get("kind", "")))
            if product != "":
                PlayerData.add_item(product, 1)
                animal["production"] = 0.0
    PlayerData.stats["livestock"] = pens.duplicate(true)

func register_animal(kind: String, name: String = "", pen_position: Vector3 = Vector3.ZERO) -> void:
    if not ["chicken", "cow", "sheep", "rabbit"].has(kind): return
    var position := pen_position
    if position == Vector3.ZERO and GameManager.player: position = GameManager.player.global_position + Vector3(randf_range(-2.0,2.0),0,randf_range(-2.0,2.0))
    var record := {"kind":kind,"name":name if name != "" else kind.capitalize(),"needs":50.0,"bond":0.0,"production":0.0,"age":0,"x":position.x,"y":position.y,"z":position.z}
    pens.append(record)
    _spawn_animal(record)
    _save()
    EventBus.toast.emit("Added %s to your livestock." % kind, "success")

func feed_nearest() -> void:
    var idx := _nearest_animal()
    if idx < 0: EventBus.toast.emit("Build a coop or barn and register livestock first.", "info"); return
    if not PlayerData.remove_item("hay", 1): EventBus.toast.emit("You need a hay bundle to feed livestock.", "warning"); return
    pens[idx]["needs"] = maxf(0.0, float(pens[idx].get("needs",50.0)) - 35.0)
    pens[idx]["bond"] = float(pens[idx].get("bond",0.0)) + 2.0
    _save(); EventBus.toast.emit("You fill the trough and feed %s." % str(pens[idx].get("name","the animal")), "success")

func care_nearest() -> void:
    var idx := _nearest_animal()
    if idx < 0: EventBus.toast.emit("No livestock nearby. Build a coop, barn or sheep pen.", "info"); return
    pens[idx]["needs"] = maxf(0.0, float(pens[idx].get("needs",50.0)) - 18.0)
    pens[idx]["bond"] = float(pens[idx].get("bond",0.0)) + 5.0
    _save(); EventBus.toast.emit("You groom and inspect %s. Bond %.0f." % [str(pens[idx].get("name","your animal")), float(pens[idx].get("bond",0.0))], "success")

func breed_nearest() -> void:
    var idx := _nearest_animal()
    if idx < 0: EventBus.toast.emit("No livestock nearby.", "info"); return
    var kind := str(pens[idx].get("kind", ""))
    var partner := -1
    for i in range(pens.size()):
        if i != idx and str(pens[i].get("kind", "")) == kind and float(pens[i].get("needs",100.0)) < 70.0:
            partner = i; break
    if partner < 0: EventBus.toast.emit("You need a second well-cared-for %s to breed." % kind, "warning"); return
    if not PlayerData.spend_gold(5): EventBus.toast.emit("Breeding care costs 5 gold.", "warning"); return
    var parent_pos := Vector3(float(pens[idx].get("x",0.0)), float(pens[idx].get("y",0.0)), float(pens[idx].get("z",0.0)))
    var child_pos := parent_pos + Vector3(randf_range(1.0,2.0),0,randf_range(1.0,2.0))
    var child := {"kind":kind,"name":"Young " + kind.capitalize(),"needs":35.0,"bond":0.0,"production":0.0,"age":0,"x":child_pos.x,"y":child_pos.y,"z":child_pos.z}
    pens.append(child); _spawn_animal(child); _save()
    EventBus.toast.emit("A young %s has been born. Keep it fed as it grows." % kind, "success")

func _nearest_animal() -> int:
    var player: Node3D = GameManager.player
    if player == null: return -1
    var best := -1; var best_d := 7.0
    for i in range(pens.size()):
        var p := Vector3(float(pens[i].get("x",0.0)),float(pens[i].get("y",0.0)),float(pens[i].get("z",0.0)))
        var d := player.global_position.distance_to(p)
        if d < best_d: best_d = d; best = i
    return best

func _spawn_animal(record: Dictionary) -> void:
    var kind := str(record.get("kind", "chicken"))
    var root := StaticBody3D.new(); root.name = "Livestock_" + kind
    root.collision_layer = Constants.LAYER_WORLD
    root.collision_mask = Constants.LAYER_WORLD
    var body_collision := CollisionShape3D.new(); var body_shape := CapsuleShape3D.new(); body_shape.radius = 0.32 if kind != "chicken" else 0.2; body_shape.height = 1.0 if kind != "chicken" else 0.55; body_collision.shape = body_shape; body_collision.position.y = 0.5; root.add_child(body_collision)
    root.position = Vector3(float(record.get("x",0.0)),float(record.get("y",0.0)),float(record.get("z",0.0)))
    get_tree().current_scene.add_child(root)
    var body := MeshInstance3D.new(); var body_mesh := CapsuleMesh.new(); body_mesh.radius = 0.36 if kind != "chicken" else 0.22; body_mesh.height = 0.95 if kind != "chicken" else 0.55; body.mesh = body_mesh; body.position.y = body_mesh.height * 0.5 + 0.25; body.rotation.z = PI * 0.5
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.88,0.82,0.67) if kind == "sheep" else (Color(0.88,0.82,0.72) if kind == "cow" else (Color(0.82,0.68,0.40) if kind == "chicken" else Color(0.55,0.43,0.34)))
    mat.roughness = 0.9; body.material_override = mat; root.add_child(body)
    var head := MeshInstance3D.new(); var head_mesh := SphereMesh.new(); head_mesh.radius = 0.22 if kind != "chicken" else 0.14; head_mesh.height = head_mesh.radius * 2.0; head.mesh = head_mesh; head.position = Vector3(0,0.72,-0.46); head.material_override = mat; root.add_child(head)
    var legs: Array[Node3D] = []
    for x in [-0.2,0.2]:
        for z in [-0.28,0.28]:
            var leg := MeshInstance3D.new(); var leg_mesh := CylinderMesh.new(); leg_mesh.top_radius = 0.055; leg_mesh.bottom_radius = 0.045; leg_mesh.height = 0.42 if kind != "chicken" else 0.25; leg.mesh = leg_mesh; leg.position = Vector3(x,0.22,z); leg.material_override = mat; root.add_child(leg); legs.append(leg)
    visual_animals.append({"root":root,"legs":legs,"base_y":root.position.y,"phase":randf() * TAU})

func _rebuild_animals() -> void:
    for visual in visual_animals:
        var root: Node3D = visual.get("root")
        if is_instance_valid(root): root.queue_free()
    visual_animals.clear()
    for animal in pens: _spawn_animal(animal)

func refresh_from_player_data() -> void:
    var saved: Variant = PlayerData.stats.get("livestock", [])
    pens.clear()
    if saved is Array: pens.assign(saved)
    _rebuild_animals()

func _save() -> void:
    PlayerData.stats["livestock"] = pens.duplicate(true)

func _product_for(kind: String) -> String:
    match kind:
        "chicken": return "egg"
        "cow": return "milk"
        "sheep": return "wool"
        "rabbit": return "animal_fur"
    return ""
