# Day / Night Cycle + whole-world look (sky, sun, moon, fog, post-processing)
# Real Coder: one place owns the atmosphere. Time of day drives sun/moon direction, sky colours,
# fog, ambient light, lamp/window glow and fireflies.
extends Node3D
class_name DayNightCycle

@export var day_length_seconds: float = 480.0   # 8 real minutes = full day
@export var start_time: float = 0.32            # 0.0 midnight, 0.25 sunrise, 0.5 noon, 0.75 sunset

var time_of_day: float = 0.32
var is_day: bool = true
var quality: int = 2   # 0 low, 1 medium, 2 high (default), 3 cinematic (F10 cycles)

@onready var sun: DirectionalLight3D = $Sun
var moon: DirectionalLight3D
var twilight_fill: DirectionalLight3D
var world_env: WorldEnvironment
var env: Environment
var sky_mat: ShaderMaterial
var fireflies: CPUParticles3D
var ambient_pollen: CPUParticles3D
var _terrain: TerrainNoise

var _lamp: float = 0.0
var _light_tick: float = 0.0

# Palettes (sRGB)
const TOP_DAY := Color(0.13, 0.32, 0.74)
const TOP_TWI := Color(0.20, 0.25, 0.52)
# Moonlit nights are stylised, not physically black: keep enough blue lift that
# silhouettes, roads and the village stay readable without flattening contrast.
const TOP_NIGHT := Color(0.030, 0.052, 0.115)
const HOR_DAY := Color(0.56, 0.73, 0.91)
const HOR_TWI := Color(0.95, 0.52, 0.34)
const HOR_NIGHT := Color(0.075, 0.105, 0.195)

func _ready() -> void:
	add_to_group("day_night")
	time_of_day = start_time
	world_env = get_node_or_null("../WorldEnvironment")
	_terrain = TerrainNoise.new(GameManager.world_seed)
	_build_environment()
	_build_moon()
	fireflies = VFX.fireflies(self)
	ambient_pollen = VFX.ambient_drift(self)
	apply_quality(quality)
	_update_visuals()
	print("[DayNight] Cycle started")

func _build_environment() -> void:
	env = Environment.new()
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = load("res://shaders/sky.gdshader")
	var sky := Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_sky_contribution = 1.0
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_white = 5.0
	env.glow_enabled = true
	env.glow_intensity = 0.62
	env.glow_bloom = 0.045
	env.glow_hdr_threshold = 1.15
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_DEPTH
	env.fog_depth_begin = 112.0
	env.fog_depth_end = 430.0
	env.fog_depth_curve = 1.62
	env.fog_density = 0.62
	env.fog_sky_affect = 0.18
	env.fog_aerial_perspective = 0.40
	env.fog_light_energy = 1.0
	env.fog_height = 1.1
	env.fog_height_density = 0.07
	env.adjustment_enabled = true
	env.adjustment_brightness = 1.02
	env.adjustment_contrast = 1.09
	env.adjustment_saturation = 1.10
	if world_env == null:
		world_env = WorldEnvironment.new()
		world_env.name = "WorldEnvironment"
		get_parent().add_child.call_deferred(world_env)
	world_env.environment = env

func _build_moon() -> void:
	moon = DirectionalLight3D.new()
	moon.name = "Moon"
	moon.light_color = Color(0.62, 0.74, 1.0)
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 80.0
	add_child(moon)

	# Warm low-angle fill for dawn/dusk. Without it the sky's mauve ambient
	# lights every surface uniformly and the whole world turns violet.
	twilight_fill = DirectionalLight3D.new()
	twilight_fill.name = "TwilightFill"
	twilight_fill.light_color = Color(1.0, 0.62, 0.38)
	twilight_fill.shadow_enabled = false
	twilight_fill.light_energy = 0.0
	add_child(twilight_fill)

## 0 = low, 1 = medium, 2 = high, 3 = cinematic. Cinematic is intentionally optional.
func apply_quality(q: int) -> void:
	quality = clampi(q, 0, 3)
	env.ssao_enabled = quality >= 1
	env.ssao_radius = 1.75 if quality >= 3 else 1.45
	env.ssao_intensity = 2.1 if quality >= 3 else 1.75
	env.ssao_power = 1.55
	env.ssao_detail = 0.6
	env.ssao_horizon = 0.09
	env.ssao_sharpness = 0.98
	env.ssao_light_affect = 0.18
	env.ssil_enabled = quality >= 3
	env.ssil_radius = 5.0
	env.ssil_intensity = 0.6
	env.ssr_enabled = quality >= 3
	env.ssr_max_steps = 48
	env.ssr_fade_in = 0.18
	env.ssr_fade_out = 2.2
	env.ssr_depth_tolerance = 0.22
	env.glow_enabled = quality >= 1
	env.glow_intensity = 0.74 if quality >= 3 else 0.62
	env.volumetric_fog_enabled = quality >= 2
	env.volumetric_fog_density = 0.0045 if quality < 3 else 0.0065
	env.volumetric_fog_length = 160.0 if quality >= 3 else 125.0
	env.volumetric_fog_anisotropy = 0.8 if quality >= 3 else 0.72
	env.volumetric_fog_ambient_inject = 0.5 if quality >= 3 else 0.42
	env.volumetric_fog_sky_affect = 0.0
	sun.shadow_enabled = quality >= 1
	moon.shadow_enabled = quality >= 3
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if quality >= 1 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 300.0 if quality >= 3 else (220.0 if quality >= 2 else (155.0 if quality == 1 else 100.0))
	sun.directional_shadow_blend_splits = true
	sun.shadow_blur = 1.6 if quality >= 3 else 1.35
	sun.light_angular_distance = 0.6 if quality >= 3 else (0.42 if quality >= 2 else 0.0)
	sun.shadow_normal_bias = 1.4
	var vp: Viewport = get_viewport()
	if vp:
		vp.msaa_3d = Viewport.MSAA_8X if quality >= 3 else (Viewport.MSAA_4X if quality >= 2 else (Viewport.MSAA_2X if quality == 1 else Viewport.MSAA_DISABLED))
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if quality >= 1 else Viewport.SCREEN_SPACE_AA_DISABLED
	# The dungeon replaces the active WorldEnvironment; keep its post effects in sync too.
	if world_env and world_env.environment and world_env.environment != env:
		var active_environment: Environment = world_env.environment
		active_environment.glow_enabled = quality >= 1
		active_environment.glow_intensity = 0.65 if quality < 3 else 0.82
		active_environment.volumetric_fog_enabled = quality >= 2
		active_environment.volumetric_fog_density = 0.008 if quality < 3 else 0.012
	_apply_dungeon_light_quality()
	print("[DayNight] Graphics quality: ", ["LOW", "MEDIUM", "HIGH", "CINEMATIC"][quality])

func _apply_dungeon_light_quality() -> void:
	var range_scales: Array[float] = [0.78, 0.90, 1.0, 1.0]
	for light_node in get_tree().get_nodes_in_group("dungeon_quality_light"):
		if not light_node is OmniLight3D:
			continue
		var light: OmniLight3D = light_node
		light.light_energy = float(light.get_meta("quality_base_energy", light.light_energy))
		light.omni_range = float(light.get_meta("quality_base_range", light.omni_range)) * range_scales[quality]
		light.shadow_enabled = bool(light.get_meta("quality_cinematic_shadow", false)) and quality >= 3
	for fill_node in get_tree().get_nodes_in_group("dungeon_corridor_fill_light"):
		if fill_node is OmniLight3D:
			fill_node.visible = quality >= 1

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F10:
		apply_quality((quality + 1) % 4)
		EventBus.toast.emit("Graphics: %s" % ["Low", "Medium", "High", "Cinematic"][quality], "info")

func _process(delta: float) -> void:
	time_of_day = fmod(time_of_day + delta / day_length_seconds, 1.0)
	_update_visuals()
	var player: Node3D = GameManager.player
	if player and fireflies:
		fireflies.global_position = player.global_position + Vector3(0, 2.0, 0)
	if player and ambient_pollen:
		ambient_pollen.global_position = player.global_position + Vector3(0, 3.0, 0)
		ambient_pollen.emitting = quality >= 1 and is_day
	_light_tick -= delta
	if _light_tick <= 0.0:
		_light_tick = 0.1
		_update_night_lights()
	_flicker_lights()

func get_sun_direction() -> Vector3:
	var a: float = (time_of_day - 0.25) * TAU
	return Vector3(cos(a) * 0.85, sin(a), 0.35).normalized()

func _update_visuals() -> void:
	var sd: Vector3 = get_sun_direction()
	var el: float = sd.y

	var day_w: float = smoothstep(0.02, 0.42, el)
	var night_w: float = 1.0 - smoothstep(-0.20, 0.0, el)
	var twi_w: float = clampf(1.0 - day_w - night_w, 0.0, 1.0)
	var norm: float = maxf(day_w + night_w + twi_w, 0.001)
	day_w /= norm
	night_w /= norm
	twi_w /= norm

	var top: Color = TOP_DAY * day_w + TOP_TWI * twi_w + TOP_NIGHT * night_w
	var hor: Color = HOR_DAY * day_w + HOR_TWI * twi_w + HOR_NIGHT * night_w
	top.a = 1.0
	hor.a = 1.0

	# --- Lights ---
	var sun_w: float = smoothstep(-0.03, 0.22, el)
	sun.global_transform = Transform3D(Basis.looking_at(-sd, Vector3.UP), Vector3.ZERO)
	sun.light_energy = 1.35 * sun_w
	sun.light_color = Color(1.0, 0.46, 0.20).lerp(Color(1.0, 0.955, 0.88), smoothstep(0.0, 0.5, el))
	sun.shadow_enabled = quality >= 1 and sun_w > 0.02
	sun.visible = sun_w > 0.005
	moon.global_transform = Transform3D(Basis.looking_at(sd, Vector3.UP), Vector3.ZERO)
	moon.light_energy = 0.52 * night_w
	moon.visible = night_w > 0.05
	twilight_fill.global_transform = sun.global_transform
	twilight_fill.light_energy = 0.34 * twi_w
	twilight_fill.light_color = Color(1.0, 0.55, 0.30).lerp(Color(1.0, 0.78, 0.56), smoothstep(0.0, 0.25, el))
	twilight_fill.visible = twi_w > 0.02

	# --- Sky ---
	sky_mat.set_shader_parameter("top_color", top)
	sky_mat.set_shader_parameter("horizon_color", hor)
	sky_mat.set_shader_parameter("ground_color", hor.darkened(0.35))
	sky_mat.set_shader_parameter("sun_dir", sd)
	sky_mat.set_shader_parameter("sun_color", sun.light_color)
	sky_mat.set_shader_parameter("sun_strength", sun_w)
	sky_mat.set_shader_parameter("twilight_amount", twi_w)
	sky_mat.set_shader_parameter("night_amount", night_w)
	var cl_lit: Color = Color(1, 1, 1).lerp(Color(1.0, 0.7, 0.55), twi_w).lerp(Color(0.12, 0.15, 0.25), night_w)
	var cl_dark: Color = Color(0.55, 0.63, 0.76).lerp(Color(0.45, 0.32, 0.42), twi_w).lerp(Color(0.04, 0.05, 0.10), night_w)
	sky_mat.set_shader_parameter("cloud_lit", cl_lit)
	sky_mat.set_shader_parameter("cloud_dark", cl_dark)

	# --- Atmosphere ---
	var regional_haze: Color = _get_regional_haze_color()
	# Keep the shared time-of-day sky, while atmospheric perspective picks up a
	# restrained hue from the current territory for stronger regional identity.
	# Dusk fog leans toward the sun colour so distance reads as warm haze instead
	# of a flat pink/lavender veil over the whole valley.
	var fog_base: Color = hor.lerp(top, 0.10).lerp(regional_haze, 0.14)
	env.fog_light_color = fog_base.lerp(sun.light_color, 0.24 * sun_w)
	env.fog_sun_scatter = 0.34 * sun_w
	env.fog_density = lerpf(0.50, 0.60, day_w)
	env.fog_height_density = lerpf(0.040, 0.034, day_w) + twi_w * 0.010
	env.fog_aerial_perspective = lerpf(0.26, 0.44, day_w)
	env.ambient_light_energy = lerpf(0.58, 0.96, day_w) - twi_w * 0.15
	env.volumetric_fog_albedo = Color(1, 1, 1).lerp(regional_haze, 0.20).lerp(Color(0.62, 0.72, 1.0), night_w)
	env.volumetric_fog_emission = Color(0, 0, 0)
	env.tonemap_exposure = lerpf(1.42, 1.0, day_w) - twi_w * 0.20
	env.adjustment_saturation = lerpf(0.94, 1.0, day_w) + twi_w * 0.15
	env.adjustment_contrast = lerpf(1.06, 1.10, day_w) + twi_w * 0.08
	sky_mat.set_shader_parameter("haze", lerpf(0.22, 0.18, day_w))
	# Fewer, more separated clouds keep the day sky blue instead of a flat white lid.
	sky_mat.set_shader_parameter("cloud_cover", 0.34 + twi_w * 0.06 - night_w * 0.08)

	var water_mat: ShaderMaterial = ChunkManager.shared_water_material
	if water_mat:
		water_mat.set_shader_parameter("day_light", clampf(day_w + twi_w * 0.55, 0.0, 1.0))
		water_mat.set_shader_parameter("sun_dir", sd)
		water_mat.set_shader_parameter("sun_color", sun.light_color)
		water_mat.set_shader_parameter("sun_energy", sun_w)
		water_mat.set_shader_parameter("clarity", lerpf(0.7, 1.15, day_w))

	_lamp = 1.0 - smoothstep(-0.02, 0.14, el)
	if fireflies:
		fireflies.emitting = _lamp > 0.6 and quality >= 1

	var was_day: bool = is_day
	is_day = el > 0.0
	if was_day != is_day:
		EventBus.day_night_changed.emit(is_day)
		print("[DayNight] Now it is ", "Day" if is_day else "Night")

func _get_regional_haze_color() -> Color:
	var player: Node3D = GameManager.player
	if player == null or _terrain == null:
		return Color(0.72, 0.80, 0.83)
	var region: String = _terrain.get_region_name(player.global_position.x, player.global_position.z)
	match region:
		"Elyndor Heartlands": return Color(0.72, 0.82, 0.67)
		"Whispering Woods": return Color(0.43, 0.66, 0.53)
		"Mirrorwater Basin": return Color(0.48, 0.70, 0.79)
		"Amberleaf Glade": return Color(0.82, 0.64, 0.39)
		"Ironback Range": return Color(0.61, 0.69, 0.77)
		"Mirefen Wetlands": return Color(0.48, 0.67, 0.60)
		"Sunscorch Expanse": return Color(0.83, 0.68, 0.48)
		"Emberfall Reach": return Color(0.76, 0.48, 0.38)
		"Frostveil Continent": return Color(0.60, 0.73, 0.87)
		_: return Color(0.72, 0.79, 0.82)

func _update_night_lights() -> void:
	BuildingKit.set_night_glow(_lamp)
	for l in get_tree().get_nodes_in_group("night_lights"):
		var light: Light3D = l
		var base: float = light.get_meta("base_energy", 1.5)
		light.light_energy = base * _lamp
		light.visible = _lamp > 0.02

func _flicker_lights() -> void:
	if _lamp < 0.02:
		return
	var t: float = Time.get_ticks_msec() * 0.001
	for l in get_tree().get_nodes_in_group("night_lights"):
		var light: Light3D = l
		var f: float = light.get_meta("flicker", 0.0)
		if f > 0.0:
			var base: float = light.get_meta("base_energy", 1.5)
			var seed_v: float = float(light.get_instance_id() % 97)
			light.light_energy = base * _lamp * (1.0 + f * (sin(t * 9.0 + seed_v) * 0.5 + sin(t * 23.0 + seed_v * 2.0) * 0.5))

func get_time_string() -> String:
	var hours: int = int(time_of_day * 24.0)
	var mins: int = int(fmod(time_of_day * 24.0 * 60.0, 60.0))
	return "%02d:%02d" % [hours, mins]
