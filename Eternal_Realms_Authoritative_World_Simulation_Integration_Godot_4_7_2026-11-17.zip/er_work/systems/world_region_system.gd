# Discovers authored geographic regions as the player physically explores them.
# The same TerrainNoise region definitions drive terrain biomes and the world atlas.
extends Node
class_name WorldRegionSystem

var _terrain: TerrainNoise
var _scan_elapsed: float = 0.0
var _last_region: String = ""

func _ready() -> void:
	add_to_group("world_region_system")
	_terrain = TerrainNoise.new(GameManager.world_seed)
	set_process(true)

func _process(delta: float) -> void:
	_scan_elapsed += delta
	if _scan_elapsed < 0.65:
		return
	_scan_elapsed = 0.0
	var player: Node3D = GameManager.player
	if player == null or not is_instance_valid(player):
		return
	var region_name := _terrain.get_region_name(player.global_position.x, player.global_position.z)
	if region_name == _last_region:
		return
	_last_region = region_name
	if region_name == "The Uncharted Wilds":
		return
	WorldLifeSimulation.on_region_entered(region_name)
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and MMORPGNetwork.is_authority():
		var region_visit_name := region_name
		if region_name == "Ironback Range": region_visit_name = "Ironback Range"
		MMORPGNetwork.record_local_quest_event("visit", region_visit_name)
	if PlayerData.discover_zone(region_name):
		if ElyndorRegionLife and ElyndorRegionLife.has_method("on_region_discovered"):
			ElyndorRegionLife.on_region_discovered(region_name)
		EventBus.toast.emit("Discovered: %s" % region_name, "levelup")
		EventBus.activity.emit("Entered %s" % region_name, "exploration")
		var skill_system: Node = player.get_node_or_null("SkillSystem")
		if skill_system and skill_system.has_method("train"):
			skill_system.train("exploration", 1.25)
			if skill_system.has_method("train"):
				skill_system.train("knowledge", 0.35, true)
