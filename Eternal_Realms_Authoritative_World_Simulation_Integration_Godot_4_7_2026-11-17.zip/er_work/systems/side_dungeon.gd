# SideDungeon - small exploration complexes scattered across the overworld.
#
# These are not raid floors. Each one is a short chain of rock chambers joined
# by crawling tunnels, seeded with harvestable resource nodes, a lit vault and
# a rare cache at the end. They exist so the mortal world has places worth
# digging into for ore, reagents and relics.
class_name SideDungeon
extends RefCounted

const ROOM_HEIGHT: float = 6.0
const MONSTER_SCENE = preload("res://scenes/monster.tscn")

const MONSTER_NAMES := {
	"cave_slime": "Cave Slime",
	"dungeon_rat": "Dungeon Rat",
	"prism_stalker": "Prism Stalker",
	"night_wisp": "Night Wisp",
	"cinder_hound": "Cinder Hound",
	"crystal_mimic": "Crystal Mimic",
	"spore_moth": "Spore Moth",
	"grave_hound": "Grave Hound",
	"bone_skitter": "Bone Skitter",
	"frost_lynx": "Frost Lynx",
	"shadow_bat": "Shadow Bat",
	"void_jelly": "Void Jelly",
	"tide_serpent": "Tide Serpent",
	"ember_wyrm": "Ember Wyrm",
}

static func _rock_material(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	mat.metallic = 0.0
	return mat

static func _solid_box(parent: Node3D, node_name: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.collision_layer = Constants.LAYER_WORLD
	body.collision_mask = 0
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _rock_material(color)
	body.add_child(mesh)
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	body.add_child(shape)
	parent.add_child(body)
	return body

static func _deco_box(parent: Node3D, node_name: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	mesh.name = node_name
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _rock_material(color)
	mesh.position = pos
	parent.add_child(mesh)
	return mesh

static func _glowing_material(color: Color, energy: float = 1.6) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	mat.roughness = 0.25
	return mat

# --- Chamber construction --------------------------------------------------

static func _build_chamber(parent: Node3D, center: Vector3, size: Vector2, tint: Color, rng: RandomNumberGenerator, west_portal: float = INF, east_portal: float = INF) -> void:
	var half := Vector2(size.x * 0.5, size.y * 0.5)
	var rock := Color(0.17, 0.18, 0.20)
	var floor := Color(0.13, 0.14, 0.16)
	_solid_box(parent, "CaveFloor", center + Vector3(0, -0.6, 0), Vector3(size.x, 1.2, size.y), floor)
	# Perimeter rock walls with a jagged inner face.
	for side in [-1.0, 1.0]:
		var portal := west_portal if side < 0.0 else east_portal
		var wall_x: float = side * (half.x + 0.9)
		if is_inf(portal):
			_solid_box(parent, "CaveWall", center + Vector3(wall_x, ROOM_HEIGHT * 0.5 - 0.6, 0), Vector3(1.8, ROOM_HEIGHT + 1.2, size.y + 3.6), rock)
		else:
			var wall_start := -half.y - 1.8
			var wall_end := half.y + 1.8
			var gap_start := portal - 2.5
			var gap_end := portal + 2.5
			_solid_box(parent, "PortalWall", center + Vector3(wall_x, 2.4, (wall_start + gap_start) * 0.5), Vector3(1.8, 7.2, gap_start - wall_start), rock)
			_solid_box(parent, "PortalWall", center + Vector3(wall_x, 2.4, (gap_end + wall_end) * 0.5), Vector3(1.8, 7.2, wall_end - gap_end), rock)
			_solid_box(parent, "PortalLintel", center + Vector3(wall_x, 4.35, portal), Vector3(1.8, 3.3, 5.0), rock)
		_solid_box(parent, "CaveWall", center + Vector3(0, ROOM_HEIGHT * 0.5 - 0.6, side * (half.y + 0.9)), Vector3(size.x + 3.6, ROOM_HEIGHT + 1.2, 1.8), rock)
	# A rough ceiling slab keeps the chamber roofed without a perfect dome.
	_solid_box(parent, "CaveCeiling", center + Vector3(0, ROOM_HEIGHT - 0.4, 0), Vector3(size.x + 2.4, 1.4, size.y + 2.4), rock.darkened(0.12))
	# Boulders and stalagmites break the flat floor.
	for i in range(int(size.x * size.y / 26.0)):
		var px: float = rng.randf_range(-half.x + 1.6, half.x - 1.6)
		var pz: float = rng.randf_range(-half.y + 1.6, half.y - 1.6)
		if absf(pz) < 4.0 or Vector2(px, pz).distance_to(Vector2(0, 5)) < 4.0:
			continue
		var boulder := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		var radius: float = rng.randf_range(0.5, 1.4)
		sphere.radius = radius
		sphere.height = radius * 1.7
		sphere.radial_segments = 10
		sphere.rings = 6
		boulder.mesh = sphere
		boulder.material_override = _rock_material(rock.lightened(rng.randf_range(-0.04, 0.06)))
		boulder.position = center + Vector3(px, radius * 0.35, pz)
		boulder.scale = Vector3(1.0, rng.randf_range(0.7, 1.2), 1.0)
		parent.add_child(boulder)
	for i in range(int(size.x * size.y / 42.0)):
		var sx: float = rng.randf_range(-half.x + 1.2, half.x - 1.2)
		var sz: float = rng.randf_range(-half.y + 1.2, half.y - 1.2)
		if absf(sz) < 4.0 or Vector2(sx, sz).distance_to(Vector2(0, 5)) < 4.0:
			continue
		var height: float = rng.randf_range(1.2, 3.0)
		var spire := MeshInstance3D.new()
		var cone := CylinderMesh.new()
		cone.top_radius = 0.05
		cone.bottom_radius = rng.randf_range(0.28, 0.55)
		cone.height = height
		cone.radial_segments = 8
		spire.mesh = cone
		spire.material_override = _rock_material(rock.lightened(0.04))
		spire.position = center + Vector3(sx, height * 0.5, sz)
		parent.add_child(spire)

static func _build_crystal_vein(parent: Node3D, pos: Vector3, tint: Color, count: int, rng: RandomNumberGenerator) -> void:
	for i in range(count):
		var shard := MeshInstance3D.new()
		var prism := PrismMesh.new()
		var height: float = rng.randf_range(0.8, 2.3)
		prism.size = Vector3(rng.randf_range(0.3, 0.6), height, rng.randf_range(0.3, 0.6))
		shard.mesh = prism
		shard.material_override = _glowing_material(tint.lightened(rng.randf_range(0.0, 0.2)), 2.2)
		shard.position = pos + Vector3(rng.randf_range(-1.1, 1.1), height * 0.5, rng.randf_range(-1.1, 1.1))
		shard.rotation.y = rng.randf_range(-0.5, 0.5)
		shard.rotation.z = rng.randf_range(-0.2, 0.2)
		parent.add_child(shard)
	var light := OmniLight3D.new()
	light.light_color = tint
	light.light_energy = 1.35
	light.omni_range = 13.0
	light.position = pos + Vector3(0, 1.4, 0)
	parent.add_child(light)

static func _build_wall_torch(parent: Node3D, pos: Vector3, tint: Color) -> void:
	var bracket := _deco_box(parent, "CaveTorchBracket", pos, Vector3(0.18, 0.5, 0.5), Color(0.12, 0.11, 0.10))
	bracket.rotation.y = PI * 0.5
	var flame := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.17
	sphere.height = 0.36
	flame.mesh = sphere
	flame.material_override = _glowing_material(tint, 3.0)
	flame.position = pos + Vector3(0, 0.25, 0)
	parent.add_child(flame)
	var light := OmniLight3D.new()
	light.light_color = tint
	light.light_energy = 1.4
	light.omni_range = 12.0
	light.position = pos + Vector3(0, 0.45, 0)
	parent.add_child(light)

# --- Resource nodes --------------------------------------------------------

static func _resource_node(parent: Node3D, pos: Vector3, node_name: String, drop: String, quantity: int, color: Color, hp: int, rng: RandomNumberGenerator) -> Dictionary:
	# Harvestable nodes are ordinary props the player can break for materials.
	var node := Node3D.new()
	node.name = node_name
	node.position = pos
	parent.add_child(node)
	for i in range(rng.randi_range(2, 4)):
		var chunk := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		var radius: float = rng.randf_range(0.35, 0.75)
		sphere.radius = radius
		sphere.height = radius * 1.5
		sphere.radial_segments = 10
		sphere.rings = 6
		chunk.mesh = sphere
		chunk.material_override = _rock_material(color.lightened(rng.randf_range(-0.05, 0.08)))
		chunk.position = Vector3(rng.randf_range(-0.7, 0.7), radius * 0.7, rng.randf_range(-0.7, 0.7))
		chunk.scale = Vector3(1.0, rng.randf_range(0.8, 1.3), 1.0)
		node.add_child(chunk)
	var label := Label3D.new()
	label.text = node_name
	label.font_size = 18
	label.position.y = 1.5
	label.modulate = color.lightened(0.35)
	label.outline_size = 5
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	node.add_child(label)
	return {"name": node_name, "node": node, "hp": hp, "broken": false, "drop": drop, "quantity": quantity, "color": color}

static func _build_cache(parent: Node3D, pos: Vector3, drop: String, quantity: int, rng: RandomNumberGenerator) -> Dictionary:
	# A sealed stone cache: the reward at the end of the complex.
	var node := Node3D.new()
	node.name = "Sealed Cache"
	node.position = pos
	parent.add_child(node)
	var plinth := _deco_box(node, "CachePlinth", Vector3(0, 0.3, 0), Vector3(2.0, 0.6, 1.6), Color(0.20, 0.20, 0.22))
	plinth.rotation.y = 0.12
	var lid := _deco_box(node, "CacheLid", Vector3(0, 0.82, 0), Vector3(1.5, 0.45, 1.1), Color(0.26, 0.22, 0.18))
	lid.rotation.y = 0.12
	var seal := MeshInstance3D.new()
	var prism := PrismMesh.new()
	prism.size = Vector3(0.34, 0.6, 0.34)
	seal.mesh = prism
	seal.material_override = _glowing_material(Color(0.55, 0.85, 1.0), 2.6)
	seal.position = Vector3(0, 1.2, 0)
	node.add_child(seal)
	var light := OmniLight3D.new()
	light.light_color = Color(0.55, 0.85, 1.0)
	light.light_energy = 1.5
	light.omni_range = 11.0
	light.position = Vector3(0, 1.4, 0)
	node.add_child(light)
	var label := Label3D.new()
	label.text = "SEALED CACHE"
	label.font_size = 20
	label.position.y = 1.9
	label.modulate = Color(0.6, 0.9, 1.0)
	label.outline_size = 5
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	node.add_child(label)
	return {"name": "Sealed Cache", "node": node, "hp": 4, "broken": false, "drop": drop, "quantity": quantity, "color": Color(0.4, 0.7, 0.95)}

# --- Guardians -------------------------------------------------------------

static func spawn_guardians(host: Node3D, ids: Array, tint: Color, rng: RandomNumberGenerator, spread: float = 6.0) -> Array:
	# The denizens that make a side dungeon risky rather than merely a mine.
	var spawned: Array = []
	for i in range(ids.size()):
		var monster: Monster = MONSTER_SCENE.instantiate()
		var monster_id: String = str(ids[i])
		monster.monster_id = monster_id
		monster.display_name = str(MONSTER_NAMES.get(monster_id, monster_id.replace("_", " ").capitalize()))
		monster.body_color = tint.lightened(0.18)
		monster.max_hp = 44.0 + float(i) * 9.0
		monster.damage = 9.0 + float(i) * 1.6
		monster.move_speed = 3.0 + float(i) * 0.3
		monster.aggro_range = 15.0
		monster.attack_range = 2.1
		monster.leash_range = 24.0
		monster.xp_train = 0.5
		monster.gold_min = 3
		monster.gold_max = 11
		monster.position = Vector3(rng.randf_range(-spread, spread), 0.4, rng.randf_range(-spread, spread))
		host.add_child(monster)
		spawned.append(monster)
	return spawned

# --- Arrival platform ------------------------------------------------------

static func _build_rope_platform(parent: Node3D, tint: Color) -> Node3D:
	# The way down: a stone disc slung on chains from a shaft in the rock. The
	# player arrives here, so the descent is visible rather than implied.
	var platform := Node3D.new()
	platform.name = "DescentPlatform"
	platform.position = Vector3(0, 0, 5.0)
	parent.add_child(platform)
	var disc := _deco_box(platform, "PlatformDisc", Vector3(0, 0.16, 0), Vector3(4.6, 0.32, 4.6), Color(0.22, 0.22, 0.24))
	disc.rotation.y = PI * 0.25
	var rim := _deco_box(platform, "PlatformRim", Vector3(0, 0.34, 0), Vector3(5.0, 0.12, 5.0), Color(0.30, 0.24, 0.18))
	rim.rotation.y = PI * 0.25
	for corner in [Vector3(-1.9, 0, -1.9), Vector3(1.9, 0, -1.9), Vector3(-1.9, 0, 1.9), Vector3(1.9, 0, 1.9)]:
		var chain := _deco_box(platform, "PlatformChain", corner + Vector3(0, 2.9, 0), Vector3(0.09, 5.4, 0.09), Color(0.30, 0.29, 0.27))
		chain.rotation.z = 0.02
	var lantern := _make_glowing_sphere(platform, Vector3(0, 2.4, 1.6), 0.2, tint)
	lantern.name = "PlatformLantern"
	var light := OmniLight3D.new()
	light.light_color = tint
	light.light_energy = 1.6
	light.omni_range = 14.0
	light.position = Vector3(0, 2.5, 1.6)
	platform.add_child(light)
	return platform

static func _make_glowing_sphere(parent: Node3D, pos: Vector3, radius: float, tint: Color) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 12
	sphere.rings = 7
	mesh.mesh = sphere
	mesh.material_override = _glowing_material(tint, 2.6)
	mesh.position = pos
	parent.add_child(mesh)
	return mesh

# --- Complex layout --------------------------------------------------------

static func build_complex(parent: Node3D, origin: Vector3, tint: Color, seed_value: int, chamber_names: Array, resources: Array, cache_drop: String, yaw: float = 0.0, monster_ids: Array = []) -> Dictionary:
	# Entry hall, resource chamber and vault in a line, joined by crawling
	# tunnels. The player digs through, harvests the veins and opens the cache.
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var root := Node3D.new()
	root.name = "SideDungeon"
	root.position = origin
	root.rotation.y = yaw
	parent.add_child(root)

	var breakables: Array[Dictionary] = []
	var room_size := Vector2(22.0, 18.0)
	var hall_center := Vector3(0, 0, 0)
	var resource_center := Vector3(42.0, 0, 6.0)
	var vault_center := Vector3(80.0, 0, -4.0)

	var hall := Node3D.new()
	hall.name = "EntryHall"
	hall.position = hall_center
	root.add_child(hall)
	_build_chamber(hall, Vector3.ZERO, room_size, tint, rng, INF, 3.0)
	_build_crystal_vein(hall, Vector3(-room_size.x * 0.5 + 2.6, 0, room_size.y * 0.5 - 2.6), tint, 4, rng)
	_build_wall_torch(hall, Vector3(-room_size.x * 0.5 + 1.4, 2.4, -4.0), tint)
	_build_wall_torch(hall, Vector3(room_size.x * 0.5 - 1.4, 2.4, 4.0), tint)
	var hall_label := Label3D.new()
	hall_label.text = str(chamber_names[0]) if chamber_names.size() > 0 else "ENTRY HALL"
	hall_label.font_size = 24
	hall_label.position = Vector3(0, 4.6, -room_size.y * 0.5 + 1.2)
	hall_label.modulate = tint.lightened(0.35)
	hall_label.outline_size = 6
	hall_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	hall.add_child(hall_label)
	_build_rope_platform(hall, tint)

	var resource_room := Node3D.new()
	resource_room.name = "ResourceChamber"
	resource_room.position = resource_center
	root.add_child(resource_room)
	_build_chamber(resource_room, Vector3.ZERO, Vector2(26.0, 22.0), tint, rng, -3.0, -5.0)
	_build_crystal_vein(resource_room, Vector3(9.0, 0, -7.0), tint, 6, rng)
	_build_crystal_vein(resource_room, Vector3(-8.0, 0, 6.0), tint.lightened(0.1), 5, rng)
	_build_wall_torch(resource_room, Vector3(0, 2.6, 11.4), tint)
	_build_wall_torch(resource_room, Vector3(-13.4, 2.6, 0), tint)
	var resource_label := Label3D.new()
	resource_label.text = str(chamber_names[1]) if chamber_names.size() > 1 else "RESOURCE CHAMBER"
	resource_label.font_size = 24
	resource_label.position = Vector3(0, 4.8, -11.6)
	resource_label.modulate = tint.lightened(0.35)
	resource_label.outline_size = 6
	resource_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	resource_room.add_child(resource_label)

	var vault := Node3D.new()
	vault.name = "Vault"
	vault.position = vault_center
	root.add_child(vault)
	_build_chamber(vault, Vector3.ZERO, Vector2(18.0, 18.0), tint, rng, 5.0, INF)
	_build_crystal_vein(vault, Vector3(-5.6, 0, -5.6), tint, 5, rng)
	_build_wall_torch(vault, Vector3(5.6, 2.6, 5.6), tint)
	var vault_label := Label3D.new()
	vault_label.text = str(chamber_names[2]) if chamber_names.size() > 2 else "VAULT"
	vault_label.font_size = 24
	vault_label.position = Vector3(0, 4.4, -9.6)
	vault_label.modulate = tint.lightened(0.35)
	vault_label.outline_size = 6
	vault_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	vault.add_child(vault_label)

	# Crawling tunnels join the three chambers with continuous walkable floor.
	_build_tunnel(root, Vector3(20.0, 0, 3.0), tint, rng)
	_build_tunnel(root, Vector3(63.0, 0, 1.0), tint, rng)

	# Resource nodes spread through the complex.
	var resource_specs: Array = resources
	for i in range(resource_specs.size()):
		var spec: Dictionary = resource_specs[i]
		var host: Node3D = hall if i % 3 == 0 else (resource_room if i % 3 == 1 else vault)
		var spread: float = rng.randf_range(-7.0, 7.0)
		var node_pos := Vector3(spread, 0.0, rng.randf_range(-6.0, 6.0))
		breakables.append(_resource_node(host, node_pos, str(spec.get("name", "Resource Vein")), str(spec.get("drop", "iron_ore")), int(spec.get("qty", 2)), spec.get("color", Color(0.5, 0.5, 0.52)), int(spec.get("hp", 3)), rng))
	breakables.append(_build_cache(vault, Vector3(4.6, 0, 2.6), cache_drop, 1, rng))

	# Guardians: most hold the resource chamber, one waits over the cache.
	var guardians: Array = []
	if monster_ids.size() > 0:
		var vault_guards: int = 1 if monster_ids.size() > 1 else 0
		var chamber_guards: Array = monster_ids.slice(0, monster_ids.size() - vault_guards)
		guardians = spawn_guardians(resource_room, chamber_guards, tint, rng, 7.0)
		if vault_guards > 0:
			guardians.append_array(spawn_guardians(vault, monster_ids.slice(monster_ids.size() - vault_guards), tint, rng, 4.0))

	var exit_marker := MeshInstance3D.new()
	var exit_sphere := SphereMesh.new()
	exit_sphere.radius = 0.28
	exit_sphere.height = 0.56
	exit_marker.mesh = exit_sphere
	exit_marker.material_override = _glowing_material(Color(0.45, 0.82, 0.95), 2.0)
	exit_marker.position = Vector3(0, 1.0, 7.0)
	vault.add_child(exit_marker)
	var exit_label := Label3D.new()
	exit_label.text = "EXIT — INTERACT"
	exit_label.font_size = 20
	exit_label.position = Vector3(0, 2.0, 7.0)
	exit_label.modulate = Color(0.5, 0.85, 0.95)
	exit_label.outline_size = 5
	exit_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	vault.add_child(exit_label)

	return {
		"root": root,
		"hall": hall,
		"resource_room": resource_room,
		"vault": vault,
		"breakables": breakables,
		"guardians": guardians,
		"start": origin + (Basis(Vector3.UP, yaw) * (hall_center + Vector3(0, 0, 4.0))),
		"exit": origin + (Basis(Vector3.UP, yaw) * (vault_center + Vector3(0, 0, 7.0))),
	}

static func _build_tunnel(parent: Node3D, center: Vector3, tint: Color, rng: RandomNumberGenerator) -> void:
	var tunnel := Node3D.new()
	tunnel.name = "CaveTunnel"
	tunnel.position = center
	parent.add_child(tunnel)
	var length: float = 20.0
	_solid_box(tunnel, "TunnelFloor", Vector3(0, -0.6, 0), Vector3(length, 1.2, 5.0), Color(0.12, 0.13, 0.15))
	_solid_box(tunnel, "TunnelRoof", Vector3(0, 3.2, 0), Vector3(length, 1.0, 5.0), Color(0.11, 0.12, 0.14))
	for side in [-1.0, 1.0]:
		_solid_box(tunnel, "TunnelWall", Vector3(0, 1.3, side * 2.9), Vector3(length, 4.6, 0.8), Color(0.12, 0.13, 0.15))
	_build_crystal_vein(tunnel, Vector3(rng.randf_range(-6.0, 6.0), 0, rng.randf_range(-1.6, 1.6)), tint, 3, rng)
