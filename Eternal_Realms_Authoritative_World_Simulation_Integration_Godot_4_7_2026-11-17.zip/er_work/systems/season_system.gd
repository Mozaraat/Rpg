# Seasons cycle with game time — gather/fish/spawn modifiers
extends Node
class_name SeasonSystem

signal season_changed(season: String)

const SEASONS := ["Spring", "Summer", "Autumn", "Winter"]
# Game seconds per season (roughly a few play sessions each)
const SEASON_LENGTH := 900.0

var season_index: int = 0
var season_time: float = 0.0

func _ready() -> void:
	add_to_group("seasons")

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	season_time += delta
	if season_time >= SEASON_LENGTH:
		season_time = 0.0
		season_index = (season_index + 1) % SEASONS.size()
		season_changed.emit(current())
		EventBus.toast.emit("Season changes: %s" % current(), "scene")
		EventBus.activity.emit("It is now %s" % current(), "world")

func current() -> String:
	return SEASONS[season_index]

func gather_mult() -> float:
	match current():
		"Spring": return 1.15
		"Summer": return 1.05
		"Autumn": return 1.20
		"Winter": return 0.75
	return 1.0

func fish_mult() -> float:
	match current():
		"Spring": return 1.1
		"Summer": return 1.0
		"Autumn": return 0.95
		"Winter": return 0.7
	return 1.0

func enemy_spawn_mult() -> float:
	match current():
		"Winter": return 1.25
		"Autumn": return 1.1
		_: return 1.0

func to_save() -> Dictionary:
	return {"season_index": season_index, "season_time": season_time}

func from_save(d: Dictionary) -> void:
	season_index = int(d.get("season_index", 0))
	season_time = float(d.get("season_time", 0.0))
