# Builds the Starting Village (Elyndor) and Magic School (Arcane Spire).
# Real Coder: layouts are authored in LOCAL coordinates around each settlement's centre;
# the terrain generator flattens the ground under both places, so nothing floats or sinks.
extends Node3D
class_name SettlementBuilder

const NPC_SCENE = preload("res://scenes/npc.tscn")

var noise: TerrainNoise
var _village: Node3D
var _spire: Node3D

func _ready() -> void:
	noise = TerrainNoise.new(GameManager.world_seed)
	_build_elyndor_village()
	_build_elyndor_bridge()
	_build_elyndor_hunting_camp()
	_build_region_identity_gates()
	_build_arcane_spire()
	_build_sect_campuses()
	print("[SettlementBuilder] Elyndor settlement, river crossing, regional identity gates and sect campuses created")

# Places `node` under `root` at local (x, z), resting on the real terrain height.
func _put(root: Node3D, node: Node3D, x: float, z: float, yaw: float = 0.0, lift: float = 0.0) -> Node3D:
	var wx: float = root.position.x + x
	var wz: float = root.position.z + z
	node.position = Vector3(x, noise.get_height(wx, wz) - root.position.y + lift, z)
	node.rotation.y = yaw
	root.add_child(node)
	return node

func _facing(from: Vector2, toward: Vector2) -> float:
	# rotation.y that makes local +Z point at `toward` (buildings: door side)
	var d: Vector2 = toward - from
	return atan2(d.x, d.y)

func _look_yaw(from: Vector2, toward: Vector2) -> float:
	# rotation.y that makes local -Z (character forward) point at `toward`
	var d: Vector2 = toward - from
	return atan2(-d.x, -d.y)

func _make_root(root_name: String, center: Vector2, height: float) -> Node3D:
	var r := Node3D.new()
	r.name = root_name
	r.position = Vector3(center.x, height, center.y)
	add_child(r)
	return r

func _tree(root: Node3D, x: float, z: float, kind: String, scl: float) -> void:
	var wx: float = root.position.x + x
	var wz: float = root.position.z + z
	var xf := Transform3D(Basis(Vector3.UP, randf() * TAU).scaled(Vector3.ONE * scl), Vector3(x, noise.get_height(wx, wz) - root.position.y - 0.15, z))
	var t := PackedColorArray([Color(1.0, 1.0, 1.0, 1.0)])
	root.add_child(VegetationKit.make_multimesh(kind, [xf], t, 400.0, true))
	var cs := StaticBody3D.new()
	cs.collision_layer = Constants.LAYER_WORLD
	var shape := CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = 0.5 * scl
	cyl.height = 4.0
	shape.shape = cyl
	shape.position = Vector3(0, 2.0, 0)
	cs.add_child(shape)
	_put(root, cs, x, z)

# ---------------------------------------------------------------------------
# Elyndor
# ---------------------------------------------------------------------------

# Six physically distinct sect compounds are placed along the highland approach.
# Their buildings sit on sampled terrain and use the same collision-ready building kit as settlements.
func _build_sect_campuses() -> void:
	var definitions: Array[Dictionary] = [
		{"id":"azure_sword_hall", "name":"Azure Sword Hall", "master":"Master Shen Rui", "region":"Elyndor Heartlands", "color":Color(0.30,0.55,0.92), "offset":Vector2(92,-22), "role":"Sword Intent"},
		{"id":"crimson_pavilion", "name":"Crimson Phoenix Pavilion", "master":"Elder Yan Huo", "region":"Ashen Reach", "color":Color(0.88,0.25,0.16), "offset":Vector2(132,-68), "role":"Crimson Flame"},
		{"id":"stillwater_monastery", "name":"Stillwater Monastery", "master":"Abbess Lian", "region":"Misty Basin", "color":Color(0.22,0.68,0.78), "offset":Vector2(84,34), "role":"Azure Tide"},
		{"id":"stormspire_order", "name":"Stormspire Order", "master":"Lord Qiao Lei", "region":"Thunder Peaks", "color":Color(0.65,0.52,0.95), "offset":Vector2(176,-4), "role":"Storm Vein"},
		{"id":"veiled_moon_covenant", "name":"Veiled Moon Covenant", "master":"Warden Yue", "region":"Whispering Wilds", "color":Color(0.40,0.38,0.62), "offset":Vector2(124,38), "role":"Shadow Step"},
		{"id":"rootbound_circle", "name":"Rootbound Circle", "master":"Grandmother Moss", "region":"Elderwood", "color":Color(0.30,0.62,0.34), "offset":Vector2(204,46), "role":"Nature Harmony"}
	]
	for i in range(definitions.size()):
		_build_one_sect(definitions[i], i)

func _build_one_sect(data: Dictionary, index: int) -> void:
	var center: Vector2 = TerrainNoise.SPIRE_CENTER + Vector2(data.get("offset", Vector2.ZERO))
	var root := _make_root("Sect_" + str(data.id), center, noise.get_height(center.x, center.y))
	var stone_color: Color = data.color
	# Conquered sect compounds rebuild under the occupying faction's architectural palette.
	var sect_state: Dictionary = PlayerData.stats.get("sect_state", {})
	var occupation: Dictionary = sect_state.get("settlement_ownership", {}).get(str(data.id), {})
	if bool(occupation.get("captured", false)):
		var owner_palette := {"azure_sword_hall":Color(0.22,0.48,0.95),"crimson_pavilion":Color(0.88,0.24,0.19),"stillwater_monastery":Color(0.18,0.65,0.78),"stormspire_order":Color(0.62,0.45,0.92),"veiled_moon_covenant":Color(0.36,0.32,0.58),"rootbound_circle":Color(0.28,0.62,0.32)}
		stone_color = owner_palette.get(str(occupation.get("owner", "")), stone_color)
	# Entrance stair, walled courtyard and ceremonial gate.
	_put(root, BuildingKit.make_house(12.0, 9.0, 5.2, "stone_blue" if index % 2 == 0 else "stone", "roof_blue" if index % 2 == 0 else "roof_brown", Color.WHITE), 0, -9, 0)
	_put(root, BuildingKit.make_house(8.0, 7.0, 3.8, "stone", "roof_brown", Color.WHITE), -12, 4, 0.35)
	_put(root, BuildingKit.make_house(8.0, 7.0, 3.8, "stone", "roof_brown", Color.WHITE), 12, 4, -0.35)
	for x in [-17.0, 17.0]:
		_put(root, BuildingKit.make_lamp_post(), x, -5)
		_put(root, BuildingKit.make_lamp_post(), x, 12)
	for x in [-10.0, -5.0, 0.0, 5.0, 10.0]:
		_put(root, BuildingKit.make_bench(), x, 12, PI)
	# Sect identity banner and spiritual focal point.
	var banner := MeshInstance3D.new()
	var bm := BoxMesh.new(); bm.size = Vector3(0.12, 4.5, 2.2)
	banner.mesh = bm
	banner.name = "FactionOwnershipBanner"
	var mat := StandardMaterial3D.new(); mat.albedo_color = stone_color; mat.roughness = 0.78; mat.emission_enabled = true; mat.emission = stone_color * 0.18
	banner.material_override = mat
	_put(root, banner, 0, -2, 0, 3.0)
	if bool(occupation.get("captured", false)):
		var ownership_label := Label3D.new()
		ownership_label.text = "OCCUPIED BY %s" % str(occupation.get("owner", "")).replace("_", " ").to_upper()
		ownership_label.font_size = 26
		ownership_label.position = Vector3(0, 8.0, -5.0)
		ownership_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		root.add_child(ownership_label)
		for mesh_node in root.find_children("*", "MeshInstance3D", true, false):
			if mesh_node == banner: continue
			var base_mat := mesh_node.material_override as StandardMaterial3D
			if base_mat:
				var occupied_mat := base_mat.duplicate() as StandardMaterial3D
				occupied_mat.albedo_color = occupied_mat.albedo_color.lerp(stone_color, 0.22)
				mesh_node.material_override = occupied_mat
	var altar := MeshInstance3D.new()
	var am := CylinderMesh.new(); am.top_radius = 1.8; am.bottom_radius = 2.3; am.height = 0.8
	altar.mesh = am
	altar.material_override = BuildingKit.get_material("stone_blue")
	_put(root, altar, 0, 5, 0, 0.4)
	var crystal := MeshInstance3D.new(); crystal.mesh = BuildingKit.make_crystal_mesh(0.7, 1.6)
	crystal.material_override = BuildingKit.get_material("crystal")
	_put(root, crystal, 0, 5, 0, 1.6)
	BuildingKit.add_light(root, Vector3(0, 2.8, 5), stone_color, 1.5, 12.0, 0.0, true)
	# Training yard props make each campus visibly inhabited and functional.
	for x in [-6.0, 0.0, 6.0]:
		var dummy := MeshInstance3D.new(); var dm := CapsuleMesh.new(); dm.radius = 0.42; dm.height = 2.0; dummy.mesh = dm
		var dmat := StandardMaterial3D.new(); dmat.albedo_color = Color(0.42,0.25,0.16); dummy.material_override = dmat
		_put(root, dummy, x, -18, 0, 1.0)
		_put(root, BuildingKit.make_crate(), x + 2.0, -17)
	# Master and two disciples have daily positions around their own headquarters.
	var master: NPC = NPC_SCENE.instantiate()
	master.npc_name = str(data.master); master.role = "sect_master"; master.sect_id = str(data.id)
	master.dialogue_lines = PackedStringArray(["I am %s of %s." % [str(data.master), str(data.name)], "Cultivation is earned through discipline, not haste.", "Prove your foundation in the examination grounds and we may speak of the Dao."])
	master.schedule = [{"h":6.0,"pos":Vector2(center.x - 4, center.y - 4)}, {"h":10.0,"pos":Vector2(center.x, center.y + 5)}, {"h":14.0,"pos":Vector2(center.x + 24, center.y + 18)}, {"h":18.0,"pos":Vector2(center.x - 4, center.y - 4)}, {"h":22.0,"pos":Vector2(center.x - 4, center.y - 4),"sleep":true}]
	master.home_center = Vector3(center.x, root.position.y, center.y)
	_put(root, master, -4, -4, 0)
	for j in range(2):
		var disciple: NPC = NPC_SCENE.instantiate()
		disciple.npc_name = ["Disciple %s" % (index * 2 + 1), "Disciple %s" % (index * 2 + 2)][j]
		disciple.role = "sect_disciple"; disciple.sect_id = str(data.id)
		disciple.dialogue_lines = PackedStringArray(["I train beneath %s." % str(data.master), "The sect grounds are open to those who respect our rules."])
		disciple.schedule = [{"h":6.0,"pos":Vector2(center.x - 6 + j * 12, center.y - 18)}, {"h":12.0,"pos":Vector2(center.x - 8 + j * 16, center.y + 12)}, {"h":18.0,"pos":Vector2(center.x - 6 + j * 12, center.y - 18)}]
		disciple.home_center = Vector3(center.x, root.position.y, center.y)
		_put(root, disciple, -6 + j * 12, -18, 0)

func _build_elyndor_village() -> void:
	_village = _make_root("ElyndorVillage", TerrainNoise.VILLAGE_CENTER, TerrainNoise.VILLAGE_HEIGHT)
	var plaza := Vector2.ZERO

	# Houses: [door point (local), depth, w, wall_h, wall mat, roof mat, tint]
	var houses: Array = [
		[Vector2(-14, -9), 5.0, 6.4, 2.8, "plaster_cream", "roof_clay", Color(1, 1, 1)],
		[Vector2(12, -10), 5.6, 5.2, 2.9, "plaster_white", "roof_brown", Color(0.96, 0.92, 0.86)],
		[Vector2(-13, 10), 5.4, 7.0, 3.0, "plaster_rose", "roof_clay", Color(1, 0.97, 0.95)],
		[Vector2(13, 9), 6.0, 5.6, 3.7, "plaster_blue", "roof_brown", Color(1, 1, 1)],
	]
	for h in houses:
		var door_pt: Vector2 = h[0]
		var outward: Vector2 = door_pt.normalized()
		var depth: float = h[1]
		var center: Vector2 = door_pt + outward * (depth * 0.5 + 0.9)
		var house: Node3D = BuildingKit.make_house(h[2], depth, h[3], h[4], h[5], h[6])
		_put(_village, house, center.x, center.y, _facing(center, plaza))

	# Plaza: fountain, benches, lamps
	_put(_village, BuildingKit.make_fountain(), 0, 0)
	for i in range(4):
		var a: float = TAU * float(i) / 4.0 + 0.0
		var p := Vector2(cos(a), sin(a)) * 5.5
		_put(_village, BuildingKit.make_bench(), p.x, p.y, atan2(p.x, p.y))
	var lamps: Array[Vector2] = [Vector2(6.2, 6.2), Vector2(-6.2, 6.2), Vector2(6.2, -6.2), Vector2(-6.2, -6.2),
		Vector2(-3.0, 16.0), Vector2(3.0, 16.0), Vector2(9.5, 0.0), Vector2(-9.5, 0.0), Vector2(0, -16.0)]
	for l in lamps:
		_put(_village, BuildingKit.make_lamp_post(), l.x, l.y)

	# Market
	_put(_village, BuildingKit.make_market_stall("cloth_red"), 9.6, -3.2, _facing(Vector2(9.6, -3.2), plaza))
	_put(_village, BuildingKit.make_market_stall("cloth_blue"), 9.8, 2.8, _facing(Vector2(9.8, 2.8), plaza))
	_put(_village, BuildingKit.make_barrel(), 11.8, -1.0)
	_put(_village, BuildingKit.make_barrel(), 12.6, -0.3)
	_put(_village, BuildingKit.make_crate(), 11.9, 0.9)
	_put(_village, BuildingKit.make_crate(0.7), 12.2, 1.9, 0.5)

	# Smithy + alchemy table (crafting stations)
	var smithy_c := Vector2(-6.5, -14.5)
	var smithy: Node3D = BuildingKit.make_smithy()
	_put(_village, smithy, smithy_c.x, smithy_c.y, _facing(smithy_c, plaza))
	var forge_station := CraftingStation.new()
	forge_station.station_type = "forge"
	forge_station.prompt = "Use the Forge"
	forge_station.position = Vector3(0.5, 0.0, 1.2)
	smithy.add_child(forge_station)
	var alch_c := Vector2(-8.0, 9.5)
	var alch: Node3D = BuildingKit.make_alchemy_table()
	_put(_village, alch, alch_c.x, alch_c.y, _facing(alch_c, plaza))
	var alch_station := CraftingStation.new()
	alch_station.station_type = "alchemy"
	alch_station.prompt = "Use the Alchemy Table"
	alch_station.position = Vector3(1.0, 0.0, 1.1)
	alch.add_child(alch_station)

	# Village campfire (cooking)
	var fire := WorldProps.make_campfire()
	var fire_station := CraftingStation.new()
	fire_station.station_type = "campfire"
	fire_station.prompt = "Cook at Campfire"
	fire_station.position = Vector3(0, 0, 0)
	fire.add_child(fire_station)
	_put(_village, fire, 1.5, -8.5)

	# Well, notice board, supplies by houses
	_put(_village, BuildingKit.make_well(), -9.0, 3.0)
	_put(_village, BuildingKit.make_notice_board(), 2.5, 11.5, 0.0)
	_put(_village, BuildingKit.make_barrel(), -19.5, -6.0)
	_put(_village, BuildingKit.make_crate(), -20.5, -5.0, 0.4)
	_put(_village, BuildingKit.make_barrel(), 17.5, 7.0)

	# Farm
	_put(_village, BuildingKit.make_crop_field(14.0, 8.0), 0, -24.0)
	_put(_village, BuildingKit.make_scarecrow(), 0, -24.0, 0.3)
	var fences: Array = [[0.0, -28.4, 14.8, 0.0], [-7.4, -24.0, 8.8, PI * 0.5], [7.4, -24.0, 8.8, PI * 0.5],
		[-4.8, -19.6, 5.2, 0.0], [4.8, -19.6, 5.2, 0.0]]
	for f in fences:
		_put(_village, BuildingKit.make_fence(f[2]), f[0], f[1], f[3])
	_put(_village, BuildingKit.make_hay_bale(), 10.0, -19.0, 0.3)
	_put(_village, BuildingKit.make_hay_bale(), 11.4, -19.8, -0.4)
	_put(_village, BuildingKit.make_hay_bale(), 10.6, -17.7, 0.1, 1.0)

	# A few big shade trees
	_tree(_village, -22.0, -2.0, "broadleaf", 1.35)
	_tree(_village, 22.0, -6.0, "broadleaf", 1.25)
	_tree(_village, -21.0, 15.0, "broadleaf", 1.30)
	_tree(_village, 23.0, 14.0, "broadleaf", 1.20)
	_tree(_village, 14.0, -24.0, "broadleaf", 1.25)
	_tree(_village, -15.0, -22.0, "broadleaf", 1.15)

	# The village grows beyond a handful of houses: an inn, a stable yard,
	# produce storage and a small roadside gathering place give the settlement
	# believable working spaces without changing its existing NPC/job logic.
	var inn_center := Vector2(24.0, -20.0)
	var inn := BuildingKit.make_house(10.5, 8.5, 4.0, "plaster_cream", "roof_clay", Color(1.0, 0.96, 0.86))
	_put(_village, inn, inn_center.x, inn_center.y, _facing(inn_center, plaza))
	var inn_sign := Label3D.new()
	inn_sign.text = "THE WAYFARER'S REST"
	inn_sign.font_size = 22
	inn_sign.modulate = Color(1.0, 0.82, 0.48)
	inn_sign.position = Vector3(0.0, 4.1, -4.55)
	inn.add_child(inn_sign)
	_put(_village, BuildingKit.make_market_stall("cloth_red"), 22.0, -11.5, PI)
	_put(_village, BuildingKit.make_barrel(), 29.0, -17.0)
	_put(_village, BuildingKit.make_crate(), 29.8, -16.2, 0.3)
	# Stable enclosure: timber rails, feed and hitching posts make mounts feel
	# like part of the world rather than inventory-only objects.
	var stable_center := Vector2(30.0, -39.0)
	var stable := Node3D.new()
	stable.name = "ElyndorStableYard"
	_put(_village, stable, stable_center.x, stable_center.y)
	for fence_data in [[0.0, -5.0, 12.0, 0.0], [0.0, 5.0, 12.0, 0.0], [-6.0, 0.0, 10.0, PI * 0.5], [6.0, 0.0, 10.0, PI * 0.5]]:
		stable.add_child(BuildingKit.make_fence(float(fence_data[2])))
		stable.get_child(stable.get_child_count() - 1).position = Vector3(float(fence_data[0]), 0.0, float(fence_data[1]))
		stable.get_child(stable.get_child_count() - 1).rotation.y = float(fence_data[3])
	var feed := BuildingKit.make_hay_bale()
	feed.position = Vector3(-3.5, 0.0, -2.5)
	stable.add_child(feed)
	var feed_two := BuildingKit.make_hay_bale()
	feed_two.position = Vector3(-2.2, 0.0, -2.5)
	stable.add_child(feed_two)
	for post_x in [-4.0, 4.0]:
		var post := MeshInstance3D.new()
		var post_mesh := BoxMesh.new(); post_mesh.size = Vector3(0.22, 1.8, 0.22)
		post.mesh = post_mesh
		post.position = Vector3(post_x, 0.9, 0.0)
		var post_mat := StandardMaterial3D.new(); post_mat.albedo_color = Color(0.28, 0.19, 0.12); post_mat.roughness = 0.94
		post.material_override = post_mat
		stable.add_child(post)
	# A small orchard and woodpile soften the village edge and frame the farm road.
	for orchard_point in [Vector2(22.0, -29.0), Vector2(26.0, -30.0), Vector2(20.0, -34.0), Vector2(25.0, -35.0)]:
		_tree(_village, orchard_point.x, orchard_point.y, "cherry", 0.88)
	_put(_village, BuildingKit.make_barrel(), -23.0, -16.0)
	_put(_village, BuildingKit.make_crate(0.75), -21.8, -16.2, 0.25)

	# --- Set dressing -------------------------------------------------------
	# The square now reads as a working village: a named gateway, hauling
	# carts, washing, firewood and market clutter frame every approach.
	_put(_village, WorldProps.make_arch("ELYNDOR"), 0.0, 18.8, 0.0)
	_put(_village, BuildingKit.make_lamp_post(), -3.6, 18.6)
	_put(_village, BuildingKit.make_lamp_post(), 3.6, 18.6)
	_put(_village, WorldProps.make_signpost([
		{"text": "ELYNDOR", "dir": Vector2(0, -1)},
		{"text": "ARCANE SPIRE", "dir": Vector2(-1, -0.7)},
		{"text": "WHISPERING WOODS", "dir": Vector2(-0.75, 0.65)},
	]), 5.2, 15.9)
	_village.add_child(WorldProps.make_bunting(Vector3(-6.2, 3.08, 6.2), Vector3(6.2, 3.08, 6.2), 0.42))
	_village.add_child(WorldProps.make_bunting(Vector3(-6.2, 3.08, -6.2), Vector3(6.2, 3.08, -6.2), 0.42))
	_put(_village, WorldProps.make_cart(true), 18.6, -15.2, 1.25)
	_put(_village, WorldProps.make_cart(true), 14.2, 6.4, -0.85)
	_put(_village, WorldProps.make_cart(false), -7.4, -20.4, 0.5)
	_put(_village, WorldProps.make_woodpile(), -11.6, -17.4, 0.15)
	_put(_village, WorldProps.make_laundry_line(4.6), -16.2, -1.2, PI * 0.5)
	_put(_village, WorldProps.make_laundry_line(4.2), 22.4, 11.8, 1.0)
	_put(_village, WorldProps.make_trough(), 26.6, -36.2, 0.0)
	for planter_point in [Vector2(-15.6, -6.4), Vector2(9.4, -7.4), Vector2(-14.8, 7.2), Vector2(15.4, 6.0)]:
		_put(_village, WorldProps.make_planter(), planter_point.x, planter_point.y)
	_put(_village, WorldProps.make_sack_pile(), 13.6, 4.6)
	_put(_village, WorldProps.make_sack_pile(), -2.9, -18.8)
	_put(_village, WorldProps.make_sack_pile(), 27.8, -22.2)

	# Villagers - each follows a daily routine: [hour, local position, sleeps there?]
	_spawn_npc(_village, "Elara", "villager", [
		"Welcome to Elyndor, child.",
		"The fields need tending when you grow stronger.",
		"Have you seen the glowing tower on the hill?"
	], plaza, [[6.0, Vector2(-7.0, 5.0)], [9.0, Vector2(-3.8, 4.6)], [13.0, Vector2(7.0, 0.3)],
		[17.0, Vector2(-3.8, 4.6)], [20.5, Vector2(-12.0, 9.0), true]])
	_spawn_npc(_village, "Borin", "farmer", [
		"The soil here is kind if you respect it.",
		"Farming is honest work. Chopping, planting, harvesting."
	], Vector2(0, -24), [[6.0, Vector2(9.5, -23.5)], [12.0, Vector2(-9.0, -22.0)], [16.0, Vector2(9.5, -23.5)],
		[18.5, Vector2(4.0, 6.0)], [20.5, Vector2(12.0, -8.5), true]])
	_spawn_npc(_village, "Old Man Thoren", "elder", [
		"You arrived under strange stars...",
		"The Arcane Spire awaits those who seek knowledge.",
		"Grow wisely, young one."
	], plaza, [[7.0, Vector2(3.8, -4.2)], [11.0, Vector2(2.5, 9.0)], [15.0, Vector2(3.8, -4.2)],
		[19.0, Vector2(3.8, 4.6)], [21.0, Vector2(12.0, 7.5), true]])
	_spawn_npc(_village, "Gorrim the Smith", "smith", [
		"Steel, sweat and patience. That's smithing.",
		"Every skill grows by doing. Swing the hammer, and the hammer teaches you."
	], smithy_c, [[6.5, Vector2(-5.3, -11.2)], [18.0, Vector2(3.8, -3.8)], [20.0, Vector2(-13.0, -8.0), true]])
	_spawn_npc(_village, "Mira", "merchant", [
		"Welcome, welcome! Potions, tonics, ore, whatever you need.",
		"Sell me your spoils and I'll pay fair coin."
	], Vector2(0, -3.2), [[7.0, Vector2(11.4, -3.2)], [18.5, Vector2(11.4, -3.2)], [20.0, Vector2(13.0, 8.5), true]])

	_spawn_npc(_village, "Tomas the Guard", "villager", [
		"I walk the fence line dawn to dusk.",
		"Keep your eyes open on the roads."
	], plaza, [[6.0, Vector2(14.0, 2.0)], [12.0, Vector2(-14.0, 2.0)], [18.0, Vector2(14.0, -10.0)],
		[21.0, Vector2(-10.0, -6.0), true]])
	_spawn_npc(_village, "Sera the Herbalist", "villager", [
		"Moonpetal loves the meadow edge.",
		"Bring me herbs and I'll teach you a thing or two."
	], Vector2(-3.8, 4.6), [[7.0, Vector2(-16.0, 6.0)], [11.0, Vector2(8.0, -16.0)], [16.0, Vector2(-3.8, 4.6)],
		[20.5, Vector2(-14.0, 8.0), true]])
	_spawn_npc(_village, "Junn the Fisher", "villager", [
		"The river still gives if you're patient.",
		"Try your luck with a rod near the banks."
	], Vector2(10, -5), [[6.5, Vector2(18.0, -12.0)], [13.0, Vector2(16.0, 8.0)], [19.0, Vector2(10.0, -5.0)],
		[21.0, Vector2(12.0, 6.0), true]])
	_spawn_npc(_village, "Pia", "farmer", [
		"Bread starts in the dirt, not the oven.",
		"The scarecrow does half my worrying for me."
	], Vector2(0, -24), [[6.0, Vector2(-8.0, -26.0)], [10.0, Vector2(6.0, -22.0)], [15.0, Vector2(-4.0, -24.0)],
		[20.0, Vector2(8.0, -10.0), true]])

	_spawn_npc(_village, "Rellan the Stablehand", "villager", [
		"The road is kinder when your mount is well cared for.",
		"Keep a little feed in your pack. Long journeys test every beast."
	], stable_center, [[6.0, Vector2(27.0, -38.0)], [11.0, Vector2(31.0, -39.0)], [16.0, Vector2(28.0, -40.0)], [20.5, Vector2(24.0, -20.0), true]])

func _build_elyndor_bridge() -> void:
	# A walkable timber crossing spans the authored north-south river where the
	# eastern trade road fords it; deck, road grade and abutments share one height.
	var bridge := Node3D.new()
	bridge.name = "ElyndorRiverBridge"
	# Deck follows the trade road's crossing direction so the road grade and the
	# walkable deck stay aligned; height comes from the shared terrain profile.
	bridge.position = Vector3(TerrainNoise.BRIDGE_CENTER.x, noise.bridge_deck_height(), TerrainNoise.BRIDGE_CENTER.y)
	bridge.rotation.y = -atan2(TerrainNoise.BRIDGE_DIR.y, TerrainNoise.BRIDGE_DIR.x)
	add_child(bridge)
	var timber := StandardMaterial3D.new()
	timber.albedo_color = Color(0.34, 0.23, 0.14)
	timber.roughness = 0.92
	var worn_plank := StandardMaterial3D.new()
	worn_plank.albedo_color = Color(0.48, 0.35, 0.22)
	worn_plank.roughness = 0.88
	var stone := StandardMaterial3D.new()
	stone.albedo_color = Color(0.37, 0.39, 0.36)
	stone.roughness = 0.98
	var deck_body := StaticBody3D.new()
	deck_body.name = "BridgeDeckCollision"
	deck_body.collision_layer = Constants.LAYER_WORLD
	deck_body.collision_mask = 0
	var deck_shape := CollisionShape3D.new()
	var deck_box := BoxShape3D.new(); deck_box.size = Vector3(30.0, 0.42, 3.8)
	deck_shape.shape = deck_box
	deck_shape.position.y = -0.08
	deck_body.add_child(deck_shape)
	bridge.add_child(deck_body)
	for i in range(38):
		var plank := MeshInstance3D.new()
		var mesh := BoxMesh.new(); mesh.size = Vector3(0.72, 0.20, 3.8)
		plank.mesh = mesh
		plank.position = Vector3(-14.45 + float(i) * 0.78, 0.0, 0.0)
		plank.material_override = worn_plank if i % 3 == 0 else timber
		bridge.add_child(plank)
	for side in [-1.0, 1.0]:
		var rail := MeshInstance3D.new()
		var rail_mesh := BoxMesh.new(); rail_mesh.size = Vector3(30.0, 0.22, 0.24)
		rail.mesh = rail_mesh
		rail.position = Vector3(0.0, 1.18, side * 1.82)
		rail.material_override = timber
		bridge.add_child(rail)
		for post_index in range(18):
			var post := MeshInstance3D.new()
			var post_mesh := BoxMesh.new(); post_mesh.size = Vector3(0.24, 1.35, 0.24)
			post.mesh = post_mesh
			post.position = Vector3(-14.3 + float(post_index) * 1.74, 0.65, side * 1.82)
			post.material_override = timber
			bridge.add_child(post)
	# Masonry abutments and two piers visibly carry the bridge load.
	for x_pos in [-14.0, 14.0]:
		var abutment := MeshInstance3D.new()
		var abutment_mesh := BoxMesh.new(); abutment_mesh.size = Vector3(1.0, 1.0, 4.5)
		abutment.mesh = abutment_mesh
		abutment.position = Vector3(x_pos, -0.42, 0.0)
		abutment.material_override = stone
		bridge.add_child(abutment)
	for x_pos in [-5.5, 5.5]:
		var pier := MeshInstance3D.new()
		var pier_mesh := BoxMesh.new()
		var pier_height := maxf(1.2, bridge.position.y - Constants.WATER_LEVEL)
		pier_mesh.size = Vector3(0.9, pier_height, 1.0)
		pier.mesh = pier_mesh
		pier.position = Vector3(x_pos, -pier_height * 0.5 - 0.12, 0.0)
		pier.material_override = stone
		bridge.add_child(pier)

func _build_elyndor_hunting_camp() -> void:
	# A modest working camp marks the transition from safe farmland to the
	# Whispering Woods hunting grounds. Hunting remains ordinary RPG gameplay.
	var center := Vector2(-88.0, 24.0)
	var camp := _make_root("ElyndorWhisperingWoodsHuntingCamp", center, noise.get_height(center.x, center.y))
	var shelter := BuildingKit.make_house(6.8, 5.8, 2.7, "wood", "thatch", Color(0.92, 0.88, 0.76))
	_put(camp, shelter, -2.8, -2.0, PI * 0.5)
	_put(camp, BuildingKit.make_crate(), 3.2, -1.8)
	_put(camp, BuildingKit.make_barrel(), 4.1, -1.0)
	_put(camp, BuildingKit.make_fence(5.5), -1.0, 4.0, 0.0)
	_put(camp, BuildingKit.make_fence(5.5), 4.5, 4.0, 0.0)
	# A timber drying rack and hide frame make the hunting profession legible.
	for side in [-1.0, 1.0]:
		var upright := MeshInstance3D.new()
		var upright_mesh := BoxMesh.new(); upright_mesh.size = Vector3(0.16, 2.2, 0.16)
		upright.mesh = upright_mesh
		upright.position = Vector3(side * 1.35, 1.1, 2.0)
		upright.material_override = BuildingKit.get_material("wood_dark")
		camp.add_child(upright)
	var rack_bar := MeshInstance3D.new()
	var rack_mesh := BoxMesh.new(); rack_mesh.size = Vector3(2.9, 0.16, 0.16)
	rack_bar.mesh = rack_mesh
	rack_bar.position = Vector3(0.0, 2.0, 2.0)
	rack_bar.material_override = BuildingKit.get_material("wood")
	camp.add_child(rack_bar)
	var hide := MeshInstance3D.new()
	var hide_mesh := QuadMesh.new(); hide_mesh.size = Vector2(1.8, 1.2)
	hide.mesh = hide_mesh
	hide.position = Vector3(0.0, 1.35, 2.08)
	var hide_mat := StandardMaterial3D.new(); hide_mat.albedo_color = Color(0.48, 0.31, 0.20); hide_mat.roughness = 1.0; hide_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	hide.material_override = hide_mat
	camp.add_child(hide)
	_put(camp, WorldProps.make_campfire(), 3.2, 2.8)
	_put(camp, WorldProps.make_woodpile(), -6.6, 2.4, 0.35)
	_put(camp, WorldProps.make_signpost([
		{"text": "ELYNDOR", "dir": Vector2(0.6, -0.8)},
		{"text": "WHISPERING WOODS", "dir": Vector2(-0.9, 0.4)},
	]), -4.9, 5.2)
	_put(camp, WorldProps.make_trough(), 5.6, 0.4, PI * 0.5)
	_spawn_npc(camp, "Tarin the Tracker", "hunter", [
		"The woods are generous, but never careless. Read the tracks before you loose an arrow.",
		"A clean hunt leaves the forest healthy enough to feed the next season.",
		"Follow the broken fern stems west. Something large passed through before dawn."
	], Vector2(0.0, 0.0), [[6.0, Vector2(1.0, 0.5)], [10.0, Vector2(-8.0, 6.0)], [14.0, Vector2(-15.0, 11.0)], [18.0, Vector2(1.0, 0.5)], [21.0, Vector2(-2.8, -2.0), true]])

func _build_region_identity_gates() -> void:
	# Ten regional entrance monuments establish distinct architectural identities
	# as players travel outward from Elyndor. These are landmarks, not substitutes
	# for the future full capital/settlement builds in each territory.
	var palettes: Array[Color] = [
		Color(0.55, 0.76, 0.91), Color(0.34, 0.27, 0.24), Color(0.24, 0.62, 0.70),
		Color(0.72, 0.66, 0.52), Color(0.31, 0.49, 0.34), Color(0.68, 0.43, 0.25),
		Color(0.43, 0.47, 0.51), Color(0.39, 0.35, 0.26), Color(0.77, 0.59, 0.34),
		Color(0.43, 0.25, 0.22)
	]
	for i in range(TerrainNoise.REGIONS.size()):
		var data: Dictionary = TerrainNoise.REGIONS[i]
		var region_center: Vector2 = data["center"]
		var rx: float = float(data["rx"])
		var rz: float = float(data["rz"])
		var offset := Vector2(rx * 0.66, rz * 0.10)
		var point := region_center + offset
		var root := Node3D.new()
		root.name = "RegionGate_%02d_%s" % [i + 1, str(data["name"]).replace(" ", "_")]
		root.position = Vector3(point.x, noise.get_height(point.x, point.y), point.y)
		add_child(root)
		var stone := StandardMaterial3D.new()
		stone.albedo_color = palettes[i % palettes.size()]
		stone.roughness = 0.86
		var accent := StandardMaterial3D.new()
		accent.albedo_color = palettes[i % palettes.size()].lightened(0.22)
		accent.emission_enabled = i in [0, 1, 2, 8, 9]
		accent.emission = palettes[i % palettes.size()] * 0.22
		accent.roughness = 0.52
		var pillar_width := 1.05 if i not in [6, 7] else 1.45
		for side in [-1.0, 1.0]:
			var pillar := MeshInstance3D.new()
			var pillar_mesh := BoxMesh.new(); pillar_mesh.size = Vector3(pillar_width, 5.4, 1.15)
			pillar.mesh = pillar_mesh
			pillar.position = Vector3(side * 3.1, 2.7, 0.0)
			pillar.material_override = stone
			root.add_child(pillar)
			var cap := MeshInstance3D.new()
			var cap_mesh := PrismMesh.new(); cap_mesh.size = Vector3(2.0, 1.0, 1.55)
			cap.mesh = cap_mesh
			cap.position = Vector3(side * 3.1, 5.85, 0.0)
			cap.material_override = accent
			root.add_child(cap)
		var lintel := MeshInstance3D.new()
		var lintel_mesh := BoxMesh.new(); lintel_mesh.size = Vector3(7.2, 0.9, 1.35)
		lintel.mesh = lintel_mesh
		lintel.position = Vector3(0.0, 5.35, 0.0)
		lintel.material_override = stone
		root.add_child(lintel)
		var crest := MeshInstance3D.new()
		if i in [0, 2, 4, 5, 8]:
			var crest_mesh := CylinderMesh.new(); crest_mesh.top_radius = 0.25; crest_mesh.bottom_radius = 0.95; crest_mesh.height = 1.7
			crest.mesh = crest_mesh
		else:
			var crest_mesh := PrismMesh.new(); crest_mesh.size = Vector3(1.35, 2.0, 1.35)
			crest.mesh = crest_mesh
		crest.position = Vector3(0.0, 6.55, 0.0)
		crest.material_override = accent
		root.add_child(crest)
		# Architectural language changes by region, not just by paint colour.
		match i:
			0: # Frostveil: faceted ice obelisks
				for side in [-1.0, 1.0]:
					var shard := MeshInstance3D.new()
					var shard_mesh := PrismMesh.new(); shard_mesh.size = Vector3(0.72, 3.4, 0.72)
					shard.mesh = shard_mesh
					shard.position = Vector3(side * 4.3, 2.0, 0.0)
					shard.material_override = accent
					root.add_child(shard)
			1: # Cinderwake: three jagged furnace spires
				for shard_index in range(3):
					var spire := MeshInstance3D.new()
					var spire_mesh := PrismMesh.new(); spire_mesh.size = Vector3(0.85, 3.0 + float(shard_index) * 0.8, 0.85)
					spire.mesh = spire_mesh
					spire.position = Vector3(-1.0 + float(shard_index), 1.5 + float(shard_index) * 0.4, 1.1)
					spire.material_override = accent
					root.add_child(spire)
			2: # Mirrorwater: reflective basin at the threshold
				var basin := MeshInstance3D.new()
				var basin_mesh := CylinderMesh.new(); basin_mesh.top_radius = 3.0; basin_mesh.bottom_radius = 3.2; basin_mesh.height = 0.18; basin_mesh.radial_segments = 32
				basin.mesh = basin_mesh
				basin.position.y = 0.08
				basin.material_override = BuildingKit.get_material("water_basin")
				root.add_child(basin)
			3: # Elyndor: timber cross-beams and a welcoming roofline
				var beam := MeshInstance3D.new()
				var beam_mesh := BoxMesh.new(); beam_mesh.size = Vector3(8.0, 0.22, 0.22)
				beam.mesh = beam_mesh
				beam.position.y = 4.35
				beam.material_override = BuildingKit.get_material("wood_dark")
				root.add_child(beam)
			4: # Whispering Woods: living canopy crown
				var canopy := MeshInstance3D.new()
				var canopy_mesh := SphereMesh.new(); canopy_mesh.radius = 2.0; canopy_mesh.height = 2.8; canopy_mesh.radial_segments = 16; canopy_mesh.rings = 8
				canopy.mesh = canopy_mesh
				canopy.position.y = 7.0
				canopy.material_override = accent
				root.add_child(canopy)
			5: # Amberleaf: broad pitched stone roof
				var roof := MeshInstance3D.new()
				var roof_mesh := PrismMesh.new(); roof_mesh.size = Vector3(8.2, 1.8, 2.3)
				roof.mesh = roof_mesh
				roof.position.y = 6.15
				roof.material_override = accent
				root.add_child(roof)
			6: # Ironback: heavy stepped plinths
				for side in [-1.0, 1.0]:
					var base := MeshInstance3D.new()
					var base_mesh := BoxMesh.new(); base_mesh.size = Vector3(2.2, 0.7, 1.8)
					base.mesh = base_mesh
					base.position = Vector3(side * 3.1, 0.35, 0.0)
					base.material_override = accent
					root.add_child(base)
			7: # Mirefen: raised boardwalk threshold on timber stilts
				var boardwalk := MeshInstance3D.new()
				var board_mesh := BoxMesh.new(); board_mesh.size = Vector3(9.0, 0.28, 2.8)
				boardwalk.mesh = board_mesh
				boardwalk.position = Vector3(0.0, 0.5, 2.2)
				boardwalk.material_override = BuildingKit.get_material("wood")
				root.add_child(boardwalk)
				for side in [-1.0, 1.0]:
					var stilt := MeshInstance3D.new()
					var stilt_mesh := CylinderMesh.new(); stilt_mesh.top_radius = 0.16; stilt_mesh.bottom_radius = 0.2; stilt_mesh.height = 1.3
					stilt.mesh = stilt_mesh
					stilt.position = Vector3(side * 3.6, -0.15, 2.2)
					stilt.material_override = BuildingKit.get_material("wood_dark")
					root.add_child(stilt)
			8: # Sunscorch: flat sandstone sunshade
				var shade := MeshInstance3D.new()
				var shade_mesh := BoxMesh.new(); shade_mesh.size = Vector3(8.6, 0.42, 2.6)
				shade.mesh = shade_mesh
				shade.position.y = 6.35
				shade.material_override = accent
				root.add_child(shade)
			9: # Emberfall: glowing basalt shard crown
				for shard_index in range(4):
					var shard := MeshInstance3D.new()
					var shard_mesh := PrismMesh.new(); shard_mesh.size = Vector3(0.55, 2.0 + float(shard_index % 2), 0.55)
					shard.mesh = shard_mesh
					shard.position = Vector3(-1.5 + float(shard_index), 6.8, 0.5)
					shard.material_override = accent
					root.add_child(shard)
		var title := Label3D.new()
		title.text = str(data["name"]).to_upper()
		title.font_size = 22
		title.modulate = palettes[i % palettes.size()].lightened(0.35)
		title.position = Vector3(0.0, 7.9, 0.0)
		title.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		root.add_child(title)

# ---------------------------------------------------------------------------
# Arcane Spire
# ---------------------------------------------------------------------------
func _build_arcane_spire() -> void:
	_spire = _make_root("ArcaneSpire", TerrainNoise.SPIRE_CENTER, TerrainNoise.SPIRE_HEIGHT)
	_spire.add_child(BuildingKit.make_spire())
	_spawn_npc(_spire, "Archmage Lira", "mage", [
		"The Spire recognizes potential.",
		"Magic answers those who respect it."
	], Vector2(0, 30), [[0.0, Vector2(0, 10.5)]])
	_spawn_npc(_spire, "Apprentice Kael", "mage", [
		"I only started last season...",
		"The books float if you ask nicely."
	], Vector2(0, 10.5), [[6.0, Vector2(-6.5, 6.5)], [12.0, Vector2(6.5, 6.5)], [18.0, Vector2(0.0, 8.0)]])
	_spawn_npc(_spire, "Master Ren", "swordmaster", [
		"A blade is not the path. It is the question you ask with your whole body.",
		"Bring me proof of your discipline, not tales of imagined talent.",
		"The old counter-form is dangerous. Learn to read intent before you attempt it."
	], Vector2(-10.0, -4.0), [[7.0, Vector2(-8.0, -5.5)], [13.0, Vector2(-6.0, -3.5)], [18.0, Vector2(-8.0, -5.5)]])
	_spawn_npc(_spire, "Vein Reader Yun", "spirit_master", [
		"The world is threaded with currents that cannot be seen by ordinary sight.",
		"A spiritual root is a beginning, not a destiny.",
		"Listen at the landmarks. The old techniques are scattered through the land."
	], Vector2(10.0, -4.0), [[7.0, Vector2(8.0, -5.5)], [13.0, Vector2(6.0, -3.5)], [18.0, Vector2(8.0, -5.5)]])

func _spawn_npc(root: Node3D, npc_name: String, role: String, lines: Array, look_at: Vector2, routine: Array) -> void:
	var npc: NPC = NPC_SCENE.instantiate()
	npc.npc_name = npc_name
	npc.role = role
	npc.dialogue_lines = PackedStringArray(lines)
	var sched: Array = []
	for r in routine:
		var lp: Vector2 = r[1]
		sched.append({"h": float(r[0]), "pos": Vector2(root.position.x + lp.x, root.position.z + lp.y), "sleep": r.size() > 2 and bool(r[2])})
	npc.schedule = sched
	npc.free_will = true
	npc.home_center = Vector3(root.position.x + routine[0][1].x, root.position.y, root.position.z + routine[0][1].y)
	npc.wander_radius = 18.0
	var first: Vector2 = routine[0][1]
	npc.look_target = Vector2(root.position.x + look_at.x, root.position.z + look_at.y)
	npc.has_look_target = true
	_put(root, npc, first.x, first.y, _look_yaw(first, look_at))
