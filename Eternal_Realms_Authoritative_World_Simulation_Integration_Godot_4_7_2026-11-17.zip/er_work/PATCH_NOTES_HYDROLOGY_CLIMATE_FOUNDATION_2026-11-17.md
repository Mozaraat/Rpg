# Eternal Realms — Hydrology and Climate Foundation

## Added

- `ClimateSystem` autoload: game-calendar seasons, hemisphere-aware seasonal temperature swing, altitude cooling, daily temperature cycle, regional humidity, precipitation potential and deterministic prevailing wind.
- `HydrologySystem` autoload: local rainfall partition into runoff and infiltration, soil saturation, groundwater recharge, surface-water accumulation, approximate stream discharge, flood-risk estimate, slope sampling, downhill flow direction and a coarse erosion index.
- Weather-to-water coupling: clear/fog/rain/storm states scale precipitation entering the local water budget.
- Climate samples update the shared physical atmosphere (temperature, humidity, pressure, density and wind) so other systems can query one consistent environment.

## Integration contract

- Query `ClimateSystem.sample_at(world_position)` for a climate snapshot.
- Query `HydrologySystem.update_cell(world_position, delta_seconds)` for a water-budget update.
- Query `HydrologySystem.flow_direction_at`, `slope_degrees_at`, `get_flood_risk`, `get_groundwater_mm`, `get_stream_flow_m3_s` and `get_erosion_index` from terrain, farming, settlement and ecosystem systems.
- `HydrologySystem` samples the existing terrain height field through the active `chunk_manager` when available.

## Accuracy boundary

This is a first gameplay-scale foundation, not a physically complete climate or watershed solver. It does not yet generate a globally connected river network, conserve water across all neighbouring cells, solve atmospheric circulation, simulate groundwater aquifers, or deform terrain through erosion. Regional state is held in memory and is not yet persisted or synchronized by the authoritative multiplayer backend. Stream discharge is a coarse catchment estimate and should not be treated as a measured river forecast.

## Validation

Static source review only. Godot 4.7 executable is not available in this environment, so engine parsing, scene startup, performance profiling and live gameplay validation remain outstanding.
