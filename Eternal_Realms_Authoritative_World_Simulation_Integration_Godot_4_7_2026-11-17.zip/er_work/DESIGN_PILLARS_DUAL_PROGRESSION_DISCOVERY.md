# Eternal Realms — Dual Progression and Rare Cultivation Discovery

## Core rule

Traditional MMORPG progression is the foundation of Eternal Realms. Cultivation is an ultra-rare, earned discovery layered into the persistent world. It is not a character-creation choice, a class, a guaranteed awakening, a level reward, or a mandatory route to influence.

A character may remain mortal for their entire story and still become a legendary warrior, master artisan, merchant magnate, guild leader, commander, ruler, explorer, assassin, or political power. Mortal achievements must remain meaningful in every era. Cultivators have unusual capabilities, but do not automatically outrank mortal institutions, armies, economies, technology, alliances, or expertise.

## Discovery journey

1. **Ordinary life:** players begin with conventional RPG systems. The game does not tell them they are destined for cultivation.
2. **Unusual discoveries:** ancient archives, memory tablets, sealed runic chambers, spiritual landmarks, ruins and unusual people can leave clues. Discoveries are evidence, not automatic unlocks.
3. **Recognition:** after collecting several clues, a knowledgeable master or other qualified figure may recognise a pattern.
4. **Genuine test:** a character must demonstrate comprehension and willpower, plus evidence of spiritual compatibility. Failure is recorded; the character may need more preparation.
5. **Legitimate method:** only a real method entrusted by a master, manual, sect inheritance or equivalent source can begin cultivation.
6. **Lifetime progression:** cultivation then requires practice, resources, comprehension, preparation, dangerous breakthroughs and further discoveries.

## Current implementation rules

- Three distinct clue records are required before recognition becomes available.
- Comprehension is derived from Knowledge, Wisdom, Ancient Lore and Observation.
- Willpower is derived separately from demonstrated endurance and discipline (Vitality, Unarmed, Shield, Wisdom and Stealth). It is not the same score as comprehension.
- The first method trial requires both scores to reach the current threshold, at least one developed elemental affinity, Spiritual Sense, and a qualified NPC who can recognise the evidence.
- The first method is recorded with its identifier, source, compatibility evidence, attempt count and failure count.
- Spiritual landmarks, dungeon memory tablets, ancient archives and solved runic secrets add clues. They do not directly grant cultivation skill or a Dao path.
- Cultivation training, circulation, Dao-path selection and breakthroughs are blocked until a legitimate method is recorded.
- Elemental magic, combat, crafting, trade, professions, guilds and ordinary RPG skills remain usable without cultivation.
- Sect recruitment begins with an Insight trial rather than requiring a cultivated spiritual root. Cultivation is not a prerequisite for joining or influencing a sect.
- Discovery records are included in local character saves and the authoritative character snapshot. Remote production clients cannot self-authorise a method; their discovery trial requires an authoritative server-side interaction/persistence workflow before it can be enabled online.

## Rarity and fairness

Rarity should emerge from scarce knowledge, hidden evidence, NPC relationships, exploration, compatibility, preparation and meaningful trials—not from a universal random awakening roll. A player can improve their prospects through deliberate play, but there is no promise that every character will qualify.

## Mortal endgame

The mortal game must remain a complete progression path. Equipment, material quality, weapon mastery, formations, logistics, wealth, political leverage, military command, crafting specialisation, guild reputation and alliances must continue to matter against threats far beyond ordinary adventuring. Cultivation should add a distinct progression scale, not invalidate everything built before it.

## Future work still required

- Persist and validate discovery evidence and first-method trials for remote characters through server-owned backend endpoints and authoritative NPC interaction handling.
- Replace the current first-trial evidence check with bespoke, authored trials per master, inheritance and method.
- Add method-specific requirements, spiritual constitution/compatibility variants, consequences for failure, and time/resource costs.
- Audit every existing cultivation-themed reward and technique so no quest, shrine, NPC, passive tick or client RPC can bypass method acquisition.
- Expand mortal endgame systems and ensure equipment, formations, logistics, politics and economy remain relevant at transcendent scales.
