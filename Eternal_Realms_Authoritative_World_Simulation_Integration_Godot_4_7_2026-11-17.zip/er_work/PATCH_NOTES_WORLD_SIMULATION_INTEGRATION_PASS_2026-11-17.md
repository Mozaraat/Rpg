# World simulation integration pass — 2026-11-17

## Changes

- Hydrology routing now records a downstream cell for each simulated cell, carries runoff across the edge of the active simulation window, and persists the edge inflow so water is not discarded at the player-area boundary.
- Upstream contributing area is accumulated while routing through the active watershed window; `estimate_upstream_area` can trace persisted downstream links in known cells.
- River visuals are rendered as oriented, cell-length water segments rather than tiny isolated puddle-like strips. Floodwater remains a shallow regional surface approximation.
- Erosion height deltas are restored after the terrain chunk manager exists, avoiding autoload startup-order loss. Dirty loaded chunks are rebuilt through the existing staged chunk builder, refreshing both terrain mesh and collision.
- Seasonal migration targets are selected for deer, rabbits and boars using regional temperature and moisture suitability. Critters steer toward those destinations during normal walking behavior and still prioritize threats.
- In multiplayer, the server is the only hydrology simulation authority. It periodically replicates nearby water-cell state to clients. Local JSON persistence remains a single-server/local-save fallback; this is not a replacement for durable central backend persistence.

## Deliberate limits

- Watershed routing is persistent across visited/active cells but is not yet a precomputed, planet-wide drainage graph. It only knows terrain cells that have been simulated or retained.
- Flood surfaces are cell-based meshes, not a Navier–Stokes or shallow-water solver. Flow velocity, momentum, hydraulic jumps and realistic shoreline propagation remain future work.
- Seasonal migration currently assigns destinations to active visible critters. It is not yet a population-level migration simulation for every unloaded region, and destination suitability uses sampled climate/moisture rather than food-web abundance.
- Terrain chunk rebuilds are batched on the hydrology save interval and only affect currently loaded chunks. Unloaded chunks use the shared heightfield when next generated.
- The multiplayer replication is server-authoritative for nearby water cells, but no PostgreSQL/world-service persistence adapter has been introduced.

## Validation boundary

Source-level inspection and archive integrity checks only. Godot 4.7 is not installed in this environment, so the project has not been parsed, imported, launched or play-tested by the engine. Multiplayer behavior and performance must be verified in an actual Godot 4.7 session with at least two peers.
