# Eternal Realms — Adventurer's Chronicle UI Consistency Pass

## Shared menu frame
- Rebuilt the shared menu shell with a responsive centred window, two-row tab navigation, consistent gold selection styling, restrained dark panels and compact headings.
- The menu window now adapts to the viewport rather than using a fixed 1000 × 620 minimum, and refreshes the visible page after a resolution change.
- Keyboard hints remain visible for the existing Inventory, Skills, Quests, Titles, Guild and Field Journal shortcuts. Character and Cultivation are available as dedicated tabs without taking over existing gameplay keys.

## Inventory
- Reworked backpack and equipment into matching contained panels.
- Inventory columns adapt to the screen width; narrow layouts stack the backpack and equipment panels vertically.
- Item names, equipment descriptions and tooltips wrap inside their panels. Selection, equip, use, unequip, discard and double-click quick actions are preserved.

## Character
- Added a dedicated Character page for current cultivation identity, spiritual root, active path, title, gold and discovered regions.
- Moved combat ratings and derived attributes out of the Skills page into the Character sheet.
- Added equipped gear, character activity totals and mastered traits.

## Skills
- Simplified skill rows to name, rank, value and rank progress; detailed descriptions remain available as tooltips.
- Added consistent category cards and made profession, trait and discovered-technique panels responsive.
- Removed duplicated combat/attribute information now shown on the Character page.

## Cultivation
- Added a dedicated cultivation page showing realm, spiritual root, active Dao path, cultivation mastery, open meridians and understood forms.
- Added next-breakthrough requirement indicators for cultivation mastery and meridian count; the existing O-key breakthrough action remains unchanged.
- Added Dao-path discovery progress and selection controls. A path is selectable only when the existing SkillSystem discovery threshold is met.
- Added meridian-network and learned-cultivation-technique summaries.

## Quests and text containment
- Added active/completed quest summary tiles and consistent quest cards.
- Quest title, issuer/turn-in status, summary, objectives and rewards now wrap within their available card widths.
- Shared layout helpers apply consistent section cards, spacing and wrapped descriptions across the new pages.

## Gameplay preservation
- No inventory, equipment, quest, skill training, attribute, cultivation, breakthrough, persistence, combat or multiplayer rules were intentionally changed.
- Character/Cultivation pages read and display the existing progression data. Path selection calls the existing `set_active_cultivation_path` method.

## Validation boundary
- Static project checks completed: GDScript file inventory, global class uniqueness, top-level function uniqueness within scripts, delimiter balance, literal `res://` resource references and ZIP integrity.
- The modified menu has no duplicate top-level functions or delimiter findings.
- Godot 4.6 is not installed in this environment. Engine parse/import, responsive screenshots, menu input tests and live gameplay checks must still be run in Godot 4.6 before release.
