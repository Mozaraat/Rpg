# PATCH NOTES – Farming, Husbandry, Fishing & Player Economy

## Activity systems
- Added crop seeds, hay, harvested crops, eggs, milk, wool, fur, flour, bread, planks and cheese to the item database with dedicated SVG inventory icons.
- Added persistent garden beds with planting, water management, growth stages, berry pruning, harvest and seed recovery.
- Added livestock records and visible procedural chicken, cow and sheep actors with collision, idle motion, feed/care, breeding and timed product generation.
- Reworked fishing into a cast / bait / bite / hook / line-tension / reel activity with a live HUD meter. Bait is selected and consumed during the wait phase.

## Construction and businesses
- Expanded construction to small houses, workshops, market stalls, coops, barns, sheep pens, dairies, bakeries, farm plots and a settlement hall that claims a build radius and levels up as nearby structures are added.
- Added walk-in house shells with open doorways, procedural roof forms, doors, windows, canopies, collision volumes and BuildingKit materials for in-game structures.
- Added player businesses, a claimable settlement hall with a 55-metre growth radius and level progression, and production chains: wheat → flour → bread, logs → planks, milk → cheese, and a market that buys player-supplied goods.
- Save/load refresh hooks restore farm plots, livestock and businesses after PlayerData is loaded. Save version advanced to 8.

## Controls
- Farming: N create bed, F1/F2/F3 select seed, H plant, Z water, Y prune, U harvest.
- Husbandry: O feed nearest animal (hay), I groom/care, K breed compatible nearby animals (5 gold; key press is consumed so mount breeding does not also trigger).
- Fishing: B cast; 1 berries or 2 seaweed as bait; SPACE set hook; alternate A/D to reel; S ease line tension.
- Building: V toggle; 1–9 select pieces, 0 barn, - farm plot, = sheep pen, ] dairy, \ bakery; R rotate; left-click place.
- Businesses: F6 inspect, F7 invest 10 gold. Settlement: F8 inspect growth and structure count. Production ticks while the game runs. Keep inputs in inventory for your owned production buildings.

## Visual honesty
The earlier assistant image panels were illustrative reference images, not screenshots or shipped game assets. This build improves the actual in-game procedural meshes/materials and UI, but does not claim to reproduce those photorealistic reference renders. Authored high-resolution art, skinned animal rigs, texture atlases and animation clips remain separate art-production work.

## Verification
Static source/resource checks and ZIP integrity checks were performed. Godot 4.6 was not available in the build environment, so no engine parse or runtime playtest is claimed.


## Static audit snapshot

```json
{
  "gdscript_files": 97,
  "scene_files": 12,
  "shader_files": 6,
  "item_definitions": 136,
  "new_item_icons": 15,
  "new_item_icon_missing": [],
  "literal_resource_references": 103,
  "missing_literal_resource_paths": [],
  "direct_inventory_item_ids_checked": 21,
  "missing_inventory_item_ids": [],
  "autoloads_checked": 17,
  "missing_autoload_scripts": [],
  "duplicate_function_definitions": [],
  "duplicate_class_names": {},
  "delimiter_findings": []
}
```
