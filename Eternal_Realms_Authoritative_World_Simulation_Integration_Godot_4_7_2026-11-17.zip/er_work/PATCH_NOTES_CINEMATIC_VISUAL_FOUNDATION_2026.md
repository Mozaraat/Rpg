# Cinematic Visual Foundation — Godot 4.7

This pass establishes a consistent visual baseline across the existing game rather than applying disconnected effects to individual menus.

## Included
- Added `systems/visual_quality_director.gd`, attached to the main world scene.
- Centralized world atmosphere: procedural sky, ambient/reflected lighting, filmic tonemapping, restrained glow, ambient occlusion, indirect lighting and distance fog.
- Four scalable render profiles: Cinematic, High, Balanced and Performance. The director exposes `apply_quality_preset()` for a future in-game graphics menu.
- Refined the shared `UIKit` palette and panel/button styling so code-built interfaces share the same dark, layered, antique-gold visual language.
- Added semantic accent colors for cultivation, rare items and special states.

## Important scope
This is a foundational art-direction and rendering pass, not a claim that the project now has AAA production assets. AAA visual quality also requires authored environment meshes, high-resolution PBR materials, bespoke character/creature models and animation, cinematic lighting per location, sound design, and performance profiling on target hardware. Those should be delivered in focused environment and character art passes while preserving gameplay systems.

## Godot 4.7 validation
The project must be opened with Godot 4.7 Forward+ and run through the editor/import pipeline. The current environment did not include a Godot executable, so engine parsing, shader compilation and GPU-specific feature validation remain outstanding. Use Balanced if volumetric fog or SDFGI is too expensive on target hardware.
