# Eternal Realms — Multiplayer Survival Expedition Foundation

## Implemented in this build

- Added a `DungeonExpedition` autoload to track expedition ID, leader peer ID, party peer IDs (up to five), deepest floor, secured checkpoint, boss-floor progress, deaths, elapsed time, supplies and a short event log.
- Added a persistent local expedition leaderboard sorted by deepest floor, then survival duration.
- Expedition state is included in dungeon save data and restored with the dungeon session.
- Added expedition records on entry, floor descent, boss kills, death and exit.
- Added supply pressure: the expedition spends one supply when pushing beyond its secured floor. Supply stashes and sanctuary rests replenish supplies.
- Added sanctuaries every five floors. Interacting with one secures the checkpoint, fully restores player health, attempts paid weapon/armour repairs and replenishes supplies.
- Added hidden pressure-plate traps that damage the player and have a cooldown. Trap count and damage increase with depth.
- Expanded random dungeon events: hunting horde, arcane surge, treasure echo, cave-in, elite patrol and supply stash.

## Multiplayer status — important

This is the expedition/gameplay data foundation, not a finished online multiplayer implementation. The project still needs an authoritative host/server, ENet or platform transport, replicated player spawning and movement, synchronized combat/loot/traps, party lobby UI, reconnect handling and anti-cheat validation. The current standalone build starts a one-member local expedition using peer ID 1. Do not advertise this build as online multiplayer-ready yet.

## Controls

- Use the existing interaction key near the blue sanctuary crystal on floors 5, 10, 15, etc.
- The sanctuary restores health, attempts repairs using the existing repair prices, secures expedition progress and restores supplies.
- Pressure plates are intentionally subtle; watch the floor and avoid suspicious metal plates.

## Validation

ZIP integrity and source-level checks are performed when packaging. Godot 4.6 runtime/parser testing is still required in the editor; this environment does not have a Godot executable.
