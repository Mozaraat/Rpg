# Patch Notes — MMORPG Foundation Architecture 2026

## Added
- Initial ENet multiplayer session service with host, join, disconnect and dedicated-server command-line modes.
- Remote cultivator proxy avatars with name labels and server-relayed transforms.
- Basic server-side transform distance/speed sanity validation.
- In-game network panel (F2) for local host/join testing.
- Versioned MMORPG world-state persistence boundary with server-only write checks while online.
- MMORPG architecture roadmap and migration map for existing game systems.

## Preserved
- Existing offline game flow and default single-player startup.
- Existing cultivation, elemental combat, stealth, dungeon, civilization, sect, siege, crafting, settlement and world simulation systems.
- Existing save system and project scenes; the new world-state adapter is additive.

## Prototype limitations
- This is the first networking slice, not production-ready multiplayer.
- Remote avatars are visual proxies; gameplay systems have not yet migrated to authoritative server simulation.
- JSON persistence is a development adapter, not a multi-process production database.
- Account authentication, region streaming/handoff, interest management, combat authority, inventory/economy transactions and anti-cheat remain future milestones.
