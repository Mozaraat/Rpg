# Eternal Realms — Expedition-Scale Geography Pass (Godot 4.7)

## World scale and settlement spacing
- Moved the Arcane Spire from the immediate Elyndor neighbourhood to the remote Frostveil landmass. The authored centres are now approximately 282 world units apart.
- New settlement sites are sampled across the expanded mainland rather than around the starter village.
- New settlements are rejected if they are within 260 world units of an existing settlement; candidate sites also keep the same minimum separation.
- Expanded the authored Elyndor mainland geographic footprint so streamed exploration can continue well beyond the starter region.

## Physical travel geography
- Strengthened the distant mountain belt and added a second ridgeline field to create more meaningful passes and barriers.
- Added two winding river systems to the shared terrain-height field. They stream with chunk geometry and collision rather than being painted decals.
- Added a narrow Frostveil causeway connecting the mainland road to the remote Spire. The causeway raises only its narrow corridor above the waterline, leaving surrounding water as a real barrier.
- Added a winding road and trail network to the remote Frostveil approach.
- Caravan movement between Elyndor and the Arcane Spire now follows the authored route waypoints rather than cutting directly across the landscape.
- Updated the Spire quest text and map marker to describe the longer journey.

## Biome and exploration additions
- Added Greenveil Rainforest and Thornwild Jungle regions to the shared terrain/atlas data.
- Added rainforest and jungle biome classifications, darker ground palettes, denser canopy coverage, region-specific tree silhouettes and region-appropriate resource nodes.
- Added habitat entries for rainforest and jungle wildlife.
- Added persistent regional ecology/economy entries and apex encounter profiles for both new regions.
- Expanded the one-time resource placement bounds so resources near the remote Spire can spawn instead of being rejected by the old starter-area-only bounds.

## Validation
- Changed-file delimiter and duplicate-function scan: passed.
- Literal `res://` reference scan: passed.
- Godot 4.7 executable was not available in this environment. Engine parsing, scene launch, terrain streaming, collision, visual appearance, caravan travel and multiplayer runtime behaviour have not been verified in-engine.
- Procedural placement and terrain results are deterministic from the world seed, but the final landscape should be inspected in Godot 4.7 at several seeds and travel routes before treating the geography as final.
