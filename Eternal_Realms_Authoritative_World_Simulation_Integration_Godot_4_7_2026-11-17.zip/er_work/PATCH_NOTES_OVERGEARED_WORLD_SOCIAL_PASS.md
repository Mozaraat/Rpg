# Overgeared-inspired World, Quest and NPC Social Pass

This pass expands the existing living-world foundation rather than treating NPCs as static quest kiosks.

## Added
- A WorldSociety director rotates regional incidents and rumours (caravan delays, unusual herb growth, beast migration, Spire signals and strange fishing currents).
- NPCs can share regional rumours, with the wording shaped by their profession so farmers, guards, merchants, smiths and mages hear different sides of the same event.
- Named NPCs now have personal story/ambition conversations, including their own motivations and concerns.
- NPC conversations expose rumour and personal-story options alongside quest interactions, so players can talk to people even while a quest is active or ready to turn in.
- Repeatedly asking the same NPC about the same incident is acknowledged; NPC affinity changes the level of trust in their wording.
- The system uses the existing reputation/affinity layer and EventBus activity feed.

## Design direction
Future quest expansion should build from these incidents and relationships: player choices, faction standing, discovered places, NPC ambitions and settlement needs should change who offers work, what information is shared, and how the region responds. This pass establishes the shared incident and conversation layer; it does not yet implement fully branching, persistent NPC life simulations or player-choice quest outcomes.
