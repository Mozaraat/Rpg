# Eternal Realms — Build Mode Configuration Pass (Godot 4.7)

## Added
- F3 opens a dedicated Build Mode Settings panel; F3 or the close button dismisses it.
- Settings persist in `PlayerData.stats["build_settings"]` and are restored on the next session.
- Grid snapping can be enabled/disabled, with 0.25 m, 0.5 m, 1 m and 2 m spacing.
- Placement distance is adjustable from 3 m to 12 m.
- Rotation increments are configurable at 15°, 30°, 45° or 90°; R rotates by the selected increment.
- Placement preview can be hidden without disabling placement.
- Free construction is available as an offline development convenience. It is disabled in production online sessions; production players still pay material costs.
- The settings panel locks gameplay input while open and prevents its mouse clicks from triggering world placement.

## Existing controls retained
- V toggles Build Mode.
- 1–9 select the first nine pieces; 0 selects the barn.
- `-`, `=`, `]`, `\\` and Backspace select the remaining construction pieces.
- R rotates the selected preview.
- Left-click places a structure when a valid ground hit is available.

## Validation boundary
- Source-level checks and project resource-reference checks were run after the patch.
- A Godot 4.7 executable was not available in this environment, so engine parsing, editor import, scene launch and multiplayer runtime tests still need to be completed in Godot 4.7.
- Build placement remains a client-side construction workflow in this patch. Do not treat the settings panel or local player save as authoritative multiplayer construction validation. Server-side ownership, permission, collision, resource and persistence validation remains a separate required backend milestone.
