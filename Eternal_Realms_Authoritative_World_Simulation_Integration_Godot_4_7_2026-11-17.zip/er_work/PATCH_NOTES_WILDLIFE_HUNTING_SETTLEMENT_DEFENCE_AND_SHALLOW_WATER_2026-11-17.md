# Eternal Realms — Wildlife Conflict, Predator Behaviour and Shallow-Water Stability

## This development pass

### Shallow-water solver
- Reworked the existing depth-averaged finite-volume solver to consume the full elapsed simulation interval using CFL-limited substeps rather than advancing only one stability-limited slice.
- Conserved state remains water depth and depth-integrated horizontal momentum `(h, h*u, h*v)`.
- Shared internal face fluxes still apply equal-and-opposite updates, with terrain-slope gravity and semi-implicit bed friction.
- Wet/dry shoreline cells are updated from the solved water depth. The model remains a coarse 64 m grid with no-flow boundaries at the active simulation window; it is not a complete catchment-scale or high-resolution flood solver.

### Actual predator hunting
- Added species-specific prey lists for the visible predator actors.
- Wolves, foxes, lynx, bears, snow leopards, jaguars, crocodiles, hyenas, sand cats and savanna lions now seek compatible nearby prey.
- Grazing animals detect nearby predators and flee.
- Successful predator attacks turn prey into carcasses, which feed into the existing carcass and regional population accounting.
- Predation mutations are restricted to the authoritative multiplayer peer.

### Regional settlement and farm pressure
- Regional ecology now calculates predator biomass and predator pressure separately from general wildlife density.
- After worker results are applied on the main thread, predator pressure can create settlement incidents, farm crop damage and livestock threats/losses.
- Settlements automatically allocate a baseline share of their population to hunters and guards; larger settlements have greater defensive capacity.
- Added `organise_settlement_wildlife_defence(settlement_id, hunters, guards)` for future civic/settlement UI integration. Assignments cannot exceed settlement population.
- Player farm plot growth can be damaged by high regional predator pressure. Livestock may be threatened or lost outside protected enclosures.

## Existing geography retained
- Seeded terrain has a broad mountain belt, named mountain massifs, foothills, mountain passes, coastlines, river valleys and region-specific lowland shaping.
- Biome classification distinguishes lowlands, hills, mountain terrain and cold high snow peaks, with 17 biome categories.
- Exploration routes remain based on the existing terrain/path and chunk-streaming systems.

## Important limits
- Regional conflict currently uses coarse pressure and incident probabilities. It is not yet a full real-time siege/raid simulation with pathfinding packs, livestock enclosure geometry, or NPC combat squads.
- Visible predator hunts operate only among loaded critter actors; unloaded regions continue using the coarse regional food-web model.
- The shallow-water solver is conservative across internal faces of its active grid, but the active-window outer boundary is no-flow. Cross-window river transport still uses the separate drainage/discharge routing layer.
- No Godot executable was available for engine parser/import/runtime verification in this environment. Source-level checks and ZIP integrity checks are not substitutes for running Godot 4.7.
