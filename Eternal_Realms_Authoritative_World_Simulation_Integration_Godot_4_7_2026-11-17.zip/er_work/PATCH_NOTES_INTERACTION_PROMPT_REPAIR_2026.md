# Interaction Prompt Repair — Godot 4.7

## Fixed
- Interaction HUD now safely reads and trims target prompt text.
- Empty or whitespace-only prompts fall back to a readable action instead of rendering a blank interaction option.
- Crafting stations now provide sensible default prompts for forge, alchemy and campfire even if a scene overrides the exported prompt with an empty string.
- NPCs with an empty display name fall back to `Talk to Villager`.
- Unknown interactables fall back to `Interact with <readable node name>` and finally `Interact`.

## Scope
This is a defensive UI repair. It does not alter interaction range, gathering timing, target selection, multiplayer validation, server authority, or the underlying interaction actions.

## Validation
- Source-level checks performed on the changed scripts.
- Godot 4.7 editor parsing and runtime interaction testing still need to be performed in the engine; no Godot executable is available in this build environment.
