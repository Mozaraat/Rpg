# Eternal Realms — Skeletal Rigs, Freeform Climbing, Streamed Terrain & Full Static Audit

## Implemented

- Replaced the creature limb-pivot animation path with a `Skeleton3D` hierarchy. Each articulated procedural limb is attached to a named bone through `BoneAttachment3D`; idle, locomotion and attack-windup poses now drive skeleton bone rotations. Existing death-collapse tween remains in place.
- Replaced step-by-step tree climbing teleports with continuous trunk traversal. WASD moves vertically and around the trunk, the player can jump off at the current height, and reaching the top exits onto the canopy. Climb index, angle and height are included in environment save state.
- Repositioned cave chambers beneath their actual surface entrances in the same world X/Z coordinates. Chamber floors, tunnels, exits and pools now occupy the same world coordinate space instead of being teleported to an unrelated distant coordinate island.
- Carved a river channel into `TerrainNoise.get_height`, so terrain chunks and collision share the same riverbed height field. Extended the waterfall river surface and swimming detection along the stream.
- Corrected cave movement so underground Y coordinates are not interpreted as deep water.
- Corrected appraisal raycast layers to include world resources, NPCs and creatures; filtered terrain-only hits and added critter inspection.
- Resolved the F-key conflict: F remains mount interaction; B now triggers fishing.
- Normalized mixed indentation in boot, skill and civilization scripts.

## Static audit results

- 92 GDScript files scanned.
- 17,600+ GDScript lines scanned for balanced delimiters and string termination.
- No unclosed strings or bracket/parenthesis mismatches found.
- No duplicate `class_name` declarations found.
- No duplicate function declarations found within a script.
- All literal `res://` references in scripts, scenes and project configuration resolve to files in the project (dynamic format-string paths excluded).
- Main scene, boot scene and autoload script paths checked.
- Mixed tab/space indentation removed from scripts that had mixed indentation.
- ZIP integrity verified after packaging.

## Important verification limitation

Godot 4.6 is not installed in this environment. Therefore this is a static source/resource audit, not a Godot parser/import run or gameplay playtest. The new `Skeleton3D` uses procedural mesh parts attached to real bones; it is not yet a set of imported, fully skinned character assets with authored AnimationPlayer clips. The cave interiors are anchored below their surface entrances in the same streamed-world coordinate system, while their geometry remains persistent under the environmental world node. The riverbed is part of the streamed terrain height field; the waterfall and water surface are persistent world features.

## Controls

- P — Appraise
- T — Open/close realm chat
- F — Mount / companion interaction
- B — Fish
- E — Interact / enter cave / start or exit climbing
- WASD — Move freely around and up/down giant tree trunks while climbing
- Space — Jump off a tree while climbing
