# Eternal Realms - Day/Night Edition (v3)

Solo-built open-world RPG foundation (Godot 4.7, Forward+).


## World Geography & First-Region Milestone
- The shared terrain field now defines the Elyndor Mainland, Frostveil Continent and Cinderwake Continent, with named territories and regional biome identities.
- The **M** atlas shows continent labels, regional boundaries, terrain/biome colour, roads, rivers, settlements, discovered landmarks and the player on the live world coordinate system.
- Entering a named region records its discovery and trains Exploration and Knowledge.
- Mirror Pond is carved into the terrain and joins the waterfall river below the shared water plane. The plunge pool and river use the same water material as the overworld surface.
- Elyndor is the first-region quality target. Distant landmasses are geographically established and procedurally explorable, but still need their own settlement, quest and landmark polish passes.

## Gameplay systems
**Progression (Entropia-style, no player levels)**
- Skills are decimal values that grow through relevant actions, with diminishing returns. Core disciplines cover weapon mastery, combat, gathering, farming, crafting, trade, exploration, swimming, fishing, cultivation, Wisdom, Compassion, Knowledge, Observation, Ancient Lore, Tracking, Archaeology and Marine Lore.
- Ranks: Untrained > Novice > Apprentice > Adept > Expert > Master > Grandmaster.
- Professions are weighted skill groups (including Swordsman, Survivor, Miner, Woodsman, Farmer, Herbalist, Blacksmith, Alchemist, Merchant, Explorer, Naturalist, Archaeologist and Spiritual Adept): your "class" is whatever you actually do.
- Skills have real effects: damage, crit, dodge, max health (Vitality), move speed (Agility), gather success, craft success + grade odds, shop prices.
- Titles (Slime Slayer, Apprentice Smith, Overgeared...) are earned by deeds and give small bonuses.

**Items & the "Grid"**: gear has grades Normal > Fine > Rare > Unique > Epic > Legendary that multiply its stats. Crafted gear rolls a grade; higher Smithing shifts the odds. Weapons and armor wear down and need repair at the forge.

**The loop**: gather (ore, trees, glowing moonpetal) -> craft (forge / alchemy table) -> fight (loot, gold, quests) -> trade (Mira) -> repeat. Everything trains something.

**Quests**: 16 quest definitions across combat, gathering, crafting, trading and exploration. Objectives: kill / collect / craft / talk / visit. NPCs show ! (available) and ? (turn in) markers. Tracker on the HUD, full log in the menu.

**Alive world**: NPCs follow daily routines (work, market, plaza, go home and sleep at night), chat in speech bubbles, chickens wander the village, rabbits flee from you, birds circle by day, butterflies drift over meadows, fireflies at night, herbs glow after dark.

## Controls
WASD move - Shift run - Space jump - Mouse look - Click attack - E interact (talk / gather / craft / activities) - F fish near water - 1–4 answer active memory seals - Q drink potion
I inventory - K skills - J quests - T titles - F2 network panel - F5 save - F9 load - F10 graphics quality - Wheel zoom - Esc free mouse / close - H hide hints - R restart (after death)

## Project layout
- `autoload/`  EventBus, GameManager, PlayerData (inventory, equipment, gold, quests, titles)
- `data/`      ItemDB, RecipeDB, QuestDB (zones + titles too): add content here
- `core/`      Constants, HealthComponent
- `entities/`  Player, NPC, Slime, Critter, ResourceNode, CraftingStation, CharacterModel
- `systems/`   Terrain/Chunks, DayNightCycle, SettlementBuilder, BuildingKit, VegetationKit, SkillSystem, ResourceSpawner, EnemySpawner, AmbientLife, SaveSystem
- `shaders/`   terrain, water, foliage, sky, building
- `ui/`        HUD, GameMenu, DialogueBox, StationPanel, UIKit

## Adding content
- New item: add to `ItemDB.ITEMS`. New recipe: `RecipeDB.RECIPES`. New quest: `QuestDB.QUESTS` (objective types: kill, collect, craft, talk, visit).
- New skill: `SkillSystem.SKILLS` (+ train it where the action happens with `skills.train("id", amount)`), optionally add it to a profession.
- New NPC: add to `SettlementBuilder` with a routine; give it dialogue/quests through `QuestDB` by name.

## Day/Night update (v3.1 polish pass)
- Startup chunk generation now creates the spawn-area terrain and collision first, then streams vegetation and grass through the existing per-frame build budget. This avoids doing all foliage work in one startup stall.
- Rebalanced the world atmosphere: distant fog is less opaque, night ambient light is darker, and high graphics mode uses 4x MSAA with a longer shadow range.
- Reduced excessive screen-space ambient occlusion and bloom so the terrain, foliage and emissive night plants retain more readable detail.
- Replaced silent placeholder audio streams with generated, seamless low-volume ambience loops for village, wilderness, night, boss, dungeon and rain states. No external audio assets are required.

## Graphics and performance
- Press **F10** in-game to cycle Low / Medium / High / Cinematic. Low disables expensive shadows and post-processing; Medium is the default; High and Cinematic progressively enable longer shadows, volumetric fog and higher MSAA. Prefer Low or Medium on modest hardware.
- If frame rate drops while exploring, use Medium or Low. The world is procedurally generated and vegetation is built incrementally as chunks stream in.

## Validation note
This archive was checked for missing `res://` references and duplicate `class_name` declarations. A Godot executable was not available in the build environment, so a full editor import and runtime playtest could not be performed here. Open `project.godot` in Godot 4.7.2 and run the main scene to complete engine-side validation.

## 100-Floor Depths of Elyndor Dungeon Update

- Expanded the dungeon progression from 50 to 100 floors.
- Moved the isolated dungeon stack deep underground so its rooms no longer render as floating sky platforms.
- Rebuilt floor chambers with enclosed ceilings, heavy stone walls, structural ribs, pillars, wall courses, floor runes, rubble, stalactites, crystals, torch lighting, and a themed descent gate.
- Added ten environmental/civilization regions, changing every ten floors: Ancient Labyrinth / Gilded Concord, Living Caverns / Verdant Choir, Crystal Depths / Prism Enclave, Forgotten Kingdom / Sepulchral Court, Ember Depths / Cinder Dominion, Frozen Hollow / Glacial Monastery, Drowned City / Thalassian Crown, Worldroot / Worldroot Communion, Abyss / Starless Court, and Ancient Realm / Astral Archive.
- Increased regular enemy population and preserved a boss encounter and gate progression on every floor, with milestone rewards every ten floors and the final boss on Floor 100.
- Reworked the overworld entrance into a stone-framed, glowing portal.

The project is built for Godot 4.7.2. The source changes are included; run the project in Godot to verify rendering and gameplay in-engine.


## Build Mode configuration (Godot 4.7)
- Press **V** to toggle player construction, then **F3** to open Build Mode Settings (F2 remains reserved for the network panel).
- Configure grid snapping and spacing, placement distance, rotation increments, placement preview and offline free-construction mode.
- Settings persist with the player data. Free construction is disabled in production online sessions.
- Press **F3** again or use the close button to return to construction.

## Skill experience controls
- Skills develop from successful actions and relevant challenges rather than menu activation.
- Weapon techniques are discovered after reaching the required mastery and landing the connected attack chain; they then flow automatically in combat.
- Press **Left Ctrl** to dodge. Evasion mastery gradually improves dodge distance, timing window and recovery. Evasion experience is awarded for actually avoiding an incoming attack during the dodge window.

## Wisdom, Knowledge & Dungeon Atmosphere Update

- Wisdom, Knowledge, Observation and Ancient Lore are now learn-by-doing skills in the Wisdom & Knowledge category.
- Dungeon exploration, hidden caches, shrines, runic secrets and boss encounters build intellectual skills as well as combat/exploration skills.
- Wisdom and lore influence cache discovery quality; knowledge and ancient lore improve dungeon drop luck and item grades.
- The Depths of Elyndor use a separate underground environment, floor-specific lighting, fog and atmospheric weather. The overworld sun and moon are suppressed while inside and restored on exit.
- Each floor has a dedicated descent/return loading screen. Press **N** in the dungeon for the current floor map; press **N** or **Escape** to close it. **M** remains the overworld map.
- Floor-band cache and boss loot pools now progress with dungeon depth, including region-specific materials and appropriately tiered equipment.


## Living Civilizations, Marine Wildlife & Exploration Activities

### Ten distinct dungeon civilizations (100 floors)
Each ten-floor region now has its own civilization identity, written history, architectural language, signature inhabitants, environmental hazard and milestone relic trial:

| Floors | Civilization | Architectural identity | Inhabitants / danger | Memory relic |
|---|---|---|---|---|
| 1–10 | Gilded Concord | Bronze oath pylons and civic plaques | Bronze Sentinels; falling masonry | Bronze Charter |
| 11–20 | Verdant Choir | Living-root arches and fungal lanterns | Spore Moths; spore blooms | Choir Seed |
| 21–30 | Prism Enclave | Crystal pylons and rotating halos | Prism Stalkers; prism backlash | Prism Heart |
| 31–40 | Sepulchral Court | Sarcophagi and royal seals | Grave Hounds; cursed epitaphs | Sepulchral Signet |
| 41–50 | Cinder Dominion | Foundry vents and slag channels | Ember Wyrms; magma vents | Cinder Insignia |
| 51–60 | Glacial Monastery | Frost mirrors and obelisks | Frost Lynx; rime slicks | Glacier Scripture |
| 61–70 | Thalassian Crown | Tide columns and coral crowns | Reef Crabs; undertow channels | Thalassian Signet |
| 71–80 | Worldroot Communion | Living root clusters and memory plates | Rootbound Guardians; thorn snares | Worldroot Sapling |
| 81–90 | Starless Court | Black-glass menhirs and orbiting shards | Void Jelly; void pulses | Starless Crown |
| 91–100 | Astral Archive | Orreries and star-map pillars | Astral Scribes; astral convergence | Celestial Codex |

Every floor receives a visible, damaging regional hazard. The tenth floor of each region contains a civilization memory seal; study its history and reproduce the four-glyph pattern with **1–4** to recover the region's relic and gain Archaeology, Ancient Lore, Knowledge, Wisdom, Observation and Dungeon Delving experience. Each culture uses a different pattern discipline; four rune nodes visibly flash the solution once, then the player must reproduce it from memory.

### More creatures and animation
- Added ten regional dungeon species with dedicated silhouettes and creature-specific details: Bronze Sentinel, Spore Moth, Prism Stalker, Grave Hound, Ember Wyrm, Frost Lynx, Reef Crab, Rootbound Guardian, Void Jelly and Astral Scribe.
- Existing enemy breathing, attack anticipation and limb motion are retained; new articulated wings, claws, tentacles and armour details participate in the motion system.
- Fish now have animated tail swishes, fin strokes and body movement. Added clearer silhouettes for swordfish, pufferfish, parrotfish, sunfish and abyss anglers.
- Added observable marine wildlife: spinner dolphins, green sea turtles, blue reef rays, reef sharks, moon jellyfish and whale sharks. Observe them with **E** to train Marine Lore, Observation, Knowledge and Swimming and occasionally earn Field Notes.

### New things to do in the overworld
- **Animal tracking:** Examine print trails to earn Field Notes, gold and Tracking / Observation experience.
- **Tidepool gathering:** Gather seaweed, coral fragments, scale shards and occasional pearls along coastal activity sites.
- **Campfire cooking:** Bring a Wood Log and a fish to a campfire and prepare a cooked meal.
- **Archaeology:** Decode buried expedition inscriptions by repeating a four-glyph sequence for Forgotten Essence, Field Notes, gold and intellectual skill experience.
- **Leyline meditation:** Attune at natural spiritual convergences to replenish spiritual energy and train Cultivation, Spiritual Sense, Arcane Attunement and Wisdom.
- **Fishing and marine observation:** Continue fishing with **F** near water; follow and study larger marine life for additional exploration progression.

New skills include Tracking, Archaeology, Marine Lore, Farming and Compassion. The profession system recognizes Farmer, Naturalist, Archaeologist and Spiritual Adept playstyles. New Field Notes and civilization relics are registered in ItemDB. **E** is the interaction key; the HUD now reminds you of fishing and the memory-trial keys.

### Validation
Static checks confirmed that all referenced `res://` paths exist, all new hard-coded activity items exist in ItemDB, all new skill-training IDs exist in SkillSystem, and the touched scripts do not contain duplicate function declarations. A Godot executable was not available in the build environment, so the project still needs an editor import and in-engine playtest in Godot 4.7.2.


## MMORPG foundation prototype

The project now includes an early ENet multiplayer test path. Open the world and use the **F2** network panel to host or join a local test session. For two instances on one machine, host on one and join `127.0.0.1` on the other using UDP port `24560`. A dedicated test server can be started with `-- --server`; a client can start with `-- --connect=127.0.0.1`.

This remains a development prototype, not a release-ready public MMO server. Server authority covers important combat, health/cultivation state, loot, party and selected interaction checks, but inventory, gold, equipment and most quest progression are not yet fully server-owned. Client snapshots and economy actions therefore still require a complete authoritative transaction migration before competitive public deployment. The offline single-player path remains the default. See `docs/MMORPG_FOUNDATION_ARCHITECTURE_2026.md` for the migration roadmap and security boundaries.


## Godot 4.7 full quality audit

The current repair pass checked 120 GDScript files, 13 scenes, 25 autoloads, 66 global classes, 136 item definitions and 47 skill definitions. Static checks covered resource and UID references, scene resource IDs/load-step counts, input actions, EventBus signals, progression/content links, typed Dictionary access, item icon coverage and SVG well-formedness. The six missing item SVGs and Farming / Compassion skill definitions were added.

The archive excludes generated `.godot/` caches while retaining source `.import` metadata. Static checks are not a substitute for opening the project in Godot 4.7.2: native parsing, editor import, shader compilation, scene launch, gameplay, multiplayer latency and persistence tests remain to be run in-engine. See `BUILD_AUDIT_FULL_QUALITY_GODOT_47_2026.txt` for the detailed audit boundary.
