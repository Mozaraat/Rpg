# Player Trade and Sect Economy Milestone — Godot 4.7

## Delivered

### Player-facing trade workflow
- Expanded the existing F2 world-network panel with nearby-peer trade requests, invitation/session ID display, invitation acceptance, inventory item selection, gold offers and explicit confirmation.
- Trade item selections use the authoritative server inventory instance UUIDs. Items without a server UUID are disabled in the UI rather than inventing an identifier.
- The server still checks participant identity, proximity, item ownership, equipped state, currency balance and the central backend's trade state.
- Both players' offer summaries are relayed to the participants. Any changed offer resets the other participant's confirmation.
- Backend commit is transactional and idempotent. It now rejects a commit if either destination inventory has no free slot, and moved items are assigned a real inventory slot so they remain visible after refresh.
- A repeated commit with the same idempotency key returns the prior committed result, including after the trade session has transitioned to `committed`.

### Player-founded sect registration and treasury
- Founding a player sect during a production multiplayer session now requests server-side registration in `player_organizations` and `organization_members`.
- The organization UUID is stable for the player's sect ID; the backend verifies the leader character belongs to the one shared world and prevents a character from registering multiple player-led sects.
- Added an in-game F2 panel section to view a member's treasury, configure tax in basis points (0–2500), and inspect regional commodity flow summaries.
- Treasury balances are calculated from immutable ledger entries, not a mutable client-supplied balance.
- Tax changes are restricted to the current territory owner and the organization leader or an authorized treasury rank.

### Territory taxes and regional economy
- Added migration `004_sect_treasury_regional_economy.sql` for organization treasury ledger, territory tax policy and regional commodity-flow ledger.
- Merchant purchases and sales now append regional commodity-flow events in the same database transaction as stock, item and currency changes.
- When a merchant is mapped to a territory with a registered organization owner and enabled tax policy, the transaction credits the calculated tax to that organization's treasury.
- Territory ownership changes clear the previous owner's tax policy. Omitting `organization_id` from a territory snapshot preserves its existing owner; an explicit null clears ownership.
- Added internal APIs for sect provisioning, treasury reads, tax policy, tax assessment and regional economy snapshots.

## Deployment changes

- Docker Compose now mounts migration `004` for new PostgreSQL volumes.
- Existing installations must apply `004` manually after `001`–`003`; follow `DEPLOYMENT_README_GODOT_4_7.md` and take a verified backup first.
- The one-world ID remains `eternal-realms-one-world`.

## Verification performed

- Python backend source compiled with `python -m py_compile`.
- Python AST parse passed.
- Docker Compose YAML parsed successfully.
- Confirmed migration `004` is mounted by the PostgreSQL service.
- Confirmed `project.godot` declares Godot `4.7`.

## Verification not performed

- No Godot executable was available in this environment, so Godot 4.7 editor import, GDScript parser checks, headless startup and multiplayer runtime tests were not run.
- No PostgreSQL or Docker executable was available, so migrations and transactional concurrency tests were not executed against a live database.

## Remaining integration work

- Existing NPC sect warfare and most territory ownership are still driven by local sect simulation records, not a server-authoritative organization/territory conquest service. Taxes accrue only after `territory_control.organization_id` is populated with a real organization UUID and merchants map to that territory.
- Merchant territory mapping currently uses `merchant_catalog.territory_id` when populated, otherwise a matching `region_id`/territory ID.
- The treasury screen is a compact management/readout section in the network panel, not a full dedicated guild hall interface.
- Treasury deposits/withdrawals, budgets, salaries, construction spending, regional production/consumption from all gathering and crafting systems, dynamic market price discovery and complete caravan supply-chain simulation remain future work.
- Trade sessions remain short-lived and server-memory-routed for live peer presence; their offers and status are persisted by the backend, but reconnect/resume UX and cancellation controls remain future work.
