# Eternal Realms — Shared-World Persistence Foundation (Godot 4.7)

This update extends the supplied Godot 4.7 project. Existing world, cultivation, combat, civilization, dungeon and multiplayer systems are retained.

## Implemented in this pass

1. **Runnable central FastAPI + PostgreSQL backend** under `backend/` with Docker Compose deployment.
2. **Secure account baseline:** Argon2id password hashes, signed short-lived access tokens, rotating hashed refresh tokens, logout/revocation and durable login throttling.
3. **Account-owned characters:** create/list/read/update; unique world-wide display names; optimistic revision checks.
4. **One-use join tickets:** client requests a 60-second ticket through HTTPS; authoritative Godot server consumes it through a service-authenticated backend call. Production connections reject legacy local IDs and unverified character names.
5. **Global single-world lease service:** atomic PostgreSQL row lock; any unexpired lease blocks a second process. Renewal/release must match exact lease owner and UUID.
6. **Transactional inventory primitives:** authenticated account ownership, inventory read/move, equipment updates, row locks and idempotency keys.
7. **Server-owned online loot and currency:** Godot server commits monster loot, equipment changes and currency rewards through internal idempotent backend endpoints before despawning drops or refreshing player inventory.
8. **Central character persistence:** Godot production server loads state through a consumed join ticket and writes whitelisted server-owned state using revision-checked database updates. Production character snapshots no longer fall back to local JSON.
9. **Godot HTTPS client autoload:** `CentralBackend` exposes account, character, inventory, join-ticket and server-only persistence/loot methods. Tokens are passed in memory and not persisted by this autoload.

## Start backend locally

See `backend/README.md`. In brief, create `backend/deploy/.env` from `.env.example`, replace all secrets, then run:

```sh
docker compose -f backend/deploy/docker-compose.yml --env-file backend/deploy/.env up --build -d
```

The compose port binds to localhost. Put the service behind TLS before remote access. Apply the SQL migration to existing databases with a migration role; do not delete a live database volume to re-run it.

## Godot environment

Dedicated server:

- `ER_PRODUCTION_SERVER=1`
- `ER_CONTROL_PLANE_URL=https://your-api-host`
- `ER_BACKEND_URL=https://your-api-host`
- `ER_CONTROL_PLANE_TOKEN=<server-only secret>`
- `ER_SERVER_INSTANCE_ID=<unique server process identifier>`

Client:

- `ER_BACKEND_URL=https://your-api-host`
- No service token.

The client flow is `CentralBackend.login/register_account` → `list_characters/create_character` → `prepare_character_connection` → ENet connection. The last step obtains a single-use join ticket; the server verifies it with the backend. A polished login and character-selection UI is not yet built, so this flow is currently exposed as code/API rather than a finished front-end screen.

## Still incomplete

- Full account UX: login/registration screens, refresh-token lifecycle UI, email verification, password reset, MFA and account recovery.
- All inventory UI operations, equipment changes, shops, player-to-player trading, crafting, gathering, quest completion/rewards and NPC interactions must be routed through transactional server endpoints. The current database primitives and shared monster loot/currency path are connected, not the entire gameplay economy.
- Persistent monster population/boss state, faction/sect simulation and territory/economic transactions still need to be migrated to the central database event model.
- Production database operations, TLS deployment, migration on a real DB, backups, recovery, two-client sessions and load tests have not been executed in this environment.
- No Godot 4.7 executable was available, so no engine parser, headless launch or multiplayer runtime test is claimed.
- The one-world model remains fixed: future regional compute must register under this same world and use shared authoritative state; it must never create separate populations.

## Verification performed here

- Python backend source passed `py_compile`.
- Static GDScript structure/resource checks were run on the updated project.
- ZIP integrity was checked after packaging.
- PostgreSQL migration and API integration were not run because Docker/PostgreSQL were unavailable; Godot runtime checks were not run because Godot 4.7 was unavailable.
