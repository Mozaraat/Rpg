# Eternal Realms central backend (first connected implementation)

This is a runnable FastAPI + PostgreSQL service for the single world `eternal-realms-one-world`.

## Included now

- Argon2id password hashing; short-lived HMAC-SHA256 access tokens; rotating opaque refresh tokens stored as SHA-256 hashes.
- Durable login throttling keyed by normalized email and source IP.
- Account-owned character creation/list/read/update with optimistic revision checks.
- 60-second, single-use character join tickets. The game client obtains a ticket over HTTPS after account login; the authoritative Godot server consumes it over the service-authenticated backend connection. The server does not trust the client-supplied character name.
- PostgreSQL-backed global world lease acquire/renew/release. Every active lease blocks a second process, including one configured with the same instance label.
- Authenticated inventory read, slot movement and equipment updates. Mutations use character ownership checks, row locks, database constraints and idempotency keys.
- Server-only idempotent loot grants and currency ledger changes. The Godot server commits online monster loot and gold rewards before it despawns the shared loot or updates the client inventory.
- Revision-checked server character state persistence. In production, local JSON world snapshots are not used as the character database.

## Start locally with Docker Compose

1. Copy `deploy/.env.example` to `deploy/.env` and replace all three secrets with long random values.
2. From this directory run:

   ```sh
   docker compose -f deploy/docker-compose.yml --env-file deploy/.env up --build -d
   ```

3. Check `http://127.0.0.1:8080/health`. The endpoint returns healthy only when PostgreSQL is reachable.
4. Put the service behind a TLS reverse proxy before allowing remote clients. The compose port binds to loopback only.

The schema is installed automatically on the first initialization of the PostgreSQL volume. The Compose stack mounts the shared schema and migrations `002`, `003_authoritative_economy_and_quests`, `003_underwater_world_persistence`, `004`, `005`, and `006` in filename order. For an existing database, apply only migrations that have not already been applied, in dependency order, using a migration role. Do not delete the production database volume to rerun migrations.

## Godot configuration

Dedicated authoritative server environment:

- `ER_PRODUCTION_SERVER=1`
- `ER_CONTROL_PLANE_URL=https://your-api-host`
- `ER_BACKEND_URL=https://your-api-host`
- `ER_CONTROL_PLANE_TOKEN=<server-only service secret>`
- `ER_SERVER_INSTANCE_ID=<unique process/deployment identifier>`

Client configuration:

- `ER_PRODUCTION_CLIENT=1` (enables fail-closed client behaviour and prevents clients from hosting a duplicate world)
- `ER_BACKEND_URL=https://your-api-host`
- Clients must never receive `ER_CONTROL_PLANE_TOKEN` or `ER_CONTROL_PLANE_URL`.

Client login flow exposed by `/root/CentralBackend`:

1. `login(email, password)` or `register_account(email, password)`.
2. `list_characters(access_token)`; create a character if needed.
3. `prepare_character_connection(access_token, character_id)` obtains a one-use join ticket and populates the network character identity.
4. Connect to the authoritative server. The client sends the ticket; the server consumes it over the service-authenticated HTTPS backend connection.

The project has the backend client and the production server join-ticket verification path. A polished login/character-selection screen and refresh-token UX are not yet integrated into the game UI; the current UI does not collect credentials. Do not bypass the ticket flow in production.

## Important limits / production hardening still required

- This is a first functional service, not a fully audited production identity provider. Email verification, password reset, MFA, abuse monitoring, CAPTCHA policy, security review and distributed edge rate limiting remain outstanding.
- The compose stack is a single PostgreSQL primary. Production needs managed HA PostgreSQL, encrypted backups, tested point-in-time recovery, secret management, metrics, tracing, alerting and a TLS reverse proxy/WAF.
- The Godot client currently exposes account and character methods but no finished login UI. Access/refresh tokens are intentionally not written to disk by the autoload.
- The authoritative-economy migration adds server-owned quest objective counters and atomic quest reward claims, merchant catalog/stock/sales ledgers, player trade offer confirmation, territory control snapshots and territory economy entries. The underwater migration adds indexes and dedicated claim/population/encounter tables. Migration 005 adds dynamic regional merchant pricing. Migration 006 adds retry-safe idempotency records for shared world-entity writes.
- Production NPC quest acceptance/turn-in is routed through service-authenticated APIs. Kill/talk/collect/craft events supported by authoritative server actions advance objective counters; the backend refuses turn-in until every configured objective is complete. Quest rewards, currency and item instances commit in one PostgreSQL transaction with unique idempotency keys.
- Merchant purchases and sales are server-routed and transactional; Mira, Gorrim and Lira stock is seeded by migration and restocked by the authoritative server. Clients receive refreshed inventory snapshots after committed transactions.
- Boss encounter rows and regional monster populations are restored from PostgreSQL at server startup; ecology counts and territory-control snapshots are persisted back to the same Elyndor world.
- Player trade offer/confirmation and atomic item/currency exchange APIs exist, but a player-facing trade interface and the full network invitation/offer flow are not yet connected. Territory-control state is persisted, but full treasury/tax/market integration with sect and guild ownership remains unfinished.
- Production quest objectives of type `visit`, some legacy local-only crafting/cooking paths, and a number of reward-bearing dungeon interactions still need authoritative event adapters. Do not treat this milestone as a fully production-ready MMO economy.
- Legacy local identity and JSON snapshots remain available only in development mode. Production rejects legacy IDs and requires a valid, account-owned, one-use join ticket.
- Movement/combat and other simulation authority still need further anti-cheat work and load testing. This backend does not prove a target population capacity.
- The service token is a shared deployment secret in this prototype; rotate it and use a dedicated secret manager and least-privilege service identities before production.

## API docs

FastAPI OpenAPI UI is available at `/docs` on the internal service. Do not expose administrative/internal endpoints publicly without network controls; the `/v1/internal/*` endpoints require the service bearer token.

## Expanded shared-world operations

The API now includes transactional crafting from the checked-in recipe catalog, server-only quest objective progression and atomic rewards, merchant provisioning/purchase/sale/restock, trade invitation/offer/confirmation/commit, territory-control snapshots and economy ledger entries, persistent ecology populations and boss encounter restoration. Shared world entities can now be listed by kind/region, and idempotency keys protect entity saves against duplicate retries. These operations always use the fixed `eternal-realms-one-world` identity. Apply all three SQL migrations in order. See `ops/BACKUP_RESTORE_MONITORING.md` for backup, recovery, monitoring and load-test requirements.

For existing databases, apply missing migrations `003_underwater_world_persistence.sql`, `005_regional_dynamic_merchant_pricing.sql`, and `006_world_entity_idempotency.sql` after their prerequisites. New Docker volumes apply all mounted migrations automatically. The server must be restarted after migrations are applied.

### Shared section/key world-state persistence

The Godot `MMORPGWorldState` adapter now uses the central `world_entities` table in production. After acquiring the single-world lease, a dedicated server must hydrate every `world_state` entity before it opens the ENet listener; a failed or unavailable database read blocks startup rather than silently booting from stale local JSON. Each section/key pair maps to a deterministic UUID entity, carries its own optimistic revision, and is written through the idempotent entity API. Pending snapshots are coalesced per entity and retried after transient failures. Development/offline sessions retain the atomic local JSON adapter. Apply migration `006_world_entity_idempotency.sql` to existing databases before deploying this build.
