# Eternal Realms one-world backend API

The runnable implementation is in `app/main.py`; PostgreSQL schema is in `postgres/001_shared_world_schema.sql`. `README.md` contains deployment and Godot configuration instructions.

## World invariant

`world_id` is fixed to `eternal-realms-one-world`. There is one active authoritative world lease. An unexpired lease blocks every new acquisition, even if a second process is accidentally configured with the same instance label. Regional workers in future must join this same world state stream; they cannot host independent populations.

## Implemented endpoints

### Public account and character endpoints

- `POST /v1/auth/register` — Argon2id password hashing, account creation and session issue.
- `POST /v1/auth/login` — verifies credentials and issues short-lived access + rotating refresh tokens; DB-backed throttling.
- `POST /v1/auth/refresh` — refresh token in `X-Refresh-Token`; revokes old session and rotates.
- `POST /v1/auth/logout` — revokes current access session.
- `POST /v1/characters` — creates an account-owned character in the one world.
- `GET /v1/characters` — lists the authenticated account's characters.
- `GET /v1/characters/{character_id}` — reads only a character owned by the account.
- `PUT /v1/characters/{character_id}` — optimistic revision-checked character state update.
- `POST /v1/characters/{character_id}/join-ticket` — creates a 60-second, one-use server join ticket for an owned character.
- `GET /v1/characters/{character_id}/inventory` — account-owned inventory and equipment read.
- `POST /v1/characters/{character_id}/inventory/move` — transactional slot movement with idempotency key.
- `POST /v1/characters/{character_id}/equipment` — transactional equipment slot change with ownership validation.

### Service-authenticated endpoints

- `POST /v1/world/lease/acquire`
- `POST /v1/world/lease/renew`
- `POST /v1/world/lease/release`
- `POST /v1/internal/characters/consume-join-ticket`
- `GET /v1/internal/characters/{character_id}`
- `PUT /v1/internal/characters/{character_id}`
- `GET /v1/internal/characters/{character_id}/inventory`
- `POST /v1/internal/inventory/grant`
- `POST /v1/internal/equipment/change`
- `POST /v1/internal/currency/change`

Internal endpoints require `Authorization: Bearer <ER_CONTROL_PLANE_TOKEN>` and should be network-restricted to the game server/control plane.

## Security and transaction behavior

- Passwords are never stored in plaintext; Argon2id hashes are stored.
- Access tokens are HMAC-SHA256 signed, short-lived and checked against an active database session.
- Refresh tokens are opaque random values; only SHA-256 hashes are stored, and refresh rotates/revokes.
- Join tickets are random, short-lived, one-use and stored as SHA-256 hashes. The client sends the ticket to the game server; the server consumes it using its service credential and receives the account-owned character record.
- Character writes use an expected revision. Stale writes fail with HTTP 409.
- Inventory/equipment mutations lock the character row, verify ownership, and write an idempotent transaction record.
- Loot grants and currency changes are service-only, idempotent and committed before the game server confirms the result to the player.
- World lease acquisition locks the singleton `world_registry` row and refuses any unexpired lease.

## Remaining gameplay migration

The complete inventory UI and every item-consuming operation must use these backend transactions. Player trade, market, crafting, gathering, quest rewards, NPC services, organization/territory transactions and persistent world events are not yet fully migrated. The current game connects monster loot/currency and character persistence to PostgreSQL, but it is not yet a fully server-authoritative economy.

## Deployment

Use `backend/deploy/docker-compose.yml`; bind backend to loopback and place it behind a TLS reverse proxy. Store secrets outside the project. Apply schema migration using a migration role. Production requires backups/PITR, monitoring, managed database HA, secret rotation, security review and runtime/load tests.
