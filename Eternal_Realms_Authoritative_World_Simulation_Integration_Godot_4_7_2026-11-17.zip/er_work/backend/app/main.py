from __future__ import annotations

import base64, hashlib, hmac, json, os, re, secrets, time, uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from fastapi import FastAPI, Header, HTTPException, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, EmailStr
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError

WORLD_ID = "eternal-realms-one-world"
QUEST_CATALOG_PATH = os.path.join(os.path.dirname(__file__), "quest_catalog.json")
CRAFT_CATALOG_PATH = os.path.join(os.path.dirname(__file__), "craft_catalog.json")
with open(QUEST_CATALOG_PATH, "r", encoding="utf-8") as _quest_file:
    QUEST_CATALOG: dict[str, dict[str, Any]] = json.load(_quest_file)
with open(CRAFT_CATALOG_PATH, "r", encoding="utf-8") as _craft_file:
    CRAFT_RECIPES: dict[str, dict[str, Any]] = json.load(_craft_file)
DATABASE_URL = os.environ.get("ER_DATABASE_URL", "")
JWT_SECRET = os.environ.get("ER_JWT_SECRET", "")
SERVICE_TOKEN = os.environ.get("ER_CONTROL_PLANE_TOKEN", "")
ACCESS_TTL = int(os.environ.get("ER_ACCESS_TOKEN_TTL", "900"))
REFRESH_TTL_DAYS = int(os.environ.get("ER_REFRESH_TOKEN_TTL_DAYS", "30"))
ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
app = FastAPI(title="Eternal Realms One-World Backend", version="0.1.0")

if not DATABASE_URL:
    # Health still starts, but every DB operation fails closed until configured.
    pass


def db():
    if not DATABASE_URL:
        raise HTTPException(503, "Database is not configured")
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def token_hash(token: str) -> bytes:
    return hashlib.sha256(token.encode()).digest()


def make_access(account_id: str, session_id: str) -> str:
    if len(JWT_SECRET) < 32:
        raise HTTPException(503, "ER_JWT_SECRET must contain at least 32 characters")
    now = int(time.time())
    head = b64u(json.dumps({"alg":"HS256","typ":"JWT"}, separators=(",", ":")).encode())
    body = b64u(json.dumps({"sub":account_id,"sid":session_id,"iat":now,"exp":now+ACCESS_TTL,"iss":"eternal-realms"}, separators=(",", ":")).encode())
    signing = f"{head}.{body}"
    sig = b64u(hmac.new(JWT_SECRET.encode(), signing.encode(), hashlib.sha256).digest())
    return f"{signing}.{sig}"


def decode_access(token: str) -> dict:
    try:
        head, body, sig = token.split(".")
        expected = b64u(hmac.new(JWT_SECRET.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            raise ValueError("signature")
        payload = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        if payload.get("iss") != "eternal-realms" or int(payload.get("exp", 0)) <= int(time.time()):
            raise ValueError("expiry")
        return payload
    except Exception:
        raise HTTPException(401, "Invalid or expired access token")


def current_account(authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Bearer access token required")
    claims = decode_access(authorization[7:])
    with db() as conn:
        row = conn.execute("""SELECT a.account_id, a.status, s.session_id
            FROM accounts a JOIN account_sessions s ON s.account_id=a.account_id
            WHERE a.account_id=%s AND s.session_id=%s AND s.revoked_at IS NULL AND s.expires_at>now()""",
            (uuid.UUID(claims["sub"]), uuid.UUID(claims["sid"]))).fetchone()
    if not row or row["status"] != "active":
        raise HTTPException(401, "Account session is not active")
    return row


def service_auth(authorization: str | None = Header(default=None)):
    if not SERVICE_TOKEN or not authorization or not authorization.startswith("Bearer ") or not hmac.compare_digest(authorization[7:], SERVICE_TOKEN):
        raise HTTPException(401, "Service authentication required")
    return True


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=128)

class CharacterCreate(BaseModel):
    display_name: str = Field(min_length=3, max_length=24, pattern=r"^[A-Za-z][A-Za-z0-9 _'-]*$")

class CharacterUpdate(BaseModel):
    revision: int = Field(ge=0)
    state: dict[str, Any]

class InventoryMove(BaseModel):
    item_instance_id: uuid.UUID
    destination_slot: int = Field(ge=0, le=27)
    idempotency_key: str = Field(min_length=16, max_length=128)

class EquipmentChange(BaseModel):
    slot_id: str = Field(min_length=2, max_length=32, pattern=r"^(weapon|armor)$")
    item_instance_id: uuid.UUID | None = None
    idempotency_key: str = Field(min_length=16, max_length=128)

class LeaseRequest(BaseModel):
    world_id: str = WORLD_ID
    server_instance_id: str = Field(min_length=3, max_length=128)
    lease_duration_seconds: int = Field(default=90, ge=45, le=180)
    lease_id: uuid.UUID | None = None

class InternalCharacterSave(BaseModel):
    character_id: uuid.UUID
    revision: int = Field(ge=0)
    state: dict[str, Any]

class InventoryConsume(BaseModel):
    item_instance_id: uuid.UUID
    quantity: int = Field(ge=1, le=9999)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalCraftRequest(BaseModel):
    character_id: uuid.UUID
    recipe_id: str = Field(min_length=2, max_length=64, pattern=r"^[a-z0-9_]+$")
    quantity: int = Field(ge=1, le=99)
    idempotency_key: str = Field(min_length=16, max_length=128)

class CraftRequest(BaseModel):
    recipe_id: str = Field(min_length=2, max_length=64, pattern=r"^[a-z0-9_]+$")
    quantity: int = Field(ge=1, le=99)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalQuestState(BaseModel):
    character_id: uuid.UUID
    quest_id: str = Field(min_length=2, max_length=96)
    quest_state: dict[str, Any]
    idempotency_key: str = Field(min_length=16, max_length=128)

class WorldEntityUpsert(BaseModel):
    entity_id: uuid.UUID
    entity_kind: str = Field(min_length=2, max_length=48)
    region_id: str = Field(min_length=1, max_length=96)
    revision: int = Field(ge=0)
    entity_state: dict[str, Any]
    idempotency_key: str | None = Field(default=None, min_length=16, max_length=128)

class InternalMerchantPurchase(BaseModel):
    character_id: uuid.UUID
    merchant_id: uuid.UUID
    item_definition_id: str = Field(min_length=2, max_length=96, pattern=r"^[a-z0-9_]+$")
    quantity: int = Field(ge=1, le=999)
    idempotency_key: str = Field(min_length=16, max_length=128)


class InternalQuestAccept(BaseModel):
    character_id: uuid.UUID
    quest_id: str = Field(min_length=2, max_length=96)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalQuestObjective(BaseModel):
    character_id: uuid.UUID
    quest_id: str = Field(min_length=1, max_length=96)
    objective_type: str = Field(min_length=2, max_length=24)
    target_id: str = Field(min_length=1, max_length=96)
    amount: int = Field(default=1, ge=1, le=999)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalQuestTurnIn(BaseModel):
    character_id: uuid.UUID
    quest_id: str = Field(min_length=2, max_length=96)
    npc_name: str = Field(min_length=2, max_length=96)
    idempotency_key: str = Field(min_length=16, max_length=128)

class MerchantStockLine(BaseModel):
    item_definition_id: str = Field(min_length=2, max_length=96, pattern=r"^[a-z0-9_]+$")
    quantity: int = Field(ge=0, le=1000000)
    unit_price: int = Field(ge=0, le=100000000)

class MerchantProvision(BaseModel):
    merchant_id: uuid.UUID
    merchant_name: str = Field(min_length=2, max_length=96)
    region_id: str = Field(default="elyndor_heartlands", min_length=1, max_length=96)
    stock: list[MerchantStockLine] = Field(min_length=1, max_length=200)

class MerchantRestockLine(BaseModel):
    item_definition_id: str = Field(min_length=2, max_length=96, pattern=r"^[a-z0-9_]+$")
    quantity_add: int = Field(ge=1, le=1000)
    stock_cap: int = Field(default=30, ge=1, le=1000000)

class MerchantRestockRequest(BaseModel):
    merchant_id: uuid.UUID
    items: list[MerchantRestockLine] = Field(min_length=1, max_length=200)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalMerchantSale(BaseModel):
    character_id: uuid.UUID
    merchant_id: uuid.UUID
    item_instance_id: uuid.UUID
    quantity: int = Field(ge=1, le=999)
    unit_price: int = Field(ge=0, le=100000000)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalTradeOpen(BaseModel):
    initiator_character_id: uuid.UUID
    target_character_id: uuid.UUID
    expires_in_seconds: int = Field(default=90, ge=15, le=300)

class InternalTradeAccept(BaseModel):
    trade_id: uuid.UUID
    target_character_id: uuid.UUID

class InternalTradeOffer(BaseModel):
    trade_id: uuid.UUID
    actor_character_id: uuid.UUID
    item_ids: list[uuid.UUID] = Field(default_factory=list, max_length=28)
    gold: int = Field(default=0, ge=0, le=1000000000)
    confirmed: bool = False

class InternalTradeCommit(BaseModel):
    trade_id: uuid.UUID
    idempotency_key: str = Field(min_length=16, max_length=128)

class TerritoryControlLine(BaseModel):
    territory_id: str = Field(min_length=1, max_length=96)
    revision: int = Field(ge=0)
    control_state: dict[str, Any]

class TerritoryControlBatch(BaseModel):
    territories: list[TerritoryControlLine] = Field(min_length=1, max_length=500)

class TerritoryEconomyEntry(BaseModel):
    territory_id: str = Field(min_length=1, max_length=96)
    organization_id: uuid.UUID | None = None
    amount: int = Field(ge=-1000000000, le=1000000000)
    reason: str = Field(min_length=2, max_length=96)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalOrganizationProvision(BaseModel):
    organization_id: uuid.UUID
    name: str = Field(min_length=3, max_length=64)
    organization_type: str = Field(default="sect", pattern=r"^(sect|guild|alliance)$")
    leader_character_id: uuid.UUID

class TerritoryTaxPolicyRequest(BaseModel):
    territory_id: str = Field(min_length=1, max_length=96)
    organization_id: uuid.UUID
    actor_character_id: uuid.UUID
    tax_basis_points: int = Field(ge=0, le=2500)
    enabled: bool = True

class TerritoryTaxAssessment(BaseModel):
    territory_id: str = Field(min_length=1, max_length=96)
    gross_amount: int = Field(gt=0, le=1000000000)
    reason: str = Field(min_length=2, max_length=96)
    source_ref: str = Field(default="", max_length=128)
    idempotency_key: str = Field(min_length=16, max_length=128)

class RegionalEconomyEvent(BaseModel):
    region_id: str = Field(min_length=1, max_length=96)
    territory_id: str | None = Field(default=None, max_length=96)
    commodity_id: str = Field(min_length=1, max_length=96, pattern=r"^[a-z0-9_]+$")
    quantity_delta: int = Field(ne=0, ge=-1000000000, le=1000000000)
    unit_value: int = Field(default=0, ge=0, le=1000000000)
    event_type: str = Field(min_length=2, max_length=48, pattern=r"^[a-z0-9_]+$")
    idempotency_key: str = Field(min_length=16, max_length=128)

class NpcInteractionEvent(BaseModel):
    character_id: uuid.UUID
    npc_id: uuid.UUID
    region_id: str = Field(min_length=1, max_length=96)
    interaction_type: str = Field(min_length=2, max_length=48, pattern=r"^[a-z0-9_]+$")
    payload: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str = Field(min_length=16, max_length=128)

class PopulationLine(BaseModel):
    region_id: str = Field(min_length=1, max_length=96)
    species_id: str = Field(min_length=1, max_length=96)
    revision: int = Field(ge=0)
    population_state: dict[str, Any]

class PopulationBatch(BaseModel):
    populations: list[PopulationLine] = Field(min_length=1, max_length=500)

class PopulationUpsert(BaseModel):
    region_id: str = Field(min_length=1, max_length=96)
    species_id: str = Field(min_length=1, max_length=96)
    revision: int = Field(ge=0)
    population_state: dict[str, Any]

class BossEncounterUpsert(BaseModel):
    boss_id: uuid.UUID
    region_id: str = Field(min_length=1, max_length=96)
    boss_definition_id: str = Field(min_length=1, max_length=96)
    revision: int = Field(ge=0)
    encounter_state: dict[str, Any]


def issue_session(conn, account_id: str) -> dict:
    sid = uuid.uuid4()
    refresh = secrets.token_urlsafe(48)
    expires = datetime.now(timezone.utc) + timedelta(days=REFRESH_TTL_DAYS)
    conn.execute("INSERT INTO account_sessions(session_id,account_id,token_hash,expires_at) VALUES (%s,%s,%s,%s)",
                  (sid, uuid.UUID(str(account_id)), token_hash(refresh), expires))
    return {"access_token": make_access(str(account_id), str(sid)), "refresh_token": refresh,
            "token_type":"Bearer", "expires_in":ACCESS_TTL, "session_id":str(sid)}


@app.get("/health")
def health():
    try:
        with db() as conn:
            conn.execute("SELECT 1")
        return {"status":"ok", "database":"connected", "world_id":WORLD_ID}
    except Exception:
        return JSONResponse(status_code=503, content={"status":"unavailable", "database":"unavailable", "world_id":WORLD_ID})


@app.post("/v1/auth/register")
def register(body: Credentials, request: Request):
    email = str(body.email).strip().lower()
    if len(body.password) < 12 or not re.search(r"[A-Za-z]", body.password) or not re.search(r"[0-9]", body.password):
        raise HTTPException(422, "Password must be at least 12 characters and include letters and numbers")
    aid = uuid.uuid4()
    try:
        with db() as conn:
            conn.execute("INSERT INTO accounts(account_id,email_normalized,password_hash) VALUES (%s,%s,%s)", (aid,email,ph.hash(body.password)))
            session = issue_session(conn, str(aid))
        return {"account_id":str(aid), **session}
    except psycopg.errors.UniqueViolation:
        raise HTTPException(409, "An account with this email already exists")


@app.post("/v1/auth/login")
def login(body: Credentials, request: Request):
    email = str(body.email).strip().lower()
    client_ip = request.client.host if request.client else "unknown"
    rate_key = hashlib.sha256(f"{email}|{client_ip}".encode()).hexdigest()
    valid = False
    result = None
    with db() as conn:
        rate = conn.execute("SELECT window_started_at,attempts,blocked_until FROM auth_rate_limits WHERE rate_key=%s FOR UPDATE", (rate_key,)).fetchone()
        if rate and rate["blocked_until"] and rate["blocked_until"] > datetime.now(timezone.utc):
            raise HTTPException(429, "Too many login attempts; try again later")
        account = conn.execute("SELECT account_id,password_hash,status FROM accounts WHERE email_normalized=%s", (email,)).fetchone()
        if account and account["status"] == "active":
            try:
                valid = ph.verify(account["password_hash"], body.password)
            except (VerifyMismatchError, VerificationError):
                valid = False
        if not valid:
            conn.execute("""INSERT INTO auth_rate_limits(rate_key,window_started_at,attempts,blocked_until)
                VALUES (%s,now(),1,NULL)
                ON CONFLICT(rate_key) DO UPDATE SET
                attempts=CASE WHEN auth_rate_limits.window_started_at < now()-interval '15 minutes' THEN 1 ELSE auth_rate_limits.attempts+1 END,
                window_started_at=CASE WHEN auth_rate_limits.window_started_at < now()-interval '15 minutes' THEN now() ELSE auth_rate_limits.window_started_at END,
                blocked_until=CASE WHEN (CASE WHEN auth_rate_limits.window_started_at < now()-interval '15 minutes' THEN 1 ELSE auth_rate_limits.attempts+1 END) >= 5 THEN now()+interval '15 minutes' ELSE auth_rate_limits.blocked_until END""", (rate_key,))
        else:
            conn.execute("DELETE FROM auth_rate_limits WHERE rate_key=%s", (rate_key,))
            if ph.check_needs_rehash(account["password_hash"]):
                conn.execute("UPDATE accounts SET password_hash=%s,updated_at=now() WHERE account_id=%s", (ph.hash(body.password),account["account_id"]))
            result = {"account_id":str(account["account_id"]), **issue_session(conn, str(account["account_id"]))}
    if not valid:
        raise HTTPException(401, "Invalid email or password")
    return result


@app.post("/v1/auth/refresh")
def refresh_session(refresh_token: str = Header(alias="X-Refresh-Token")):
    old_hash = token_hash(refresh_token)
    with db() as conn:
        old = conn.execute("""SELECT s.session_id,s.account_id,a.status FROM account_sessions s JOIN accounts a ON a.account_id=s.account_id
            WHERE s.token_hash=%s AND s.revoked_at IS NULL AND s.expires_at>now() FOR UPDATE""", (old_hash,)).fetchone()
        if not old or old["status"] != "active":
            raise HTTPException(401, "Refresh token is invalid")
        conn.execute("UPDATE account_sessions SET revoked_at=now() WHERE session_id=%s", (old["session_id"],))
        session = issue_session(conn, str(old["account_id"]))
    return {"account_id":str(old["account_id"]), **session}


@app.post("/v1/auth/logout")
def logout(account=Depends(current_account)):
    with db() as conn:
        conn.execute("UPDATE account_sessions SET revoked_at=now() WHERE session_id=%s", (account["session_id"],))
    return {"ok":True}


@app.post("/v1/characters")
def create_character(body: CharacterCreate, account=Depends(current_account)):
    cid = uuid.uuid4()
    try:
        with db() as conn:
            conn.execute("INSERT INTO characters(character_id,account_id,world_id,display_name) VALUES (%s,%s,%s,%s)",
                         (cid,account["account_id"],WORLD_ID,body.display_name.strip()))
            starter_items = [("healing_potion",2),("fishing_rod",1),("wheat_seed",6),("carrot_seed",4),("berry_seed",3),("hay",5),("wood_log",12)]
            for slot, (definition_id, quantity) in enumerate(starter_items):
                conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index) VALUES (%s,%s,%s,%s,%s)",
                             (uuid.uuid4(),cid,definition_id,quantity,slot))
            weapon_id, armor_id = uuid.uuid4(), uuid.uuid4()
            conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index) VALUES (%s,%s,'rusty_sword',1,NULL),(%s,%s,'cloth_tunic',1,NULL)",
                         (weapon_id,cid,armor_id,cid))
            conn.execute("INSERT INTO equipment_slots(character_id,slot_id,item_instance_id) VALUES (%s,'weapon',%s),(%s,'armor',%s)",
                         (cid,weapon_id,cid,armor_id))
            conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,25,'starter_grant',%s)",
                         (uuid.uuid4(),WORLD_ID,cid,"starter:"+str(cid)))
        return {"character_id":str(cid), "display_name":body.display_name.strip(), "world_id":WORLD_ID, "revision":0}
    except psycopg.errors.UniqueViolation:
        raise HTTPException(409, "That character name is already in use in Elyndor")


@app.get("/v1/characters")
def list_characters(account=Depends(current_account)):
    with db() as conn:
        rows = conn.execute("SELECT character_id,display_name,level,revision,updated_at FROM characters WHERE account_id=%s AND world_id=%s ORDER BY created_at", (account["account_id"],WORLD_ID)).fetchall()
    return {"world_id":WORLD_ID,"characters":[{**r,"character_id":str(r["character_id"])} for r in rows]}


@app.get("/v1/characters/{character_id}")
def get_character(character_id: uuid.UUID, account=Depends(current_account)):
    with db() as conn:
        row = conn.execute("SELECT character_id,display_name,level,character_state,revision FROM characters WHERE character_id=%s AND account_id=%s AND world_id=%s", (character_id,account["account_id"],WORLD_ID)).fetchone()
    if not row: raise HTTPException(404, "Character not found")
    return {**row,"character_id":str(row["character_id"])}


@app.put("/v1/characters/{character_id}")
def update_character(character_id: uuid.UUID, body: CharacterUpdate, account=Depends(current_account)):
    # Clients may update presentation preferences only; progression, location, health,
    # cultivation, inventory and currency are exclusively server-owned.
    allowed_keys = {"appearance", "hotbar", "ui_preferences"}
    if not set(body.state.keys()).issubset(allowed_keys):
        raise HTTPException(403, "Gameplay state can only be changed by the authoritative world server")
    with db() as conn:
        current = conn.execute("SELECT character_state,revision FROM characters WHERE character_id=%s AND account_id=%s AND world_id=%s FOR UPDATE",
            (character_id,account["account_id"],WORLD_ID)).fetchone()
        if not current or int(current["revision"]) != body.revision:
            raise HTTPException(409, "Character revision conflict or character not owned by this account")
        merged = dict(current["character_state"] or {})
        merged.update(body.state)
        row = conn.execute("UPDATE characters SET character_state=%s,revision=revision+1,updated_at=now() WHERE character_id=%s RETURNING revision",
            (Jsonb(merged),character_id)).fetchone()
    return {"ok":True,"revision":row["revision"]}


@app.get("/v1/characters/{character_id}/inventory")
def get_inventory(character_id: uuid.UUID, account=Depends(current_account)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND account_id=%s", (character_id,account["account_id"])).fetchone()
        if not owned: raise HTTPException(404, "Character not found")
        items = conn.execute("SELECT item_instance_id,item_definition_id,quantity,slot_index,item_state,revision FROM inventory_items WHERE character_id=%s ORDER BY slot_index NULLS LAST", (character_id,)).fetchall()
        equipment = conn.execute("SELECT slot_id,item_instance_id FROM equipment_slots WHERE character_id=%s", (character_id,)).fetchall()
    return {"items":[{**i,"item_instance_id":str(i["item_instance_id"])} for i in items],"equipment":[{**e,"item_instance_id":str(e["item_instance_id"]) if e["item_instance_id"] else None} for e in equipment]}


@app.get("/v1/characters/{character_id}/quests")
def get_character_quests(character_id: uuid.UUID, account=Depends(current_account)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND account_id=%s AND world_id=%s", (character_id, account["account_id"], WORLD_ID)).fetchone()
        if not owned:
            raise HTTPException(404, "Character not found")
        rows = conn.execute("SELECT quest_id,quest_state,revision,updated_at FROM character_quests WHERE character_id=%s ORDER BY quest_id", (character_id,)).fetchall()
        progress_rows = conn.execute("SELECT quest_id,objective_index,progress FROM character_quest_objectives WHERE character_id=%s ORDER BY quest_id,objective_index", (character_id,)).fetchall()
    progress = {}
    for item in progress_rows: progress.setdefault(str(item["quest_id"]), {})[int(item["objective_index"])] = int(item["progress"])
    for row in rows: row["objective_progress"] = progress.get(str(row["quest_id"]), {})
    return {"world_id": WORLD_ID, "quests": rows}


@app.get("/v1/internal/merchants/{merchant_id}/stock")
def internal_get_merchant_stock(merchant_id: uuid.UUID, _=Depends(service_auth)):
    with db() as conn:
        merchant = conn.execute("SELECT merchant_name,region_id,merchant_state FROM merchant_catalog WHERE world_id=%s AND merchant_id=%s", (WORLD_ID, merchant_id)).fetchone()
        rows = conn.execute("SELECT item_definition_id,quantity,unit_price,revision,updated_at FROM merchant_stock WHERE world_id=%s AND merchant_id=%s ORDER BY item_definition_id", (WORLD_ID, merchant_id)).fetchall()
    return {"world_id": WORLD_ID, "merchant_id": str(merchant_id), "merchant": merchant, "stock": rows}


@app.get("/v1/merchants/{merchant_id}/stock")
def get_merchant_stock(merchant_id: uuid.UUID, account=Depends(current_account)):
    with db() as conn:
        rows = conn.execute("SELECT item_definition_id,quantity,unit_price,revision,updated_at FROM merchant_stock WHERE world_id=%s AND merchant_id=%s ORDER BY item_definition_id", (WORLD_ID, merchant_id)).fetchall()
    return {"world_id": WORLD_ID, "merchant_id": str(merchant_id), "stock": rows}


@app.post("/v1/characters/{character_id}/inventory/move")
def move_inventory(character_id: uuid.UUID, body: InventoryMove, account=Depends(current_account)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND account_id=%s FOR UPDATE", (character_id,account["account_id"])).fetchone()
        if not owned: raise HTTPException(404, "Character not found")
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok":prior["status"]=="committed","replayed":True,"result":prior["payload"]}
        item = conn.execute("SELECT item_instance_id FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE", (character_id,body.item_instance_id)).fetchone()
        if not item: raise HTTPException(404, "Item not owned")
        equipped = conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s", (character_id,body.item_instance_id)).fetchone()
        if equipped: raise HTTPException(409, "Unequip this item before moving it")
        occupied = conn.execute("SELECT item_instance_id FROM inventory_items WHERE character_id=%s AND slot_index=%s AND item_instance_id<>%s FOR UPDATE", (character_id,body.destination_slot,body.item_instance_id)).fetchone()
        if occupied: raise HTTPException(409, "Destination slot is occupied")
        conn.execute("UPDATE inventory_items SET slot_index=%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s", (body.destination_slot,character_id,body.item_instance_id))
        payload={"item_instance_id":str(body.item_instance_id),"slot_index":body.destination_slot}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'inventory_move',%s,'committed',%s)", (uuid.uuid4(),WORLD_ID,character_id,body.idempotency_key,Jsonb(payload)))
    return {"ok":True,"replayed":False,"result":payload}


@app.post("/v1/characters/{character_id}/equipment")
def change_equipment(character_id: uuid.UUID, body: EquipmentChange, account=Depends(current_account)):
    with db() as conn:
        owned=conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND account_id=%s FOR UPDATE", (character_id,account["account_id"])).fetchone()
        if not owned: raise HTTPException(404,"Character not found")
        prior=conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s",(body.idempotency_key,)).fetchone()
        if prior: return {"ok":prior["status"]=="committed","replayed":True,"result":prior["payload"]}
        current=conn.execute("SELECT item_instance_id FROM equipment_slots WHERE character_id=%s AND slot_id=%s FOR UPDATE",(character_id,body.slot_id)).fetchone()
        old_id=current["item_instance_id"] if current else None
        new_item_slot = None
        if body.item_instance_id:
            item=conn.execute("SELECT item_instance_id,slot_index FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE",(character_id,body.item_instance_id)).fetchone()
            if not item: raise HTTPException(404,"Item not owned")
            new_item_slot = item["slot_index"]
            elsewhere=conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s AND slot_id<>%s",(character_id,body.item_instance_id,body.slot_id)).fetchone()
            if elsewhere: raise HTTPException(409,"Item is already equipped in another slot")
        used={int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL",(character_id,)).fetchall()}
        free_slot = int(new_item_slot) if new_item_slot is not None else next((i for i in range(28) if i not in used),None)
        if old_id and old_id != body.item_instance_id:
            if free_slot is None: raise HTTPException(409,"No free inventory slot to unequip the previous item")
            conn.execute("UPDATE inventory_items SET slot_index=%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s",(free_slot,character_id,old_id))
            used.add(free_slot)
        if body.item_instance_id:
            conn.execute("UPDATE inventory_items SET slot_index=NULL,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s",(character_id,body.item_instance_id))
        conn.execute("INSERT INTO equipment_slots(character_id,slot_id,item_instance_id) VALUES (%s,%s,%s) ON CONFLICT(character_id,slot_id) DO UPDATE SET item_instance_id=EXCLUDED.item_instance_id",(character_id,body.slot_id,body.item_instance_id))
        payload={"slot_id":body.slot_id,"item_instance_id":str(body.item_instance_id) if body.item_instance_id else None}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'equipment_change',%s,'committed',%s)",(uuid.uuid4(),WORLD_ID,character_id,body.idempotency_key,Jsonb(payload)))
    return {"ok":True,"replayed":False,"result":payload}


# Recipe inputs and outputs are loaded from the checked-in server catalog mirrored from RecipeDB.


def _owned_character(conn, character_id, account_id):
    row = conn.execute("SELECT character_id FROM characters WHERE character_id=%s AND account_id=%s AND world_id=%s FOR UPDATE", (character_id, account_id, WORLD_ID)).fetchone()
    if not row:
        raise HTTPException(404, "Character not found")
    return row


def _record_transaction(conn, character_id, tx_type, key, payload):
    conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,%s,%s,'committed',%s)", (uuid.uuid4(), WORLD_ID, character_id, tx_type, key, Jsonb(payload)))


@app.post("/v1/characters/{character_id}/inventory/consume")
def consume_inventory(character_id: uuid.UUID, body: InventoryConsume, account=Depends(current_account)):
    with db() as conn:
        _owned_character(conn, character_id, account["account_id"])
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": prior["status"] == "committed", "replayed": True, "result": prior["payload"]}
        item = conn.execute("SELECT quantity,item_definition_id FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE", (character_id, body.item_instance_id)).fetchone()
        if not item or int(item["quantity"]) < body.quantity:
            raise HTTPException(409, "Item quantity is insufficient")
        equipped = conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s", (character_id, body.item_instance_id)).fetchone()
        if equipped:
            raise HTTPException(409, "Unequip this item before consuming it")
        remaining = int(item["quantity"]) - body.quantity
        if remaining:
            conn.execute("UPDATE inventory_items SET quantity=%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s", (remaining, character_id, body.item_instance_id))
        else:
            conn.execute("DELETE FROM inventory_items WHERE character_id=%s AND item_instance_id=%s", (character_id, body.item_instance_id))
        payload = {"item_instance_id": str(body.item_instance_id), "item_definition_id": item["item_definition_id"], "consumed": body.quantity, "remaining": remaining}
        _record_transaction(conn, character_id, "inventory_consume", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


def _progress_active_quest_objectives(conn, character_id, objective_type: str, target_id: str, amount: int = 1):
    active = conn.execute("SELECT quest_id FROM character_quests WHERE character_id=%s AND quest_state->>'status'='active' FOR UPDATE", (character_id,)).fetchall()
    for active_row in active:
        quest_id = str(active_row["quest_id"])
        definition = QUEST_CATALOG.get(quest_id, {})
        for index, objective in enumerate(definition.get("objectives", [])):
            if objective.get("type") == objective_type and objective.get("target") == target_id:
                required = int(objective.get("count", 1))
                conn.execute("INSERT INTO character_quest_objectives(character_id,quest_id,objective_index,progress) VALUES (%s,%s,%s,%s) ON CONFLICT(character_id,quest_id,objective_index) DO UPDATE SET progress=LEAST(%s,character_quest_objectives.progress+EXCLUDED.progress),updated_at=now()", (character_id, quest_id, index, amount, required))


@app.post("/v1/characters/{character_id}/craft")
def craft_item(character_id: uuid.UUID, body: CraftRequest, account=Depends(current_account)):
    recipe = CRAFT_RECIPES.get(body.recipe_id)
    if not recipe:
        raise HTTPException(404, "Unknown recipe")
    with db() as conn:
        _owned_character(conn, character_id, account["account_id"])
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": prior["status"] == "committed", "replayed": True, "result": prior["payload"]}
        rows = conn.execute("SELECT item_instance_id,item_definition_id,quantity,slot_index FROM inventory_items WHERE character_id=%s ORDER BY item_definition_id,item_instance_id FOR UPDATE", (character_id,)).fetchall()
        totals = {}
        for row in rows:
            totals[row["item_definition_id"]] = totals.get(row["item_definition_id"], 0) + int(row["quantity"])
        required = {k: int(v) * body.quantity for k, v in recipe["inputs"].items()}
        for definition_id, needed in required.items():
            if totals.get(definition_id, 0) < needed:
                raise HTTPException(409, f"Insufficient crafting material: {definition_id}")
        # Consume deterministic stacks, preserving atomicity within this transaction.
        for definition_id, needed in required.items():
            left = needed
            for row in rows:
                if row["item_definition_id"] != definition_id or left <= 0:
                    continue
                take = min(int(row["quantity"]), left)
                remain = int(row["quantity"]) - take
                if remain:
                    conn.execute("UPDATE inventory_items SET quantity=%s,revision=revision+1 WHERE item_instance_id=%s", (remain, row["item_instance_id"]))
                else:
                    conn.execute("DELETE FROM inventory_items WHERE item_instance_id=%s", (row["item_instance_id"],))
                left -= take
        occupied_slots = {int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL", (character_id,)).fetchall()}
        slot = next((candidate for candidate in range(28) if candidate not in occupied_slots), None)
        output_quantity = int(recipe["output_quantity"]) * body.quantity
        if slot is None:
            raise HTTPException(409, "Inventory is full")
        output_id = uuid.uuid4()
        conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index) VALUES (%s,%s,%s,%s,%s)", (output_id, character_id, recipe["output"], output_quantity, slot))
        _progress_active_quest_objectives(conn, character_id, "craft", recipe["output"], output_quantity)
        payload = {"recipe_id": body.recipe_id, "item_instance_id": str(output_id), "item_definition_id": recipe["output"], "quantity": output_quantity, "slot_index": slot}
        _record_transaction(conn, character_id, "craft", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.post("/v1/internal/crafting/craft")
def internal_craft_item(body: InternalCraftRequest, _=Depends(service_auth)):
    recipe = CRAFT_RECIPES.get(body.recipe_id)
    if not recipe: raise HTTPException(404, "Unknown server recipe")
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": prior["status"] == "committed", "replayed": True, "result": prior["payload"]}
        rows = conn.execute("SELECT item_instance_id,item_definition_id,quantity FROM inventory_items WHERE character_id=%s ORDER BY item_definition_id,item_instance_id FOR UPDATE", (body.character_id,)).fetchall()
        totals = {}
        for row in rows: totals[row["item_definition_id"]] = totals.get(row["item_definition_id"], 0) + int(row["quantity"])
        required = {key: int(value) * body.quantity for key, value in recipe["inputs"].items()}
        for item_id, needed in required.items():
            if totals.get(item_id, 0) < needed: raise HTTPException(409, f"Insufficient crafting material: {item_id}")
        for item_id, needed in required.items():
            remaining = needed
            for row in rows:
                if row["item_definition_id"] != item_id or remaining <= 0: continue
                take = min(int(row["quantity"]), remaining); rest = int(row["quantity"]) - take
                if rest: conn.execute("UPDATE inventory_items SET quantity=%s,revision=revision+1 WHERE item_instance_id=%s", (rest, row["item_instance_id"]))
                else: conn.execute("DELETE FROM inventory_items WHERE item_instance_id=%s", (row["item_instance_id"],))
                remaining -= take
        occupied = {int(row["slot_index"]) for row in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL", (body.character_id,)).fetchall()}
        slot = next((candidate for candidate in range(28) if candidate not in occupied), None)
        if slot is None: raise HTTPException(409, "Inventory is full")
        output_quantity = int(recipe["output_quantity"]) * body.quantity; output_id = uuid.uuid4()
        conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index) VALUES (%s,%s,%s,%s,%s)", (output_id, body.character_id, recipe["output"], output_quantity, slot))
        _progress_active_quest_objectives(conn, body.character_id, "craft", recipe["output"], output_quantity)
        payload = {"recipe_id": body.recipe_id, "item_instance_id": str(output_id), "item_definition_id": recipe["output"], "quantity": output_quantity, "slot_index": slot}
        _record_transaction(conn, body.character_id, "craft", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


def _record_merchant_tax_and_flow(conn, merchant_id, item_id: str, quantity: int, unit_value: int, event_type: str, idempotency_key: str):
    merchant = conn.execute("SELECT region_id,territory_id FROM merchant_catalog WHERE world_id=%s AND merchant_id=%s", (WORLD_ID, merchant_id)).fetchone()
    if not merchant:
        return {"tax_amount": 0, "territory_id": None}
    territory_id = merchant["territory_id"] or merchant["region_id"]
    if territory_id and not conn.execute("SELECT 1 FROM territory_control WHERE world_id=%s AND territory_id=%s", (WORLD_ID, territory_id)).fetchone():
        territory_id = None
    tax_amount = 0
    if territory_id:
        territory = conn.execute("""SELECT tc.organization_id,tp.tax_basis_points,tp.enabled FROM territory_control tc
            LEFT JOIN territory_tax_policy tp ON tp.world_id=tc.world_id AND tp.territory_id=tc.territory_id
            WHERE tc.world_id=%s AND tc.territory_id=%s FOR UPDATE OF tc""", (WORLD_ID, territory_id)).fetchone()
        if territory and territory["organization_id"]:
            rate = int(territory["tax_basis_points"] or 0) if territory["enabled"] is not False else 0
            tax_amount = (quantity * unit_value * rate) // 10000
            if tax_amount > 0:
                tax_key = hashlib.sha256((idempotency_key + ":sect-tax").encode()).hexdigest()
                conn.execute("""INSERT INTO organization_treasury_ledger(entry_id,world_id,organization_id,territory_id,amount,reason,source_ref,idempotency_key)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(idempotency_key) DO NOTHING""",
                    (uuid.uuid4(), WORLD_ID, territory["organization_id"], territory_id, tax_amount, "merchant_" + event_type, str(merchant_id), tax_key))
    flow_key = hashlib.sha256((idempotency_key + ":regional-flow").encode()).hexdigest()
    conn.execute("""INSERT INTO regional_economy_ledger(entry_id,world_id,region_id,territory_id,organization_id,commodity_id,quantity_delta,unit_value,event_type,idempotency_key)
        VALUES (%s,%s,%s,%s,(SELECT organization_id FROM territory_control WHERE world_id=%s AND territory_id=%s),%s,%s,%s,%s,%s)
        ON CONFLICT(idempotency_key) DO NOTHING""",
        (uuid.uuid4(), WORLD_ID, merchant["region_id"], territory_id, WORLD_ID, territory_id or "", item_id, quantity if event_type == "sale" else -quantity, unit_value, "merchant_" + event_type, flow_key))
    return {"tax_amount": tax_amount, "territory_id": territory_id}


@app.post("/v1/internal/merchant/purchase")
def internal_merchant_purchase(body: InternalMerchantPurchase, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned:
            raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": prior["status"] == "committed", "replayed": True, "result": prior["payload"]}
        stock = conn.execute("""SELECT ms.quantity,ms.unit_price,mc.region_id
            FROM merchant_stock ms LEFT JOIN merchant_catalog mc
              ON mc.world_id=ms.world_id AND mc.merchant_id=ms.merchant_id
            WHERE ms.world_id=%s AND ms.merchant_id=%s AND ms.item_definition_id=%s
            FOR UPDATE OF ms""", (WORLD_ID, body.merchant_id, body.item_definition_id)).fetchone()
        if not stock or int(stock["quantity"]) < body.quantity:
            raise HTTPException(409, "Merchant does not have enough stock")
        # Serialize price formation for this shared regional commodity. The
        # lock and inventory/currency/ledger writes live in this same DB txn.
        region_id = str(stock.get("region_id") or "")
        unit_price = int(stock["unit_price"])
        if region_id:
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("regional-market:%s:%s" % (region_id, body.item_definition_id),))
            regional_stock = conn.execute("""SELECT COALESCE(SUM(ms.quantity),0) AS quantity,
                    COUNT(DISTINCT ms.merchant_id) AS merchants
                FROM merchant_stock ms JOIN merchant_catalog mc
                  ON mc.world_id=ms.world_id AND mc.merchant_id=ms.merchant_id
                WHERE ms.world_id=%s AND mc.region_id=%s AND ms.item_definition_id=%s""",
                (WORLD_ID, region_id, body.item_definition_id)).fetchone()
            merchant_count = max(1, int(regional_stock["merchants"] or 1))
            target_stock = float(merchant_count * 24)
            available_stock = float(regional_stock["quantity"] or 0)
            scarcity = (target_stock - available_stock) / target_stock
            price_multiplier = max(0.65, min(2.25, 1.0 + scarcity * 0.85))
            unit_price = max(1, int(round(unit_price * price_multiplier)))
        cost = unit_price * body.quantity
        balance = conn.execute("SELECT COALESCE(SUM(amount),0) AS balance FROM currency_ledger WHERE character_id=%s", (body.character_id,)).fetchone()
        if int(balance["balance"]) < cost:
            raise HTTPException(409, "Insufficient currency")
        slots = {int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL", (body.character_id,)).fetchall()}
        slot = next((candidate for candidate in range(28) if candidate not in slots), None)
        if slot is None:
            raise HTTPException(409, "Inventory is full")
        conn.execute("UPDATE merchant_stock SET quantity=quantity-%s,revision=revision+1,updated_at=now() WHERE world_id=%s AND merchant_id=%s AND item_definition_id=%s", (body.quantity, WORLD_ID, body.merchant_id, body.item_definition_id))
        economy = _record_merchant_tax_and_flow(conn, body.merchant_id, body.item_definition_id, body.quantity, unit_price, "purchase", body.idempotency_key)
        ledger_key = hashlib.sha256(f"{body.character_id}:{body.idempotency_key}:merchant_gold".encode()).hexdigest()
        conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'merchant_purchase',%s)", (uuid.uuid4(), WORLD_ID, body.character_id, -cost, ledger_key))
        item_id = uuid.uuid4()
        conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index) VALUES (%s,%s,%s,%s,%s)", (item_id, body.character_id, body.item_definition_id, body.quantity, slot))
        _progress_active_quest_objectives(conn, body.character_id, "collect", body.item_definition_id, body.quantity)
        payload = {"item_instance_id": str(item_id), "item_definition_id": body.item_definition_id, "quantity": body.quantity, "unit_price": unit_price, "gold_spent": cost, "tax_paid": economy["tax_amount"], "remaining_gold": int(balance["balance"]) - cost, "region_id": region_id, "regional_price_multiplier": round(unit_price / max(1, int(stock["unit_price"])), 4)}
        _record_transaction(conn, body.character_id, "merchant_purchase", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.post("/v1/internal/quests/accept")
def internal_quest_accept(body: InternalQuestAccept, _=Depends(service_auth)):
    quest = QUEST_CATALOG.get(body.quest_id)
    if not quest:
        raise HTTPException(404, "Unknown quest definition")
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": True, "replayed": True, "result": prior["payload"]}
        existing = conn.execute("SELECT quest_state FROM character_quests WHERE character_id=%s AND quest_id=%s FOR UPDATE", (body.character_id, body.quest_id)).fetchone()
        if existing and existing["quest_state"].get("status") == "completed":
            raise HTTPException(409, "Quest is already completed")
        for prerequisite in quest.get("prereq", []):
            row = conn.execute("SELECT quest_state FROM character_quests WHERE character_id=%s AND quest_id=%s", (body.character_id, prerequisite)).fetchone()
            if not row or row["quest_state"].get("status") != "completed":
                raise HTTPException(409, "Quest prerequisites are not complete")
        state = {"status": "active", "title": quest.get("title", body.quest_id)}
        conn.execute("INSERT INTO character_quests(character_id,quest_id,quest_state,revision) VALUES (%s,%s,%s,0) ON CONFLICT(character_id,quest_id) DO UPDATE SET quest_state=EXCLUDED.quest_state,revision=character_quests.revision+1,updated_at=now()", (body.character_id, body.quest_id, Jsonb(state)))
        conn.execute("DELETE FROM character_quest_objectives WHERE character_id=%s AND quest_id=%s", (body.character_id, body.quest_id))
        for i, objective in enumerate(quest.get("objectives", [])):
            initial_progress = 0
            if objective.get("type") == "collect":
                count_row = conn.execute("SELECT COALESCE(SUM(quantity),0) AS quantity FROM inventory_items WHERE character_id=%s AND item_definition_id=%s", (body.character_id, objective.get("target", ""))).fetchone()
                initial_progress = min(int(objective.get("count", 1)), int(count_row["quantity"]))
            conn.execute("INSERT INTO character_quest_objectives(character_id,quest_id,objective_index,progress) VALUES (%s,%s,%s,%s)", (body.character_id, body.quest_id, i, initial_progress))
        payload = {"quest_id": body.quest_id, "status": "active"}
        _record_transaction(conn, body.character_id, "quest_accept", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.post("/v1/internal/quests/objective-event")
def internal_quest_objective_event(body: InternalQuestObjective, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": True, "replayed": True, "result": prior["payload"]}
        if body.quest_id == "*":
            active_rows = conn.execute("SELECT quest_id FROM character_quests WHERE character_id=%s AND quest_state->>'status'='active' FOR UPDATE", (body.character_id,)).fetchall()
            quest_ids = [str(row["quest_id"]) for row in active_rows]
        else:
            state = conn.execute("SELECT quest_state FROM character_quests WHERE character_id=%s AND quest_id=%s FOR UPDATE", (body.character_id, body.quest_id)).fetchone()
            if not state or state["quest_state"].get("status") != "active":
                raise HTTPException(409, "Quest is not active")
            quest_ids = [body.quest_id]
        changed = []
        for quest_id in quest_ids:
            definition = QUEST_CATALOG.get(quest_id)
            if not definition: continue
            for index, objective in enumerate(definition.get("objectives", [])):
                if objective.get("type") != body.objective_type or objective.get("target") != body.target_id: continue
                required = int(objective.get("count", 1))
                conn.execute("INSERT INTO character_quest_objectives(character_id,quest_id,objective_index,progress) VALUES (%s,%s,%s,%s) ON CONFLICT(character_id,quest_id,objective_index) DO UPDATE SET progress=LEAST(%s,character_quest_objectives.progress+EXCLUDED.progress),updated_at=now()", (body.character_id, quest_id, index, body.amount, required))
                changed.append({"quest_id": quest_id, "objective_index": index})
        payload = {"quest_ids": changed, "event": body.objective_type, "target": body.target_id, "amount": body.amount}
        _record_transaction(conn, body.character_id, "quest_objective", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.post("/v1/internal/quests/turn-in")
def internal_quest_turn_in(body: InternalQuestTurnIn, _=Depends(service_auth)):
    definition = QUEST_CATALOG.get(body.quest_id)
    if not definition: raise HTTPException(404, "Unknown quest definition")
    if definition.get("turn_in") != body.npc_name: raise HTTPException(403, "Wrong quest turn-in NPC")
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": prior["status"] == "committed", "replayed": True, "result": prior["payload"]}
        quest = conn.execute("SELECT quest_state FROM character_quests WHERE character_id=%s AND quest_id=%s FOR UPDATE", (body.character_id, body.quest_id)).fetchone()
        if not quest or quest["quest_state"].get("status") != "active": raise HTTPException(409, "Quest is not active")
        rows = conn.execute("SELECT objective_index,progress FROM character_quest_objectives WHERE character_id=%s AND quest_id=%s", (body.character_id, body.quest_id)).fetchall()
        progress = {int(r["objective_index"]): int(r["progress"]) for r in rows}
        for index, objective in enumerate(definition.get("objectives", [])):
            if progress.get(index, 0) < int(objective.get("count", 1)):
                raise HTTPException(409, "Quest objectives are not complete")
        rewards = definition.get("rewards", {})
        gold = int(rewards.get("gold", 0))
        if gold:
            gold_key = hashlib.sha256(f"{body.character_id}:{body.quest_id}:quest_gold".encode()).hexdigest()
            conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'quest_reward',%s) ON CONFLICT(idempotency_key) DO NOTHING", (uuid.uuid4(), WORLD_ID, body.character_id, gold, gold_key))
        granted = []
        used = {int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL", (body.character_id,)).fetchall()}
        for reward in rewards.get("items", []):
            item_id = str(reward.get("id", "")); quantity = int(reward.get("count", 1))
            if not re.fullmatch(r"[a-z0-9_]{2,96}", item_id) or quantity < 1: raise HTTPException(500, "Invalid server quest reward catalog")
            slot = next((candidate for candidate in range(28) if candidate not in used), None)
            if slot is None: raise HTTPException(409, "Inventory is full; quest reward remains unclaimed")
            used.add(slot); instance_id = uuid.uuid4()
            conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index,item_state) VALUES (%s,%s,%s,%s,%s,%s)", (instance_id, body.character_id, item_id, quantity, slot, Jsonb({"grade": int(reward.get("grade", 0))})))
            granted.append({"item_instance_id": str(instance_id), "item_definition_id": item_id, "quantity": quantity})
        transaction_id = uuid.uuid4()
        conn.execute("INSERT INTO quest_reward_claims(character_id,quest_id,transaction_id) VALUES (%s,%s,%s)", (body.character_id, body.quest_id, transaction_id))
        completed_state = {"status": "completed", "completed_at": datetime.now(timezone.utc).isoformat(), "rewards": {"gold": gold, "items": granted, "skills": rewards.get("skills", {}), "title": rewards.get("title"), "reputation": rewards.get("reputation", {})}}
        conn.execute("UPDATE character_quests SET quest_state=%s,revision=revision+1,updated_at=now() WHERE character_id=%s AND quest_id=%s", (Jsonb(completed_state), body.character_id, body.quest_id))
        payload = {"quest_id": body.quest_id, "status": "completed", "giver": definition.get("giver", ""), "gold_granted": gold, "items_granted": granted, "skills": rewards.get("skills", {}), "title": rewards.get("title"), "reputation": rewards.get("reputation", {})}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'quest_reward',%s,'committed',%s)", (transaction_id, WORLD_ID, body.character_id, body.idempotency_key, Jsonb(payload)))
    return {"ok": True, "replayed": False, "result": payload}


@app.put("/v1/internal/merchants/provision")
def internal_merchant_provision(body: MerchantProvision, _=Depends(service_auth)):
    with db() as conn:
        conn.execute("INSERT INTO merchant_catalog(world_id,merchant_id,merchant_name,region_id) VALUES (%s,%s,%s,%s) ON CONFLICT(world_id,merchant_id) DO UPDATE SET merchant_name=EXCLUDED.merchant_name,region_id=EXCLUDED.region_id", (WORLD_ID, body.merchant_id, body.merchant_name, body.region_id))
        for line in body.stock:
            conn.execute("INSERT INTO merchant_stock(world_id,merchant_id,item_definition_id,quantity,unit_price) VALUES (%s,%s,%s,%s,%s) ON CONFLICT(world_id,merchant_id,item_definition_id) DO NOTHING", (WORLD_ID, body.merchant_id, line.item_definition_id, line.quantity, line.unit_price))
    return {"ok": True, "world_id": WORLD_ID, "merchant_id": str(body.merchant_id), "provisioned_lines": len(body.stock)}


@app.post("/v1/internal/merchant/restock")
def internal_merchant_restock(body: MerchantRestockRequest, _=Depends(service_auth)):
    with db() as conn:
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": True, "replayed": True, "result": prior["payload"]}
        updated = []
        for line in body.items:
            row = conn.execute("UPDATE merchant_stock SET quantity=LEAST(%s,quantity+%s),revision=revision+1,updated_at=now() WHERE world_id=%s AND merchant_id=%s AND item_definition_id=%s RETURNING quantity", (line.stock_cap, line.quantity_add, WORLD_ID, body.merchant_id, line.item_definition_id)).fetchone()
            if row: updated.append({"item_definition_id": line.item_definition_id, "quantity": int(row["quantity"])})
        payload = {"merchant_id": str(body.merchant_id), "restocked": updated}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,NULL,'merchant_restock',%s,'committed',%s)", (uuid.uuid4(), WORLD_ID, body.idempotency_key, Jsonb(payload)))
    return {"ok": True, "replayed": False, "result": payload}


@app.post("/v1/internal/merchant/sell")
def internal_merchant_sell(body: InternalMerchantSale, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok": True, "replayed": True, "result": prior["payload"]}
        item = conn.execute("SELECT item_definition_id,quantity FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE", (body.character_id, body.item_instance_id)).fetchone()
        if not item or int(item["quantity"]) < body.quantity: raise HTTPException(409, "Item quantity is insufficient")
        if conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s", (body.character_id, body.item_instance_id)).fetchone(): raise HTTPException(409, "Unequip this item before selling it")
        conn.execute("INSERT INTO merchant_stock(world_id,merchant_id,item_definition_id,quantity,unit_price) VALUES (%s,%s,%s,%s,%s) ON CONFLICT(world_id,merchant_id,item_definition_id) DO UPDATE SET quantity=merchant_stock.quantity+EXCLUDED.quantity,revision=merchant_stock.revision+1,updated_at=now()", (WORLD_ID, body.merchant_id, item["item_definition_id"], body.quantity, body.unit_price * 2))
        if int(item["quantity"]) == body.quantity: conn.execute("DELETE FROM inventory_items WHERE character_id=%s AND item_instance_id=%s", (body.character_id, body.item_instance_id))
        else: conn.execute("UPDATE inventory_items SET quantity=quantity-%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s", (body.quantity, body.character_id, body.item_instance_id))
        total = body.unit_price * body.quantity
        economy = _record_merchant_tax_and_flow(conn, body.merchant_id, str(item["item_definition_id"]), body.quantity, body.unit_price, "sale", body.idempotency_key)
        net_total = max(0, total - int(economy["tax_amount"]))
        if net_total: conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'merchant_sale',%s)", (uuid.uuid4(), WORLD_ID, body.character_id, net_total, hashlib.sha256(f"{body.character_id}:{body.idempotency_key}:sale_gold".encode()).hexdigest()))
        conn.execute("INSERT INTO merchant_sales_ledger(sale_id,world_id,merchant_id,seller_character_id,item_definition_id,quantity,unit_price,idempotency_key) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", (uuid.uuid4(), WORLD_ID, body.merchant_id, body.character_id, item["item_definition_id"], body.quantity, body.unit_price, body.idempotency_key))
        payload = {"item_definition_id": item["item_definition_id"], "quantity": body.quantity, "gold_received": net_total, "gross_value": total, "tax_paid": economy["tax_amount"]}
        _record_transaction(conn, body.character_id, "merchant_sale", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.get("/v1/internal/world/populations")
def internal_load_populations(_=Depends(service_auth)):
    with db() as conn:
        rows = conn.execute("SELECT region_id,species_id,population_state,revision,updated_at FROM regional_monster_populations WHERE world_id=%s ORDER BY region_id,species_id", (WORLD_ID,)).fetchall()
    return {"world_id": WORLD_ID, "populations": rows}


@app.get("/v1/internal/world/bosses")
def internal_load_bosses(_=Depends(service_auth)):
    with db() as conn:
        rows = conn.execute("SELECT boss_id,region_id,boss_definition_id,encounter_state,revision,last_defeated_at,updated_at FROM world_boss_encounters WHERE world_id=%s ORDER BY region_id,boss_id", (WORLD_ID,)).fetchall()
    return {"world_id": WORLD_ID, "bosses": [{**r, "boss_id": str(r["boss_id"])} for r in rows]}


@app.post("/v1/internal/trades/open")
def internal_trade_open(body: InternalTradeOpen, _=Depends(service_auth)):
    if body.initiator_character_id == body.target_character_id: raise HTTPException(422, "Trade participants must differ")
    with db() as conn:
        ids = conn.execute("SELECT character_id FROM characters WHERE world_id=%s AND character_id IN (%s,%s) FOR UPDATE", (WORLD_ID, body.initiator_character_id, body.target_character_id)).fetchall()
        if len(ids) != 2: raise HTTPException(404, "Both trade participants must exist in Elyndor")
        trade_id = uuid.uuid4()
        conn.execute("INSERT INTO player_trade_sessions(trade_id,world_id,initiator_character_id,target_character_id,trade_state,status,expires_at) VALUES (%s,%s,%s,%s,%s,'offered',now()+(%s * interval '1 second'))", (trade_id, WORLD_ID, body.initiator_character_id, body.target_character_id, Jsonb({"offers": {}}), body.expires_in_seconds))
    return {"ok": True, "trade_id": str(trade_id), "status": "offered"}


@app.post("/v1/internal/trades/accept")
def internal_trade_accept(body: InternalTradeAccept, _=Depends(service_auth)):
    with db() as conn:
        trade = conn.execute("SELECT target_character_id,status,expires_at FROM player_trade_sessions WHERE trade_id=%s AND world_id=%s FOR UPDATE", (body.trade_id, WORLD_ID)).fetchone()
        if not trade or trade["target_character_id"] != body.target_character_id: raise HTTPException(404, "Trade invitation not found")
        if trade["status"] != "offered" or trade["expires_at"] <= datetime.now(timezone.utc): raise HTTPException(409, "Trade invitation expired or unavailable")
        conn.execute("UPDATE player_trade_sessions SET status='accepted',revision=revision+1 WHERE trade_id=%s", (body.trade_id,))
    return {"ok": True, "trade_id": str(body.trade_id), "status": "accepted"}


@app.post("/v1/internal/trades/offer")
def internal_trade_offer(body: InternalTradeOffer, _=Depends(service_auth)):
    with db() as conn:
        trade = conn.execute("SELECT initiator_character_id,target_character_id,status,expires_at,trade_state FROM player_trade_sessions WHERE trade_id=%s AND world_id=%s FOR UPDATE", (body.trade_id, WORLD_ID)).fetchone()
        if not trade or trade["status"] != "accepted" or trade["expires_at"] <= datetime.now(timezone.utc): raise HTTPException(409, "Trade is not accepted or has expired")
        if body.actor_character_id not in (trade["initiator_character_id"], trade["target_character_id"]): raise HTTPException(403, "Character is not a trade participant")
        for item_id in body.item_ids:
            item = conn.execute("SELECT 1 FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE", (body.actor_character_id, item_id)).fetchone()
            if not item or conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s", (body.actor_character_id, item_id)).fetchone(): raise HTTPException(409, "Trade item is unavailable or equipped")
        balance = conn.execute("SELECT COALESCE(SUM(amount),0) AS balance FROM currency_ledger WHERE character_id=%s", (body.actor_character_id,)).fetchone()
        if int(balance["balance"]) < body.gold: raise HTTPException(409, "Insufficient currency for trade offer")
        state = trade["trade_state"] if isinstance(trade["trade_state"], dict) else {}
        offers = state.get("offers", {})
        actor_key = str(body.actor_character_id)
        previous_offer = offers.get(actor_key, {})
        next_offer = {"item_ids": [str(item_id) for item_id in body.item_ids], "gold": body.gold, "confirmed": body.confirmed}
        if previous_offer.get("item_ids", []) != next_offer["item_ids"] or int(previous_offer.get("gold", 0)) != body.gold:
            for other_key in offers:
                if other_key != actor_key:
                    offers[other_key]["confirmed"] = False
        offers[actor_key] = next_offer
        state["offers"] = offers
        conn.execute("UPDATE player_trade_sessions SET trade_state=%s,revision=revision+1 WHERE trade_id=%s", (Jsonb(state), body.trade_id))
    return {"ok": True, "trade_id": str(body.trade_id), "confirmed": body.confirmed}


@app.post("/v1/internal/trades/commit")
def internal_trade_commit(body: InternalTradeCommit, _=Depends(service_auth)):
    with db() as conn:
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": True, "replayed": True, "result": prior["payload"]}
        trade = conn.execute("SELECT initiator_character_id,target_character_id,status,expires_at,trade_state FROM player_trade_sessions WHERE trade_id=%s AND world_id=%s FOR UPDATE", (body.trade_id, WORLD_ID)).fetchone()
        if not trade or trade["status"] != "accepted" or trade["expires_at"] <= datetime.now(timezone.utc): raise HTTPException(409, "Trade is not accepted or has expired")
        a, b = trade["initiator_character_id"], trade["target_character_id"]
        if a == b: raise HTTPException(409, "Trade participants must differ")
        trade_state = trade["trade_state"] if isinstance(trade["trade_state"], dict) else {}
        offers = trade_state.get("offers", {})
        offer_a = offers.get(str(a), {})
        offer_b = offers.get(str(b), {})
        if not offer_a.get("confirmed", False) or not offer_b.get("confirmed", False): raise HTTPException(409, "Both players must confirm the current trade offer")
        items_a = [uuid.UUID(value) for value in offer_a.get("item_ids", [])]
        items_b = [uuid.UUID(value) for value in offer_b.get("item_ids", [])]
        gold_a = int(offer_a.get("gold", 0)); gold_b = int(offer_b.get("gold", 0))
        transfer_items = {str(a): [], str(b): []}
        for cid, item_ids in ((a, items_a), (b, items_b)):
            for item_id in item_ids:
                item = conn.execute("SELECT item_instance_id,item_definition_id,quantity FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE", (cid, item_id)).fetchone()
                if not item or conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s", (cid, item_id)).fetchone(): raise HTTPException(409, "Trade item is unavailable or equipped")
                transfer_items[str(cid)].append({"item_instance_id": item_id, "item_definition_id": item["item_definition_id"], "quantity": int(item["quantity"])})
        balances = {}
        for cid, offer in ((a, gold_a), (b, gold_b)):
            bal = conn.execute("SELECT COALESCE(SUM(amount),0) AS balance FROM currency_ledger WHERE character_id=%s", (cid,)).fetchone()
            balances[cid] = int(bal["balance"])
            if balances[cid] < offer: raise HTTPException(409, "A participant cannot afford the offered currency")
        for src, dst, item_ids in ((a, b, items_a), (b, a, items_b)):
            for item_id in item_ids:
                occupied = {int(row["slot_index"]) for row in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL FOR UPDATE", (dst,)).fetchall()}
                free_slot = next((candidate for candidate in range(28) if candidate not in occupied), None)
                if free_slot is None:
                    raise HTTPException(409, "A participant inventory is full; trade cannot commit")
                moved = conn.execute("UPDATE inventory_items SET character_id=%s,slot_index=%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s RETURNING item_instance_id", (dst, free_slot, src, item_id)).fetchone()
                if not moved:
                    raise HTTPException(409, "Trade item changed before commit")
        for row in transfer_items[str(a)]: _progress_active_quest_objectives(conn, b, "collect", row["item_definition_id"], row["quantity"])
        for row in transfer_items[str(b)]: _progress_active_quest_objectives(conn, a, "collect", row["item_definition_id"], row["quantity"])
        for cid, amount, suffix in ((a, gold_a, "a"), (b, gold_b, "b")):
            if amount:
                conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'player_trade',%s)", (uuid.uuid4(), WORLD_ID, cid, -amount, hashlib.sha256(f"{body.trade_id}:{body.idempotency_key}:{suffix}:out".encode()).hexdigest()))
        if gold_b:
            conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'player_trade',%s)", (uuid.uuid4(), WORLD_ID, a, gold_b, hashlib.sha256(f"{body.trade_id}:{body.idempotency_key}:b:in".encode()).hexdigest()))
        if gold_a:
            conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,'player_trade',%s)", (uuid.uuid4(), WORLD_ID, b, gold_a, hashlib.sha256(f"{body.trade_id}:{body.idempotency_key}:a:in".encode()).hexdigest()))
        payload = {"trade_id": str(body.trade_id), "status": "committed"}
        _record_transaction(conn, a, "player_trade", body.idempotency_key, payload)
        conn.execute("UPDATE player_trade_sessions SET status='committed',revision=revision+1 WHERE trade_id=%s", (body.trade_id,))
    return {"ok": True, "replayed": False, "result": payload}


@app.put("/v1/internal/territories/bulk")
def internal_territory_control_bulk(body: TerritoryControlBatch, _=Depends(service_auth)):
    revisions = []
    with db() as conn:
        for line in body.territories:
            current = conn.execute("SELECT revision,organization_id FROM territory_control WHERE world_id=%s AND territory_id=%s FOR UPDATE", (WORLD_ID, line.territory_id)).fetchone()
            if current and int(current["revision"]) != line.revision:
                raise HTTPException(409, f"Territory revision conflict: {line.territory_id}")
            raw_owner = line.control_state.get("organization_id") if "organization_id" in line.control_state else (current["organization_id"] if current else None)
            try:
                owner_id = uuid.UUID(str(raw_owner)) if raw_owner else None
            except ValueError:
                raise HTTPException(422, "Territory organization_id must be a valid organization UUID")
            if owner_id and not conn.execute("SELECT 1 FROM player_organizations WHERE organization_id=%s AND world_id=%s", (owner_id, WORLD_ID)).fetchone():
                raise HTTPException(404, "Territory owner organization does not exist in Elyndor")
            if current:
                if current["organization_id"] != owner_id:
                    conn.execute("DELETE FROM territory_tax_policy WHERE world_id=%s AND territory_id=%s", (WORLD_ID, line.territory_id))
                conn.execute("UPDATE territory_control SET organization_id=%s,control_state=%s,revision=revision+1,updated_at=now() WHERE world_id=%s AND territory_id=%s", (owner_id, Jsonb(line.control_state), WORLD_ID, line.territory_id))
                revision = line.revision + 1
            else:
                if line.revision != 0: raise HTTPException(409, "New territory records must start at revision zero")
                conn.execute("INSERT INTO territory_control(world_id,territory_id,organization_id,control_state,revision) VALUES (%s,%s,%s,%s,0)", (WORLD_ID, line.territory_id, owner_id, Jsonb(line.control_state)))
                revision = 0
            revisions.append({"territory_id": line.territory_id, "revision": revision})
    return {"ok": True, "world_id": WORLD_ID, "revisions": revisions}


@app.get("/v1/internal/territories")
def internal_territory_control_load(_=Depends(service_auth)):
    with db() as conn:
        rows = conn.execute("SELECT territory_id,organization_id,control_state,revision,updated_at FROM territory_control WHERE world_id=%s ORDER BY territory_id", (WORLD_ID,)).fetchall()
    return {"ok": True, "world_id": WORLD_ID, "territories": [{**row, "organization_id": str(row["organization_id"]) if row["organization_id"] else None} for row in rows]}


@app.post("/v1/internal/territory/economy")
def internal_territory_economy(body: TerritoryEconomyEntry, _=Depends(service_auth)):
    if body.amount == 0: raise HTTPException(422, "Territory economy entry cannot be zero")
    with db() as conn:
        if conn.execute("SELECT 1 FROM territory_control WHERE world_id=%s AND territory_id=%s FOR UPDATE", (WORLD_ID, body.territory_id)).fetchone() is None:
            raise HTTPException(404, "Territory does not exist in Elyndor")
        conn.execute("INSERT INTO territory_economy_ledger(entry_id,world_id,territory_id,organization_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(idempotency_key) DO NOTHING", (uuid.uuid4(), WORLD_ID, body.territory_id, body.organization_id, body.amount, body.reason, body.idempotency_key))
    return {"ok": True, "world_id": WORLD_ID, "territory_id": body.territory_id}


@app.put("/v1/internal/organizations/provision")
def internal_provision_organization(body: InternalOrganizationProvision, _=Depends(service_auth)):
    with db() as conn:
        leader = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.leader_character_id, WORLD_ID)).fetchone()
        if not leader:
            raise HTTPException(404, "Organization leader character not found in Elyndor")
        existing_sect = conn.execute("SELECT organization_id FROM player_organizations WHERE world_id=%s AND leader_character_id=%s AND organization_type='sect'", (WORLD_ID, body.leader_character_id)).fetchone()
        if existing_sect and str(existing_sect["organization_id"]) != str(body.organization_id):
            raise HTTPException(409, "This character already leads a registered player sect")
        row = conn.execute("""INSERT INTO player_organizations(organization_id,world_id,organization_type,name,leader_character_id)
            VALUES (%s,%s,%s,%s,%s) ON CONFLICT(organization_id) DO UPDATE SET name=EXCLUDED.name
            WHERE player_organizations.leader_character_id=EXCLUDED.leader_character_id
            RETURNING organization_id""", (body.organization_id, WORLD_ID, body.organization_type, body.name.strip(), body.leader_character_id)).fetchone()
        if not row:
            raise HTTPException(409, "Organization identity is already owned by another leader")
        conn.execute("INSERT INTO organization_members(organization_id,character_id,rank_id) VALUES (%s,%s,'leader') ON CONFLICT(organization_id,character_id) DO UPDATE SET rank_id='leader'", (body.organization_id, body.leader_character_id))
    return {"ok": True, "organization_id": str(body.organization_id), "name": body.name.strip(), "organization_type": body.organization_type}


@app.put("/v1/internal/territories/tax-policy")
def internal_set_territory_tax_policy(body: TerritoryTaxPolicyRequest, _=Depends(service_auth)):
    with db() as conn:
        territory = conn.execute("SELECT organization_id FROM territory_control WHERE world_id=%s AND territory_id=%s FOR UPDATE", (WORLD_ID, body.territory_id)).fetchone()
        if not territory:
            raise HTTPException(404, "Territory does not exist in Elyndor")
        if str(territory["organization_id"] or "") != str(body.organization_id):
            raise HTTPException(409, "Only the current territory owner can set its tax policy")
        leader = conn.execute("SELECT leader_character_id FROM player_organizations WHERE organization_id=%s AND world_id=%s", (body.organization_id, WORLD_ID)).fetchone()
        member = conn.execute("SELECT rank_id FROM organization_members WHERE organization_id=%s AND character_id=%s", (body.organization_id, body.actor_character_id)).fetchone()
        allowed_ranks = {"leader", "sect_leader", "elder", "steward", "administrator", "officer"}
        if not leader or (str(leader["leader_character_id"]) != str(body.actor_character_id) and (not member or str(member["rank_id"]).lower() not in allowed_ranks)):
            raise HTTPException(403, "Only the organization leader or an authorized treasury officer may change territory taxes")
        row = conn.execute("""INSERT INTO territory_tax_policy(world_id,territory_id,organization_id,tax_basis_points,enabled)
            VALUES (%s,%s,%s,%s,%s) ON CONFLICT(world_id,territory_id) DO UPDATE SET
            organization_id=EXCLUDED.organization_id,tax_basis_points=EXCLUDED.tax_basis_points,enabled=EXCLUDED.enabled,
            revision=territory_tax_policy.revision+1,updated_at=now()
            RETURNING revision""", (WORLD_ID, body.territory_id, body.organization_id, body.tax_basis_points, body.enabled)).fetchone()
    return {"ok": True, "territory_id": body.territory_id, "tax_basis_points": body.tax_basis_points, "enabled": body.enabled, "revision": row["revision"]}


@app.post("/v1/internal/territories/assess-tax")
def internal_assess_territory_tax(body: TerritoryTaxAssessment, _=Depends(service_auth)):
    with db() as conn:
        prior_tx = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior_tx:
            return {"ok": True, "replayed": True, **(prior_tx["payload"] if isinstance(prior_tx["payload"], dict) else {})}
        territory = conn.execute("""SELECT tc.organization_id, tp.tax_basis_points, tp.enabled
            FROM territory_control tc LEFT JOIN territory_tax_policy tp
            ON tp.world_id=tc.world_id AND tp.territory_id=tc.territory_id
            WHERE tc.world_id=%s AND tc.territory_id=%s FOR UPDATE OF tc""", (WORLD_ID, body.territory_id)).fetchone()
        if not territory:
            raise HTTPException(404, "Territory does not exist in Elyndor")
        owner = territory["organization_id"]
        rate = int(territory["tax_basis_points"] or 0) if territory["enabled"] is not False else 0
        tax = (body.gross_amount * rate) // 10000
        if tax > 0 and owner:
            conn.execute("""INSERT INTO organization_treasury_ledger(entry_id,world_id,organization_id,territory_id,amount,reason,source_ref,idempotency_key)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(idempotency_key) DO NOTHING""",
                (uuid.uuid4(), WORLD_ID, owner, body.territory_id, tax, "territory_tax:" + body.reason, body.source_ref, body.idempotency_key))
        else:
            tax = 0
        payload = {"world_id": WORLD_ID, "territory_id": body.territory_id, "gross_amount": body.gross_amount, "tax_amount": tax, "tax_basis_points": rate, "organization_id": str(owner) if owner else None}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,NULL,'territory_tax_assessment',%s,'committed',%s)", (uuid.uuid4(), WORLD_ID, body.idempotency_key, Jsonb(payload)))
    return {"ok": True, **payload}


@app.post("/v1/internal/regional-economy/events")
def internal_regional_economy_event(body: RegionalEconomyEvent, _=Depends(service_auth)):
    with db() as conn:
        owner = None
        if body.territory_id:
            row = conn.execute("SELECT organization_id FROM territory_control WHERE world_id=%s AND territory_id=%s", (WORLD_ID, body.territory_id)).fetchone()
            if not row:
                raise HTTPException(404, "Territory does not exist in Elyndor")
            owner = row["organization_id"]
        conn.execute("""INSERT INTO regional_economy_ledger(entry_id,world_id,region_id,territory_id,organization_id,commodity_id,quantity_delta,unit_value,event_type,idempotency_key)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(idempotency_key) DO NOTHING""",
            (uuid.uuid4(), WORLD_ID, body.region_id, body.territory_id, owner, body.commodity_id, body.quantity_delta, body.unit_value, body.event_type, body.idempotency_key))
    return {"ok": True, "world_id": WORLD_ID, "region_id": body.region_id, "commodity_id": body.commodity_id}


@app.get("/v1/internal/organizations/{organization_id}/treasury")
def internal_organization_treasury(organization_id: uuid.UUID, actor_character_id: uuid.UUID, _=Depends(service_auth)):
    with db() as conn:
        org = conn.execute("SELECT organization_id,name,organization_type,leader_character_id FROM player_organizations WHERE organization_id=%s AND world_id=%s", (organization_id, WORLD_ID)).fetchone()
        if not org:
            raise HTTPException(404, "Organization not found in Elyndor")
        member = conn.execute("SELECT 1 FROM organization_members WHERE organization_id=%s AND character_id=%s", (organization_id, actor_character_id)).fetchone()
        if str(org["leader_character_id"]) != str(actor_character_id) and not member:
            raise HTTPException(403, "Character is not a member of this organization")
        balance = conn.execute("SELECT COALESCE(sum(amount),0) AS balance FROM organization_treasury_ledger WHERE world_id=%s AND organization_id=%s", (WORLD_ID, organization_id)).fetchone()["balance"]
        ledger = conn.execute("SELECT territory_id,amount,reason,source_ref,created_at FROM organization_treasury_ledger WHERE world_id=%s AND organization_id=%s ORDER BY created_at DESC LIMIT 50", (WORLD_ID, organization_id)).fetchall()
    return {"ok": True, "organization": {"organization_id": str(org["organization_id"]), "name": org["name"], "organization_type": org["organization_type"]}, "balance": int(balance), "ledger": ledger}


@app.get("/v1/internal/regional-economy/{region_id}")
def internal_regional_economy_snapshot(region_id: str, _=Depends(service_auth)):
    with db() as conn:
        rows = conn.execute("""SELECT commodity_id,sum(quantity_delta) AS net_quantity,
            sum(quantity_delta * unit_value) AS estimated_value, max(created_at) AS last_activity
            FROM regional_economy_ledger WHERE world_id=%s AND region_id=%s
            GROUP BY commodity_id ORDER BY commodity_id""", (WORLD_ID, region_id)).fetchall()
        activity = conn.execute("SELECT event_type,commodity_id,quantity_delta,unit_value,created_at FROM regional_economy_ledger WHERE world_id=%s AND region_id=%s ORDER BY created_at DESC LIMIT 40", (WORLD_ID, region_id)).fetchall()
    return {"ok": True, "world_id": WORLD_ID, "region_id": region_id, "commodities": rows, "activity": activity}


@app.post("/v1/internal/npc/interactions")
def internal_npc_interaction(body: NpcInteractionEvent, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s", (body.character_id, WORLD_ID)).fetchone()
        if not owned:
            raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": True, "replayed": True, "result": prior["payload"]}
        payload = {"character_id": str(body.character_id), "npc_id": str(body.npc_id), "interaction_type": body.interaction_type, "payload": body.payload}
        conn.execute("INSERT INTO world_events(event_id,world_id,event_type,region_id,payload) VALUES (%s,%s,%s,%s,%s)", (uuid.uuid4(), WORLD_ID, "npc_" + body.interaction_type, body.region_id, Jsonb(payload)))
        _record_transaction(conn, body.character_id, "npc_interaction", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.put("/v1/internal/world/populations/bulk")
def internal_population_bulk_upsert(body: PopulationBatch, _=Depends(service_auth)):
    revisions = []
    with db() as conn:
        for line in body.populations:
            current = conn.execute("SELECT revision FROM regional_monster_populations WHERE world_id=%s AND region_id=%s AND species_id=%s FOR UPDATE", (WORLD_ID, line.region_id, line.species_id)).fetchone()
            if current and int(current["revision"]) != line.revision:
                raise HTTPException(409, f"Population revision conflict: {line.region_id}/{line.species_id}")
            if current:
                conn.execute("UPDATE regional_monster_populations SET population_state=%s,revision=revision+1,updated_at=now() WHERE world_id=%s AND region_id=%s AND species_id=%s", (Jsonb(line.population_state), WORLD_ID, line.region_id, line.species_id))
                revision = line.revision + 1
            else:
                if line.revision != 0: raise HTTPException(409, "New population records must start at revision zero")
                conn.execute("INSERT INTO regional_monster_populations(world_id,region_id,species_id,population_state,revision) VALUES (%s,%s,%s,%s,0)", (WORLD_ID, line.region_id, line.species_id, Jsonb(line.population_state)))
                revision = 0
            revisions.append({"region_id": line.region_id, "species_id": line.species_id, "revision": revision})
    return {"ok": True, "world_id": WORLD_ID, "revisions": revisions}


@app.put("/v1/internal/world/populations")
def internal_population_upsert(body: PopulationUpsert, _=Depends(service_auth)):
    with db() as conn:
        current = conn.execute("SELECT revision FROM regional_monster_populations WHERE world_id=%s AND region_id=%s AND species_id=%s FOR UPDATE", (WORLD_ID, body.region_id, body.species_id)).fetchone()
        if current and int(current["revision"]) != body.revision:
            raise HTTPException(409, "Monster population revision conflict")
        if current:
            conn.execute("UPDATE regional_monster_populations SET population_state=%s,revision=revision+1,updated_at=now() WHERE world_id=%s AND region_id=%s AND species_id=%s", (Jsonb(body.population_state), WORLD_ID, body.region_id, body.species_id))
            revision = body.revision + 1
        else:
            if body.revision != 0:
                raise HTTPException(409, "New population records must start at revision zero")
            conn.execute("INSERT INTO regional_monster_populations(world_id,region_id,species_id,population_state,revision) VALUES (%s,%s,%s,%s,0)", (WORLD_ID, body.region_id, body.species_id, Jsonb(body.population_state)))
            revision = 0
    return {"ok": True, "world_id": WORLD_ID, "revision": revision}


@app.put("/v1/internal/world/bosses/{boss_id}")
def internal_boss_upsert(boss_id: uuid.UUID, body: BossEncounterUpsert, _=Depends(service_auth)):
    if boss_id != body.boss_id:
        raise HTTPException(400, "Boss identifier mismatch")
    with db() as conn:
        current = conn.execute("SELECT revision FROM world_boss_encounters WHERE boss_id=%s AND world_id=%s FOR UPDATE", (boss_id, WORLD_ID)).fetchone()
        if current and int(current["revision"]) != body.revision:
            raise HTTPException(409, "Boss encounter revision conflict")
        if current:
            conn.execute("UPDATE world_boss_encounters SET encounter_state=%s,revision=revision+1,last_defeated_at=CASE WHEN %s='defeated' THEN now() ELSE last_defeated_at END,updated_at=now() WHERE boss_id=%s", (Jsonb(body.encounter_state), str(body.encounter_state.get("status", "")), boss_id))
            revision = body.revision + 1
        else:
            if body.revision != 0:
                raise HTTPException(409, "New boss encounters must start at revision zero")
            conn.execute("INSERT INTO world_boss_encounters(boss_id,world_id,region_id,boss_definition_id,encounter_state,revision) VALUES (%s,%s,%s,%s,%s,0)", (boss_id, WORLD_ID, body.region_id, body.boss_definition_id, Jsonb(body.encounter_state)))
            revision = 0
    return {"ok": True, "world_id": WORLD_ID, "revision": revision}


@app.post("/v1/internal/quests/state")
def internal_quest_state(body: InternalQuestState, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id, WORLD_ID)).fetchone()
        if not owned:
            raise HTTPException(404, "Character not found in Elyndor")
        prior = conn.execute("SELECT payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior:
            return {"ok": True, "replayed": True, "result": prior["payload"]}
        conn.execute("INSERT INTO character_quests(character_id,quest_id,quest_state,revision) VALUES (%s,%s,%s,0) ON CONFLICT(character_id,quest_id) DO UPDATE SET quest_state=EXCLUDED.quest_state,revision=character_quests.revision+1,updated_at=now()", (body.character_id, body.quest_id, Jsonb(body.quest_state)))
        payload = {"quest_id": body.quest_id, "quest_state": body.quest_state}
        _record_transaction(conn, body.character_id, "quest_state", body.idempotency_key, payload)
    return {"ok": True, "replayed": False, "result": payload}


@app.put("/v1/internal/world/entities/{entity_id}")
def internal_upsert_world_entity(entity_id: uuid.UUID, body: WorldEntityUpsert, _=Depends(service_auth)):
    if entity_id != body.entity_id:
        raise HTTPException(400, "Entity identifier mismatch")
    with db() as conn:
        # Serialize duplicate retries and concurrent writes to the same entity before checking revisions.
        if body.idempotency_key:
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("world-entity-idem:" + body.idempotency_key,))
        conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("world-entity:" + str(entity_id),))
        if body.idempotency_key:
            replay = conn.execute("SELECT entity_id, resulting_revision FROM world_entity_mutations WHERE world_id=%s AND idempotency_key=%s", (WORLD_ID, body.idempotency_key)).fetchone()
            if replay:
                if str(replay["entity_id"]) != str(entity_id):
                    raise HTTPException(409, "Idempotency key was already used for another entity")
                return {"ok": True, "world_id": WORLD_ID, "revision": int(replay["resulting_revision"]), "replayed": True}
        current = conn.execute("SELECT revision FROM world_entities WHERE entity_id=%s AND world_id=%s FOR UPDATE", (entity_id, WORLD_ID)).fetchone()
        if current and int(current["revision"]) != body.revision:
            raise HTTPException(409, "World entity revision conflict")
        if current:
            conn.execute("UPDATE world_entities SET entity_kind=%s,region_id=%s,entity_state=%s,revision=revision+1,updated_at=now() WHERE entity_id=%s", (body.entity_kind, body.region_id, Jsonb(body.entity_state), entity_id))
            next_revision = body.revision + 1
        else:
            if body.revision != 0:
                raise HTTPException(409, "New world entities must start at revision zero")
            conn.execute("INSERT INTO world_entities(entity_id,world_id,entity_kind,region_id,entity_state,revision) VALUES (%s,%s,%s,%s,%s,0)", (entity_id, WORLD_ID, body.entity_kind, body.region_id, Jsonb(body.entity_state)))
            next_revision = 0
        conn.execute("INSERT INTO world_events(event_id,world_id,event_type,region_id,payload) VALUES (%s,%s,'entity_state_saved',%s,%s)", (uuid.uuid4(), WORLD_ID, body.region_id, Jsonb({"entity_id": str(entity_id), "entity_kind": body.entity_kind, "revision": next_revision})))
        if body.idempotency_key:
            conn.execute("INSERT INTO world_entity_mutations(world_id,idempotency_key,entity_id,resulting_revision) VALUES (%s,%s,%s,%s)", (WORLD_ID, body.idempotency_key, entity_id, next_revision))
    return {"ok": True, "world_id": WORLD_ID, "revision": next_revision, "replayed": False}


@app.get("/v1/internal/world/entities")
def internal_list_world_entities(entity_kind: str | None = None, region_id: str | None = None, _=Depends(service_auth)):
    clauses = ["world_id=%s"]
    params: list[Any] = [WORLD_ID]
    if entity_kind:
        clauses.append("entity_kind=%s")
        params.append(entity_kind)
    if region_id:
        clauses.append("region_id=%s")
        params.append(region_id)
    with db() as conn:
        rows = conn.execute("SELECT entity_id,entity_kind,region_id,entity_state,revision,updated_at FROM world_entities WHERE " + " AND ".join(clauses) + " ORDER BY entity_kind,region_id,entity_id", tuple(params)).fetchall()
    return {"world_id": WORLD_ID, "entities": [{**row, "entity_id": str(row["entity_id"])} for row in rows]}


@app.get("/v1/internal/world/regions/{region_id}/entities")
def internal_get_region_entities(region_id: str, _=Depends(service_auth)):
    with db() as conn:
        rows = conn.execute("SELECT entity_id,entity_kind,region_id,entity_state,revision,updated_at FROM world_entities WHERE world_id=%s AND region_id=%s ORDER BY entity_kind,entity_id", (WORLD_ID, region_id)).fetchall()
    return {"world_id": WORLD_ID, "region_id": region_id, "entities": [{**row, "entity_id": str(row["entity_id"])} for row in rows]}


@app.get("/internal/metrics")
def internal_metrics(_=Depends(service_auth)):
    with db() as conn:
        counts = conn.execute("SELECT (SELECT count(*) FROM accounts WHERE status='active') AS accounts, (SELECT count(*) FROM characters) AS characters, (SELECT count(*) FROM world_entities) AS world_entities, (SELECT count(*) FROM account_sessions WHERE revoked_at IS NULL AND expires_at>now()) AS active_sessions").fetchone()
        lease = conn.execute("SELECT active_server_instance_id,lease_expires_at FROM world_registry WHERE world_id=%s", (WORLD_ID,)).fetchone()
    return {"world_id": WORLD_ID, "counts": counts, "lease": lease, "database": "connected"}


@app.post("/v1/world/lease/acquire")
def lease_acquire(body: LeaseRequest, _=Depends(service_auth)):
    if body.world_id != WORLD_ID: raise HTTPException(400,"Unknown world identity")
    lease=uuid.uuid4()
    with db() as conn:
        row=conn.execute("SELECT active_server_instance_id,lease_id,lease_expires_at FROM world_registry WHERE world_id=%s FOR UPDATE",(WORLD_ID,)).fetchone()
        if row["lease_expires_at"] and row["lease_expires_at"] > datetime.now(timezone.utc):
            raise HTTPException(409,"The Elyndor world already has an active authoritative server lease")
        conn.execute("UPDATE world_registry SET active_server_instance_id=%s,lease_id=%s,lease_expires_at=now()+(%s * interval '1 second'),updated_at=now() WHERE world_id=%s",(body.server_instance_id,lease,body.lease_duration_seconds,WORLD_ID))
    return {"world_id":WORLD_ID,"server_instance_id":body.server_instance_id,"lease_id":str(lease)}


@app.post("/v1/world/lease/renew")
def lease_renew(body: LeaseRequest, _=Depends(service_auth)):
    if body.world_id != WORLD_ID or not body.lease_id: raise HTTPException(400,"Invalid lease renewal")
    with db() as conn:
        row=conn.execute("UPDATE world_registry SET lease_expires_at=now()+(%s * interval '1 second'),updated_at=now() WHERE world_id=%s AND active_server_instance_id=%s AND lease_id=%s AND lease_expires_at>now() RETURNING world_id",(body.lease_duration_seconds,WORLD_ID,body.server_instance_id,body.lease_id)).fetchone()
    if not row: raise HTTPException(409,"Lease is expired, stale or owned by another server")
    return {"world_id":WORLD_ID,"server_instance_id":body.server_instance_id,"lease_id":str(body.lease_id)}


@app.post("/v1/world/lease/release")
def lease_release(body: LeaseRequest, _=Depends(service_auth)):
    if body.world_id != WORLD_ID or not body.lease_id: raise HTTPException(400,"Invalid lease release")
    with db() as conn:
        row=conn.execute("UPDATE world_registry SET active_server_instance_id=NULL,lease_id=NULL,lease_expires_at=NULL,updated_at=now() WHERE world_id=%s AND active_server_instance_id=%s AND lease_id=%s RETURNING world_id",(WORLD_ID,body.server_instance_id,body.lease_id)).fetchone()
    return {"ok":bool(row)}


@app.get("/v1/internal/characters/{character_id}")
def internal_get_character(character_id: uuid.UUID, _=Depends(service_auth)):
    with db() as conn:
        row=conn.execute("SELECT character_id,display_name,character_state,revision FROM characters WHERE character_id=%s AND world_id=%s",(character_id,WORLD_ID)).fetchone()
    if not row: raise HTTPException(404,"Character not found")
    return {**row,"character_id":str(row["character_id"])}


@app.put("/v1/internal/characters/{character_id}")
def internal_save_character(character_id: uuid.UUID, body: InternalCharacterSave, _=Depends(service_auth)):
    if character_id != body.character_id: raise HTTPException(400,"Character ID mismatch")
    with db() as conn:
        row=conn.execute("UPDATE characters SET character_state=COALESCE(character_state,'{}'::jsonb) || %s,revision=revision+1,updated_at=now() WHERE character_id=%s AND world_id=%s AND revision=%s RETURNING revision",(Jsonb(body.state),character_id,WORLD_ID,body.revision)).fetchone()
    if not row: raise HTTPException(409,"Revision conflict or unknown character")
    return {"ok":True,"revision":row["revision"]}

class InternalItemGrant(BaseModel):
    character_id: uuid.UUID
    item_definition_id: str = Field(min_length=1, max_length=96, pattern=r"^[A-Za-z0-9_.:-]+$")
    quantity: int = Field(ge=1, le=9999)
    item_state: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str = Field(min_length=16, max_length=128)

class InternalCurrencyChange(BaseModel):
    character_id: uuid.UUID
    amount: int = Field(ge=-1000000000, le=1000000000)
    reason: str = Field(min_length=2, max_length=96)
    idempotency_key: str = Field(min_length=16, max_length=128)


@app.post("/v1/internal/inventory/grant")
def internal_inventory_grant(body: InternalItemGrant, _=Depends(service_auth)):
    item_id = uuid.uuid4()
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE", (body.character_id,WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404,"Character not found in Elyndor")
        prior = conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s", (body.idempotency_key,)).fetchone()
        if prior: return {"ok":prior["status"]=="committed","replayed":True,"result":prior["payload"]}
        used_slots = {int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL", (body.character_id,)).fetchall()}
        slot = next((candidate for candidate in range(28) if candidate not in used_slots), None)
        if slot is None: raise HTTPException(409,"Inventory is full")
        conn.execute("INSERT INTO inventory_items(item_instance_id,character_id,item_definition_id,quantity,slot_index,item_state) VALUES (%s,%s,%s,%s,%s,%s)",
                     (item_id,body.character_id,body.item_definition_id,body.quantity,slot,Jsonb(body.item_state)))
        payload={"item_instance_id":str(item_id),"item_definition_id":body.item_definition_id,"quantity":body.quantity,"slot_index":slot}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'loot_grant',%s,'committed',%s)",
                     (uuid.uuid4(),WORLD_ID,body.character_id,body.idempotency_key,Jsonb(payload)))
    return {"ok":True,"replayed":False,"result":payload}


@app.post("/v1/internal/currency/change")
def internal_currency_change(body: InternalCurrencyChange, _=Depends(service_auth)):
    if body.amount == 0: raise HTTPException(422,"Currency change cannot be zero")
    with db() as conn:
        owned=conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE",(body.character_id,WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404,"Character not found in Elyndor")
        prior=conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s",(body.idempotency_key,)).fetchone()
        if prior: return {"ok":prior["status"]=="committed","replayed":True,"result":prior["payload"]}
        balance_row=conn.execute("SELECT COALESCE(SUM(amount),0) AS balance FROM currency_ledger WHERE character_id=%s",(body.character_id,)).fetchone()
        balance=int(balance_row["balance"])
        if balance + body.amount < 0: raise HTTPException(409,"Insufficient currency")
        conn.execute("INSERT INTO currency_ledger(ledger_id,world_id,character_id,amount,reason,idempotency_key) VALUES (%s,%s,%s,%s,%s,%s)",
                     (uuid.uuid4(),WORLD_ID,body.character_id,body.amount,body.reason,body.idempotency_key))
        payload={"previous_balance":balance,"balance":balance+body.amount,"change":body.amount}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'currency_change',%s,'committed',%s)",
                     (uuid.uuid4(),WORLD_ID,body.character_id,body.idempotency_key,Jsonb(payload)))
    return {"ok":True,"replayed":False,"result":payload}

@app.post("/v1/characters/{character_id}/join-ticket")
def create_join_ticket(character_id: uuid.UUID, account=Depends(current_account)):
    ticket = secrets.token_urlsafe(32)
    with db() as conn:
        owned=conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND account_id=%s AND world_id=%s",(character_id,account["account_id"],WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404,"Character not found")
        conn.execute("INSERT INTO character_join_tickets(token_hash,character_id,account_id,expires_at) VALUES (%s,%s,%s,now()+interval '60 seconds')",(token_hash(ticket),character_id,account["account_id"]))
    return {"join_ticket":ticket,"expires_in":60,"character_id":str(character_id)}


class JoinTicketConsume(BaseModel):
    join_ticket: str = Field(min_length=32, max_length=128)


@app.post("/v1/internal/characters/consume-join-ticket")
def consume_join_ticket(body: JoinTicketConsume, _=Depends(service_auth)):
    with db() as conn:
        row=conn.execute("""SELECT t.character_id,t.account_id,c.display_name,c.character_state,c.revision
            FROM character_join_tickets t JOIN characters c ON c.character_id=t.character_id
            WHERE t.token_hash=%s AND t.consumed_at IS NULL AND t.expires_at>now() AND c.world_id=%s
            FOR UPDATE OF t""",(token_hash(body.join_ticket),WORLD_ID)).fetchone()
        if not row: raise HTTPException(401,"Join ticket is invalid, expired or already used")
        conn.execute("UPDATE character_join_tickets SET consumed_at=now() WHERE token_hash=%s",(token_hash(body.join_ticket),))
    return {"character_id":str(row["character_id"]),"display_name":row["display_name"],"character_state":row["character_state"],"revision":row["revision"]}

@app.get("/v1/internal/characters/{character_id}/quests")
def internal_get_character_quests(character_id: uuid.UUID, _=Depends(service_auth)):
    with db() as conn:
        owned = conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s", (character_id, WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404, "Character not found in Elyndor")
        rows = conn.execute("SELECT quest_id,quest_state,revision,updated_at FROM character_quests WHERE character_id=%s ORDER BY quest_id", (character_id,)).fetchall()
        progress_rows = conn.execute("SELECT quest_id,objective_index,progress FROM character_quest_objectives WHERE character_id=%s ORDER BY quest_id,objective_index", (character_id,)).fetchall()
    progress = {}
    for item in progress_rows: progress.setdefault(str(item["quest_id"]), {})[int(item["objective_index"])] = int(item["progress"])
    for row in rows: row["objective_progress"] = progress.get(str(row["quest_id"]), {})
    return {"world_id": WORLD_ID, "quests": rows}


@app.get("/v1/internal/characters/{character_id}/inventory")
def internal_get_inventory(character_id: uuid.UUID, _=Depends(service_auth)):
    with db() as conn:
        items=conn.execute("SELECT item_instance_id,item_definition_id,quantity,slot_index,item_state,revision FROM inventory_items WHERE character_id=%s ORDER BY slot_index",(character_id,)).fetchall()
        equipment=conn.execute("SELECT slot_id,item_instance_id FROM equipment_slots WHERE character_id=%s",(character_id,)).fetchall()
        balance=conn.execute("SELECT COALESCE(SUM(amount),0) AS balance FROM currency_ledger WHERE character_id=%s",(character_id,)).fetchone()
    return {"items":[{**i,"item_instance_id":str(i["item_instance_id"])} for i in items],
            "equipment":[{**e,"item_instance_id":str(e["item_instance_id"]) if e["item_instance_id"] else None} for e in equipment],
            "gold":int(balance["balance"])}

class InternalEquipmentChange(BaseModel):
    character_id: uuid.UUID
    slot_id: str = Field(pattern=r"^(weapon|armor)$")
    item_instance_id: uuid.UUID | None = None
    idempotency_key: str = Field(min_length=16, max_length=128)


@app.post("/v1/internal/equipment/change")
def internal_equipment_change(body: InternalEquipmentChange, _=Depends(service_auth)):
    with db() as conn:
        owned=conn.execute("SELECT 1 FROM characters WHERE character_id=%s AND world_id=%s FOR UPDATE",(body.character_id,WORLD_ID)).fetchone()
        if not owned: raise HTTPException(404,"Character not found in Elyndor")
        prior=conn.execute("SELECT status,payload FROM gameplay_transactions WHERE idempotency_key=%s",(body.idempotency_key,)).fetchone()
        if prior: return {"ok":prior["status"]=="committed","replayed":True,"result":prior["payload"]}
        current=conn.execute("SELECT item_instance_id FROM equipment_slots WHERE character_id=%s AND slot_id=%s FOR UPDATE",(body.character_id,body.slot_id)).fetchone()
        old_id=current["item_instance_id"] if current else None
        new_item_slot=None
        if body.item_instance_id:
            item=conn.execute("SELECT item_instance_id,slot_index FROM inventory_items WHERE character_id=%s AND item_instance_id=%s FOR UPDATE",(body.character_id,body.item_instance_id)).fetchone()
            if not item: raise HTTPException(404,"Item not owned")
            new_item_slot=item["slot_index"]
            elsewhere=conn.execute("SELECT 1 FROM equipment_slots WHERE character_id=%s AND item_instance_id=%s AND slot_id<>%s",(body.character_id,body.item_instance_id,body.slot_id)).fetchone()
            if elsewhere: raise HTTPException(409,"Item already equipped in another slot")
        used={int(r["slot_index"]) for r in conn.execute("SELECT slot_index FROM inventory_items WHERE character_id=%s AND slot_index IS NOT NULL",(body.character_id,)).fetchall()}
        free_slot=int(new_item_slot) if new_item_slot is not None else next((i for i in range(28) if i not in used),None)
        if old_id and old_id != body.item_instance_id:
            if free_slot is None: raise HTTPException(409,"No free inventory slot for previous equipment")
            conn.execute("UPDATE inventory_items SET slot_index=%s,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s",(free_slot,body.character_id,old_id))
        if body.item_instance_id:
            conn.execute("UPDATE inventory_items SET slot_index=NULL,revision=revision+1 WHERE character_id=%s AND item_instance_id=%s",(body.character_id,body.item_instance_id))
        conn.execute("INSERT INTO equipment_slots(character_id,slot_id,item_instance_id) VALUES (%s,%s,%s) ON CONFLICT(character_id,slot_id) DO UPDATE SET item_instance_id=EXCLUDED.item_instance_id",(body.character_id,body.slot_id,body.item_instance_id))
        payload={"slot_id":body.slot_id,"item_instance_id":str(body.item_instance_id) if body.item_instance_id else None}
        conn.execute("INSERT INTO gameplay_transactions(transaction_id,world_id,actor_character_id,transaction_type,idempotency_key,status,payload) VALUES (%s,%s,%s,'equipment_change',%s,'committed',%s)",(uuid.uuid4(),WORLD_ID,body.character_id,body.idempotency_key,Jsonb(payload)))
    return {"ok":True,"replayed":False,"result":payload}
