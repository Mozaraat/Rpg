# Elyndor database operations

## Scope

The PostgreSQL database stores the one authoritative universe identified by `eternal-realms-one-world`. Backups are copies of the same world database, not separate playable worlds. Never restore a backup into a second live production world and accept players there.

## Automated backups

The Compose `backup` service performs an initial PostgreSQL custom-format dump, writes a SHA-256 checksum, then repeats every 24 hours. Files are stored in the named `er_postgres_backups` volume. Retention defaults to 14 days and is configurable with `ER_BACKUP_RETENTION_DAYS`.

A local Docker volume is not an adequate disaster-recovery strategy by itself. Production must copy encrypted backup files and WAL/PITR archives to a separate failure domain with restricted credentials and retention lock. Monitor backup age, dump exit status, checksum verification and free disk space.

## Restore drill

1. Stop world writes and fence the active world lease before restoring.
2. Restore into an isolated recovery database, never a second public world.
3. Verify `world_registry` contains exactly `eternal-realms-one-world` and inspect the latest characters, inventory, ledger, quests, entities and boss records.
4. Run application-level consistency checks and compare expected row counts/checksums.
5. Record the restore drill in the incident log. Only then promote the recovered database behind the single active world lease.

Example manual restore into a disposable database:

```sh
docker compose -f backend/deploy/docker-compose.yml exec -T postgres createdb -U er_service er_restore_test
cat backup.dump | docker compose -f backend/deploy/docker-compose.yml exec -T postgres pg_restore -U er_service -d er_restore_test --no-owner --no-privileges
```

## Monitoring

`GET /health` reports database connectivity and the fixed world ID. `GET /internal/metrics` requires the service bearer token and returns active account/session counts, character/world-entity counts and the current world lease. Production monitoring should additionally collect PostgreSQL connection saturation, transaction latency, lock waits, deadlocks, disk/backup age, lease-renewal failures, request error rates and per-region simulation tick duration.

## Load testing gates

Before a public launch, test with multiple real Godot 4.7 clients and representative world activity. Include login bursts, character selection, movement replication, combat, simultaneous inventory/crafting, merchant stock contention, reconnects, server restarts and boss/world-state saves. Verify idempotency under retries, no negative balances, no duplicate item instances, no lost committed transactions and no second active world lease. Record p50/p95/p99 latency, tick time, packet loss, CPU, memory, DB pool use and recovery time. The current build has not passed these live tests.

## Migration notes

`002_persistent_world_operations.sql` is mounted for fresh Docker database initialization. Existing installations must apply it explicitly with `psql` before enabling the new NPC, merchant, monster-population and boss endpoints. The init scripts in `/docker-entrypoint-initdb.d` do not rerun automatically against an already initialized named volume.
