-- Idempotency records for retry-safe shared world entity writes.
BEGIN;
CREATE TABLE IF NOT EXISTS world_entity_mutations (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    idempotency_key TEXT NOT NULL CHECK (length(idempotency_key) BETWEEN 16 AND 128),
    entity_id UUID NOT NULL,
    resulting_revision BIGINT NOT NULL CHECK (resulting_revision >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (world_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS world_entity_mutations_created_idx
    ON world_entity_mutations(created_at DESC);
COMMIT;
