-- Persistent shared-world operations for the single Elyndor universe.
BEGIN;

CREATE TABLE IF NOT EXISTS npc_world_state (
    npc_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    region_id TEXT NOT NULL,
    npc_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS npc_world_region_idx ON npc_world_state(world_id, region_id);

CREATE TABLE IF NOT EXISTS merchant_stock (
    merchant_id UUID NOT NULL,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    item_definition_id TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity >= 0),
    unit_price BIGINT NOT NULL CHECK (unit_price >= 0),
    restock_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, merchant_id, item_definition_id)
);

CREATE TABLE IF NOT EXISTS player_trade_sessions (
    trade_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    initiator_character_id UUID NOT NULL REFERENCES characters(character_id),
    target_character_id UUID NOT NULL REFERENCES characters(character_id),
    trade_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    status TEXT NOT NULL CHECK (status IN ('offered','accepted','committed','cancelled','expired')),
    expires_at TIMESTAMPTZ NOT NULL,
    revision BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (initiator_character_id <> target_character_id)
);

CREATE TABLE IF NOT EXISTS regional_monster_populations (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    region_id TEXT NOT NULL,
    species_id TEXT NOT NULL,
    population_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, region_id, species_id)
);

CREATE TABLE IF NOT EXISTS world_boss_encounters (
    boss_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    region_id TEXT NOT NULL,
    boss_definition_id TEXT NOT NULL,
    encounter_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    last_defeated_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS world_boss_region_idx ON world_boss_encounters(world_id, region_id);

CREATE TABLE IF NOT EXISTS backup_catalog (
    backup_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    object_key TEXT NOT NULL UNIQUE,
    backup_kind TEXT NOT NULL CHECK (backup_kind IN ('full','wal','logical')),
    checksum_sha256 TEXT NOT NULL,
    byte_size BIGINT NOT NULL CHECK (byte_size >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_at TIMESTAMPTZ,
    restore_tested_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS world_service_heartbeats (
    service_id TEXT PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    service_role TEXT NOT NULL,
    instance_id TEXT NOT NULL,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    metrics JSONB NOT NULL DEFAULT '{}'::jsonb
);

COMMIT;
