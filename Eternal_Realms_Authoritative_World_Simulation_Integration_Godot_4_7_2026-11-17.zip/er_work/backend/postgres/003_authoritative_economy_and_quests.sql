-- Server-owned quest progress, merchant provisioning, player trade and territory economy.
BEGIN;

CREATE TABLE IF NOT EXISTS character_quest_objectives (
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    quest_id TEXT NOT NULL,
    objective_index INTEGER NOT NULL CHECK (objective_index >= 0),
    progress INTEGER NOT NULL DEFAULT 0 CHECK (progress >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(character_id, quest_id, objective_index)
);

CREATE TABLE IF NOT EXISTS quest_reward_claims (
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    quest_id TEXT NOT NULL,
    transaction_id UUID NOT NULL UNIQUE,
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(character_id, quest_id)
);

CREATE TABLE IF NOT EXISTS merchant_catalog (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    merchant_id UUID NOT NULL,
    merchant_name TEXT NOT NULL,
    region_id TEXT NOT NULL DEFAULT 'elyndor_heartlands',
    merchant_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    PRIMARY KEY(world_id, merchant_id),
    UNIQUE(world_id, merchant_name)
);

CREATE TABLE IF NOT EXISTS merchant_sales_ledger (
    sale_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    merchant_id UUID NOT NULL,
    seller_character_id UUID NOT NULL REFERENCES characters(character_id),
    item_definition_id TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price BIGINT NOT NULL CHECK (unit_price >= 0),
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS territory_economy_ledger (
    entry_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    territory_id TEXT NOT NULL,
    organization_id UUID REFERENCES player_organizations(organization_id),
    amount BIGINT NOT NULL CHECK (amount <> 0),
    reason TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS trade_sessions_world_status_idx ON player_trade_sessions(world_id,status,expires_at);
CREATE INDEX IF NOT EXISTS territory_economy_timeline_idx ON territory_economy_ledger(world_id,territory_id,created_at DESC);


-- Migrate bosses written by the previous world_entities persistence path.
INSERT INTO world_boss_encounters(boss_id,world_id,region_id,boss_definition_id,encounter_state,revision)
SELECT entity_id,world_id,region_id,COALESCE(entity_state->>'monster_id','legacy_boss'),entity_state,revision
FROM world_entities WHERE world_id='eternal-realms-one-world' AND entity_kind='world_boss'
ON CONFLICT(boss_id) DO NOTHING;

-- Stable merchant identities match the server's SHA-256 UUID derivation.
INSERT INTO merchant_catalog(world_id,merchant_id,merchant_name,region_id) VALUES
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','Mira','elyndor'),
('eternal-realms-one-world','d70afd72-4d9b-22ab-3249-4eedffa1eee5','Gorrim the Smith','elyndor'),
('eternal-realms-one-world','a2ef41e7-8c89-a7d4-3268-34c87d39b878','Archmage Lira','mirrorwater')
ON CONFLICT(world_id,merchant_id) DO NOTHING;
INSERT INTO merchant_stock(world_id,merchant_id,item_definition_id,quantity,unit_price) VALUES
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','healing_potion',5,14),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','fish_mackerel',8,6),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','leather_strip',4,9),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','wood_log',8,3),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','iron_ore',6,7),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','iron_ingot',3,22),
('eternal-realms-one-world','feb3f6a0-21d3-8c6c-e0eb-d4c5ec1df0bd','cloth_tunic',2,38),
('eternal-realms-one-world','d70afd72-4d9b-22ab-3249-4eedffa1eee5','iron_ore',8,7),
('eternal-realms-one-world','d70afd72-4d9b-22ab-3249-4eedffa1eee5','iron_ingot',5,22),
('eternal-realms-one-world','d70afd72-4d9b-22ab-3249-4eedffa1eee5','wood_log',4,3),
('eternal-realms-one-world','a2ef41e7-8c89-a7d4-3268-34c87d39b878','healing_potion',7,14),
('eternal-realms-one-world','a2ef41e7-8c89-a7d4-3268-34c87d39b878','mana_potion',4,28)
ON CONFLICT(world_id,merchant_id,item_definition_id) DO NOTHING;

COMMIT;
