-- Sect treasuries, territory tax policy and regional commodity flows.
-- All balances are derived from immutable, idempotent ledger entries.
BEGIN;

ALTER TABLE merchant_catalog ADD COLUMN IF NOT EXISTS territory_id TEXT;

CREATE TABLE IF NOT EXISTS organization_treasury_ledger (
    entry_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    organization_id UUID NOT NULL REFERENCES player_organizations(organization_id),
    territory_id TEXT,
    amount BIGINT NOT NULL CHECK (amount <> 0),
    reason TEXT NOT NULL,
    source_ref TEXT NOT NULL DEFAULT '',
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS org_treasury_timeline_idx
    ON organization_treasury_ledger(world_id, organization_id, created_at DESC);

CREATE TABLE IF NOT EXISTS territory_tax_policy (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    territory_id TEXT NOT NULL,
    organization_id UUID NOT NULL REFERENCES player_organizations(organization_id),
    tax_basis_points INTEGER NOT NULL DEFAULT 0 CHECK (tax_basis_points BETWEEN 0 AND 2500),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, territory_id)
);

CREATE TABLE IF NOT EXISTS regional_economy_ledger (
    entry_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    region_id TEXT NOT NULL,
    territory_id TEXT,
    organization_id UUID REFERENCES player_organizations(organization_id),
    commodity_id TEXT NOT NULL,
    quantity_delta BIGINT NOT NULL CHECK (quantity_delta <> 0),
    unit_value BIGINT NOT NULL DEFAULT 0 CHECK (unit_value >= 0),
    event_type TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS regional_economy_timeline_idx
    ON regional_economy_ledger(world_id, region_id, commodity_id, created_at DESC);

CREATE INDEX IF NOT EXISTS territory_tax_owner_idx
    ON territory_tax_policy(world_id, organization_id, territory_id);

COMMIT;
