-- Eternal Realms: shared-world PostgreSQL foundation
-- Apply with a migration runner using a dedicated, least-privilege database role.
-- Passwords are Argon2id hashes produced by the authentication service, never plaintext.

BEGIN;

CREATE TABLE IF NOT EXISTS world_registry (
    world_id TEXT PRIMARY KEY CHECK (world_id = 'eternal-realms-one-world'),
    active_server_instance_id TEXT,
    lease_id UUID,
    lease_expires_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (
        (active_server_instance_id IS NULL AND lease_id IS NULL AND lease_expires_at IS NULL)
        OR
        (active_server_instance_id IS NOT NULL AND lease_id IS NOT NULL AND lease_expires_at IS NOT NULL)
    )
);

INSERT INTO world_registry(world_id)
VALUES ('eternal-realms-one-world')
ON CONFLICT (world_id) DO NOTHING;

CREATE TABLE IF NOT EXISTS accounts (
    account_id UUID PRIMARY KEY,
    email_normalized TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','locked','closed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS account_sessions (
    session_id UUID PRIMARY KEY,
    account_id UUID NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
    token_hash BYTEA NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS account_sessions_account_idx ON account_sessions(account_id);

-- Durable login throttling; key is a SHA-256 digest of normalized email + client IP.
CREATE TABLE IF NOT EXISTS auth_rate_limits (
    rate_key TEXT PRIMARY KEY,
    window_started_at TIMESTAMPTZ NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    blocked_until TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS characters (
    character_id UUID PRIMARY KEY,
    account_id UUID NOT NULL REFERENCES accounts(account_id),
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    display_name TEXT NOT NULL,
    level INTEGER NOT NULL DEFAULT 1 CHECK (level >= 1),
    character_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(world_id, display_name)
);
CREATE INDEX IF NOT EXISTS characters_account_idx ON characters(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS characters_world_display_name_lower_uq ON characters(world_id, lower(display_name));

CREATE TABLE IF NOT EXISTS character_join_tickets (
    token_hash BYTEA PRIMARY KEY,
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS character_join_tickets_expiry_idx ON character_join_tickets(expires_at);

CREATE TABLE IF NOT EXISTS world_entities (
    entity_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    entity_kind TEXT NOT NULL,
    region_id TEXT NOT NULL,
    entity_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS world_entities_region_idx ON world_entities(world_id, region_id, entity_kind);

CREATE TABLE IF NOT EXISTS world_events (
    event_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    event_type TEXT NOT NULL,
    region_id TEXT,
    payload JSONB NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS world_events_timeline_idx ON world_events(world_id, occurred_at DESC);

CREATE TABLE IF NOT EXISTS inventory_items (
    item_instance_id UUID PRIMARY KEY,
    character_id UUID NOT NULL REFERENCES characters(character_id),
    item_definition_id TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    slot_index INTEGER CHECK (slot_index IS NULL OR slot_index BETWEEN 0 AND 27),
    item_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    UNIQUE(character_id, slot_index),
    UNIQUE(character_id, item_instance_id)
);
CREATE INDEX IF NOT EXISTS inventory_character_idx ON inventory_items(character_id);

CREATE TABLE IF NOT EXISTS equipment_slots (
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    slot_id TEXT NOT NULL,
    item_instance_id UUID UNIQUE,
    PRIMARY KEY(character_id, slot_id),
    FOREIGN KEY(character_id, item_instance_id)
        REFERENCES inventory_items(character_id, item_instance_id)
);

CREATE TABLE IF NOT EXISTS currency_ledger (
    ledger_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    character_id UUID NOT NULL REFERENCES characters(character_id),
    amount BIGINT NOT NULL CHECK (amount <> 0),
    reason TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS currency_ledger_character_idx ON currency_ledger(character_id, created_at DESC);

CREATE TABLE IF NOT EXISTS gameplay_transactions (
    transaction_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    actor_character_id UUID REFERENCES characters(character_id),
    transaction_type TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK (status IN ('committed','rejected')),
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS character_quests (
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    quest_id TEXT NOT NULL,
    quest_state JSONB NOT NULL,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(character_id, quest_id)
);

CREATE TABLE IF NOT EXISTS parties (
    party_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    leader_character_id UUID NOT NULL REFERENCES characters(character_id),
    party_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS party_members (
    party_id UUID NOT NULL REFERENCES parties(party_id) ON DELETE CASCADE,
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(party_id, character_id)
);

CREATE TABLE IF NOT EXISTS player_organizations (
    organization_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    organization_type TEXT NOT NULL CHECK (organization_type IN ('sect','guild','alliance')),
    name TEXT NOT NULL,
    leader_character_id UUID NOT NULL REFERENCES characters(character_id),
    organization_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE(world_id, name)
);

CREATE TABLE IF NOT EXISTS organization_members (
    organization_id UUID NOT NULL REFERENCES player_organizations(organization_id) ON DELETE CASCADE,
    character_id UUID NOT NULL REFERENCES characters(character_id) ON DELETE CASCADE,
    rank_id TEXT NOT NULL,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(organization_id, character_id)
);

CREATE TABLE IF NOT EXISTS territory_control (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    territory_id TEXT NOT NULL,
    organization_id UUID REFERENCES player_organizations(organization_id),
    control_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, territory_id)
);

CREATE TABLE IF NOT EXISTS market_listings (
    listing_id UUID PRIMARY KEY,
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    seller_character_id UUID NOT NULL REFERENCES characters(character_id),
    item_instance_id UUID NOT NULL UNIQUE,
    FOREIGN KEY(seller_character_id, item_instance_id)
        REFERENCES inventory_items(character_id, item_instance_id),
    currency_amount BIGINT NOT NULL CHECK (currency_amount > 0),
    status TEXT NOT NULL CHECK (status IN ('active','sold','cancelled','expired')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMIT;

-- Important deployment notes:
-- 1. The control-plane service must acquire the single row in world_registry
--    with SELECT ... FOR UPDATE in a transaction, reject an unexpired foreign
--    lease, and atomically assign a fresh UUID lease_id and expiry.
-- 2. Renew/release must match world_id + server_instance_id + lease_id.
-- 3. Inventory, currency, trading, crafting and quest rewards must commit in
--    one DB transaction with a unique idempotency_key.
-- 4. Never grant an item/currency on the client before the transaction commits.
-- 5. Use optimistic revision checks for character/entity updates.
