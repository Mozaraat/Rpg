-- Regional merchant pricing lookup indexes. Price calculation and purchase
-- remain one authoritative transaction in /v1/internal/merchant/purchase.
BEGIN;
CREATE INDEX IF NOT EXISTS merchant_catalog_region_idx
    ON merchant_catalog(world_id, region_id, merchant_id);
CREATE INDEX IF NOT EXISTS merchant_stock_regional_item_idx
    ON merchant_stock(world_id, item_definition_id, merchant_id)
    INCLUDE (quantity, unit_price);
COMMIT;
