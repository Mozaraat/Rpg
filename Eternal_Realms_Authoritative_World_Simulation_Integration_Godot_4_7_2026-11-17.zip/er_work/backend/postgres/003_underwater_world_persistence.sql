-- Durable underwater discoveries and ecosystem state.
-- Uses the shared world_entities table so the existing world entity API can
-- persist site snapshots; dedicated indexes make region/habitat queries cheap.
BEGIN;

CREATE INDEX IF NOT EXISTS world_entities_underwater_region_idx
    ON world_entities(world_id, region_id, updated_at DESC)
    WHERE entity_kind = 'underwater_site';

CREATE TABLE IF NOT EXISTS underwater_resource_claims (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    site_id TEXT NOT NULL,
    resource_key TEXT NOT NULL,
    character_id UUID REFERENCES characters(character_id),
    item_definition_id TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity >= 0),
    is_treasure BOOLEAN NOT NULL DEFAULT FALSE,
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, site_id, resource_key)
);

CREATE TABLE IF NOT EXISTS underwater_boss_encounters (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    site_id TEXT NOT NULL,
    boss_definition_id TEXT NOT NULL,
    encounter_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    last_defeated_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, site_id, boss_definition_id)
);

CREATE TABLE IF NOT EXISTS aquatic_site_populations (
    world_id TEXT NOT NULL REFERENCES world_registry(world_id),
    site_id TEXT NOT NULL,
    species_id TEXT NOT NULL,
    habitat_id TEXT NOT NULL,
    population_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision BIGINT NOT NULL DEFAULT 0,
    simulated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY(world_id, site_id, species_id)
);
CREATE INDEX IF NOT EXISTS aquatic_site_population_habitat_idx
    ON aquatic_site_populations(world_id, habitat_id, species_id);

COMMIT;
