# Eternal Realms — Living Dungeon Expansion

## Dungeon creatures
- Added Fungal Stalker, Crystal Mimic, Cinder Hound, Drowned Guard, Rune Stalker, Abyss Mantis, Grave Knight, Ember Shaman and Void Stalker to the 100-floor monster roster.
- Added creature-specific materials and drop tables, plus additional common magical drops.
- New creatures reuse the project's existing procedural creature rigs/silhouettes with their own palettes and stats; they are not imported high-poly models.
- Wandering elite encounters can appear on deeper floors and guard side branches.

## Exploration
- Every floor now places a discoverable forgotten cache in an optional maze branch.
- Every second floor can contain an ancient skill shrine in a separate branch.
- Cache rewards scale modestly with floor depth; caches and shrines are rebuilt cleanly when a floor is restored from save.
- Optional elite encounters reward extra combat and exploration progression.

## Earnable skills
- Dungeon Delving: gained by entering, advancing through, and exploring dungeon floors and opening hidden caches.
- Monster Lore: gained by defeating dungeon creatures; bosses award more.
- Arcane Attunement: gained by interacting with ancient skill shrines.
- These are integrated into the existing use-based skill progression and skill save data. Dungeon Delving and Arcane Attunement also improve drop luck gradually, with caps to protect balance.

## Verification
- Archive structure and script delimiter balance checked.
- Godot executable was not available in this environment, so project import/runtime play-testing remains required. Please test entering Floor 1, opening the cache, using a shrine on an even floor, killing each new creature, saving and reloading.
