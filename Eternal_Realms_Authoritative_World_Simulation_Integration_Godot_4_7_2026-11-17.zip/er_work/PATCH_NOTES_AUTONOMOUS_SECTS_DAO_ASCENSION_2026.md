# Eternal Realms — Autonomous Sects & Dao Progression Expansion

## Added in this pass

- Persistent sect disciple rosters with training progress, cultivation advancement, loyalty and rivalry values.
- Sect master expedition records with destinations, departure/return timestamps and travel status.
- Periodic world simulation advances master expeditions and disciple development while the game is actively running.
- Active sect wars now resolve into persistent battle reports. Victories transfer the contested territory owner and reduce war pressure; prolonged wars can become exhausted.
- Player-founded sect data, gated behind a minimum of three player-built structures, with the player recorded as Sect Master.
- Player sect recruitment records new disciples in the same persistent roster structure used by the established sects.
- Dao comprehension tracks insight and unlocks five stages per Dao path.
- Immortal ascension now requires a high cultivation realm, advanced Dao comprehension and three tribulation milestones.
- Sect world reports and faction reports expose the new persistent data for future map/UI integration.

## Integration notes

This pass extends the existing `SectSimulation` autoload and `PlayerData.stats.sect_state` save data. It does not create a parallel faction manager. Existing sect recruitment, diplomacy, territory and inheritance APIs remain in place.

## Known implementation boundary

War outcomes are currently resolved by the persistent world simulation and recorded as battle reports/territory ownership changes. A fully rendered battlefield with spawned squads, pathfinding, attack animations and player intervention is a separate presentation/combat integration task and is not claimed as completed here. Master expeditions are persistent world-state journeys; visible long-distance NPC travel routes and map markers still need to be connected to the world scene. Player headquarters founding currently uses the existing player-built structure count as its initial construction gate; a dedicated sect-hall blueprint and placement validation remain future work.

## Validation

- Source-level review performed on the edited sect simulation script.
- Godot runtime/parser validation was not available in this environment; the project must still be opened in Godot 4.6 for a full import and runtime test.
