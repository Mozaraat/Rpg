# Eternal Realms — Living Dungeon Systems Update

## Implemented in this pass

- **Pack hunting:** Dungeon enemies assigned to the same local pack group alert nearby packmates when one detects the player. Existing home/leash roaming gives each pack a territory to defend.
- **Rare encounters:** Seed/depth-gated rare variants can appear on selected floors, with boosted stats and a guaranteed rare material plus a chance at legendary equipment.
- **Runic secrets:** Side-branch rune seals now require the player to enter a three-symbol sequence using keys 1–4. Solving grants materials, gold and Exploration, Dungeon Delving and Arcane Attunement training.
- **Legendary equipment:** Added Eclipse Edge and Warden Heartplate as rare-encounter drops, alongside three new rare crafting/relic materials.
- **Active combat abilities:** Press **R** to queue the highest unlocked ability. Swordsmanship 10 unlocks Cleave; Swordsmanship 25 unlocks Heavy Strike; Arcane Attunement 10 unlocks Arcane Burst. The next melee impact consumes the queued ability.
- **Boss phases:** Dungeon bosses change behaviour at 60% and 25% health, increasing damage, speed and attack reach and announcing phase transitions.
- **Living floor events:** While inside, a timed event can trigger a hunting horde, an Arcane Surge that empowers shrines, or a Treasure Echo that creates a bonus cache.
- **Persistent discoveries:** Opened floor caches, used shrines and solved secret seals are recorded in dungeon save data and are not recreated after loading. Discovered floors are also saved.

## Controls

- **E** (Interact): activate a runic seal, then follow the displayed sequence.
- **1, 2, 3, 4**: enter the runic sequence after activating a seal.
- **R**: queue your highest currently unlocked combat ability; perform a normal attack to release it.

## Verification

Archive structure and ZIP CRC integrity were checked. The Godot executable is not available in this environment, so the project still needs an in-engine import and gameplay test for parser/runtime validation, combat balance and scene behaviour.
