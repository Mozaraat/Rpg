# Guilds, Hunting Parties, Dungeon Variants & Inventory Art

## Design boundary
Networking remains intentionally disabled/deferred. These systems run as local development foundations and use stable IDs/data shapes so an authoritative multiplayer backend can be connected later.

## Guilds
- Added persistent `GuildSystem` autoload with guild creation, descriptions/emblems, membership, leader/officer/member roles, join requests, approvals, invitations, member removal, renown, levels and guild dungeon records.
- Voluntarily leaving a guild starts a seven-day cooldown before joining another guild. This does not block solo play, creating parties, or dungeon exploration.
- Guild profile is saved independently to `user://guild_profile.json`.
- Guild tab is available with **G** in the game menu.
- Boss victories grant guild renown when the player belongs to a guild.

## Parties
- Added `PartySystem` for temporary five-member hunting parties, leader identity, readiness, test-member management and hunting targets.
- Parties are independent of guild membership and can be disbanded without guild penalties.
- Online invitations and synchronization are deferred until the network layer is added.

## Rare dungeon creatures and materials
- Rare encounters now receive named regional variants and unique visual tints.
- Variant-exclusive drops include Moonstone Ore, Voidsilk, Dragonbone, Ancient Scale and Heart of the Depths.
- These materials are only dropped by rare dungeon encounters and are added to the item database for future crafting recipes.

## Inventory art
- Added 63 item SVG illustrations and updated the shared inventory icon renderer to use them, retaining grade borders, stack counts and durability bars.
- Icons are local project assets and do not require network access.

## Validation
- ZIP archive integrity checked after packaging.
- Godot 4.6 executable was not available in the build environment, so runtime/parser validation could not be performed here.
