# Eternal Realms — Repair Pass

## Fixed in this pass
- Fixed first-visit dungeon floor visibility: a floor is now instantiated before visibility is switched to it. This prevents newly reached floors from appearing empty.
- Boss floor gates and rewards now respond to the boss death signal rather than `tree_exiting`. Leaving a floor or exiting the dungeon no longer counts as defeating its boss.
- Save data now records dungeon entry state, current floor, deepest cleared floor, and overworld return position. Loading a dungeon save restores the correct dungeon floor and safe player placement; normal overworld saves still restore the saved player position.
- Increased save schema version to 4 while retaining best-effort loading of older saves.
- Inventory removal and gold spending reject zero/negative quantities, preventing invalid inventory changes.
- Save deserialization now sanitizes item counts, grades, durability, and quest progress lengths/ranges to avoid malformed or outdated data breaking quest UI.

## Validation performed
- ZIP archive extracted successfully before editing.
- Static resource-path scan: no missing `res://` references found.
- Static class-name scan: no duplicate `class_name` declarations found.
- Static group scan: no queried scene groups were missing an `add_to_group` declaration.
- Godot runtime/editor validation was not available in this environment, so this pass is not represented as an in-engine playtest. Open the project in Godot 4.6 and check the debugger for engine-level parse/runtime warnings.
