# Eternal Realms — deployment guide (Godot 4.7)

This guide covers the current authoritative Elyndor backend, PostgreSQL database, dedicated Godot server and production clients. It is written for the **single persistent world** only.

> **World identity:** `eternal-realms-one-world`  
> **Game transport:** ENet over UDP, default port `24560`  
> **Backend:** FastAPI over HTTPS  
> **Database:** PostgreSQL 16

Do not deploy multiple public world servers, shards, channels or independent databases that accept players as separate populations. The database-backed world lease is intended to fence a second production server from starting.

---

## 1. Deployment layout

A basic deployment has these components:

1. **PostgreSQL** — persistent accounts, characters, inventories, currency ledgers, quests, merchant stock, trades and world simulation records.
2. **FastAPI backend** — account/session endpoints and authenticated internal operations used by the authoritative game server.
3. **One dedicated Godot server** — owns live gameplay simulation and listens on UDP `24560` by default.
4. **Godot clients** — connect to that server and use the HTTPS backend for account/character operations. Clients must not have the backend service secret.
5. **TLS reverse proxy** — exposes the backend securely as `https://your-api-host`; the included Compose file binds backend port `8080` to loopback.

The included Docker Compose file runs PostgreSQL, the API and a daily local database backup service. It does not provision a public TLS reverse proxy, firewall, managed database, or a Godot server host; those are deployment responsibilities.

## 2. Requirements

- Godot **4.7** (use the same compatible 4.7 release for editor exports and dedicated server builds).
- Docker Engine and Docker Compose plugin.
- A Linux host or equivalent environment for the dedicated server.
- A DNS name and TLS certificate for the backend before production clients connect.
- Firewall access for HTTPS to the backend and UDP `24560` to the game server.
- Persistent storage for PostgreSQL data and backups.

## 3. Configure backend secrets

From the project root, create the deployment environment file:

```sh
cd backend
cp deploy/.env.example deploy/.env
```

Edit `backend/deploy/.env`. Replace every placeholder with a different, cryptographically random secret:

```dotenv
ER_POSTGRES_PASSWORD=YOUR_LONG_RANDOM_DATABASE_PASSWORD
ER_JWT_SECRET=YOUR_RANDOM_SECRET_AT_LEAST_32_CHARACTERS_LONG
ER_CONTROL_PLANE_TOKEN=YOUR_LONG_RANDOM_PRIVATE_SERVER_TOKEN
ER_BACKUP_RETENTION_DAYS=14
```

Generate secrets with a trusted password manager or a cryptographically secure generator. Do not reuse passwords, commit `deploy/.env`, put secrets in screenshots/logs, or include the service token in a client export. Restrict file access to the deployment operator and service account.

The same `ER_CONTROL_PLANE_TOKEN` value is used by the dedicated server for authenticated internal backend calls and the world-lease control plane. It is a server-only secret.

## 4. Start the backend and database

From the `backend` directory:

```sh
docker compose -f deploy/docker-compose.yml --env-file deploy/.env up --build -d
```

Check service state and logs:

```sh
docker compose -f deploy/docker-compose.yml --env-file deploy/.env ps
docker compose -f deploy/docker-compose.yml --env-file deploy/.env logs --tail=100 backend postgres
```

Check the health endpoint on the deployment host:

```sh
curl http://127.0.0.1:8080/health
```

The health endpoint should report a healthy database connection and the fixed world identity. The backend is bound to `127.0.0.1:8080` by default; keep it private behind a TLS reverse proxy. Do not expose plain HTTP port `8080` directly to the internet.

### TLS and reverse proxy

Configure the reverse proxy to:

- Serve the API on your HTTPS hostname.
- Forward requests to `http://127.0.0.1:8080`.
- Preserve the request method, path, headers and body.
- Support the API's normal request sizes and timeouts.
- Restrict `/v1/internal/*` endpoints at the network layer where practical; they also require the service bearer token.
- Avoid logging Authorization headers, passwords, refresh tokens or join tickets.

Use the final HTTPS hostname for both `ER_BACKEND_URL` and `ER_CONTROL_PLANE_URL` below. Do not use a trailing path such as `/v1`; the game appends API paths itself.

## 5. Database migrations and existing installations

### New database volume

On the first initialization of a new PostgreSQL data volume, the Compose file runs these migrations in order:

1. `backend/postgres/001_shared_world_schema.sql`
2. `backend/postgres/002_persistent_world_operations.sql`
3. `backend/postgres/003_authoritative_economy_and_quests.sql`
4. `backend/postgres/004_sect_treasury_regional_economy.sql`

Migration `003` seeds the current merchant catalog and stock. Migration `004` adds immutable sect treasury entries, per-territory tax policies and regional commodity-flow ledgers. The initialization scripts are only run when PostgreSQL initializes an empty data directory.

### Existing database

For an existing database, take and verify a backup first, then apply each migration that has not already been applied, in order. Example for a database that has already completed migrations `001` and `002`:

```sh
cd backend
docker compose -f deploy/docker-compose.yml --env-file deploy/.env exec -T postgres \
  psql -U er_service -d eternalrealms -v ON_ERROR_STOP=1 \
  < postgres/003_authoritative_economy_and_quests.sql
docker compose -f deploy/docker-compose.yml --env-file deploy/.env exec -T postgres \
  psql -U er_service -d eternalrealms -v ON_ERROR_STOP=1 \
  < postgres/004_sect_treasury_regional_economy.sql
```

If `001`, `002` or `003` has not yet been applied, apply the missing migrations first and in order. Coordinate migration execution so it is not run concurrently by multiple operators.

**Never delete `er_postgres_data` or run `docker compose down -v` to force migrations.** That destroys the persistent world database. Do not point a second live world server at a cloned production database.

## 6. Dedicated authoritative Godot server

Set these environment variables in the dedicated server process environment:

```sh
export ER_PRODUCTION_SERVER=1
export ER_BACKEND_URL=https://your-api-host
export ER_CONTROL_PLANE_URL=https://your-api-host
export ER_CONTROL_PLANE_TOKEN='YOUR_LONG_RANDOM_PRIVATE_SERVER_TOKEN'
export ER_SERVER_INSTANCE_ID='elyndor-primary-01'
```

- `ER_PRODUCTION_SERVER=1` enables production server behavior.
- `ER_BACKEND_URL` is the HTTPS API base used by the central backend autoload.
- `ER_CONTROL_PLANE_URL` is the HTTPS API base used to acquire, renew and release the one-world lease.
- `ER_CONTROL_PLANE_TOKEN` authenticates internal calls and lease operations. Never expose it to players.
- `ER_SERVER_INSTANCE_ID` is a stable, unique identifier for this server deployment. Do not run two public server processes with separate IDs against the same world.

Start the dedicated server from the directory containing `project.godot`:

```sh
godot --headless --path . -- --server
```

Use the actual Godot 4.7 executable name/path on your host (for example, `godot` or `godot4`). The server requests the global world lease before hosting. If it cannot obtain or renew the lease, it must not continue hosting a second or unfenced Elyndor. The default ENet listen port is UDP `24560`.

Run the server under a process supervisor (systemd, container orchestrator or equivalent) with automatic restart, restricted filesystem permissions, log rotation and environment secrets injected securely. Do not put secrets directly in shell history or a publicly readable service definition.

### Server network/firewall

- Allow inbound **UDP 24560** to the dedicated Godot server.
- Allow outbound HTTPS from the server to the backend.
- Allow only required administrative access (SSH or equivalent) to the host.
- Do not expose PostgreSQL port `5432` publicly.
- The server port can be changed only by changing the launch/network configuration consistently; the current default client and server port is `24560`.

## 7. Production client configuration

Each production client needs only the public HTTPS API address and the production-client flag:

```sh
export ER_PRODUCTION_CLIENT=1
export ER_BACKEND_URL=https://your-api-host
```

The client connects to the public address of the one authoritative game server on UDP `24560`. A command-line connection can be started with:

```sh
godot --path . -- --connect=YOUR_GAME_SERVER_HOSTNAME_OR_IP
```

**Never set `ER_PRODUCTION_SERVER=1` on a player client. Never distribute `ER_CONTROL_PLANE_TOKEN` or `ER_CONTROL_PLANE_URL` to clients.** Production-client mode blocks clients from hosting another world and enables fail-closed behavior for protected local mutations.

### Account and character flow limitation

The backend exposes registration, login, character listing/creation and one-use character join-ticket operations. The account portal and backend methods exist, but the polished end-to-end login/character-selection and refresh-token user experience is not complete. Do not bypass the account-owned character and join-ticket verification flow in production. A client should authenticate, select an owned character, obtain a one-use join ticket and then connect; the authoritative server consumes and verifies that ticket with the backend.

## 8. Backups and recovery

The Compose `backup` service creates a PostgreSQL custom-format dump and SHA-256 checksum every 24 hours. Files are stored in the Docker volume `er_postgres_backups`; retention defaults to 14 days.

List backup files:

```sh
docker compose -f deploy/docker-compose.yml --env-file deploy/.env exec backup ls -lh /backups
```

Copy a backup out of the container/volume using your approved operations process and store encrypted copies in a separate failure domain. A local Docker volume is not disaster recovery. Before public launch, configure off-host encrypted backups, WAL/PITR if required, monitoring, and scheduled restore drills.

For a restore, stop world writes and fence the active world lease first. Restore into an isolated recovery database, validate world identity and application records, then promote only one recovered server behind the single active lease. Never bring up a second public Elyndor using a restored copy.

See `backend/ops/BACKUP_RESTORE_MONITORING.md` for operational detail.

## 9. First deployment checklist

- [ ] Use Godot 4.7 for the server and clients.
- [ ] Generate unique database, JWT and server-service secrets.
- [ ] Keep `backend/deploy/.env` private and out of source control.
- [ ] Start PostgreSQL and FastAPI with Docker Compose.
- [ ] Confirm `/health` is healthy.
- [ ] Put the API behind HTTPS and verify the certificate.
- [ ] Confirm migrations `001`, `002`, `003`, `004` are applied in order.
- [ ] Configure the dedicated server with all five `ER_*` variables above.
- [ ] Start exactly one production dedicated server and verify it acquires the global lease.
- [ ] Open UDP `24560` to the game server; keep PostgreSQL private.
- [ ] Configure clients with `ER_PRODUCTION_CLIENT=1` and the HTTPS backend URL only.
- [ ] Verify login, character ownership and one-use join-ticket flow before allowing real players.
- [ ] Test quest completion, merchant purchase/sale, restart restoration and database recovery with test accounts.
- [ ] Confirm no client has the server service token and no second public world can acquire the lease.

## 10. Verification status and production readiness

This package has static checks and archive-integrity checks recorded in its build audit. Those checks are not equivalent to running the game or backend in a production-like environment. Before public launch, perform and record:

- Godot 4.7 editor import, script parsing and headless server startup.
- PostgreSQL migration tests on both a fresh database and a copy of an existing database.
- HTTPS certificate, authentication, authorization and secret-leak checks.
- Two-or-more-client tests for quest rewards, merchant stock contention, player trading and reconnects.
- Server restart tests for boss state, monster populations and territory snapshots.
- Backup restore drills and database consistency checks.
- Load, latency, packet-loss, database contention and failover tests at the intended population.

The current project is an evolving authoritative multiplayer foundation, not a security-certified or capacity-certified public MMO deployment. The network panel now exposes a player trade workflow (nearby peer request, invitation acceptance, server-UUID item selection, gold offer and confirmation). The backend validates and commits both offers atomically, including inventory-capacity checks, and synchronizes inventories after commit. Player-founded sects are provisioned into the shared organization registry. Merchant transactions now append regional commodity-flow entries and collect configured territory tax into the owning organization's immutable treasury ledger.

Important integration boundary: territory tax only accrues when the authoritative `territory_control.organization_id` is populated with a real organization UUID and the merchant maps to that territory (explicit `merchant_catalog.territory_id`, or a matching territory/region ID). Existing NPC sect-war simulation still stores faction names/IDs in local simulation state; it is not yet a fully server-authoritative organization/territory-ownership service. Treasury balances are ledger-derived and can be queried by the internal API, but a complete in-game sect treasury administration screen, player treasury spending/withdrawal permissions, and full production/consumption integration for every resource source are still outstanding. Do not represent those remaining systems as complete. Preserve the one-world invariant throughout every deployment and recovery operation.
