# Eternal Realms — Vast 100-Floor Raid Dungeon Expansion

## Dungeon scale and layout

- Expanded each floor from a compact 9×9 maze to a 13×13 city-scale floor.
- Each cell represents a 16-metre chamber/route module, producing an approximately 208×208-metre underground district.
- The deterministic route network retains a connected entrance-to-descent path while adding loops and wide civic spaces.
- Added a broad entrance/transit ward, four recognisable city quarters, a monumental central civic forum and a dedicated 5×4-cell raid sanctum.
- Added exchange stalls, residential building shells, abandoned archive ruins, a sacred precinct, environmental signage and floor-specific memorial text.
- Preserved the ten civilisation bands across 100 floors, their palette, landmark props, hazards, discoveries and existing progression hooks.

## Raid guardian on every floor

- Every floor still spawns a boss that must be defeated to open the descent gate.
- Added 100 unique floor-specific guardian titles grouped by the ten underground civilisations.
- Boss appearance colour is blended with the local civilisation glow to better match each floor's art direction.
- Raid guardians receive scaled health/damage, increased size, extended detection/leash ranges, and four health-driven encounter phases.
- Added four telegraphed raid attacks: ring slam, aimed void lance, cross burst and close-range inner blast. The telegraphs are visible before resolution, and line-of-sight is checked before damage is applied.
- The HUD expands for raid encounters and displays floor number, guardian name, phase and the full health bar.
- Every tenth floor receives a stronger milestone guardian; the 100th floor retains the final sovereign encounter and final-floor scaling.

## Exploration, lore and navigation

- Added 100 short environmental records—one per floor—distributed across the ten civilisations.
- Expanded the dungeon map to 13×13 and gave it distinct colour blocks for transit, exchange, residential, archive, temple, central forum and raid sanctum districts.
- Preserved start, player and boss-gate markers.
- Reduced wall-dressing mesh count while preserving the carved masonry read. Corrected duplicate wall generation so every sealed internal edge creates one wall and one collision body rather than overlapping duplicates.
- Kept only the current and adjacent floor rooms cached to bound memory and scene-node usage during descent.

## Files changed

- `systems/dungeon_system.gd`
- `entities/monster.gd`
- `ui/dungeon_map_view.gd`
- `ui/player_hud.gd`

## Static verification performed

- 99 GDScript files scanned.
- No duplicate global `class_name` declarations found.
- No duplicate function declarations found.
- 110 fixed `res://` references scanned; no missing targets found.
- 10 civilisation boss-title groups and 100 unique titles verified.
- Delimiter balance checked in all four changed GDScript files.
- Maze connectivity model checked for all 169 cells, including the boss sanctum connection.
- Archive integrity checked after packaging.

## Runtime verification limitation

Godot 4.6 is not installed in the build environment. The project has not been imported or launched in Godot during this pass. GDScript parser validation, combat feel, collision/navigation behaviour, visual rendering and performance must still be verified in-engine. Static checks do not replace those tests.
