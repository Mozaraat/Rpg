# Eternal Realms — Dungeon Depth & Faction Combat Expansion

## Dungeon civilization combat identities
- Added ten data-driven civilization combat profiles across the 100-floor structure.
- Each civilization's defenders carry a faction identity, tactical profile and elemental resistance adjustments; these adjustments combine with species resistances.
- Raid guardians alternate their existing multi-stage attack cycle with a civilization signature: bronze lance, spore cloud, prism split, grave pulse, ash cone, frost ring, tide surge, root snare, void fold or astral orbit.
- Existing boss health thresholds and phase escalation remain intact; signature telegraphs now communicate the new danger shapes before resolution.

## Dungeon factions and intelligent groups
- Every floor now fields a named faction vanguard captain and two guards in addition to its existing inhabitants, elites and raid guardian.
- Patrol members share faction and pack identifiers, with captain/guard/flanker roles. The existing monster pack-alert and flanking behaviours are reused so groups react as a unit rather than as unrelated spawns.
- The ten faction identities follow the ten civilization bands: Concord Remnant, Mycelium Choir, Prism Enclave, Sepulchral Court, Cinder Dominion, Winter Monastery, Thalassian Court, Root Communion, Starless Court and Eternal Archive.

## Traps, puzzles and hidden areas
- Pressure traps can now be disarmed through the existing interaction system before they trigger; disarming trains Observation and Dungeon Delving.
- Runic secret locks now appear on every floor rather than only occasional floors.
- Solving a runic lock reveals a physically modelled hidden reliquary alcove with a relic plinth, in addition to the existing floor-scaled rewards and technique discovery.
- Existing civilization memory trials, floor hazards, caches, shrines, spirit veins and memory tablets are retained.

## Compatibility and validation
- Changes are integrated into the existing `DungeonSystem`, `Monster`, `dungeon_secret.gd` and `dungeon_trap.gd` systems; no replacement dungeon or separate save format was introduced.
- Static audit: 105 GDScript files scanned; no duplicate top-level functions, delimiter-balance findings or missing literal `res://` resource references.
- Godot 4.6 runtime parsing, editor import, physics, AI, visual telegraphing and save/load playtesting were not available in this environment. Static checks do not replace an engine playtest.
