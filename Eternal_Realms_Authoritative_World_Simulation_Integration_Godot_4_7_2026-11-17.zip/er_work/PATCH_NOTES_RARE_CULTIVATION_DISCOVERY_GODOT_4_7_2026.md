# Patch Notes — Rare Cultivation Discovery (Godot 4.7)

## Implemented

- Added `CultivationDiscovery` autoload and a persistent discovery record with clues, recognition state, trial attempts/failures, method identifier/source and first-cultivation timestamp.
- Added comprehension and willpower scoring as separate derived measures.
- Added clue recording from spiritual landmarks, dungeon memory tablets, ancient archives and solved runic secrets.
- Removed automatic cultivation and arcane-attunement skill gains from spiritual-landmark discovery and meditation; these locations now reveal evidence instead.
- Gated cultivation/arcane-attunement training, circulation, Dao path selection and breakthrough attempts until the character has a legitimate method.
- Added qualified-NPC recognition dialogue when the player has enough evidence and meets the comprehension/will requirements.
- Updated the cultivation menu to present ordinary field notes and discoveries while the character remains mortal, rather than displaying a default realm/root/path as if cultivation were already their progression track.
- Updated the character sheet to identify a locked character as Mortal and keep hidden cultivation fields undisclosed.
- Changed sect recruitment's first examination from a spiritual-root gate to an Insight trial, so ordinary mortals can join sects.
- Added discovery state to authoritative character snapshots. Local saves already include `PlayerData.stats`.
- Prevented remote production clients from authorising a cultivation method locally; server-side validation is required.

## Important limitations

- The current recognition interaction is a first-pass system, not the final bespoke trial/minigame design. Its compatibility evidence is a structured eligibility check and should be expanded into authored trials.
- Remote production-character discovery is deliberately locked pending an authoritative backend interaction workflow. This avoids trusting client-submitted cultivation unlocks. A server-side trial and backend persistence endpoint are required before enabling this for remote clients.
- No Godot 4.7 executable is available in this environment, so GDScript parser/runtime testing was not performed. Static inspections and project integrity checks are reported separately.
