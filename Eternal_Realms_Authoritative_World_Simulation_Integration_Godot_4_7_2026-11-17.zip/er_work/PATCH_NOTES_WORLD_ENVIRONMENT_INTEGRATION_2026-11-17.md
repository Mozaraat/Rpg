# Eternal Realms — World Environment Integration Pass

## Scope
Connect the existing climate and hydrology foundations to gameplay in the Godot 4.7 project. This pass adds regional runoff routing, visible surface-water indicators, persistent regional water state, farm moisture response, settlement water management, wildlife habitat response and a terrain erosion heightfield ledger.

## Implemented

- Hydrology now samples a 64 m regional grid around the active player, partitions rainfall into runoff/infiltration, updates soil saturation, groundwater, surface water and evaporation, and routes accumulated discharge downhill from higher cells to lower cells.
- Connected downstream cells accumulate upstream discharge. Cells exceeding the configured discharge threshold receive a narrow water-surface visual; waterlogged cells receive a broader flood-surface visual. Flood risk is estimated from local surface storage, valley position and routed discharge.
- Regional water cells are serialized to `user://regional_hydrology.json` every 30 seconds and restored on startup.
- Farm plots now sample the hydrology and climate systems. Crop growth is affected by soil moisture, drought, waterlogging/flood stress and temperature suitability. Manual watering remains available.
- Settlement water accounts now estimate population demand, collect rainfall from a notional roof catchment into a capacity-limited cistern, abstract groundwater to meet demand, and calculate reserve stress. Settlement flood risk reduces development and can damage buildings; flood protection gradually improves and can be increased through `invest_flood_protection`.
- Wildlife critters choose local movement directions using moisture, stream flow, flood exposure and temperature suitability. The ecosystem population model adjusts fish and terrestrial carrying capacity to local water and temperature conditions and reduces breeding under temperature extremes.
- Hydrology records sediment mass and erosion indices and feeds small persistent height offsets into the shared `TerrainNoise` heightfield. Newly generated terrain chunks can reflect those accumulated changes.

## Important simulation boundaries

- The hydrology grid is regional and active-area driven, not a globally running fluid solver. It currently simulates a square around the player and settlement cells.
- Downhill routing uses a local-neighbour drainage approximation, not a globally precomputed watershed graph. It can stop at local sinks and needs world-generation watershed preprocessing for fully connected continental river basins.
- River and flood visuals are coarse water-surface patches, not a physically solved river mesh, depth field or shoreline system.
- Settlement water is a strategic abstraction model. It does not yet create animated wells, pumps, cistern props, water carriers or water-quality disease systems.
- Wildlife habitat selection affects local movement and carrying capacity; it is not yet a long-distance seasonal migration planner.
- Erosion is accumulated in the shared heightfield data. Already-rendered terrain chunks are not immediately rebuilt after each tiny erosion step; regenerated chunks display the updated heightfield. A safe, throttled terrain-chunk refresh and sediment deposition/transport pass remain future work.
- Water persistence is local `user://` state. Authoritative shared-world persistence and multiplayer replication must be implemented through the central backend before deployment.

## Validation

- Confirmed the modified scripts and autoload entries exist in the project tree.
- Performed source-level structural checks and archive integrity checks.
- Godot 4.7 executable was not available in this environment, so engine parsing, scene startup, runtime simulation and multiplayer tests remain unverified.
