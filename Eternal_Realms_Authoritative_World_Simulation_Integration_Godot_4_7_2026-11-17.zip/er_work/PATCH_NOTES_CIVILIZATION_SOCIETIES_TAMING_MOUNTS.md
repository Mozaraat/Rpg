# Eternal Realms – Civilization Societies, Taming & Mounts

## Civilization society framework
- Added ten named dungeon cultures with distinct languages, greeting phrases and translations.
- Each culture has trade specialties and a faction conflict hook.
- Added per-culture reputation, reputation-adjusted trade quote helpers, conflict resolution, and repeatable post-conflict quest descriptions.
- Culture selection maps dungeon floors 1–100 to ten ten-floor civilization bands.

## Taming and mounts
- Added a taming/companion system for rabbits and chickens.
- Taming uses a food offering (one Mackerel) and species-specific trust chance; failed attempts consume the offering.
- Tamed companions are recorded in PlayerData stats and survive normal save serialization of stats.
- Press **F** to attempt taming when no companion is owned; once one is owned, F summons/mounts it. Press F again to dismount.
- Mounted movement speed is increased by 45%; a simple companion mount model follows the player while mounted.

## Integration
- Added TamingMountSystem and CivilizationSocieties as autoloads.
- Added the `tame_mount` input action on F and integrated it into the player input and movement systems.

## Validation
- Checked new script resource paths and existing project references. The only unresolved path found is the existing intentional format-string `res://assets/items/%s.svg` in `ui/ui_kit.gd`.
- Godot executable/editor is not available in this environment, so a Godot parser/import/playtest could not be run. Open the project in Godot 4.6 and test taming, save/load, mounting, and culture APIs in-engine.
