# Eternal Realms — Autonomous Generations, Settlements & Tides

**Target:** Godot 4.7 / Forward+  
**Milestone:** Living world simulation and physical environment pass

## Autonomous NPC generations

- Added a persistent NPC life record with age, profession, family membership, partner, children, home region, migration state, expedition state, work experience, adventurer experience, survival state and death history.
- Children age in world days, visibly grow through staged model scaling and become adults at 18. Adult residents without an assigned profession are also migrated into the career system, so older save data does not leave them permanently as generic villagers.
- Adult careers are selected from weighted world needs: farmers, guards, hunters, merchants, smiths, craftsmen, adventurers, herbalists, scholars and fishers. Family work can influence a child's eventual career without guaranteeing inheritance.
- Generated merchants and craftspeople can establish persistent market stalls or workshops with stock, region and ownership records.
- Adults can form households, have children, become widowed, form a new household later, retire and eventually die of old age. New marriages detach adults from their former household's active membership while preserving the old household's historical record.
- Merchant ownership is inherited by an eligible adult family member or regional craftsperson after the proprietor dies. A business closes when no suitable successor exists.

## Migration and expeditions

- Households can migrate to an adjacent region, using a sampled safe-land position instead of selecting an arbitrary underwater or inaccessible region centre.
- Resident-owned businesses relocate with migrating households and retain their inventory.
- Profession-qualified NPCs can form small expeditions. Parties are chosen from a single origin region, travel to a neighbouring region, gather experience and resources, return after a simulated journey and can suffer casualties.
- NPC life state is saved across scene changes and restarts. Residents on expeditions are not respawned at home; returning residents can be reconstructed at their saved home. Interrupted migration journeys resolve safely to the persisted destination on reload.
- Death is permanent in the life record. A dead resident is not recreated when their scene is loaded again.

## Settlement history and return visits

- Society changes are recorded in a bounded history: births, careers, marriages, widowhood, retirement, migration, expeditions, deaths, business openings, inheritance, relocation and closure.
- Returning after an extended absence triggers a settlement summary showing population, local defenders, active families, businesses and expeditions away, followed by recent local history.
- Settlement reports exclude residents currently away on expeditions; expeditions are counted once per party rather than once per member.
- Offline world catch-up is bounded to 3,650 in-game days. The game day remains aligned to the existing 480-second day/night cycle.
- The society snapshot is saved through the existing shared-world authority path. Production mode uses the existing central region-entity storage and revision flow; generated vendors are provisioned through the existing merchant ledger API when first opened.

## Tides and coastal physics

- Added a shared `TideSystem` autoload with a semidiurnal lunar-tide approximation: two high-water cycles per 1.035-day lunar day and a 14.77-day spring/neap modulation.
- The default simulated amplitude is 1.25 metres around the existing base sea level. Current strength follows the rate of water-level change, with a changing current direction.
- The ocean plane and terrain shoreline/wet-sand shader receive the live water level.
- Swimming-depth checks, fishing-water checks and fish placement use the live level. Marine fish drift with the current. Fishing bite timing, line load and catch conditions respond to current strength.
- The HUD displays rising/falling/high/low tide and the current level offset.

## Compatibility and implementation notes

- New society fields are merged through the current player-data and shared-world snapshots. Older NPC records are assigned a profession when eligible instead of requiring a destructive save reset.
- The new `TideSystem` autoload is registered in `project.godot`; existing `LivingWorldSystem`, `WorldLifeSimulation`, NPC jobs, merchant panel and backend services remain the source of truth for their respective domains.
- `systems/terrain_noise.gd` indentation was normalized where the prior file mixed tabs and spaces in its region definition array.

## Validation performed

- Static scan of 126 GDScript files and 14 scene files.
- Checked GDScript delimiter/string balance, duplicate top-level function declarations, duplicate `class_name` declarations, GDScript indentation consistency and literal project/resource references.
- Checked new career names against `NPCJobs`; checked generated merchant items against `ItemDB`; verified the tide shader parameter and water-level consumers are connected.
- Godot 4.7 executable is not installed in this build environment. Engine import, Godot parser execution, actual game launch, visual playtesting, multiplayer latency tests and persistence round-trip tests could not be run here. Static checks do not replace those runtime tests.

## Simulation scope

The tide model is a gameplay-oriented physical approximation, not a full ocean solver: it does not calculate astronomical ephemerides, coastal bathymetry, weather-driven surge, wave breaking or region-specific fluid flow. Likewise, distant NPC events are simulated as persistent life events rather than running every off-screen resident as a continuously simulated physics body. The system is designed to make the world evolve coherently without requiring every NPC to remain loaded.
