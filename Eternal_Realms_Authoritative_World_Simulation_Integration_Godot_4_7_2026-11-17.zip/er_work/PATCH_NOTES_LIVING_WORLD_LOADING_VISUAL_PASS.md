# Eternal Realms – Living World, Login and Visual Pass

## New in this build
- The title/login screen is a local single-player profile/save entry screen; no online account authentication is required. New adventures write an initial save after the player and world are ready.
- New login/title screen with Continue Journey and Begin New Adventure.
- Asynchronous main-scene loading with a progress bar and world-specific loading tips.
- Saved progression is restored only after the game scene and player are ready.
- Persistent settlement business stock, restocking cycles, stock-sensitive price multipliers and purchase-stock API.
- Household reputation/bond records and new family-help dialogue choice.
- Visible world events: caravan arrivals, lantern festival, faction patrols and relief convoys. Events dress the settlement with banners, crates, lighting, signage and temporary NPC groups with gently animated banners and pulsing event lights; events can restock shops or improve settlement growth.
- Mount idle/movement bob and alternating leg motion; breeding same-species companions when both have bond 35+, costing 3 Mackerel; offspring saved to the stable.

## Controls
- F: tame / mount / dismount.
- G: feed and bond with active companion.
- H: equip saddle (2 Leather Strips).
- J: equip barding (3 Iron Ingots).
- K: breed active companion with a compatible bonded companion (3 Mackerel).
- L: cycle to the next companion so you can build bonds with both breeding partners.

## RPG reference audit
This pass uses living-world patterns associated with games such as Red Dead Redemption 2 and The Elder Scrolls: NPC routines and social relationships, reactive events, persistent faction/settlement state, readable feedback, and consequences that are visible in the world. Research also highlights schedules as a scalable way to make background characters feel active, and recommends tying economy, NPCs, quests and geography into one shared state.

### Still missing for a more complete RPG
- Fully animated, rigged mount species with rider seating, mounted combat, stamina, jumping and dismount blending. Current mount visuals use procedural primitives and gait motion.
- Actual genetics, pregnancy/gestation, foal growth, feeding schedules, stables and mount death/injury. Current breeding creates a saved offspring companion record.
- Full family trees with persistent parent/child/sibling NPC entities, aging, marriages, births and inheritance. Current implementation tracks household bond/reputation and family dialogue.
- Fully interactive shop inventory UI with individual item quantities, supply chains, wages and business ownership. This build adds persistent stock simulation and pricing API but does not yet replace every legacy shop panel transaction.
- Large-scale faction battles, territory ownership, siege objectives and AI combat formations. Visible events are small settlement encounters.
- Cinematic camera, facial animation, voice acting, handcrafted character rigs, authored environment assets and platform-specific graphics scalability.
- Robust controller remapping, accessibility options, audio sliders, cloud saves and automated regression tests.

## Visual quality notes
The existing day/night system already configures ACES tonemapping, glow, SSAO, optional SSIL, volumetric fog, dynamic sky and shadow quality. This pass adds stronger title-screen presentation and event-specific lighting/signage without forcing expensive global settings on lower-end hardware. Use F10 in-game to cycle the existing visual quality preset.

## Verification
ZIP integrity and static source checks were run. Godot 4.6 is not installed in this environment, so scripts were not engine-parsed and gameplay was not playtested.
