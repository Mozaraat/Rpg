# Dungeon Wall Seal Fix

- Added an opaque, continuous cave-stone core to every generated maze wall.
- Kept the irregular boulder meshes as surface dressing, preserving the natural cavern appearance.
- Matched the core dimensions to the existing solid wall collision volume, with a tiny visual overlap to prevent hairline seams between adjacent wall sections.
- Applied across all generated dungeon floors because every floor uses the shared `_add_maze_wall()` builder.

This specifically fixes the see-through slits caused by separated rounded boulder meshes; it does not change maze links, doorways, room layout, floor progression, or collision dimensions.
