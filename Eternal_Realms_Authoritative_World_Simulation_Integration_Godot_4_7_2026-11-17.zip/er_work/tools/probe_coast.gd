extends SceneTree

func _init() -> void:
	var t := TerrainNoise.new(42)
	for p in [
		Vector2(24, -48), Vector2(16, -48), Vector2(32, -48),
		Vector2(24, -40), Vector2(24, -56), Vector2(24, -64),
		Vector2(8, -56), Vector2(0, -64), Vector2(16, -64),
		Vector2(32, -56), Vector2(40, -48),
	]:
		print("X (%d,%d) h=%.2f" % [int(p.x), int(p.y), t.get_height(p.x, p.y)])
	quit()
