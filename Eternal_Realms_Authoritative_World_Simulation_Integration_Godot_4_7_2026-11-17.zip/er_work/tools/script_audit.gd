extends Node

# Temporary development audit: loads every GDScript in the project with the
# full autoload set registered, so cross-script singleton references resolve.

func _ready() -> void:
	var files: Array[String] = []
	_collect("res://", files)
	files.sort()
	var failures: Array[String] = []
	for path in files:
		if path.begins_with("res://tools/"):
			continue
		var script: Script = load(path)
		if script == null or not script.can_instantiate():
			failures.append(path)
	print("SCRIPT_AUDIT checked=%d failures=%d" % [files.size(), failures.size()])
	for path in failures:
		print("SCRIPT_AUDIT_FAIL ", path)
	get_tree().quit(0 if failures.is_empty() else 1)

func _collect(dir_path: String, out: Array[String]) -> void:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry.begins_with("."):
			entry = dir.get_next()
			continue
		var full := dir_path.path_join(entry)
		if dir.current_is_dir():
			if entry != "tools" and entry != "backend":
				_collect(full, out)
		elif entry.ends_with(".gd"):
			out.append(full)
		entry = dir.get_next()
	dir.list_dir_end()
