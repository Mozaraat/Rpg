extends SceneTree

# Temporary probe: scan for open, walkable scenic points (shorelines and
# hilltop views) so screenshot framing can be chosen from real terrain data.

func _init() -> void:
	var t := TerrainNoise.new(42)
	print("SHORE_PROBE start")
	for z in range(-160, 41, 8):
		for x in range(-160, 161, 8):
			var h: float = t.get_height(x, z)
			if h > 0.25 and h < 1.6 and t.get_forest_density(x, z, h) < 0.35:
				print("SHORE (%d,%d) h=%.2f region=%s forest=%.2f" % [
					x, z, h, t.get_region_name(x, z), t.get_forest_density(x, z, h)])
	print("HILL_PROBE start")
	for z in range(-160, 41, 12):
		for x in range(-160, 161, 12):
			var h: float = t.get_height(x, z)
			if h > 9.0 and h < 18.0 and t.get_forest_density(x, z, h) < 0.25:
				print("HILL (%d,%d) h=%.2f region=%s forest=%.2f" % [
					x, z, h, t.get_region_name(x, z), t.get_forest_density(x, z, h)])
	quit()
