extends Node

# Temporary HUD screenshot harness: boots the real game with the HUD visible,
# fires representative toast messages, then captures the top of the screen so
# banner text/geometry can be checked visually.

const OUT := "res://captures/00_hud_toasts.png"
var _t := 0.0
var _fired := false

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	var packed: PackedScene = load("res://scenes/main.tscn")
	add_child(packed.instantiate())

func _process(delta: float) -> void:
	_t += delta
	if not _fired and _t > 2.5:
		_fired = true
		EventBus.toast.emit("Discovered: Fisher's Fire near the eastern trail", "info")
		EventBus.toast.emit("Level up! You reached level 7 — +2 attribute points", "levelup")
		EventBus.toast.emit("Gathered 3 Ironwood Bark", "xp")
	if _t > 3.4:
		var img := get_viewport().get_texture().get_image()
		var err := img.save_png(OUT)
		print("HUD_CAPTURE %s err=%d" % [OUT, err])
		get_tree().quit()
