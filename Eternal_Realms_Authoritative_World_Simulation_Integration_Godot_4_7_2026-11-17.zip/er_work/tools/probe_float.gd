extends Node

# Temporary probe: find meshes and multimesh instances that hang in the air
# far above their terrain, seen from the river viewpoint.

var _t := 0.0
var _main: Node3D
var _player: Node3D

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate() as Node3D
	add_child(_main)
	_player = _main.get_node("Player") as Node3D

func _process(delta: float) -> void:
	_t += delta
	if _t < 3.0:
		return
	if _player.global_position.distance_to(Vector3(42, 0, 30)) > 4.0:
		_player.global_position = Vector3(42, 2.0, 30)
	if _t < 9.0:
		return
	var noise := TerrainNoise.new(GameManager.world_seed)
	print("FLOAT_PROBE player=", _player.global_position)
	_scan(get_tree().root, noise)
	get_tree().quit()

func _scan(node: Node, noise: TerrainNoise) -> void:
	if node is MultiMeshInstance3D and _under_chunk(node):
		var mmi := node as MultiMeshInstance3D
		var floating := 0
		var max_dy := 0.0
		var worst := Vector3.ZERO
		for i in range(mmi.multimesh.instance_count):
			var xf: Transform3D = mmi.multimesh.get_instance_transform(i)
			var w: Vector3 = mmi.global_transform * xf.origin
			var g: float = noise.get_height(w.x, w.z)
			var dy := w.y - g
			if dy > 2.5:
				floating += 1
				if dy > max_dy:
					max_dy = dy
					worst = w
		if floating > 0:
			print("FLOAT_MMI kind=%s parent=%s count=%d/%d max_dy=%.1f at %s" % [
				mmi.name, mmi.get_parent().name, floating, mmi.multimesh.instance_count, max_dy, str(worst)])
	elif node is MeshInstance3D and not _under_chunk(node):
		var mi := node as MeshInstance3D
		var p := mi.global_position
		if p.y > 4.0 and p.distance_to(Vector3(42, 0, 30)) < 700.0:
			print("FLOAT_MESH name=%s path=%s pos=%s aabb=%s" % [
				mi.name, str(mi.get_path()), str(p), str(mi.get_aabb().size)])
	for c in node.get_children():
		_scan(c, noise)

func _under_chunk(node: Node) -> bool:
	var n := node.get_parent()
	while n != null:
		if n is Chunk:
			return true
		n = n.get_parent()
	return false
