extends Node

# Temporary probe: prints terrain heights for candidate side-dungeon sites.
func _ready() -> void:
	var noise := TerrainNoise.new(GameManager.world_seed)
	var sites := [
		Vector2(-92, -82), Vector2(-52, -108), Vector2(18, -104),
		Vector2(150, 90), Vector2(200, -60), Vector2(-200, -140),
		Vector2(-120, 140), Vector2(-60, 60),
	]
	for site in sites:
		var surface: float = noise.get_height(site.x, site.y)
		var lowest: float = 9999.0
		var lowest_at := Vector2.ZERO
		var x: float = site.x - 14.0
		while x <= site.x + 98.0:
			var z: float = site.y - 14.0
			while z <= site.y + 14.0:
				var h: float = noise.get_height(x, z)
				if h < lowest:
					lowest = h
					lowest_at = Vector2(x, z)
				z += 7.0
			x += 8.0
		print("SITE %s surface=%.2f axis_min=%.2f at %s clearance=%.2f region=%s" % [
			str(site), surface, lowest, str(lowest_at), lowest - (surface - 24.0), noise.get_region_name(site.x, site.y)])
	get_tree().quit()
