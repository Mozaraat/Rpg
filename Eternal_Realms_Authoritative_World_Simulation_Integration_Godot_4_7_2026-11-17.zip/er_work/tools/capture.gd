extends Node

# Development screenshot harness. Instantiates the real main scene, lets the
# world settle, then captures a series of reference frames for visual review.

const OUT_DIR := "res://captures"
var _main: Node3D
var _camera: Camera3D
var _shot := 0
var _timer := 0.0
# player: where the character stands (drives world streaming).
# cam/target: independent cinematic framing so terrain and props cannot swallow
# the lens the way a collision-limited SpringArm can.
var _shots := [
	{"name": "01_village_morning", "time": 0.33, "pos": Vector3(-25, 0, -8), "cam": Vector3(-4, 13.0, 5), "target": Vector3(-28, 3.2, -35)},
	{"name": "02_village_noon", "time": 0.50, "pos": Vector3(-14, 0, -23), "cam": Vector3(-25, 30.0, 6), "target": Vector3(-25, 2.5, -40)},
	{"name": "03_valley_sunset", "time": 0.735, "pos": Vector3(8, 0, 8), "cam": Vector3(18, 44.0, 32), "target": Vector3(-30, 9.0, -70)},
	{"name": "04_coast_twilight", "time": 0.77, "pos": Vector3(32, 0, -62), "cam": Vector3(31, 9.5, -47), "target": Vector3(80, 2.0, -88)},
	{"name": "05_village_night", "time": 0.86, "pos": Vector3(-25, 0, -18), "cam": Vector3(-25, 7.5, -9), "target": Vector3(-25, 3.0, -33)},
	{"name": "06_gate_closeup", "time": 0.40, "pos": Vector3(-25, 0, -20), "cam": Vector3(-25, 5.6, -2.5), "target": Vector3(-25, 4.5, -12.0)},
	{"name": "07_plaza_closeup", "time": 0.42, "pos": Vector3(-18, 0, -22), "cam": Vector3(-14.5, 6.1, -13.5), "target": Vector3(-25, 4.3, -31.0)},
]

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT_DIR))
	var packed: PackedScene = load("res://scenes/main.tscn")
	_main = packed.instantiate() as Node3D
	add_child(_main)
	_camera = Camera3D.new()
	_camera.name = "CaptureCamera"
	_camera.fov = 72.0
	_camera.near = 0.08
	_camera.far = 900.0
	add_child(_camera)
	_camera.current = true

func _process(delta: float) -> void:
	_timer += delta
	if _shot >= _shots.size():
		return
	# Allow terrain streaming and vegetation to finish before the first frame.
	if _timer < 2.5 + float(_shot) * 1.6:
		return
	_apply_shot(_shots[_shot])
	if _timer < 3.4 + float(_shot) * 1.6:
		return
	var image := get_viewport().get_texture().get_image()
	var path := "%s/%s.png" % [OUT_DIR, str(_shots[_shot]["name"])]
	var err := image.save_png(path)
	print("CAPTURE %s err=%d" % [path, err])
	_shot += 1
	if _shot >= _shots.size():
		get_tree().quit()

func _apply_shot(shot: Dictionary) -> void:
	var cycle := _main.get_node_or_null("DayNightCycle")
	if cycle:
		cycle.set("time_of_day", float(shot["time"]))
	var player := _main.get_node_or_null("Player") as Node3D
	if player:
		var p: Vector3 = shot["pos"]
		var noise := TerrainNoise.new(GameManager.world_seed)
		player.global_position = Vector3(p.x, noise.get_height(p.x, p.z) + 1.1, p.z)
		player.rotation.y = atan2(-(float(shot["target"].x) - p.x), -(float(shot["target"].z) - p.z))
	_camera.global_position = shot["cam"]
	_camera.look_at(shot["target"], Vector3.UP)
