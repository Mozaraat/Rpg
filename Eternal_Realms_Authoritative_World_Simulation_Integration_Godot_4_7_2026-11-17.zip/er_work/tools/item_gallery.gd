extends Node
# Renders every item model in labelled pages for visual review.

const OUT_DIR := "res://captures"
const COLS := 12
const ROWS := 3
const PAGE_SIZE := COLS * ROWS
const GAP_X := 1.16
const GAP_Z := 1.40

var _page := 0
var _timer := 0.0
var _ids: Array = []
var _holder: Node3D
var _total_pages := 1

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1600, 900)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT_DIR))
	_build_stage()

	var order := {"weapon": 0, "armor": 1, "consumable": 2, "material": 3}
	var keys: Array = ItemDB.ITEMS.keys()
	keys.sort_custom(func(a, b):
		var ta: int = order.get(ItemDB.ITEMS[a].get("type", "material"), 9)
		var tb: int = order.get(ItemDB.ITEMS[b].get("type", "material"), 9)
		if ta != tb:
			return ta < tb
		return str(a) < str(b)
	)
	_ids = keys
	_total_pages = int(ceil(float(_ids.size()) / float(PAGE_SIZE)))
	_show_page(0)

func _build_stage() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.055, 0.06, 0.075)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.60, 0.65, 0.78)
	env.ambient_light_energy = 0.75
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -36.0, 0.0)
	sun.light_energy = 1.7
	sun.light_color = Color(1.0, 0.95, 0.86)
	sun.shadow_enabled = true
	add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-28.0, 142.0, 0.0)
	fill.light_energy = 0.55
	fill.light_color = Color(0.55, 0.66, 0.92)
	add_child(fill)

	var floor_mesh := PlaneMesh.new()
	floor_mesh.size = Vector2(30.0, 14.0)
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.13, 0.135, 0.15)
	fm.roughness = 0.9
	var floor := MeshInstance3D.new()
	floor.mesh = floor_mesh
	floor.material_override = fm
	floor.position.y = -0.02
	add_child(floor)

	var cam := Camera3D.new()
	cam.fov = 52.0
	cam.position = Vector3(0.0, 5.6, 6.6)
	add_child(cam)
	cam.look_at(Vector3(0.0, 0.35, -0.15), Vector3.UP)
	cam.current = true

func _show_page(page: int) -> void:
	if _holder:
		_holder.queue_free()
	_holder = Node3D.new()
	add_child(_holder)
	var start: int = page * PAGE_SIZE
	for i in range(PAGE_SIZE):
		var idx: int = start + i
		if idx >= _ids.size():
			break
		var id: String = str(_ids[idx])
		var row: int = i / COLS
		var col: int = i % COLS
		var root := Node3D.new()
		root.position = Vector3((float(col) - float(COLS - 1) * 0.5) * GAP_X, 0.10, (float(row) - float(ROWS - 1) * 0.5) * GAP_Z)
		root.add_child(ItemVisuals.make(id))
		var label := Label3D.new()
		label.text = ItemDB.def(id).get("name", id)
		label.font_size = 20
		label.pixel_size = 0.0032
		label.modulate = Color(0.90, 0.92, 0.96)
		label.outline_size = 6
		label.outline_modulate = Color(0.05, 0.05, 0.07, 0.9)
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.position = Vector3(0.0, -0.04, 0.42)
		root.add_child(label)
		_holder.add_child(root)
	print("ITEM_GALLERY page %d/%d items=%d" % [page + 1, _total_pages, mini(PAGE_SIZE, _ids.size() - start)])

func _process(delta: float) -> void:
	if _holder == null:
		return
	_holder.rotate_y(delta * 0.0)
	_timer += delta
	if _timer < 1.4:
		return
	_timer = 0.0
	var image := get_viewport().get_texture().get_image()
	var path := "%s/items_%02d.png" % [OUT_DIR, _page + 1]
	var err := image.save_png(path)
	print("CAPTURE %s err=%d" % [path, err])
	_page += 1
	if _page >= _total_pages:
		get_tree().quit()
	else:
		_show_page(_page)
