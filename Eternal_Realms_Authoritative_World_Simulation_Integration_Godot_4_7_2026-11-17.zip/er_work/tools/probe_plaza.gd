extends Node

# Temporary probe: list meshes near the village plaza so an unidentified
# blue structure can be traced back to its builder.

var _t := 0.0

func _ready() -> void:
	add_child((load("res://scenes/main.tscn") as PackedScene).instantiate())

func _process(delta: float) -> void:
	_t += delta
	if _t < 2.5:
		return
	var center := Vector3(TerrainNoise.VILLAGE_CENTER.x, TerrainNoise.VILLAGE_HEIGHT, TerrainNoise.VILLAGE_CENTER.y)
	print("PLAZA_PROBE center=", center)
	_scan(get_tree().root, center)
	get_tree().quit()

func _scan(node: Node, center: Vector3) -> void:
	if node is MeshInstance3D:
		var m := node as MeshInstance3D
		var d: float = m.global_position.distance_to(center)
		if d < 18.0:
			var mat_name := "-"
			if m.material_override:
				mat_name = m.material_override.resource_path
			elif m.mesh and m.mesh.get_surface_count() > 0:
				var mat := m.mesh.surface_get_material(0)
				if mat:
					mat_name = mat.resource_path if mat.resource_path != "" else mat.get_class()
			print("PLAZA_MESH d=%.1f pos=%s aabb=%s parent=%s node=%s mat=%s" % [
				d, str(m.global_position), str(m.get_aabb().size), m.get_parent().name, m.name, mat_name])
	for c in node.get_children():
		_scan(c, center)
