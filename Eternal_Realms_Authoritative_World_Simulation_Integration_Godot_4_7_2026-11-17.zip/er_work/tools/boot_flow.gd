extends Node

# End-to-end check of the real startup path: boot screen -> Begin New Adventure
# -> threaded load of main.tscn -> live main world. Uses the boot screen's own
# _begin() entry point, then instantiates the loaded scene so this harness can
# observe it (change_scene_to_packed would free this test node).
#
# Run: godot --headless --path . res://tools/boot_flow.tscn

const MAIN_SCENE := "res://scenes/main.tscn"

var _boot: Control
var _t := 0.0
var _stage := 0
var _frames := 0
var _main: Node

func _ready() -> void:
	var packed: PackedScene = load("res://scenes/boot.tscn")
	_boot = packed.instantiate() as Control
	add_child(_boot)

func _process(delta: float) -> void:
	_t += delta
	match _stage:
		0:
			if _t > 0.4:
				_stage = 1
				_boot.call("_begin", false)
				print("FLOW boot._begin(false) requested")
		1:
			var progress: Array = []
			var status := ResourceLoader.load_threaded_get_status(MAIN_SCENE, progress)
			if status == ResourceLoader.THREAD_LOAD_LOADED:
				var packed := ResourceLoader.load_threaded_get(MAIN_SCENE) as PackedScene
				if packed == null:
					push_error("FLOW main.tscn failed to instantiate")
					get_tree().quit(1)
					return
				_main = packed.instantiate()
				get_tree().root.add_child.call_deferred(_main)
				_stage = 2
				print("FLOW main scene instantiated")
			elif status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				push_error("FLOW threaded load failed status=%d" % status)
				get_tree().quit(1)
			elif _t > 60.0:
				push_error("FLOW load timeout")
				get_tree().quit(1)
		2:
			_frames += 1
			if _frames == 90:
				var ok := true
				for path in ["Player", "DayNightCycle", "WorldEnvironment"]:
					if _main.get_node_or_null(path) == null:
						push_error("FLOW missing node: " + path)
						ok = false
				print("FLOW OK scene children=%d frames=%d" % [_main.get_child_count(), _frames])
				get_tree().quit(0 if ok else 1)
