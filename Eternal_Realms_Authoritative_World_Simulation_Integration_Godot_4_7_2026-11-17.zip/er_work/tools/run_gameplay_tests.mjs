import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sandbox = path.resolve(project, '../.gameplay-validation');
const executable = process.env.GODOT_EXE;
if (!executable) throw new Error('Set GODOT_EXE to the Godot console executable.');
fs.mkdirSync(sandbox, { recursive: true });
function copyTree(source, target) {
  fs.mkdirSync(target, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    if (['backend', 'captures', '.git', '.qoder', 'shader_cache', 'editor', 'node_modules'].includes(entry.name)) continue;
    const from = path.join(source, entry.name);
    const to = path.join(target, entry.name);
    if (entry.isDirectory()) copyTree(from, to);
    else if (entry.isFile()) {
      if (from.includes(`${path.sep}.godot${path.sep}`) || from.includes(`${path.sep}assets${path.sep}`)) {
        if (!fs.existsSync(to)) fs.linkSync(from, to);
      } else fs.copyFileSync(from, to);
    }
  }
}
copyTree(project, sandbox);
const config = fs.readFileSync(path.join(project, 'project.godot'), 'utf8');
if (!config.includes('config/name="Eternal Realms: Awakened"')) throw new Error('Cannot isolate unknown project configuration.');
fs.writeFileSync(path.join(sandbox, 'project.godot'), config.replace('config/name="Eternal Realms: Awakened"', 'config/name="Eternal Realms Gameplay Validation"\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="Eternal Realms Gameplay Validation"'));
const visual = process.argv.includes('--visual');
const audit = process.argv.includes('--audit');
const result = spawnSync(executable, [...(visual ? ['--windowed', '--resolution', '1280x720'] : ['--headless']), '--path', sandbox, audit ? 'res://tools/script_audit.tscn' : 'res://tools/gameplay_validation.tscn'], { encoding: 'utf8', timeout: 240000, maxBuffer: 24 * 1024 * 1024 });
process.stdout.write(result.stdout ?? '');
process.stderr.write(result.stderr ?? '');
if (result.error) console.error(result.error);
if (fs.existsSync(path.join(sandbox, 'captures', 'validation'))) {
  fs.mkdirSync(path.join(project, 'captures', 'validation'), { recursive: true });
  fs.cpSync(path.join(sandbox, 'captures', 'validation'), path.join(project, 'captures', 'validation'), { recursive: true });
}
const errors = /SCRIPT ERROR:|ERROR:|VALIDATION_FAIL/.test(`${result.stdout}\n${result.stderr}`);
process.exit(result.status === 0 && !errors ? 0 : 1);
