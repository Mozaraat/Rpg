extends SceneTree

# Temporary terrain probe: prints height / biome / region / forest density for
# candidate camera viewpoints so screenshot framing can be chosen on real data.

func _init() -> void:
	var t := TerrainNoise.new(42)
	var pts := [
		Vector2(-25, -12), Vector2(-25, -8), Vector2(-25, -50),
		Vector2(-12, 2), Vector2(10, -20), Vector2(-40, -30),
		Vector2(-55, 28), Vector2(-70, 40), Vector2(-5, -60),
		Vector2(38, -58), Vector2(50, -40), Vector2(20, -80),
		Vector2(-120, -90), Vector2(-100, 20), Vector2(70, 10),
		Vector2(-25, -140), Vector2(-200, -150), Vector2(120, -120),
	]
	print("TREE_PROBE seed=", t.world_seed)
	for p in pts:
		var h: float = t.get_height(p.x, p.y)
		var biome: int = int(t.get_biome(p.x, p.y, h))
		print("PT (%.0f,%.0f) h=%.2f region=%s forest=%.2f biome=%d" % [
			p.x, p.y, h, t.get_region_name(p.x, p.y),
			t.get_forest_density(p.x, p.y, h), biome])
	quit()
