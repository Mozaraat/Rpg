extends Node

# Temporary UI inspector: dumps visible Control nodes that look like banners or bars.

var _t := 0.0
var _moved := false

func _ready() -> void:
	var packed: PackedScene = load("res://scenes/main.tscn")
	add_child(packed.instantiate())

func _process(delta: float) -> void:
	_t += delta
	if _t > 2.0 and not _moved:
		_moved = true
		var player: Node3D = GameManager.player
		if player:
			player.global_position = Vector3(24.0, 8.0, -48.0)
			print("UI_DUMP moved player to ", player.global_position)
	if _t < 4.5:
		return
	_dump(get_tree().root, 0)
	get_tree().quit()

func _dump(node: Node, depth: int) -> void:
	if node is Control:
		var c := node as Control
		if c.is_visible_in_tree():
			var text := ""
			if c is Label:
				text = (c as Label).text
			elif c is Button:
				text = (c as Button).text
			var extra := (" text=%s" % text) if text != "" else ""
			print("UI_DUMP %s class=%s name=%s pos=%s size=%s visible=%s%s" % [
				"  ".repeat(depth), c.get_class(), c.name,
				str(c.global_position), str(c.size), str(c.visible), extra])
	for child in node.get_children():
		_dump(child, depth + 1)
