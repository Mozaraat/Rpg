import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

project = Path(__file__).resolve().parent.parent
sandbox = project.parent / '.gameplay-validation'
executable = os.environ['GODOT_EXE']
excluded = {'backend', 'captures', '.git', '.qoder', 'shader_cache', 'editor', 'node_modules'}
for source, directories, files in os.walk(project):
    directories[:] = [name for name in directories if name not in excluded]
    relative = Path(source).relative_to(project)
    target = sandbox / relative
    target.mkdir(parents=True, exist_ok=True)
    for name in files:
        destination = target / name
        original = Path(source) / name
        if '.godot' in relative.parts or 'assets' in relative.parts:
            if not destination.exists():
                os.link(original, destination)
        else:
            shutil.copy2(original, destination)
config = (project / 'project.godot').read_text(encoding='utf-8')
assert 'config/name="Eternal Realms: Awakened"' in config, 'Cannot isolate unknown project configuration'
config = config.replace('config/name="Eternal Realms: Awakened"', 'config/name="Eternal Realms Gameplay Validation"\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="Eternal Realms Gameplay Validation"')
(sandbox / 'project.godot').write_text(config, encoding='utf-8')
visual = '--visual' in sys.argv
scene = 'res://tools/script_audit.tscn' if '--audit' in sys.argv else 'res://tools/gameplay_validation.tscn'
command = [executable] + (['--windowed', '--resolution', '1280x720'] if visual else ['--headless']) + ['--path', str(sandbox), scene]
result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=240)
print(result.stdout)
print(result.stderr, file=sys.stderr)
if (sandbox / 'captures/validation').exists():
    shutil.copytree(sandbox / 'captures/validation', project / 'captures/validation', dirs_exist_ok=True)
sys.exit(0 if result.returncode == 0 and not re.search(r'SCRIPT ERROR:|ERROR:|VALIDATION_FAIL', result.stdout + result.stderr) else 1)
