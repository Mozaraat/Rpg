extends Node

# Development screenshot harness for the boot / title screen.

const OUT := "res://captures/00_boot_title.png"

var _t := 0.0

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	var packed: PackedScene = load("res://scenes/boot.tscn")
	var boot := packed.instantiate()
	add_child(boot)

func _process(delta: float) -> void:
	_t += delta
	if _t < 1.2:
		return
	var image := get_viewport().get_texture().get_image()
	var err := image.save_png(OUT)
	print("CAPTURE %s err=%d" % [OUT, err])
	get_tree().quit()
