extends Node

# Development review harness for the wild biomes and dungeon interiors.
# Renders the rainforest, jungle, river systems and a few underground floors
# from fixed cinematic cameras so their dressing can be reviewed directly.

const OUT_DIR := "res://captures/review"

var _main: Node3D
var _camera: Camera3D
var _noise: TerrainNoise
var _shot := 0
var _phase := 0
var _phase_t := 0.0

var _shots := [
	{"name": "10_rainforest_canopy", "time": 0.31, "anchor": Vector2(-450, 120),
		"cam": Vector3(-46, 30, 68), "target": Vector3(4, 8, -12), "wait": 9.0},
	{"name": "11_rainforest_floor", "time": 0.33, "anchor": Vector2(-450, 120),
		"cam": Vector3(10.5, 2.2, 13.5), "target": Vector3(-3.0, 3.2, -10.0), "wait": 4.0},
	{"name": "12_jungle_canopy", "time": 0.40, "anchor": Vector2(420, -60),
		"cam": Vector3(40, 28, 66), "target": Vector3(-6, 7, -14), "wait": 9.0},
	{"name": "13_jungle_floor", "time": 0.42, "anchor": Vector2(420, -60),
		"cam": Vector3(-10.0, 2.2, 14.0), "target": Vector3(3.0, 3.0, -9.0), "wait": 4.0},
	{"name": "14_heartlands_river", "time": 0.48, "anchor": Vector2(42, 30), "cam_anchor": Vector2(42, 6),
		"cam": Vector3(0, 11.0, 0), "target": Vector3(-0.5, 0.6, 30), "wait": 7.0},
	{"name": "15_heartlands_waterfall", "time": 0.52, "anchor": Vector2(42, -16), "cam_anchor": Vector2(50, 0),
		"cam": Vector3(0, 4.0, 0), "target": Vector3(0, 4.5, -7.6), "wait": 4.0},
	{"name": "16_wild_river", "time": 0.50, "anchor": Vector2(-148, -49), "cam_anchor": Vector2(-136, -59),
		"cam": Vector3(0, 3.2, 0), "target": Vector3(-29, 0.9, 34), "wait": 8.0},
	{"name": "17_rainforest_stream", "time": 0.36, "anchor": Vector2(-452, 130), "cam_anchor": Vector2(-441, 142),
		"cam": Vector3(0, 2.8, 0), "target": Vector3(-37, 0.8, -38), "wait": 7.0},
	{"name": "18_jungle_stream", "time": 0.44, "anchor": Vector2(410, -62), "cam_anchor": Vector2(421, -52),
		"cam": Vector3(0, 2.8, 0), "target": Vector3(-39, 0.8, -33), "wait": 7.0},
	{"name": "19_worldroot_baobab", "time": 0.50, "anchor": Vector2(36, 33), "cam_anchor": Vector2(52, 48),
		"cam": Vector3(0, 10.0, 0), "target": Vector3(-7, 12.0, -7), "wait": 6.0},
	{"name": "24_river_bridge", "time": 0.50, "anchor": Vector2(43, 70), "cam_anchor": Vector2(58, 88),
		"cam": Vector3(0, 5.0, 0), "target": Vector3(0, 3.0, 0), "wait": 6.0},
	{"name": "20_dungeon_labyrinth", "floor": 0, "cam_local": Vector3(-18.0, 4.8, -28.0), "target_local": Vector3(-42.0, 2.6, -33.0), "wait": 3.0},
	{"name": "21_dungeon_living_caverns", "floor": 10, "cam_local": Vector3(0.0, 5.4, -18.0), "target_local": Vector3(0.0, 2.6, -58.0), "wait": 3.5},
	{"name": "22_dungeon_crystal_depths", "floor": 20, "cam_local": Vector3(13.0, 6.4, 104.0), "target_local": Vector3(-3.0, 3.2, 95.0), "wait": 3.5},
	{"name": "23_dungeon_boss_arena", "floor": 0, "cam_local": Vector3(0.0, 5.6, 40.0), "target_local": Vector3(0.0, 5.2, 66.0), "wait": 3.0},
	{"name": "25_side_dungeon_adit", "time": 0.42, "anchor": Vector2(-92, -82), "cam_anchor": Vector2(-81, -71),
		"cam": Vector3(0, 3.2, 0), "target": Vector3(0, 4.6, 0), "wait": 3.0},
	{"name": "26_side_dungeon_hall", "side": Vector2(-92, -82), "cam_local": Vector3(-9.0, 2.6, 8.5),
		"target_local": Vector3(4.0, 1.4, -5.0), "wait": 3.5},
	{"name": "27_side_dungeon_vault", "side": Vector2(-92, -82), "cam_local": Vector3(72.0, 2.6, 6.0),
		"target_local": Vector3(84.0, 1.6, -2.0), "wait": 3.5},
	{"name": "28_ironback_adit", "time": 0.45, "anchor": Vector2(200, -60), "cam_anchor": Vector2(212, -68),
		"cam": Vector3(0, 3.2, 0), "target": Vector3(0, 4.6, 0), "wait": 3.0},
]

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT_DIR))
	_noise = TerrainNoise.new(GameManager.world_seed)
	var packed: PackedScene = load("res://scenes/main.tscn")
	_main = packed.instantiate() as Node3D
	add_child(_main)
	for child in _main.get_children():
		if child is CanvasLayer:
			child.visible = false
	_camera = Camera3D.new()
	_camera.name = "ReviewCamera"
	_camera.fov = 72.0
	_camera.near = 0.08
	_camera.far = 1400.0
	add_child(_camera)
	_camera.current = true

func _process(delta: float) -> void:
	if _shot >= _shots.size():
		return
	_phase_t += delta
	var shot: Dictionary = _shots[_shot]
	if _phase == 0:
		if _phase_t < 1.6:
			return
		_apply_shot(shot)
		_phase = 1
		_phase_t = 0.0
	elif _phase_t >= float(shot.get("wait", 4.0)):
		var image := get_viewport().get_texture().get_image()
		var path := "%s/%s.png" % [OUT_DIR, str(shot["name"])]
		var err := image.save_png(path)
		print("REVIEW %s err=%d" % [path, err])
		_shot += 1
		_phase = 0
		_phase_t = 0.0
		if _shot >= _shots.size():
			get_tree().quit()

func _apply_shot(shot: Dictionary) -> void:
	if shot.has("floor"):
		_apply_dungeon_shot(shot)
		return
	if shot.has("side"):
		_apply_side_dungeon_shot(shot)
		return
	_restore_overworld()
	var cycle := _main.get_node_or_null("DayNightCycle")
	if cycle:
		cycle.set("time_of_day", float(shot["time"]))
	var anchor: Vector2 = shot["anchor"]
	var ground := _noise.get_height(anchor.x, anchor.y)
	var cam_anchor: Vector2 = shot.get("cam_anchor", anchor)
	var cam_ground := _noise.get_height(cam_anchor.x, cam_anchor.y)
	var player := _main.get_node_or_null("Player") as Node3D
	if player:
		player.global_position = Vector3(anchor.x, ground + 1.2, anchor.y)
		player.velocity = Vector3.ZERO
	_camera.global_position = Vector3(cam_anchor.x, cam_ground, cam_anchor.y) + (shot["cam"] as Vector3)
	_camera.look_at(Vector3(anchor.x, ground, anchor.y) + (shot["target"] as Vector3), Vector3.UP)
	_camera.current = true

func _apply_dungeon_shot(shot: Dictionary) -> void:
	var ds := _main.get_node_or_null("DungeonSystem")
	if ds == null:
		return
	var floor_i: int = int(shot["floor"])
	var room: Node3D = ds.call("_ensure_room", floor_i)
	ds.call("_apply_dungeon_environment", floor_i)
	ds.call("_show_floor", floor_i)
	var origin: Vector3 = room.global_position
	_camera.global_position = origin + (shot["cam_local"] as Vector3)
	_camera.look_at(origin + (shot["target_local"] as Vector3), Vector3.UP)
	_camera.current = true

func _apply_side_dungeon_shot(shot: Dictionary) -> void:
	var p: Vector2 = shot["side"]
	var surface := _noise.get_height(p.x, p.y)
	var origin := Vector3(p.x, surface - 46.0, p.y)
	# The caves run on their own dark environment, so the shot matches the game.
	var exploration := _main.get_node_or_null("EnvironmentalExploration")
	if exploration and exploration.has_method("_apply_cave_environment"):
		exploration.call("_apply_cave_environment", true)
	_camera.global_position = origin + (shot["cam_local"] as Vector3)
	_camera.look_at(origin + (shot["target_local"] as Vector3), Vector3.UP)
	_camera.current = true

func _restore_overworld() -> void:
	var ds := _main.get_node_or_null("DungeonSystem")
	if ds and bool(ds.get("inside")) == false:
		ds.call("_restore_overworld_environment")
	var exploration := _main.get_node_or_null("EnvironmentalExploration")
	if exploration and exploration.has_method("_apply_cave_environment"):
		exploration.call("_apply_cave_environment", false)
