extends Node

# Temporary probe: verify frontier outposts resolve to dry, open ground away
# from settlement centres.

var _t := 0.0

func _ready() -> void:
	add_child((load("res://scenes/main.tscn") as PackedScene).instantiate())

func _process(delta: float) -> void:
	_t += delta
	if _t < 3.0:
		return
	var noise := TerrainNoise.new(GameManager.world_seed)
	for node in get_tree().root.find_children("SectFrontierOutpost_*", "Node3D", true, false):
		var n := node as Node3D
		var h: float = noise.get_height(n.global_position.x, n.global_position.z)
		var mask: float = noise.settlement_mask(n.global_position.x, n.global_position.z)
		print("OUTPOST %s pos=%s terrain_h=%.2f settlement_mask=%.2f" % [
			n.name, str(n.global_position), h, mask])
	get_tree().quit()
