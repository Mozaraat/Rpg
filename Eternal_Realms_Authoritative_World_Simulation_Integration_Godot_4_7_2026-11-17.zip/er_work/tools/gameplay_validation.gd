extends Node

var failures := 0
var checks := 0
var main: Node3D
var camera: Camera3D

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("VALIDATION_FAIL " + message)

func _ready() -> void:
	if not OS.get_user_data_dir().contains("Gameplay Validation"):
		push_error("Run through tools/run_gameplay_tests.py to isolate save files.")
		get_tree().quit(1)
		return
	GameManager.time_scale = 0.0
	WorldLifeSimulation.set_process(false)
	MMORPGWorldState.world_state["dungeon_clears"] = {}
	var maze := DungeonSystem.new()
	var shortest := 9999
	for seed_value in [42, 71, 9876]:
		GameManager.world_seed = seed_value
		for f in range(100):
			maze._generate_maze(f)
			var distances := maze._maze_distances(maze.MAZE_START)
			check(distances.size() == 169, "all cells connected: seed %d floor %d" % [seed_value, f])
			shortest = mini(shortest, int(distances.get(maze.MAZE_GOAL, 0)))
			var boundary_links := 0
			var rect: Rect2i = maze.CHAMBER_RECTS.back()
			for cell in maze._maze_cells:
				if not rect.has_point(cell):
					continue
				for direction in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.UP, Vector2i.DOWN]:
					if not rect.has_point(cell + direction) and maze._maze_has_link(cell, cell + direction):
						boundary_links += 1
			check(boundary_links == 1, "boss chamber has one entrance")
			var links := maze._maze_links.duplicate()
			maze._generate_maze(f)
			check(links == maze._maze_links, "maze generation deterministic")
	check(shortest > 12, "boss route is longer than the old direct avenue")
	print("MAZE_TEST floors=300 shortest_route_cells=", shortest)
	maze.free()
	GameManager.world_seed = 42
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(0.5).timeout
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var player: Player = GameManager.player
	var dungeon: DungeonSystem = main.get_node("DungeonSystem")
	dungeon._cleared_floors.clear()
	check(not dungeon.is_boss_defeated(), "missing boss does not unlock floor")
	var room := dungeon._ensure_room(0)
	dungeon.inside = true
	dungeon.add_to_group("dungeon_active")
	dungeon._show_floor(0)
	dungeon._apply_dungeon_environment(0)
	player.global_position = room.global_position + dungeon._maze_cell_position(dungeon.MAZE_START) + Vector3.UP * 0.4
	dungeon._explored_cells.clear()
	dungeon._reveal_player_cell()
	check(dungeon.get_explored_cells().size() == 1, "map reveals only visited cells")
	check(not dungeon.has_discovery(0, "boss_chamber"), "boss chamber initially hidden")
	dungeon._spawn_floor_content(0)
	check(dungeon._farming_slots[0].size() == 72, "floor one contains 24 farming packs")
	var slot: Dictionary = dungeon._farming_slots[0][0]
	var monster: Monster = slot.node
	monster.health.take_damage(monster.health.current_health + 1.0, player)
	check(slot.node == null and float(slot.ready_at) > Time.get_ticks_msec() / 1000.0, "killed pack member gets respawn cooldown")
	slot.ready_at = 0.0
	player.global_position = room.global_position + dungeon._maze_cell_position(slot.cell)
	dungeon._tick_farming()
	check(slot.node == null, "no monster respawn beside a player")
	player.global_position = room.global_position + dungeon._maze_cell_position(dungeon.MAZE_START)
	dungeon._tick_farming()
	check(is_instance_valid(slot.node), "unoccupied farming spawn replenishes")
	await get_tree().physics_frame
	for cell in dungeon._maze_cells:
		for direction in [Vector2i.RIGHT, Vector2i.DOWN]:
			var next: Vector2i = cell + direction
			if not dungeon._maze_has_link(cell, next):
				continue
			var midpoint := room.global_position + (dungeon._maze_cell_position(cell) + dungeon._maze_cell_position(next)) * 0.5 + Vector3.UP * 1.3
			var axis := Vector3(direction.x, 0, direction.y)
			check(clear_ray(midpoint - axis * 1.0, midpoint + axis * 1.0), "generated open edge has no wall")
	var cave := SideDungeon.build_complex(main, Vector3(1400, -600, 1400), Color.CYAN, 42, [], [], "iron_ore")
	await get_tree().physics_frame
	var cave_origin: Vector3 = cave.root.global_position
	check(clear_ray(cave_origin + Vector3(9, 1.3, 3), cave_origin + Vector3(31, 1.3, 3)), "first cave passage traversable")
	check(clear_ray(cave_origin + Vector3(53, 1.3, 1), cave_origin + Vector3(73, 1.3, 1)), "second cave passage traversable")
	camera = Camera3D.new()
	camera.fov = 72
	main.add_child(camera)
	camera.global_position = room.global_position + Vector3(0, 3.2, -92)
	camera.look_at(room.global_position + Vector3(0, 2.4, -70))
	camera.current = true
	dungeon._toggle_dungeon_map()
	await capture("01_unexplored_map")
	dungeon._toggle_dungeon_map()
	await capture("02_maze_entrance")
	player.global_position = room.global_position + dungeon._boss_arena_center()
	dungeon._reveal_player_cell()
	check(dungeon.has_discovery(0, "boss_chamber"), "entering sanctum discovers boss chamber")
	camera.global_position = room.global_position + Vector3(-14, 4.4, 64)
	camera.look_at(room.global_position + Vector3(0, 3.0, 83))
	await capture("03_raid_sanctum")
	var boss: Monster = dungeon._floor_boss
	boss.health.take_damage(boss.health.current_health + 1.0, player)
	check(dungeon.is_boss_defeated(), "boss death unlocks floor")
	check(MMORPGWorldState.get_world_value("dungeon_clears", "0", {}).has("cleared_at"), "floor clear persisted in world state")
	var gold_after_clear := PlayerData.gold
	dungeon._on_floor_boss_died(player, 0)
	check(PlayerData.gold == gold_after_clear, "duplicate death does not repeat rewards")
	var second_view := DungeonSystem.new()
	await second_view._load_shared_clears()
	check(second_view.is_boss_defeated(), "another dungeon instance reads the shared clear")
	second_view.free()
	var provider = load("res://systems/sect_civilization_presence.gd").new()
	for index in range(3):
		var actor: Node3D = provider._make_disciple("Azure Sword Hall", Color(0.3, 0.5, 0.9), index, index == 0)
		room.add_child(actor)
		actor.position = Vector3(-3.0 + index * 3.0, 0.4, -91)
		var model: CharacterModel = actor.get_node("CharacterModel")
		check(model._asset_root != null, "sect NPC uses a rigged asset")
	provider.free()
	camera.global_position = room.global_position + Vector3(0, 2.4, -85)
	camera.look_at(room.global_position + Vector3(0, 1.5, -91))
	await capture("04_sect_characters")
	var region := {"name": "Test Settlement", "economy": {"food": 2.0, "timber": 10.0, "ore": 10.0, "herbs": 10.0}, "resources": {"herbs": 50.0, "ore": 5.0}, "territory_pressure": {}, "settlement_supply": 100.0}
	WorldLifeSimulation._state["governance_policy"] = "provisioning"
	WorldLifeSimulation._govern_region("test", region)
	check(region.economy.food == 10.0 and region.resources.herbs == 46.0, "governor provisioned food with finite costs")
	WorldLifeSimulation._state["governance_policy"] = "hands_off"
	var before := region.duplicate(true)
	WorldLifeSimulation._govern_region("test", region)
	check(region == before, "hands-off governance takes no action")
	check(not WorldLifeSimulation.set_governance_policy("arbitrary"), "unknown governance policy rejected")
	WorldLifeSimulation._state["governance_policy"] = "security"
	region.territory_pressure = {"raiders": 70.0}
	WorldLifeSimulation._govern_region("test", region)
	check(region.territory_pressure.raiders == 64.0 and region.economy.ore == 9.0, "governor funds a defensive patrol")
	var menu: GameMenu = get_tree().get_first_node_in_group("game_menu")
	menu.open_tab(GameMenu.Tab.JOURNAL)
	await capture("05_field_journal")
	menu.close_menu()
	GameManager.game_time_seconds = 300000.0
	player._handle_aging(0.0)
	var age := player.current_age
	PlayerData.gold = 200
	var skill_values := player.skills.to_dict().duplicate(true)
	player.health.take_damage(player.health.current_health + 1.0, null)
	check(PlayerData.gold == 190, "combat death costs five percent gold")
	check(player.skills.to_dict() == skill_values, "combat death retains skills")
	await capture("06_death_penalties")
	await player.respawn_at_sanctuary()
	check(not player.health.is_dead and not dungeon.inside, "respawn ejects dungeon and revives")
	check(is_equal_approx(player.current_age, age), "respawn retains age")
	check(is_equal_approx(player.health.current_health, player.health.max_health * 0.5), "respawn restores half health")
	player.health.take_damage(player.health.current_health + 1.0, null)
	check(PlayerData.gold == 180, "a second death charges exactly once")
	await player.respawn_at_sanctuary()
	PlayerData.gold = 0
	player.health.take_damage(player.health.current_health + 1.0, null)
	check(PlayerData.gold == 0, "death cannot produce negative gold")
	await player.respawn_at_sanctuary()
	GameManager.game_time_seconds = (80.0 - Constants.STARTING_AGE) / 0.0001
	player._handle_aging(0.0)
	check(player.health.is_dead and PlayerData.stats.death_cause == "old_age", "mortal lifespan expires")
	await player.respawn_at_sanctuary()
	check(player.health.is_dead, "combat respawn cannot bypass old age")
	check(SkillSystem.REALM_LIFESPANS[2] > SkillSystem.REALM_LIFESPANS[0] and is_inf(SkillSystem.REALM_LIFESPANS.back()), "cultivation extends lifespan to immortality")
	for i in range(60):
		LivingEcosystem.simulate_tick()
	var eco: Dictionary = LivingEcosystem.get_report().species
	for id in eco.keys():
		var cap := float(LivingEcosystem.species_def(id).cap) * 1.6
		check(eco[id].adults > 0 and eco[id].adults + eco[id].young <= cap, "ecosystem keeps %s alive and bounded" % id)
	print("ECOSYSTEM ", eco, " emerged=", LivingEcosystem.get_report().emerged)
	await get_tree().process_frame
	print("GAMEPLAY_VALIDATION checks=%d failures=%d" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)

func clear_ray(from: Vector3, to: Vector3) -> bool:
	var query := PhysicsRayQueryParameters3D.create(from, to, Constants.LAYER_WORLD)
	return main.get_world_3d().direct_space_state.intersect_ray(query).is_empty()

func capture(label: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await get_tree().create_timer(0.35).timeout
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute("res://captures/validation")
	check(get_viewport().get_texture().get_image().save_png("res://captures/validation/" + label + ".png") == OK, "capture " + label)
