# Eternal Realms — Persistent Dungeon Campaigns (2026)

## Implemented
- Added `DungeonCampaign`, a persistent campaign ledger for all ten dungeon civilizations.
- Factions retain strength, morale, victories, defeats, leader status, protective retinues, temporary alliances, controlled floors and a rolling 30-entry history.
- Real autonomous faction-on-faction casualties update campaign victories/defeats; commander deaths are recorded as leadership defeats.
- Defeated factions gradually rebuild strength and morale. A successor can emerge and rebuild a defeated leader's guard.
- Factions can negotiate temporary alliances when morale is low. Allied factions no longer treat one another as hostile targets in dungeon combat AI.
- Capturing a faction shrine records persistent floor ownership and the previous owner's defeat. Strong rival factions can retake weakly held faction territory; very hostile factions can rarely retake expedition-held rooms.
- Player rescue, shrine-claim and skirmish choices update civilization reputation, influence, morale and strength.
- Campaign state is embedded in the normal save file. On load, the campaign simulates capped offline time (up to seven days) so factions continue rebuilding and diplomacy expires while away.
- Restored room ownership influences faction shrine ownership metadata and visual tint when the floor is regenerated.

## Integration
- Added `systems/dungeon_campaign_system.gd` as the `DungeonCampaign` autoload.
- Integrated save/load through `systems/save_system.gd`.
- Integrated campaign reputation and territory outcomes through `entities/dungeon_faction_encounter.gd`.
- Integrated faction casualty tracking and alliance-aware combat targeting through `entities/monster.gd`.
- Linked floor faction identities in `systems/dungeon_system.gd`.

## Verification
- Source archive integrity checked before editing; output archive integrity checked after packaging.
- Static integration checks confirm the autoload, save payload, load restoration and combat/encounter hooks are present.
- Godot 4.6 is not installed in this environment; engine parsing, runtime battle behaviour, scene restoration and balancing still require an in-engine test.
