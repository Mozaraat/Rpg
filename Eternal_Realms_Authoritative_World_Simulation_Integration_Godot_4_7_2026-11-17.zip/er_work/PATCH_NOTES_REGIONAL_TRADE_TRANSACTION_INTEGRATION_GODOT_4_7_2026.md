# Eternal Realms — Regional Trade Transaction Integration

## Implemented

- Successful authoritative player merchant purchases now feed back into the regional economy ledger after the central merchant transaction commits.
- Commodity mappings connect common purchased goods to regional food, herb, timber and ore stock.
- Merchant purchases also decrement the matching local LivingWorldSystem business stock when a matching business owner is present.
- Caravan cargo is now reserved and deducted from the origin region at departure.
- Shipment reservations are persisted in the authoritative living-world state with stable shipment IDs and explicit `in_transit`, `delivered` and `lost` states.
- Arrival transfers reserved cargo to the destination. An ambush marks the reserved cargo lost rather than deducting origin stock at journey completion.
- Shipment resolution is idempotent: a repeated resolve cannot deliver the same cargo twice. Completed reservation history is bounded.
- Caravan spawning is restricted to the multiplayer authority to prevent clients creating independent duplicate shipments.

## Important backend boundary

The central merchant purchase endpoint remains the authority for the actual player charge. This project change updates regional supply after a committed purchase, but does not claim that the central backend's charged unit price has been dynamically changed by the regional price ledger. That requires a matching server-side API/schema change so the backend can calculate and commit the price atomically with inventory and currency. Do not substitute a client-provided price for that server-side calculation.

## Still outstanding

- Individual villagers physically carrying specific goods between farm/workshop stock and market inventories.
- Caravan visual/entity replication to all connected clients and persistence/recovery of in-transit visual entities after reconnect or server restart.
- Server-side atomic regional price calculation inside the central merchant transaction.
- End-to-end live multiplayer tests for purchase, caravan reservation, ambush, delivery and save/restart recovery.

## Validation boundary

Static source checks and ZIP integrity checks were run. Godot 4.7 was not available in the build environment, so GDScript engine parsing, scene launch, multiplayer runtime and backend transaction tests remain outstanding.
