# Eternal Realms — Systems Audit & Combat/Visual Polish Pass

## Audit findings

- The project already contains a substantial procedural world foundation: streamed terrain chunks, instanced vegetation, terrain/water shaders, day/night lighting, weather, ambient wildlife, settlements, fishing, a dungeon, quests, and skill progression.
- The skill system trains weapon mastery from successful weapon impacts, but monster death handling also awarded Swordsmanship XP regardless of the equipped weapon. Bosses awarded that Swordsmanship XP twice. This was removed; weapon mastery now remains tied to the weapon actually used in combat.
- The project referenced an item icon path using a runtime-formatted filename. This is an intentional dynamic path; no missing literal `res://` resource references were found during the static reference audit.
- Godot 4.6 is not installed in the build environment, so an editor import, runtime launch, and gameplay test could not be performed here.

## New combat features

- Hold **Right Mouse Button** to guard.
- Guarding consumes a dedicated stamina resource; stamina regenerates when not guarding.
- A guard timed within the first 0.24 seconds is a **Perfect Guard**: it completely negates that hit, trains Shield, discovers Riposte, and opens a counterattack window.
- A Riposte empowers the next successful weapon impact, then consumes the counter window.
- Ordinary guards mitigate 58% of incoming damage and train Shield more slowly.
- Attacks are suppressed while the player is actively guarding, preventing accidental simultaneous guard/attack input.
- Added camera impact feedback, dodge dust, expanding emissive impact rings, and stronger technique/guard feedback.
- Added a visible guard stamina bar and control hint to the HUD.

## Graphics polish

- F10 now cycles four quality levels: Low, Medium, High, and Cinematic.
- Cinematic enables stronger screen-space ambient occlusion and screen-space indirect lighting, 8x MSAA, longer directional shadow distance, and richer volumetric fog/glow settings.
- Cinematic is intentionally optional because it can be expensive on lower-end GPUs.

## Controls

- WASD: move
- Shift: run
- Space: jump
- Left Mouse Button: attack
- Right Mouse Button: guard / perfect guard timing
- Left Ctrl: dodge
- E: interact
- F10: cycle graphics quality

## Validation performed

- ZIP integrity checked after packaging.
- Static `res://` reference scan: no missing literal resource references.
- Basic delimiter checks passed for all modified GDScript files.
- Not runtime-validated: Godot executable unavailable in the environment. Please import and run the project in Godot 4.6 before treating this as release-ready.
