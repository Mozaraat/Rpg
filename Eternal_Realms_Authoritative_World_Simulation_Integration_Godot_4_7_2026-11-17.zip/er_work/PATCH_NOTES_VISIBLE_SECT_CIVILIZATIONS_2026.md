# Eternal Realms — Visible Sect Civilizations Milestone

## Purpose
Continue the Living Civilizations & World Simulation build by making cultivation sects physically present in the overworld. This is an additive presentation layer: existing dungeon visuals, authored geography, faction simulation, world bosses, cultivation, settlements and one-world multiplayer systems are preserved.

## Added
- Six sect headquarters are now physically represented in their authored regional locations with raised stone platforms, halls, pillars, banners and readable name/region labels.
- Each headquarters has resident disciples who remain around the compound and perform subtle idle/social movement.
- Each sect fields a visible five-disciple patrol in formation. Patrols travel from their headquarters toward a neighbouring sect territory and return, following terrain height rather than floating above the landscape.
- Presence is proximity-streamed: camps and their actors are created when the player approaches and removed after leaving the area, keeping the active scene bounded.
- Sect headquarters and patrol identities are deterministic from the existing world seed and sect IDs, so clients produce matching cosmetic presence without creating additional world instances.
- Strategic sect state remains in the existing SectSimulation and MMORPGWorldState architecture; this addition does not create a second authority or separate shard.

## Integration
- Added `systems/sect_civilization_presence.gd`.
- Registered `SectCivilizationPresence` in the existing `scenes/main.tscn` scene.
- No existing autoloads, player controls, save schema, dungeon scenes or network identity rules were replaced.

## Validation
- New script delimiter/string scan: clean.
- New script top-level duplicate-function scan: none.
- Main scene script reference and node registration: verified.
- Full-project literal resource-path scan: one apparent `%s` dynamic path in the pre-existing `ui/ui_kit.gd`; it is a formatted resource path, not a missing literal resource.
- ZIP archive integrity: verified with Python ZIP test.

## Runtime boundary
Godot 4.6 is not installed in this build environment. The project has not been engine-imported or launched here. Please open the project in Godot 4.6 to validate GDScript parsing, terrain placement, patrol route visuals, framerate and multiplayer session behaviour. The new patrols/headquarters are presentation entities; they do not independently own strategic combat or shared-world state.
