# Eternal Realms — Sect Masters, Secret Inheritances & Faction Simulation

## Added
- `SectSimulation` autoload: six cultivation sects with named masters, home regions, path identities, rival sects and minimum teaching requirements.
- Sect standing and optional discipleship. Entry requires earned trust; master lessons require both cultivation realm and standing.
- Six secret inheritances distributed across distinct regions. Each records its lore clue, associated path, required realm and rare technique reward.
- Explicit exploration-discovery API (`SectSimulation.record_exploration_discovery(region, landmark_id)`) and direct discovery API (`discover_inheritance(id)`). Discovery is persistent in `PlayerData.stats` and grants the corresponding technique.
- Slow rival-sect tension simulation with occasional conflict/truce world events. Faction report API exposes master, region, standing, rival and tension.
- Regional guild competition score and tier, persisted alongside existing regional commissions. Commission completion contributes to competition, increases the player's guild renown, and regional commission tier scales with both reputation and competition heat.

## Integration notes
- Sect state is stored in `PlayerData.stats` so the existing player save serialization carries it without a second save format.
- The new autoload is registered in `project.godot` after the existing faction systems.
- Existing skill paths and technique dictionaries remain authoritative; sect masters and inheritances teach existing technique IDs rather than creating parallel combat abilities.
- The discovery API is intentionally called by a real landmark/secret interaction when that interaction is wired. It does not reveal secret inheritance locations globally or grant them just for entering a region.

## Validation
- ZIP archive integrity checked after packaging.
- Static project checks cover GDScript inventory, duplicate top-level function declarations, autoload target existence, and fixed `res://` resource references.
- Godot 4.6 runtime import/playtest was not available in this environment; no engine validation is claimed.
