# Eternal Realms — Shared Caravans & Wildlife Fleeing Fix

## Shared multiplayer caravans
- Caravans are spawned and simulated only by the authoritative world host.
- Reliable spawn/despawn messages replicate each unique shipment ID, route, cargo type and quantity to connected players.
- Position/progress and ambush state are broadcast periodically; clients render replicas and do not resolve economy transactions.
- Every cart visibly includes a draft horse, loaded crates and two armed escorts.
- Bandit ambushes create a visible group around the cart. The caravan pauses briefly while the guards contest the ambush; the server then resolves whether the cargo is saved or seized.
- A newly connected player receives a snapshot of all currently active caravans, including route progress, cargo and any ambush state.
- The server alone calls `resolve_caravan_shipment`, preserving the existing reserved-cargo/idempotency flow.

## Wildlife behaviour correction
- Fixed an inverted flee direction: prey previously used the vector pointing toward the player and nearby threats, causing animals to converge on them.
- Wildlife now moves away from the player, hostile creatures and hunter/ranger NPCs.

## Cultivation-world direction
- Recommended architecture: keep the mortal RPG world as the default playable layer and expose a persistent, connected cultivation realm only after discovery and demonstrated cultivation aptitude.
- The cultivation realm should be a separate world layer/zone with its own sect territories and access gates, while preserving shared world identity and cross-layer consequences. Do not reveal public sect headquarters or overt cultivation institutions in the opening mortal experience.

## Validation
- Static scan of all project GDScript files for balanced delimiters and duplicate top-level functions.
- Static scan of literal `res://` references; dynamic format-string resource paths are excluded from static existence checks.
- ZIP archive integrity verified after packaging.
- Godot 4.7 runtime/editor executable is unavailable in this environment; no engine parse, multiplayer session or gameplay test is claimed.

## Known scope boundary
- Caravans replicate during a live server session and late-join snapshots include active shipments. Restoring physical caravan visuals after a server process restart still needs a world-start recovery pass from persisted `in_transit` reservations.
- Ambush outcome is a server-resolved caravan event with shared visual combat staging; it is not yet a full player-targetable bandit squad encounter with individual combat AI and guard health.
