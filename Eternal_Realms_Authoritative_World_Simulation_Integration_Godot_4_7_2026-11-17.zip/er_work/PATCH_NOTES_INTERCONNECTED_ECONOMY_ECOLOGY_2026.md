# Eternal Realms — Interconnected Economy & Ecology Pass

## Scope

This pass connects the existing `WorldLifeSimulation`, `NPCJobs`, `CaravanSystem`, and `SettlementGrowth` systems. It does not replace the existing One World architecture, merchant transaction system, NPC schedule system, or dungeon/cultivation progression.

## Implemented

- Added persistent per-region commodity stock ledgers for food, timber, ore, and herbs, plus derived market prices.
- Added backward-compatible defaults so older saved region records receive the new economy fields when loaded.
- World simulation cycles consume food, recalculate scarcity pricing, and change regional settlement supply based on available food.
- Elyndor settlement progress receives a small positive adjustment with healthy food stores and a negative adjustment during critical shortages.
- Farmer job cycles contribute food to the regional ledger; merchant job cycles consume a small amount to represent sales.
- Caravans select a food or timber cargo based on origin stock. Successful arrivals transfer the cargo into the destination region. Ambushed caravans lose their shipment and do not grant settlement growth from a successful delivery.
- Hunter snares reduce the relevant regional wildlife population when they catch a supported animal.
- Predators in severely depleted prey regions move a portion of their population to a neighboring region.
- Economy and ecology records are stored inside the existing `MMORPGWorldState` living-world section, so server authority and snapshot replication continue to govern the data.

## Important boundaries

- This is the first connected simulation pass, not a complete player-facing commodity market. Existing shop purchases/sales still use `LivingWorldSystem` business stock and transactional paths; a later integration should quote and settle player purchases against the regional price ledger without bypassing backend validation.
- Active caravan visual replication, shipment reservations at departure, route-specific bandit combat encounters, carcass recovery into settlement inventory, and full predator pack AI remain follow-up work.
- `NPCJobs` and caravan presentation still rely on the existing scene/network replication setup. Live multi-client validation is required before claiming every client sees identical physical actors.
- Cultivation discovery and progression are unchanged; ordinary RPG life remains the intended starting experience.

## Validation

- Static delimiter/string scan: passed for all 125 GDScript files.
- Duplicate top-level function scan: no findings.
- Literal resource reference scan: no missing project resources; the one dynamic item-icon template `res://assets/items/%s.svg` is intentionally excluded.
- ZIP integrity: checked after packaging.
- Godot 4.7 editor/parser and runtime were not available in this environment. Engine parsing, in-game simulation, save/load round trips, and multiplayer replication still require testing in Godot 4.7.
