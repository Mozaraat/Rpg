# Eternal Realms — Real-World Physics Foundation

Target: Godot 4.7 / Forward+

## Implemented in this pass

- Added `PhysicalWorldSystem` as a project autoload, providing shared metre-based physical constants and reusable laws.
- Standard Earth gravity is 9.80665 m/s²; player, NPC, critter, slime and monster falling acceleration now use the same baseline.
- Added altitude-dependent barometric pressure and ideal-gas air-density approximations for the lower atmosphere.
- Added quadratic aerodynamic drag, Archimedes buoyancy, Newton cooling / heat transfer, pressure-adjusted water boiling point, and a rainfall infiltration/runoff partition.
- Added deterministic regional wind sampling based on world position and world time.
- Player gravity adjusts slightly with altitude; rain particle gravity uses standard Earth gravity, rain speed is reduced to plausible terminal-velocity ranges, and rainfall direction responds to the sampled wind.
- Bow projectiles now follow a ballistic arc under gravity and aerodynamic drag; elemental projectiles retain their authored magical propulsion.
- Added Godot project default 3D gravity at 9.80665 m/s².

## Design contract

Real-world physical laws are the baseline. Fantasy abilities may alter local conditions, inject energy, change material properties, or create controlled exceptions, but those effects should be explicit, measurable and consistent. For example, a fire technique supplies heat; a levitation technique applies an upward force; a water technique moves existing water or creates a documented magical source rather than silently ignoring mass balance.

## Important limits / next implementation layers

This is a shared gameplay approximation, not a complete Earth simulator. It does not yet provide a global Navier–Stokes fluid solver, deformable terrain, a full thermodynamic climate model, astronomical ephemerides, biome-calibrated hydrology, structural stress simulation, or species-specific physiology. The existing tide model remains a semidiurnal approximation. The new APIs are intended to be adopted progressively by swimming, projectiles, falling objects, construction, farming, weather, ecology and creature AI.

## Validation boundary

Source-level checks and archive integrity can be performed here. A Godot 4.7 executable is not available in this environment, so engine parsing, import, runtime physics, multiplayer authority and visual playtesting must still be run in Godot 4.7 before release.
