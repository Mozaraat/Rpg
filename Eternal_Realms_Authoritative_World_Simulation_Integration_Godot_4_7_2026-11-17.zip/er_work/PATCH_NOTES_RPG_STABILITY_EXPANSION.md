# RPG Stability & Progression Expansion

## Stability and error hardening
- Fixed guild succession when the guild leader leaves: the next member is promoted only inside the leader-transfer branch, avoiding an uninitialised local variable for ordinary members leaving.
- Hardened quest acceptance, progress reads, quest notifications, and restored quest state against unknown IDs, invalid indices, and malformed save entries.
- Hardened inventory restoration against invalid item IDs, impossible stack counts, invalid grades, and out-of-range equipment durability.
- Prevented invalid negative durability wear and clamped newly added item grades to supported quality tiers.
- Added reputation persistence to save files and tolerant loading for saves created before the new reputation field existed. Save format version is now 5; older saves are still loaded with defaults for newly introduced data.

## RPG progression
- Added five practice-derived attributes: Might, Finesse, Endurance, Intellect, and Survival. They reflect the player's actual skill use rather than a fixed class choice.
- Added mastery traits that unlock automatically at 25 skill points: Blade Veteran, Sunderer, Quickdraw, Lancer, Impact Adept, Deadeye, Arcane Conduit, Iron Body, Fleetfoot, Field Medic, Gatherer's Instinct, and Deep Delver.
- Traits grant small, distinct bonuses to the relevant weapon family, bow critical chance, magic damage, health, movement, potion healing, gathering, or dungeon loot.
- The Skills panel now displays derived attributes and mastered traits.
- Quest completion now grants faction reputation and NPC affinity; key Elyndor, Arcane Spire, and wilderness quest rewards were updated.
- Friendly and Honored faction standing now provides additional shop discounts, stacking with the Bartering skill up to a capped discount.

## Verification
- Checked the ZIP source archive before editing.
- Static resource-reference scan: no missing literal `res://` paths.
- Static loot-table scan: no unknown item IDs.
- Godot runtime/editor validation was not available in this environment; open the project in Godot 4.6 and run it to complete engine-level parse and gameplay verification.
