# Eternal Realms — authoritative quests, economy and world restoration

## World invariant

All records and transactions are scoped to the single fixed world ID `eternal-realms-one-world`. Production clients set `ER_PRODUCTION_CLIENT=1`; only the authoritative server sets `ER_PRODUCTION_SERVER=1` and receives the service token. A production client is blocked from starting another world server.

## Implemented in this pass

### Quests
- Added a server-side quest catalog mirrored from the 16 current `QuestDB` definitions.
- Quest acceptance is committed by the backend, including prerequisite checks and initial collect progress from already-owned inventory.
- Server-validated NPC dialogue, named-zone/region discovery, monster kills, authoritative loot/gather/fishing grants and server crafting advance persisted objective counters.
- Turn-in verifies every objective against PostgreSQL. The backend grants configured gold and item instances and marks the quest complete in one transaction; a unique reward-claim key prevents repeat claims.
- Production clients mark the quest journal as complete only after the server confirms the transaction. Local client reward minting is bypassed. Inventory and currency are refreshed from the backend after turn-in.

### Merchant economy
- Added seeded merchant catalog/stock for Mira, Gorrim the Smith and Archmage Lira with stable IDs matching the Godot server's deterministic UUID derivation.
- Production shop UI requests authoritative stock. Purchase and sale requests go through the authoritative server, which validates proximity and permitted merchant inventory before asking PostgreSQL to commit the transaction.
- Purchases debit currency and grant item instances atomically. Sales remove owned, unequipped items, credit currency and update stock atomically.
- Caravan restocks now increment shared database stock; retries are idempotent.
- Clients receive authoritative inventory and stock snapshots after successful transactions.

### Persistent world
- Boss encounter writes now use `world_boss_encounters`; startup restores living bosses and remaining respawn delays. Migration 003 imports records written by the previous `world_entities` path.
- Regional monster populations are restored from PostgreSQL before offline catch-up and persisted in batches with revision checks.
- Territory control/supply snapshots are restored and saved in the same world database.

### Trade foundations
- Added database-backed trade invitation, accept, offer, double-confirmation and atomic item/currency commit APIs.
- Godot server-side trade request/offer/commit methods call those APIs, require both players to confirm the current offers, enforce proximity, and refresh both players' inventories and quest journals after a successful commit.

## Remaining work / honest limits

- There is not yet a polished player-facing trade window for selecting items, setting currency and confirming offers. The network/backend invitation and double-confirmation flow is present, but users cannot operate the full trade workflow through the normal UI yet.
- Territory ownership and supply/control snapshots persist, and a territory economy ledger exists. Sect/guild treasuries, tax collection, market pricing, player-owned production and full regional supply-chain accounting are not yet connected end-to-end.
- Bosses restore alive/defeated status, spawn position and core combat profile, including the regional apex bosses created by `WorldLifeSimulation`. Exact in-progress boss health/phase and individual boss AI state are not yet checkpointed.
- Quest objective adapters cover current kill, collect, craft, talk and named-zone visit objectives. Other bespoke dungeon/secret reward interactions still need their own server-side event adapters.
- Server craft transactions enforce recipe inputs and outputs from the mirrored recipe catalog. Skill thresholds, interactive quality grades and every cooking experiment are not yet fully calculated server-side.
- This is not a production scale or security certification. The Godot 4.7 parser/runtime, PostgreSQL migration against a live database, two-client trades, multiplayer combat, restart restoration and load tests were not run in this environment.

## Database migration

Apply migrations in order:

1. `backend/postgres/001_shared_world_schema.sql`
2. `backend/postgres/002_persistent_world_operations.sql`
3. `backend/postgres/003_authoritative_economy_and_quests.sql`

New Docker volumes apply all three automatically. Existing production databases must be migrated in place; do not delete the PostgreSQL volume.
