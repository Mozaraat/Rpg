# Eternal Realms — Repair and Cleanup Pass

## Boot and loading reliability

- A failed threaded main-scene request now restores the title menu and makes the loading action retryable.
- A failed threaded load or rejected scene transition no longer leaves the title controls hidden.
- Pending load/new-game flags are cleared when the scene transition fails.
- New-game data is reset only after the main scene has been successfully loaded as a PackedScene, rather than before the asynchronous load begins.

## Project cleanup

- Removed the `captures/` screenshot collection from the deliverable.
- Added `assets/characters/README.txt` and `assets/creatures/README.txt` so the optional art directories exist and their procedural fallback behavior is documented.
- Updated the build audit to describe the current archive and its validation boundary accurately.

## Validation boundary

Static source inspection and ZIP integrity checks are not equivalent to a Godot engine parse or playtest. Godot 4.7 runtime validation remains required for boot, save/load, multiplayer, backend persistence, NPC simulation and visual performance.
