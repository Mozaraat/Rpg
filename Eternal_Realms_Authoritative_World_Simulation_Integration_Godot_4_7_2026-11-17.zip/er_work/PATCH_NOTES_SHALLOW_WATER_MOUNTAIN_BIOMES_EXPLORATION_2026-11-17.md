# Eternal Realms — shallow water, mountain geography and biome exploration

## Water simulation

- Added a depth-averaged 2D shallow-water finite-volume step over the active 64 m hydrology grid.
- Conserved state is water depth and the two horizontal momentum components.
- Shared Rusanov face fluxes are applied with equal and opposite signs to adjacent cells, conserving water volume inside the active simulation window before local source/sink terms.
- Added a CFL-limited timestep based on local flow speed and gravity-wave speed.
- Terrain gradients accelerate water downhill; semi-implicit bed friction damps velocity.
- Wetting/drying is represented by a small depth threshold. Water depth, surface storage, velocity and momentum are persisted in the hydrology cell state and used by the water surface renderer.
- Added persistent summit snowpack: cold high elevations store precipitation, and warm periods release degree-day meltwater into runoff, infiltration and groundwater recharge.
- Rainfall/runoff, infiltration, evaporation, groundwater recharge and erosion remain source/sink and terrain-coupling processes around the solver.

### Water solver limits

- Grid spacing is currently 64 m. It is suitable for regional river/flood behaviour, not detailed riverbank, rapids, wave breaking or splash simulation.
- The active window has no-flow solver boundaries; downstream watershed routing retains outflow into saved downstream cells, but a fully coupled multi-window finite-volume halo exchange is still required for exact cross-window mass conservation.
- The solver currently uses a first-order Rusanov flux and simple bed friction. A well-balanced hydrostatic reconstruction, explicit infiltration sink limiter, sediment transport and lake/ocean boundary conditions remain future work.
- The solver has not been run in Godot 4.7 in this environment; runtime stability and conservation tests remain outstanding.

## Mountain geography

- Reworked Ironback and Frostveil into broad uplifted ranges with ridged high summits and lower foothill transitions.
- Added a multi-scale massif term so high peaks are concentrated along coherent range spines rather than uniformly raising all nearby hills.
- Added two reduced-relief saddle/pass corridors aligned with existing traversable roads.
- Kept low hills below the mountain/alpine elevation bands; high peaks transition to alpine rock and cold summit snow.
- Raised terrain shader snowline to match the new summit scale rather than painting snow over ordinary hills.
- Applied an altitude temperature lapse so mountain biomes become colder than adjacent valleys.

## Biomes

Added TAIGA, TUNDRA, SAVANNA and MEDITERRANEAN biome classifications, colors on the world map and resource distributions. Existing plains, temperate forest, autumn woodland, rainforest, jungle, wetlands, desert, volcanic, alpine mountain, snow, beach and ocean biomes remain.

The climate/landform reference palette is inspired by real-world patterns: Alpine/Himalayan high relief and snow zones; Rocky Mountain-style foothills and passes; boreal taiga and tundra; Amazon/Congo-style humid tropical forest; Sahara-style arid desert; African savanna; Mediterranean dry-summer woodland; and lowland wetland/delta environments. These are ecological inspirations, not literal copies of Earth geography.

## Exploration

- Existing graded road and trail profiles are retained and now cross the new ranges through lower-relief saddles.
- Resource generation now distinguishes taiga, tundra, savanna and Mediterranean regions.
- The world map displays the added biome types.
- Routes remain physically graded rather than relying on teleporting players across impassable peaks.

## Verification status

Source-level edits only. ZIP integrity and structural delimiter checks can be performed here, but Godot 4.7 is not installed in this environment. Do not treat this patch as engine parser, runtime, gameplay, performance, multiplayer or physical-validation certification.
