# Eternal Realms – Mounts, Households and Faction Life

## Implemented
- Expanded wild tameable species to deer, wolves and boars alongside rabbits and chickens; larger wildlife now spawns in non-settlement wilderness areas.
- Mounts have species-specific speed, bond progression, levels, saddle/armour flags and a visible saddle when equipped. Feed a companion with a Mackerel using **G** to raise bond; higher bond/levels improve travel speed. **F** summons/mounts or dismounts.
- NPCs now receive deterministic family households, named relatives, occupations and ambitions. Their dialogue offers family/work stories and local-tension interactions.
- Peaceful mediation and faction support shift persisted reputation/influence and can contribute to settlement growth.
- A background faction-pressure simulation creates changing tension/peace reports across the ten dungeon cultures.
- Culture data now provides household, business-specialty and faction-influence helpers.
- Fixed save loading so custom progression data in `PlayerData.stats` (companions, bonds, faction reputation and other systems) is preserved instead of being discarded.

## Controls
- **F** – tame a nearby animal when you have no companion; otherwise mount/dismount.
- **G** – feed and train your active companion (requires one Mackerel).
- **H** – craft/equip a saddle (requires 2 Leather Strips).
- **J** – craft/equip mount barding (requires 3 Iron Ingots).

## Notes
- The mount model is a procedural placeholder following the player, not a final animated skeletal mount with a seated rider.
- Mount saddle/armour equipment is currently represented by progression flags and visible saddle geometry; dedicated crafted tack recipes, mount combat abilities, breeding and aquatic mounts remain future work.
- NPC households and faction simulation are systemic foundations, not yet a fully voiced family tree or large-scale real-time siege simulation.
- Godot was not available in this environment, so the project has been statically inspected but not parsed or playtested in-engine.
