# Wall Combat, Maps, Cultivation & Projectiles Pass

## Combat and collision
- Player melee attacks now perform a physics line-of-sight test against world geometry before applying damage.
- Monster wind-up attacks also require an unobstructed path to the player. Dungeon masonry blocks both outgoing and incoming melee hits.
- Bow, staff and wand attacks now launch physical travel projectiles. Projectiles raycast along their path, stop on solid world geometry, and only damage enemies they actually reach.
- Staff and wand attacks consume spiritual energy; shots train the relevant ranged/magic discipline when launched and when they connect.

## Cultivation
- Hold **C** while grounded and still to circulate internal energy.
- Spiritual energy regenerates during cultivation and its capacity grows with cultivation practice.
- A circulation aura and dedicated HUD energy bar show the process and remaining energy.
- Staff and wand attacks require spiritual energy; the HUD and toast explain when to cultivate.

## Maps
- **M** opens the overworld atlas, sampled from the same seeded `TerrainNoise` generator used by the live world. Biomes and paths now appear as terrain rather than a text-only/empty map panel; settlement, POI, caravan and player markers remain aligned to world X/Z coordinates.
- When underground, the overworld map pins the player marker to the dungeon entrance; use **N** for the actual dungeon floor map.
- The dungeon map draws sealed masonry edges and traversable corridors, shows entrance/exit and follows the player's current maze cell while open.

## Dungeon presentation
- Replaced rounded boulder wall dressing with continuous collision-backed masonry, staggered ashlar blocks, mortar seams and heavy pilasters.
- Replaced round floor blobs with cut-stone pavers and visible joints for a more deliberate constructed labyrinth feel.

## Audio
- Reworked the procedural footstep sample into a softer, lower-frequency boot impact with a restrained double-thump and filtered grit to reduce the harsh synthetic click/noise.

## Controls
- **C**: cultivate while standing still.
- **M**: overworld terrain atlas.
- **N**: current dungeon floor navigation map.
- **LMB**: melee attack, or launch an arrow/energy projectile with bow/staff/wand.
- **RMB**: guard.

## Validation
- ZIP archive integrity checked after packaging.
- Godot executable is not available in this environment, so editor import and runtime playtesting could not be performed here.
