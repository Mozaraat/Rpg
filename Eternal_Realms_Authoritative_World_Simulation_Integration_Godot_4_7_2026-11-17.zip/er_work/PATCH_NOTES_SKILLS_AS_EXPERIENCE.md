# Skills as an Experience

## Combat flow replaces manual ability activation
- Removed the old R-key ability preparation flow. Players no longer need to open a menu or press a separate ability key to use a learned combat technique.
- Weapon techniques now emerge automatically from successful combat rhythm. Maintain a chain of three successful attacks to trigger a trained technique, subject to its cooldown.
- Sword, dagger, axe, spear, blunt, bow, staff and wand techniques remain tied to the weapon actually equipped.
- Sword mastery at Adept level can produce a stronger Heavy Strike later in a longer chain.
- Missing an attack breaks the chain. A short 2.4-second rhythm window gives the player room to reposition without instantly losing momentum.
- Combo momentum improves weapon mastery training, so deliberate continuous fighting develops a style faster than isolated button mashing.
- Technique cooldowns are refunded if the attack finds no target, preventing wasted activations.

## Skill philosophy
Skills continue to grow from relevant actions: weapon mastery from successful hits, precision from combat, evasion from avoiding attacks, vitality from surviving damage, agility from movement, and gathering/crafting skills from their actual activities. Rank milestones remain persistent skill progression rather than character-level gates.

## Controls
- Normal attack and movement remain the core combat controls.
- No dedicated skill activation key is required for weapon flow techniques.
