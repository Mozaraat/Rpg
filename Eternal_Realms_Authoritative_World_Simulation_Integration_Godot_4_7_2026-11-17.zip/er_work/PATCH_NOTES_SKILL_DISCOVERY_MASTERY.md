# Skill Discovery & Mastery Pass

## Design direction
Skills and techniques are knowledge the character discovers, earns, studies and practises. They are not automatically granted by character level or by reaching a numeric threshold.

## Implemented
- Skills begin undiscovered. A discipline becomes known the first time the player meaningfully practises it; discovery is recorded and saved with the character.
- The skills screen distinguishes undiscovered disciplines from known skills rather than presenting every discipline as already learned.
- Combat techniques require a source of knowledge and a minimum practical foundation. Reaching a mastery number alone no longer unlocks them.
- Old Man Thoren can teach Cleave, Gorrim can teach Heavy Strike, and Archmage Lira / Apprentice Kael can teach Arcane Burst once the player has the required experience.
- Hunter/ranger, guard/soldier, swordsman/swordmaster and mage/scholar NPC roles can teach their matching techniques when those roles exist in the world.
- Ancient dungeon shrines can reveal Arcane Burst to a character with sufficient elemental practice. Solving a runic secret can reveal a lesson aligned with the weapon discipline the player has practised most.
- Learned techniques only flow during combat when the player maintains a successful attack chain. They are not activated from a skill button.
- Successful technique executions are counted and milestone feedback is shown as the player develops control and reliability.
- Perfectly timed guards can still earn Riposte through the player's own execution.
- Added Cultivation and Spiritual Sense disciplines, developed by attuning to ancient shrines. These are separate from ordinary weapon mastery.
- Skill knowledge, discovered techniques and technique practice counts persist through the existing save system.

## Notes
This is a foundational implementation. It establishes discovery, teaching, practice and persistence for the existing disciplines and combat techniques. Broader manual placement, deeper cultivation breakthroughs, branching teacher relationships and interactive practice challenges remain suitable next expansion layers.
