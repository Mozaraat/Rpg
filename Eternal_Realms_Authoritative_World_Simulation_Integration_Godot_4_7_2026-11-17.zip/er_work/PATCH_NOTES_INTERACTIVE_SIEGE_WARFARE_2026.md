# Eternal Realms — Interactive Siege Warfare (2026)

## Built on the latest Visible Dungeon Campaign Warfare archive

This milestone adds a playable siege layer to each of the ten civilization-band strongholds while preserving the existing dungeon campaign, faction histories, save system, commander parley, patrols and room ownership.

## Siege battlefield systems

- **Physical fortress gates:** each stronghold now has a collision-backed gate with integrity, visible damage scaling, opening rotation, collision disablement on breach and restoration for a later siege.
- **Siege ladders:** two climbable-looking ladder structures flank the gate; assault units divert to ladder positions as the gate weakens.
- **Battering ram:** a visible wheeled ram advances during an assault and accompanies gate damage.
- **Defensive weapons:** a fortress ballista fires visible bolts at attackers. Repeated hits remove attackers from the assault formation; a wiped assault force results in a defender victory.
- **Assembling formations:** the siege begins with an assembly phase, then attacker and defender formations advance through the assault state.
- **Reinforcement waves:** a player order spawns a new formation from the fortress rear command yard, representing troops arriving from the headquarters.
- **Breach and capture:** breaking the gate moves the battle into the breach phase. Surviving attackers advance into the fortress; successful capture updates persistent room ownership.

## Player command sequence

Interact with the siege command point at the fortress. Its prompt describes the next available order:

1. Begin siege assembly.
2. Order battering ram assault.
3. Order gate breach and swing the gate open.
4. Call a reinforcement wave from headquarters.
5. Attempt commander negotiations (requires sufficient reputation for a truce).
6. Order withdrawal if negotiations are not accepted.

Orders alter the live siege rather than merely writing flavour text. A successful negotiation ends the siege without changing ownership; a successful assault changes the campaign territory owner to `PLAYER_EXPEDITION`; a failed assault strengthens the defending faction.

## Persistent campaign consequences

- Siege events are written into faction histories.
- Attacker victories reduce defender strength and morale, increment defeats and claim the floor for the expedition.
- Defender victories restore strength and morale and increment victories.
- Negotiated truces are recorded separately from military victories.
- Captured strongholds update their banner, commander label, fortress stone/trim palette, guard armour and lighting.

## Compatibility

- The campaign state continues to use the existing `DungeonCampaign` save payload; no separate save file or incompatible save-version bump was introduced.
- Existing dungeon generation and the previous visible campaign headquarters remain the foundation.
- New scripts are loaded by resource path and included in the project archive.

## Validation and limitations

- Original archive integrity checked before modification.
- New script references and `res://` paths checked.
- Changed scripts checked for balanced delimiters and duplicate top-level function declarations.
- Final ZIP integrity checked with `unzip -t`.
- Godot 4.6 is not installed in this environment. Engine parsing, collision behaviour, navigation, visuals and full playtesting have not been runtime-verified.
