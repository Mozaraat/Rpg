# Eternal Realms — World Scale, Biome Variety & Resource Expansion

## World scale and natural landmarks
- Increased terrain height range and added a low-frequency ridged mountain field that forms distant mountain chains while fading around the starting homeland.
- Mountain biome thresholds now account for taller highlands and snow peaks.
- Mountain landmark spires have a much larger vertical silhouette.
- Added monumental redwoods with buttress roots, broad-trunk baobabs, drooping willows, pink-blossom cherry trees, tropical jungle trees, tall pines and deadwood silhouettes.
- Tree species are selected from local moisture, temperature and elevation, with individual size variation and rare giant specimens.
- Tree collision trunks now scale with the actual species and size rather than using one small shared cylinder.
- Growing saplings now mature into species-specific trees; giant species can produce distinctive timber.

## More believable creature scale
- Field monsters now have size variation, with alpha beasts and major bosses significantly larger.
- Monster health, damage, attack reach, nameplates and collision dimensions scale alongside their visible models.
- Wild deer, wolves and boars vary in size; collision sizes follow their models.
- Slimes have a range of sizes with matching health, nameplates and collision shapes.

## More resource variety
- Added silver ore, gold ore, sulfur, mana-crystal outcrops, salt crystals, glowcap mushrooms and wild berry bushes.
- Added five harvestable tree types that produce distinct materials: redwood heartwood, willow bark, baobab fibre, cherrywood and jungle hardwood.
- New resource nodes have different visuals, gathering times, yields, skill progression and respawn periods.
- Added silver/gold refining, an Elder Redwood Longbow recipe and a Glowcap Tonic recipe.
- Resource nodes now spawn as chunks stream in, with resource families selected by biome. The authored starting area keeps its existing hand-placed resource fields.

## Files changed
- `systems/terrain_noise.gd`
- `systems/chunk.gd`
- `systems/vegetation_kit.gd`
- `systems/resource_spawner.gd`
- `systems/world_growth.gd`
- `entities/resource_node.gd`
- `entities/growing_tree.gd`
- `entities/monster.gd`
- `entities/critter.gd`
- `entities/slime.gd`
- `data/item_db.gd`
- `data/recipe_db.gd`

## Validation
- Checked new resource kinds against resource-node configurations.
- Checked all new gatherable item IDs and recipe inputs/outputs against the item database.
- Checked referenced procedural vegetation mesh names.
- ZIP integrity checked after packaging.
- Godot 4.6 executable was not available in this environment, so a real engine parse and gameplay test could not be performed. Please import and run the project in Godot 4.6 before merging into a release build.
