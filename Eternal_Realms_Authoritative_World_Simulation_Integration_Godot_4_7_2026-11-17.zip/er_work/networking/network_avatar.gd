extends CharacterBody3D
class_name MMORPGNetworkAvatar

var peer_id: int = 0
var display_name: String = "Cultivator"
var _target_position: Vector3 = Vector3.ZERO
var _target_yaw: float = 0.0
var _has_target: bool = false
var character_model: CharacterModel
var _last_model_position: Vector3 = Vector3.ZERO

@onready var name_tag: Label3D = $NameTag

func configure(owner_id: int, owner_name: String = "") -> void:
	peer_id = owner_id
	add_to_group("player")
	display_name = owner_name if owner_name != "" else "Cultivator %d" % owner_id
	set_multiplayer_authority(1)
	if is_node_ready():
		_update_label()

func _ready() -> void:
	_update_label()
	_target_position = global_position
	_last_model_position = global_position
	var placeholder: Node = get_node_or_null("Body")
	if placeholder:
		placeholder.queue_free()
	character_model = CharacterModel.new()
	character_model.name = "CultivatorModel"
	add_child(character_model)
	var robes: Array[Color] = [Color(0.20, 0.48, 0.66), Color(0.48, 0.25, 0.62), Color(0.23, 0.52, 0.38), Color(0.68, 0.36, 0.20), Color(0.30, 0.34, 0.58)]
	var robe_color: Color = robes[absi(peer_id) % robes.size()]
	character_model.build({"skin": CharacterModel.SKIN_TONES[absi(peer_id + 1) % CharacterModel.SKIN_TONES.size()], "hair": Color(0.18, 0.12, 0.09), "hair_style": "short", "shirt": robe_color, "pants": Color(0.24, 0.21, 0.19), "boots": Color(0.16, 0.12, 0.09), "accent": robe_color.lightened(0.38), "robe": true})

func _update_label() -> void:
	if name_tag:
		name_tag.text = "%s  ·  #%d" % [display_name, peer_id]

func apply_network_state(world_position: Vector3, yaw: float) -> void:
	_target_position = world_position
	_target_yaw = yaw
	_has_target = true

func _physics_process(delta: float) -> void:
	if not _has_target:
		return
	# Remote avatars are presentation proxies. Their transforms are accepted only
	# from the authoritative server and smoothly interpolated on receiving clients.
	global_position = global_position.lerp(_target_position, clampf(delta * 14.0, 0.0, 1.0))
	rotation.y = lerp_angle(rotation.y, _target_yaw, clampf(delta * 14.0, 0.0, 1.0))
	if character_model:
		var speed_ratio: float = clampf(global_position.distance_to(_last_model_position) / maxf(delta, 0.001) / 5.5, 0.0, 1.0)
		character_model.set_motion(speed_ratio)
	_last_model_position = global_position

func take_damage(amount: float, _source: Node = null) -> void:
	if multiplayer.is_server() and amount > 0.0:
		MMORPGNetwork.apply_damage_to_peer(peer_id, amount)
