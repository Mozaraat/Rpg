# Sapling that grows over time; chop with interaction if mature (woodcutting XP via PlayerData path optional)
class_name GrowingTree
extends Node3D

var maturity: float = 0.0
@export var species: String = "broadleaf"
var _visual: Node3D
var _tree_mesh: MeshInstance3D
var _species_scale: float = 1.0
var _trunk_collision: CollisionShape3D
var _base_lift: float = 0.0
var _trunk_height: float = 4.0
var _trunk_radius: float = 0.35

func _ready() -> void:
	add_to_group("sapling")
	add_to_group("growing_tree")
	add_to_group("interactable")
	_build()
	_apply()

func grow(amount: float) -> void:
	maturity = minf(maturity + amount, 1.3)
	_apply()

func can_interact() -> bool:
	return maturity >= 0.25

func get_prompt() -> String:
	if maturity < 0.25:
		return "Young sapling"
	return "Chop growing tree"

func interact(player: Node3D = null) -> void:
	if maturity < 0.25:
		EventBus.toast.emit("Too young to chop", "warning")
		return
	# Prefer woodcutting skill on player
	if player and player.get("skills"):
		player.skills.train("woodcutting", 0.35 + maturity * 0.25)
	var yield_amount := 1 + floori(maturity * 2.0)
	var timber_id := "wood_log"
	match species:
		"redwood": timber_id = "redwood_heartwood"
		"willow": timber_id = "willow_bark"
		"baobab": timber_id = "baobab_fiber"
		"cherry": timber_id = "cherrywood"
		"jungle": timber_id = "jungle_hardwood"
	if species == "redwood" or species == "baobab":
		yield_amount += 2
	PlayerData.add_item(timber_id, yield_amount)
	PlayerData.stats["gathered"] = int(PlayerData.stats.get("gathered", 0)) + 1
	queue_free()

func _build() -> void:
	_visual = Node3D.new()
	_visual.name = "Growing_%s" % species.capitalize()
	add_child(_visual)
	_tree_mesh = MeshInstance3D.new()
	_tree_mesh.mesh = VegetationKit.get_mesh(species)
	_tree_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	_visual.add_child(_tree_mesh)
	match species:
		"redwood":
			_species_scale = 1.0; _base_lift = 3.0; _trunk_height = 12.0; _trunk_radius = 0.95
		"baobab":
			_species_scale = 1.45; _base_lift = 0.15; _trunk_height = 4.5; _trunk_radius = 1.25
		"pine":
			_species_scale = 1.0; _base_lift = 3.45; _trunk_height = 6.5; _trunk_radius = 0.36
		"willow":
			_species_scale = 1.35; _base_lift = 0.2; _trunk_height = 3.8; _trunk_radius = 0.38
		"jungle":
			_species_scale = 1.15; _base_lift = 0.2; _trunk_height = 5.0; _trunk_radius = 0.58
		"cherry":
			_species_scale = 1.25; _base_lift = 0.15; _trunk_height = 3.0; _trunk_radius = 0.30
		"deadwood":
			_species_scale = 1.0; _base_lift = 0.0; _trunk_height = 3.6; _trunk_radius = 0.35
		_:
			_species_scale = 1.0; _base_lift = 0.65; _trunk_height = 3.3; _trunk_radius = 0.42
	_tree_mesh.position.y = _base_lift
	var trunk_body := StaticBody3D.new()
	trunk_body.name = "GrowingTreeCollision"
	trunk_body.collision_layer = Constants.LAYER_WORLD
	trunk_body.collision_mask = 0
	_trunk_collision = CollisionShape3D.new()
	var trunk_shape := CylinderShape3D.new()
	_trunk_collision.shape = trunk_shape
	trunk_body.add_child(_trunk_collision)
	add_child(trunk_body)

func _apply() -> void:
	var growth := 0.18 + maturity * 0.95
	if species == "redwood":
		growth = 0.12 + maturity * 1.45
	var final_scale := growth * _species_scale
	if _visual:
		_visual.scale = Vector3.ONE * final_scale
	if _trunk_collision and _trunk_collision.shape is CylinderShape3D:
		var trunk_shape := _trunk_collision.shape as CylinderShape3D
		trunk_shape.height = maxf(0.45, _trunk_height * final_scale)
		trunk_shape.radius = maxf(0.16, _trunk_radius * final_scale)
		_trunk_collision.position.y = (_base_lift + _trunk_height * 0.5) * final_scale
