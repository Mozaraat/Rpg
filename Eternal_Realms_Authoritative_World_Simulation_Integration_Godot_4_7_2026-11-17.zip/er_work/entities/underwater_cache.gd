# Harvestable underwater deposits and ancient caches. Rewards are granted by the host.
extends Node3D
class_name UnderwaterCache

@export var item_id: String = "coral_fragment"
@export var amount: int = 2
@export var display_name: String = "Coral deposit"
@export var is_treasure: bool = false
var interact_range: float = 3.4
var _claimed := false
var _cooldown := 0.0
var _mesh: MeshInstance3D
@export var persistent_key: String = ""

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("underwater_resource")
	_build_visual()
	var manager := get_tree().get_first_node_in_group("underwater_exploration")
	if manager and not persistent_key.is_empty():
		var saved_state: Dictionary = manager.get_save_state().get("sites", {}).get(persistent_key.get_slice(":resource:", 0) if persistent_key.contains(":resource:") else persistent_key.get_slice(":treasure:", 0), {}).get("resources", {}).get(persistent_key, {})
		restore_persistent_state(saved_state)

func _process(delta: float) -> void:
	if _cooldown > 0.0:
		_cooldown = maxf(0.0, _cooldown - delta)

func can_interact() -> bool:
	return not _claimed and _cooldown <= 0.0

func get_prompt() -> String:
	return "Open %s" % display_name if is_treasure else "Harvest %s" % display_name

func interact(player: Node) -> void:
	if not can_interact() or player == null:
		return
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return
	if is_treasure:
		_claimed = true
		_record_claim()
		var rewards := ["abyssal_relic", "pearl", "scale_shard", "coral_fragment"]
		var reward := rewards[randi_range(0, rewards.size() - 1)]
		PlayerData.add_item(reward, 1, 1, -1.0, false)
		PlayerData.add_item("pearl", 2, 0, -1.0, false)
		EventBus.toast.emit("Ancient cache opened: %s and 2 pearls" % reward.replace("_", " "), "info")
		queue_free()
	else:
		PlayerData.add_item(item_id, amount, 0, -1.0, false)
		_record_claim()
		EventBus.toast.emit("Collected %d %s" % [amount, display_name.to_lower()], "info")
		_claimed = true
		visible = false
		_cooldown = 90.0
		_claimed = false
		visible = true

func _build_visual() -> void:
	var mesh := MeshInstance3D.new()
	var material := StandardMaterial3D.new()
	material.roughness = 0.48
	if is_treasure:
		var box := BoxMesh.new(); box.size = Vector3(1.4, 0.9, 1.0); mesh.mesh = box
		material.albedo_color = Color(0.28, 0.22, 0.12)
		material.metallic = 0.55
	else:
		var sphere := SphereMesh.new(); sphere.radius = 0.55; sphere.height = 0.9; sphere.radial_segments = 10; sphere.rings = 6
		mesh.mesh = sphere
		match item_id:
			"pearl": material.albedo_color = Color(0.88, 0.92, 1.0)
			"seaweed": material.albedo_color = Color(0.12, 0.48, 0.24)
			"abyssal_relic": material.albedo_color = Color(0.12, 0.72, 0.9)
			_: material.albedo_color = Color(0.2, 0.68, 0.58)
	if item_id == "abyssal_relic" or is_treasure:
		material.emission_enabled = true
		material.emission = Color(0.08, 0.48, 0.8)
		material.emission_energy_multiplier = 1.3
	mesh.material_override = material
	add_child(mesh)
	_mesh = mesh
	var shape := CollisionShape3D.new()
	var sphere_shape := SphereShape3D.new(); sphere_shape.radius = 2.2
	shape.shape = sphere_shape
	var area := Area3D.new(); area.add_child(shape); add_child(area)


func _record_claim() -> void:
	var manager := get_tree().get_first_node_in_group("underwater_exploration")
	if manager and manager.has_method("record_underwater_resource"):
		manager.record_underwater_resource(persistent_key, item_id, amount, is_treasure)

func restore_persistent_state(state: Dictionary) -> void:
	if state.is_empty() or not bool(state.get("claimed", false)):
		return
	if is_treasure:
		_claimed = true
		visible = false
		set_process(false)
		return
	var claimed_at := float(state.get("claimed_at", 0.0))
	var remaining := 90.0 - (Time.get_unix_time_from_system() - claimed_at)
	if remaining > 0.0:
		_claimed = true
		visible = false
		_cooldown = remaining
		set_process(true)
