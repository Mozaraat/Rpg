# Milestone lore-and-memory trial for each of the ten dungeon civilizations.
extends Area3D

var solved: bool = false
var active: bool = false
var civilization_name: String = "The Forgotten People"
var history: String = "Their names were lost, but their works remain."
var puzzle_hint: String = "Remember the sequence."
var relic_id: String = "rune_fragment"
var floor_index: int = 9
var glow_color: Color = Color(0.7, 0.55, 1.0)
var _sequence: Array[int] = []
var _step: int = 0
var _replaying: bool = false
var interact_range: float = 3.8

const CIVILIZATION_TECHNIQUES: Array[String] = [
	"eclipse_counter", "starfall_burst", "dragon_piercer", "void_step",
	"eclipse_counter", "dragon_piercer", "starfall_burst", "void_step",
	"eclipse_counter", "starfall_burst"
]

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("dungeon_discovery")
	var band := clampi(int(floor_index / 10), 0, 9)
	# Each culture teaches a different ordering discipline rather than reusing
	# one generic door code: civic vows, root-song, refraction, funeral bells,
	# forge stages, mirror pairs, tide pulses, branching growth, starfall and orbit.
	match band:
		0: _sequence = [1, 3, 2, 4] # Concord: oath / witness / bond / crown.
		1: _sequence = [2, 4, 1, 3] # Verdant: center, outer, seed, canopy.
		2: _sequence = [1, 4, 2, 3] # Prism: refract the first ray across opposite facets.
		3: _sequence = [4, 3, 2, 1] # Court: funeral bells descend toward the crypt.
		4: _sequence = [1, 2, 4, 3] # Forge: spark, flame, white heat, quench.
		5: _sequence = [2, 1, 4, 3] # Monastery: mirrored pairs.
		6: _sequence = [3, 1, 4, 2] # Tide: high / low / rising / ebb.
		7: _sequence = [2, 3, 1, 4] # Worldroot: branch outward from the trunk.
		8: _sequence = [4, 2, 1, 3] # Starless: collapse inward then relight.
		9: _sequence = [3, 2, 4, 1] # Astral: follow the archive's four orbital stations.

func _process(_delta: float) -> void:
	if (active or _replaying) and GameManager.player and GameManager.player.global_position.distance_to(global_position) > interact_range * 1.5:
		active = false
		_replaying = false
		_step = 0
		EventBus.toast.emit("You leave the memory seal before restoring it.", "info")

func can_interact() -> bool:
	return not solved and not active and not _replaying

func get_prompt() -> String:
	return "Study the %s memory trial" % civilization_name if not solved else "Civilization memory restored"

func interact(_player: Node3D = null) -> void:
	if solved or active or _replaying:
		return
	_step = 0
	_replaying = true
	EventBus.activity.emit("Discovered the history of %s" % civilization_name, "exploration")
	EventBus.toast.emit("%s: %s" % [civilization_name, history], "info")
	EventBus.toast.emit("Trial clue — %s. Watch the four runes, then repeat their order with keys 1–4." % puzzle_hint, "info")
	await _show_memory_sequence()
	if not is_inside_tree() or solved or not _replaying:
		return
	_replaying = false
	if GameManager.player and GameManager.player.global_position.distance_to(global_position) <= interact_range * 1.5:
		active = true
		EventBus.toast.emit("Your turn: press 1–4 in the order the runes flashed.", "info")

func _show_memory_sequence() -> void:
	for rune_index in _sequence:
		if not _replaying or not is_inside_tree():
			return
		var rune_node := get_node_or_null("MemoryRune_%d" % rune_index) as Node3D
		if rune_node:
			rune_node.scale = Vector3.ONE * 1.75
		await get_tree().create_timer(0.42).timeout
		if not _replaying or not is_inside_tree():
			return
		if rune_node and is_instance_valid(rune_node):
			rune_node.scale = Vector3.ONE
		await get_tree().create_timer(0.24).timeout

func _unhandled_key_input(event: InputEvent) -> void:
	if solved or not active or GameManager.input_locked or not event is InputEventKey or not event.pressed or event.echo:
		return
	var pressed: int = -1
	match event.keycode:
		KEY_1: pressed = 1
		KEY_2: pressed = 2
		KEY_3: pressed = 3
		KEY_4: pressed = 4
	if pressed < 0:
		return
	get_viewport().set_input_as_handled()
	if pressed == _sequence[_step]:
		_step += 1
		if _step < _sequence.size():
			EventBus.toast.emit("Memory restored: %d / 4" % _step, "info")
			return
		_complete_trial()
	else:
		_step = 0
		EventBus.toast.emit("The memory fractures. Study the inscription and try again.", "warning")

func _complete_trial() -> void:
	if solved:
		return
	solved = true
	active = false
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.mark_discovery(floor_index, "civilization")
	if ItemDB.has_item(relic_id):
		PlayerData.add_item(relic_id, 1)
	PlayerData.add_item("field_notes", 2)
	PlayerData.add_gold(90 + floor_index * 7)
	PlayerData.stats["archaeology"] = int(PlayerData.stats.get("archaeology", 0)) + 1
	var player: Node3D = GameManager.player
	if player and player.get("skills") != null:
		player.skills.train("archaeology", 2.4)
		player.skills.train("ancient_lore", 2.2)
		player.skills.train("knowledge", 1.8)
		player.skills.train("wisdom", 1.5)
		player.skills.train("observation", 1.5)
		player.skills.train("dungeon_delving", 1.2)
		var band: int = clampi(int(floor_index / 10), 0, CIVILIZATION_TECHNIQUES.size() - 1)
		var sealed_form: String = CIVILIZATION_TECHNIQUES[band]
		if player.skills.has_method("seal_rare_technique"):
			player.skills.seal_rare_technique(sealed_form, "%s civilization memory, floor %d" % [civilization_name, floor_index + 1])
		var records_value: Variant = PlayerData.stats.get("dungeon_civilization_records", {})
		var records: Dictionary = records_value.duplicate(true) if records_value is Dictionary else {}
		records[str(band)] = {"civilization": civilization_name, "floor": floor_index + 1, "recovered": true}
		PlayerData.stats["dungeon_civilization_records"] = records
	EventBus.toast.emit("%s's history has been recovered. Unique relic acquired!" % civilization_name, "levelup")
	EventBus.activity.emit("Restored a lost civilization's memory", "exploration")
	visible = false
	set_deferred("monitoring", false)
