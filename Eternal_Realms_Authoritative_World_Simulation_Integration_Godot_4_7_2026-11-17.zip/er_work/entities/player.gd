# Player - Movement, Aging, Combat, Health, third-person camera
extends CharacterBody3D
class_name Player

# --- Aging System ---
@export var current_age: float = Constants.STARTING_AGE
var previous_age: float = Constants.STARTING_AGE
var _respawning := false

# --- Movement ---
@export var walk_speed: float = Constants.PLAYER_WALK_SPEED
@export var run_speed: float = Constants.PLAYER_RUN_SPEED
@export var jump_velocity: float = Constants.PLAYER_JUMP_VELOCITY
var gravity: float = Constants.PLAYER_GRAVITY
var is_running: bool = false
var is_swimming: bool = false
var is_stealthed: bool = false
var _stealth_training_clock: float = 0.0
var _stealth_strike_pending: bool = false
var selected_element: String = "fire"
var _selected_element_index: int = 0
var _spell_cooldown: float = 0.0

# --- Combat ---
@export var attack_damage: float = Constants.BASE_MELEE_DAMAGE
var can_attack: bool = true
var _combat_combo_count: int = 0
var _combat_combo_timer: float = 0.0
var attack_cooldown: float = Constants.ATTACK_COOLDOWN
var _dodge_cooldown: float = 0.0
var _dodge_window: float = 0.0
var _dodge_direction: Vector3 = Vector3.ZERO
var guarding: bool = false
var guard_stamina: float = 100.0
var _guard_time: float = 0.0
var _riposte_ready: bool = false
var _shake_strength: float = 0.0
var _shake_clock: float = 0.0

# --- Nodes ---
@onready var camera_pivot: Node3D = $CameraPivot
@onready var spring_arm: SpringArm3D = $CameraPivot/SpringArm3D
@onready var camera: Camera3D = $CameraPivot/SpringArm3D/Camera3D
@onready var model: CharacterModel = $Model
@onready var collision: CollisionShape3D = $CollisionShape3D
@onready var health: HealthComponent = $HealthComponent
@onready var skills: SkillSystem = $SkillSystem

# Mouse look
var mouse_sensitivity: float = 0.0025
var pitch: float = -0.15
var focus_target: Node = null

var _cam_dist: float = 4.6
var _kb: Vector3 = Vector3.ZERO
var _invuln: float = 0.0
var _since_damage: float = 99.0
var _swing_side: float = 1.0
var _attack_impact_generation: int = 0
var _attack_impact_resolved: bool = false
var _noise: TerrainNoise = null

# --- Gathering ---
var gather_ratio: float = -1.0           # 0..1 while gathering, -1 otherwise (HUD reads this)
var gather_text: String = ""
var _gather_node: Node = null
var _gather_t: float = 0.0
var _gather_swing: float = 0.0

# --- Zones / exploration ---
var current_zone: String = ""
var _zone_timer: float = 0.0
var _walked: float = 0.0
var _run_train: float = 0.0
var _last_pos: Vector3 = Vector3.ZERO
var _step_distance: float = 0.0
var _step_audio: AudioStreamPlayer3D
var _camera_bob_clock: float = 0.0
var _camera_base_y: float = 1.55
var _scale_fov_bonus: float = 0.0

# Internal energy is cultivated through stillness and controlled circulation.
var spiritual_energy: float = 30.0
var max_spiritual_energy: float = 30.0
var _cultivation_clock: float = 0.0
var _cultivating: bool = false
var _cultivation_ring: MeshInstance3D
var _network_cultivation_clock: float = 0.0

const DAMAGE_NUMBER_SCENE = preload("res://ui/damage_number.tscn")

func _ready() -> void:
	add_to_group("player")
	GameManager.register_player(self)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	health.died.connect(_on_died)
	model.build({
		"asset": "elf",
		"skin": CharacterModel.SKIN_TONES[1],
		"hair": Color(0.22, 0.14, 0.09),
		"hair_style": "short",
		"shirt": Color(0.16, 0.48, 0.60),
		"pants": Color(0.36, 0.26, 0.18),
		"boots": Color(0.22, 0.14, 0.09),
		"accent": Color(0.90, 0.72, 0.28),
		"held": _held_visual_for_equipment(),
	})
	model.attack_impact.connect(_on_attack_impact)
	spring_arm.spring_length = _cam_dist
	spring_arm.collision_mask = Constants.LAYER_WORLD
	var sphere := SphereShape3D.new()
	sphere.radius = 0.25
	spring_arm.shape = sphere
	spring_arm.margin = 0.1
	spring_arm.add_excluded_object(get_rid())
	camera_pivot.rotation.x = pitch
	refresh_age_visuals()
	_build_footstep_audio()
	_build_cultivation_visual()
	print("[Player] Spawned at age %.1f with %.0f HP" % [current_age, health.current_health])
	skills.rank_up.connect(_on_rank_up)
	PlayerData.title_changed.connect(refresh_stats)
	PlayerData.equipment_changed.connect(_on_equipment_changed)
	_last_pos = global_position
	await get_tree().process_frame
	for grp in ["game_menu", "station_panel"]:
		var ui: Node = get_tree().get_first_node_in_group(grp)
		if ui and ui.has_method("set_skill_system"):
			ui.set_skill_system(skills)
	refresh_stats()
	health.current_health = health.max_health
	health.health_changed.emit(health.current_health, health.max_health)

func refresh_age_visuals() -> void:
	var s: float = model.set_age(current_age)
	var cap: CapsuleShape3D = collision.shape
	cap.radius = 0.35 * s
	cap.height = maxf(1.6 * s, cap.radius * 2.0 + 0.05)
	collision.position.y = cap.height * 0.5
	_camera_base_y = 1.45 * s + 0.1
	camera_pivot.position.y = _camera_base_y

## Max health etc. come from skills (Vitality) and titles.
func refresh_stats() -> void:
	if skills == null or health == null:
		return
	var ratio: float = health.get_health_percent() if health.max_health > 0.0 else 1.0
	health.max_health = skills.max_health()
	health.current_health = clampf(health.max_health * ratio, 0.0, health.max_health) if not health.is_dead else 0.0
	health.health_changed.emit(health.current_health, health.max_health)

func _on_rank_up(skill_id: String, rank_name: String) -> void:
	if skill_id == "vitality":
		refresh_stats()
		if rank_name == "Adept":
			PlayerData.grant_title("Unyielding")

# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------
func _input(event: InputEvent) -> void:
	if health.is_dead:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not GameManager.input_locked:
		rotate_y(-event.relative.x * mouse_sensitivity)
		pitch = clampf(pitch - event.relative.y * mouse_sensitivity, -1.2, 0.9)
		camera_pivot.rotation.x = pitch

	if event is InputEventMouseButton and event.pressed and not GameManager.input_locked:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_cam_dist = clampf(_cam_dist - 0.4, 1.8, 9.0)
			spring_arm.spring_length = _cam_dist
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_cam_dist = clampf(_cam_dist + 0.4, 1.8, 9.0)
			spring_arm.spring_length = _cam_dist

	if event.is_action_pressed("ui_cancel") and not GameManager.input_locked:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	# Quick Save / Load / Potion
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_Q and not GameManager.input_locked:
			PlayerData.use_first_potion()
		elif event.keycode == KEY_B and not GameManager.input_locked:
			_try_fish()
		elif event.keycode == KEY_V and not GameManager.input_locked and not is_swimming:
			_toggle_stealth()
		elif event.keycode == KEY_Z and not GameManager.input_locked:
			_cast_elemental_spell()
		elif event.keycode == KEY_X and not GameManager.input_locked:
			_cycle_element()
		elif event.keycode == KEY_Y and not GameManager.input_locked:
			_cycle_cultivation_path()
		elif event.keycode == KEY_O and not GameManager.input_locked:
			_attempt_cultivation_breakthrough()
		elif event.keycode == KEY_F5:
			SaveSystem.save_game()
		elif event.keycode == KEY_F9:
			SaveSystem.load_game()

func _toggle_stealth() -> void:
	is_stealthed = not is_stealthed
	if model:
		model.set_stealth_stance(is_stealthed)
	if is_stealthed:
		EventBus.toast.emit("You lower your stance and move quietly — reduced noise and detection", "info")
	else:
		_stealth_training_clock = 0.0
		EventBus.toast.emit("You rise from your crouch", "info")

func _cycle_element() -> void:
	var elements: Array[String] = SkillSystem.ELEMENTS
	if elements.is_empty():
		return
	_selected_element_index = posmod(_selected_element_index + 1, elements.size())
	selected_element = elements[_selected_element_index]
	EventBus.toast.emit("Attuned element: %s — %s" % [selected_element.capitalize(), skills.get_elemental_form(selected_element)], "info")

func _cycle_cultivation_path() -> void:
	if not CultivationDiscovery.is_cultivation_unlocked():
		EventBus.toast.emit("Cultivation is not a selectable discipline. Discover a method and earn recognition first.", "info")
		return
	var path_name: String = skills.cycle_cultivation_path(1)
	if path_name == "":
		EventBus.toast.emit("Cultivation paths reveal themselves through practice. Train a discipline first.", "info")
	else:
		EventBus.toast.emit("Active cultivation path: %s" % path_name, "levelup")

func _attempt_cultivation_breakthrough() -> void:
	if not CultivationDiscovery.is_cultivation_unlocked():
		EventBus.toast.emit("You have not discovered a legitimate cultivation method.", "warning")
		return
	if not is_on_floor() or is_swimming or Vector2(velocity.x, velocity.z).length() > 0.35:
		EventBus.toast.emit("A breakthrough requires stillness. Hold C to settle your circulation.", "warning")
		return
	var requirement: Dictionary = skills.breakthrough_requirement()
	if not bool(requirement.get("available", false)):
		EventBus.toast.emit(str(requirement.get("reason", "Your foundation is not ready.")), "warning")
		return
	if spiritual_energy < max_spiritual_energy * 0.8:
		EventBus.toast.emit("The spirit sea must be at least 80% full before a breakthrough.", "warning")
		return
	var cost: float = max_spiritual_energy * 0.65
	spiritual_energy = maxf(spiritual_energy - cost, 0.0)
	var stability: float = clampf(0.68 + skills.get_value("cultivation") * 0.002 + skills.meridian_count() * 0.018, 0.68, 0.94)
	var success: bool = randf() <= stability
	skills.complete_breakthrough(success)
	if success:
		max_spiritual_energy += 8.0 + float(skills.meridian_count()) * 1.5
		spiritual_energy = minf(max_spiritual_energy, spiritual_energy + max_spiritual_energy * 0.28)
		EventBus.toast.emit("突破  ·  Realm advanced: %s" % skills.cultivation_realm_name(), "levelup")
		EventBus.activity.emit("Broke through into %s" % skills.cultivation_realm_name(), "cultivation")
		if skills.cultivation_realm_index() == 1:
			EventBus.toast.emit("Spiritual root awakened: %s" % str(skills.cultivation_state.get("spiritual_root", "Balanced Root")), "levelup")
	else:
		EventBus.toast.emit("The breakthrough faltered. Your realm remains stable; rebuild your spirit and try again.", "warning")

func _cast_elemental_spell() -> void:
	if _spell_cooldown > 0.0 or guarding or is_swimming or health.is_dead:
		return
	var element: String = selected_element
	var skill_id: String = str(SkillSystem.ELEMENT_SKILLS.get(element, "fire_affinity"))
	var affinity: float = skills.get_value(skill_id)
	var spell_tier: int = 2 if affinity >= 25.0 else (1 if affinity >= 8.0 else 0)
	var cost: float = 7.5 + minf(affinity * 0.04, 2.0) + float(spell_tier) * 1.2
	if skills.is_cultivation_technique_active("meridian_spiral"):
		cost *= 0.86
	if spiritual_energy < cost:
		EventBus.toast.emit("Insufficient spiritual energy. Hold C while still to cultivate.", "warning")
		return
	var form_name: String = skills.get_elemental_form(element)
	var root_bonus: float = skills.elemental_root_multiplier(element)
	var realm_bonus: float = 1.0 + float(skills.cultivation_realm_index()) * 0.055
	var tier_damage: float = 1.0 + float(spell_tier) * 0.12
	var technique_bonus: float = 1.0
	if skills.is_cultivation_technique_active("meridian_spiral"):
		technique_bonus *= 1.12
	var element_technique: String = str({"fire":"flame_resonance", "water":"tide_recovery", "wind":"gale_footwork", "earth":"stone_heart", "lightning":"storm_chain", "ice":"frost_prison"}.get(element, ""))
	if element_technique != "" and skills.is_cultivation_technique_active(element_technique):
		technique_bonus *= 1.14
	if element == "water" and skills.is_cultivation_technique_active("tide_recovery"):
		technique_bonus *= 1.18
	var damage_value: float = (15.0 + affinity * 0.9 + skills.get_value("elemental_magic") * 0.38 + skills.get_value("cultivation") * 0.32) * root_bonus * realm_bonus * tier_damage * technique_bonus
	var range_value: float = 28.0 + minf(affinity * 0.12, 8.0)
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		MMORPGNetwork.request_elemental_spell(global_position, -global_transform.basis.z.normalized(), range_value, damage_value, cost, skill_id)
		spiritual_energy -= cost
		_spell_cooldown = maxf(0.48, 0.92 - affinity * 0.004)
		is_stealthed = false
		model.set_stealth_stance(false)
		EventBus.toast.emit("%s — %s Form" % [form_name, ["Foundation", "Adept", "Master"][spell_tier]], "info")
		return
	var projectile := Node3D.new()
	projectile.set_script(load("res://entities/projectile.gd"))
	projectile.set("travel_direction", -global_transform.basis.z.normalized())
	projectile.set("source", self)
	projectile.set("damage", damage_value)
	projectile.set("max_distance", range_value)
	projectile.set("projectile_kind", "elemental")
	projectile.set("spell_element", element)
	projectile.set("spell_name", form_name)
	var power_bonus: float = 1.15 if element_technique != "" and skills.is_cultivation_technique_active(element_technique) else 1.0
	projectile.set("spell_power", (1.0 + affinity * 0.012) * power_bonus)
	projectile.set("spell_tier", spell_tier)
	get_tree().current_scene.add_child(projectile)
	projectile.global_position = global_position + Vector3.UP * 1.25 - global_transform.basis.z * 0.85
	spiritual_energy -= cost
	_spell_cooldown = maxf(0.48, 0.92 - affinity * 0.004)
	is_stealthed = false
	model.set_stealth_stance(false)
	VFX.burst(self, global_position + Vector3.UP * 1.0, _element_color(element), 10, 2.4, 0.045)
	skills.train("elemental_magic", 0.16, true)
	skills.train(skill_id, 0.22, true)
	skills.train("cultivation", 0.045, true)
	skills.refresh_meridian_unlocks()
	EventBus.toast.emit("%s — %s Form" % [form_name, ["Foundation", "Adept", "Master"][spell_tier]], "info")
	EventBus.activity.emit("Shaped %s with %s" % [form_name, element.capitalize()], "cultivation")

func _element_color(element: String) -> Color:
	match element:
		"fire": return Color(1.0, 0.32, 0.08)
		"water": return Color(0.18, 0.62, 1.0)
		"wind": return Color(0.6, 0.95, 0.76)
		"earth": return Color(0.72, 0.54, 0.31)
		"lightning": return Color(0.95, 0.86, 0.22)
		"ice": return Color(0.55, 0.88, 1.0)
	return Color(0.72, 0.62, 1.0)

func get_stealth_detection_multiplier() -> float:
	if not is_stealthed:
		return 1.0
	var trained: float = skills.get_value("stealth") if skills and skills.values.has("stealth") else 0.0
	var detection: float = clampf(0.48 - trained * 0.002, 0.2, 0.48)
	if skills.is_cultivation_technique_active("shadow_breath"):
		detection *= 0.78
	return detection

func _try_fish() -> void:
	var fs: Node = get_tree().get_first_node_in_group("fishing")
	if fs and fs.has_method("try_fish"):
		fs.try_fish(self)
	else:
		EventBus.toast.emit("Cannot fish here", "warning")

# Gameplay actions use _unhandled_input so UI (dialogue, panels) can consume the same click / key.
func _unhandled_input(event: InputEvent) -> void:
	if health.is_dead or GameManager.input_locked:
		return
	if event.is_action_pressed("attack"):
		# A gameplay click should never be wasted solely on recapturing the cursor.
		# UI controls consume their own clicks before _unhandled_input reaches here.
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		_try_attack()
	elif event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_K:
		# Keyboard fallback for players whose mouse is unavailable or awkward to recapture.
		_try_attack()
	elif event.is_action_pressed("interact"):
		_try_interact()
	elif event.is_action_pressed("tame_mount"):
		TamingMountSystem.handle_mount_input(self)
	elif event.is_action_pressed("mount_care"):
		TamingMountSystem.care_active()
	elif event.is_action_pressed("mount_saddle"):
		TamingMountSystem.equip_tack("saddle")
	elif event.is_action_pressed("mount_armor"):
		TamingMountSystem.equip_tack("armor")
	elif event.is_action_pressed("mount_breed"):
		TamingMountSystem.breed_active()
	elif event.is_action_pressed("mount_next"):
		TamingMountSystem.select_next_companion()
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_P:
		AppraisalSystem.appraise(self)
	elif event.is_action_pressed("dodge"):
		_try_dodge()

# ---------------------------------------------------------------------------
# Physics
# ---------------------------------------------------------------------------
func _physics_process(delta: float) -> void:
	# Poll the action as a second input path. Some full-screen HUD Controls consume
	# mouse events before _unhandled_input; polling preserves combat input while
	# GameManager's UI lock still prevents attacks inside menus/dialogue.
	if not GameManager.input_locked and Input.is_action_just_pressed("attack"):
		_try_attack()
	gravity = PhysicalWorldSystem.gravity_at(global_position)
	_invuln = maxf(_invuln - delta, 0.0)
	_spell_cooldown = maxf(_spell_cooldown - delta, 0.0)
	_dodge_window = maxf(_dodge_window - delta, 0.0)
	_dodge_cooldown = maxf(_dodge_cooldown - delta, 0.0)
	_combat_combo_timer = maxf(_combat_combo_timer - delta, 0.0)
	guarding = Input.is_action_pressed("guard") and not GameManager.input_locked and not is_swimming and guard_stamina > 0.5
	_guard_time = _guard_time + delta if guarding else 0.0
	if guarding:
		guard_stamina = maxf(guard_stamina - 19.0 * delta, 0.0)
	else:
		guard_stamina = minf(100.0, guard_stamina + (12.0 if is_on_floor() else 7.0) * delta)
	_update_camera_feedback(delta)
	if _combat_combo_timer <= 0.0:
		_combat_combo_count = 0
	_since_damage += delta
	if health.is_dead:
		velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
		if not is_on_floor():
			velocity.y -= gravity * delta
		move_and_slide()
		return
	_handle_aging(delta)
	_process_cultivation(delta)
	_handle_movement(delta)
	_update_gather(delta)
	_update_focus()
	_update_zone(delta)
	_check_fell_out_of_world()
	if MMORPGNetwork.is_online():
		MMORPGNetwork.publish_local_player(global_position, rotation.y)
	if _since_damage > 6.0 and health.current_health < health.max_health and (not MMORPGNetwork.is_online() or multiplayer.is_server()):
		health.heal(2.0 * delta)

func _handle_aging(_delta: float) -> void:
	var new_age: float = Constants.STARTING_AGE + GameManager.get_game_time_years()
	if int(new_age) > int(current_age):
		previous_age = current_age
		current_age = new_age
		EventBus.player_aged.emit(current_age, previous_age)
		_on_age_up()
	else:
		current_age = new_age
	if current_age >= skills.lifespan_years() and not health.is_dead:
		PlayerData.stats["death_cause"] = "old_age"
		health.take_damage(health.current_health, null)

func _on_age_up() -> void:
	print("[Player] Birthday! Now age %.0f" % current_age)
	EventBus.toast.emit("Happy birthday! You are now %d" % int(current_age), "levelup")
	refresh_age_visuals()

func _handle_movement(delta: float) -> void:
	var locked: bool = GameManager.input_locked
	var input_dir := Vector2.ZERO
	if not locked:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction: Vector3 = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	var environment_for_climb := get_tree().get_first_node_in_group("environment_world")
	if environment_for_climb and environment_for_climb.has_method("is_player_climbing") and environment_for_climb.is_player_climbing(self):
		environment_for_climb.update_climbing(self, input_dir, delta)
		if not locked and Input.is_action_just_pressed("jump"):
			environment_for_climb.end_climbing(self, true)
		return

	# Dungeon floors live far below the overworld water plane. Treating their
	# negative Y position as deep water applied buoyancy and made the player float.
	var in_dungeon: bool = get_tree().get_first_node_in_group("dungeon_active") != null
	var inside_cave: bool = bool(get_meta("inside_cave", false))
	var surface_level: float = TideSystem.level_at(global_position.x, global_position.z) if is_instance_valid(TideSystem) else Constants.WATER_LEVEL
	var depth: float = 0.0 if in_dungeon or inside_cave else surface_level - global_position.y
	var environment := get_tree().get_first_node_in_group("environment_world")
	var landmark_water: bool = environment != null and environment.has_method("is_in_water") and environment.is_in_water(global_position)
	if landmark_water: depth = maxf(depth, 2.0)
	is_swimming = not in_dungeon and not inside_cave and (depth > 1.0 or landmark_water)
	is_running = not locked and Input.is_key_pressed(KEY_SHIFT) and input_dir.length() > 0.1 and not is_swimming
	var speed: float = (run_speed if is_running else walk_speed) * skills.speed_mult() * TamingMountSystem.movement_multiplier()
	if is_swimming and skills.is_cultivation_technique_active("flowing_breath"):
		speed *= 1.15
	if is_stealthed:
		speed *= 0.52
	if model:
		model.set_stealth_stance(is_stealthed)
		if input_dir.length() > 0.1 and not is_running:
			_stealth_training_clock += delta
			if _stealth_training_clock >= 3.0:
				_stealth_training_clock = 0.0
				skills.train("stealth", 0.08, true)
		if is_running:
			is_stealthed = false
			EventBus.toast.emit("You break cover by running", "info")
	if not in_dungeon and depth > 0.25:
		speed *= 0.65 if is_swimming else 0.85

	if is_swimming:
		if skills and randf() < 0.02:
			skills.train("swimming", 0.08, true)

		# Swimmers control buoyancy directly: SPACE ascends and CTRL dives.
		var vertical_input := 0.0
		if not locked:
			if Input.is_action_pressed("jump") or Input.is_key_pressed(KEY_SPACE):
				vertical_input += 1.0
			if Input.is_key_pressed(KEY_CTRL):
				vertical_input -= 1.0
		var target_y: float = vertical_input * speed * 0.78
		if absf(vertical_input) < 0.01:
			target_y = clampf((depth - 1.0) * 0.55, -0.65, 0.9)
		velocity.y = lerpf(velocity.y, target_y, clampf(delta * 2.8, 0.0, 1.0))
	elif not is_on_floor():
		velocity.y -= gravity * delta

	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed * 8.0 * delta)
		velocity.z = move_toward(velocity.z, 0, speed * 8.0 * delta)

	# Knockback from enemy hits
	velocity.x += _kb.x
	velocity.z += _kb.z
	_kb = _kb.move_toward(Vector3.ZERO, 30.0 * delta)

	if not locked and Input.is_action_just_pressed("jump") and is_on_floor() and not is_swimming:
		velocity.y = jump_velocity

	move_and_slide()

	# Small camera movement and surface-aware footsteps sell the weight of travel.
	var grounded_speed: float = Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and grounded_speed > 0.8 and not guarding:
		_camera_bob_clock += delta * (10.5 if is_running else 7.2)
		_step_distance += grounded_speed * delta
		var stride: float = 1.65 if is_running else 2.15
		if _step_distance >= stride:
			_step_distance = 0.0
			_play_footstep()
	else:
		_step_distance = minf(_step_distance, 0.35)
		_camera_bob_clock = lerpf(_camera_bob_clock, 0.0, delta * 5.0)
	camera_pivot.position.y = _camera_base_y + (sin(_camera_bob_clock) * (0.035 if is_running else 0.018) if is_on_floor() and grounded_speed > 0.8 else 0.0)

	# Learning by doing: running trains Agility, travelling trains Exploration
	if is_running and is_on_floor():
		_run_train += delta
		if _run_train >= 2.0:
			_run_train = 0.0
			skills.train("agility", 0.04, true)
	var moved: float = Vector2(global_position.x - _last_pos.x, global_position.z - _last_pos.z).length()
	_last_pos = global_position
	if moved < 3.0:
		_walked += moved
		if _walked >= 40.0:
			_walked = 0.0
			skills.train("exploration", 0.05, true)

	# Character model: face the direction of travel (or forward while fighting)
	if model.is_attacking():
		model.rotation.y = lerp_angle(model.rotation.y, 0.0, clampf(delta * 14.0, 0.0, 1.0))
	elif input_dir != Vector2.ZERO:
		var target: float = atan2(-input_dir.x, -input_dir.y)
		model.rotation.y = lerp_angle(model.rotation.y, target, clampf(delta * 12.0, 0.0, 1.0))
	var horiz: float = Vector2(velocity.x, velocity.z).length()
	model.set_motion(horiz / (walk_speed * skills.speed_mult()) if is_on_floor() or is_swimming else 0.5)

	var target_fov: float = 72.0 + (7.0 if is_running else 0.0) + _scale_fov_bonus
	camera.fov = lerpf(camera.fov, target_fov, clampf(delta * 6.0, 0.0, 1.0))


func _build_footstep_audio() -> void:
	_step_audio = AudioStreamPlayer3D.new()
	_step_audio.name = "Footsteps"
	_step_audio.bus = "Master"
	_step_audio.volume_db = -12.0
	_step_audio.max_distance = 22.0
	_step_audio.unit_size = 5.0
	_step_audio.stream = _make_footstep_sample()
	add_child(_step_audio)

func _make_footstep_sample() -> AudioStreamWAV:
	# A soft boot-on-stone transient: low double thump with restrained filtered grit.
	const RATE := 22050
	const LENGTH := 0.19
	var bytes := PackedByteArray()
	var count := int(RATE * LENGTH)
	bytes.resize(count * 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = 87231
	var low_state: float = 0.0
	for i in range(count):
		var t := float(i) / float(RATE)
		var envelope := exp(-t * 34.0)
		var thump := sin(TAU * (62.0 - 15.0 * t / LENGTH) * t) * 0.42
		var heel := sin(TAU * 94.0 * maxf(t - 0.035, 0.0)) * exp(-maxf(t - 0.035, 0.0) * 70.0) * 0.13
		low_state = lerpf(low_state, rng.randf_range(-1.0, 1.0), 0.10)
		var grit := low_state * exp(-t * 48.0) * 0.055
		var sample := (thump + heel + grit) * envelope * 0.46
		bytes.encode_s16(i * 2, int(clampf(sample, -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	return wav

func _has_clear_attack_path(target: Node3D) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	# Trace through the torso rather than down toward the enemy's feet. This avoids
	# the terrain collider falsely eating swings against low creatures such as slimes.
	var from: Vector3 = global_position + Vector3.UP * 1.15
	var to: Vector3 = target.global_position + Vector3.UP * 0.9
	var query := PhysicsRayQueryParameters3D.create(from, to, Constants.LAYER_WORLD, [get_rid()])
	query.collide_with_areas = false
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return true
	# A collision immediately beside the target is usually a floor lip, foliage,
	# or the target's own terrain contact. A wall farther along still blocks damage.
	var hit_position: Vector3 = hit.get("position", to)
	return hit_position.distance_to(to) <= 0.85 or global_position.distance_to(target.global_position) <= 1.55

func _spawn_combat_projectile(weapon_class: String, direction: Vector3, damage_value: float, max_range: float, impact_radius: float = 0.0) -> void:
	var projectile := Node3D.new()
	projectile.set_script(load("res://entities/projectile.gd"))
	projectile.global_position = global_position + Vector3.UP * 1.15 + direction * 0.75
	projectile.set("travel_direction", direction.normalized())
	projectile.set("source", self)
	projectile.set("damage", damage_value)
	projectile.set("max_distance", max_range)
	projectile.set("projectile_kind", weapon_class)
	projectile.set("impact_radius", impact_radius)
	projectile.set("impact_damage_ratio", 0.42 if impact_radius > 0.0 else 0.0)
	get_tree().current_scene.add_child(projectile)
	projectile.global_position = global_position + Vector3.UP * 1.15 + direction * 0.75
	skills.train("archery" if weapon_class == "bow" else "elemental_magic", 0.16, true)
	if weapon_class in ["staff", "wand"]:
		skills.train("cultivation", 0.08, true)

func _build_cultivation_visual() -> void:
	_cultivation_ring = MeshInstance3D.new()
	_cultivation_ring.name = "CultivationCirculationAura"
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.48
	ring_mesh.outer_radius = 0.56
	ring_mesh.rings = 8
	ring_mesh.ring_segments = 24
	_cultivation_ring.mesh = ring_mesh
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color(0.35, 0.62, 1.0, 0.34)
	ring_mat.emission_enabled = true
	ring_mat.emission = Color(0.28, 0.55, 1.0)
	ring_mat.emission_energy_multiplier = 1.35
	ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_cultivation_ring.material_override = ring_mat
	_cultivation_ring.position = Vector3(0, 0.88, 0)
	_cultivation_ring.rotation.x = PI * 0.5
	_cultivation_ring.visible = false
	add_child(_cultivation_ring)

func _process_cultivation(delta: float) -> void:
	if not CultivationDiscovery.is_cultivation_unlocked():
		_cultivating = false
		_cultivation_clock = 0.0
		if _cultivation_ring:
			_cultivation_ring.visible = false
		return
	if MMORPGNetwork.is_online():
		var network_holding: bool = Input.is_key_pressed(KEY_C) and not GameManager.input_locked and not health.is_dead and is_on_floor() and Vector2(velocity.x, velocity.z).length() < 0.35 and not is_swimming
		_cultivating = network_holding
		if _cultivation_ring:
			_cultivation_ring.visible = network_holding
			if network_holding:
				cultivation_ring_rotate(delta)
		_network_cultivation_clock += delta
		if _network_cultivation_clock >= 0.35:
			_network_cultivation_clock = 0.0
			MMORPGNetwork.submit_cultivation_intent(global_position, network_holding)
		return
	var holding: bool = Input.is_key_pressed(KEY_C) and not GameManager.input_locked and not health.is_dead
	if holding and is_on_floor() and Vector2(velocity.x, velocity.z).length() < 0.35 and not is_swimming:
		_cultivating = true
		if _cultivation_ring:
			_cultivation_ring.visible = true
			cultivation_ring_rotate(delta)
		max_spiritual_energy = 30.0 + skills.get_value("cultivation") * 0.45
		var breathing_bonus: float = 1.16 if skills.is_cultivation_technique_active("still_mind") else 1.0
		spiritual_energy = minf(max_spiritual_energy, spiritual_energy + (1.8 + skills.get_value("cultivation") * 0.018) * breathing_bonus * delta)
		_cultivation_clock += delta
		if _cultivation_clock >= 2.5:
			_cultivation_clock = 0.0
			skills.train("cultivation", 0.12, true)
			skills.train("arcane_attunement", 0.06, true)
			skills.refresh_meridian_unlocks()
		var realm_capacity: float = float(SkillSystem.CULTIVATION_REALMS[skills.cultivation_realm_index()].get("capacity", 0.0))
		max_spiritual_energy = 30.0 + skills.get_value("cultivation") * 0.45 + skills.meridian_count() * 3.0 + realm_capacity
		spiritual_energy = minf(spiritual_energy, max_spiritual_energy)
	else:
		_cultivating = false
		_cultivation_clock = 0.0
		if _cultivation_ring:
			_cultivation_ring.visible = false

func cultivation_ring_rotate(delta: float) -> void:
	if _cultivation_ring:
		_cultivation_ring.rotate_y(delta * 0.85)

func _play_footstep() -> void:
	if _step_audio == null or is_swimming:
		return
	_step_audio.global_position = global_position + Vector3(0.0, 0.08, 0.0)
	var dungeon := get_tree().get_first_node_in_group("dungeon_active") != null
	var coast := current_zone in ["Mirror Pond", "Lonely Lake"] or global_position.x > 30.0 and global_position.z > -35.0
	if dungeon:
		_step_audio.pitch_scale = randf_range(0.72, 0.9)
		_step_audio.volume_db = -8.0
	elif coast:
		_step_audio.pitch_scale = randf_range(1.08, 1.22)
		_step_audio.volume_db = -17.0
	elif current_zone == "Elyndor Village":
		_step_audio.pitch_scale = randf_range(0.94, 1.08)
		_step_audio.volume_db = -13.0
	else:
		_step_audio.pitch_scale = randf_range(0.86, 1.06)
		_step_audio.volume_db = -15.0
	if is_stealthed:
		_step_audio.volume_db -= 10.0
	if not _step_audio.playing:
		_step_audio.play()

func _update_camera_feedback(delta: float) -> void:
	_shake_strength = move_toward(_shake_strength, 0.0, delta * 1.8)
	_shake_clock += delta * 34.0
	if camera:
		camera.h_offset = sin(_shake_clock) * _shake_strength
		camera.v_offset = cos(_shake_clock * 1.37) * _shake_strength * 0.65
	# Give colossal creatures room in frame so their scale reads clearly.
	var giant_presence := 0.0
	for beast in get_tree().get_nodes_in_group("colossal_beast"):
		if is_instance_valid(beast):
			var d := global_position.distance_to(beast.global_position)
			giant_presence = maxf(giant_presence, 1.0 - clampf(d / 34.0, 0.0, 1.0))
	var landmark_presence := 0.0
	for tree in get_tree().get_nodes_in_group("hero_tree"):
		if is_instance_valid(tree):
			var td := global_position.distance_to(tree.global_position)
			landmark_presence = maxf(landmark_presence, 1.0 - clampf(td / 18.0, 0.0, 1.0))
	if spring_arm:
		var framing_distance := _cam_dist + giant_presence * 3.0 + landmark_presence * 0.8
		spring_arm.spring_length = lerpf(spring_arm.spring_length, framing_distance, clampf(delta * 2.2, 0.0, 1.0))
	_scale_fov_bonus = lerpf(_scale_fov_bonus, giant_presence * 5.0, clampf(delta * 1.8, 0.0, 1.0))

func _check_fell_out_of_world() -> void:
	# Dungeon floors are intentionally built far below the overworld. Do not let
	# the overworld fall-rescue teleport dungeon players back onto the surface.
	var active_dungeon: Node3D = get_tree().get_first_node_in_group("dungeon_active") as Node3D
	if active_dungeon != null:
		var floor_index: int = int(active_dungeon.get("current_floor"))
		var floor_y: float = active_dungeon.global_position.y - float(floor_index) * 30.0
		# Safety recovery only if the player actually falls through this dungeon floor.
		if global_position.y < floor_y - 12.0:
			# Room slab top is +0.30 from its origin; player root is at the feet.
			global_position = Vector3(active_dungeon.global_position.x, floor_y + 0.34, active_dungeon.global_position.z + 6.0)
			velocity = Vector3.ZERO
		return
	if global_position.y < -60.0:
		if _noise == null:
			_noise = TerrainNoise.new(GameManager.world_seed)
		var sp: Vector2 = Constants.SPAWN_XZ
		global_position = Vector3(sp.x, _noise.get_height(sp.x, sp.y) + 2.0, sp.y)
		velocity = Vector3.ZERO

# ---------------------------------------------------------------------------
# Interaction
# ---------------------------------------------------------------------------
func _update_focus() -> void:
	var best: Node = null
	var best_d: float = 99.0
	if not GameManager.input_locked and _gather_node == null:
		for node in get_tree().get_nodes_in_group("interactable"):
			if not is_instance_valid(node) or not node.has_method("can_interact") or not node.can_interact():
				continue
			var d: float = global_position.distance_to(node.global_position)
			var rng: float = float(node.get("interact_range")) if node.get("interact_range") != null else 3.2
			if d < rng and d < best_d:
				best_d = d
				best = node
	if best != focus_target:
		focus_target = best
		if focus_target:
			EventBus.interaction_available.emit(focus_target)
		else:
			EventBus.interaction_cleared.emit()

func _try_interact() -> void:
	var environment := get_tree().get_first_node_in_group("environment_world")
	if environment and environment.has_method("try_interact") and environment.try_interact(self):
		focus_target = null
		EventBus.interaction_cleared.emit()
		return
	if focus_target and is_instance_valid(focus_target):
		var t: Node = focus_target
		EventBus.interaction_cleared.emit()
		t.interact(self)

# ---------------------------------------------------------------------------
# Gathering
# ---------------------------------------------------------------------------
func begin_gather(node: Node) -> void:
	if _gather_node != null or health.is_dead:
		return
	_gather_node = node
	_gather_t = 0.0
	_gather_swing = 0.0
	gather_ratio = 0.0
	gather_text = node.get_prompt() + "..."
	focus_target = null
	EventBus.interaction_cleared.emit()

func cancel_gather(msg: String = "") -> void:
	if _gather_node == null:
		return
	_gather_node = null
	gather_ratio = -1.0
	if msg != "":
		EventBus.toast.emit(msg, "info")

func _update_gather(delta: float) -> void:
	if _gather_node == null:
		return
	if not is_instance_valid(_gather_node) or not _gather_node.can_interact():
		cancel_gather()
		return
	if global_position.distance_to(_gather_node.global_position) > 4.2:
		cancel_gather("Too far away")
		return
	if not GameManager.input_locked and Input.get_vector("move_left", "move_right", "move_forward", "move_back").length() > 0.3:
		cancel_gather("Gathering cancelled")
		return
	_gather_t += delta
	var total: float = float(_gather_node.harvest_time)
	if skills.is_cultivation_technique_active("living_root"):
		total *= 0.88
	gather_ratio = clampf(_gather_t / total, 0.0, 1.0)
	# face the node and swing
	var d: Vector3 = global_transform.basis.inverse() * (_gather_node.global_position - global_position)
	model.rotation.y = lerp_angle(model.rotation.y, atan2(-d.x, -d.z), clampf(delta * 14.0, 0.0, 1.0))
	_gather_swing -= delta
	if _gather_swing <= 0.0:
		_gather_swing = 0.7
		model.play_attack(-model_swing_side())
		VFX.burst(self, _gather_node.global_position + Vector3(0, 0.8, 0), Color(0.9, 0.8, 0.5), 6, 2.5, 0.04)
	if _gather_t >= total:
		var n: Node = _gather_node
		_gather_node = null
		gather_ratio = -1.0
		n.attempt(skills)

func model_swing_side() -> float:
	_swing_side = -_swing_side
	return _swing_side

# ---------------------------------------------------------------------------
# Zones & discovery
# ---------------------------------------------------------------------------
func _update_zone(delta: float) -> void:
	_zone_timer -= delta
	if _zone_timer > 0.0:
		return
	_zone_timer = 0.5
	var p := Vector2(global_position.x, global_position.z)
	var found: String = ""
	var best: float = 99999.0
	for z in QuestDB.ZONES:
		var d: float = p.distance_to(z["pos"])
		if d < float(z["radius"]) and d < best:
			best = d
			found = z["name"]
	if found != current_zone:
		current_zone = found
		if found != "":
			if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
				MMORPGNetwork.request_zone_discovery(found)
			var first: bool = PlayerData.discover_zone(found)
			EventBus.zone_entered.emit(found, first)
			if first:
				var gain: float = skills.train("exploration", 1.5)
				EventBus.activity.emit("Discovered: %s" % found, "quest")
				if PlayerData.zones.size() >= QuestDB.ZONES.size():
					PlayerData.grant_title("Pathfinder")

# ---------------------------------------------------------------------------
func _held_visual_for_equipment() -> String:
	var equipped: Dictionary = PlayerData.equipment.get("weapon", {})
	var weapon_id: String = str(equipped.get("id", ""))
	var weapon_class: String = str(ItemDB.def(weapon_id).get("weapon_class", "sword"))
	match weapon_class:
		"axe": return "axe"
		"dagger": return "daggers" if weapon_id in ["paired_fang_daggers", "moonshadow_stilettos", "packlord_fang"] else "dagger"
		"spear": return "spear"
		"blunt": return "hammer"
		"bow": return "bow"
		"staff": return "staff"
		"wand": return "wand"
		_: return "sword"

func _on_equipment_changed() -> void:
	refresh_stats()
	if model:
		model.set_held_weapon(_held_visual_for_equipment())

# Combat
# ---------------------------------------------------------------------------
func _try_dodge() -> void:
	if _dodge_cooldown > 0.0 or is_swimming or not is_on_floor() or GameManager.input_locked:
		return
	var input_dir: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var local_dir: Vector3 = Vector3(input_dir.x, 0.0, input_dir.y)
	if local_dir.length() < 0.1:
		local_dir = Vector3(0.0, 0.0, 1.0)
	if is_stealthed:
		is_stealthed = false
		model.set_stealth_stance(false)
		EventBus.toast.emit("You break cover with a sudden dodge", "info")
	_dodge_direction = (transform.basis * local_dir).normalized()
	var evade_mastery: float = skills.get_value("evasion")
	var dodge_speed: float = 10.5 + minf(evade_mastery * 0.025, 2.0)
	velocity.x = _dodge_direction.x * dodge_speed
	velocity.z = _dodge_direction.z * dodge_speed
	_invuln = minf(0.38, 0.28 + evade_mastery * 0.0015)
	_dodge_window = _invuln
	_dodge_cooldown = maxf(0.65, 1.15 - evade_mastery * 0.006)
	_combat_combo_timer = maxf(_combat_combo_timer, 1.0)
	model.rotation.y = atan2(-_dodge_direction.x, -_dodge_direction.z)
	VFX.burst(self, global_position + Vector3(0, 0.12, 0), Color(0.72, 0.72, 0.68, 0.65), 8, 2.4, 0.07)
	EventBus.activity.emit("Evaded — reposition and keep the pressure", "combat")

func _try_attack() -> void:
	if guarding or not can_attack:
		return
	var equipped_for_opening: Dictionary = PlayerData.equipment.get("weapon", {})
	var opening_weapon: String = str(ItemDB.def(str(equipped_for_opening.get("id", ""))).get("weapon_class", "sword"))
	_stealth_strike_pending = is_stealthed and opening_weapon == "dagger"
	is_stealthed = false
	if model:
		model.set_stealth_stance(false)
	can_attack = false
	_swing_side = -_swing_side
	var equipped: Dictionary = PlayerData.equipment.get("weapon", {})
	var weapon_id: String = str(equipped.get("id", ""))
	var weapon_def: Dictionary = ItemDB.def(weapon_id)
	var weapon_class: String = str(weapon_def.get("weapon_class", "sword"))
	if weapon_class == "dagger":
		model.attack_duration = 0.28 if _stealth_strike_pending else 0.34
	elif weapon_class in ["axe", "blunt"]:
		model.attack_duration = 0.58
	elif weapon_class in ["bow", "staff", "wand"]:
		model.attack_duration = 0.5
	else:
		model.attack_duration = 0.45
	_attack_impact_generation += 1
	_attack_impact_resolved = false
	model.play_attack(_swing_side, _stealth_strike_pending)
	# Safety net: if a model animation is interrupted or its impact event is missed,
	# the attack still resolves once. The generation prevents an old timer hitting
	# during a newer swing, and the resolved flag prevents double damage.
	var impact_generation: int = _attack_impact_generation
	var fallback_delay: float = maxf(model.attack_duration * 0.68, 0.24)
	get_tree().create_timer(fallback_delay).timeout.connect(func() -> void:
		if impact_generation == _attack_impact_generation and not _attack_impact_resolved and _gather_node == null:
			_on_attack_impact())
	var speed: float = float(weapon_def.get("attack_speed", 1.0))
	get_tree().create_timer(attack_cooldown / maxf(speed, 0.5)).timeout.connect(func() -> void: can_attack = true)

func _is_backstab_target(target: Node) -> bool:
	if not target is Node3D or not is_instance_valid(target):
		return false
	var target_node: Node3D = target as Node3D
	var visual_value: Variant = target.get("_visual")
	var facing_node: Node3D = visual_value as Node3D if visual_value is Node3D else target_node
	var to_player: Vector3 = global_position - target_node.global_position
	to_player.y = 0.0
	if to_player.length_squared() < 0.01:
		return false
	var target_forward: Vector3 = -facing_node.global_transform.basis.z
	target_forward.y = 0.0
	if target_forward.length_squared() < 0.01:
		return false
	return target_forward.normalized().dot(to_player.normalized()) < -0.45

func _on_attack_impact() -> void:
	if _gather_node != null or _attack_impact_resolved:
		return
	_attack_impact_resolved = true
	var fwd: Vector3 = -global_transform.basis.z
	var equipped: Dictionary = PlayerData.equipment.get("weapon", {})
	var weapon_id: String = str(equipped.get("id", ""))
	var weapon_def: Dictionary = ItemDB.def(weapon_id)
	var weapon_class: String = str(weapon_def.get("weapon_class", "sword"))
	var skill_id: String = skills.weapon_skill_id(weapon_class)
	var reach: float = float(weapon_def.get("reach", Constants.ATTACK_RANGE + 0.7))
	if weapon_class == "sword":
		reach = maxf(reach, 3.35)
	elif weapon_class == "dagger":
		reach = maxf(reach, 3.0)
	if weapon_class == "spear":
		reach = maxf(reach, 3.8)
	elif weapon_class == "bow":
		reach = maxf(reach, 15.0)
	elif weapon_class in ["staff", "wand"]:
		reach = maxf(reach, 13.0)
	var base: float = PlayerData.weapon_damage() * skills.weapon_damage_mult(skill_id)
	if weapon_class in ["sword", "dagger", "spear"] and skills.is_cultivation_technique_active("blade_intent"):
		base *= 1.08
	base *= _set_bonus_mult()
	if _riposte_ready:
		base *= 1.85
	var ability: String = ""
	if _combat_combo_count >= 2:
		ability = skills.try_flow_technique(weapon_class, _combat_combo_count + 1)
	var radius_bonus: float = 0.0
	match ability:
		"heavy_strike": base *= 2.35
		"cleave":
			base *= 1.35
			radius_bonus = 1.5
		"shadow_flurry": base *= 1.65
		"sundering_chop": base *= 2.0
		"piercing_thrust":
			base *= 1.8
			reach += 1.5
		"groundbreaker":
			base *= 1.9
			radius_bonus = 2.4
		"piercing_shot": base *= 2.25
		"arcane_burst":
			base *= 1.65
			radius_bonus = 2.8
		"eclipse_counter":
			base *= 2.65
			radius_bonus = 0.85
		"dragon_piercer":
			base *= 2.45
			reach += 2.6
		"starfall_burst":
			base *= 2.15
			radius_bonus = 3.6
		"void_step": base *= 2.1

	var hit_any: bool = false
	var is_ranged: bool = weapon_class in ["bow", "staff", "wand"]
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		MMORPGNetwork.request_combat_action(global_position, fwd, reach + radius_bonus, base, skill_id)
		_stealth_strike_pending = false
		if is_ranged:
			_spawn_combat_projectile(weapon_class, fwd, base, reach, 0.0)
		else:
			_spawn_slash_fx(false)
		PlayerData.wear("weapon", 0.5)
		return
	if is_ranged:
		var energy_cost: float = 5.0 if weapon_class == "bow" else 8.0
		if weapon_class in ["staff", "wand"] and spiritual_energy < energy_cost:
			if ability != "":
				skills.refund_flow_technique(ability)
			EventBus.toast.emit("Your spiritual energy is too low. Cultivate with C.", "warning")
			return
		if weapon_class in ["staff", "wand"]:
			spiritual_energy -= energy_cost
		var projectile_damage: float = base * (1.0 + skills.get_value("cultivation") * 0.0025 if weapon_class in ["staff", "wand"] else 1.0)
		_spawn_combat_projectile(weapon_class, fwd, projectile_damage, reach, 3.6 if ability == "starfall_burst" else (2.8 if ability == "arcane_burst" else 0.0))
	var attack_targets: Array = get_tree().get_nodes_in_group("enemy") if not is_ranged else []
	for e in attack_targets:
		if not is_instance_valid(e) or not e.has_method("take_damage"):
			continue
		var to: Vector3 = e.global_position - global_position
		var dist: float
		if is_swimming and e.is_in_group("marine_hostile"):
			dist = global_position.distance_to(e.global_position)
			to.y = 0.0 # Facing remains horizontal; reach is genuinely three-dimensional.
		else:
			to.y = 0.0
			dist = to.length()
		if dist > reach + radius_bonus:
			continue
		if radius_bonus <= 0.0 and dist > 0.6:
			var facing: float = fwd.dot(to.normalized())
			var required_facing: float = 0.62 if weapon_class in ["bow", "staff", "wand"] else (0.08 if weapon_class == "spear" else 0.05)
			if facing < required_facing:
				continue
		# Solid dungeon walls and overworld obstacles block melee reach.
		if not _has_clear_attack_path(e):
			continue
		var crit_chance: float = skills.crit_chance()
		if weapon_class == "dagger":
			crit_chance += minf(skills.get_value("dagger_mastery") * 0.001, 0.12)
		if weapon_class == "bow":
			crit_chance += minf(skills.get_value("archery") * 0.0008, 0.08) + skills.ranged_crit_bonus()
		var crit: bool = randf() < clampf(crit_chance, 0.0, 0.65)
		var dmg: float = base * (1.8 if crit else 1.0) * randf_range(0.92, 1.08)
		var backstab: bool = _is_backstab_target(e) if _stealth_strike_pending else false
		if backstab:
			dmg *= 3.0 + minf(skills.get_value("stealth") * 0.012, 0.6)
			if ability == "void_step":
				dmg *= 1.32
			if skills.is_cultivation_technique_active("shadow_breath"):
				dmg *= 1.12
			e.take_damage(dmg, self, true)
			EventBus.toast.emit("BACKSTAB — devastating opening strike", "levelup")
			skills.train("stealth", 0.28, true)
		else:
			e.take_damage(dmg, self, crit)
		hit_any = true
		var rhythm_bonus: float = minf(float(_combat_combo_count) * 0.025, 0.15)
		skills.train(skill_id, 0.12 + rhythm_bonus, true)
		skills.train("precision", 0.18 if crit else 0.06, true)
		if weapon_class == "dagger":
			skills.train("dual_wield", 0.025, true)
	_stealth_strike_pending = false
	if hit_any:
		if _riposte_ready:
			_riposte_ready = false
			skills.record_technique_practice("riposte", true)
			EventBus.toast.emit("Riposte! Counterattack landed", "levelup")
			VFX.burst(self, global_position + fwd * 1.2 + Vector3.UP, Color(0.55, 0.88, 1.0), 20, 6.0, 0.055)
			VFX.impact_ring(self, global_position, Color(0.42, 0.78, 1.0), 1.55)
			_shake_strength = maxf(_shake_strength, 0.16)
		if ability != "":
			skills.record_technique_practice(ability, true)
		_combat_combo_count = mini(_combat_combo_count + 1, 8)
		_combat_combo_timer = 2.4
		if _combat_combo_count == 2:
			EventBus.toast.emit("Combo building — keep your rhythm!", "skill")
		elif _combat_combo_count >= 4:
			EventBus.activity.emit("%d-hit combat chain" % _combat_combo_count, "skill")
	else:
		_combat_combo_count = 0
		_combat_combo_timer = 0.0
		if ability != "":
			skills.refund_flow_technique(ability)

	if weapon_class in ["bow", "staff", "wand"]:
		var shot_color: Color = Color(0.42, 0.78, 1.0) if weapon_class == "bow" else Color(0.72, 0.48, 1.0)
		VFX.burst(self, global_position + fwd * minf(reach, 7.0) + Vector3.UP * 1.1, shot_color, 8 if hit_any else 4, 3.2, 0.04)
	else:
		_spawn_slash_fx(hit_any)
		VFX.weapon_sweep(self, global_position + fwd * 0.95 + Vector3.UP * 1.0, fwd, Color(1.0, 0.82, 0.48) if hit_any else Color(0.72, 0.78, 0.88), hit_any)
	if hit_any:
		_shake_strength = maxf(_shake_strength, 0.055 if not ability else 0.13)
	if ability != "" and hit_any:
		VFX.dust_puff(self, global_position, 1.15)
		VFX.impact_ring(self, global_position + fwd * 0.75, Color(0.62, 0.78, 1.0) if weapon_class in ["staff", "wand"] else Color(1.0, 0.72, 0.34), 1.7 + radius_bonus * 0.2)
		EventBus.toast.emit("Technique flows: %s" % ability.replace("_", " ").capitalize(), "levelup")
		skills.train(skill_id, 0.6)
		if weapon_class in ["staff", "wand"]:
			skills.train("arcane_attunement", 0.2, true)
	PlayerData.wear("weapon", 0.5)

func _spawn_slash_fx(_hit: bool) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var segs: int = 14
	var r0: float = 0.7
	var r1: float = 1.75
	var a_start: float = -1.15
	var a_end: float = 1.15
	for i in range(segs):
		var a0: float = lerpf(a_start, a_end, float(i) / float(segs))
		var a1: float = lerpf(a_start, a_end, float(i + 1) / float(segs))
		var fade0: float = sin(PI * float(i) / float(segs))
		var fade1: float = sin(PI * float(i + 1) / float(segs))
		var in0 := Vector3(sin(a0) * r0, 0, -cos(a0) * r0)
		var in1 := Vector3(sin(a1) * r0, 0, -cos(a1) * r0)
		var out0 := Vector3(sin(a0) * r1, 0, -cos(a0) * r1)
		var out1 := Vector3(sin(a1) * r1, 0, -cos(a1) * r1)
		var c_in := Color(1.0, 0.95, 0.8, 0.0)
		var c0 := Color(1.0, 0.95, 0.8, 0.85 * fade0)
		var c1 := Color(1.0, 0.95, 0.8, 0.85 * fade1)
		MeshKit.tri_core(st, in0, out0, out1, Vector3.UP, Vector3.UP, Vector3.UP, c_in, c0, c1, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
		MeshKit.tri_core(st, in0, out1, in1, Vector3.UP, Vector3.UP, Vector3.UP, c_in, c1, c_in, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	st.set_material(mat)
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = Vector3(0, 1.1 * model.scale.y, 0)
	mi.rotation = Vector3(0.0, 0.0, _swing_side * 0.55)
	add_child(mi)
	var tw: Tween = create_tween()
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.18)
	tw.tween_callback(mi.queue_free)

func take_damage(amount: float, source: Node = null) -> void:
	if health.is_dead:
		return
	if guarding and guard_stamina > 0.0:
		var perfect_guard: bool = _guard_time <= 0.24
		var guard_cost: float = minf(guard_stamina, amount * (0.55 if perfect_guard else 0.42))
		guard_stamina = maxf(guard_stamina - guard_cost, 0.0)
		var blocked: float = amount if perfect_guard else amount * 0.58
		if perfect_guard:
			_riposte_ready = true
			skills.train("shield", 0.42)
			skills.discover_technique("riposte")
			EventBus.toast.emit("Perfect Guard — Riposte ready", "levelup")
			EventBus.activity.emit("Perfectly timed a guard and opened a counter window", "combat")
			VFX.impact_ring(self, global_position, Color(0.55, 0.85, 1.0), 1.25)
			_shake_strength = maxf(_shake_strength, 0.11)
		else:
			skills.train("shield", 0.08, true)
		if blocked >= amount - 0.01:
			return
		amount = maxf(amount - blocked, 1.0)
	if _invuln > 0.0:
		if _dodge_window > 0.0:
			_dodge_window = 0.0
			skills.train("evasion", 0.32)
			var perfect: DamageNumber = DAMAGE_NUMBER_SCENE.instantiate()
			get_tree().current_scene.add_child(perfect)
			perfect.global_position = global_position + Vector3(0, 2.0, 0)
			perfect.setup_text("Perfect Evade!", Color(0.55, 0.9, 1.0))
			EventBus.activity.emit("Perfectly evaded an incoming attack", "skill")
		return
	if skills.is_cultivation_technique_active("iron_skin_breath"):
		amount *= 0.94
	if is_stealthed:
		is_stealthed = false
		model.set_stealth_stance(false)
	var reduced: float = maxf(amount - PlayerData.armor_value() * 0.7, 1.0)
	_invuln = 0.35
	_since_damage = 0.0
	if _gather_node != null:
		cancel_gather("Interrupted!")
	health.take_damage(reduced, source)
	_shake_strength = maxf(_shake_strength, 0.20)
	skills.train("vitality", 0.10 + minf(reduced, 20.0) * 0.01, true)
	PlayerData.wear("armor", 0.8)
	_spawn_damage_number(reduced)
	model.flash(Color(1.0, 0.2, 0.15))
	EventBus.entity_damaged.emit(self, reduced, source)

func apply_knockback(impulse: Vector3) -> void:
	_kb = impulse

func _spawn_damage_number(amount: float) -> void:
	var dn: DamageNumber = DAMAGE_NUMBER_SCENE.instantiate()
	get_tree().current_scene.add_child(dn)
	dn.global_position = global_position + Vector3(0, 2.0, 0)
	dn.setup(amount, false, true)

func _on_died(source: Node) -> void:
	if GameManager.current_state == GameManager.GameState.DEAD:
		return
	if not bool(PlayerData.stats.get("death_pending", false)):
		PlayerData.stats["death_pending"] = true
		PlayerData.stats["death_count"] = int(PlayerData.stats.get("death_count", 0)) + 1
		if str(PlayerData.stats.get("death_cause", "")) != "old_age":
			PlayerData.stats["death_cause"] = "combat"
		if MMORPGNetwork.is_authority() and not WorldDeploymentGuard.production_mode:
			var lost_gold := mini(PlayerData.gold, int(ceil(PlayerData.gold * 0.05)))
			PlayerData.spend_gold(lost_gold)
			PlayerData.stats["last_death_gold"] = lost_gold
			for slot in PlayerData.equipment:
				var item: Dictionary = PlayerData.equipment[slot]
				if not item.is_empty():
					PlayerData.wear(str(slot), ItemDB.max_durability(item) * 0.10)
	print("[Player] Died")
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	if expedition and expedition.active and get_tree().get_first_node_in_group("dungeon_active"):
		expedition.record_death()
		expedition.finish_expedition(false)
	GameManager.set_dead()
	EventBus.player_died.emit(str(PlayerData.stats.get("death_cause", "combat")))
	velocity = Vector3.ZERO
	model.play_death()
	if not MMORPGNetwork.is_online():
		SaveSystem.call_deferred("save_game")

func respawn_at_sanctuary() -> void:
	if _respawning or not health.is_dead or str(PlayerData.stats.get("death_cause", "")) == "old_age":
		return
	if MMORPGNetwork.is_online():
		MMORPGNetwork.request_respawn()
		return
	_respawning = true
	var dungeon := get_tree().get_first_node_in_group("dungeon_active")
	if dungeon:
		await dungeon.exit_dungeon(false)
	var environment := get_tree().get_first_node_in_group("environment_world")
	if environment and bool(get_meta("inside_cave", false)):
		environment.restore_from_save({"inside_cave": -1})
	var spawn := Constants.SPAWN_XZ
	var terrain := TerrainNoise.new(GameManager.world_seed)
	complete_respawn(Vector3(spawn.x, terrain.get_height(spawn.x, spawn.y) + 0.4, spawn.y))
	SaveSystem.save_game()

func complete_respawn(destination: Vector3) -> void:
	_respawning = false
	global_position = destination
	velocity = Vector3.ZERO
	health.is_dead = false
	health.current_health = health.max_health * 0.5
	spiritual_energy = max_spiritual_energy * 0.5
	PlayerData.stats["death_pending"] = false
	PlayerData.stats["death_cause"] = ""
	GameManager.register_player(self)
	model.build(model.cfg.duplicate(true))
	refresh_age_visuals()
	health.health_changed.emit(health.current_health, health.max_health)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	EventBus.toast.emit("Recovered at Elyndor sanctuary. Skills, belongings and age retained.", "info")

func _set_bonus_mult() -> float:
	var w: Dictionary = PlayerData.equipment.get("weapon", {})
	var a: Dictionary = PlayerData.equipment.get("armor", {})
	if w.is_empty() or a.is_empty():
		return 1.0
	var sw: String = str(ItemDB.def(str(w.get("id", ""))).get("set", ""))
	var sa: String = str(ItemDB.def(str(a.get("id", ""))).get("set", ""))
	if sw != "" and sw == sa:
		return 1.12  # 12% set bonus
	return 1.0
