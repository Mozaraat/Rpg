extends Area3D

func can_interact() -> bool:
	return true

func get_prompt() -> String:
	var d = get_tree().get_first_node_in_group("dungeon")
	if d == null:
		return "Dungeon Gate"
	if not d.has_method("is_boss_defeated") or not d.is_boss_defeated():
		return "Gate sealed — defeat the floor boss"
	var f: int = int(d.get("current_floor"))
	var total: int = int(d.get("FLOORS")) if d.get("FLOORS") != null else 100
	if f >= total - 1:
		return "Exit Depths (final floor cleared)"
	return "Descend to Floor %d" % (f + 2)

func interact(_player: Node3D = null) -> void:
	var d = get_tree().get_first_node_in_group("dungeon")
	if d and d.has_method("try_advance_or_exit"):
		d.try_advance_or_exit()
