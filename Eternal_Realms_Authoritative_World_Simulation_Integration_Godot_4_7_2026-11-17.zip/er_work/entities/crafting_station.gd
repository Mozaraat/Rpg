# CraftingStation - an interactable spot (forge, alchemy table) that opens the StationPanel.
extends Node3D
class_name CraftingStation

@export var station_type: String = "forge"
@export var prompt: String = "Use Forge"
var interact_range: float = 3.6

func _ready() -> void:
	add_to_group("interactable")

func can_interact() -> bool:
	return true

func get_prompt() -> String:
	var clean_prompt: String = prompt.strip_edges()
	if not clean_prompt.is_empty():
		return clean_prompt
	match station_type:
		"forge": return "Use the Forge"
		"alchemy": return "Use the Alchemy Table"
		"campfire": return "Cook at the Campfire"
		_: return "Use %s Station" % station_type.replace("_", " ").capitalize()

func interact(_player: Node3D) -> void:
	if station_type == "campfire":
		var activity: Node = get_tree().get_first_node_in_group("interactive_professions")
		if activity and activity.has_method("begin_cooking"):
			activity.begin_cooking(_player)
			return
	var panel: Node = get_tree().get_first_node_in_group("station_panel")
	if panel and panel.has_method("open_station"):
		panel.open_station(station_type)
