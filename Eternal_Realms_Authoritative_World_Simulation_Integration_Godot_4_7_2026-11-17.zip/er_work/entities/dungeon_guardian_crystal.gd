extends Node3D
# The floor guardian's core crystal. It hangs over the arena and dims and sinks
# as the guardian's health falls, so a player can read the fight's progress
# without a health bar, and goes dark the moment the guardian dies.

@export var crystal_node: MeshInstance3D
@export var halo_node: MeshInstance3D
@export var glow_color: Color = Color(0.8, 0.55, 1.0)

var _clock: float = 0.0
var _boss: Node3D = null
var _check_timer: float = 0.0
var _fraction: float = 1.0
var _alive: bool = true

func _ready() -> void:
	if crystal_node == null:
		crystal_node = get_node_or_null("GuardianCrystal") as MeshInstance3D
	if halo_node == null:
		halo_node = get_node_or_null("GuardianHalo") as MeshInstance3D
	_find_boss()

func _process(delta: float) -> void:
	_clock += delta
	_check_timer -= delta
	if _check_timer <= 0.0:
		_check_timer = 0.35
		_find_boss()
	if _boss == null or not is_instance_valid(_boss):
		_alive = false
		_fraction = maxf(_fraction - delta * 0.7, 0.0)
	else:
		_alive = true
		var health := _boss.get_node_or_null("HealthComponent") as HealthComponent
		if health != null:
			_fraction = clampf(health.current_health / maxf(health.max_health, 1.0), 0.0, 1.0)
			_alive = not health.is_dead
	var target_scale: float = lerpf(0.30, 1.0, _fraction)
	if crystal_node != null:
		var breathe: float = 1.0 + (0.03 if _alive else 0.0) * sin(_clock * 2.2)
		crystal_node.scale = Vector3(1.0, target_scale * breathe, 1.0)
		var mat := crystal_node.material_override as StandardMaterial3D
		if mat != null:
			mat.emission_energy_multiplier = lerpf(0.25, 2.2, _fraction)
			mat.albedo_color = glow_color.darkened(0.2 + (1.0 - _fraction) * 0.45)
	if halo_node != null:
		halo_node.rotation.y = _clock * 0.5
		halo_node.rotation.z = _clock * 0.27
		var halo_mat := halo_node.material_override as StandardMaterial3D
		if halo_mat != null:
			halo_mat.emission_energy_multiplier = lerpf(0.15, 1.6, _fraction)

func _find_boss() -> void:
	for node in get_tree().get_nodes_in_group("enemy"):
		if node is Node3D and bool(node.get_meta("floor_boss", false)) and int(node.get_meta("dungeon_floor", -2)) == int(get_meta("dungeon_floor", -1)):
			_boss = node
			return
	_boss = null
