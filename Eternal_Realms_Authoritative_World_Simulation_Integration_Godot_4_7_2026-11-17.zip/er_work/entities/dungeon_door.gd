extends Node3D
# Chamber doors for a dungeon floor. They stand open until a party steps into a
# chamber that still holds hostiles: then the leaves grind shut behind the
# adventurers and stay sealed until every enemy in the chamber has fallen.
# The seal rune burns warning-red while shut and turns to the floor's own light
# once the way is clear.

@export var room_cells: Array[Vector2i] = []
@export var floor_index: int = 0
@export var maze_cell_size: float = 16.0
@export var maze_grid: int = 13
@export var leaf_axis: Vector3 = Vector3.RIGHT

var _leaves: Node3D
var _leaf_nodes: Array[MeshInstance3D] = []
var _leaf_home: Array[Vector3] = []
var _block: StaticBody3D
var _shape: CollisionShape3D
var _axis: Vector3 = Vector3.RIGHT
var _seals: Array[MeshInstance3D] = []
var _slide: float = 1.0
var _sealed: bool = false
var _check_timer: float = 0.0
var _clock: float = 0.0
var _room: Node3D = null

func _ready() -> void:
	_leaves = get_node_or_null("DoorLeaves") as Node3D
	_block = get_node_or_null("DoorBlock") as StaticBody3D
	if _block != null:
		_shape = _block.get_node_or_null("CollisionShape3D") as CollisionShape3D
	_axis = leaf_axis
	_room = get_parent() as Node3D
	if _leaves != null:
		for child in _leaves.get_children():
			if child is MeshInstance3D:
				if child.name == "DoorLeaf":
					_leaf_nodes.append(child)
					_leaf_home.append(child.position)
				elif child.name == "DoorSeal":
					_seals.append(child)
	_set_sealed(false)

func _process(delta: float) -> void:
	_clock += delta
	_check_timer -= delta
	if _check_timer <= 0.0:
		_check_timer = 0.3
		_evaluate()
	var target: float = 0.0 if _sealed else 1.0
	if not is_equal_approx(_slide, target):
		_slide = move_toward(_slide, target, delta * 0.9)
	_apply_slide()

func _evaluate() -> void:
	if _room == null or room_cells.is_empty():
		return
	var player := get_tree().get_first_node_in_group("player") as Node3D
	var player_inside: bool = false
	if player != null:
		player_inside = room_cells.has(_cell_of(player.global_position - _room.global_position))
	if player_inside and not _chamber_is_clear():
		_set_sealed(true)
	else:
		_set_sealed(false)

func _cell_of(local: Vector3) -> Vector2i:
	var half_grid: float = float(maze_grid - 1) * 0.5
	return Vector2i(int(round(local.x / maze_cell_size + half_grid)), int(round(local.z / maze_cell_size + half_grid)))

func _chamber_is_clear() -> bool:
	# Hostiles are judged by where they stand now, not where they spawned, so a
	# patrol that wanders out stops holding the chamber shut.
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(enemy) or not (enemy is Node3D):
			continue
		if int(enemy.get_meta("dungeon_floor", -1)) != floor_index:
			continue
		var local: Vector3 = (enemy as Node3D).global_position - _room.global_position
		var cell := _cell_of(local)
		if cell.x < 0 or cell.y < 0 or cell.x >= maze_grid or cell.y >= maze_grid:
			continue
		if room_cells.has(cell):
			return false
	return true

func _set_sealed(sealed: bool) -> void:
	if _sealed == sealed:
		return
	_sealed = sealed
	if _shape != null:
		_shape.set_deferred("disabled", not sealed)
	for seal in _seals:
		var mat := seal.material_override as StandardMaterial3D
		if mat != null:
			if sealed:
				mat.albedo_color = Color(1.0, 0.42, 0.22)
				mat.emission = Color(1.0, 0.36, 0.16)
				mat.emission_energy_multiplier = 2.8
			else:
				mat.albedo_color = Color(0.55, 0.95, 1.0)
				mat.emission = Color(0.45, 0.9, 1.0)
				mat.emission_energy_multiplier = 2.2

func _apply_slide() -> void:
	if _leaves == null:
		return
	var sway: float = sin(_clock * 1.6) * 0.012
	for i in range(_leaf_nodes.size()):
		var leaf := _leaf_nodes[i]
		var home: Vector3 = _leaf_home[i]
		var push: float = _slide * DungeonFloorDressing.DOOR_WIDTH * 0.48
		leaf.position = home + _axis * push * signf(home.dot(_axis)) + Vector3(0, sway * (1.0 - _slide) * 0.35, 0)
