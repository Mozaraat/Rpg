extends Area3D

@export var damage: float = 18.0
@export var trap_name: String = "Pressure plate"
@export var cooldown: float = 5.0
var _ready_to_trigger: bool = true
var _cooldown_left: float = 0.0

func _ready() -> void:
	monitoring = true
	monitorable = false
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	if not _ready_to_trigger:
		_cooldown_left -= delta
		if _cooldown_left <= 0.0:
			_ready_to_trigger = true

func _on_body_entered(body: Node3D) -> void:
	if not _ready_to_trigger or body != GameManager.player:
		return
	_ready_to_trigger = false
	_cooldown_left = cooldown
	if body.has_method("take_damage"):
		body.take_damage(damage, self)
	EventBus.toast.emit("Trap triggered: %s!" % trap_name, "warning")
	EventBus.activity.emit("The party triggered a dungeon trap", "combat")
	var light: OmniLight3D = get_node_or_null("TrapLight")
	if light:
		light.light_color = Color(1.0, 0.12, 0.05)
		light.light_energy = 3.0


func can_interact() -> bool:
	return _ready_to_trigger and monitoring

func get_prompt() -> String:
	return "Disarm %s" % trap_name if can_interact() else "Disarmed trap"

func interact(player: Node3D = null) -> void:
	if not can_interact():
		return
	_ready_to_trigger = false
	monitoring = false
	monitorable = false
	EventBus.toast.emit("You carefully disarm the %s." % trap_name, "levelup")
	EventBus.activity.emit("Disarmed a dungeon mechanism", "exploration")
	if player and player.get("skills") != null:
		player.skills.train("observation", 0.8)
		player.skills.train("dungeon_delving", 0.65)
	var lamp: OmniLight3D = get_node_or_null("TrapLight")
	if lamp:
		lamp.light_color = Color(0.2, 0.85, 0.42)
		lamp.light_energy = 0.55
	var plate: MeshInstance3D = get_node_or_null("Plate")
	if plate:
		plate.visible = false
