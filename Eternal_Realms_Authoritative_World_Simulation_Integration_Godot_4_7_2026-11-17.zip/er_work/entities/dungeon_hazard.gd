# Visible floor hazard with a clear warning cue and a short damage cooldown.
extends Area3D

var hazard_name: String = "Unstable floor"
var warning_text: String = "The ground shudders beneath you."
var damage: float = 7.0
var cooldown: float = 4.0
var hazard_color: Color = Color(1.0, 0.35, 0.12)
var _cooldown_left: float = 0.0
var _clock: float = 0.0
var interact_range: float = 0.0

func _ready() -> void:
	monitoring = true
	monitorable = false
	collision_layer = 0
	collision_mask = Constants.LAYER_PLAYER
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	_clock += delta
	_cooldown_left = maxf(_cooldown_left - delta, 0.0)
	var ring := get_node_or_null("WarningRing") as MeshInstance3D
	if ring:
		ring.rotation.y += delta * 0.55
	var lamp := get_node_or_null("WarningLight") as OmniLight3D
	if lamp:
		lamp.light_energy = 0.25 + absf(sin(_clock * 2.4)) * 0.65

func _on_body_entered(body: Node3D) -> void:
	if body != GameManager.player or _cooldown_left > 0.0:
		return
	_cooldown_left = cooldown
	if body.has_method("take_damage"):
		body.take_damage(damage, self)
	if body.get("skills") != null:
		body.skills.train("observation", 0.08, true)
	EventBus.toast.emit("Hazard: %s — %s" % [hazard_name, warning_text], "warning")
	EventBus.activity.emit("Navigated a %s hazard" % hazard_name.to_lower(), "exploration")
