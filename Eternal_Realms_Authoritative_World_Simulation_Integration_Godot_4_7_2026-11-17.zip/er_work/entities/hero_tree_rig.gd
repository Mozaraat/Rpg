# Monumental tree rig using the same high-detail species meshes as the streamed forests.
# Foliage inherits the vegetation wind shader; accessory branch pivots react to nearby giants.
extends Node3D
class_name HeroTreeRig

var species: String = "redwood"
var tree_scale: float = 1.0
var _clock: float = 0.0
var _branches: Array[Dictionary] = []
var _impact_shake: float = 0.0

func configure(p_species: String, p_scale: float) -> void:
	species = p_species
	tree_scale = p_scale

func _ready() -> void:
	add_to_group("hero_tree")
	add_to_group("wind_reactive")
	_build_tree()

func _build_tree() -> void:
	var base_lift := 0.0
	var trunk_height := 5.0
	var trunk_radius := 0.55
	var branch_height := 4.0
	match species:
		"redwood":
			base_lift = 3.0; trunk_height = 12.0; trunk_radius = 0.95; branch_height = 11.0
		"baobab":
			base_lift = 0.15; trunk_height = 4.5; trunk_radius = 1.25; branch_height = 4.8
		"pine":
			base_lift = 3.45; trunk_height = 6.5; trunk_radius = 0.36; branch_height = 5.8
		"willow":
			base_lift = 0.2; trunk_height = 3.8; trunk_radius = 0.38; branch_height = 3.4
		"jungle":
			base_lift = 0.2; trunk_height = 5.0; trunk_radius = 0.58; branch_height = 5.0
		"cherry":
			base_lift = 0.15; trunk_height = 3.0; trunk_radius = 0.30; branch_height = 3.6
		"deadwood":
			base_lift = 0.0; trunk_height = 3.6; trunk_radius = 0.35; branch_height = 3.0
		_:
			base_lift = 0.65; trunk_height = 3.3; trunk_radius = 0.42; branch_height = 4.2
	var tree_mesh := MeshInstance3D.new()
	tree_mesh.name = "DetailedSpeciesMesh"
	tree_mesh.mesh = VegetationKit.get_mesh(species)
	tree_mesh.position.y = base_lift
	tree_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(tree_mesh)
	var trunk_body := StaticBody3D.new()
	trunk_body.name = "HeroTreeTrunkCollision"
	trunk_body.collision_layer = Constants.LAYER_WORLD
	trunk_body.collision_mask = 0
	var trunk_collision := CollisionShape3D.new()
	var trunk_shape := CylinderShape3D.new()
	trunk_shape.radius = trunk_radius
	trunk_shape.height = trunk_height
	trunk_collision.shape = trunk_shape
	trunk_collision.position.y = base_lift + trunk_height * 0.5
	trunk_body.add_child(trunk_collision)
	add_child(trunk_body)
	# Six smaller branch arms provide articulated reactions without replacing the species canopy.
	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.25, 0.16, 0.105)
	bark.roughness = 0.97
	for i in range(6):
		var angle := TAU * float(i) / 6.0
		var pivot := Node3D.new()
		pivot.position = Vector3(cos(angle) * trunk_radius * 0.35, base_lift + branch_height, sin(angle) * trunk_radius * 0.35)
		pivot.rotation.y = angle
		add_child(pivot)
		var branch := MeshInstance3D.new()
		var branch_mesh := CylinderMesh.new()
		branch_mesh.top_radius = maxf(0.06, trunk_radius * 0.11)
		branch_mesh.bottom_radius = maxf(0.12, trunk_radius * 0.22)
		branch_mesh.height = maxf(1.2, trunk_radius * 2.6)
		branch.mesh = branch_mesh
		branch.material_override = bark
		branch.position = Vector3(0.0, 0.0, trunk_radius * 1.25)
		branch.rotation.x = PI * 0.5
		pivot.add_child(branch)
		var foliage := MeshInstance3D.new()
		foliage.mesh = VegetationKit.get_mesh("bush")
		foliage.position = Vector3(0.0, 0.0, trunk_radius * 2.25)
		foliage.scale = Vector3.ONE * maxf(0.8, trunk_radius * 0.8)
		pivot.add_child(foliage)
		_branches.append({"node": pivot, "phase": float(i) * 1.047, "base": pivot.rotation})
	scale = Vector3.ONE * tree_scale

func shake_from_beast(_beast_position: Vector3) -> void:
	_impact_shake = 1.0

func _process(delta: float) -> void:
	_clock += delta
	var wind := sin(_clock * 0.72 + global_position.x * 0.013) * 0.035
	var beast_shake := 0.0
	for beast in get_tree().get_nodes_in_group("colossal_beast"):
		if is_instance_valid(beast) and global_position.distance_to(beast.global_position) < 22.0:
			beast_shake = maxf(beast_shake, (22.0 - global_position.distance_to(beast.global_position)) / 22.0 * 0.18)
	_impact_shake = move_toward(_impact_shake, 0.0, delta * 0.65)
	var target := wind + sin(_clock * 4.0) * beast_shake + sin(_clock * 17.0) * _impact_shake * 0.12
	for item in _branches:
		var pivot: Node3D = item["node"]
		var base: Vector3 = item["base"]
		var phase: float = item["phase"]
		pivot.rotation.z = lerpf(pivot.rotation.z, base.z + target * sin(_clock * 1.1 + phase), delta * 2.2)
		pivot.rotation.x = lerpf(pivot.rotation.x, base.x + target * 0.65 * cos(_clock + phase), delta * 2.0)
