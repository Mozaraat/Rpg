extends Area3D

var used: bool = false

const BAND_TECHNIQUES: Array[String] = [
	"eclipse_counter", "starfall_burst", "dragon_piercer", "void_step",
	"eclipse_counter", "dragon_piercer", "starfall_burst", "void_step",
	"eclipse_counter", "starfall_burst"
]
const BAND_ELEMENTS: Array[String] = ["fire", "water", "lightning", "earth", "ice", "wind", "fire", "water", "lightning", "earth"]

func can_interact() -> bool:
	return not used

func get_prompt() -> String:
	return "Attune to ancient skill shrine" if not used else "Dormant shrine"

func interact(player: Node3D = null) -> void:
	if used:
		return
	used = true
	var floor_i: int = int(get_meta("floor", 0))
	var band: int = clampi(int(floor_i / 10), 0, BAND_TECHNIQUES.size() - 1)
	var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.mark_discovery(floor_i, "shrine")
	var surge_bonus: float = 1.8 if dungeon and dungeon.has_method("is_arcane_surge_active") and dungeon.is_arcane_surge_active() else 1.0
	if player and player.get("skills") != null:
		var skills: SkillSystem = player.skills
		skills.train("arcane_attunement", 1.25 * surge_bonus)
		skills.train("cultivation", 0.65 * surge_bonus)
		skills.train("spiritual_sense", 0.35 * surge_bonus)
		skills.train("dungeon_delving", 0.45 * surge_bonus)
		skills.train("exploration", 0.35 * surge_bonus)
		skills.train("knowledge", 0.25 * surge_bonus)
		skills.train("ancient_lore", 0.2 * surge_bonus)
		var element_skill: String = str(SkillSystem.ELEMENT_SKILLS.get(BAND_ELEMENTS[band], ""))
		if element_skill != "":
			skills.train(element_skill, 0.22 * surge_bonus, true)
		var rare_form: String = BAND_TECHNIQUES[band]
		if skills.has_method("seal_rare_technique"):
			skills.seal_rare_technique(rare_form, "Floor %d %s shrine inscription" % [floor_i + 1, BAND_ELEMENTS[band]])
		if skills.get_value("elemental_magic") >= 3.0:
			skills.discover_technique("arcane_burst", "ancient shrine inscription")
		if player.get("health") != null:
			player.health.heal(12.0)
	EventBus.toast.emit("You attune to the shrine. Spiritual energy settles into your pathways.", "levelup")
	EventBus.activity.emit("Attuned to an ancient dungeon shrine", "skill")
	for child in get_children():
		if child is OmniLight3D:
			child.light_energy = 0.12
