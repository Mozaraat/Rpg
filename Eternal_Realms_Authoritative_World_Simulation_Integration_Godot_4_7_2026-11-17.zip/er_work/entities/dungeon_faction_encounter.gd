extends Area3D
## Lightweight, save-safe faction encounter used by the ten lost civilizations.

var encounter_type: String = "prisoner"
var faction_name: String = "Forgotten Faction"
var floor_number: int = 1
var resolved: bool = false
var _material: StandardMaterial3D
var merchant_stock: Array[Dictionary] = []
var room_owner: String = ""
var faction_id: String = ""
var _network_interaction_approved: bool = false

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("dungeon_discovery")
	set_meta("interact_range", 3.8)
	monitoring = true
	collision_layer = Constants.LAYER_WORLD
	collision_mask = 0
	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 2.2
	shape.shape = sphere
	add_child(shape)
	_material = StandardMaterial3D.new()
	_material.metallic = 0.45
	_material.roughness = 0.32
	_material.emission_enabled = true
	_material.emission_energy_multiplier = 0.65
	var pillar := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.34
	mesh.bottom_radius = 0.58
	mesh.height = 1.55
	pillar.mesh = mesh
	pillar.position.y = 0.78
	pillar.material_override = _material
	add_child(pillar)
	var sigil := MeshInstance3D.new()
	var orb := SphereMesh.new()
	orb.radius = 0.28
	orb.height = 0.56
	sigil.mesh = orb
	sigil.position.y = 1.8
	sigil.material_override = _material
	add_child(sigil)
	var colors := {
		"prisoner": Color(0.25, 0.9, 0.55), "merchant": Color(0.95, 0.72, 0.25),
		"leader": Color(0.78, 0.35, 1.0), "control": Color(0.3, 0.72, 1.0),
		"skirmish": Color(1.0, 0.32, 0.22)
	}
	_material.albedo_color = colors.get(encounter_type, Color(0.6, 0.7, 0.8))
	room_owner = faction_name
	if faction_id == "":
		faction_id = str(CivilizationSocieties.culture_for_floor(floor_number).get("id", "labyrinth"))
	merchant_stock = [{"id":"healing_potion", "count":2, "price":18 + floor_number}, {"id":"mana_crystal", "count":1, "price":28 + floor_number * 2}, {"id":"rune_fragment", "count":1, "price":42 + floor_number * 2}]
	_material.emission = _material.albedo_color
	var campaign: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
	if campaign:
		var persistent_owner: String = str(campaign.room_owner(floor_number))
		if persistent_owner != faction_id:
			room_owner = persistent_owner
			_material.albedo_color = Color(0.25, 0.9, 0.65) if persistent_owner == "PLAYER_EXPEDITION" else Color(0.95, 0.48, 0.28)
			_material.emission = _material.albedo_color
	set_meta("room_owner", room_owner)
	name = "Faction_%s_Floor_%d" % [encounter_type.capitalize(), floor_number]

func on_server_interaction_validated(action: String, _detail_id: String = "") -> void:
	if action != "faction_merchant" or resolved or encounter_type != "merchant":
		return
	_network_interaction_approved = true
	interact(GameManager.player)

func _can_fit_stock_item(item_id: String, amount: int) -> bool:
	if not ItemDB.has_item(item_id) or amount <= 0:
		return false
	var stack_limit: int = maxi(1, ItemDB.max_stack(item_id))
	var capacity: int = 0
	for slot_value in PlayerData.slots:
		if not slot_value is Dictionary:
			continue
		var slot: Dictionary = slot_value
		if slot.is_empty():
			capacity += stack_limit
		elif str(slot.get("id", "")) == item_id and int(slot.get("grade", 0)) == 0:
			capacity += maxi(0, stack_limit - int(slot.get("count", 0)))
	return capacity >= amount

func can_interact() -> bool:
	return not resolved

func get_prompt() -> String:
	match encounter_type:
		"prisoner": return "Rescue %s captive" % faction_name
		"merchant": return "Trade with %s quartermaster" % faction_name
		"leader": return "Confront hidden %s leader" % faction_name
		"control": return "Claim %s district shrine" % faction_name
		"skirmish": return "Intervene in rival faction clash"
	return "Investigate faction remnant"

func interact(player: Node3D = null) -> void:
	if resolved:
		return
	if encounter_type == "merchant" and MMORPGNetwork.is_online() and not multiplayer.is_server() and not _network_interaction_approved:
		MMORPGNetwork.request_validated_interaction(self, "faction_merchant")
		return
	_network_interaction_approved = false
	if encounter_type != "merchant":
		resolved = true
	var band: int = clampi(int((floor_number - 1) / 10), 0, 9)
	var reward_gold: int = 18 + floor_number * 3
	var item_pool: Array[String] = ["rune_fragment", "forgotten_essence", "mana_crystal", "moonstone_ore", "heart_of_depths"]
	var item_id: String = item_pool[mini(band, item_pool.size() - 1)]
	match encounter_type:
		"prisoner":
			EventBus.toast.emit("You free a %s captive. They join your expedition as an allied fighter." % faction_name, "levelup")
			PlayerData.add_item(item_id, 1, mini(5, int(band / 2)))
			PlayerData.add_gold(reward_gold)
			var ally_scene: PackedScene = load("res://scenes/monster.tscn")
			if ally_scene and get_parent():
				var ally := ally_scene.instantiate() as Monster
				if ally:
					ally.monster_id = "bronze_sentinel"
					ally.display_name = faction_name + " Prisoner"
					ally.max_hp = 95.0 + float(floor_number) * 2.0
					ally.damage = 9.0 + float(floor_number) * 0.55
					ally.body_color = Color(0.35, 0.82, 0.62)
					ally.set_meta("dungeon_floor", floor_number - 1)
					get_parent().add_child(ally)
					ally.global_position = global_position + Vector3(2.2, 0.35, 1.8)
					ally.home = ally.global_position
					ally.recruit_as_dungeon_ally(floor_number - 1)
			if player and player.get("skills") != null:
				player.skills.train("compassion", 0.4)
		"merchant":
			var bought: int = 0
			var remaining_stock: Array[Dictionary] = []
			for stock_value in merchant_stock:
				if not stock_value is Dictionary:
					continue
				var stock_entry: Dictionary = stock_value.duplicate(true)
				var stock_id: String = str(stock_entry.get("id", ""))
				var stock_count: int = clampi(int(stock_entry.get("count", 0)), 0, 20)
				var price: int = clampi(int(stock_entry.get("price", 0)), 1, 1000000)
				if stock_count <= 0 or not ItemDB.has_item(stock_id):
					continue
				if not _can_fit_stock_item(stock_id, stock_count) or not PlayerData.spend_gold(price):
					remaining_stock.append(stock_entry)
					continue
				var remaining: int = PlayerData.add_item(stock_id, stock_count)
				if remaining > 0:
					var added: int = stock_count - remaining
					if added > 0:
						PlayerData.remove_item(stock_id, added)
					PlayerData.add_gold(price)
					remaining_stock.append(stock_entry)
					continue
				bought += 1
			merchant_stock = remaining_stock
			resolved = merchant_stock.is_empty()
			if bought <= 0:
				EventBus.toast.emit("No trade completed. Check your gold and inventory space, then try again.", "warning")
				return
			if not resolved:
				EventBus.toast.emit("Quartermaster sold %d goods. Remaining stock is still available." % bought, "loot")
				return
			EventBus.toast.emit("Quartermaster trade complete: all available goods purchased.", "loot")
		"leader":
			EventBus.toast.emit("The hidden %s leader yields an ancient treaty and a rare relic." % faction_name, "discovery")
			PlayerData.add_item(item_id, 2, mini(5, int(band / 2) + 1))
			PlayerData.add_gold(reward_gold * 2)
			if player and player.get("skills") != null:
				player.skills.train("ancient_lore", 1.2)
		"control":
			room_owner = "PLAYER_EXPEDITION"
			set_meta("room_owner", room_owner)
			var dungeon_owner: Node = get_tree().get_first_node_in_group("dungeon")
			if dungeon_owner:
				dungeon_owner.set_meta("floor_%d_room_owner" % (floor_number - 1), room_owner)
			EventBus.toast.emit("District shrine claimed. %s loses control; this chamber now bears your expedition's claim." % faction_name, "levelup")
			PlayerData.add_gold(reward_gold * 2)
			PlayerData.add_item(item_id, 1, mini(5, int(band / 2)))
		"skirmish":
			EventBus.toast.emit("You turn the tide of a %s border clash; the survivors scatter and leave their war chest." % faction_name, "combat")
			PlayerData.add_gold(reward_gold * 2)
			PlayerData.add_item(item_id, 1, mini(5, int(band / 2)))
	var campaign: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
	if campaign:
		match encounter_type:
			"prisoner": campaign.player_action(faction_id, "aid", 6)
			"control":
				campaign.claim_floor(floor_number, "PLAYER_EXPEDITION", faction_id)
				campaign.player_action(faction_id, "attack", -4)
			"leader":
				campaign.player_action(faction_id, "aid", 2)
			"skirmish": campaign.player_action(faction_id, "aid", 3)
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.mark_discovery(floor_number - 1, "faction_" + encounter_type)
	if player and player.get("skills") != null:
		player.skills.train("dungeon_delving", 0.7)
		player.skills.train("observation", 0.35)
	for child in get_children():
		if child is MeshInstance3D:
			(child as MeshInstance3D).visible = false
	monitoring = false
