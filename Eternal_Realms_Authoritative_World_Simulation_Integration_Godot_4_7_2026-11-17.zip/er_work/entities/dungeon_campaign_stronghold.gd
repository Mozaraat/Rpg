extends Node3D
## Procedural occupied faction fortress with commander, retinue, siege gate and banner.
var faction_name := "Forgotten Faction"
var faction_id := "labyrinth"
var floor_number := 1
var faction_color := Color(0.55, 0.65, 0.82)
var _banner: MeshInstance3D
var _crest_label: Label3D
var _commander_label: Label3D
var _stone_parts: Array[MeshInstance3D] = []
var _trim_parts: Array[MeshInstance3D] = []
var _guard_armors: Array[MeshInstance3D] = []
var _fortress_light: OmniLight3D

func _ready() -> void:
	add_to_group("dungeon_discovery")
	var campaign: Node = get_node_or_null("/root/DungeonCampaign")
	var owner_id := faction_id
	if campaign and campaign.has_method("room_owner"):
		owner_id = str(campaign.room_owner(floor_number))
	if owner_id == "PLAYER_EXPEDITION":
		faction_name = "Expedition Command"
		faction_color = Color(0.22, 0.78, 0.58)
	elif owner_id != faction_id and owner_id != "":
		faction_name = "Occupied by " + owner_id.replace("_", " ").capitalize()
		faction_color = faction_color.lightened(0.12)
	var stone := faction_color.darkened(0.48)
	var trim := faction_color.lightened(0.18)
	_box(Vector3(10.5, 0.55, 7.5), Vector3(0, 0.28, 0), stone)
	_box(Vector3(2, 4, 2), Vector3(-4.1, 2.25, -2.2), stone)
	_box(Vector3(2, 4, 2), Vector3(4.1, 2.25, -2.2), stone)
	_box(Vector3(6.2, 0.65, 1), Vector3(0, 3.55, -2.2), trim)
	_box(Vector3(2.4, 2.8, 0.65), Vector3(0, 1.55, -2), Color(0.08, 0.07, 0.09))
	for side in [-1.0, 1.0]:
		_box(Vector3(2.7, 1.05, 0.48), Vector3(side * 3.2, 0.85, 3.4), Color(0.32, 0.2, 0.12))
		for spike in range(4):
			_box(Vector3(0.12, 1.35, 0.12), Vector3(side * 3.2 + (float(spike) - 1.5) * 0.55, 1.7, 3.4), Color(0.22, 0.23, 0.25))
	_box(Vector3(0.16, 3.4, 0.16), Vector3(0, 4.9, -2.8), Color(0.55, 0.43, 0.25))
	_banner = MeshInstance3D.new()
	var banner_mesh := BoxMesh.new()
	banner_mesh.size = Vector3(1.8, 1.15, 0.12)
	_banner.mesh = banner_mesh
	_banner.position = Vector3(0.88, 5.55, -2.8)
	var banner_mat := StandardMaterial3D.new()
	banner_mat.albedo_color = faction_color
	banner_mat.emission_enabled = true
	banner_mat.emission = faction_color.darkened(0.35)
	_banner.material_override = banner_mat
	add_child(_banner)
	var crest := Label3D.new()
	_crest_label = crest
	crest.text = faction_name.to_upper() + "\nHOLD"
	crest.font_size = 22
	crest.position = Vector3(0, 6.15, -2.6)
	crest.modulate = trim
	crest.outline_size = 5
	add_child(crest)
	_guard(Vector3(0, 0.6, -0.2), 1.28, trim, true)
	for p in [Vector3(-1.8, 0.6, 0.9), Vector3(1.8, 0.6, 0.9), Vector3(-1.5, 0.6, -1.8), Vector3(1.5, 0.6, -1.8)]:
		_guard(p, 0.92, faction_color.darkened(0.12))
	var light := OmniLight3D.new()
	_fortress_light = light
	light.light_color = faction_color
	light.light_energy = 1.15
	light.omni_range = 9
	light.position = Vector3(0, 4.5, 0)
	add_child(light)
	var title := Label3D.new()
	_commander_label = title
	title.text = "COMMANDER · " + faction_name
	title.font_size = 18
	title.position = Vector3(0, 2.7, 1.2)
	title.modulate = Color(1, 0.86, 0.56)
	add_child(title)
	var diplomat := Area3D.new()
	diplomat.set_script(load("res://entities/dungeon_campaign_diplomat.gd"))
	diplomat.set("faction_id", faction_id)
	diplomat.set("faction_name", faction_name)
	diplomat.set("floor_number", floor_number)
	diplomat.position = Vector3(0, 0.15, 4.4)
	add_child(diplomat)
	var siege_script: Script = load("res://entities/dungeon_siege_director.gd")
	if siege_script:
		var siege := Node3D.new()
		siege.name = "DungeonSiegeDirector"
		siege.set_script(siege_script)
		siege.set("faction_id", faction_id)
		siege.set("faction_name", faction_name)
		siege.set("floor_number", floor_number)
		siege.set("faction_color", faction_color)
		add_child(siege)

func _box(size: Vector3, pos: Vector3, color: Color) -> void:
	var n := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	n.mesh = mesh
	n.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = 0.18
	mat.roughness = 0.72
	n.material_override = mat
	if color.is_equal_approx(faction_color.darkened(0.48)):
		_stone_parts.append(n)
	elif color.is_equal_approx(faction_color.lightened(0.18)):
		_trim_parts.append(n)
	add_child(n)

func _guard(pos: Vector3, scale: float, color: Color, commander: bool = false) -> void:
	var body := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.34 * scale
	capsule.height = 1.55 * scale
	body.mesh = capsule
	body.position = pos + Vector3(0, 0.78 * scale, 0)
	var armor := StandardMaterial3D.new()
	armor.albedo_color = color
	armor.metallic = 0.55
	body.material_override = armor
	_guard_armors.append(body)
	add_child(body)
	var head := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.23 * scale
	sphere.height = 0.46 * scale
	head.mesh = sphere
	head.position = pos + Vector3(0, 1.67 * scale, 0)
	add_child(head)
	if commander:
		var crown := MeshInstance3D.new()
		var ring := TorusMesh.new()
		ring.inner_radius = 0.2 * scale
		ring.outer_radius = 0.29 * scale
		crown.mesh = ring
		crown.position = pos + Vector3(0, 2 * scale, 0)
		add_child(crown)

func apply_capture(new_owner: String) -> void:
	if new_owner == "PLAYER_EXPEDITION":
		faction_name = "Expedition Command"
		faction_color = Color(0.22, 0.78, 0.58)
	else:
		faction_name = "Occupied by " + new_owner.replace("_", " ").capitalize()
		faction_color = faction_color.lightened(0.16)
	if _banner and _banner.material_override is StandardMaterial3D:
		(_banner.material_override as StandardMaterial3D).albedo_color = faction_color
		(_banner.material_override as StandardMaterial3D).emission = faction_color
	if _crest_label:
		_crest_label.text = faction_name.to_upper() + "\nHOLD"
		_crest_label.modulate = faction_color.lightened(0.2)
	if _commander_label:
		_commander_label.text = "COMMANDER · " + faction_name
	if _fortress_light:
		_fortress_light.light_color = faction_color
	for part in _stone_parts:
		if part.material_override is StandardMaterial3D:
			(part.material_override as StandardMaterial3D).albedo_color = faction_color.darkened(0.48)
	for part in _trim_parts:
		if part.material_override is StandardMaterial3D:
			(part.material_override as StandardMaterial3D).albedo_color = faction_color.lightened(0.18)
	for armor in _guard_armors:
		if armor.material_override is StandardMaterial3D:
			(armor.material_override as StandardMaterial3D).albedo_color = faction_color.lightened(0.08)
	for child in get_children():
		if child is Node3D and child.name == "DungeonSiegeDirector":
			child.set("faction_name", faction_name)
