extends Area3D

var used_this_visit: bool = false

func can_interact() -> bool:
	return true

func get_prompt() -> String:
	var floor_number: int = int(get_meta("floor_number", 1))
	return "Sanctuary — secure Floor %d, rest and repair" % floor_number

func interact(_player: Node3D = null) -> void:
	var expedition: Node = get_node_or_null("/root/DungeonExpedition")
	var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("secure_expedition_checkpoint"):
		dungeon.secure_expedition_checkpoint(int(get_meta("floor_number", 1)))
	var player: Node = GameManager.player
	if player:
		var health_component: HealthComponent = player.get_node_or_null("HealthComponent")
		if health_component:
			health_component.heal(health_component.max_health)
	if PlayerData.get("equipment") != null:
		var repair: Node = get_tree().get_first_node_in_group("gear_upgrade")
		if repair:
			repair.repair_slot("weapon")
			repair.repair_slot("armor")
	if expedition:
		expedition.restore_supplies(2)
	if has_node("/root/SaveSystem"):
		SaveSystem.save_game()
	used_this_visit = true
	EventBus.toast.emit("Sanctuary secured. Health restored; gear repair attempted.", "levelup")
	EventBus.activity.emit("Party rested at a dungeon sanctuary", "world")
	if has_node("SanctuaryLight"):
		$SanctuaryLight.light_energy = 2.4
