# Animated swimming fish with a readable silhouette and fishing loot table.
class_name MarineFish
extends Node3D

@export var fish_id: String = "fish_trout"
@export var is_ocean: bool = false

var _speed: float = 2.2
var _dir: Vector3 = Vector3.FORWARD
var _timer: float = 0.0
var _noise: TerrainNoise
var home: Vector3
var _clock: float = 0.0
var _visual: Node3D
var _tail: Node3D
var _left_fin: MeshInstance3D
var _right_fin: MeshInstance3D
var _age_seconds := 0.0
var _breeding_clock := 0.0
var _migration_clock := 0.0
var _mature := false

func _ready() -> void:
	add_to_group("marine_life")
	add_to_group("fish")
	home = global_position
	_noise = TerrainNoise.new(GameManager.world_seed)
	_speed = randf_range(1.6, 3.2)
	_dir = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
	_build()
	_timer = randf() * 3.0

func _build() -> void:
	_visual = Node3D.new()
	_visual.name = "FishVisual"
	add_child(_visual)
	var color := Color(0.48, 0.65, 0.5)
	var fish_scale := Vector3(0.92, 0.56, 1.55)
	match fish_id:
		"fish_minnow":
			color = Color(0.75, 0.82, 0.88)
			fish_scale = Vector3(0.55, 0.38, 0.9)
		"fish_mackerel", "fish_swordfish":
			color = Color(0.28, 0.46, 0.66)
			fish_scale = Vector3(0.9, 0.5, 1.9 if fish_id == "fish_swordfish" else 1.6)
		"fish_glowfin", "fish_angler":
			color = Color(0.22, 0.88, 0.98) if fish_id == "fish_glowfin" else Color(0.42, 0.34, 0.72)
			fish_scale = Vector3(0.82, 0.58, 1.45)
		"fish_koi":
			color = Color(0.92, 0.56, 0.28)
			fish_scale = Vector3(0.94, 0.62, 1.65)
		"fish_sunfish":
			color = Color(0.86, 0.65, 0.22)
			fish_scale = Vector3(1.0, 0.86, 1.05)
		"fish_parrotfish":
			color = Color(0.22, 0.72, 0.48)
			fish_scale = Vector3(0.88, 0.68, 1.35)
		"fish_puffer":
			color = Color(0.82, 0.72, 0.36)
			fish_scale = Vector3(1.05, 0.92, 1.0)
	var body_mat := _make_mat(color, fish_id in ["fish_glowfin", "fish_angler"])
	var belly_mat := _make_mat(color.lightened(0.42), false)
	var body := _make_ellipsoid(Vector3.ZERO, fish_scale, body_mat)
	body.name = "FishBody"
	_make_ellipsoid(Vector3(0.0, -fish_scale.y * 0.38, 0.02), Vector3(fish_scale.x * 0.82, fish_scale.y * 0.28, fish_scale.z * 0.74), belly_mat)
	# Caudal tail pivots at the back of the fish and swishes during movement.
	_tail = Node3D.new()
	_tail.name = "TailPivot"
	_tail.position.z = fish_scale.z * 0.88
	_visual.add_child(_tail)
	_make_ellipsoid_parent(_tail, Vector3(0.0, 0.0, 0.22), Vector3(0.12, 0.56, 0.5), body_mat)
	var dorsal := _make_ellipsoid(Vector3(0.0, fish_scale.y * 0.83, 0.1), Vector3(0.12, 0.24, 0.48), body_mat)
	dorsal.rotation.x = -0.12
	_left_fin = _make_ellipsoid(Vector3(-fish_scale.x * 0.78, -0.02, -0.05), Vector3(0.42, 0.08, 0.48), body_mat)
	_right_fin = _make_ellipsoid(Vector3(fish_scale.x * 0.78, -0.02, -0.05), Vector3(0.42, 0.08, 0.48), body_mat)
	_left_fin.rotation.y = -0.35
	_right_fin.rotation.y = 0.35
	if fish_id == "fish_puffer":
		for i in range(8):
			var a := TAU * float(i) / 8.0
			var spine := _make_ellipsoid(Vector3(cos(a) * 0.78, sin(a) * 0.58, 0.0), Vector3(0.055, 0.055, 0.22), belly_mat)
			spine.rotation.z = -a
	if fish_id == "fish_swordfish":
		_make_ellipsoid(Vector3(0.0, 0.12, -fish_scale.z * 1.02), Vector3(0.09, 0.09, 0.82), belly_mat)
	if fish_id == "fish_angler":
		var lure := _make_ellipsoid(Vector3(0.0, fish_scale.y + 0.32, -0.1), Vector3(0.04, 0.04, 0.04), belly_mat)
		lure.name = "LuminousLure"

func _make_ellipsoid(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	return _make_ellipsoid_parent(_visual, pos, scale_value, material)

func _make_ellipsoid_parent(parent: Node3D, pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := SphereMesh.new(); mesh.radial_segments = 16; mesh.rings = 10
	instance.mesh = mesh; instance.material_override = material; instance.position = pos; instance.scale = scale_value
	parent.add_child(instance)
	return instance

func _make_mat(color: Color, emissive: bool) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color; mat.roughness = 0.32; mat.metallic = 0.12
	if emissive:
		mat.emission_enabled = true; mat.emission = color; mat.emission_energy_multiplier = 1.35
	return mat

func _process(delta: float) -> void:
	_timer += delta
	_clock += delta
	_age_seconds += delta
	_breeding_clock += delta
	_migration_clock += delta
	_mature = _age_seconds >= 75.0
	# Seasonal/current-driven migration gradually shifts the home range rather than teleporting fish.
	if _migration_clock >= 48.0:
		_migration_clock = 0.0
		var current := TideSystem.get_current_vector(global_position)
		if current.length() > 0.05:
			home += Vector3(current.x, 0.0, current.z).normalized() * randf_range(3.0, 8.0)
	if _mature and _breeding_clock >= 95.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		_breeding_clock = 0.0
		_try_breed()
	if _timer > randf_range(2.0, 5.0):
		_timer = 0.0
		_dir = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
	var next: Vector3 = global_position + _dir * _speed * delta
	next += TideSystem.get_current_vector(global_position) * (0.16 * delta)
	if _noise:
		var h: float = _noise.get_height(next.x, next.z)
		var water_level: float = TideSystem.level_at_bed(h)
		if h > water_level - 0.15:
			_dir = (home - global_position)
			_dir.y = 0.0
			if _dir.length() > 0.01:
				_dir = _dir.normalized()
			next = global_position + _dir * _speed * delta
			h = _noise.get_height(next.x, next.z)
			water_level = TideSystem.level_at_bed(h)
		# Swim in the water column between bed and surface, never inside the ground.
		next.y = clampf(water_level - 0.35, h + 0.2, water_level - 0.12)
	else:
		next.y = TideSystem.current_level - 0.4
	if global_position.distance_to(home) > 18.0:
		_dir = (home - global_position)
		_dir.y = 0.0
		if _dir.length() > 0.01:
			_dir = _dir.normalized()
	global_position = next
	if _dir.length() > 0.1:
		look_at(global_position + _dir, Vector3.UP)
	if _tail:
		_tail.rotation.y = sin(_clock * 6.2) * 0.42
	if _left_fin:
		_left_fin.rotation.z = sin(_clock * 5.4) * 0.16
	if _right_fin:
		_right_fin.rotation.z = -sin(_clock * 5.4) * 0.16
	if _visual:
		_visual.position.y = sin(_clock * 2.3) * 0.035


func _try_breed() -> void:
	var population := get_tree().get_nodes_in_group("elyndor_spawned_marine_life")
	if population.size() >= 5 or get_tree().current_scene == null:
		return
	var compatible := 0
	for other in population:
		if other != self and is_instance_valid(other) and other is MarineFish and (other as MarineFish).fish_id == fish_id and global_position.distance_to((other as MarineFish).global_position) < 12.0:
			compatible += 1
	if compatible <= 0 or randf() > 0.18:
		return
	var offspring := MarineFish.new()
	offspring.fish_id = fish_id
	offspring.is_ocean = is_ocean
	offspring.position = global_position + Vector3(randf_range(-2.0, 2.0), randf_range(-0.5, 0.5), randf_range(-2.0, 2.0))
	offspring.add_to_group("elyndor_spawned_wildlife")
	offspring.add_to_group("elyndor_spawned_marine_life")
	get_tree().current_scene.add_child(offspring)

func try_catch(luck: float = 0.0) -> String:
	var roll: float = randf() - luck
	if is_ocean:
		if roll < 0.045: return "fish_angler"
		if roll < 0.10: return "fish_glowfin"
		if roll < 0.22: return "fish_swordfish"
		if roll < 0.43: return "fish_mackerel"
		if roll < 0.58: return "fish_parrotfish"
		if roll < 0.70: return "fish_sunfish"
		if roll < 0.80: return "fish_puffer"
		if roll < 0.88: return "pearl" if randf() < 0.2 else "coral_fragment"
		if roll < 0.96: return "seaweed"
		return "scale_shard"
	if roll < 0.08: return "fish_koi"
	if roll < 0.2: return "fish_bass"
	if roll < 0.52: return "fish_trout"
	if roll < 0.68: return "fish_minnow"
	if roll < 0.82: return "seaweed"
	return "scale_shard"
