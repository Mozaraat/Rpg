extends Area3D

var _cd: float = 0.0

func _process(delta: float) -> void:
	_cd = maxf(_cd - delta, 0.0)

func can_interact() -> bool:
	return _cd <= 0.0

func get_prompt() -> String:
	return "Pray at %s" % str(get_meta("poi_name", "Shrine"))

func interact(player: Node3D = null) -> void:
	_cd = 120.0
	if player and player.get("health"):
		player.health.heal(25.0)
	PlayerData.add_gold(5)
	if player and player.get("skills"):
		player.skills.train("exploration", 0.4)
	EventBus.toast.emit("The shrine grants a quiet blessing.", "levelup")
	EventBus.activity.emit("Prayed at %s" % str(get_meta("poi_name", "Shrine")), "world")
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg:
		sg.add_progress("elyndor", 1.5)
