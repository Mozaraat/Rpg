# Critter - small ambient animals (chickens in the village, rabbits in the meadows).
# They wander, peck / nibble, and flee when the player gets close.
extends CharacterBody3D
class_name Critter

@export var kind: String = "chicken"   # chicken | rabbit | deer | wolf | boar

var home: Vector3 = Vector3.ZERO
var _model: Node3D
var _head: Node3D
var _t: float = 0.0
var _state: String = "idle"
var _timer: float = 0.0
var _dir: Vector3 = Vector3.ZERO
var _leash: float = 10.0
var _flee_range: float = 4.0
var _walk_speed: float = 0.9
var _flee_speed: float = 3.2
var _carcass: bool = false
var _age_ticks: int = 0
var physical_strength: float = 1.0
var _adult_model_scale: Vector3 = Vector3.ONE
var _hunt_target: Critter
var _hunt_cooldown: float = 0.0

func _ready() -> void:
	add_to_group("critter")
	add_to_group("wildlife")
	if _is_predator():
		add_to_group("wildlife_predator")
	collision_layer = Constants.LAYER_CREATURE
	collision_mask = Constants.LAYER_WORLD
	home = global_position
	_t = randf() * 10.0
	if kind != "chicken":
		_leash = 30.0
		_flee_range = 7.0
		_walk_speed = 1.6
		_flee_speed = 5.5
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.22
	cs.shape = sh
	cs.position = Vector3(0, 0.22, 0)
	add_child(cs)
	_model = Node3D.new()
	add_child(_model)
	if kind in ["rabbit", "arctic_hare"]:
		_build_rabbit()
	elif kind != "chicken":
		_build_large_wildlife()
	else:
		_build_chicken()
	var size_factor := randf_range(0.9, 1.12)
	match kind:
		"deer", "red_deer", "marsh_deer", "elk", "tundra_muskox", "savanna_elephant": size_factor = randf_range(1.25, 1.55)
		"wolf", "grey_wolf", "brown_bear", "snow_leopard", "jaguar", "marsh_crocodile", "savanna_lion": size_factor = randf_range(1.10, 1.48)
		"boar", "wild_boar", "mountain_goat", "ash_goat", "tapir": size_factor = randf_range(1.15, 1.48)
		"rabbit", "arctic_hare", "red_fox", "snow_fox", "sand_cat", "lynx", "desert_gazelle", "shorebird", "marsh_heron", "monkey", "ember_lizard", "vulture": size_factor = randf_range(0.82, 1.18)
	_model.scale = Vector3.ONE * size_factor
	_adult_model_scale = _model.scale
	physical_strength = _base_species_strength() * 0.55
	cs.scale = Vector3.ONE * size_factor
	cs.position.y *= size_factor
	_timer = randf_range(0.5, 3.0)

func _is_predator() -> bool:
	return kind in ["wolf", "grey_wolf", "red_fox", "snow_fox", "lynx", "brown_bear", "snow_leopard", "jaguar", "marsh_crocodile", "hyena", "sand_cat", "savanna_lion"]

func _prey_kinds() -> Array[String]:
	var prey_map := {
		"wolf": ["deer", "red_deer", "elk", "rabbit", "wild_boar"],
		"grey_wolf": ["red_deer", "elk", "rabbit", "wild_boar"],
		"red_fox": ["rabbit", "arctic_hare", "shorebird"],
		"snow_fox": ["arctic_hare", "rabbit", "shorebird"],
		"lynx": ["rabbit", "red_deer"],
		"brown_bear": ["wild_boar", "red_deer", "trout"],
		"snow_leopard": ["mountain_goat", "tundra_muskox"],
		"jaguar": ["tapir", "wild_boar", "monkey"],
		"marsh_crocodile": ["marsh_deer", "trout"],
		"hyena": ["desert_gazelle", "shorebird"],
		"sand_cat": ["desert_gazelle", "arctic_hare"],
		"savanna_lion": ["desert_gazelle", "savanna_elephant"]
	}
	var result: Array[String] = []
	for prey_kind in prey_map.get(kind, []):
		result.append(str(prey_kind))
	return result

func _base_species_strength() -> float:
	var strengths := {
		"rabbit": 0.8, "arctic_hare": 0.9, "deer": 1.4, "red_deer": 1.4,
		"marsh_deer": 1.5, "elk": 3.0, "boar": 1.8, "wild_boar": 1.8,
		"wolf": 3.4, "grey_wolf": 3.4, "brown_bear": 6.0, "mountain_goat": 2.8,
		"snow_leopard": 5.2, "snow_fox": 1.8, "red_fox": 2.0, "lynx": 2.7,
		"marsh_crocodile": 5.5, "jaguar": 5.0, "tapir": 2.1, "monkey": 1.1,
		"desert_gazelle": 1.6, "sand_cat": 2.0, "hyena": 3.1, "ash_goat": 2.6,
		"ember_lizard": 1.2, "vulture": 1.7, "savanna_elephant": 8.0,
		"savanna_lion": 5.8, "tundra_muskox": 4.1, "coastal_seal": 2.8,
		"river_otter": 1.7, "reef_shark": 7.0, "trout": 0.9, "shorebird": 0.8,
		"marsh_heron": 1.1
	}
	return float(strengths.get(kind, 1.0))

func get_combat_strength() -> float:
	return physical_strength

func advance_ecological_age() -> void:
	_age_ticks += 1
	var maturity := clampf(float(_age_ticks) / 8.0, 0.12, 1.0)
	physical_strength = _base_species_strength() * maturity
	set_meta("ecological_age_ticks", _age_ticks)
	set_meta("physical_strength", physical_strength)
func _mat(c: Color, rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

func _sph(parent: Node3D, r: float, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 10
	m.rings = 6
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi

func _cone(parent: Node3D, r: float, h: float, mat: Material, pos: Vector3, rot: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = 0.0
	m.bottom_radius = r
	m.height = h
	m.radial_segments = 6
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


func _build_large_wildlife() -> void:
	var fur_color := Color(0.48, 0.29, 0.14)
	if kind in ["wolf", "grey_wolf", "snow_fox", "snow_leopard", "lynx"]:
		fur_color = Color(0.48, 0.53, 0.60) if kind != "snow_fox" and kind != "snow_leopard" else Color(0.88, 0.90, 0.94)
	elif kind in ["boar", "wild_boar", "brown_bear", "marsh_crocodile", "jaguar", "savanna_lion"]:
		fur_color = Color(0.30, 0.19, 0.13)
	elif kind in ["mountain_goat", "ash_goat", "tundra_muskox"]:
		fur_color = Color(0.72, 0.70, 0.62)
	elif kind in ["red_fox", "desert_gazelle", "sand_cat", "hyena"]:
		fur_color = Color(0.68, 0.43, 0.22)
	var fur := _mat(fur_color)
	var body_scale := Vector3(1.0, 0.9, 1.45) if kind == "deer" else Vector3(1.0,0.85,1.25)
	_sph(_model, 0.32 if kind == "deer" else 0.35, fur, Vector3(0,0.48,0), body_scale)
	_head = Node3D.new(); _head.position = Vector3(0,0.62,-0.38); _model.add_child(_head)
	_sph(_head, 0.19, fur, Vector3(0,0,0), Vector3(0.9,0.9,1.25))
	for side in [-1.0,1.0]:
		var leg := MeshInstance3D.new(); var lm := CylinderMesh.new(); lm.top_radius=0.045; lm.bottom_radius=0.06; lm.height=0.48; leg.mesh=lm; leg.material_override=fur; leg.position=Vector3(side*0.2,0.22,0.08); _model.add_child(leg)
	if kind in ["deer", "red_deer", "marsh_deer", "elk"]:
		for side in [-1.0,1.0]:
			var antler := MeshInstance3D.new(); var am := CylinderMesh.new(); am.top_radius=0.012; am.bottom_radius=0.035; am.height=0.48; antler.mesh=am; antler.material_override=_mat(Color(0.72,0.62,0.42)); antler.position=Vector3(side*0.13,0.25,0.0); antler.rotation.z=side*0.3; _head.add_child(antler)

func _build_chicken() -> void:
	var variants: Array[Color] = [Color(0.95, 0.93, 0.88), Color(0.62, 0.36, 0.20), Color(0.25, 0.22, 0.22), Color(0.85, 0.65, 0.35)]
	var body_c: Color = variants[randi() % variants.size()]
	var body := _mat(body_c)
	var orange := _mat(Color(0.95, 0.6, 0.15))
	var red := _mat(Color(0.85, 0.12, 0.1))
	_sph(_model, 0.2, body, Vector3(0, 0.3, 0), Vector3(1.0, 0.95, 1.3))
	_sph(_model, 0.12, body, Vector3(0, 0.42, 0.22), Vector3(0.6, 1.0, 0.8)).rotation.x = -0.5   # tail
	_head = Node3D.new()
	_head.position = Vector3(0, 0.46, -0.2)
	_model.add_child(_head)
	_sph(_head, 0.085, body, Vector3.ZERO)
	_cone(_head, 0.03, 0.09, orange, Vector3(0, -0.01, -0.1), Vector3(-PI * 0.5, 0, 0))
	_sph(_head, 0.035, red, Vector3(0, 0.08, -0.01), Vector3(0.5, 1.0, 1.4))
	_sph(_head, 0.02, _mat(Color(0.9, 0.1, 0.1)), Vector3(0, -0.07, -0.07), Vector3(0.7, 1.2, 0.7))
	var eye := _mat(Color(0.02, 0.02, 0.02))
	for s in [-1.0, 1.0]:
		_sph(_head, 0.014, eye, Vector3(s * 0.065, 0.02, -0.04))
		var leg := MeshInstance3D.new()
		var lm := CylinderMesh.new()
		lm.top_radius = 0.012
		lm.bottom_radius = 0.012
		lm.height = 0.16
		leg.mesh = lm
		leg.material_override = orange
		leg.position = Vector3(s * 0.07, 0.08, 0.02)
		_model.add_child(leg)

func _build_rabbit() -> void:
	var furs: Array[Color] = [Color(0.55, 0.45, 0.35), Color(0.72, 0.68, 0.62), Color(0.4, 0.34, 0.3)]
	var fur: StandardMaterial3D = _mat(furs[randi() % furs.size()], 0.95)
	var white := _mat(Color(0.95, 0.95, 0.95), 0.95)
	_sph(_model, 0.17, fur, Vector3(0, 0.2, 0.04), Vector3(0.9, 0.9, 1.25))
	_sph(_model, 0.065, white, Vector3(0, 0.22, 0.26))   # tail
	_head = Node3D.new()
	_head.position = Vector3(0, 0.3, -0.16)
	_model.add_child(_head)
	_sph(_head, 0.09, fur, Vector3.ZERO, Vector3(0.9, 0.95, 1.1))
	for s in [-1.0, 1.0]:
		var ear := _sph(_head, 0.035, fur, Vector3(s * 0.045, 0.14, 0.02), Vector3(0.5, 2.6, 0.5))
		ear.rotation.z = s * -0.15
		_sph(_head, 0.015, _mat(Color(0.02, 0.02, 0.02)), Vector3(s * 0.065, 0.02, -0.06))
	_sph(_head, 0.018, _mat(Color(0.9, 0.55, 0.55)), Vector3(0, -0.02, -0.095))

func _choose_water_and_food_direction() -> Vector3:
	var best_direction := Vector3.ZERO
	var best_score := -INF
	var climate := ClimateSystem.sample_at(global_position)
	var temperature := float(climate.get("temperature_c", 18.0))
	for i in range(10):
		var angle := TAU * float(i) / 10.0 + randf_range(-0.18, 0.18)
		var distance := randf_range(30.0, 90.0)
		var candidate := global_position + Vector3(cos(angle) * distance, 0.0, sin(angle) * distance)
		var water := HydrologySystem.get_water_state(candidate)
		var moisture := float(water.get("soil_saturation", 0.25))
		var stream := float(water.get("discharge_m3_s", 0.0))
		var flood := float(water.get("flood_risk", 0.0))
		var score := moisture * 1.4 + minf(stream, 3.0) * 0.25 - flood * 1.8
		if kind in ["deer", "boar", "rabbit"]:
			score += moisture * 0.4 # grazing and browse are better where plants can grow
		if kind == "wolf":
			score += 0.2 if temperature > -5.0 and temperature < 30.0 else -0.4
		if temperature < -2.0 and kind in ["chicken", "rabbit"]:
			score -= 0.35
		if score > best_score:
			best_score = score
			best_direction = (candidate - global_position).normalized()
	if best_direction.length() < 0.01:
		var a := randf() * TAU
		return Vector3(cos(a), 0.0, sin(a))
	return best_direction

func become_carcass() -> void:
	if _carcass:
		return
	_carcass = true
	remove_from_group("critter")
	remove_from_group("elyndor_spawned_wildlife")
	_state = "carcass"
	velocity = Vector3.ZERO
	if _model:
		_model.rotation.z = PI * 0.5
		_model.position.y = 0.035
		_model.scale *= Vector3(1.0, 0.72, 1.0)
		for child in _model.get_children():
			if child is MeshInstance3D:
				var old_material: Material = (child as MeshInstance3D).material_override
				if old_material is StandardMaterial3D:
					var muted := (old_material as StandardMaterial3D).duplicate() as StandardMaterial3D
					muted.albedo_color = muted.albedo_color.darkened(0.28)
					(child as MeshInstance3D).material_override = muted
		set_meta("wildlife_carcass", true)
		set_meta("carcass_species", kind)
		add_to_group("wildlife_carcass")
		var label := Label3D.new()
		label.text = "Carcass"
		label.font_size = 20
		label.outline_size = 5
		label.position.y = 0.55
		label.modulate = Color(0.78, 0.72, 0.58)
		add_child(label)
		get_tree().create_timer(150.0).timeout.connect(queue_free)

func _physics_process(delta: float) -> void:
	if _carcass:
		return
	_t += delta
	if not is_on_floor():
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
	var player: Node3D = GameManager.player
	var to_player := Vector3.ZERO
	var dist: float = 999.0
	if player:
		to_player = player.global_position - global_position
		to_player.y = 0.0
		dist = to_player.length()

	# Wildlife responds to both the player and nearby threats. Predators and
	# armed hunters disturb grazing animals even when the player is not close.
	var threat_vector := -to_player if dist < _flee_range else Vector3.ZERO
	var threat_distance := dist
	for threat in get_tree().get_nodes_in_group("enemy"):
		if threat is Node3D:
			var away := global_position - (threat as Node3D).global_position
			away.y = 0.0
			if away.length() < _flee_range * 1.8 and away.length() > 0.01 and away.length() < threat_distance:
				threat_distance = away.length()
				threat_vector = away
	if not _is_predator():
		for predator in get_tree().get_nodes_in_group("wildlife_predator"):
			if predator == self or not predator is Critter or (predator as Critter)._carcass:
				continue
			var predator_away := global_position - (predator as Node3D).global_position
			predator_away.y = 0.0
			if predator_away.length() < _flee_range * 2.2 and predator_away.length() > 0.01 and predator_away.length() < threat_distance:
				threat_distance = predator_away.length()
				threat_vector = predator_away
	for hunter in get_tree().get_nodes_in_group("npc"):
		if hunter is Node3D and str(hunter.get("role")) in ["hunter", "ranger"]:
			var away := global_position - (hunter as Node3D).global_position
			away.y = 0.0
			if away.length() < _flee_range * 0.85 and away.length() > 0.01 and away.length() < threat_distance:
				threat_distance = away.length()
				threat_vector = away
	if threat_vector.length() > 0.01:
		_state = "flee"
		_dir = threat_vector.normalized()
	elif _state == "flee" and dist > _flee_range * 1.6:
		_state = "idle"
		_timer = randf_range(1.0, 2.5)

	_hunt_cooldown = maxf(0.0, _hunt_cooldown - delta)
	if _is_predator() and _state != "flee":
		if not is_instance_valid(_hunt_target) or _hunt_target._carcass or global_position.distance_to(_hunt_target.global_position) > 24.0:
			_hunt_target = null
			var best_distance := 18.0
			for possible_prey in get_tree().get_nodes_in_group("critter"):
				if possible_prey == self or not possible_prey is Critter or (possible_prey as Critter)._carcass:
					continue
				if str((possible_prey as Critter).kind) not in _prey_kinds():
					continue
				var prey_distance := global_position.distance_to((possible_prey as Node3D).global_position)
				if prey_distance < best_distance:
					best_distance = prey_distance
					_hunt_target = possible_prey as Critter
		if is_instance_valid(_hunt_target):
			var hunt_direction := _hunt_target.global_position - global_position
			hunt_direction.y = 0.0
			if hunt_direction.length() > 0.01:
				_dir = hunt_direction.normalized()
				_state = "walk"
				if hunt_direction.length() < 1.45 and _hunt_cooldown <= 0.0 and MMORPGNetwork.is_authority():
					_hunt_target.become_carcass()
					_hunt_cooldown = 3.0
					_hunt_target = null
	_timer -= delta
	if _state != "flee" and _timer <= 0.0 and not (_is_predator() and is_instance_valid(_hunt_target)):
		if _state == "idle" and randf() < 0.6:
			_state = "walk"
			_timer = randf_range(0.8, 2.2)
			var migration_target: Variant = get_meta("seasonal_migration_target", null)
			if migration_target is Vector3 and global_position.distance_to(migration_target) > 24.0:
				var migration_direction: Vector3 = migration_target - global_position
				migration_direction.y = 0.0
				_dir = migration_direction.normalized()
				_timer = randf_range(3.0, 6.0)
			else:
				var to_home: Vector3 = home - global_position
				to_home.y = 0.0
				if to_home.length() > _leash:
					_dir = to_home.normalized()
				else:
					_dir = _choose_water_and_food_direction()
		else:
			_state = "idle"
			_timer = randf_range(1.2, 4.0)

	var speed: float = 0.0
	if _state == "walk":
		speed = _walk_speed
	elif _state == "flee":
		speed = _flee_speed
	var wish: Vector3 = _dir * speed
	velocity.x = lerpf(velocity.x, wish.x, clampf(delta * 10.0, 0.0, 1.0))
	velocity.z = lerpf(velocity.z, wish.z, clampf(delta * 10.0, 0.0, 1.0))
	if kind == "rabbit" and speed > 0.0 and is_on_floor() and fmod(_t, 0.45) < delta:
		velocity.y = 3.2
	move_and_slide()

	if speed > 0.0 and _dir.length() > 0.1:
		_model.rotation.y = lerp_angle(_model.rotation.y, atan2(-_dir.x, -_dir.z), clampf(delta * 10.0, 0.0, 1.0))
	if _head:
		if kind == "chicken":
			if _state == "idle":
				_head.rotation.x = 0.7 * maxf(0.0, sin(_t * 5.0 + float(get_instance_id() % 7)))   # peck
			else:
				_head.position.z = -0.2 + sin(_t * 12.0) * 0.03
				_head.rotation.x = 0.0
		else:
			_head.rotation.x = sin(_t * 6.0) * 0.1 if _state == "idle" else 0.0
