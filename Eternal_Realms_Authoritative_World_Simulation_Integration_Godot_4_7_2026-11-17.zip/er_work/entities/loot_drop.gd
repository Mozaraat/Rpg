# Ground loot — a real item model hovering over a tinted glow ring, with a
# faint light shaft so drops stay findable at night without being a beacon.
class_name LootDrop
extends Area3D

var item_id: String = ""
var count: int = 1
var _life: float = 45.0
var _spin: Node3D
var _disc_mat: StandardMaterial3D
var _bob_phase: float = 0.0
var network_uid: String = ""

func _ready() -> void:
	add_to_group("loot_drop")
	add_to_group("interactable")
	monitoring = true
	collision_layer = 0
	collision_mask = Constants.LAYER_PLAYER
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.7
	cs.shape = sh
	add_child(cs)

	var glow := ItemVisuals.glow_color(item_id)
	_spin = Node3D.new()
	_spin.position.y = 0.34
	_spin.rotation.y = randf() * TAU
	_spin.add_child(ItemVisuals.make(item_id))
	add_child(_spin)

	var disc := MeshInstance3D.new()
	var dm := CylinderMesh.new()
	dm.top_radius = 0.30
	dm.bottom_radius = 0.30
	dm.height = 0.014
	dm.radial_segments = 24
	dm.rings = 1
	disc.mesh = dm
	disc.position.y = 0.035
	_disc_mat = _glow_surface(glow, 0.28)
	disc.material_override = _disc_mat
	disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(disc)

	var beam := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.15
	bm.bottom_radius = 0.08
	bm.height = 1.35
	bm.radial_segments = 16
	bm.cap_top = false
	bm.cap_bottom = false
	beam.mesh = bm
	beam.position.y = 0.70
	beam.material_override = _glow_surface(glow, 0.055)
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(beam)

	body_entered.connect(_on_body)

func _glow_surface(c: Color, a: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = Color(c.r, c.g, c.b, a)
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = 1.1
	return m

func _process(delta: float) -> void:
	_life -= delta
	_bob_phase += delta * 2.0
	if _spin:
		_spin.rotation.y += delta * 1.35
		_spin.position.y = 0.34 + sin(_bob_phase) * 0.055
	if _disc_mat:
		_disc_mat.albedo_color.a = 0.24 + sin(_bob_phase * 1.4) * 0.06
	if _life <= 0.0:
		queue_free()

func can_interact() -> bool:
	return true

func get_prompt() -> String:
	var item_name: String = str(ItemDB.def(item_id).get("name", item_id))
	if count > 1:
		return "Pick up %s x%d" % [item_name, count]
	return "Pick up %s" % item_name

func interact(_player: Node3D = null) -> void:
	_pickup()

func _on_body(body: Node) -> void:
	if body.is_in_group("player") or body == GameManager.player:
		_pickup()

func _pickup() -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		MMORPGNetwork.request_loot_pickup(network_uid)
		return
	if MMORPGNetwork.is_online() and multiplayer.is_server() and network_uid != "":
		MMORPGNetwork.server_collect_loot(network_uid, 1)
		return
	if item_id == "" or not ItemDB.has_item(item_id):
		queue_free()
		return
	PlayerData.add_item(item_id, count)
	queue_free()

static func spawn_at(parent: Node, pos: Vector3, id: String, cnt: int = 1) -> void:
	if parent == null or not ItemDB.has_item(id):
		return
	if MMORPGNetwork.is_online():
		if MMORPGNetwork.is_authority():
			MMORPGNetwork.spawn_shared_loot(pos, id, cnt)
		return
	var d := LootDrop.new()
	d.item_id = id
	d.count = cnt
	d.position = pos + Vector3(randf_range(-0.4, 0.4), 0.2, randf_range(-0.4, 0.4))
	parent.add_child(d)
