# Lightweight motion for landmark props (orreries, crystal gyres and ritual rings).
extends Node3D

@export var spin_speed: float = 0.28
@export var bob_height: float = 0.08
@export var bob_speed: float = 1.1
var _base_y: float = 0.0
var _clock: float = 0.0

func _ready() -> void:
	_base_y = position.y
	_clock = randf() * TAU

func _process(delta: float) -> void:
	_clock += delta * bob_speed
	rotation.y += delta * spin_speed
	position.y = _base_y + sin(_clock) * bob_height
