extends Area3D
class_name SpiritualLandmark

@export var landmark_id: String = "elderheart_heartwell"
@export var landmark_name: String = "Elderheart Heartwell"
@export var element: String = "nature"
@export_multiline var lore: String = "Ancient spiritual energy gathers here."
@export var rare_technique: String = ""
@export var glow_color: Color = Color(0.38, 0.78, 0.92)

var interact_range: float = 3.8
var _cooldown: float = 0.0
var _discovered: bool = false
var _visual_root: Node3D
var _core: MeshInstance3D
var _halo: MeshInstance3D
var _light: OmniLight3D
var _pulse_time: float = 0.0

const ELEMENT_SKILLS: Dictionary = {
	"fire":"fire_affinity", "water":"water_affinity", "wind":"wind_affinity",
	"earth":"earth_affinity", "lightning":"lightning_affinity", "ice":"ice_affinity",
	"nature":"herbalism"
}

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("spirit_landmark")
	collision_layer = 0
	collision_mask = 0
	var stored: Variant = PlayerData.stats.get("spiritual_landmark_discoveries", {})
	_discovered = stored is Dictionary and bool(stored.get(landmark_id, false))
	_build_landmark()

func _process(delta: float) -> void:
	_cooldown = maxf(_cooldown - delta, 0.0)
	_pulse_time += delta
	if _core:
		_core.position.y = 2.05 + sin(_pulse_time * 1.45) * 0.12
		_core.rotation.y += delta * 0.55
	if _halo:
		_halo.rotation.y -= delta * 0.3
	if _light:
		_light.light_energy = 0.75 + (sin(_pulse_time * 1.9) + 1.0) * 0.22

func can_interact() -> bool:
	return _cooldown <= 0.0

func get_prompt() -> String:
	if not _discovered:
		return "Attune to %s" % landmark_name
	return "Meditate at %s" % landmark_name

func interact(player: Node3D = null) -> void:
	if player == null or not is_instance_valid(player) or _cooldown > 0.0:
		return
	var skill_value: Variant = player.get("skills")
	var skills: SkillSystem = skill_value as SkillSystem if skill_value is SkillSystem else null
	if not _discovered:
		_discover_landmark(player, skills)
	else:
		_meditate(player, skills)

func _discover_landmark(player: Node3D, skills: SkillSystem) -> void:
	_discovered = true
	var stored_value: Variant = PlayerData.stats.get("spiritual_landmark_discoveries", {})
	var stored: Dictionary = stored_value.duplicate(true) if stored_value is Dictionary else {}
	stored[landmark_id] = true
	PlayerData.stats["spiritual_landmark_discoveries"] = stored
	PlayerData.stats["spiritual_landmarks_found"] = int(PlayerData.stats.get("spiritual_landmarks_found", 0)) + 1
	if has_meta("dungeon_floor"):
		var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
		if dungeon and dungeon.has_method("mark_discovery"):
			dungeon.mark_discovery(int(get_meta("dungeon_floor", 0)), "spirit_vein")
	if skills:
		var affinity_skill: String = str(ELEMENT_SKILLS.get(element, "spiritual_sense"))
		skills.train(affinity_skill, 1.35)
		skills.train("spiritual_sense", 0.65)
		skills.train("ancient_lore", 0.22, true)
		CultivationDiscovery.record_clue("landmark_%s" % landmark_id, landmark_name, lore)
		if CultivationDiscovery.is_cultivation_unlocked():
			skills.refresh_meridian_unlocks()
			skills.refresh_cultivation_techniques()
		if rare_technique != "" and not skills.has_discovered_technique(rare_technique):
			if skills.has_method("seal_rare_technique"):
				skills.seal_rare_technique(rare_technique, "resonance at " + landmark_name)
			else:
				skills.discover_technique(rare_technique, "resonance at " + landmark_name)
	PlayerData.add_item("mana_crystal", 1)
	_restore_spirit(player, 26.0)
	_cooldown = 30.0
	EventBus.toast.emit("SPIRIT LANDMARK — %s" % landmark_name, "levelup")
	EventBus.toast.emit(lore, "info")
	EventBus.activity.emit("Attuned to the %s landmark" % element.capitalize(), "cultivation")
	if _core and _core.material_override is StandardMaterial3D:
		(_core.material_override as StandardMaterial3D).emission_energy_multiplier = 2.4

func _meditate(player: Node3D, skills: SkillSystem) -> void:
	_restore_spirit(player, 17.0)
	if player.get("health") != null:
		player.health.heal(7.0)
	if skills:
		skills.train("spiritual_sense", 0.045, true)
		skills.train("cultivation", 0.035, true)
	_cooldown = 75.0
	EventBus.toast.emit("You settle your breathing. Spirit and body recover.", "info")
	EventBus.activity.emit("Meditated at %s" % landmark_name, "cultivation")

func _restore_spirit(player: Node3D, amount: float) -> void:
	var current_value: Variant = player.get("spiritual_energy")
	var maximum_value: Variant = player.get("max_spiritual_energy")
	if current_value != null and maximum_value != null:
		player.set("spiritual_energy", minf(float(maximum_value), float(current_value) + amount))

func _build_landmark() -> void:
	_visual_root = Node3D.new()
	_visual_root.name = "ResonanceStructure"
	add_child(_visual_root)
	var stone := _material(glow_color.darkened(0.64), false, 0.18)
	var metal := _material(glow_color.darkened(0.16), false, 0.62)
	var glow := _material(glow_color, true, 0.05)
	var base := MeshInstance3D.new()
	var base_mesh := CylinderMesh.new()
	base_mesh.top_radius = 1.0
	base_mesh.bottom_radius = 1.28
	base_mesh.height = 0.38
	base.mesh = base_mesh
	base.material_override = stone
	base.position.y = 0.19
	_visual_root.add_child(base)
	var inlay := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.88
	ring_mesh.outer_radius = 1.03
	inlay.mesh = ring_mesh
	inlay.material_override = glow
	inlay.position.y = 0.42
	inlay.rotation.x = PI * 0.5
	_visual_root.add_child(inlay)
	for shard_i in range(3):
		var angle: float = TAU * float(shard_i) / 3.0
		var shard := MeshInstance3D.new()
		var prism := PrismMesh.new()
		prism.size = Vector3(0.34, 1.15 + float(shard_i % 2) * 0.22, 0.34)
		shard.mesh = prism
		shard.material_override = metal
		shard.position = Vector3(cos(angle) * 0.72, 0.9, sin(angle) * 0.72)
		shard.rotation = Vector3(0.12, -angle, 0.18)
		_visual_root.add_child(shard)
	_core = MeshInstance3D.new()
	var core_mesh := PrismMesh.new()
	core_mesh.size = Vector3(0.62, 1.05, 0.62)
	_core.mesh = core_mesh
	_core.material_override = glow
	_core.position.y = 2.05
	_visual_root.add_child(_core)
	_halo = MeshInstance3D.new()
	var halo_mesh := TorusMesh.new()
	halo_mesh.inner_radius = 0.9
	halo_mesh.outer_radius = 0.98
	_halo.mesh = halo_mesh
	_halo.material_override = glow
	_halo.position.y = 1.75
	_halo.rotation.x = 0.42
	_visual_root.add_child(_halo)
	_light = OmniLight3D.new()
	_light.light_color = glow_color
	_light.light_energy = 1.0
	_light.omni_range = 7.5
	_light.position.y = 1.9
	_visual_root.add_child(_light)
	var label := Label3D.new()
	label.text = landmark_name.to_upper()
	label.font_size = 22
	label.position.y = 2.9
	label.modulate = glow_color.lightened(0.25)
	label.outline_size = 6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.pixel_size = 0.006
	_visual_root.add_child(label)

func _material(color: Color, emissive: bool, metalness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.42 if emissive else 0.86
	material.metallic = metalness
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.55
	return material
