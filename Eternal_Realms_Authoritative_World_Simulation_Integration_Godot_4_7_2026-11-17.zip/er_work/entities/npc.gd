# NPC - lives a daily routine, gives quests, trades, and chats.
extends CharacterBody3D
class_name NPC

@export var npc_name: String = "Villager"
@export var role: String = "villager"
@export var sect_id: String = ""
@export var free_will: bool = true
var home_center: Vector3 = Vector3.ZERO
var wander_radius: float = 16.0
enum WillState { FOLLOW_SCHEDULE, WANDER, SOCIAL, FLEE, REST }
var will_state: WillState = WillState.FOLLOW_SCHEDULE
var _will_timer: float = 0.0
var _wander_target: Vector3 = Vector3.ZERO
var _personality: float = 0.5

@export var dialogue_lines: PackedStringArray = [
	"Welcome to Elyndor, young one.",
	"The world is vast. Grow strong."
]

@onready var model: CharacterModel = $Model
@onready var name_label: Label3D = $NameLabel
@onready var health: HealthComponent = $HealthComponent

## Daily routine: Array of {"h": hour 0-24, "pos": Vector2 (world XZ), "sleep": bool}
var schedule: Array = []
var look_target: Vector2 = Vector2.ZERO
var has_look_target: bool = false

var interact_range: float = 3.4
var _combat_cd: float = 0.0
var asleep: bool = false

var _talking_to: Node3D = null
var _talk_time: float = 0.0
var _height_scale: float = 1.0
var _marker: Label3D
var _bubble: Label3D
var _bubble_t: float = 0.0
var _delivery_state: Dictionary = {}
var _bark_timer: float = 0.0
var _day_node: Node = null
var _stuck_t: float = 0.0
var _last_pos: Vector3 = Vector3.ZERO
var _check_t: float = 0.0
var _extra_light: Light3D = null
var _merchant_stall: Node3D = null
var _stall_state_clock: float = 0.0
var _stall_is_open: bool = false
var _cargo_prop: Node3D = null
var _cargo_timer: float = 0.0
var family_profile: Dictionary = {}
var combat_profession: bool = false
var _combat_target: Node3D = null
var _combat_attack_timer: float = 0.0
var _combat_experience: int = 0
var _combat_flee_timer: float = 0.0
var _is_child: bool = false
var _life_journey_active: bool = false
var _life_journey_target: Vector3 = Vector3.ZERO
var _life_journey_returning: bool = false
var _life_journey_mode: String = "expedition"
const NPC_DEFENCE_ROLES := ["guard", "soldier", "ranger", "hunter", "adventurer", "mercenary", "swordsman"]
const SECT_COLORS := {
	"azure_sword_hall": Color(0.34, 0.58, 0.94),
	"crimson_pavilion": Color(0.9, 0.28, 0.18),
	"stillwater_monastery": Color(0.26, 0.7, 0.78),
	"stormspire_order": Color(0.68, 0.54, 0.96),
	"veiled_moon_covenant": Color(0.46, 0.42, 0.68),
	"rootbound_circle": Color(0.34, 0.64, 0.36),
}
# Dye swatches multiply the scanned cloth atlas; they keep the photo texture but
# give every household its own cloth, so shared meshes never read as clones.
const NPC_TINTS := {
	"guard": [Color(0.66, 0.76, 0.98), Color(0.98, 0.66, 0.62), Color(0.64, 0.94, 0.7), Color(0.98, 0.88, 0.66), Color(0.76, 0.8, 0.92), Color(0.66, 0.68, 0.72)],
	"soldier": [Color(0.72, 0.62, 0.44), Color(0.54, 0.6, 0.74), Color(0.86, 0.56, 0.44), Color(0.56, 0.7, 0.56), Color(0.7, 0.66, 0.6)],
	"ranger": [Color(0.62, 0.86, 0.6), Color(0.74, 0.8, 0.52), Color(0.6, 0.76, 0.64), Color(0.9, 0.8, 0.58)],
	"hunter": [Color(0.66, 0.62, 0.42), Color(0.8, 0.6, 0.4), Color(0.5, 0.6, 0.46), Color(0.72, 0.5, 0.36)],
	"farmer": [Color(0.9, 0.78, 0.58), Color(0.78, 0.66, 0.5), Color(0.66, 0.74, 0.56), Color(0.86, 0.7, 0.62)],
	"merchant": [Color(0.9, 0.66, 0.38), Color(0.78, 0.56, 0.56), Color(0.68, 0.62, 0.9), Color(0.56, 0.74, 0.72)],
	"smith": [Color(0.7, 0.7, 0.72), Color(0.86, 0.68, 0.5), Color(0.72, 0.74, 0.82), Color(0.62, 0.6, 0.58)],
	"craftsman": [Color(0.8, 0.68, 0.48), Color(0.56, 0.66, 0.58), Color(0.72, 0.56, 0.42), Color(0.62, 0.62, 0.72)],
	"carpenter": [Color(0.84, 0.68, 0.46), Color(0.6, 0.68, 0.52), Color(0.72, 0.56, 0.4), Color(0.56, 0.6, 0.68)],
	"fisher": [Color(0.64, 0.82, 0.9), Color(0.72, 0.78, 0.68), Color(0.9, 0.74, 0.54), Color(0.62, 0.72, 0.84)],
	"scholar": [Color(0.68, 0.76, 0.96), Color(0.9, 0.88, 0.8), Color(0.7, 0.8, 0.86), Color(0.9, 0.78, 0.62)],
	"herbalist": [Color(0.66, 0.88, 0.64), Color(0.78, 0.84, 0.6), Color(0.6, 0.8, 0.74), Color(0.9, 0.8, 0.62)],
	"healer": [Color(0.8, 0.9, 0.94), Color(0.6, 0.8, 0.72), Color(0.92, 0.84, 0.72), Color(0.62, 0.7, 0.88)],
	"mage": [Color(0.7, 0.68, 1.0), Color(0.86, 0.62, 1.0), Color(0.62, 0.86, 1.0), Color(0.94, 0.76, 0.96)],
	"spirit_master": [Color(0.66, 0.9, 0.86), Color(0.78, 0.74, 1.0), Color(0.64, 0.8, 0.98), Color(0.92, 0.86, 0.72)],
	"elder": [Color(0.8, 0.78, 0.72), Color(0.62, 0.6, 0.6), Color(0.88, 0.84, 0.74), Color(0.64, 0.68, 0.76)],
	"adventurer": [Color(0.8, 0.66, 0.46), Color(0.56, 0.68, 0.8), Color(0.76, 0.56, 0.46), Color(0.6, 0.62, 0.56)],
	"mercenary": [Color(0.72, 0.52, 0.4), Color(0.5, 0.54, 0.64), Color(0.8, 0.66, 0.42), Color(0.58, 0.5, 0.46)],
	"swordsman": [Color(0.8, 0.7, 0.56), Color(0.56, 0.62, 0.78), Color(0.82, 0.6, 0.5), Color(0.64, 0.56, 0.52)],
	"villager": [Color(1.0, 0.92, 0.8), Color(0.9, 0.94, 0.84), Color(0.86, 0.9, 1.0), Color(0.96, 0.86, 0.78), Color(0.88, 0.84, 0.94), Color(0.94, 0.9, 0.82)],
	"sect_master": [Color(1.0, 1.0, 1.0), Color(0.98, 0.96, 1.0), Color(0.96, 0.98, 1.0), Color(1.0, 0.98, 0.94)],
	"sect_disciple": [Color(1.0, 1.0, 1.0), Color(1.0, 0.98, 0.96), Color(0.96, 0.98, 1.0), Color(0.98, 1.0, 0.96)],
}
static var _look_claims: Dictionary = {}

const WALK_SPEED: float = 1.5

const BARKS: Dictionary = {
	"Elara": ["Lovely morning, isn't it?", "Mind the slimes out by the fields!", "Fresh bread at the market today!", "The well water is so cold this morning."],
	"Borin": ["These crops won't water themselves.", "Good soil, honest work.", "Hmph. Where did I leave that axe?", "Rain tomorrow, mark my words."],
	"Old Man Thoren": ["The stars were odd last night...", "Ah, my old bones.", "Young ones grow up so fast.", "Mm. The Spire hums tonight."],
	"Gorrim the Smith": ["Clang! Clang! Good iron sings.", "Bring me ore, and I'll make you a legend.", "A dull blade is a dead blade.", "Nothing like the smell of hot steel."],
	"Mira": ["Potions, tonics, fresh stock!", "Best prices in Elyndor!", "A coin saved is a coin earned.", "Come, come, take a look!"],
	"Archmage Lira": ["The crystal is restless today.", "Knowledge is its own reward.", "Hmm... fascinating."],
	"Apprentice Kael": ["I'm reading. Really!", "Don't tell Lira I dropped the book.", "Floating books are harder than they look."],
}

func _ready() -> void:
	add_to_group("mmo_world_npc")
	add_to_group("npc")
	add_to_group("interactable")
	var transient: bool = has_meta("transient_npc") or has_meta("network_remote_replica")
	var life_record: Dictionary = LivingWorldSystem.get_npc_life(npc_name)
	if not life_record.is_empty():
		if not bool(life_record.get("alive", true)):
			queue_free()
			return
		if bool(life_record.get("mobile", false)) and str(life_record.get("location_state", "home")) == "on_expedition":
			queue_free()
			return
		role = str(life_record.get("role", role))
		_is_child = int(life_record.get("age_days", 0)) < 18 * 365
		if _is_child:
			role = "child"
		var home: Array = life_record.get("home", [])
		if home.size() >= 3:
			home_center = Vector3(float(home[0]), float(home[1]), float(home[2]))
			if bool(life_record.get("mobile", false)):
				var saved_region := str(life_record.get("region_id", ""))
				var current_region := WorldLifeSimulation.region_id_at(global_position.x, global_position.z)
				if str(life_record.get("location_state", "home")) == "migrating" or (not saved_region.is_empty() and current_region != saved_region):
					var spread := absi(npc_name.hash())
					global_position = home_center + Vector3(float(spread % 7) - 3.0, 0.0, float((spread >> 3) % 7) - 3.0)
					life_record["location_state"] = "home"
					if not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority():
						LivingWorldSystem.npc_lives[npc_name] = life_record
						LivingWorldSystem._save_state()
	elif not transient and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		LivingWorldSystem.register_npc(npc_name, role, global_position, role == "child")
		life_record = LivingWorldSystem.get_npc_life(npc_name)
		if not life_record.is_empty():
			role = str(life_record.get("role", role))
			_is_child = int(life_record.get("age_days", 0)) < 18 * 365
			if _is_child: role = "child"
	name_label.text = npc_name
	combat_profession = role in NPC_DEFENCE_ROLES
	family_profile = CivilizationSocieties.family_profile(npc_name, role)
	var look: Dictionary = _appearance()
	if _is_child:
		var age_ratio := clampf(float(life_record.get("age_days", 0)) / float(18 * 365), 0.0, 1.0)
		look["scale"] = lerpf(0.62, 0.88, age_ratio)
	_height_scale = float(look.get("scale", 1.0))
	model.build(look)
	model.scale = Vector3.ONE * _height_scale
	var top: float = 2.15 * _height_scale + (0.25 if look.get("hat", "none") == "wizard" else 0.0)
	name_label.position.y = top
	name_label.shaded = false
	name_label.modulate = Color(1.0, 0.94, 0.72, 1.0)
	name_label.outline_modulate = Color(0.015, 0.02, 0.03, 1.0)
	name_label.outline_size = maxi(name_label.outline_size, 12)

	_marker = Label3D.new()
	_marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_marker.no_depth_test = true
	_marker.font_size = 96
	_marker.outline_size = 16
	_marker.shaded = false
	_marker.modulate = Color(1.0, 0.86, 0.35, 1.0)
	_marker.outline_modulate = Color(0.015, 0.02, 0.03, 1.0)
	_marker.pixel_size = 0.006
	_marker.position.y = top + 0.5
	_marker.visible = false
	add_child(_marker)

	_bubble = Label3D.new()
	_bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_bubble.no_depth_test = true
	_bubble.font_size = 30
	_bubble.outline_size = 12
	_bubble.shaded = false
	_bubble.modulate = Color(1.0, 0.98, 0.88, 1.0)
	_bubble.outline_modulate = Color(0.015, 0.02, 0.03, 1.0)
	_bubble.pixel_size = 0.0055
	_bubble.modulate = Color(1, 1, 0.9)
	_bubble.position.y = top + 0.4
	_bubble.visible = false
	add_child(_bubble)

	_bark_timer = randf_range(8.0, 25.0)
	_add_extras()
	if role == "merchant":
		_build_merchant_stall()
	PlayerData.quests_changed.connect(_update_marker)
	_update_marker()
	_snap_to_schedule()
	_personality = randf()
	_will_timer = randf_range(2.0, 6.0)
	if home_center == Vector3.ZERO:
		home_center = global_position
	add_to_group("npc")



# A merchant's business has a physical presence in the settlement. The stall
# opens with the market day and folds away at closing time; it is not just a log.
func _build_merchant_stall() -> void:
	_merchant_stall = Node3D.new()
	_merchant_stall.name = "MerchantStall"
	_merchant_stall.position = Vector3(1.25, 0.0, 0.65)
	add_child(_merchant_stall)
	var wood := _stall_material(Color(0.30, 0.19, 0.11))
	var cloth := _stall_material(Color(0.68, 0.36, 0.18))
	var linen := _stall_material(Color(0.88, 0.78, 0.57))
	var goods := _stall_material(Color(0.35, 0.58, 0.32))
	_add_stall_box(_merchant_stall, Vector3(0, 0.72, 0), Vector3(1.9, 0.16, 0.95), wood)
	_add_stall_box(_merchant_stall, Vector3(0, 1.05, -0.18), Vector3(2.05, 0.08, 0.12), wood)
	for side in [-0.88, 0.88]:
		_add_stall_box(_merchant_stall, Vector3(side, 1.42, -0.34), Vector3(0.09, 1.55, 0.09), wood)
	var canopy := Node3D.new()
	canopy.name = "Canopy"
	canopy.position = Vector3(0, 2.05, -0.34)
	_merchant_stall.add_child(canopy)
	_add_stall_box(canopy, Vector3(0, 0, 0), Vector3(2.25, 0.08, 1.15), cloth)
	for stripe in range(5):
		_add_stall_box(canopy, Vector3(-0.9 + float(stripe) * 0.45, -0.045, 0.0), Vector3(0.16, 0.012, 1.13), linen)
	for i in range(3):
		var produce := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.14
		sphere.height = 0.28
		produce.mesh = sphere
		produce.material_override = goods if i != 1 else linen
		produce.position = Vector3(-0.55 + float(i) * 0.5, 0.92, 0.02)
		_merchant_stall.add_child(produce)
	var sign := Label3D.new()
	sign.text = "MARKET" if npc_name == "Mira" else "GOODS"
	sign.font_size = 30
	sign.outline_size = 8
	sign.position = Vector3(0, 2.55, -0.93)
	sign.modulate = Color(1.0, 0.88, 0.62)
	_merchant_stall.add_child(sign)
	_update_merchant_stall()

func _stall_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	return material

func _add_stall_box(parent: Node3D, pos: Vector3, dimensions: Vector3, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	mesh_instance.mesh = mesh
	mesh_instance.material_override = material
	mesh_instance.position = pos
	parent.add_child(mesh_instance)

func _update_merchant_stall() -> void:
	if _merchant_stall == null:
		return
	var hour := _hour()
	var should_open := hour >= 7.0 and hour < 18.5 and not asleep
	if should_open == _stall_is_open:
		return
	_stall_is_open = should_open
	_merchant_stall.visible = should_open
	if should_open:
		EventBus.activity.emit("%s opens the market stall" % npc_name, "world")
	else:
		EventBus.activity.emit("%s closes the market stall for the evening" % npc_name, "world")

func set_carrying_goods(duration: float = 16.0) -> void:
	if _cargo_prop != null and is_instance_valid(_cargo_prop):
		_cargo_timer = maxf(_cargo_timer, duration)
		return
	_cargo_prop = Node3D.new()
	_cargo_prop.name = "VisibleTradeCargo"
	var wood := _stall_material(Color(0.34, 0.23, 0.14))
	var crate := MeshInstance3D.new()
	var crate_mesh := BoxMesh.new()
	crate_mesh.size = Vector3(0.38, 0.34, 0.34)
	crate.mesh = crate_mesh
	crate.material_override = wood
	crate.position = Vector3(0.27, 0.98, 0.28)
	_cargo_prop.add_child(crate)
	for slat in range(2):
		var board := MeshInstance3D.new()
		var board_mesh := BoxMesh.new()
		board_mesh.size = Vector3(0.4, 0.045, 0.045)
		board.mesh = board_mesh
		board.material_override = _stall_material(Color(0.52, 0.39, 0.24))
		board.position = Vector3(0.27, 0.89 + float(slat) * 0.18, 0.46)
		_cargo_prop.add_child(board)
	model.add_child(_cargo_prop)
	_cargo_timer = maxf(duration, 2.0)

func _appearance() -> Dictionary:
	match npc_name:
		"Elara":
			return {"asset": "witch", "skin": CharacterModel.SKIN_TONES[0], "hair": Color(0.52, 0.24, 0.12), "hair_style": "long",
				"dress": true, "shirt": Color(0.28, 0.52, 0.38), "boots": Color(0.3, 0.2, 0.12), "scale": 0.95}
		"Borin":
			return {"asset": "dwarf", "skin": CharacterModel.SKIN_TONES[2], "hair": Color(0.32, 0.2, 0.1), "hair_style": "short",
				"beard": "short", "shirt": Color(0.86, 0.8, 0.62), "pants": Color(0.24, 0.34, 0.6),
				"bulk": 1.14, "scale": 1.02}
		"Old Man Thoren":
			return {"asset": "wizard", "skin": CharacterModel.SKIN_TONES[1], "hair": Color(0.92, 0.92, 0.94), "hair_style": "short",
				"beard": "long", "robe": true, "shirt": Color(0.42, 0.32, 0.2), "accent": Color(0.62, 0.5, 0.2),
				"held": "staff", "scale": 0.96}
		"Gorrim the Smith":
			return {"asset": "viking", "skin": CharacterModel.SKIN_TONES[2], "hair": Color(0.15, 0.1, 0.08), "hair_style": "short",
				"beard": "short", "beard_color": Color(0.2, 0.12, 0.08), "shirt": Color(0.40, 0.38, 0.38),
				"pants": Color(0.18, 0.16, 0.16), "boots": Color(0.12, 0.09, 0.07), "bulk": 1.25, "held": "hammer", "scale": 1.05,
				"back_prop": "apron", "prop_cloth": Color(0.3, 0.26, 0.22)}
		"Mira":
			return {"asset": "queen", "skin": CharacterModel.SKIN_TONES[2], "hair": Color(0.08, 0.06, 0.08), "hair_style": "bun",
				"dress": true, "shirt": Color(0.55, 0.25, 0.55), "scale": 0.97,
				"back_prop": "satchel", "accent": Color(0.9, 0.75, 0.3), "prop_color": Color(0.44, 0.28, 0.15)}
		"Archmage Lira":
			return {"asset": "witch", "skin": CharacterModel.SKIN_TONES[0], "hair": Color(0.82, 0.84, 0.92), "hair_style": "long",
				"robe": true, "shirt": Color(0.34, 0.2, 0.58), "accent": Color(0.95, 0.78, 0.3), "hat": "wizard",
				"hat_color": Color(0.26, 0.16, 0.46), "held": "orb_staff", "scale": 1.05}
		"Apprentice Kael":
			return {"asset": "elf", "skin": CharacterModel.SKIN_TONES[3], "hair": Color(0.08, 0.08, 0.1), "hair_style": "wild",
				"robe": true, "shirt": Color(0.2, 0.4, 0.74), "accent": Color(0.82, 0.86, 0.92), "scale": 0.88}
	match role:
		"guard":
			var gh: int = absi(npc_name.hash())
			var shield_face: Color = [Color(0.28, 0.4, 0.72), Color(0.62, 0.28, 0.24),
				Color(0.3, 0.5, 0.34), Color(0.58, 0.44, 0.24)][gh % 4]
			var shield_boss: Color = [Color(0.84, 0.72, 0.36), Color(0.7, 0.72, 0.78),
				Color(0.82, 0.64, 0.4), Color(0.62, 0.64, 0.7)][(gh / 5) % 4]
			return _claim_variant(_make_look(["armored-knight", "viking", "armored-knight"], "guard", "spear",
				{"back_prop": "shield", "accent": shield_boss, "prop_wood": shield_face,
				"bulk": 1.03 + float(gh % 4) * 0.015}))
		"soldier":
			return _claim_variant(_make_look(["armored-knight", "viking"], "soldier", "spear",
				{"back_prop": "shield", "accent": Color(0.6, 0.56, 0.48), "bulk": 1.02}))
		"knight":
			return _claim_variant(_make_look(["armored-knight"], "guard", "sword",
				{"back_prop": "shield", "accent": Color(0.78, 0.68, 0.36), "bulk": 1.12}))
		"ranger":
			return _claim_variant(_make_look(["ninja", "elf"], "ranger", "bow",
				{"back_prop": "quiver", "prop_color": Color(0.32, 0.21, 0.13)}))
		"hunter":
			return _claim_variant(_make_look(["elf", "viking", "ninja"], "hunter", "bow",
				{"back_prop": "quiver", "prop_color": Color(0.38, 0.25, 0.14)}))
		"adventurer":
			return _claim_variant(_make_look(["samurai", "viking", "elf"], "adventurer",
				["sword", "axe"][absi(npc_name.hash() / 7) % 2],
				{"back_prop": "pack", "prop_color": Color(0.4, 0.27, 0.15), "prop_cloth": Color(0.36, 0.33, 0.24)}))
		"mercenary":
			return _claim_variant(_make_look(["viking", "samurai"], "mercenary", "axe",
				{"back_prop": "pack", "prop_color": Color(0.3, 0.2, 0.12)}))
		"swordsman":
			return _claim_variant(_make_look(["samurai", "viking"], "swordsman", "sword",
				{"back_prop": "", "bulk": 1.04}))
		"child":
			return {"asset": "child", "shirt": Color(0.65, 0.52, 0.34), "pants": Color(0.28, 0.32, 0.38), "scale": 0.72}
		"farmer":
			return _claim_variant(_make_look(
				["elf", "viking"] if _looks_female() else ["viking", "dwarf", "elf"], "farmer", "none",
				{"back_prop": "basket", "prop_color": Color(0.5, 0.36, 0.2)}))
		"fisher":
			return _claim_variant(_make_look(["viking", "pirate", "elf"], "fisher", "spear",
				{"back_prop": "basket", "prop_color": Color(0.34, 0.28, 0.2), "prop_cloth": Color(0.4, 0.44, 0.4)}))
		"merchant":
			return _claim_variant(_make_look(["queen"] if _looks_female() else ["pirate", "viking"], "merchant", "none",
				{"back_prop": "satchel", "accent": Color(0.86, 0.7, 0.3), "prop_color": Color(0.44, 0.28, 0.15), "dress": _looks_female()}))
		"smith", "craftsman", "carpenter":
			return _claim_variant(_make_look(["elf"] if _looks_female() else ["dwarf", "viking"], str(role), "hammer",
				{"back_prop": "apron", "prop_cloth": Color(0.32, 0.28, 0.24), "bulk": 1.08}))
		"scholar":
			return _claim_variant(_make_look(["wizard", "elf"], "scholar", "none",
				{"back_prop": "satchel", "prop_color": Color(0.34, 0.26, 0.18)}))
		"herbalist", "healer":
			return _claim_variant(_make_look(["witch", "elf"], str(role), "none",
				{"back_prop": "basket", "prop_color": Color(0.42, 0.34, 0.2), "robe": true}))
		"mage":
			return _claim_variant(_make_look(["wizard", "witch"], "mage", "orb_staff",
				{"robe": true, "accent": Color(0.78, 0.62, 0.28)}))
		"spirit_master":
			return _claim_variant(_make_look(["elf", "witch"], "spirit_master", "orb_staff",
				{"robe": true, "accent": Color(0.62, 0.82, 0.76)}))
		"elder":
			return _claim_variant(_make_look(["queen"] if _looks_female() else ["king", "wizard"], "elder", "staff",
				{"robe": true, "beard": "long", "hair": Color(0.86, 0.86, 0.88), "bulk": 0.98}))
		"sect_master":
			var master_col: Color = SECT_COLORS.get(sect_id, Color(0.72, 0.66, 0.8)).lerp(Color.WHITE, 0.52)
			return _claim_variant(_make_look(["queen"] if _looks_female() else ["king"], "sect_master", "orb_staff",
				{"asset_tint": master_col, "accent": SECT_COLORS.get(sect_id, Color(0.8, 0.72, 0.36)), "scale": 1.1}))
		"sect_disciple":
			var disciple_col: Color = SECT_COLORS.get(sect_id, Color(0.72, 0.66, 0.8)).lerp(Color.WHITE, 0.62)
			return _claim_variant(_make_look(["ninja", "elf"], "sect_disciple",
				"staff" if absi(npc_name.hash()) % 2 == 0 else "none",
				{"asset_tint": disciple_col, "accent": SECT_COLORS.get(sect_id, Color(0.8, 0.72, 0.36))}))
	var villager_assets: Array = ["witch", "queen", "elf"] if _looks_female() else ["viking", "dwarf", "elf"]
	var villager_props: Array = ["", "satchel", "basket"]
	var prop: String = str(villager_props[absi(npc_name.hash() / 13) % villager_props.size()])
	var look: Dictionary = _make_look(villager_assets, "villager", "none",
		{"back_prop": prop, "dress": _looks_female(), "bulk": 0.98 + float(absi(npc_name.hash() / 17) % 5) * 0.02})
	return _claim_variant(look)

func _looks_female() -> bool:
	var lower: String = npc_name.to_lower()
	for title in ["abbess", "grandmother", "lady", "mother", "queen", "mistress", "sister"]:
		if lower.begins_with(title):
			return true
	for name in ["elara", "mira", "lira", "moss", "lian"]:
		if lower.contains(name):
			return true
	return absi(npc_name.hash()) % 100 < 46

func _make_look(assets: Array, tint_role: String, held: String, extra: Dictionary = {}) -> Dictionary:
	var h: int = absi(npc_name.hash())
	var look: Dictionary = {
		"asset": str(assets[h % assets.size()]),
		"held": held,
		"skin": CharacterModel.SKIN_TONES[h % CharacterModel.SKIN_TONES.size()],
		"hair": [Color(0.1, 0.07, 0.05), Color(0.26, 0.16, 0.09), Color(0.5, 0.34, 0.18), Color(0.78, 0.72, 0.6)][(h / 5) % 4],
		"hair_style": ["short", "wild", "long", "bun"][(h / 7) % 4],
		"scale": 0.97 + float((h / 11) % 6) * 0.012,
		"role_tint": tint_role,
	}
	for key in extra:
		look[key] = extra[key]
	return look

## Give every live NPC a dye and build that no same-role NPC already wears. Claims
## are stable for the session, so reloading a settlement does not reshuffle looks.
func _claim_variant(look: Dictionary) -> Dictionary:
	var tint_role: String = str(look.get("role_tint", "villager"))
	var palette: Array = NPC_TINTS.get(tint_role, NPC_TINTS["villager"])
	var variants: int = palette.size() * 3
	var used: Dictionary = _look_claims.get(role, {})
	var start: int = absi(npc_name.hash()) % variants
	var picked: int = -1
	for offset in range(variants):
		var idx: int = (start + offset) % variants
		var key: String = "%s|%d|%s" % [str(look.get("asset", "")), idx, str(look.get("back_prop", ""))]
		if not used.has(key):
			used[key] = npc_name
			picked = idx
			break
	if picked >= 0:
		_look_claims[role] = used
		var dye: Color = palette[picked % palette.size()]
		var base: Color = look.get("asset_tint", Color.WHITE)
		look["asset_tint"] = Color(base.r * dye.r, base.g * dye.g, base.b * dye.b)
		look["scale"] = clampf(float(look.get("scale", 1.0)) * (0.97 + float(picked / palette.size()) * 0.03), 0.9, 1.12)
	else:
		var fallback: Color = palette[start % palette.size()]
		var fallback_base: Color = look.get("asset_tint", Color.WHITE)
		look["asset_tint"] = Color(fallback_base.r * fallback.r, fallback_base.g * fallback.g, fallback_base.b * fallback.b)
	look.erase("role_tint")
	return look

func _add_extras() -> void:
	if npc_name == "Apprentice Kael":
		var float_node := AmbientMotion.new()
		float_node.position = Vector3(0.75, 1.5, -0.25)
		float_node.bob_height = 0.12
		float_node.bob_speed = 1.6
		add_child(float_node)
		var cover := StandardMaterial3D.new()
		cover.albedo_color = Color(0.5, 0.12, 0.18)
		cover.roughness = 0.6
		var pages := StandardMaterial3D.new()
		pages.albedo_color = Color(0.95, 0.92, 0.82)
		for side in [-1.0, 1.0]:
			var c := MeshInstance3D.new()
			var cm := BoxMesh.new()
			cm.size = Vector3(0.17, 0.02, 0.24)
			c.mesh = cm
			c.material_override = cover
			c.position = Vector3(side * 0.09, 0, 0)
			c.rotation.z = side * 0.3
			float_node.add_child(c)
			var p := MeshInstance3D.new()
			var pm := BoxMesh.new()
			pm.size = Vector3(0.15, 0.025, 0.22)
			p.mesh = pm
			p.material_override = pages
			p.position = Vector3(side * 0.09, 0.018, 0)
			p.rotation.z = side * 0.3
			float_node.add_child(p)
		_extra_light = BuildingKit.add_light(float_node, Vector3(0, 0.15, 0), Color(1.0, 0.9, 0.6), 0.5, 3.0, 0.0, true)
	elif npc_name == "Archmage Lira":
		_extra_light = BuildingKit.add_light(self, Vector3(0.45, 1.9, -0.2), Color(0.5, 0.65, 1.0), 1.2, 7.0, 0.0, true)

# ---------------------------------------------------------------------------
# Interaction API (shared "interactable" duck-typing)
# ---------------------------------------------------------------------------
func set_work_pose(pose: String) -> void:
	if model and model.has_method("set_work_pose"):
		model.set_work_pose(pose)

func has_active_delivery() -> bool:
	return not _delivery_state.is_empty()

func start_goods_delivery(target: Vector3, business_id: String, item_id: String, quantity: int, duration: float = 180.0) -> bool:
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return false
	if has_active_delivery() or business_id.is_empty() or item_id.is_empty() or quantity <= 0:
		return false
	_delivery_state = {"business_id": business_id, "item_id": item_id, "quantity": quantity}
	set_carrying_goods(duration)
	_wander_target = target
	_wander_target.y = global_position.y
	will_state = WillState.WANDER
	_will_timer = maxf(duration, 30.0)
	set_work_pose("trade")
	_bubble.text = "Delivering %s" % item_id.replace("_", " ")
	_bubble.visible = true
	_bubble_t = 3.0
	return true

func _complete_goods_delivery() -> void:
	if _delivery_state.is_empty():
		return
	var delivered: Dictionary = _delivery_state.duplicate(true)
	_delivery_state.clear()
	var world_system: Node = get_tree().get_first_node_in_group("living_world")
	if world_system and world_system.has_method("record_business_delivery"):
		world_system.call("record_business_delivery", str(delivered.business_id), str(delivered.item_id), int(delivered.quantity))
	if _cargo_prop and is_instance_valid(_cargo_prop):
		_cargo_prop.queue_free()
	_cargo_prop = null
	_cargo_timer = 0.0
	will_state = WillState.FOLLOW_SCHEDULE
	_will_timer = 5.0
	set_work_pose("trade")
	_bubble.text = "Delivery complete"
	_bubble.visible = true
	_bubble_t = 3.0
	EventBus.activity.emit("%s delivers %d %s to the market" % [npc_name, int(delivered.quantity), str(delivered.item_id).replace("_", " ")], "world")

func set_hunt_target(target: Vector3, duration: float = 5.0) -> void:
	_wander_target = target
	wander_radius = maxf(wander_radius, 34.0)
	will_state = WillState.WANDER
	_will_timer = maxf(duration, 1.0)

func can_interact() -> bool:
	return not asleep

func get_prompt() -> String:
	return "Talk to %s" % npc_name

func interact(player: Node3D = null) -> void:
	if asleep:
		return
	_talking_to = player
	_talk_time = 0.0
	_bubble.visible = false
	EventBus.interaction_started.emit(self)
	if MMORPGNetwork.is_online() and not multiplayer.is_server() and WorldDeploymentGuard.is_production_session():
		MMORPGNetwork.request_validated_interaction(self, "npc_talk")
	PlayerData.notify("talk", npc_name)   # local journal prediction; production progress is recorded by the server
	var dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
	if dialogue == null:
		print("[%s]: %s" % [npc_name, dialogue_lines[0]])
		return
	var status: Dictionary = PlayerData.npc_quest_status(npc_name)
	var qid: String = status["quest"]
	var lines: Array = []
	var choices: Array = []
	match status["kind"]:
		"turn_in":
			lines = QuestDB.QUESTS[qid]["complete"].duplicate()
			choices.append({"id": "claim:" + qid, "text": "Accept reward  (%s)" % GameMenu._reward_text(QuestDB.QUESTS[qid]["rewards"])})
		"offer":
			lines = QuestDB.QUESTS[qid]["offer"].duplicate()
			choices.append({"id": "accept:" + qid, "text": "Accept quest:  %s" % QuestDB.QUESTS[qid]["title"]})
			choices.append({"id": "bye", "text": "Not right now"})
		"progress":
			lines = QuestDB.QUESTS[qid]["progress"].duplicate()
			_add_role_choices(choices)
			choices.append({"id": "bye", "text": "Goodbye"})
		_:
			lines = Array(dialogue_lines)
			_add_role_choices(choices)
			if not choices.is_empty():
				choices.append({"id": "bye", "text": "Goodbye"})
	choices.append({"id": "rumours", "text": "Ask what is happening around the region"})
	choices.append({"id": "personal", "text": "Ask about their life and ambitions"})
	choices.append({"id": "family", "text": "Ask about their family and work"})
	choices.append({"id": "tension", "text": "Ask about local tensions"})
	_add_training_choices(choices)
	_add_cultivation_guidance_choices(choices)
	_add_sect_choices(choices)
	dialogue.start_conversation(npc_name, lines, choices, _on_choice)

func _add_sect_choices(choices: Array) -> void:
	if sect_id == "": return
	if role == "sect_master" or role == "elder":
		choices.append({"id":"sect_exam", "text":"Register for the sect recruitment examination"})
		choices.append({"id":"sect_advance", "text":"Request disciple rank advancement"})
		choices.append({"id":"sect_lesson", "text":"Request a private master lesson"})
		choices.append({"id":"sect_legacy", "text":"Ask about a sealed multi-floor inheritance"})
	elif role == "sect_disciple":
		choices.append({"id":"sect_trial", "text":"Attempt the next recruitment trial"})

func _add_role_choices(choices: Array) -> void:
	if StationPanel.SHOPS.has(npc_name) or not LivingWorldSystem.business_id_for_owner(npc_name).is_empty():
		choices.append({"id": "trade", "text": "Browse wares"})
	if npc_name == "Gorrim the Smith":
		choices.append({"id": "forge", "text": "Use the forge"})
	choices.append({"id": "gift", "text": "Offer a gift"})

func _on_choice(choice_id: String) -> void:
	if choice_id.begins_with("accept:"):
		var accepted_id := choice_id.substr(7)
		if MMORPGNetwork.is_online() and WorldDeploymentGuard.is_production_session():
			if multiplayer.is_server():
				MMORPGNetwork.commit_local_quest_action(self, "quest_accept", accepted_id)
			else:
				MMORPGNetwork.request_validated_interaction(self, "quest_accept", accepted_id)
			return
		PlayerData.accept_quest(accepted_id)
	elif choice_id.begins_with("claim:"):
		var claim_id: String = choice_id.substr(6)
		if MMORPGNetwork.is_online() and WorldDeploymentGuard.is_production_session():
			if multiplayer.is_server():
				MMORPGNetwork.commit_local_quest_action(self, "quest_turn_in", claim_id)
			else:
				MMORPGNetwork.request_validated_interaction(self, "quest_turn_in", claim_id)
			return
		PlayerData.complete_quest(claim_id)
	elif choice_id == "trade":
		if MMORPGNetwork.is_online() and not multiplayer.is_server():
			MMORPGNetwork.request_validated_interaction(self, "shop_open")
			return
		var panel: Node = get_tree().get_first_node_in_group("station_panel")
		if panel:
			panel.open_shop(npc_name)
	elif choice_id == "forge":
		var panel2: Node = get_tree().get_first_node_in_group("station_panel")
		if panel2:
			panel2.open_station("forge")
	elif choice_id == "sect_exam":
		SectSimulation.begin_recruitment(sect_id)
	elif choice_id == "sect_trial":
		var report: Dictionary = PlayerData.stats.get("sect_state", {}).get("exam_progress", {}).get(sect_id, {})
		var stage := int(report.get("stage", 0))
		var trials := SectSimulation.EXAM_TRIALS
		if stage < trials.size():
			var trial := str(trials[stage])
			var passed := false
			var skill_check: Node = GameManager.player.get_node_or_null("SkillSystem") if GameManager.player else null
			var skill_values: Dictionary = skill_check.get("values") if skill_check else {}
			if trial == "insight":
				passed = skill_check != null and (float(skill_values.get("wisdom", 0.0)) >= 1.0 or float(skill_values.get("knowledge", 0.0)) >= 1.0 or float(skill_values.get("ancient_lore", 0.0)) >= 1.0)
			elif trial == "endurance":
				passed = skill_check != null and float(skill_values.get("vitality", 0.0)) >= 1.0
			elif trial == "combat":
				passed = skill_check != null and (float(skill_values.get("swordsmanship", 0.0)) >= 1.0 or float(skill_values.get("elemental_magic", 0.0)) >= 1.0 or int(skill_check.call("cultivation_realm_index")) >= 1)
			elif trial == "formation":
				passed = float(GameManager.player.global_position.distance_to(global_position)) <= 4.0
			if passed: SectSimulation.complete_recruitment_trial(sect_id, trial)
			else: EventBus.toast.emit("You are not ready for this trial. Improve your foundation and return.", "info")
	elif choice_id == "sect_advance":
		SectSimulation.advance_disciple_rank()
	elif choice_id == "sect_lesson":
		SectSimulation.request_master_lesson(sect_id)
	elif choice_id == "sect_legacy":
		AncientInheritanceSystem.start_sect_legacy(sect_id)
	elif choice_id == "cultivation_recognition_trial":
		var path_id: String = _cultivation_path_taught()
		if path_id == "":
			path_id = "body_refinement"
		var method_id: String = "first_method_%s" % path_id
		var evidence: String = "observed:%s;clues:%d;comprehension:%.2f;will:%.2f" % [npc_name, int(CultivationDiscovery.get_report().get("clues_found", 0)), float(CultivationDiscovery.get_report().get("comprehension", 0.0)), float(CultivationDiscovery.get_report().get("willpower", 0.0))]
		if CultivationDiscovery.resolve_recognition_trial(method_id, "Personal instruction from %s" % npc_name, evidence):
			var dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
			if dialogue:
				dialogue.start_conversation(npc_name, ["You have shown understanding, discipline and a resonance worth investigating. I will entrust you with the first method. Guard it; knowledge like this is not common."], [{"id":"bye", "text":"I will study it carefully"}], _on_choice)
	elif choice_id == "gift":
		_receive_gift()
	elif choice_id == "rumours":
		_show_social_response("rumours")
	elif choice_id == "personal":
		_show_social_response("personal")
	elif choice_id == "family":
		var family_lines := CivilizationSocieties.household_story(npc_name, role)
		var household := str(family_profile.get("family", npc_name))
		var life: Dictionary = LivingWorldSystem.get_npc_life(npc_name)
		var partner := str(life.get("partner", ""))
		if partner != "":
			family_lines.append("I share my life with %s." % partner)
		var household_id := str(life.get("household", ""))
		if household_id != "":
			var household_record: Dictionary = LivingWorldSystem.households.get(household_id, {})
			var children: Array = household_record.get("children", [])
			if not children.is_empty(): family_lines.append("Our children: %s." % ", ".join(PackedStringArray(children)))
		family_lines.append(LivingWorldSystem.relationship_line(household))
		var family_dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
		if family_dialogue: family_dialogue.start_conversation(npc_name, family_lines, [{"id":"family_help", "text":"Offer practical help to the household"}, {"id":"bye", "text":"I hope your family prospers"}], _on_choice)
	elif choice_id == "family_help":
		LivingWorldSystem.help_family(str(family_profile.get("family", npc_name)))
	elif choice_id == "tension":
		var c := CivilizationSocieties.culture_for_floor(0)
		var tension_lines: Array[String] = [str(c.conflict), "The market needs stability. A fair agreement would help everyone."]
		var tension_dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
		if tension_dialogue: tension_dialogue.start_conversation(npc_name, tension_lines, [{"id":"mediate", "text":"Help negotiate a peaceful agreement"}, {"id":"back_faction", "text":"Support the local faction"}, {"id":"bye", "text":"Leave it to them"}], _on_choice)
	elif choice_id == "mediate":
		LivingWorldSystem.change_family_bond(str(family_profile.get("family", npc_name)), 3)
		CivilizationSocieties.apply_faction_choice("labyrinth", true)
		var growth := get_tree().get_first_node_in_group("settlement_growth")
		if growth: growth.add_progress("elyndor", 8.0, "community mediation")
		EventBus.toast.emit("You helped ease tensions in the settlement", "success")
	elif choice_id == "back_faction":
		CivilizationSocieties.apply_faction_choice("labyrinth", false)
		EventBus.toast.emit("Your support changed the local balance of power", "info")
	elif choice_id.begins_with("learn:"):
		_learn_technique(choice_id.substr(6))
	elif choice_id.begins_with("cultivate:"):
		_learn_cultivation_path(choice_id.substr(9))

# ---------------------------------------------------------------------------
# Quest marker
# ---------------------------------------------------------------------------
func _update_marker() -> void:
	if _marker == null:
		return
	var st: Dictionary = PlayerData.npc_quest_status(npc_name)
	match st["kind"]:
		"offer":
			_marker.text = "!"
			_marker.modulate = Color(1.0, 0.85, 0.25)
			_marker.visible = not asleep
		"turn_in":
			_marker.text = "?"
			_marker.modulate = Color(1.0, 0.85, 0.25)
			_marker.visible = not asleep
		"progress":
			_marker.text = "?"
			_marker.modulate = Color(0.6, 0.62, 0.7)
			_marker.visible = not asleep
		_:
			_marker.visible = false

# ---------------------------------------------------------------------------
# Daily routine
# ---------------------------------------------------------------------------
func _hour() -> float:
	if _day_node == null:
		_day_node = get_tree().get_first_node_in_group("day_night")
	if _day_node:
		return float(_day_node.time_of_day) * 24.0
	return 10.0

func _current_entry() -> Dictionary:
	if schedule.is_empty():
		return {}
	var h: float = _hour()
	var best: Dictionary = schedule[schedule.size() - 1]   # wraps from the previous day
	for e in schedule:
		if float(e["h"]) <= h:
			best = e
	return best

func _snap_to_schedule() -> void:
	var e: Dictionary = _current_entry()
	if e.is_empty():
		return
	var p: Vector2 = e["pos"]
	global_position = Vector3(p.x, global_position.y, p.y)
	if bool(e.get("sleep", false)):
		_set_asleep(true)

func _set_asleep(v: bool) -> void:
	asleep = v
	model.visible = not v
	name_label.visible = not v
	_bubble.visible = false
	if _extra_light:
		_extra_light.visible = not v
	for c in get_children():
		if c is CollisionShape3D:
			(c as CollisionShape3D).set_deferred("disabled", v)
	_update_marker()

func _process(delta: float) -> void:
	# Names are a conversation aid, not a permanent floating caption. Fading them
	# out at range keeps busy village and wilderness shots legible.
	if name_label and not asleep:
		var viewer: Node3D = GameManager.player
		if viewer:
			var view_dist: float = global_position.distance_to(viewer.global_position)
			var name_fade: float = clampf((30.0 - view_dist) / 12.0, 0.0, 1.0)
			name_fade *= name_fade
			name_label.modulate.a = name_fade
			name_label.visible = name_fade > 0.02
	if _talking_to and is_instance_valid(_talking_to):
		_talk_time += delta
		var d: Vector3 = _talking_to.global_position - global_position
		rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), clampf(delta * 6.0, 0.0, 1.0))
		if _talk_time > 20.0:
			_talking_to = null
	if _cargo_prop != null:
		_cargo_timer -= delta
		if _cargo_timer <= 0.0:
			_cargo_prop.queue_free()
			_cargo_prop = null
	if _merchant_stall != null:
		_stall_state_clock -= delta
		if _stall_state_clock <= 0.0:
			_stall_state_clock = 2.0
			_update_merchant_stall()
	if _marker and _marker.visible:
		_marker.position.y = name_label.position.y + 0.5 + sin(Time.get_ticks_msec() * 0.004) * 0.06
	# idle chatter
	if _bubble_t > 0.0:
		_bubble_t -= delta
		if _bubble_t <= 0.0:
			_bubble.visible = false
	if not asleep and _talking_to == null:
		_bark_timer -= delta
		_combat_cd = maxf(_combat_cd - delta, 0.0)
		if _combat_cd <= 0.0 and not asleep and _talking_to == null:
			_check_combat_nearby()
		if _bark_timer <= 0.0:
			_bark_timer = randf_range(25.0, 55.0)
			var p: Node3D = GameManager.player
			if p and BARKS.has(npc_name) and global_position.distance_to(p.global_position) < 14.0:
				var lines: Array = BARKS[npc_name]
				_bubble.text = lines[randi() % lines.size()]
				_bubble.visible = true
				_bubble_t = 4.5

func _physics_process(delta: float) -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		return
	if health and health.is_dead:
		velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
	_check_t -= delta
	var e: Dictionary = _current_entry()
	if asleep:
		velocity = Vector3.ZERO
		if _check_t <= 0.0:
			_check_t = 1.0
			if not e.is_empty() and not bool(e.get("sleep", false)):
				_set_asleep(false)
		return
	if _talking_to != null and is_instance_valid(_talking_to):
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		model.set_motion(0.0)
		return
	_talking_to = null
	if _process_local_combat(delta):
		move_and_slide()
		model.set_motion(1.0 if Vector2(velocity.x, velocity.z).length() > 0.2 else 0.0)
		return
	if _life_journey_active:
		var journey_delta: Vector3 = _life_journey_target - global_position
		journey_delta.y = 0.0
		if journey_delta.length() > 1.25:
			var journey_direction := journey_delta.normalized()
			velocity.x = journey_direction.x * WALK_SPEED * 1.25
			velocity.z = journey_direction.z * WALK_SPEED * 1.25
			rotation.y = lerp_angle(rotation.y, atan2(-journey_direction.x, -journey_direction.z), clampf(delta * 8.0, 0.0, 1.0))
			move_and_slide()
			model.set_motion(1.0)
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			move_and_slide()
			model.set_motion(0.0)
			if _life_journey_returning or _life_journey_mode == "migration":
				_life_journey_active = false
				_life_journey_returning = false
				home_center = _life_journey_target
				if _life_journey_mode == "migration":
					LivingWorldSystem.complete_npc_migration(npc_name)
		return
	var moving: bool = false
	# Free will can override pure schedule walking when not sleeping
	_will_timer -= delta
	if free_will and not asleep and not e.is_empty() and not bool(e.get("sleep", false)):
		_update_will(delta, e)
		if will_state != WillState.FOLLOW_SCHEDULE:
			moving = _drive_will(delta)
			move_and_slide()
			model.set_motion(1.0 if moving else 0.0)
			return
	if not e.is_empty():
		var tgt: Vector2 = e["pos"]
		var to := Vector2(tgt.x - global_position.x, tgt.y - global_position.z)
		var dist: float = to.length()
		if dist > 0.7:
			var dir := Vector3(to.x, 0, to.y).normalized()
			velocity.x = dir.x * WALK_SPEED
			velocity.z = dir.z * WALK_SPEED
			rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), clampf(delta * 8.0, 0.0, 1.0))
			moving = true
			# stuck detection: if we barely moved for a while, just arrive (avoids NPCs jammed on props)
			if _check_t <= 0.0:
				_check_t = 1.2
				if global_position.distance_to(_last_pos) < 0.25:
					_stuck_t += 1.0
				else:
					_stuck_t = 0.0
				_last_pos = global_position
				if _stuck_t >= 3.0:
					global_position = Vector3(tgt.x, global_position.y + 0.1, tgt.y)
					_stuck_t = 0.0
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			if bool(e.get("sleep", false)):
				_set_asleep(true)
			elif has_look_target:
				var d2 := Vector2(look_target.x - global_position.x, look_target.y - global_position.z)
				if d2.length() > 0.1:
					rotation.y = lerp_angle(rotation.y, atan2(-d2.x, -d2.y), clampf(delta * 4.0, 0.0, 1.0))
	move_and_slide()
	model.set_motion(1.0 if moving else 0.0)




# Teachers share knowledge only when the character has enough practical
# experience to understand the lesson. Finding the teacher reveals knowledge;
# actual combat practice is still required to develop reliable execution.
func _teacher_techniques() -> Array[String]:
	match npc_name:
		"Old Man Thoren": return ["cleave", "heavy_strike", "eclipse_counter"]
		"Gorrim the Smith": return ["heavy_strike", "dragon_piercer"]
		"Archmage Lira": return ["arcane_burst", "starfall_burst"]
		"Apprentice Kael": return ["arcane_burst", "void_step"]
	match role:
		"hunter", "ranger": return ["piercing_shot"]
		"guard", "soldier": return ["riposte"]
		"swordsman", "swordmaster": return ["cleave", "heavy_strike", "eclipse_counter"]
		"mage", "scholar": return ["arcane_burst", "starfall_burst"]
		"spear_master": return ["piercing_thrust", "dragon_piercer"]
		"shadow_master", "assassin": return ["shadow_flurry", "void_step"]
		"spirit_master": return ["starfall_burst"]
	return []

func _add_training_choices(choices: Array) -> void:
	var player := GameManager.player
	if player == null or player.skills == null:
		return
	for technique_id in _teacher_techniques():
		if player.skills.has_discovered_technique(technique_id):
			continue
		var req: Dictionary = SkillSystem.TECHNIQUE_REQUIREMENTS.get(technique_id, {})
		var skill_id: String = str(req.get("skill", ""))
		var required: float = float(req.get("minimum", 0.0))
		var secondary_skill: String = str(req.get("secondary_skill", ""))
		var secondary_required: float = float(req.get("secondary_minimum", 0.0))
		var meets_secondary: bool = secondary_skill == "" or player.skills.get_value(secondary_skill) >= secondary_required
		if player.skills.get_value(skill_id) >= required and meets_secondary:
			var title: String = str(SkillSystem.TECHNIQUE_NAMES.get(technique_id, technique_id.capitalize()))
			var rare_prefix: String = "Rare lesson: " if bool(req.get("rare", false)) else ""
			choices.append({"id": "learn:" + technique_id, "text": "Ask %s to teach you %s%s" % [npc_name, rare_prefix, title]})

func _cultivation_path_taught() -> String:
	match npc_name:
		"Old Man Thoren": return "body_refinement" if GameManager.player and GameManager.player.skills.get_value("vitality") >= GameManager.player.skills.get_value("swordsmanship") else "sword_intent"
		"Gorrim the Smith": return "sword_intent"
		"Archmage Lira": return "elemental_core"
		"Apprentice Kael": return "shadow_step"
		"Sera the Herbalist": return "nature_harmony"
		"Junn the Fisher": return "flowing_water"
		"Master Ren": return "sword_intent"
		"Vein Reader Yun": return "spirit_sense"
	match role:
		"mage", "scholar": return "elemental_core"
		"elder": return "body_refinement"
		"hunter", "ranger": return "nature_harmony"
		"swordmaster": return "sword_intent"
		"spirit_master": return "spirit_sense"
	return ""

func _add_cultivation_guidance_choices(choices: Array) -> void:
	var player: Node3D = GameManager.player
	if player == null or player.get("skills") == null:
		return
	if not CultivationDiscovery.is_cultivation_unlocked():
		var discovery_report: Dictionary = CultivationDiscovery.get_report()
		var can_recognise: bool = role in ["sect_master", "elder", "scholar", "spirit_master", "mage"] or npc_name in ["Master Ren", "Vein Reader Yun", "Old Man Thoren", "Archmage Lira"]
		if can_recognise and bool(discovery_report.get("recognition_unlocked", false)):
			var trial: Dictionary = CultivationDiscovery.begin_recognition_trial()
			if bool(trial.get("available", false)):
				choices.append({"id":"cultivation_recognition_trial", "text":"Ask %s to test your understanding and resolve" % npc_name})
		return
	var path_id: String = _cultivation_path_taught()
	if path_id == "" or not SkillSystem.CULTIVATION_PATHS.has(path_id):
		return
	if player.skills.cultivation_path_progress(path_id) < 0.35:
		return
	if str(player.skills.cultivation_state.get("active_path", "")) == path_id:
		return
	var path_name: String = str(SkillSystem.CULTIVATION_PATHS[path_id].get("name", path_id))
	choices.append({"id":"cultivate:" + path_id, "text":"Ask %s to guide you in %s" % [npc_name, path_name]})

func _learn_cultivation_path(path_id: String) -> void:
	var player: Node3D = GameManager.player
	if player == null or player.get("skills") == null or path_id != _cultivation_path_taught():
		return
	if player.skills.cultivation_path_progress(path_id) < 0.35:
		EventBus.toast.emit("Build more practical experience before committing to this path", "warning")
		return
	if player.skills.set_active_cultivation_path(path_id):
		var path_name: String = player.skills.active_cultivation_path_name()
		player.skills.train("cultivation", 0.18, true)
		player.skills.train("knowledge", 0.12, true)
		var dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
		if dialogue:
			dialogue.start_conversation(npc_name, ["Do not mistake a path for a chain. It is a method of understanding the world.", "You have the experience to begin following %s. Keep practising its disciplines and let the path deepen naturally." % path_name], [{"id":"bye", "text":"I will continue my training"}], _on_choice)
		EventBus.toast.emit("Cultivation path adopted: %s" % path_name, "levelup")
		EventBus.activity.emit("Received cultivation guidance from %s: %s" % [npc_name, path_name], "cultivation")

func on_server_interaction_validated(action: String, detail_id: String = "") -> void:
	match action:
		"quest_accept":
			if QuestDB.QUESTS.has(detail_id) and str(QuestDB.QUESTS[detail_id].get("giver", "")) == npc_name:
				if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
					PlayerData.mark_quest_accepted_authoritatively(detail_id)
				else:
					PlayerData.accept_quest(detail_id)
		"quest_turn_in":
			if not QuestDB.QUESTS.has(detail_id):
				return
			var quest_record: Dictionary = QuestDB.QUESTS.get(detail_id, {})
			if str(quest_record.get("turn_in", "")) != npc_name:
				EventBus.toast.emit("The quest cannot be turned in here.", "warning")
				return
			if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
				PlayerData.mark_quest_completed_authoritatively(detail_id)
			elif PlayerData.is_ready(detail_id):
				PlayerData.complete_quest(detail_id)
			else:
				EventBus.toast.emit("The quest is not ready to turn in here.", "warning")
		"shop_open":
			if not StationPanel.SHOPS.has(npc_name) and LivingWorldSystem.business_id_for_owner(npc_name).is_empty():
				return
			var panel: Node = get_tree().get_first_node_in_group("station_panel")
			if panel:
				panel.open_shop(npc_name)

func _learn_technique(technique_id: String) -> void:
	var player := GameManager.player
	if player == null or player.skills == null:
		return
	if technique_id not in _teacher_techniques():
		return
	var req: Dictionary = SkillSystem.TECHNIQUE_REQUIREMENTS.get(technique_id, {})
	var skill_id: String = str(req.get("skill", ""))
	var required: float = float(req.get("minimum", 0.0))
	var secondary_skill: String = str(req.get("secondary_skill", ""))
	var secondary_required: float = float(req.get("secondary_minimum", 0.0))
	if player.skills.get_value(skill_id) < required or (secondary_skill != "" and player.skills.get_value(secondary_skill) < secondary_required):
		EventBus.toast.emit("You need more practical experience in both disciplines before this lesson makes sense", "warning")
		return
	var description: String = str(req.get("description", "Study the technique carefully."))
	var lines: Array = ["A technique is not a gift. It is knowledge earned through attention and practice.", description, "I can show you the principles. Your hands must learn the rest through real use."]
	if player.skills.discover_technique(technique_id, "taught by " + npc_name):
		var dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
		if dialogue:
			dialogue.start_conversation(npc_name, lines, [{"id":"bye", "text":"I will practise what you have taught me"}], _on_choice)

func _show_social_response(kind: String) -> void:
	var society: Node = get_tree().get_first_node_in_group("world_society")
	var rep: Node = get_tree().get_first_node_in_group("reputation")
	var affinity: int = int(rep.get_affinity(npc_name)) if rep and rep.has_method("get_affinity") else 0
	var lines: Array[String] = []
	if society:
		if kind == "rumours" and society.has_method("get_npc_rumour"):
			var region_id: String = WorldLifeSimulation.region_id_at(global_position.x, global_position.z)
			lines = society.get_npc_rumour(npc_name, role, affinity, region_id)
		elif kind == "personal" and society.has_method("get_personal_story"):
			lines = society.get_personal_story(npc_name, role, affinity)
	if lines.is_empty():
		lines = ["There is always something happening somewhere in the region."]
	if rep and rep.has_method("add_affinity"):
		rep.add_affinity(npc_name, 1)
	var dialogue: Node = get_tree().get_first_node_in_group("dialogue_box")
	if dialogue:
		dialogue.start_conversation(npc_name, lines, [{"id": "bye", "text": "I'll keep that in mind"}], _on_choice)

func _receive_gift() -> void:
	# Give first non-empty bag material/consumable that is not unique gear
	for i in range(PlayerData.slots.size()):
		var s: Dictionary = PlayerData.slots[i]
		if s.is_empty():
			continue
		var iid: String = str(s.get("id", ""))
		var t: String = str(ItemDB.def(iid).get("type", ""))
		if t not in ["material", "consumable"]:
			continue
		if not PlayerData.remove_item(iid, 1):
			continue
		var nm: String = str(ItemDB.def(iid).get("name", iid))
		EventBus.toast.emit("%s accepts your %s" % [npc_name, nm], "info")
		EventBus.activity.emit("Gifted %s to %s" % [nm, npc_name], "social")
		PlayerData.notify("gift", npc_name, 1)
		var rep = get_tree().get_first_node_in_group("reputation")
		if rep:
			rep.add_affinity(npc_name, 5)
			if npc_name in ["Elara", "Old Man Thoren", "Gorrim the Smith"]:
				rep.add_rep("elyndor", 1)
			elif "Lira" in npc_name or "Kael" in npc_name:
				rep.add_rep("arcane_spire", 1)
		if _bubble:
			_bubble.text = "Thank you."
			_bubble.visible = true
			_bubble_t = 3.0
		return
	EventBus.toast.emit("Nothing suitable to gift", "warning")


func apply_life_record(record: Dictionary) -> void:
	if not bool(record.get("alive", true)):
		queue_free()
		return
	var life_state := str(record.get("location_state", "home"))
	if bool(record.get("mobile", false)):
		var saved_home: Array = record.get("home", [])
		if saved_home.size() >= 3:
			home_center = Vector3(float(saved_home[0]), float(saved_home[1]), float(saved_home[2]))
		if MMORPGNetwork.is_authority() and not _life_journey_active:
			if life_state == "on_expedition":
				var expedition_id := str(record.get("expedition_id", ""))
				var expedition: Dictionary = LivingWorldSystem.expeditions.get(expedition_id, {})
				if not expedition.is_empty():
					var destination := str(expedition.get("destination", ""))
					var target: Vector3 = WorldLifeSimulation.get_safe_region_location(destination)
					if target == Vector3.ZERO:
						target = WorldLifeSimulation.get_region_center(destination)
					begin_expedition_journey(target)
			elif life_state == "migrating" and saved_home.size() >= 3:
				begin_migration_journey(home_center)
			elif life_state == "home" and saved_home.size() >= 3:
				var saved_region := str(record.get("region_id", ""))
				var current_region := WorldLifeSimulation.region_id_at(global_position.x, global_position.z)
				if not saved_region.is_empty() and current_region != saved_region:
					var spread := absi(npc_name.hash())
					global_position = home_center + Vector3(float(spread % 7) - 3.0, 0.0, float((spread >> 3) % 7) - 3.0)
	var next_role := str(record.get("role", role))
	var next_child := int(record.get("age_days", 0)) < 18 * 365
	if next_child:
		next_role = "child"
	var changed := next_role != role or next_child != _is_child
	role = next_role
	_is_child = next_child
	combat_profession = role in NPC_DEFENCE_ROLES and not _is_child
	if changed and model:
		family_profile = CivilizationSocieties.family_profile(npc_name, role)
		var look: Dictionary = _appearance()
		if _is_child:
			look["scale"] = lerpf(0.62, 0.88, clampf(float(record.get("age_days", 0)) / float(18 * 365), 0.0, 1.0))
		model.build(look)
		_height_scale = float(look.get("scale", 1.0))
		model.scale = Vector3.ONE * _height_scale
		name_label.position.y = 2.15 * _height_scale + (0.25 if look.get("hat", "none") == "wizard" else 0.0)
		if role == "merchant" and _merchant_stall == null:
			_build_merchant_stall()
		elif role != "merchant" and _merchant_stall != null:
			_merchant_stall.queue_free()
			_merchant_stall = null
	elif _is_child and model:
		var grown_scale := lerpf(0.62, 0.88, clampf(float(record.get("age_days", 0)) / float(18 * 365), 0.0, 1.0))
		if absf(grown_scale - _height_scale) >= 0.005:
			_height_scale = grown_scale
			model.scale = Vector3.ONE * _height_scale
			if name_label:
				name_label.position.y = 2.15 * _height_scale

func begin_expedition_journey(target: Vector3) -> void:
	_life_journey_active = true
	_life_journey_target = target
	_life_journey_returning = false
	_life_journey_mode = "expedition"
	asleep = false
	_set_asleep(false)
	will_state = WillState.FOLLOW_SCHEDULE
	_bubble.text = "Setting out on an expedition"
	_bubble.visible = true
	_bubble_t = 4.0

func return_from_expedition_journey(home_position: Vector3) -> void:
	_life_journey_active = true
	_life_journey_target = home_position
	_life_journey_returning = true
	_life_journey_mode = "expedition"
	_bubble.text = "Returning home"
	_bubble.visible = true
	_bubble_t = 3.0

func begin_migration_journey(destination: Vector3) -> void:
	_life_journey_active = true
	_life_journey_target = destination
	_life_journey_returning = false
	_life_journey_mode = "migration"
	will_state = WillState.FOLLOW_SCHEDULE

func apply_network_role(next_role: String) -> void:
	if next_role == role: return
	role = next_role
	combat_profession = role in NPC_DEFENCE_ROLES
	if model:
		model.build(_appearance())

func take_damage(amount: float, source: Node = null) -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server(): return
	if health == null or health.is_dead or _is_child: return
	health.take_damage(amount, source)
	if source is Node3D:
		_combat_experience += 1
		if _combat_experience >= 3 and not combat_profession and health.current_health > 24.0 and not _is_child:
			role = "adventurer"
			combat_profession = true
			model.build(_appearance())
			var life: Dictionary = LivingWorldSystem.get_npc_life(npc_name)
			life["role"] = role
			life["profession_chosen"] = true
			life["work_experience"] = float(life.get("work_experience", 0.0)) + 1.0
			LivingWorldSystem.npc_lives[npc_name] = life
			LivingWorldSystem._save_state()
			EventBus.activity.emit("%s has begun training as an adventurer after surviving attacks" % npc_name, "world")
		_combat_target = source as Node3D
		_combat_flee_timer = 2.0
		if not combat_profession:
			will_state = WillState.FLEE
			_will_timer = 3.0
		if _bubble:
			_bubble.text = "Help!" if not combat_profession else "Stand your ground!"
			_bubble.visible = true
			_bubble_t = 2.5

func _on_npc_died(_source: Node) -> void:
	if health and health.is_dead:
		velocity = Vector3.ZERO
		will_state = WillState.REST
		model.set_motion(0.0)
		if _bubble:
			_bubble.visible = false
		EventBus.activity.emit("%s has fallen defending the settlement" % npc_name, "world")
		if LivingWorldSystem.has_method("record_npc_casualty"):
			LivingWorldSystem.record_npc_casualty(npc_name, "combat")

func _process_local_combat(delta: float) -> bool:
	if health == null or health.is_dead or _is_child: return false
	_combat_attack_timer = maxf(_combat_attack_timer - delta, 0.0)
	_combat_flee_timer = maxf(_combat_flee_timer - delta, 0.0)
	var nearest: Node3D = null
	var nearest_distance := 12.0 if combat_profession else 8.0
	for hostile in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(hostile) or not hostile is Node3D: continue
		if hostile.has_method("get") and str(hostile.get("state")) == "DEAD": continue
		var distance := global_position.distance_to((hostile as Node3D).global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest = hostile as Node3D
	if nearest == null:
		_combat_target = null
		return false
	_combat_target = nearest
	if not combat_profession:
		will_state = WillState.FLEE
		_will_timer = 2.5
		return false
	var direction := nearest.global_position - global_position
	direction.y = 0.0
	if direction.length() > 2.2:
		var move_dir := direction.normalized()
		velocity.x = move_dir.x * WALK_SPEED * 1.25
		velocity.z = move_dir.z * WALK_SPEED * 1.25
	else:
		velocity.x = 0.0
		velocity.z = 0.0
		if _combat_attack_timer <= 0.0 and nearest.has_method("take_damage"):
			_combat_attack_timer = 1.45
			nearest.call("take_damage", 7.0 + minf(float(_combat_experience), 8.0), self)
			_combat_experience += 1
			if _combat_experience >= 3 and role not in ["guard", "soldier", "ranger"]:
				role = "adventurer"
				combat_profession = true
				if health: health.max_health = 125.0
				EventBus.activity.emit("%s has taken up the adventurer's life after defending the settlement" % npc_name, "world")
	rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), clampf(delta * 8.0, 0.0, 1.0))
	return true

func _check_combat_nearby() -> void:
	var p: Node3D = GameManager.player
	if p == null:
		return
	if global_position.distance_to(p.global_position) > 16.0:
		return
	for e in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(e) or not (e is Node3D):
			continue
		if global_position.distance_to(e.global_position) < 12.0:
			_combat_cd = 14.0
			if _bubble:
				_bubble.text = ["Stay back!", "By the roots—!", "Careful!", "Monsters!"][randi() % 4]
				_bubble.visible = true
				_bubble_t = 3.5
			return


func _update_will(_delta: float, entry: Dictionary) -> void:
	# Flee from nearby enemies always, including while carrying a delivery.
	for en in get_tree().get_nodes_in_group("enemy"):
		if en is Node3D and global_position.distance_to(en.global_position) < 10.0:
			will_state = WillState.FLEE
			_will_timer = 3.0
			return
	# A committed delivery is a job, not a random wander impulse. Keep its
	# destination active if navigation takes longer than the initial estimate.
	if has_active_delivery():
		will_state = WillState.WANDER
		_will_timer = 30.0
		return
	if _will_timer > 0.0 and will_state != WillState.FOLLOW_SCHEDULE:
		return
	# Pick a new impulse
	_will_timer = randf_range(4.0, 12.0)
	var roll: float = randf()
	if roll < 0.35:
		will_state = WillState.WANDER
		var ang: float = randf() * TAU
		var rad: float = randf_range(3.0, wander_radius)
		var c: Vector3 = home_center if home_center != Vector3.ZERO else global_position
		_wander_target = c + Vector3(cos(ang) * rad, 0, sin(ang) * rad)
		_wander_target.y = global_position.y
	elif roll < 0.55:
		will_state = WillState.SOCIAL
		_wander_target = global_position
		var best: Node3D = null
		var best_d: float = 22.0
		for n in get_tree().get_nodes_in_group("npc"):
			if n == self or not (n is Node3D):
				continue
			var d: float = global_position.distance_to(n.global_position)
			if d < best_d and d > 1.0:
				best_d = d
				best = n
		if best:
			_wander_target = best.global_position
		else:
			will_state = WillState.WANDER
	elif roll < 0.7:
		will_state = WillState.REST
		_will_timer = randf_range(3.0, 7.0)
	else:
		will_state = WillState.FOLLOW_SCHEDULE

func _drive_will(delta: float) -> bool:
	match will_state:
		WillState.REST:
			velocity.x = 0.0
			velocity.z = 0.0
			return false
		WillState.FLEE:
			var away: Vector3 = Vector3.ZERO
			for en in get_tree().get_nodes_in_group("enemy"):
				if en is Node3D:
					var d: Vector3 = global_position - en.global_position
					d.y = 0.0
					if d.length() < 14.0 and d.length() > 0.01:
						away += d.normalized()
			if away.length() < 0.01:
				will_state = WillState.FOLLOW_SCHEDULE
				return false
			away = away.normalized()
			velocity.x = away.x * WALK_SPEED * 1.35
			velocity.z = away.z * WALK_SPEED * 1.35
			rotation.y = lerp_angle(rotation.y, atan2(-away.x, -away.z), clampf(delta * 8.0, 0.0, 1.0))
			return true
		WillState.WANDER, WillState.SOCIAL:
			var to: Vector3 = _wander_target - global_position
			to.y = 0.0
			if to.length() < 1.0:
				if has_active_delivery():
					_complete_goods_delivery()
					velocity.x = 0.0
					velocity.z = 0.0
					return false
				if will_state == WillState.SOCIAL and _bubble and randf() < 0.3:
					_bubble.text = ["Good day.", "How are the fields?", "Stay safe."][randi() % 3]
					_bubble.visible = true
					_bubble_t = 2.5
				will_state = WillState.FOLLOW_SCHEDULE
				_will_timer = randf_range(2.0, 5.0)
				velocity.x = 0.0
				velocity.z = 0.0
				return false
			var dir: Vector3 = to.normalized()
			velocity.x = dir.x * WALK_SPEED * (0.85 if will_state == WillState.WANDER else 1.0)
			velocity.z = dir.z * WALK_SPEED * (0.85 if will_state == WillState.WANDER else 1.0)
			rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), clampf(delta * 8.0, 0.0, 1.0))
			return true
		_:
			return false
