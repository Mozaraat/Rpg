# Readable environmental story fragment for each distinct underground civilization.
extends Area3D

var _read: bool = false

func can_interact() -> bool:
	return not _read

func get_prompt() -> String:
	return "Read the civilization memory" if not _read else "Memory already preserved"

func interact(player: Node3D = null) -> void:
	if _read:
		return
	_read = true
	var floor_i: int = int(get_meta("floor", 0))
	var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
	var record: String = "The inscription has weathered beyond recognition."
	var culture: String = "Forgotten Civilization"
	if dungeon and dungeon.has_method("get_floor_story"):
		var story_value: Variant = dungeon.call("get_floor_story", floor_i)
		if story_value is Dictionary:
			var story: Dictionary = story_value
			record = str(story.get("record", record))
			culture = str(story.get("culture", culture))
	EventBus.toast.emit("MEMORY ECHO — %s" % record, "info")
	EventBus.activity.emit("Preserved a memory from %s" % culture, "exploration")
	if player != null and is_instance_valid(player):
		var skill_value: Variant = player.get("skills")
		if skill_value is SkillSystem:
			var skill_system: SkillSystem = skill_value as SkillSystem
			skill_system.train("ancient_lore", 0.85)
			skill_system.train("archaeology", 0.55)
			skill_system.train("knowledge", 0.45)
			skill_system.train("spiritual_sense", 0.22)
			CultivationDiscovery.record_clue("memory_%d" % floor_i, culture, record)
			if CultivationDiscovery.is_cultivation_unlocked():
				skill_system.refresh_meridian_unlocks()
				skill_system.refresh_cultivation_techniques()
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.call("mark_discovery", floor_i, "memory")
	monitoring = false
	visible = false
