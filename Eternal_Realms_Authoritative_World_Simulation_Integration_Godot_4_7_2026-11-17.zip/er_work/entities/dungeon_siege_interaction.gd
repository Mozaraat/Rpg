extends Area3D
## Player command point for initiating and directing a fortress siege.
var director_path: NodePath = NodePath("..")
var faction_name := "Forgotten Faction"
func _ready() -> void:
	collision_layer = Constants.LAYER_WORLD
	collision_mask = 0
	monitoring = true
func can_interact() -> bool:
	return true
func get_prompt() -> String:
	var director := get_node_or_null(director_path)
	if director and director.has_method("get_order_prompt"):
		return "%s · %s" % [director.get_order_prompt(), faction_name]
	return "Command siege against %s" % faction_name
func interact(_player: Node3D = null) -> void:
	var director := get_node_or_null(director_path)
	if director and director.has_method("issue_player_order"):
		director.issue_player_order()
