# CreatureAsset - high-detail scanned creature body for non-humanoid monsters.
# The scans are static meshes, so locomotion is layered on as a gait cycle on a
# pivot (bob, pitch, bank, undulation) while the monster steers the root.
class_name CreatureAsset
extends Node3D

const ASSET_DIR := "res://assets/creatures/"

var _pivot: Node3D
var _t: float = 0.0
var _gait: String = "quadruped"
var _base_y: float = 0.0
var _base_yaw: float = 0.0
var _move: float = 0.0
var _height: float = 1.0
var _flap: float = 0.0

func build(slug: String, opts: Dictionary = {}) -> bool:
	var path := ASSET_DIR + slug + ".glb"
	if not ResourceLoader.exists(path):
		return false
	var packed := load(path) as PackedScene
	if packed == null:
		return false
	var inst := packed.instantiate() as Node3D
	if inst == null:
		return false
	var meshes := inst.find_children("*", "MeshInstance3D", true, false)
	var box := AABB()
	var first := true
	for m in meshes:
		var mi := m as MeshInstance3D
		if mi.mesh == null:
			continue
		var b: AABB = _rel_transform(mi, inst) * mi.mesh.get_aabb()
		box = b if first else box.merge(b)
		first = false
	if first:
		inst.free()
		return false
	var target: float = maxf(float(opts.get("size", opts.get("height", 1.0))), 0.05)
	var norm: String = str(opts.get("norm", "height"))
	var base_dim: float = box.size.y
	if norm == "span":
		base_dim = maxf(box.size.x, box.size.z)
	elif norm == "max":
		base_dim = maxf(box.size.x, maxf(box.size.y, box.size.z))
	elif norm == "length":
		base_dim = box.size.z
	var s: float = target / maxf(base_dim, 0.001)
	var target_h: float = box.size.y * s
	inst.scale = Vector3.ONE * s
	inst.position = Vector3(-(box.position.x + box.size.x * 0.5) * s, -box.position.y * s, -(box.position.z + box.size.z * 0.5) * s)
	_base_yaw = float(opts.get("yaw", PI))
	_pivot = Node3D.new()
	_pivot.name = "Gait"
	_pivot.rotation.y = _base_yaw
	add_child(_pivot)
	_pivot.add_child(inst)
	var tint: Color = opts.get("tint", Color.WHITE)
	var rough: float = float(opts.get("roughness", -1.0))
	var metal: float = float(opts.get("metallic", -1.0))
	var glow: Color = opts.get("glow", Color(0, 0, 0))
	var glow_energy: float = float(opts.get("glow_energy", 0.0))
	for m in meshes:
		var mi := m as MeshInstance3D
		if mi.mesh == null:
			continue
		for surf in range(mi.mesh.get_surface_count()):
			var base := mi.get_active_material(surf)
			if base is StandardMaterial3D:
				var copy := (base as StandardMaterial3D).duplicate() as StandardMaterial3D
				mi.set_surface_override_material(surf, copy)
				copy.albedo_color = Color(copy.albedo_color.r * tint.r, copy.albedo_color.g * tint.g, copy.albedo_color.b * tint.b, copy.albedo_color.a)
				if rough >= 0.0:
					copy.roughness = rough
				if metal >= 0.0:
					copy.metallic = metal
				if glow_energy > 0.0:
					copy.emission_enabled = true
					copy.emission = glow
					copy.emission_energy_multiplier = glow_energy
	_gait = str(opts.get("gait", "quadruped"))
	_base_y = float(opts.get("lift", 0.0))
	_flap = float(opts.get("flap", 0.0))
	_height = target_h
	position.y = _base_y
	return true

func _rel_transform(node: Node3D, root: Node3D) -> Transform3D:
	var xf := Transform3D.IDENTITY
	var n: Node3D = node
	while n != null and n != root:
		xf = n.transform * xf
		n = n.get_parent() as Node3D
	return xf

func tick(delta: float, moving: float, rate: float) -> void:
	if _pivot == null:
		return
	_t += delta
	_move = lerpf(_move, clampf(moving, 0.0, 1.0), clampf(delta * 7.0, 0.0, 1.0))
	var m: float = _move
	var breathe: float = sin(_t * 2.0) * 0.01
	scale = Vector3.ONE
	match _gait:
		"quadruped":
			var ph: float = _t * rate
			position.y = _base_y + absf(sin(ph * 0.5)) * 0.06 * m + breathe
			_pivot.rotation.x = sin(ph * 0.5 + 0.5) * 0.045 * m
			_pivot.rotation.z = sin(ph) * 0.032 * m
			_pivot.rotation.y = _base_yaw + sin(ph * 0.5) * 0.022 * m
			scale = Vector3(1.0 + 0.014 * m * sin(ph), 1.0 - 0.018 * m * absf(sin(ph * 0.5)), 1.0)
		"serpent":
			var ph2: float = _t * rate
			position.y = _base_y + sin(ph2 * 0.5) * 0.02 * m + breathe
			_pivot.rotation.y = _base_yaw + sin(ph2 * 0.4) * 0.18 * m
			_pivot.rotation.z = sin(ph2 * 0.8) * 0.03 * m
			_pivot.rotation.x = sin(ph2 * 0.5 + 0.8) * 0.02 * m
		"crawler":
			var ph3: float = _t * rate
			position.y = _base_y + absf(sin(ph3 * 0.5)) * 0.035 * m + breathe
			_pivot.rotation.z = sin(ph3 * 0.5) * 0.05 * m
			_pivot.rotation.x = sin(ph3 * 0.5 + 0.6) * 0.03 * m
			_pivot.rotation.y = _base_yaw + sin(ph3) * 0.03 * m
		"flyer":
			var ph4: float = _t * rate
			# Static scans have no bones, so wingbeat is a see-saw roll on the pivot
			# plus a hover bob; reads as flapping from the side and from the front.
			_pivot.rotation.z = sin(ph4) * _flap * (0.4 + 0.6 * m) + sin(_t * 0.9) * 0.02
			position.y = _base_y + 0.04 + sin(_t * 2.2) * 0.05 + sin(ph4 * 0.5 + 0.8) * 0.03 * m
			_pivot.rotation.x = sin(ph4 * 0.5 + 0.4) * 0.035 * (0.4 + m)
			_pivot.rotation.y = _base_yaw + sin(_t * 0.7) * 0.04
		"blob":
			var wob: float = sin(_t * 3.0) * (0.035 + 0.045 * m)
			position.y = _base_y + breathe
			scale = Vector3(1.0 + wob, 1.0 - wob * 0.85, 1.0 + wob)
			_pivot.rotation.y = _base_yaw + sin(_t * 1.4) * 0.03 * (0.3 + m)
