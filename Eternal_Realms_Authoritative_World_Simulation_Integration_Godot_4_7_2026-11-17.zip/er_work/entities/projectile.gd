extends Node3D
class_name ERProjectile

var travel_direction: Vector3 = Vector3.FORWARD
var source: Node3D
var damage: float = 10.0
var max_distance: float = 20.0
var projectile_kind: String = "wand"
var spell_element: String = "fire"
var spell_name: String = "Ember Lance"
var spell_power: float = 1.0
var spell_tier: int = 0
var speed: float = 24.0
var impact_radius: float = 0.0
var impact_damage_ratio: float = 0.0
var _travelled: float = 0.0
var _ballistic_velocity: Vector3 = Vector3.ZERO
var _ballistic_initialized: bool = false
var _life: float = 4.0
var _glow: OmniLight3D
var _trail: CPUParticles3D

func _ready() -> void:
	name = spell_name if projectile_kind == "elemental" else ("SpellProjectile" if projectile_kind != "bow" else "ArrowProjectile")
	_build_visual()

func _physics_process(delta: float) -> void:
	_life -= delta
	if _life <= 0.0 or _travelled >= max_distance:
		queue_free()
		return
	var movement: Vector3 = travel_direction.normalized() * speed
	if projectile_kind == "bow":
		if not _ballistic_initialized:
			_ballistic_velocity = movement
			_ballistic_initialized = true
		_ballistic_velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
			var drag_force := PhysicalWorldSystem.aerodynamic_drag(_ballistic_velocity, 1.0, 0.00005, global_position.y)
			_ballistic_velocity += drag_force / 0.025 * delta
		movement = _ballistic_velocity
		if movement.length_squared() > 0.0001:
			travel_direction = movement.normalized()
			speed = movement.length()
	var step: float = minf(movement.length() * delta, max_distance - _travelled)
	var next_position: Vector3 = global_position + movement.normalized() * step
	var exclude: Array[RID] = []
	if source and is_instance_valid(source) and source is CollisionObject3D:
		exclude.append((source as CollisionObject3D).get_rid())
	var query := PhysicsRayQueryParameters3D.create(global_position, next_position, Constants.LAYER_WORLD | Constants.LAYER_CREATURE, exclude)
	query.collide_with_areas = true
	query.hit_from_inside = true
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var collider: Object = hit.get("collider")
		if collider is Node and (collider as Node).is_in_group("enemy") and (collider as Node).has_method("take_damage"):
			var critical: bool = randf() < (0.12 if projectile_kind == "elemental" else 0.08)
			var impact_damage: float = damage * (1.8 if critical else 1.0)
			if projectile_kind == "elemental" and (collider as Node).has_method("take_elemental_damage"):
				(collider as Node).take_elemental_damage(impact_damage, source, spell_element, critical)
			else:
				(collider as Node).take_damage(impact_damage, source, critical)
			if impact_radius > 0.0:
				_apply_impact_splash(collider as Node3D, hit.get("position", next_position))
			if projectile_kind == "elemental":
				if (collider as Node).has_method("apply_elemental_status"):
					(collider as Node).apply_elemental_status(spell_element, source, spell_power + float(spell_tier) * 0.28)
				var impact_position: Vector3 = hit.get("position", next_position)
				_apply_elemental_mastery(collider as Node3D, impact_position)
			if source and is_instance_valid(source) and source.has_node("SkillSystem"):
				var skill_node: Node = source.get_node("SkillSystem")
				if skill_node.has_method("train"):
					skill_node.train("archery" if projectile_kind == "bow" else "elemental_magic", 0.18, true)
		_impact(hit.get("position", next_position))
		return
	global_position = next_position
	_travelled += step

func _build_visual() -> void:
	var mesh_instance := MeshInstance3D.new()
	var light_color := Color(0.75, 0.45, 1.0)
	if projectile_kind == "bow":
		var mesh := BoxMesh.new()
		mesh.size = Vector3(0.045, 0.045, 0.72)
		mesh_instance.mesh = mesh
		mesh_instance.material_override = _material(Color(0.55, 0.34, 0.16), false)
		mesh_instance.rotation.y = PI
		mesh_instance.position.z = -0.24
		light_color = Color(0.55, 0.34, 0.16)
		speed = 42.0
	elif projectile_kind == "elemental":
		light_color = _element_color(spell_element)
		match spell_element:
			"earth":
				var shard := PrismMesh.new()
				shard.size = Vector3(0.30, 0.44, 0.76)
				mesh_instance.mesh = shard
				mesh_instance.rotation.x = 0.45
				speed = 18.0
			"wind":
				var ring := TorusMesh.new()
				ring.inner_radius = 0.08
				ring.outer_radius = 0.18
				mesh_instance.mesh = ring
				mesh_instance.rotation.x = PI * 0.5
				speed = 34.0
			"ice":
				var ice := PrismMesh.new()
				ice.size = Vector3(0.16, 0.16, 0.62)
				mesh_instance.mesh = ice
				speed = 29.0
			"lightning":
				var spark := CapsuleMesh.new()
				spark.radius = 0.075
				spark.height = 0.54
				mesh_instance.mesh = spark
				mesh_instance.rotation.z = PI * 0.5
				speed = 38.0
			"water":
				var drop := SphereMesh.new()
				drop.radius = 0.15
				drop.height = 0.38
				mesh_instance.mesh = drop
				speed = 25.0
			_:
				var flame := SphereMesh.new()
				flame.radius = 0.16
				flame.height = 0.38
				mesh_instance.mesh = flame
				speed = 23.0
		mesh_instance.material_override = _material(light_color, true)
	else:
		var mesh := SphereMesh.new()
		mesh.radius = 0.16 if projectile_kind == "staff" else 0.12
		mesh.height = mesh.radius * 2.0
		mesh.radial_segments = 16
		mesh.rings = 10
		mesh_instance.mesh = mesh
		light_color = Color(0.35, 0.72, 1.0) if projectile_kind == "staff" else Color(0.72, 0.42, 1.0)
		mesh_instance.material_override = _material(light_color, true)
		speed = 20.0 if projectile_kind == "staff" else 25.0
	if projectile_kind == "elemental":
		var tier_scale: float = 1.0 + float(spell_tier) * 0.12
		mesh_instance.scale = Vector3.ONE * tier_scale
		speed *= 1.0 + float(spell_tier) * 0.06
	add_child(mesh_instance)
	_glow = OmniLight3D.new()
	_glow.light_color = light_color
	_glow.light_energy = 1.65 if projectile_kind == "elemental" else 1.4
	_glow.omni_range = 3.6 if projectile_kind == "elemental" else 3.2
	add_child(_glow)
	look_at(global_position + travel_direction, Vector3.UP)

func _apply_impact_splash(first_target: Node3D, impact_point: Vector3) -> void:
	if impact_radius <= 0.0:
		return
	for candidate in get_tree().get_nodes_in_group("enemy"):
		if not candidate is Node3D or candidate == first_target or not is_instance_valid(candidate):
			continue
		var target: Node3D = candidate as Node3D
		if target.global_position.distance_to(impact_point) > impact_radius:
			continue
		if not target.has_method("take_damage") or not _has_elemental_line_of_sight(impact_point, target):
			continue
		_deal_projectile_damage(target, damage * impact_damage_ratio, false)
		if projectile_kind == "elemental" and target.has_method("apply_elemental_status"):
			target.apply_elemental_status(spell_element, source, spell_power * 0.5)
	VFX.burst(get_parent(), impact_point, _element_color(spell_element) if projectile_kind == "elemental" else Color(0.62, 0.72, 1.0), 18, impact_radius + 1.5, 0.065)

func _element_color(element: String) -> Color:
	match element:
		"fire": return Color(1.0, 0.30, 0.07)
		"water": return Color(0.15, 0.64, 1.0)
		"wind": return Color(0.52, 0.95, 0.72)
		"earth": return Color(0.68, 0.47, 0.24)
		"lightning": return Color(0.98, 0.88, 0.22)
		"ice": return Color(0.56, 0.88, 1.0)
	return Color(0.75, 0.45, 1.0)

func _apply_elemental_mastery(first_target: Node3D, impact_point: Vector3) -> void:
	match spell_element:
		"fire":
			if spell_tier > 0:
				var radius: float = 2.0 + float(spell_tier) * 0.8
				for candidate in get_tree().get_nodes_in_group("enemy"):
					if not candidate is Node3D or candidate == first_target or not is_instance_valid(candidate):
						continue
					var target: Node3D = candidate as Node3D
					if target.global_position.distance_to(impact_point) <= radius and target.has_method("take_damage") and _has_elemental_line_of_sight(impact_point, target):
						_deal_projectile_damage(target, damage * (0.18 + float(spell_tier) * 0.07), false)
						if target.has_method("apply_elemental_status"):
							target.apply_elemental_status("fire", source, spell_power * 0.55)
				VFX.burst(get_parent(), impact_point, _element_color("fire"), 18 + spell_tier * 8, 4.0 + float(spell_tier), 0.07)
		"water":
			if source and is_instance_valid(source):
				var source_health: Variant = source.get("health")
				if source_health != null and source_health.has_method("heal"):
					var heal_ratio: float = 0.10 + float(spell_tier) * 0.075
					source_health.heal(maxf(1.0, damage * heal_ratio))
			VFX.burst(get_parent(), impact_point, _element_color("water"), 10 + spell_tier * 5, 2.8 + float(spell_tier), 0.06)
		"wind":
			if spell_tier > 0:
				var radius: float = 2.0 + float(spell_tier) * 1.1
				for candidate in get_tree().get_nodes_in_group("enemy"):
					if not candidate is Node3D or candidate == first_target or not is_instance_valid(candidate):
						continue
					var target: Node3D = candidate as Node3D
					if target.global_position.distance_to(impact_point) <= radius and target.has_method("apply_elemental_status") and _has_elemental_line_of_sight(impact_point, target):
						target.apply_elemental_status("wind", source, spell_power * 0.7)
			VFX.burst(get_parent(), impact_point, _element_color("wind"), 14 + spell_tier * 7, 3.4 + float(spell_tier), 0.05)
		"earth":
			if spell_tier > 0:
				var radius: float = 2.2 + float(spell_tier) * 0.9
				for candidate in get_tree().get_nodes_in_group("enemy"):
					if not candidate is Node3D or candidate == first_target or not is_instance_valid(candidate):
						continue
					var target: Node3D = candidate as Node3D
					if target.global_position.distance_to(impact_point) <= radius and target.has_method("take_damage") and _has_elemental_line_of_sight(impact_point, target):
						_deal_projectile_damage(target, damage * (0.22 + float(spell_tier) * 0.08), false)
						if target.has_method("apply_elemental_status"):
							target.apply_elemental_status("earth", source, spell_power * 0.6)
			VFX.impact_ring(get_parent(), impact_point + Vector3.UP * 0.05, _element_color("earth"), 1.8 + float(spell_tier) * 0.6)
		"lightning":
			_apply_lightning_chain(first_target, 1 + spell_tier)
		"ice":
			if spell_tier >= 2 and first_target.has_method("apply_elemental_status"):
				first_target.apply_elemental_status("ice", source, spell_power * 1.8)
			VFX.burst(get_parent(), impact_point, _element_color("ice"), 12 + spell_tier * 6, 3.2 + float(spell_tier), 0.055)

func _apply_lightning_chain(first_target: Node3D, chain_count: int = 1) -> void:
	var previous: Node3D = first_target
	var hit_targets: Array[Node3D] = [first_target]
	for chain_i in range(chain_count):
		var best: Node3D = null
		var best_distance: float = 6.5 + float(spell_tier) * 1.5
		for candidate in get_tree().get_nodes_in_group("enemy"):
			if not candidate is Node3D or not is_instance_valid(candidate):
				continue
			var target: Node3D = candidate as Node3D
			if hit_targets.has(target):
				continue
			var distance: float = target.global_position.distance_to(previous.global_position)
			if distance < best_distance and _has_elemental_line_of_sight(previous.global_position, target):
				best_distance = distance
				best = target
		if best == null:
			break
		hit_targets.append(best)
		if best.has_method("take_damage"):
			_deal_projectile_damage(best, damage * (0.42 if chain_i == 0 else 0.28), false)
		if best.has_method("apply_elemental_status"):
			best.apply_elemental_status("lightning", source, spell_power * 0.55)
		VFX.burst(get_parent(), best.global_position + Vector3.UP, _element_color("lightning"), 9, 3.8, 0.04)
		previous = best

func _deal_projectile_damage(target: Node3D, amount: float, critical: bool) -> void:
	if target == null or not is_instance_valid(target):
		return
	if projectile_kind == "elemental" and target.has_method("take_elemental_damage"):
		target.take_elemental_damage(amount, source, spell_element, critical)
	elif target.has_method("take_damage"):
		target.take_damage(amount, source, critical)

func _has_elemental_line_of_sight(origin: Vector3, target: Node3D) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var excluded: Array[RID] = []
	if source and is_instance_valid(source) and source is CollisionObject3D:
		excluded.append((source as CollisionObject3D).get_rid())
	var from: Vector3 = origin + Vector3.UP * 0.25
	var to: Vector3 = target.global_position + Vector3.UP * 0.85
	var query := PhysicsRayQueryParameters3D.create(from, to, Constants.LAYER_WORLD, excluded)
	query.collide_with_areas = false
	return get_world_3d().direct_space_state.intersect_ray(query).is_empty()

func _material(col: Color, emissive: bool) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 0.35
	if emissive:
		mat.emission_enabled = true
		mat.emission = col
		mat.emission_energy_multiplier = 2.8
	return mat

func _impact(point: Vector3) -> void:
	global_position = point
	if _glow:
		_glow.light_energy = 0.0
	var puff := GPUParticles3D.new()
	var process := ParticleProcessMaterial.new()
	process.direction = Vector3(0, 1, 0)
	process.spread = 180.0
	process.initial_velocity_min = 1.0
	process.initial_velocity_max = 3.0
	process.gravity = Vector3.ZERO
	puff.process_material = process
	var particle_mesh := SphereMesh.new()
	particle_mesh.radius = 0.045
	particle_mesh.height = 0.09
	puff.draw_pass_1 = particle_mesh
	puff.amount = 12
	puff.lifetime = 0.25
	puff.one_shot = true
	add_child(puff)
	puff.emitting = true
	await get_tree().create_timer(0.3).timeout
	queue_free()
