# ResourceNode - something you can gather: iron ore outcrop, tree, or glowing moonpetal.
# Gathering takes a few seconds (cancelled if you move), has a skill-based success chance,
# always teaches the skill (more on success), and respawns after a while.
extends StaticBody3D
class_name ResourceNode

const CONFIGS: Dictionary = {
	"ore": {"item": "iron_ore", "skill": "mining", "charges": 3, "time": 2.2, "base": 0.55, "respawn": 150.0,
		"gain": 0.35, "min_q": 1, "max_q": 2, "verb": "Mine", "label": "Iron Ore"},
	"copper": {"item": "copper_ore", "skill": "mining", "charges": 3, "time": 2.0, "base": 0.60, "respawn": 140.0,
		"gain": 0.32, "min_q": 1, "max_q": 2, "verb": "Mine", "label": "Copper Ore"},
	"tree": {"item": "wood_log", "skill": "woodcutting", "charges": 2, "time": 1.9, "base": 0.70, "respawn": 120.0,
		"gain": 0.30, "min_q": 1, "max_q": 3, "verb": "Chop", "label": "Tree"},
	"tree_redwood": {"item": "redwood_heartwood", "skill": "woodcutting", "charges": 4, "time": 3.8, "base": 0.52, "respawn": 360.0, "gain": 0.55, "min_q": 3, "max_q": 6, "verb": "Chop", "label": "Ancient Redwood"},
	"tree_willow": {"item": "willow_bark", "skill": "woodcutting", "charges": 2, "time": 2.2, "base": 0.68, "respawn": 180.0, "gain": 0.34, "min_q": 2, "max_q": 4, "verb": "Chop", "label": "Silver Willow"},
	"tree_baobab": {"item": "baobab_fiber", "skill": "woodcutting", "charges": 3, "time": 3.0, "base": 0.58, "respawn": 260.0, "gain": 0.44, "min_q": 2, "max_q": 5, "verb": "Chop", "label": "Giant Baobab"},
	"tree_cherry": {"item": "cherrywood", "skill": "woodcutting", "charges": 2, "time": 2.0, "base": 0.70, "respawn": 170.0, "gain": 0.34, "min_q": 1, "max_q": 3, "verb": "Chop", "label": "Blossom Tree"},
	"tree_jungle": {"item": "jungle_hardwood", "skill": "woodcutting", "charges": 3, "time": 2.7, "base": 0.62, "respawn": 230.0, "gain": 0.40, "min_q": 2, "max_q": 4, "verb": "Chop", "label": "Jungle Strangler"},
	"herb": {"item": "moonpetal", "skill": "herbalism", "charges": 1, "time": 1.2, "base": 0.68, "respawn": 90.0,
		"gain": 0.30, "min_q": 1, "max_q": 2, "verb": "Pick", "label": "Moonpetal"},
	"silver": {"item": "silver_ore", "skill": "mining", "charges": 3, "time": 2.8, "base": 0.46, "respawn": 240.0, "gain": 0.42, "min_q": 1, "max_q": 2, "verb": "Mine", "label": "Silver Vein"},
	"gold": {"item": "gold_ore", "skill": "mining", "charges": 2, "time": 3.2, "base": 0.34, "respawn": 300.0, "gain": 0.52, "min_q": 1, "max_q": 1, "verb": "Mine", "label": "Gold Vein"},
	"crystal": {"item": "mana_crystal", "skill": "mining", "charges": 2, "time": 3.0, "base": 0.40, "respawn": 260.0, "gain": 0.48, "min_q": 1, "max_q": 2, "verb": "Harvest", "label": "Mana Crystal"},
	"sulfur": {"item": "sulfur", "skill": "mining", "charges": 3, "time": 2.5, "base": 0.48, "respawn": 210.0, "gain": 0.4, "min_q": 1, "max_q": 2, "verb": "Mine", "label": "Sulfur Deposit"},
	"mushroom": {"item": "glowcap", "skill": "herbalism", "charges": 2, "time": 1.4, "base": 0.72, "respawn": 110.0, "gain": 0.32, "min_q": 1, "max_q": 3, "verb": "Gather", "label": "Glowcap Cluster"},
	"berry": {"item": "wild_berries", "skill": "herbalism", "charges": 2, "time": 1.1, "base": 0.78, "respawn": 100.0, "gain": 0.28, "min_q": 2, "max_q": 4, "verb": "Gather", "label": "Wild Berry Bush"},
	"salt": {"item": "salt_crystal", "skill": "mining", "charges": 2, "time": 1.8, "base": 0.65, "respawn": 180.0, "gain": 0.30, "min_q": 1, "max_q": 3, "verb": "Collect", "label": "Salt Crystal"},
	"peat": {"item": "peat", "skill": "herbalism", "charges": 2, "time": 1.8, "base": 0.7, "respawn": 160.0, "gain": 0.34, "min_q": 2, "max_q": 4, "verb": "Harvest", "label": "Peat Moss"},
	"cactus": {"item": "cactus_fiber", "skill": "herbalism", "charges": 2, "time": 2.0, "base": 0.62, "respawn": 190.0, "gain": 0.36, "min_q": 1, "max_q": 3, "verb": "Harvest", "label": "Desert Cactus"},
	"obsidian": {"item": "obsidian_shard", "skill": "mining", "charges": 3, "time": 3.0, "base": 0.42, "respawn": 300.0, "gain": 0.5, "min_q": 1, "max_q": 2, "verb": "Mine", "label": "Obsidian Vein"},
	"orchid": {"item": "rare_orchid", "skill": "herbalism", "charges": 1, "time": 2.1, "base": 0.38, "respawn": 420.0, "gain": 0.55, "min_q": 1, "max_q": 1, "verb": "Pick", "label": "Marsh Orchid"},
	"amber": {"item": "amber_resin", "skill": "woodcutting", "charges": 2, "time": 2.2, "base": 0.58, "respawn": 280.0, "gain": 0.42, "min_q": 1, "max_q": 2, "verb": "Collect", "label": "Amber Resin"},
}

@export var kind: String = "ore"
var interact_range: float = 3.0
var depleted: bool = false
var charges: int = 1
var harvest_time: float = 2.0
var skill_id: String = "mining"

var _cfg: Dictionary = {}
var _visual: Node3D
var _stump: Node3D
var _light: OmniLight3D
var _rng := RandomNumberGenerator.new()
var _tree_kind_name: String = ""
var _tree_xf: Transform3D = Transform3D.IDENTITY
var _tree_height: float = 0.0
var _tree_radius: float = 0.0
var _last_player_pos: Vector3 = Vector3.ZERO
var _has_player_pos: bool = false

func _ready() -> void:
	add_to_group("interactable")
	collision_layer = Constants.LAYER_WORLD
	collision_mask = 0
	_cfg = CONFIGS[kind]
	charges = int(_cfg["charges"])
	harvest_time = float(_cfg["time"])
	skill_id = _cfg["skill"]
	_rng.seed = hash(Vector2i(int(global_position.x * 10.0), int(global_position.z * 10.0)))
	match kind:
		"ore", "copper", "silver", "gold", "sulfur": _build_ore()
		"tree", "tree_redwood", "tree_willow", "tree_baobab", "tree_cherry", "tree_jungle": _build_tree()
		"herb", "mushroom", "berry", "peat", "cactus", "orchid", "amber": _build_herb()
		"crystal", "salt", "obsidian": _build_special_resource()

func can_interact() -> bool:
	return not depleted

func get_prompt() -> String:
	return "%s %s" % [_cfg["verb"], _cfg["label"]]

func interact(player: Node3D) -> void:
	_last_player_pos = player.global_position
	_has_player_pos = true
	if player.has_method("begin_gather"):
		player.begin_gather(self)

## One gather attempt. Called by the player when the progress bar fills.
func attempt(skills: SkillSystem) -> void:
	var chance: float = clampf(float(_cfg["base"]) + skills.gather_bonus(skill_id), 0.1, 0.97)
	var season = get_tree().get_first_node_in_group("seasons")
	if season:
		chance = clampf(chance * season.gather_mult(), 0.1, 0.98)
	var weather = get_tree().get_first_node_in_group("weather")
	if weather and weather.has_method("gather_mult"):
		chance = clampf(chance * weather.gather_mult(), 0.1, 0.98)

	var gain: float = float(_cfg["gain"])
	var regional_resource: String = "ore" if skill_id == "mining" else ("timber" if skill_id == "woodcutting" else "herbs")
	var region_id: String = WorldLifeSimulation.region_id_at(global_position.x, global_position.z)
	var resource_factor: float = WorldLifeSimulation.get_resource_modifier(region_id, regional_resource) if region_id != "" else 1.0
	chance = clampf(chance * clampf(0.78 + resource_factor * 0.22, 0.82, 1.12), 0.1, 0.98)
	if _rng.randf() < chance:
		var qty: int = _rng.randi_range(int(_cfg["min_q"]), int(_cfg["max_q"]))
		if skills.get_value(skill_id) >= 15.0 and _rng.randf() < 0.3:
			qty += 1
		if resource_factor >= 1.5 and _rng.randf() < 0.16:
			qty += 1
		var collected: int = 0
		if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
			WorldLifeSimulation.request_authoritative_gather(self)
			collected = qty # predicted locally; the server grants the authoritative amount
		else:
			var unadded: int = PlayerData.add_item(_cfg["item"], qty)
			collected = qty - unadded
			if collected > 0 and ElyndorRegionLife and ElyndorRegionLife.has_method("record_harvest"):
				ElyndorRegionLife.record_harvest(str(_cfg["item"]), collected)
			if collected > 0 and region_id != "":
				WorldLifeSimulation.record_player_gather(region_id, regional_resource, float(collected) * 0.65, self)
		PlayerData.stats["gathered"] = int(PlayerData.stats["gathered"]) + qty
		var sg = get_tree().get_first_node_in_group("settlement_growth")
		if sg and sg.has_method("add_progress"):
			sg.add_progress("elyndor", 0.8)

		skills.train(skill_id, gain)
		charges -= 1
		if charges <= 0:
			_deplete()
	else:
		skills.train(skill_id, gain * 0.35)
		EventBus.activity.emit("You failed to gather anything.", "info")

func _is_tree_kind() -> bool:
	return kind.begins_with("tree")

func _deplete() -> void:
	depleted = true
	if _visual:
		_visual.visible = false
	if _stump:
		_stump.visible = true
	if _light:
		_light.visible = false
		_light.remove_from_group("night_lights")
	for c in get_children():
		if c is CollisionShape3D:
			c.disabled = true
	if _is_tree_kind():
		_drop_tree()
	get_tree().create_timer(float(_cfg["respawn"])).timeout.connect(_respawn)

## Turns the standing tree into a rigid body that topples away from the chopper,
## then settles as a solid fallen trunk.
func _drop_tree() -> void:
	var parent: Node = get_parent()
	if parent == null or _tree_height <= 0.0:
		return
	var fall_dir := _fall_direction()
	var height: float = _tree_height
	var radius: float = maxf(_tree_radius * 0.85, 0.22)
	var rb := RigidBody3D.new()
	rb.continuous_cd = true
	rb.collision_layer = Constants.LAYER_WORLD
	rb.collision_mask = Constants.LAYER_WORLD
	rb.linear_damp = 0.05
	rb.angular_damp = 0.1
	var mesh: MultiMeshInstance3D = VegetationKit.make_multimesh(_tree_kind_name, [_tree_xf], PackedColorArray([Color(1, 1, 1, 1)]), 0.0, true)
	rb.add_child(mesh)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = height * 0.94
	cs.shape = shape
	cs.position = Vector3(0, height * 0.47, 0)
	rb.add_child(cs)
	rb.mass = clampf(PI * radius * radius * height * 480.0, 240.0, 9000.0)
	parent.add_child(rb)
	rb.global_position = global_position + Vector3(0, 0.14, 0)
	rb.sleeping = false
	# Launched as if pivoting about the stump: COM arcs forward while the base
	# stays put, then gravity and ground contact take over and it tumbles.
	var hinge_axis := Vector3.UP.cross(fall_dir).normalized()
	var com_h: float = height * 0.47
	var spin: float = clampf(1.05 * 4.6 / maxf(com_h, 0.5), 0.6, 1.05)
	rb.linear_velocity = fall_dir * spin * com_h
	rb.angular_velocity = hinge_axis * spin
	get_tree().create_timer(9.0).timeout.connect(_settle_fallen.bind(rb))

func _fall_direction() -> Vector3:
	var d := Vector3.ZERO
	if _has_player_pos:
		d = global_position - _last_player_pos
		d.y = 0.0
	if d.length_squared() < 0.04:
		var a: float = _rng.randf() * TAU
		d = Vector3(cos(a), 0.0, sin(a))
	return d.normalized()

func _settle_fallen(rb: RigidBody3D) -> void:
	if is_instance_valid(rb):
		rb.freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
		rb.freeze = true
	get_tree().create_timer(26.0).timeout.connect(_clear_fallen.bind(rb))

func _clear_fallen(rb: RigidBody3D) -> void:
	if is_instance_valid(rb):
		rb.queue_free()

func _respawn() -> void:
	if not is_inside_tree():
		return
	depleted = false
	charges = int(_cfg["charges"])
	if _visual:
		_visual.visible = true
	if _stump:
		_stump.visible = false
	if _light:
		_light.add_to_group("night_lights")
	for c in get_children():
		if c is CollisionShape3D:
			c.set_deferred("disabled", false)

# ---------------------------------------------------------------------------
# Visuals
# ---------------------------------------------------------------------------
func _vertex_mat(emission: Color = Color(0, 0, 0), energy: float = 0.0, rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	m.roughness = rough
	if energy > 0.0:
		m.emission_enabled = true
		m.emission = emission
		m.emission_energy_multiplier = energy
	return m

func _add_collision(radius: float, height: float) -> void:
	var cs := CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = radius
	cyl.height = height
	cs.shape = cyl
	cs.position = Vector3(0, height * 0.5, 0)
	add_child(cs)

func _build_ore() -> void:
	var mesh := ArrayMesh.new()
	var rock := SurfaceTool.new()
	rock.begin(Mesh.PRIMITIVE_TRIANGLES)
	var lo := Color(0.25, 0.26, 0.30)
	var hi := Color(0.50, 0.50, 0.56)
	MeshKit.blob(rock, Vector3(0, 0.55, 0), Vector3(0.95, 0.75, 0.85), _rng, lo, hi, 0.25, 7, 5)
	MeshKit.blob(rock, Vector3(0.7, 0.3, 0.2), Vector3(0.5, 0.4, 0.45), _rng, lo, hi, 0.25, 6, 4)
	MeshKit.blob(rock, Vector3(-0.6, 0.35, -0.3), Vector3(0.55, 0.45, 0.5), _rng, lo, hi, 0.25, 6, 4)
	rock.set_material(_vertex_mat())
	rock.commit(mesh)
	var ore := SurfaceTool.new()
	ore.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rust_lo := Color(0.55, 0.25, 0.10)
	var rust_hi := Color(0.95, 0.55, 0.20)
	match kind:
		"copper":
			rust_lo = Color(0.48, 0.22, 0.08); rust_hi = Color(0.95, 0.48, 0.18)
		"silver":
			rust_lo = Color(0.48, 0.54, 0.62); rust_hi = Color(0.92, 0.96, 1.0)
		"gold":
			rust_lo = Color(0.58, 0.38, 0.06); rust_hi = Color(1.0, 0.82, 0.20)
		"sulfur":
			rust_lo = Color(0.48, 0.38, 0.06); rust_hi = Color(0.96, 0.86, 0.22)
	for i in range(7):
		var a: float = _rng.randf() * TAU
		var r: float = _rng.randf_range(0.55, 0.9)
		var p := Vector3(cos(a) * r, _rng.randf_range(0.25, 1.0), sin(a) * r)
		MeshKit.blob(ore, p, Vector3(0.14, 0.17, 0.14), _rng, rust_lo, rust_hi, 0.3, 5, 3)
	var vein_glow := Color(1.0, 0.5, 0.2)
	match kind:
		"silver": vein_glow = Color(0.55, 0.72, 1.0)
		"gold": vein_glow = Color(1.0, 0.76, 0.18)
		"sulfur": vein_glow = Color(0.95, 0.82, 0.18)
	ore.set_material(_vertex_mat(vein_glow, 0.55, 0.45))
	ore.commit(mesh)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.rotation.y = _rng.randf() * TAU
	add_child(mi)
	_visual = mi
	_add_collision(0.95, 1.2)
	# depleted: small rubble
	var rub := SurfaceTool.new()
	rub.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.blob(rub, Vector3(0, 0.12, 0), Vector3(0.5, 0.14, 0.45), _rng, lo, hi, 0.3, 6, 3)
	rub.set_material(_vertex_mat())
	var rm := MeshInstance3D.new()
	rm.mesh = rub.commit()
	rm.visible = false
	add_child(rm)
	_stump = rm

func _build_tree() -> void:
	var kind_name: String = "pine" if _rng.randf() < 0.4 else "broadleaf"
	match kind:
		"tree_redwood": kind_name = "redwood"
		"tree_willow": kind_name = "willow"
		"tree_baobab": kind_name = "baobab"
		"tree_cherry": kind_name = "cherry"
		"tree_jungle": kind_name = "jungle"
	var tree_scale: float = _rng.randf_range(1.3, 1.8)
	var tree_height: float = 6.0
	var trunk_radius: float = 0.5
	if kind_name == "redwood":
		tree_scale = _rng.randf_range(2.1, 3.1)
		tree_height = 18.0
		trunk_radius = 0.95
	elif kind_name == "baobab":
		tree_scale = _rng.randf_range(1.7, 2.4)
		tree_height = 5.5
		trunk_radius = 1.25
	elif kind_name == "willow":
		tree_height = 4.5
	elif kind_name == "jungle":
		tree_height = 6.0
		trunk_radius = 0.58
	elif kind_name == "pine":
		tree_height = 6.5
		trunk_radius = 0.36
	elif kind_name == "cherry":
		tree_height = 4.0
		trunk_radius = 0.3
	var xf := Transform3D(Basis(Vector3.UP, _rng.randf() * TAU).scaled(Vector3.ONE * tree_scale), Vector3(0, -0.1, 0))
	_tree_kind_name = kind_name
	_tree_xf = xf
	_tree_height = tree_height * tree_scale
	_tree_radius = trunk_radius * tree_scale
	var mmi: MultiMeshInstance3D = VegetationKit.make_multimesh(kind_name, [xf], PackedColorArray([Color(1, 1, 1, 1)]), 0.0, true)
	add_child(mmi)
	_visual = mmi
	_add_collision(trunk_radius * tree_scale, tree_height * tree_scale)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	MeshKit.cylinder_at(st, Vector3(0, -0.1, 0), 0.42, 0.34, 0.55, 8, Color(0.25, 0.16, 0.09), Color(0.45, 0.32, 0.2))
	st.set_material(_vertex_mat())
	var sm := MeshInstance3D.new()
	sm.mesh = st.commit()
	sm.visible = false
	add_child(sm)
	_stump = sm

func _build_special_resource() -> void:
	var mesh: ArrayMesh = VegetationKit.get_mesh("crystal")
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	if kind == "salt":
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.88, 0.91, 0.94)
		mat.metallic = 0.12
		mat.roughness = 0.28
		mi.material_override = mat
	elif kind == "obsidian":
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.12, 0.09, 0.15)
		mat.metallic = 0.28
		mat.roughness = 0.18
		mi.material_override = mat
	mi.scale = Vector3.ONE * _rng.randf_range(0.75, 1.2)
	add_child(mi)
	_visual = mi
	_add_collision(0.85, 1.5)

func _build_herb() -> void:
	if kind == "cactus":
		var cactus := Node3D.new()
		var green := StandardMaterial3D.new(); green.albedo_color = Color(0.16, 0.40, 0.20); green.roughness = 0.82
		var trunk := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.24; cm.bottom_radius = 0.34; cm.height = 1.5; trunk.mesh = cm; trunk.material_override = green; trunk.position.y = 0.75; cactus.add_child(trunk)
		for side in [-1.0, 1.0]:
			var arm := MeshInstance3D.new(); var am := CylinderMesh.new(); am.top_radius = 0.10; am.bottom_radius = 0.13; am.height = 0.62; arm.mesh = am; arm.material_override = green; arm.position = Vector3(side * 0.30, 0.72, 0); arm.rotation.z = -side * 0.55; cactus.add_child(arm)
		add_child(cactus); _visual = cactus; _add_collision(0.55, 1.5); return
	if kind == "peat":
		var moss := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 0.48; sm.height = 0.28; moss.mesh = sm
		var mm := StandardMaterial3D.new(); mm.albedo_color = Color(0.20, 0.29, 0.15); mm.roughness = 1.0; moss.material_override = mm; moss.position.y = 0.12
		add_child(moss); _visual = moss; _add_collision(0.48, 0.3); return
	if kind == "amber":
		var crystal := MeshInstance3D.new(); crystal.mesh = VegetationKit.get_mesh("crystal"); crystal.scale = Vector3(0.5, 0.65, 0.5)
		var am := StandardMaterial3D.new(); am.albedo_color = Color(0.88, 0.48, 0.12); am.emission_enabled = true; am.emission = Color(0.55, 0.22, 0.04); am.emission_energy_multiplier = 0.35; crystal.material_override = am
		add_child(crystal); _visual = crystal; _add_collision(0.45, 0.9); return
	if kind == "mushroom":
		var group := Node3D.new()
		for i in range(3):
			var cap := MeshInstance3D.new()
			cap.mesh = VegetationKit.get_mesh("mushroom")
			cap.position = Vector3(_rng.randf_range(-0.28, 0.28), 0.0, _rng.randf_range(-0.28, 0.28))
			cap.scale = Vector3.ONE * _rng.randf_range(0.65, 1.25)
			group.add_child(cap)
		add_child(group)
		_visual = group
		_add_collision(0.55, 0.8)
		return
	if kind == "berry":
		var berry_group := Node3D.new()
		var bush := MeshInstance3D.new()
		bush.mesh = VegetationKit.get_mesh("bush")
		bush.scale = Vector3(1.25, 1.0, 1.25)
		berry_group.add_child(bush)
		var berry_mat := StandardMaterial3D.new()
		berry_mat.albedo_color = Color(0.72, 0.08, 0.18)
		berry_mat.roughness = 0.28
		for i in range(9):
			var berry := MeshInstance3D.new()
			var sphere := SphereMesh.new()
			sphere.radius = 0.075
			sphere.height = 0.15
			berry.mesh = sphere
			berry.material_override = berry_mat
			var a := TAU * float(i) / 9.0
			berry.position = Vector3(cos(a) * 0.48, 0.35 + _rng.randf_range(0.05, 0.35), sin(a) * 0.48)
			berry_group.add_child(berry)
		add_child(berry_group)
		_visual = berry_group
		_add_collision(0.6, 0.9)
		return
	var mesh := ArrayMesh.new()
	var stems := SurfaceTool.new()
	stems.begin(Mesh.PRIMITIVE_TRIANGLES)
	var blooms := SurfaceTool.new()
	blooms.begin(Mesh.PRIMITIVE_TRIANGLES)
	var green := Color(0.12, 0.40, 0.18)
	for i in range(5):
		var a: float = TAU * float(i) / 5.0 + _rng.randf() * 0.5
		var r: float = _rng.randf_range(0.08, 0.3)
		var h: float = _rng.randf_range(0.35, 0.6)
		var base := Vector3(cos(a) * r, 0, sin(a) * r)
		MeshKit.cylinder_at(stems, base, 0.015, 0.01, h, 4, green, green)
		MeshKit.blob(stems, base + Vector3(0.06, h * 0.4, 0), Vector3(0.08, 0.015, 0.035), _rng, green, green, 0.1, 5, 3)
		var c := Color(0.62, 0.85, 1.0)
		MeshKit.blob(blooms, base + Vector3(0, h + 0.03, 0), Vector3(0.09, 0.055, 0.09), _rng, c.darkened(0.2), c, 0.12, 7, 4)
	stems.set_material(_vertex_mat())
	stems.commit(mesh)
	blooms.set_material(_vertex_mat(Color(0.55, 0.8, 1.0), 2.2, 0.3))
	blooms.commit(mesh)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	add_child(mi)
	_visual = mi
	interact_range = 2.6
	_light = BuildingKit.add_light(self, Vector3(0, 0.6, 0), Color(0.55, 0.8, 1.0), 0.9, 5.5, 0.1)
