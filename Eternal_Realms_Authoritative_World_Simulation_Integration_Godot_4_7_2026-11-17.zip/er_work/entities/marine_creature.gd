# Non-catchable large marine wildlife. Creatures swim in schools and can be observed.
extends Area3D
class_name MarineCreature

@export var creature_id: String = "sea_turtle"
@export var display_name: String = "Sea Turtle"
@export var body_color: Color = Color(0.2, 0.58, 0.48)
@export var body_scale: float = 1.0

var interact_range: float = 5.0
var home: Vector3 = Vector3.ZERO
var _noise: TerrainNoise
var _direction: Vector3 = Vector3.FORWARD
var _speed: float = 1.1
var _turn_clock: float = 0.0
var _animation_clock: float = 0.0
var _observe_cooldown: float = 0.0
var _visual: Node3D
var _tail: Node3D
var _left_fin: Node3D
var _right_fin: Node3D
var is_hostile: bool = false
var is_deep_boss: bool = false
var max_health: float = 100.0
var current_health: float = 100.0
var attack_damage: float = 8.0
var attack_range: float = 3.2
var swim_speed: float = 2.8
var _attack_cooldown: float = 0.0
var _surge_cooldown: float = 3.0
var _undertow_cooldown: float = 8.0
var _target_player: Node3D
var _dead: bool = false
var _boss_phase: int = 1
var _phase_attack_clock: float = 0.0

func _ready() -> void:
	add_to_group("marine_creatures")
	add_to_group("marine_life")
	add_to_group("interactable")
	if is_hostile:
		add_to_group("enemy")
		add_to_group("marine_hostile")
		set_meta("marine_hostile", true)
		collision_layer = Constants.LAYER_CREATURE
		collision_mask = 0
		monitoring = false
		monitorable = true
		var hit_shape := CollisionShape3D.new()
		var hit_sphere := SphereShape3D.new()
		hit_sphere.radius = maxf(1.0, body_scale * 0.9)
		hit_shape.shape = hit_sphere
		hit_shape.position.y = 0.1
		add_child(hit_shape)
	current_health = max_health
	home = global_position
	_noise = TerrainNoise.new(GameManager.world_seed)
	_speed = randf_range(0.7, 1.7)
	_direction = Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0)).normalized()
	_build_visual()

func _build_visual() -> void:
	_visual = Node3D.new()
	_visual.name = "MarineBody"
	add_child(_visual)
	var body_mat := _mat(body_color, 0.35)
	var light_mat := _mat(body_color.lightened(0.32), 0.28)
	var dark_mat := _mat(body_color.darkened(0.36), 0.65)
	match creature_id:
		"sea_turtle":
			_add_ellipsoid(Vector3.ZERO, Vector3(0.72, 0.34, 1.0), body_mat)
			_add_ellipsoid(Vector3(0.0, 0.16, 0.0), Vector3(0.76, 0.24, 0.72), dark_mat)
			_add_ellipsoid(Vector3(0.0, 0.15, -0.82), Vector3(0.24, 0.22, 0.34), light_mat)
			_add_ellipsoid(Vector3(0.0, 0.1, 1.04), Vector3(0.13, 0.12, 0.34), body_mat)
			_left_fin = _add_ellipsoid(Vector3(-0.72, -0.03, -0.35), Vector3(0.19, 0.11, 0.55), light_mat)
			_right_fin = _add_ellipsoid(Vector3(0.72, -0.03, -0.35), Vector3(0.19, 0.11, 0.55), light_mat)
			_add_ellipsoid(Vector3(-0.52, -0.03, 0.62), Vector3(0.16, 0.10, 0.34), body_mat)
			_add_ellipsoid(Vector3(0.52, -0.03, 0.62), Vector3(0.16, 0.10, 0.34), body_mat)
		"reef_ray":
			_add_ellipsoid(Vector3.ZERO, Vector3(0.5, 0.15, 0.72), dark_mat)
			_left_fin = _add_ellipsoid(Vector3(-0.78, 0.0, 0.0), Vector3(0.9, 0.09, 0.48), body_mat)
			_right_fin = _add_ellipsoid(Vector3(0.78, 0.0, 0.0), Vector3(0.9, 0.09, 0.48), body_mat)
			_add_ellipsoid(Vector3(0.0, -0.04, 0.9), Vector3(0.07, 0.07, 0.8), light_mat)
		"dolphin":
			_add_ellipsoid(Vector3.ZERO, Vector3(0.42, 0.42, 1.25), body_mat)
			_add_ellipsoid(Vector3(0.0, 0.03, -1.2), Vector3(0.25, 0.22, 0.55), light_mat)
			_add_ellipsoid(Vector3(0.0, -0.03, -1.62), Vector3(0.16, 0.11, 0.45), body_mat)
			_add_ellipsoid(Vector3(-0.52, -0.18, 0.18), Vector3(0.12, 0.08, 0.56), dark_mat)
			_add_ellipsoid(Vector3(0.52, -0.18, 0.18), Vector3(0.12, 0.08, 0.56), dark_mat)
			_tail = Node3D.new(); _tail.position.z = 1.03; _visual.add_child(_tail)
			_add_tail_fluke(_tail, light_mat)
		"reef_shark":
			_add_ellipsoid(Vector3.ZERO, Vector3(0.52, 0.38, 1.38), body_mat)
			_add_ellipsoid(Vector3(0.0, 0.0, -1.35), Vector3(0.29, 0.2, 0.58), light_mat)
			_add_ellipsoid(Vector3(0.0, 0.26, 0.25), Vector3(0.12, 0.36, 0.28), dark_mat)
			_left_fin = _add_ellipsoid(Vector3(-0.58, -0.12, 0.18), Vector3(0.16, 0.08, 0.62), dark_mat)
			_right_fin = _add_ellipsoid(Vector3(0.58, -0.12, 0.18), Vector3(0.16, 0.08, 0.62), dark_mat)
			_tail = Node3D.new(); _tail.position.z = 1.15; _visual.add_child(_tail)
			_add_tail_fluke(_tail, body_mat)
		"jellyfish":
			_add_ellipsoid(Vector3(0.0, 0.2, 0.0), Vector3(0.48, 0.42, 0.48), light_mat)
			for i in range(7):
				var tentacle := _add_ellipsoid(Vector3(-0.36 + float(i) * 0.12, -0.38, 0.0), Vector3(0.035, 0.48 + randf() * 0.24, 0.035), body_mat)
				tentacle.rotation.z = randf_range(-0.2, 0.2)
			var glow := OmniLight3D.new(); glow.light_color = body_color; glow.light_energy = 0.5; glow.omni_range = 3.0; glow.position.y = 0.2; _visual.add_child(glow)
		"whale_shark", "giant_shark":
			_add_ellipsoid(Vector3.ZERO, Vector3(0.95, 0.62, 2.25), body_mat)
			_add_ellipsoid(Vector3(0.0, -0.24, 0.15), Vector3(0.85, 0.28, 1.55), light_mat)
			_left_fin = _add_ellipsoid(Vector3(-1.0, -0.14, 0.32), Vector3(0.23, 0.11, 0.84), dark_mat)
			_right_fin = _add_ellipsoid(Vector3(1.0, -0.14, 0.32), Vector3(0.23, 0.11, 0.84), dark_mat)
			_tail = Node3D.new(); _tail.position.z = 2.0; _visual.add_child(_tail)
			_add_tail_fluke(_tail, body_mat)
		"leviathan", "abyssal_leviathan", "deep_sea_kraken":
			_add_ellipsoid(Vector3.ZERO, Vector3(1.25, 0.92, 3.5), body_mat)
			_add_ellipsoid(Vector3(0.0, -0.38, 0.6), Vector3(1.05, 0.35, 2.6), light_mat)
			_left_fin = _add_ellipsoid(Vector3(-1.55, -0.18, 0.2), Vector3(0.34, 0.16, 1.25), dark_mat)
			_right_fin = _add_ellipsoid(Vector3(1.55, -0.18, 0.2), Vector3(0.34, 0.16, 1.25), dark_mat)
			_tail = Node3D.new(); _tail.position.z = 3.0; _visual.add_child(_tail)
			_add_tail_fluke(_tail, body_mat)
			for tentacle_index in range(6):
				var tentacle := _add_ellipsoid(Vector3(-0.9 + float(tentacle_index) * 0.36, -0.9, -1.2), Vector3(0.12, 1.1, 0.12), dark_mat)
				tentacle.rotation.z = -0.22 + float(tentacle_index) * 0.08
	if _visual:
		_visual.scale = Vector3.ONE * body_scale

func _add_tail_fluke(parent: Node3D, material: Material) -> void:
	var fin_a := MeshInstance3D.new()
	var mesh_a := SphereMesh.new(); mesh_a.radius = 0.34; mesh_a.height = 0.12
	fin_a.mesh = mesh_a; fin_a.material_override = material
	fin_a.position = Vector3(-0.2, 0.0, 0.12); fin_a.rotation.z = -0.35; fin_a.scale = Vector3(0.7, 0.7, 1.0); parent.add_child(fin_a)
	var fin_b := MeshInstance3D.new()
	var mesh_b := SphereMesh.new(); mesh_b.radius = 0.34; mesh_b.height = 0.12
	fin_b.mesh = mesh_b; fin_b.material_override = material
	fin_b.position = Vector3(0.2, 0.0, 0.12); fin_b.rotation.z = 0.35; fin_b.scale = Vector3(0.7, 0.7, 1.0); parent.add_child(fin_b)

func _add_ellipsoid(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var sphere := SphereMesh.new(); sphere.radial_segments = 20; sphere.rings = 12
	mesh_instance.mesh = sphere
	mesh_instance.material_override = material
	mesh_instance.position = pos
	mesh_instance.scale = scale_value
	_visual.add_child(mesh_instance)
	return mesh_instance

func _mat(color: Color, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = 0.06
	return material

func _process(delta: float) -> void:
	_observe_cooldown = maxf(_observe_cooldown - delta, 0.0)
	if is_hostile:
		_process_hostile_swimming(delta)
		return
	_turn_clock += delta
	_animation_clock += delta
	if _turn_clock > randf_range(3.0, 6.0):
		_turn_clock = 0.0
		_direction = Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0)).normalized()
	var next := global_position + _direction * _speed * delta
	var ground_height := _noise.get_height(next.x, next.z) if _noise else -3.0
	if ground_height > -0.65:
		_direction = (home - global_position); _direction.y = 0.0
		if _direction.length() < 0.1:
			_direction = -_direction
		_direction = _direction.normalized()
		next = global_position + _direction * _speed * delta
		ground_height = _noise.get_height(next.x, next.z) if _noise else -3.0
	next.y = maxf(ground_height + 0.95, -2.8) + sin(_animation_clock * 1.35) * 0.08
	if global_position.distance_to(home) > 32.0:
		_direction = (home - global_position); _direction.y = 0.0
		if _direction.length() > 0.1:
			_direction = _direction.normalized()
	global_position = next
	if _direction.length() > 0.1:
		look_at(global_position + _direction, Vector3.UP)
	if _tail:
		_tail.rotation.y = sin(_animation_clock * 3.2) * 0.35
	if _left_fin:
		_left_fin.rotation.z = sin(_animation_clock * 2.6) * 0.16
	if _right_fin:
		_right_fin.rotation.z = -sin(_animation_clock * 2.6) * 0.16
	if creature_id == "jellyfish" and _visual:
		_visual.scale.y = body_scale * (1.0 + sin(_animation_clock * 2.0) * 0.09)


func _process_hostile_swimming(delta: float) -> void:
	if _dead:
		return
	_attack_cooldown = maxf(_attack_cooldown - delta, 0.0)
	_surge_cooldown = maxf(_surge_cooldown - delta, 0.0)
	_undertow_cooldown = maxf(_undertow_cooldown - delta, 0.0)
	_animation_clock += delta
	var player: Node3D = null
	var nearest_player_distance := INF
	for player_value in get_tree().get_nodes_in_group("player"):
		if not player_value is Node3D or not is_instance_valid(player_value): continue
		if not bool(player_value.get("is_swimming")): continue
		var player_distance := global_position.distance_to((player_value as Node3D).global_position)
		if player_distance < nearest_player_distance:
			nearest_player_distance = player_distance
			player = player_value as Node3D
	if player == null and GameManager.player is Node3D and bool(GameManager.player.get("is_swimming")):
		player = GameManager.player
	if player == null:
		_target_player = null
		_swim_roam(delta)
		return
	var horizontal_distance := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z).length()
	var vertical_distance := absf(player.global_position.y - global_position.y)
	var aggro := 25.0 if is_deep_boss else (18.0 if creature_id == "giant_shark" else 12.0)
	if horizontal_distance > aggro or vertical_distance > 12.0:
		_target_player = null
		_swim_roam(delta)
		return
	_target_player = player
	var offset := player.global_position - global_position
	var distance := offset.length()
	if distance > 0.1:
		_direction = offset.normalized()
		var speed_mult := 1.0
		if creature_id == "giant_shark" and _surge_cooldown <= 0.0:
			speed_mult = 2.15
			_surge_cooldown = 5.0
		elif creature_id in ["leviathan", "abyssal_leviathan", "deep_sea_kraken"] and _surge_cooldown <= 0.0:
			speed_mult = 2.4
			_surge_cooldown = 7.0
		else:
			speed_mult = 0.82 if is_deep_boss else 1.0
		global_position += _direction * swim_speed * speed_mult * delta
		var bed_height := _noise.get_height(global_position.x, global_position.z) if _noise else -8.0
		global_position.y = clampf(global_position.y, bed_height + 1.4, TideSystem.current_level - 1.6)
		look_at(global_position + Vector3(_direction.x, _direction.y * 0.35, _direction.z), Vector3.UP)
	_phase_attack_clock = maxf(0.0, _phase_attack_clock - delta)
	if is_deep_boss and _boss_phase >= 2 and distance < 15.0 and _phase_attack_clock <= 0.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		_phase_attack_clock = 13.0 if _boss_phase == 2 else 8.0
		for diver in get_tree().get_nodes_in_group("player"):
			if diver is CharacterBody3D and bool(diver.get("is_swimming")) and (diver as Node3D).global_position.distance_to(global_position) < 13.0:
				var push := ((diver as Node3D).global_position - global_position).normalized()
				(diver as CharacterBody3D).velocity += push * (4.0 if _boss_phase == 2 else 6.5)
		EventBus.activity.emit("%s releases a crushing pressure pulse" % display_name, "combat")
	if is_deep_boss and creature_id == "deep_sea_kraken" and distance < 12.0 and _undertow_cooldown <= 0.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		_undertow_cooldown = 11.0
		if player is CharacterBody3D:
			var swimmer := player as CharacterBody3D
			var pull_direction := global_position - swimmer.global_position
			if pull_direction.length() > 0.1:
				swimmer.velocity += pull_direction.normalized() * 7.5
			EventBus.activity.emit("The Drowned Sovereign summons an undertow and drags you toward its tentacles", "combat")
	if distance <= attack_range and _attack_cooldown <= 0.0 and (not MMORPGNetwork.is_online() or MMORPGNetwork.is_authority()):
		_attack_cooldown = 2.2 if is_deep_boss else 3.0
		if player.has_method("take_damage"):
			player.take_damage(attack_damage, self)
			var attack_text := "lunges through the water" if creature_id == "giant_shark" else ("lashes out with crushing tentacles" if creature_id == "deep_sea_kraken" else "strikes from below")
			EventBus.activity.emit("%s %s" % [display_name, attack_text], "combat")
	if _tail:
		_tail.rotation.y = sin(_animation_clock * 4.2) * 0.48
	if _left_fin:
		_left_fin.rotation.z = sin(_animation_clock * 3.0) * 0.18
	if _right_fin:
		_right_fin.rotation.z = -sin(_animation_clock * 3.0) * 0.18

func _swim_roam(delta: float) -> void:
	_turn_clock += delta
	if _turn_clock > randf_range(2.0, 4.0):
		_turn_clock = 0.0
		_direction = Vector3(randf_range(-1.0, 1.0), randf_range(-0.25, 0.25), randf_range(-1.0, 1.0)).normalized()
	global_position += _direction * swim_speed * 0.42 * delta
	var bed := _noise.get_height(global_position.x, global_position.z) if _noise else -8.0
	var surface := TideSystem.current_level
	global_position.y = clampf(global_position.y, bed + 1.4, surface - 1.8)
	if _direction.length() > 0.1:
		look_at(global_position + Vector3(_direction.x, _direction.y * 0.3, _direction.z), Vector3.UP)
	if _tail:
		_tail.rotation.y = sin(_animation_clock * 3.2) * 0.35

func take_damage(amount: float, source: Node = null, crit: bool = false) -> void:
	if not is_hostile or _dead or amount <= 0.0:
		return
	if MMORPGNetwork.is_online() and not MMORPGNetwork.is_authority():
		return
	current_health = maxf(0.0, current_health - amount)
	if is_deep_boss:
		_update_boss_phase()
	EventBus.entity_damaged.emit(self, amount, source)
	if current_health <= 0.0:
		_die_marine()


func _update_boss_phase() -> void:
	var ratio := current_health / maxf(1.0, max_health)
	var next_phase := 3 if ratio <= 0.32 else (2 if ratio <= 0.66 else 1)
	if next_phase <= _boss_phase:
		return
	_boss_phase = next_phase
	if _boss_phase == 2:
		swim_speed *= 1.18
		attack_damage *= 1.18
		_surge_cooldown = 0.8
		EventBus.activity.emit("%s enters its enraged second phase. The current turns violent!" % display_name, "boss")
	else:
		swim_speed *= 1.22
		attack_damage *= 1.28
		attack_range *= 1.12
		_surge_cooldown = 0.4
		_undertow_cooldown = 1.0
		EventBus.activity.emit("%s enters its final abyssal phase. Pressure waves tear through the water!" % display_name, "boss")
	if _visual:
		_visual.scale = Vector3.ONE * body_scale * (1.08 if _boss_phase == 2 else 1.16)

func _die_marine() -> void:
	if _dead: return
	_dead = true
	remove_from_group("enemy")
	remove_from_group("marine_hostile")
	EventBus.activity.emit("%s has been defeated in the deep sea" % display_name, "combat")
	if MMORPGNetwork.is_online() and MMORPGNetwork.is_authority() and MMORPGNetwork.has_method("broadcast_marine_creature_despawn"):
		MMORPGNetwork.broadcast_marine_creature_despawn(self)
	queue_free()

func can_interact() -> bool:
	return _observe_cooldown <= 0.0

func get_prompt() -> String:
	return "Challenge %s" % display_name if is_hostile else "Observe %s" % display_name

func interact(player: Node3D = null) -> void:
	if is_hostile:
		EventBus.toast.emit("%s is a hostile deep-sea predator. Prepare for underwater combat." % display_name, "warning")
		return
	_observe_cooldown = 45.0
	PlayerData.stats["marine_observations"] = int(PlayerData.stats.get("marine_observations", 0)) + 1
	if player and player.get("skills") != null:
		player.skills.train("marine_lore", 0.9)
		player.skills.train("observation", 0.45)
		player.skills.train("knowledge", 0.35)
		player.skills.train("swimming", 0.18)
	if randf() < 0.3:
		PlayerData.add_item("field_notes", 1)
	EventBus.toast.emit("You observe the %s and record its behaviour in your field journal." % display_name, "levelup")
	EventBus.activity.emit("Observed marine wildlife: %s" % display_name, "exploration")
