extends Area3D

func can_interact() -> bool:
	return true

func get_prompt() -> String:
	return "Enter Depths of Elyndor"

func interact(_player: Node3D = null) -> void:
	var d = get_tree().get_first_node_in_group("dungeon")
	if d and d.has_method("enter_dungeon"):
		d.enter_dungeon()
