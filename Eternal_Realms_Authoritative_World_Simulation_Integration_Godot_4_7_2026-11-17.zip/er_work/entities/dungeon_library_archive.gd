extends Area3D

@export var floor_number: int = 5
@export var archive_id: String = "archive_005"
@export var civilization_name: String = "The Forgotten Civilization"
@export_multiline var fragment_lore: String = "A damaged archive fragment waits to be transcribed."

var interact_range: float = 3.8
var _read: bool = false
var _pulse: float = 0.0
var _core: MeshInstance3D
var _light: OmniLight3D

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("dungeon_discovery")
	collision_layer = 0
	collision_mask = 0
	var known: Dictionary = PlayerData.stats.get("ancient_archive_discoveries", {})
	_read = known.has(archive_id)
	_build_archive()

func _process(delta: float) -> void:
	_pulse += delta
	if _core:
		_core.rotation.y += delta * 0.22
		_core.position.y = 1.55 + sin(_pulse * 1.5) * 0.07
	if _light:
		_light.light_energy = 0.55 + (sin(_pulse * 2.0) + 1.0) * 0.16

func can_interact() -> bool:
	return not _read

func get_prompt() -> String:
	return "Transcribe %s Archive" % civilization_name if not _read else "Archive already transcribed"

func interact(player: Node3D = null) -> void:
	if _read:
		return
	_read = true
	if AncientInheritanceSystem.record_archive_fragment(floor_number, archive_id):
		var dungeon: Node = get_tree().get_first_node_in_group("dungeon")
		if dungeon and dungeon.has_method("mark_discovery"):
			dungeon.mark_discovery(floor_number - 1, "legacy_archive")
		EventBus.toast.emit(fragment_lore, "discovery")
	else:
		_read = false

func _build_archive() -> void:
	var dark := _mat(Color(0.16, 0.12, 0.09), false)
	var brass := _mat(Color(0.58, 0.39, 0.16), false)
	var glow := _mat(Color(0.42, 0.78, 1.0), true)
	var shelf := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(2.25, 1.55, 0.7)
	shelf.mesh = box
	shelf.material_override = dark
	shelf.position.y = 0.78
	add_child(shelf)
	for level in range(3):
		var rail := MeshInstance3D.new()
		var rail_mesh := BoxMesh.new()
		rail_mesh.size = Vector3(2.42, 0.09, 0.82)
		rail.mesh = rail_mesh
		rail.material_override = brass
		rail.position = Vector3(0.0, 0.3 + float(level) * 0.48, 0.0)
		add_child(rail)
	for scroll_i in range(5):
		var scroll := MeshInstance3D.new()
		var scroll_mesh := CylinderMesh.new()
		scroll_mesh.top_radius = 0.095
		scroll_mesh.bottom_radius = 0.095
		scroll_mesh.height = 0.52
		scroll.mesh = scroll_mesh
		scroll.material_override = glow if scroll_i == 2 else brass
		scroll.position = Vector3(-0.83 + float(scroll_i) * 0.41, 1.15, 0.0)
		scroll.rotation.z = PI * 0.5
		add_child(scroll)
	_core = MeshInstance3D.new()
	var core_mesh := PrismMesh.new()
	core_mesh.size = Vector3(0.46, 0.58, 0.46)
	_core.mesh = core_mesh
	_core.material_override = glow
	_core.position = Vector3(0.0, 1.55, -0.54)
	add_child(_core)
	var label := Label3D.new()
	label.text = "%s\nFLOOR %d" % [civilization_name.to_upper(), floor_number]
	label.font_size = 22
	label.outline_size = 6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.position.y = 2.45
	label.pixel_size = 0.006
	add_child(label)
	_light = OmniLight3D.new()
	_light.light_color = Color(0.42, 0.78, 1.0)
	_light.light_energy = 0.8
	_light.omni_range = 5.5
	_light.position.y = 1.8
	add_child(_light)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 2.1
	collision.shape = shape
	add_child(collision)

func _mat(color: Color, emissive: bool) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.72
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.4
	return material
