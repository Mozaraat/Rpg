extends Node3D

var _phase := 0.0
var _banner: Node3D
var _light: OmniLight3D

func _ready() -> void:
    _banner = get_node_or_null("Banner") as Node3D
    _light = get_node_or_null("EventLight") as OmniLight3D
    _phase = randf() * TAU

func _process(delta: float) -> void:
    _phase += delta
    if is_instance_valid(_banner):
        _banner.rotation.z = sin(_phase * 1.3) * 0.045
        _banner.rotation.x = cos(_phase * 0.8) * 0.025
    if is_instance_valid(_light):
        _light.light_energy = 1.0 + sin(_phase * 2.2) * 0.18
