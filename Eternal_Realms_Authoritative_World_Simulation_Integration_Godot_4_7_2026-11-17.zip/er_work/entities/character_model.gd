# CharacterModel - a detailed rigged character with a procedural silhouette fallback.
# The scanned CC0 GLBs in res://assets/characters supply the close-up body and its
# walk/run clips; the procedural build is kept for distance LOD and as a fallback
# when an asset is missing. Faces -Z. Feet are at y = 0.
# Configure with build({...}); animate with set_motion()/play_attack().
class_name CharacterModel
extends Node3D

signal attack_impact   # emitted once per swing at the moment the blade should connect

var cfg: Dictionary = {}
var body_root: Node3D
var torso: Node3D
var head: Node3D
var leg_l: Node3D
var leg_r: Node3D
var knee_l: Node3D
var knee_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var elbow_l: Node3D
var elbow_r: Node3D
var hand_l: Node3D
var hand_r: Node3D
var _held_visual: Node3D
var _eye_root: Node3D
var _cape_root: Node3D
var _skirt_root: Node3D

# Asset-backed body (CC0 rigged GLB). Kept hidden when the player is far away so
# the cheaper procedural silhouette can take over.
var _asset_root: Node3D
var _asset_skeleton: Skeleton3D
var _asset_player: AnimationPlayer
var _asset_bone: Dictionary = {}
var _asset_meshes: Array[MeshInstance3D] = []
var _asset_weapon_attach: Node3D
var _asset_weapon: Node3D
var _asset_hand_bone: int = -1
var _asset_hand_basis_inv: Basis = Basis()
var _asset_back_attach: Node3D
var _asset_spine_bone: int = -1
var _overlay_rot: Dictionary = {}
var _asset_clip: String = "idle"
var _asset_idle_phase: float = 0.0
var _asset_near: bool = true
var _asset_far_check: float = 0.0
var _asset_dead_tween: Tween

const ASSET_DIR := "res://assets/characters/"
const ASSET_DETAIL_RANGE := 42.0
const ASSET_DETAIL_RANGE_HYST := 7.0
const ASSET_BONES: Array[String] = [
	"Hips", "Spine", "Spine01", "Spine02", "neck", "Head",
	"LeftShoulder", "LeftArm", "LeftForeArm", "LeftHand",
	"RightShoulder", "RightArm", "RightForeArm", "RightHand",
	"LeftUpLeg", "LeftLeg", "LeftFoot", "RightUpLeg", "RightLeg", "RightFoot",
]

var _mats: Array[StandardMaterial3D] = []
var _move: float = 0.0
var _target_move: float = 0.0
var _run: float = 0.0
var _target_run: float = 0.0
var _phase: float = 0.0
var _time: float = 0.0
var _attack_t: float = -1.0
var _attack_side: float = 1.0
var _impact_sent: bool = false
var _dead: bool = false
var _holds_weapon: bool = false
var _work_pose: String = ""
var _work_clock: float = 0.0
var _stealth_pose: float = 0.0
var _stealth_target: float = 0.0
var _stealth_attack: bool = false
var _blink_timer: float = 2.2
var _blink_t: float = -1.0
var attack_duration: float = 0.45
var _flash_tween: Tween
var _flash_saved: Array = []

const SKIN_TONES: Array[Color] = [
	Color(0.96, 0.78, 0.64), Color(0.88, 0.68, 0.52), Color(0.7, 0.49, 0.34), Color(0.49, 0.32, 0.23),
]
const EYE_TONES: Array[Color] = [
	Color(0.25, 0.16, 0.09), Color(0.18, 0.29, 0.4), Color(0.19, 0.36, 0.27),
	Color(0.38, 0.28, 0.48), Color(0.44, 0.38, 0.3),
]

func _c(key: String, default: Variant) -> Variant:
	return cfg.get(key, default)

func build(c: Dictionary) -> void:
	cfg = c
	if _flash_tween and _flash_tween.is_valid():
		_flash_tween.kill()
	_flash_saved.clear()
	for ch in get_children():
		ch.queue_free()
	_mats.clear()
	body_root = null
	torso = null
	head = null
	leg_l = null
	leg_r = null
	knee_l = null
	knee_r = null
	arm_l = null
	arm_r = null
	elbow_l = null
	elbow_r = null
	hand_l = null
	hand_r = null
	_held_visual = null
	_eye_root = null
	_cape_root = null
	_skirt_root = null
	if _asset_dead_tween and _asset_dead_tween.is_valid():
		_asset_dead_tween.kill()
	_asset_root = null
	_asset_skeleton = null
	_asset_player = null
	_asset_bone.clear()
	_asset_meshes.clear()
	_asset_weapon_attach = null
	_asset_weapon = null
	_asset_hand_bone = -1
	_asset_hand_basis_inv = Basis()
	_asset_back_attach = null
	_asset_spine_bone = -1
	_overlay_rot.clear()
	_asset_clip = "idle"
	_asset_idle_phase = 0.0
	_asset_near = true
	_asset_far_check = 0.0
	_dead = false
	_attack_t = -1.0
	_move = 0.0
	_target_move = 0.0
	_phase = 0.0
	_blink_timer = randf_range(1.4, 3.6)
	_blink_t = -1.0

	var skin: Color = _c("skin", SKIN_TONES[0])
	var hair_col: Color = _c("hair", Color(0.25, 0.16, 0.1))
	var shirt: Color = _c("shirt", Color(0.2, 0.45, 0.6))
	var pants: Color = _c("pants", Color(0.35, 0.25, 0.18))
	var boots: Color = _c("boots", Color(0.2, 0.13, 0.08))
	var accent: Color = _c("accent", Color(0.8, 0.65, 0.25))
	var robe: bool = _c("robe", false)
	var dress: bool = _c("dress", false)
	var bulk: float = float(_c("bulk", 1.0))
	var armoured: bool = bool(_c("armour", false))
	var frame: String = str(_c("frame", "female" if dress else "male"))
	var eye_col: Color = _c("eye", EYE_TONES[0])
	var shoulder_scale: float = 1.0 if frame != "female" else 0.93
	if dress:
		shoulder_scale *= 0.96
	var waist_scale: float = 1.0 if frame != "female" else 0.9

	var m_skin: StandardMaterial3D = _mat_skin(skin)
	var m_skin_shadow: StandardMaterial3D = _mat_skin(skin.darkened(0.07))
	var m_hair: StandardMaterial3D = _mat_hair(hair_col)
	var m_hair_hi: StandardMaterial3D = _mat_hair(hair_col.lightened(0.16))
	var m_shirt: StandardMaterial3D = _mat_cloth(shirt)
	var m_shirt_dark: StandardMaterial3D = _mat_cloth(shirt.darkened(0.17))
	var m_pants: StandardMaterial3D = _mat_cloth(pants)
	var m_pants_dark: StandardMaterial3D = _mat_cloth(pants.darkened(0.15))
	var m_boot: StandardMaterial3D = _mat_leather(boots)
	var m_leather: StandardMaterial3D = _mat_leather(boots.darkened(0.14))
	var m_accent: StandardMaterial3D = _mat_metal(accent)
	var m_accent_dark: StandardMaterial3D = _mat_metal(accent.darkened(0.12))
	var m_metal: StandardMaterial3D = _mat_metal(accent.lightened(0.1))
	var m_dark: StandardMaterial3D = _mat(Color(0.045, 0.04, 0.042), 0.5, 0.1)
	var m_lip: StandardMaterial3D = _mat(skin.lerp(Color(0.62, 0.22, 0.24), 0.42), 0.5)
	var m_lip_hi: StandardMaterial3D = _mat(skin.lerp(Color(0.72, 0.32, 0.32), 0.4), 0.42)
	var m_eye_white: StandardMaterial3D = _mat(Color(0.87, 0.86, 0.84), 0.26)
	var m_iris: StandardMaterial3D = _mat(eye_col, 0.24)
	var m_pupil: StandardMaterial3D = _mat(Color(0.012, 0.011, 0.011), 0.28)
	var m_catch: StandardMaterial3D = _mat(Color(1.0, 1.0, 1.0), 0.08)
	for eye_mat in [m_eye_white, m_iris, m_pupil, m_catch]:
		eye_mat.rim_enabled = false
	m_iris.emission_enabled = true
	m_iris.emission = eye_col.darkened(0.15)
	m_iris.emission_energy_multiplier = 0.22
	m_catch.emission_enabled = true
	m_catch.emission = Color(1.0, 1.0, 1.0)
	m_catch.emission_energy_multiplier = 0.55

	body_root = Node3D.new()
	body_root.name = "Body"
	add_child(body_root)

	# --- Legs: long thighs, shaped calves, layered boots ---
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.105 * bulk, 0.92, 0)
		body_root.add_child(leg)
		_lathe(leg, [
			Vector2(0.056, -0.44), Vector2(0.061, -0.36), Vector2(0.072, -0.26),
			Vector2(0.083, -0.13), Vector2(0.087, -0.02), Vector2(0.084, 0.02),
		], m_pants, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 18)
		_cyl(leg, 0.083 * bulk, 0.084 * bulk, 0.012, m_pants_dark, Vector3(0, -0.2, 0), 16)
		_cyl(leg, 0.079 * bulk, 0.08 * bulk, 0.009, m_pants_dark, Vector3(0, -0.34, 0), 16)
		var knee := Node3D.new()
		knee.position = Vector3(0, -0.44, 0)
		leg.add_child(knee)
		_sph(knee, 0.062, m_pants, Vector3(0, 0.005, -0.004), Vector3(1.0, 0.9, 1.0))
		_lathe(knee, [
			Vector2(0.043, -0.42), Vector2(0.055, -0.3), Vector2(0.066, -0.18),
			Vector2(0.061, -0.08), Vector2(0.057, 0.0),
		], m_pants, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 16)
		# boot shaft with a soft leather cuff
		_lathe(knee, [
			Vector2(0.0835, -0.44), Vector2(0.076, -0.39), Vector2(0.069, -0.31),
			Vector2(0.066, -0.25), Vector2(0.074, -0.225),
		], m_boot, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 18)
		_cyl(knee, 0.078 * bulk, 0.078 * bulk, 0.016, m_boot, Vector3(0, -0.225, 0), 18)
		_cyl(knee, 0.08 * bulk, 0.08 * bulk, 0.007, m_leather, Vector3(0, -0.236, 0), 18)
		_sph(knee, 0.057, m_boot, Vector3(0, -0.4, 0.0), Vector3(1.0, 0.8, 1.0))
		_box(knee, Vector3(0.11, 0.078, 0.23), m_boot, Vector3(0, -0.44, -0.055))
		_sph(knee, 0.058, m_boot, Vector3(0, -0.447, -0.16), Vector3(0.92, 0.62, 1.35))
		_box(knee, Vector3(0.098, 0.068, 0.075), m_boot, Vector3(0, -0.45, 0.065))
		_box(knee, Vector3(0.116, 0.018, 0.285), m_dark, Vector3(0, -0.474, -0.052))
		_box(knee, Vector3(0.1, 0.012, 0.11), m_leather, Vector3(0, -0.408, -0.115))
		for lace_i in range(3):
			_box(knee, Vector3(0.058, 0.009, 0.009), m_leather, Vector3(0, -0.414 + float(lace_i) * 0.012, -0.145 + float(lace_i) * 0.012))
		if side < 0.0:
			leg_l = leg
			knee_l = knee
		else:
			leg_r = leg
			knee_r = knee

	# --- Hips / waist ---
	_lathe(body_root, [
		Vector2(0.148, -0.1), Vector2(0.168, -0.02), Vector2(0.171, 0.07),
		Vector2(0.162, 0.14), Vector2(0.152, 0.18),
	], m_pants, Vector3.ZERO, Vector3(1.1 * bulk, 1.0, 0.82), 20)
	if not robe and not dress:
		# Short travelling tunic over the hips, with a stitched hem.
		_lathe(body_root, [
			Vector2(0.208, -0.2), Vector2(0.196, -0.12), Vector2(0.186, -0.04),
			Vector2(0.177, 0.0), Vector2(0.17, 0.02),
		], m_shirt, Vector3.ZERO, Vector3(1.1 * bulk, 1.0, 0.86), 22)
		_cyl(body_root, 0.211 * bulk, 0.211 * bulk, 0.02, m_shirt_dark, Vector3(0, -0.2, 0), 22)
		_box(body_root, Vector3(0.06, 0.14, 0.02), m_shirt_dark, Vector3(0, -0.14, -0.205 * bulk))

	# --- Torso: shaped chest, narrow waist, trapezius and collarbones ---
	torso = Node3D.new()
	torso.position = Vector3(0, 0.98, 0)
	body_root.add_child(torso)
	var chest_profile := [
		Vector2(0.148 * waist_scale, -0.05), Vector2(0.152 * waist_scale, 0.03),
		Vector2(0.168, 0.13), Vector2(0.191, 0.26), Vector2(0.197, 0.36),
		Vector2(0.188, 0.44), Vector2(0.152, 0.51), Vector2(0.1, 0.57),
		Vector2(0.075, 0.61),
	]
	_lathe(torso, chest_profile, m_shirt, Vector3.ZERO, Vector3(1.13 * bulk * shoulder_scale, 1.0, 0.76), 24)
	# Cloth folds and the seam of the tunic.
	_cyl(torso, 0.163 * bulk, 0.163 * bulk, 0.008, m_shirt_dark, Vector3(0, 0.065, 0), 22).scale = Vector3(1.13 * shoulder_scale, 1.0, 0.76)
	_cyl(torso, 0.181 * bulk, 0.181 * bulk, 0.008, m_shirt_dark, Vector3(0, 0.17, 0), 22).scale = Vector3(1.13 * shoulder_scale, 1.0, 0.76)
	_box(torso, Vector3(0.012, 0.36, 0.012), m_shirt_dark, Vector3(0, 0.25, -0.147 * bulk))
	# Neck and trapezius; the collar hides the seam.
	_lathe(torso, [
		Vector2(0.06, 0.55), Vector2(0.058, 0.62), Vector2(0.052, 0.68), Vector2(0.05, 0.7),
	], m_skin, Vector3.ZERO, Vector3(1.0, 1.0, 0.92), 16)
	_sph(torso, 0.07, m_skin_shadow, Vector3(0, 0.555, -0.045), Vector3(1.25, 0.42, 0.7))
	for side in [-1.0, 1.0]:
		var clavicle: MeshInstance3D = _box(torso, Vector3(0.095, 0.014, 0.014), m_skin_shadow, Vector3(side * 0.075, 0.555, -0.102))
		clavicle.rotation.z = side * 0.12
	# Open collar V: skin at the throat and two folded edges.
	_sph(torso, 0.052, m_skin, Vector3(0, 0.542, -0.1), Vector3(0.42, 0.58, 0.16))
	for side in [-1.0, 1.0]:
		var collar: MeshInstance3D = _box(torso, Vector3(0.03, 0.13, 0.012), m_shirt_dark, Vector3(side * 0.034, 0.512, -0.115))
		collar.rotation.z = side * 0.34
		_box(torso, Vector3(0.012, 0.128, 0.006), m_accent, Vector3(side * 0.046, 0.512, -0.121)).rotation.z = side * 0.34
	# Belt with a real buckle, keeper loops and a hip pouch.
	var belt_mesh := TorusMesh.new()
	belt_mesh.inner_radius = 0.153 * bulk
	belt_mesh.outer_radius = 0.176 * bulk
	belt_mesh.rings = 24
	belt_mesh.ring_segments = 8
	_add(torso, belt_mesh, m_leather, Vector3(0, 0.025, 0), Vector3(1.16, 1.0, 0.78))
	_box(torso, Vector3(0.07, 0.065, 0.02), m_accent, Vector3(0, 0.025, -0.128 * bulk))
	_box(torso, Vector3(0.042, 0.036, 0.01), m_dark, Vector3(0, 0.024, -0.138 * bulk))
	for side in [-1.0, 1.0]:
		_box(torso, Vector3(0.014, 0.08, 0.025), m_leather, Vector3(side * 0.1, 0.02, -0.105 * bulk))
	# Shoulder harness, strap, stitched edging, belt kit.
	if not robe and not dress:
		var harness: MeshInstance3D = _box(torso, Vector3(0.055, 0.56, 0.024), m_leather, Vector3(0.078 * bulk, 0.29, -0.148 * bulk))
		harness.rotation.z = -0.36
		_box(torso, Vector3(0.069, 0.052, 0.03), m_accent, Vector3(0.078 * bulk, 0.29, -0.161 * bulk)).rotation.z = -0.36
		for side in [-1.0, 1.0]:
			_box(torso, Vector3(0.011, 0.33, 0.008), m_accent, Vector3(side * 0.142, 0.29, -0.140 * bulk))
		_box(torso, Vector3(0.13, 0.16, 0.09), m_leather, Vector3(0.172 * bulk, -0.015, -0.105 * bulk))
		_box(torso, Vector3(0.142, 0.025, 0.096), m_boot, Vector3(0.172 * bulk, 0.072, -0.11 * bulk))
		_sph(torso, 0.018, m_accent, Vector3(0.172 * bulk, 0.068, -0.162 * bulk))
	# A small travelling charm at the sternum.
	_cyl(torso, 0.004, 0.004, 0.12, m_leather, Vector3(0, 0.47, -0.136), 6)
	_sph(torso, 0.023, m_accent, Vector3(0, 0.405, -0.14), Vector3(0.7, 1.0, 0.4))
	_sph(torso, 0.014, m_dark, Vector3(0, 0.407, -0.15), Vector3(0.7, 1.0, 0.35))
	# Shoulders: cloth caps, replaced or layered by steel when armoured.
	for side in [-1.0, 1.0]:
		var pauldron: MeshInstance3D = _sph(torso, 0.078 * bulk, m_shirt_dark, Vector3(side * 0.19 * bulk * shoulder_scale, 0.478, 0.0), Vector3(1.24, 0.62, 0.98))
		pauldron.rotation.z = side * -0.16
		if armoured:
			var plate: MeshInstance3D = _sph(torso, 0.082 * bulk, m_metal, Vector3(side * 0.194 * bulk * shoulder_scale, 0.487, -0.004), Vector3(1.22, 0.48, 1.0))
			plate.rotation.z = side * -0.2
			var plate2: MeshInstance3D = _sph(torso, 0.072 * bulk, m_metal, Vector3(side * 0.204 * bulk * shoulder_scale, 0.448, -0.004), Vector3(1.02, 0.36, 0.92))
			plate2.rotation.z = side * -0.28
	if armoured:
		# Cuirass, abdomen plate, gorget and tassets sit over the tunic.
		_sph(torso, 0.16, m_metal, Vector3(0, 0.36, -0.098 * bulk), Vector3(1.15, 1.12, 0.42))
		_box(torso, Vector3(0.32 * bulk, 0.028, 0.035), m_accent, Vector3(0, 0.35, -0.153 * bulk))
		_sph(torso, 0.145, m_metal, Vector3(0, 0.17, -0.085 * bulk), Vector3(1.02, 0.82, 0.38))
		_box(torso, Vector3(0.29 * bulk, 0.026, 0.032), m_accent, Vector3(0, 0.17, -0.129 * bulk))
		var gorget := TorusMesh.new()
		gorget.inner_radius = 0.075
		gorget.outer_radius = 0.096
		gorget.rings = 20
		gorget.ring_segments = 8
		_add(torso, gorget, m_accent, Vector3(0, 0.555, 0), Vector3(1.0, 1.0, 0.9))
		for side in [-1.0, 1.0]:
			var tasset: MeshInstance3D = _box(torso, Vector3(0.09, 0.2, 0.035), m_metal, Vector3(side * 0.145, 0.03, -0.105 * bulk))
			tasset.rotation.z = side * 0.12
			tasset.rotation.x = -0.12
	if robe:
		# Crossed robe collar and a wide sash.
		for side in [-1.0, 1.0]:
			var lapel: MeshInstance3D = _box(torso, Vector3(0.075, 0.5, 0.018), m_shirt_dark, Vector3(side * 0.052, 0.34, -0.139 * bulk))
			lapel.rotation.z = side * 0.42
			_box(torso, Vector3(0.022, 0.48, 0.01), m_accent, Vector3(side * 0.083, 0.335, -0.149 * bulk)).rotation.z = side * 0.42
		var sash: MeshInstance3D = _cyl(torso, 0.174 * bulk, 0.174 * bulk, 0.1, m_accent, Vector3(0, 0.045, 0), 22)
		sash.scale = Vector3(1.19 * shoulder_scale, 1.0, 0.78)
		for i in range(3):
			_box(torso, Vector3(0.09, 0.014, 0.014), m_accent_dark, Vector3(-0.07 + float(i) * 0.07, 0.045, -0.147 * bulk)).rotation.z = -0.2 + float(i) * 0.2
	elif dress:
		# Bodice lacing.
		for i in range(4):
			var lace: MeshInstance3D = _box(torso, Vector3(0.07, 0.008, 0.008), m_accent, Vector3(0, 0.18 + float(i) * 0.06, -0.142 * bulk))
			lace.rotation.z = 0.5 if i % 2 == 0 else -0.5
		_box(torso, Vector3(0.13, 0.02, 0.02), m_accent, Vector3(0, 0.155, -0.145 * bulk))

	# Cape / cloak: a curved cloth sheet hung from the shoulders.
	if bool(_c("cape", false)):
		_cape_root = Node3D.new()
		_cape_root.position = Vector3(0, 0.5, 0.145)
		torso.add_child(_cape_root)
		var cape_mat: StandardMaterial3D = _mat_cloth(_c("cape_color", shirt.darkened(0.25)))
		cape_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		cape_mat.roughness = 0.92
		_add(_cape_root, _cape_mesh(0.34 * bulk, 0.52 * bulk, 0.98, 0.16), cape_mat, Vector3.ZERO)
		_cyl(_cape_root, 0.02, 0.035, 0.06, m_accent, Vector3(-0.09, -0.03, 0.0), 8)
		_cyl(_cape_root, 0.02, 0.035, 0.06, m_accent, Vector3(0.09, -0.03, 0.0), 8)
		_box(_cape_root, Vector3(0.27, 0.03, 0.02), m_accent, Vector3(0, -0.005, 0.012))

	if robe or dress:
		_skirt_root = Node3D.new()
		_skirt_root.position = Vector3(0, 0.94, 0)
		body_root.add_child(_skirt_root)
		var skirt_len: float = 0.78 if robe else 0.52
		var hem: float = 0.225 if robe else 0.2
		_lathe(_skirt_root, [
			Vector2(hem, -skirt_len), Vector2(hem * 0.94, -skirt_len * 0.78),
			Vector2(hem * 0.82, -skirt_len * 0.52), Vector2(hem * 0.65, -skirt_len * 0.26),
			Vector2(0.185, -0.04), Vector2(0.166, 0.0),
		], m_shirt, Vector3.ZERO, Vector3(1.04 * bulk, 1.0, 0.84), 26)
		_cyl(_skirt_root, hem * 1.01, hem * 1.01, 0.02, m_accent, Vector3(0, -skirt_len + 0.03, 0), 26).scale = Vector3(1.04 * bulk, 1.0, 0.84)
		for side in [-1.0, 1.0]:
			var front_trim: MeshInstance3D = _box(_skirt_root, Vector3(0.016, skirt_len * 0.72, 0.012), m_accent, Vector3(side * 0.055, -skirt_len * 0.44, -hem * 0.82))
			front_trim.rotation.x = -0.04
		if dress:
			_box(_skirt_root, Vector3(0.24, skirt_len * 0.7, 0.022), m_shirt_dark, Vector3(0, -skirt_len * 0.4, -hem * 0.86))
			for i in range(4):
				_cyl(_skirt_root, 0.006, 0.006, skirt_len * 0.55, m_accent, Vector3(-0.08 + float(i) * 0.053, -skirt_len * 0.35, -hem * 0.87 - 0.012), 6)

	# --- Arms ---
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.236 * bulk * shoulder_scale, 0.5, 0)
		arm.rotation.z = side * 0.05
		torso.add_child(arm)
		_sph(arm, 0.082 * bulk, m_shirt, Vector3.ZERO, Vector3(1.18, 0.95, 1.02))
		if robe:
			# Hanging sleeve that widens below the elbow.
			_lathe(arm, [
				Vector2(0.085, -0.34), Vector2(0.1, -0.28), Vector2(0.092, -0.2),
				Vector2(0.075, -0.1), Vector2(0.072, 0.0),
			], m_shirt, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 18)
			_lock(arm, 0.2, 0.08, 0.03, 0.04, m_shirt_dark, Vector3(side * 0.03, -0.33, 0.0), Vector3(0.3, 0.0, side * 0.15))
		else:
			_lathe(arm, [
				Vector2(0.05, -0.3), Vector2(0.055, -0.22), Vector2(0.062, -0.12),
				Vector2(0.061, -0.03), Vector2(0.058, 0.02),
			], m_shirt, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 16)
			_cyl(arm, 0.058 * bulk, 0.058 * bulk, 0.026, m_shirt_dark, Vector3(0, -0.292, 0), 16)
			_lock(arm, 0.09, 0.026, 0.012, 0.015, m_shirt_dark, Vector3(side * 0.028, -0.29, -0.045), Vector3(0.15, 0.0, side * 0.18))
		var elbow := Node3D.new()
		elbow.position = Vector3(0, -0.3, 0)
		arm.add_child(elbow)
		if not robe:
			_sph(elbow, 0.048 * bulk, m_skin, Vector3.ZERO, Vector3(1.0, 0.95, 1.0))
		_lathe(elbow, [
			Vector2(0.033, -0.27), Vector2(0.039, -0.2), Vector2(0.051, -0.11),
			Vector2(0.047, -0.04), Vector2(0.043, 0.0),
		], m_skin if not robe else m_shirt, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 16)
		# Leather bracer, metal cuff when armoured.
		var bracer_r: float = 0.053 if not robe else 0.056
		_lathe(elbow, [
			Vector2(bracer_r * 0.92, -0.245), Vector2(bracer_r, -0.21),
			Vector2(bracer_r, -0.165), Vector2(bracer_r * 0.94, -0.145),
		], m_leather, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 16)
		_cyl(elbow, bracer_r * 0.98, bracer_r * 1.02, 0.02, m_accent, Vector3(0, -0.248, 0), 16)
		if armoured:
			_lathe(elbow, [
				Vector2(0.042, -0.26), Vector2(0.059, -0.215), Vector2(0.061, -0.13),
				Vector2(0.055, -0.06), Vector2(0.05, 0.0),
			], m_metal, Vector3.ZERO, Vector3(bulk, 1.0, bulk), 16)
			_box(elbow, Vector3(0.09, 0.02, 0.06), m_accent, Vector3(0, -0.225, -0.03))
		var hand := Node3D.new()
		hand.position = Vector3(0, -0.275, 0)
		elbow.add_child(hand)
		_sph(hand, 0.047 * bulk, m_skin, Vector3(0, -0.012, 0), Vector3(0.92, 1.15, 0.58))
		for finger_i in range(4):
			var fx: float = (-0.028 + float(finger_i) * 0.0187) * bulk
			var fy: float = -0.065 + absf(float(finger_i) - 1.5) * 0.003
			var finger: MeshInstance3D = _cyl(hand, 0.0085 * bulk, 0.0075 * bulk, 0.055, m_skin, Vector3(fx, fy, -0.008), 8)
			finger.rotation.x = -0.32 - absf(float(finger_i) - 1.5) * 0.02
			_sph(hand, 0.009 * bulk, m_skin, Vector3(fx, fy - 0.026, -0.024), Vector3(1.0, 0.9, 1.1))
		var thumb: MeshInstance3D = _cyl(hand, 0.011 * bulk, 0.009 * bulk, 0.045, m_skin, Vector3(side * 0.036, -0.036, -0.012), 8)
		thumb.rotation.z = side * -0.6
		thumb.rotation.x = -0.35
		if armoured:
			_box(hand, Vector3(0.072, 0.05, 0.05), m_metal, Vector3(0, -0.005, 0.012))
			for knuckle_i in range(4):
				_sph(hand, 0.009, m_accent, Vector3(-0.027 + float(knuckle_i) * 0.018, -0.04, -0.024), Vector3(1.0, 1.0, 0.7))
		if side < 0.0:
			arm_l = arm
			elbow_l = elbow
			hand_l = hand
		else:
			arm_r = arm
			elbow_r = elbow
			hand_r = hand

	# --- Head: shaped cranium, jaw, cheeks, ears and a readable face ---
	head = Node3D.new()
	head.position = Vector3(0, 0.73, 0)
	torso.add_child(head)
	# The lathe skull has inward-facing winding depending on row order; rendering it
	# double-sided is cheaper than reordering and keeps the fallback head visible.
	var m_head_skin: StandardMaterial3D = m_skin.duplicate() as StandardMaterial3D
	m_head_skin.cull_mode = BaseMaterial3D.CULL_DISABLED
	_mats.append(m_head_skin)
	_add(head, _head_mesh(), m_head_skin, Vector3(0, 0.025, 0))
	# Ears with a darker inner fold.
	for side in [-1.0, 1.0]:
		var ear: MeshInstance3D = _sph(head, 0.03, m_skin, Vector3(side * 0.109, 0.022, 0.004), Vector3(0.34, 0.86, 0.68))
		ear.rotation.y = side * 0.18
		_sph(head, 0.018, m_skin_shadow, Vector3(side * 0.113, 0.024, -0.002), Vector3(0.3, 0.65, 0.5))
	# Eyes are grouped so both lids can blink together.
	_eye_root = Node3D.new()
	_eye_root.position = Vector3(0, 0.034, 0)
	head.add_child(_eye_root)
	for side in [-1.0, 1.0]:
		var ex: float = side * 0.045
		_sph(head, 0.021, m_skin_shadow, Vector3(ex, 0.031, -0.108), Vector3(1.5, 1.0, 0.2))
		_sph(_eye_root, 0.0175, m_eye_white, Vector3(ex, 0.0, -0.1105), Vector3(1.32, 0.92, 0.5))
		_sph(_eye_root, 0.0122, m_iris, Vector3(ex, 0.0005, -0.1175), Vector3(1.0, 1.0, 0.34))
		_sph(_eye_root, 0.0058, m_pupil, Vector3(ex, 0.0005, -0.1192), Vector3(1.0, 1.0, 0.4))
		_sph(_eye_root, 0.0034, m_catch, Vector3(ex - side * 0.003, 0.0055, -0.1235), Vector3(1.0, 1.0, 0.5))
		_sph(_eye_root, 0.0016, m_catch, Vector3(ex + side * 0.004, -0.0045, -0.1228))
		var lash: MeshInstance3D = _sph(head, 0.019, m_dark, Vector3(ex, 0.049, -0.1045), Vector3(1.45, 0.16, 0.32))
		lash.rotation.z = side * 0.09
		var brow: MeshInstance3D = _sph(head, 0.018, m_hair, Vector3(ex, 0.07, -0.098), Vector3(1.6, 0.2, 0.28))
		brow.rotation.z = side * 0.13
	# Nose bridge, tip and nostrils kept shallow so the face reads as sculpted.
	_sph(head, 0.016, m_skin, Vector3(0, 0.021, -0.112), Vector3(0.5, 1.35, 0.5))
	_sph(head, 0.0145, m_skin, Vector3(0, -0.011, -0.114), Vector3(1.15, 0.7, 0.62))
	_sph(head, 0.005, m_skin_shadow, Vector3(0.011, -0.021, -0.117), Vector3(0.8, 0.28, 0.4))
	_sph(head, 0.005, m_skin_shadow, Vector3(-0.011, -0.021, -0.117), Vector3(0.8, 0.28, 0.4))
	# Lips and mouth line.
	_sph(head, 0.0175, m_lip, Vector3(0, -0.044, -0.1105), Vector3(1.35, 0.2, 0.35))
	_sph(head, 0.0175, m_lip_hi, Vector3(0, -0.053, -0.107), Vector3(1.25, 0.22, 0.38))
	_cyl(head, 0.018, 0.018, 0.0028, m_dark, Vector3(0, -0.049, -0.1135), 14).scale = Vector3(1.0, 1.0, 0.35)

	var helm: String = str(_c("helm", "none"))
	var hair_style: String = str(_c("hair_style", "short"))
	if helm != "knight" and helm != "hood":
		_build_hair(head, hair_style, m_hair, m_hair_hi, hair_col)

	var beard: String = str(_c("beard", "none"))
	if beard != "none":
		var beard_col: Color = _c("beard_color", hair_col)
		_build_beard(head, beard, beard_col)

	if helm == "knight":
		_build_helm(head, "knight", m_metal, m_accent, m_dark, eye_col)
	elif helm == "open":
		_build_helm(head, "open", m_metal, m_accent, m_dark, eye_col)
	elif helm == "hood":
		_build_hood(head, m_shirt_dark, m_dark)
	elif helm == "crown":
		_build_crown(head, m_accent, m_metal, eye_col)

	var horns: String = str(_c("horns", "none"))
	if horns != "none":
		_build_horns(head, horns, m_dark, m_leather)

	var hat: String = str(_c("hat", "none"))
	if hat == "wizard" and helm == "none":
		var m_hat: StandardMaterial3D = _mat_cloth(_c("hat_color", shirt))
		_cyl(head, 0.215, 0.215, 0.022, m_hat, Vector3(0, 0.13, 0), 28).rotation.x = 0.05
		_cyl(head, 0.14, 0.146, 0.032, m_hat, Vector3(0, 0.152, 0.004), 22)
		var cone: MeshInstance3D = _cyl(head, 0.002, 0.145, 0.46, m_hat, Vector3(0, 0.39, 0.03), 20)
		cone.rotation.x = -0.12
		_cyl(head, 0.147, 0.147, 0.045, m_accent, Vector3(0, 0.157, 0.004), 22)
		_box(head, Vector3(0.04, 0.04, 0.01), m_accent, Vector3(0.105, 0.157, -0.085)).rotation.z = 0.2
		_sph(head, 0.007, m_accent, Vector3(0.105, 0.157, -0.092))
	elif hat == "straw" and helm == "none":
		var m_straw: StandardMaterial3D = _mat_cloth(Color(0.8, 0.65, 0.29))
		var m_straw_dark: StandardMaterial3D = _mat_cloth(Color(0.8, 0.65, 0.29).darkened(0.08))
		_cyl(head, 0.25, 0.25, 0.018, m_straw, Vector3(0, 0.128, 0), 30).rotation.x = 0.03
		_lathe(head, [
			Vector2(0.145, 0.128), Vector2(0.14, 0.175), Vector2(0.122, 0.215),
			Vector2(0.075, 0.245), Vector2(0.028, 0.256),
		], m_straw, Vector3.ZERO, Vector3(1.0, 1.0, 1.0), 24)
		_cyl(head, 0.146, 0.146, 0.026, m_leather, Vector3(0, 0.152, 0), 22)
		for i in range(5):
			var a: float = TAU * float(i) / 5.0
			_box(head, Vector3(0.01, 0.005, 0.085), m_straw_dark, Vector3(cos(a) * 0.2, 0.12, sin(a) * 0.2)).rotation.y = a

	# --- Held item (recreated when equipment changes) ---
	set_held_weapon(str(_c("held", "none")))

	# Static decorative meshes are merged per material after construction. This
	# keeps the extra detail from turning every NPC into dozens of draw calls.
	_merge_part(leg_l)
	_merge_part(knee_l)
	_merge_part(leg_r)
	_merge_part(knee_r)
	_merge_part(body_root)
	_merge_part(torso)
	_merge_part(arm_l)
	_merge_part(elbow_l)
	_merge_part(hand_l)
	_merge_part(arm_r)
	_merge_part(elbow_r)
	_merge_part(hand_r)
	_merge_part(head)
	_merge_part(_eye_root)

	var slug: String = _resolve_asset(cfg)
	if slug != "":
		_build_asset(slug)
	_merge_part(_cape_root)
	_merge_part(_skirt_root)

	set_process(true)

func _build_hair(head_node: Node3D, style: String, mat: StandardMaterial3D, hi: StandardMaterial3D, hair_col: Color) -> void:
	var cap: MeshInstance3D = _sph(head_node, 0.12, mat, Vector3(0, 0.046, 0.02), Vector3(1.04, 0.92, 0.98), true)
	cap.rotation.x = 0.1
	_sph(head_node, 0.111, mat, Vector3(0, 0.002, 0.043), Vector3(1.02, 1.03, 0.76))
	for side in [-1.0, 1.0]:
		_lock(head_node, 0.09, 0.028, 0.016, 0.01, mat, Vector3(side * 0.101, 0.04, 0.015), Vector3(-0.05, 0.0, side * 0.12))
	# Layered fringe with a soft side sweep, laid on the forehead surface.
	var bangs := [
		[-0.083, 0.05, 0.021], [-0.046, 0.062, 0.026],
		[-0.008, 0.07, 0.03], [0.03, 0.06, 0.027],
		[0.067, 0.048, 0.022],
	]
	for i in range(bangs.size()):
		var b: Array = bangs[i]
		var rot := Vector3(0.34 + absf(float(i) - 2.0) * 0.02, 0.0, (float(i) - 2.0) * 0.06)
		_lock(head_node, float(b[1]), float(b[2]), 0.014, 0.018, mat, Vector3(float(b[0]), 0.088, -0.084), rot)
	_lock(head_node, 0.1, 0.034, 0.015, 0.025, hi, Vector3(-0.032, 0.096, -0.082), Vector3(0.4, 0.0, -0.35))
	_lock(head_node, 0.085, 0.028, 0.014, 0.02, mat, Vector3(0.055, 0.096, -0.08), Vector3(0.36, 0.0, 0.32))
	# Side locks frame the jaw.
	_lock(head_node, 0.2, 0.026, 0.016, 0.025, mat, Vector3(-0.101, 0.035, -0.032), Vector3(-0.08, 0.0, 0.12))
	_lock(head_node, 0.19, 0.025, 0.015, 0.02, mat, Vector3(0.102, 0.03, -0.03), Vector3(-0.07, 0.0, -0.1))
	match style:
		"long":
			_sph(head_node, 0.1, mat, Vector3(0, -0.1, 0.088), Vector3(0.9, 1.65, 0.6))
			for i in range(5):
				var x: float = -0.081 + float(i) * 0.0405
				_lock(head_node, 0.52 - absf(float(i) - 2.0) * 0.05, 0.034, 0.019, 0.06, mat, Vector3(x, 0.02, 0.082), Vector3(0.1, 0.0, x * 1.6))
			_lock(head_node, 0.36, 0.03, 0.017, 0.02, hi, Vector3(-0.08, -0.01, 0.06), Vector3(0.08, 0.0, 0.2))
			_lock(head_node, 0.3, 0.022, 0.014, 0.03, mat, Vector3(-0.105, 0.03, -0.018), Vector3(-0.04, 0.0, 0.08))
			_lock(head_node, 0.3, 0.022, 0.014, 0.03, mat, Vector3(0.105, 0.028, -0.015), Vector3(-0.04, 0.0, -0.08))
		"bun":
			var bun: MeshInstance3D = _sph(head_node, 0.062, mat, Vector3(0, 0.135, 0.085), Vector3(1.0, 0.9, 0.9))
			bun.rotation.x = 0.2
			var wrap := TorusMesh.new()
			wrap.inner_radius = 0.045
			wrap.outer_radius = 0.06
			wrap.rings = 18
			wrap.ring_segments = 8
			var band: MeshInstance3D = _add(head_node, wrap, mat, Vector3(0, 0.12, 0.083))
			band.rotation.x = PI * 0.5
			_lock(head_node, 0.23, 0.024, 0.014, 0.03, mat, Vector3(-0.095, 0.03, 0.0), Vector3(-0.05, 0.0, 0.12))
			_lock(head_node, 0.2, 0.023, 0.013, 0.025, mat, Vector3(0.1, 0.02, 0.0), Vector3(-0.04, 0.0, -0.1))
			_cyl(head_node, 0.004, 0.004, 0.13, _mat_metal(Color(0.72, 0.58, 0.3)), Vector3(0, 0.135, 0.083), 6).rotation.z = 1.1
			_cyl(head_node, 0.004, 0.004, 0.13, _mat_metal(Color(0.72, 0.58, 0.3)), Vector3(0, 0.135, 0.083), 6).rotation.z = -1.1
		"wild":
			for i in range(8):
				var a: float = TAU * float(i) / 8.0
				_lock(head_node, 0.15 + float(i % 3) * 0.035, 0.026, 0.014, 0.03, mat, Vector3(cos(a) * 0.075, 0.1, sin(a) * 0.055), Vector3(0.45 - sin(a) * 0.35, 0.0, -cos(a) * 0.55))
			_lock(head_node, 0.18, 0.028, 0.016, 0.04, hi, Vector3(0.05, 0.1, -0.08), Vector3(-0.28, 0.0, 0.35))
		"ponytail":
			_sph(head_node, 0.04, mat, Vector3(0, 0.075, 0.108), Vector3(1.0, 0.8, 0.8))
			_lock(head_node, 0.42, 0.043, 0.025, 0.08, mat, Vector3(0, 0.06, 0.12), Vector3(1.05, 0.0, 0.0))
			_lock(head_node, 0.24, 0.028, 0.016, 0.03, hi, Vector3(0.015, 0.03, 0.14), Vector3(0.95, 0.0, 0.12))
		_:
			# Short: tapered nape and a little volume behind the ears.
			for side in [-1.0, 1.0]:
				_lock(head_node, 0.075, 0.028, 0.016, 0.01, mat, Vector3(side * 0.072, 0.02, 0.075), Vector3(0.3, 0.0, side * 0.1))
			_lock(head_node, 0.07, 0.026, 0.015, 0.02, mat, Vector3(0, -0.005, 0.085), Vector3(0.55, 0.0, 0.0))

func _build_beard(head_node: Node3D, style: String, beard_col: Color) -> void:
	var mat: StandardMaterial3D = _mat_hair(beard_col)
	var mustache_mat: StandardMaterial3D = _mat_hair(beard_col.lightened(0.06))
	for side in [-1.0, 1.0]:
		var m: MeshInstance3D = _sph(head_node, 0.018, mustache_mat, Vector3(side * 0.017, -0.036, -0.118), Vector3(1.45, 0.46, 0.45))
		m.rotation.z = side * 0.1
	_sph(head_node, 0.054, mat, Vector3(0, -0.063, -0.085), Vector3(1.3, 0.92, 0.72))
	for i in range(5):
		var x: float = -0.046 + float(i) * 0.023
		_lock(head_node, 0.095 + absf(float(i) - 2.0) * 0.012, 0.018, 0.012, 0.008, mat, Vector3(x, -0.072, -0.115), Vector3(-0.08, 0.0, (float(i) - 2.0) * 0.09))
	if style == "long":
		_lock(head_node, 0.34, 0.045, 0.028, 0.04, mat, Vector3(0, -0.11, -0.105), Vector3(-0.04, 0.0, 0.0))
		_lock(head_node, 0.27, 0.03, 0.02, 0.03, mustache_mat, Vector3(0.03, -0.1, -0.108), Vector3(-0.02, 0.0, 0.12))
		_lock(head_node, 0.25, 0.026, 0.018, 0.03, mat, Vector3(-0.035, -0.1, -0.108), Vector3(-0.02, 0.0, -0.1))

func _build_helm(head_node: Node3D, style: String, metal: StandardMaterial3D, trim: StandardMaterial3D, dark: StandardMaterial3D, glow_col: Color) -> void:
	if style == "knight":
		# Full visored helm; the face is hidden behind a slit and a nasal ridge.
		_lathe(head_node, [
			Vector2(0.135, -0.06), Vector2(0.142, -0.01), Vector2(0.145, 0.06),
			Vector2(0.137, 0.12), Vector2(0.11, 0.16), Vector2(0.06, 0.182), Vector2(0.02, 0.188),
		], metal, Vector3.ZERO, Vector3(1.0, 1.02, 1.04), 26)
		_box(head_node, Vector3(0.185, 0.02, 0.025), dark, Vector3(0, 0.038, -0.137))
		var glow := _mat(Color(glow_col.r, glow_col.g, glow_col.b), 0.2)
		glow.emission_enabled = true
		glow.emission = glow_col
		glow.emission_energy_multiplier = 1.6
		for side in [-1.0, 1.0]:
			_box(head_node, Vector3(0.036, 0.011, 0.008), glow, Vector3(side * 0.043, 0.038, -0.142))
		_box(head_node, Vector3(0.022, 0.15, 0.028), trim, Vector3(0, 0.02, -0.14))
		for side in [-1.0, 1.0]:
			var cheek: MeshInstance3D = _box(head_node, Vector3(0.03, 0.14, 0.14), metal, Vector3(side * 0.13, -0.015, -0.025))
			cheek.rotation.z = side * 0.1
			_box(head_node, Vector3(0.018, 0.08, 0.08), dark, Vector3(side * 0.121, 0.005, 0.0))
		_box(head_node, Vector3(0.03, 0.16, 0.22), trim, Vector3(0, 0.135, -0.025))
		var crest: MeshInstance3D = _box(head_node, Vector3(0.018, 0.12, 0.24), trim, Vector3(0, 0.17, 0.01))
		crest.rotation.x = -0.2
		_box(head_node, Vector3(0.24, 0.04, 0.08), metal, Vector3(0, -0.07, 0.035))
		_cyl(head_node, 0.142, 0.142, 0.022, trim, Vector3(0, -0.04, 0), 26)
	elif style == "open":
		var cap: MeshInstance3D = _sph(head_node, 0.139, metal, Vector3(0, 0.052, 0.008), Vector3(1.0, 0.9, 1.02), true)
		cap.rotation.x = 0.03
		_cyl(head_node, 0.142, 0.142, 0.025, trim, Vector3(0, 0.075, 0.005), 24)
		_box(head_node, Vector3(0.02, 0.13, 0.03), metal, Vector3(0, 0.035, -0.126))
		for side in [-1.0, 1.0]:
			var cheek: MeshInstance3D = _box(head_node, Vector3(0.028, 0.11, 0.1), metal, Vector3(side * 0.125, -0.005, -0.015))
			cheek.rotation.z = side * 0.08
			_sph(head_node, 0.012, trim, Vector3(side * 0.13, 0.055, -0.035))
		# Nasal guard leaves the eyes and mouth visible.
		_box(head_node, Vector3(0.11, 0.015, 0.02), trim, Vector3(0, 0.093, -0.122))

func _build_hood(head_node: Node3D, cloth: StandardMaterial3D, dark: StandardMaterial3D) -> void:
	var hood_mat: StandardMaterial3D = _mat_cloth(cloth.albedo_color.darkened(0.08))
	_sph(head_node, 0.142, hood_mat, Vector3(0, 0.02, 0.038), Vector3(1.12, 1.12, 1.0), true)
	_sph(head_node, 0.125, hood_mat, Vector3(0, -0.01, 0.075), Vector3(1.1, 1.16, 0.78))
	for side in [-1.0, 1.0]:
		_lock(head_node, 0.22, 0.052, 0.03, 0.03, hood_mat, Vector3(side * 0.13, 0.04, -0.01), Vector3(-0.08, 0.0, side * 0.08))
	_lock(head_node, 0.18, 0.04, 0.025, 0.01, hood_mat, Vector3(0, 0.105, -0.07), Vector3(-0.4, 0.0, 0.0))
	var rim := TorusMesh.new()
	rim.inner_radius = 0.102
	rim.outer_radius = 0.123
	rim.rings = 22
	rim.ring_segments = 8
	var rim_mi: MeshInstance3D = _add(head_node, rim, hood_mat, Vector3(0, 0.016, -0.092))
	rim_mi.rotation.x = PI * 0.5
	rim_mi.scale = Vector3(1.0, 1.12, 1.0)
	_sph(head_node, 0.07, dark, Vector3(0, 0.0, 0.015), Vector3(1.25, 1.3, 0.55))

func _build_crown(head_node: Node3D, trim: StandardMaterial3D, metal: StandardMaterial3D, gem_col: Color) -> void:
	var band := TorusMesh.new()
	band.inner_radius = 0.112
	band.outer_radius = 0.132
	band.rings = 24
	band.ring_segments = 8
	var band_mi: MeshInstance3D = _add(head_node, band, trim, Vector3(0, 0.12, 0.005))
	band_mi.rotation.x = PI * 0.5
	band_mi.scale = Vector3(1.0, 1.02, 1.0)
	var gem := _mat(gem_col, 0.15)
	gem.emission_enabled = true
	gem.emission = gem_col
	gem.emission_energy_multiplier = 0.8
	for i in range(7):
		var a: float = TAU * float(i) / 7.0
		var x: float = cos(a) * 0.118
		var z: float = sin(a) * 0.118 + 0.005
		var point: MeshInstance3D = _cyl(head_node, 0.002, 0.026, 0.1 + (0.04 if i % 2 == 0 else 0.0), trim, Vector3(x, 0.18, z), 6)
		point.rotation.z = -x * 1.4
		point.rotation.x = z * 1.4
		if i % 2 == 0:
			_sph(head_node, 0.013, gem, Vector3(x * 0.94, 0.137, z * 0.94))
	# A heavy brow circlet keeps the crown seated on the head.
	_cyl(head_node, 0.134, 0.134, 0.025, metal, Vector3(0, 0.105, 0.005), 26)

func _build_horns(head_node: Node3D, style: String, dark: StandardMaterial3D, wood: StandardMaterial3D) -> void:
	if style == "demon":
		for side in [-1.0, 1.0]:
			_lock(head_node, 0.24, 0.036, 0.03, 0.06, dark, Vector3(side * 0.09, 0.13, 0.005), Vector3(0.4, 0.0, side * 0.55))
			_lock(head_node, 0.12, 0.021, 0.018, 0.03, dark, Vector3(side * 0.135, 0.24, 0.06), Vector3(0.9, 0.0, side * 1.05))
	elif style == "antlers":
		for side in [-1.0, 1.0]:
			_lock(head_node, 0.28, 0.023, 0.019, 0.03, wood, Vector3(side * 0.075, 0.13, 0.02), Vector3(0.25, 0.0, side * 0.4))
			_lock(head_node, 0.16, 0.016, 0.013, 0.03, wood, Vector3(side * 0.12, 0.25, 0.03), Vector3(0.1, 0.0, side * 0.8))
			_lock(head_node, 0.13, 0.014, 0.012, 0.02, wood, Vector3(side * 0.11, 0.31, 0.055), Vector3(0.55, 0.0, side * 1.1))
			_lock(head_node, 0.11, 0.013, 0.011, 0.02, wood, Vector3(side * 0.16, 0.32, 0.06), Vector3(0.4, 0.0, side * 0.3))

# ---------------------------------------------------------------------------
# Held items
# ---------------------------------------------------------------------------
func set_held_weapon(held: String) -> void:
	if is_instance_valid(_held_visual):
		_held_visual.queue_free()
	_held_visual = null
	if is_instance_valid(_asset_weapon):
		_asset_weapon.queue_free()
	_asset_weapon = null
	_holds_weapon = held != "none"
	if held == "none":
		return
	if hand_r != null:
		_held_visual = _build_weapon_visual(hand_r, held)
	if _asset_weapon_attach != null:
		_asset_weapon = _build_weapon_visual(_asset_weapon_attach, held)
		_asset_weapon.rotation = Vector3(-0.16, 0.0, 0.12)
	if _held_visual == null and _asset_weapon == null:
		_holds_weapon = false

func _build_weapon_visual(parent: Node3D, held: String) -> Node3D:
	var w := Node3D.new()
	w.name = "HeldWeaponVisual"
	parent.add_child(w)
	if held == "sword":
		w.rotation.x = -1.75
		var steel: StandardMaterial3D = _mat(Color(0.82, 0.86, 0.92), 0.22, 0.95)
		var gold: StandardMaterial3D = _mat(Color(0.85, 0.68, 0.3), 0.32, 0.8)
		_cyl(w, 0.018, 0.018, 0.13, _mat(Color(0.25, 0.15, 0.08), 0.8), Vector3(0, -0.02, 0))
		for i in range(4):
			_cyl(w, 0.02, 0.02, 0.012, _mat(Color(0.38, 0.23, 0.12), 0.85), Vector3(0, -0.055 + float(i) * 0.027, 0), 8)
		_box(w, Vector3(0.19, 0.028, 0.038), gold, Vector3(0, 0.11, 0))
		_box(w, Vector3(0.055, 0.68, 0.014), steel, Vector3(0, 0.46, 0))
		_box(w, Vector3(0.011, 0.44, 0.016), _mat(Color(0.96, 0.97, 1.0), 0.18, 0.98), Vector3(0, 0.48, -0.01))
		_cyl(w, 0.0, 0.0235, 0.11, steel, Vector3(0, 0.805, 0), 4)
		_cyl(w, 0.026, 0.026, 0.036, gold, Vector3(0, -0.06, 0), 10)
		_sph(w, 0.027, gold, Vector3(0, -0.095, 0))
	elif held == "orb_staff":
		w.rotation.x = -0.12
		var wood: StandardMaterial3D = _mat(Color(0.3, 0.19, 0.1), 0.82)
		_cyl(w, 0.02, 0.026, 1.78, wood, Vector3(0, 0.46, 0))
		for i in range(6):
			var ring: MeshInstance3D = _cyl(w, 0.023, 0.023, 0.012, _mat(Color(0.55, 0.4, 0.18), 0.5, 0.4), Vector3(0, 0.22 + float(i) * 0.16, 0), 10)
			ring.rotation.z = 0.15 if i % 2 == 0 else -0.15
		var cradle := TorusMesh.new()
		cradle.inner_radius = 0.07
		cradle.outer_radius = 0.086
		cradle.rings = 20
		cradle.ring_segments = 8
		var cradle_mi: MeshInstance3D = _add(w, cradle, _mat(Color(0.8, 0.66, 0.32), 0.3, 0.8), Vector3(0, 1.35, 0))
		cradle_mi.rotation.x = PI * 0.5
		var orb_mat: StandardMaterial3D = _mat(Color(0.55, 0.74, 1.0), 0.08)
		orb_mat.emission_enabled = true
		orb_mat.emission = Color(0.45, 0.68, 1.0)
		orb_mat.emission_energy_multiplier = 3.0
		_sph(w, 0.09, orb_mat, Vector3(0, 1.35, 0))
		_sph(w, 0.036, _mat(Color(1, 1, 1), 0.05), Vector3(0, 1.35, 0.0))
	elif held in ["staff", "wand"]:
		w.rotation.x = -0.1
		var wood: StandardMaterial3D = _mat(Color(0.35, 0.22, 0.12), 0.85)
		_cyl(w, 0.022 if held == "staff" else 0.014, 0.028 if held == "staff" else 0.018, 1.75 if held == "staff" else 0.8, wood, Vector3(0, 0.45, 0))
		for i in range(4 if held == "staff" else 2):
			var wrap: MeshInstance3D = _cyl(w, 0.025, 0.025, 0.01, _mat(Color(0.5, 0.36, 0.18), 0.6, 0.3), Vector3(0, 0.18 + float(i) * 0.13, 0), 10)
			wrap.rotation.z = 0.2
		var orb_mat: StandardMaterial3D = _mat(Color(0.5, 0.7, 1.0), 0.1)
		orb_mat.emission_enabled = true
		orb_mat.emission = Color(0.4, 0.6, 1.0)
		orb_mat.emission_energy_multiplier = 2.5
		_sph(w, 0.08 if held == "staff" else 0.055, orb_mat, Vector3(0, 1.35 if held == "staff" else 0.83, 0))
	elif held == "hammer":
		w.rotation.x = -1.2
		var wood_h: StandardMaterial3D = _mat(Color(0.35, 0.22, 0.12), 0.85)
		var iron_h: StandardMaterial3D = _mat(Color(0.3, 0.3, 0.34), 0.35, 0.9)
		_cyl(w, 0.02, 0.025, 0.55, wood_h, Vector3(0, 0.17, 0))
		_box(w, Vector3(0.26, 0.15, 0.15), iron_h, Vector3(0, 0.45, 0))
		_box(w, Vector3(0.27, 0.035, 0.16), _mat(Color(0.55, 0.56, 0.6), 0.3, 0.85), Vector3(0, 0.45, 0))
	elif held == "axe":
		w.rotation.x = -1.45
		_cyl(w, 0.018, 0.024, 0.78, _mat(Color(0.38, 0.24, 0.13), 0.9), Vector3(0, 0.29, 0))
		_box(w, Vector3(0.3, 0.27, 0.06), _mat(Color(0.68, 0.73, 0.8), 0.24, 0.9), Vector3(0.14, 0.65, 0))
		_cyl(w, 0.0, 0.025, 0.08, _mat(Color(0.68, 0.73, 0.8), 0.24, 0.9), Vector3(0.29, 0.65, 0), 4).rotation.z = -PI * 0.5
	elif held == "spear":
		w.rotation.x = -0.25
		_cyl(w, 0.018, 0.022, 1.68, _mat(Color(0.42, 0.28, 0.16), 0.85), Vector3(0, 0.52, 0))
		_cyl(w, 0.03, 0.03, 0.06, _mat(Color(0.4, 0.4, 0.44), 0.4, 0.8), Vector3(0, 1.34, 0), 10)
		_cyl(w, 0.0, 0.078, 0.3, _mat(Color(0.72, 0.78, 0.86), 0.25, 0.9), Vector3(0, 1.51, 0), 6)
	elif held == "bow":
		w.rotation.x = -0.2
		var bow_mat: StandardMaterial3D = _mat(Color(0.52, 0.32, 0.17), 0.75)
		var string_mat: StandardMaterial3D = _mat(Color(0.82, 0.8, 0.72), 0.6)
		_cyl(w, 0.02, 0.026, 0.28, bow_mat, Vector3(0, 0.48, 0))
		for side in [-1.0, 1.0]:
			var limb: MeshInstance3D = _cyl(w, 0.014, 0.022, 0.35, bow_mat, Vector3(0, 0.48 + side * 0.27, -0.035))
			limb.rotation.x = side * -0.22
		_cyl(w, 0.004, 0.004, 0.84, string_mat, Vector3(0, 0.48, -0.075))
		_cyl(w, 0.006, 0.006, 0.5, _mat(Color(0.75, 0.72, 0.62), 0.7), Vector3(0, 0.48, -0.02), 6)
	elif held == "dagger" or held == "daggers":
		var count: int = 2 if held == "daggers" else 1
		for i in range(count):
			var side: float = -0.075 if i == 0 else 0.075
			var blade: Node3D = Node3D.new()
			blade.position.x = side
			blade.rotation.z = 0.16 if i == 0 else -0.16
			w.add_child(blade)
			_cyl(blade, 0.012, 0.012, 0.12, _mat(Color(0.28, 0.18, 0.12), 0.8), Vector3(0, -0.02, 0))
			_box(blade, Vector3(0.025, 0.34, 0.012), _mat(Color(0.82, 0.87, 0.94), 0.2, 0.95), Vector3(0, 0.2, 0))
			_cyl(blade, 0.0, 0.014, 0.07, _mat(Color(0.82, 0.87, 0.94), 0.2, 0.95), Vector3(0, 0.4, 0), 4)
	return w

# ---------------------------------------------------------------------------
# Asset body
# ---------------------------------------------------------------------------
## Pick a scanned CC0 body for the requested look. Explicit cfg["asset"] wins.
func _resolve_asset(c: Dictionary) -> String:
	var explicit: String = str(c.get("asset", ""))
	if explicit != "":
		return explicit if ResourceLoader.exists(ASSET_DIR + explicit + ".glb") else ""
	var scale: float = float(c.get("scale", 1.0))
	var hat: String = str(c.get("hat", "none"))
	var helm: String = str(c.get("helm", "none"))
	# Medieval fantasy cast only: no modern soldiers, jackets or jeans.
	var slug := "viking"
	var female: bool = bool(c.get("dress", false)) or str(c.get("frame", "male")) == "female"
	if scale < 0.8:
		slug = "child"
	elif bool(c.get("armour", false)) or helm == "knight":
		slug = "armored-knight"
	elif female:
		slug = "witch" if bool(c.get("robe", false)) else "queen"
	elif bool(c.get("robe", false)):
		slug = "wizard"
	elif hat == "straw":
		slug = "dwarf"
	elif float(c.get("bulk", 1.0)) >= 1.2:
		slug = "viking"
	return slug if ResourceLoader.exists(ASSET_DIR + slug + ".glb") else ""

func _find_rig(node: Node) -> void:
	if _asset_skeleton == null and node is Skeleton3D:
		_asset_skeleton = node as Skeleton3D
	if _asset_player == null and node is AnimationPlayer:
		_asset_player = node as AnimationPlayer
	for child in node.get_children():
		_find_rig(child)

func _build_asset(slug: String) -> void:
	var packed := load(ASSET_DIR + slug + ".glb") as PackedScene
	if packed == null:
		return
	var inst := packed.instantiate() as Node3D
	if inst == null:
		return
	_asset_root = Node3D.new()
	_asset_root.name = "AssetBody"
	add_child(_asset_root)
	_asset_root.add_child(inst)
	# glTF characters look down +Z; this rig faces -Z.
	inst.rotation.y = PI
	_find_rig(inst)
	if _asset_skeleton == null or _asset_player == null:
		_asset_root.queue_free()
		_asset_root = null
		return
	for bone in ASSET_BONES:
		var idx := _asset_skeleton.find_bone(bone)
		if idx >= 0:
			_asset_bone[bone] = idx
	for clip_name in _asset_player.get_animation_list():
		var anim := _asset_player.get_animation(clip_name)
		if anim and _clip_name(clip_name) != "":
			anim.loop_mode = Animation.LOOP_LINEAR
	# Manual processing lets the additive overlay poses land after the mixer
	# samples the clip; otherwise the mixer overwrites them every frame.
	_asset_player.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	for child in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := child as MeshInstance3D
		if mi.mesh == null:
			continue
		_asset_meshes.append(mi)
		for s in range(mi.mesh.get_surface_count()):
			var base := mi.get_active_material(s)
			if base is StandardMaterial3D:
				var copy := (base as StandardMaterial3D).duplicate() as StandardMaterial3D
				mi.set_surface_override_material(s, copy)
				_mats.append(copy)
	# Tinting the scanned atlas is what separates two villagers wearing the same
	# outfit: every NPC gets its own cloth dye without a new texture download.
	var tint: Color = _c("asset_tint", Color(1, 1, 1))
	var rough_override: float = float(_c("asset_roughness", -1.0))
	for m in _mats:
		m.albedo_color = Color(m.albedo_color.r * tint.r, m.albedo_color.g * tint.g, m.albedo_color.b * tint.b, m.albedo_color.a)
		if rough_override >= 0.0:
			m.roughness = rough_override
	var hand_idx := int(_asset_bone.get("RightHand", -1))
	if hand_idx >= 0:
		_asset_hand_bone = hand_idx
		_asset_weapon_attach = Node3D.new()
		_asset_weapon_attach.name = "WeaponBone"
		_asset_root.add_child(_asset_weapon_attach)
	var back_prop: String = str(_c("back_prop", ""))
	if back_prop != "":
		_asset_spine_bone = int(_asset_bone.get("Spine02", _asset_bone.get("Spine01", _asset_bone.get("Spine", -1))))
		if _asset_spine_bone >= 0:
			_asset_back_attach = Node3D.new()
			_asset_back_attach.name = "BackBone"
			_asset_root.add_child(_asset_back_attach)
			_build_back_prop(back_prop)
	_asset_idle_phase = _find_idle_phase()
	_asset_player.play("walk" if _has_clip("walk") else _first_clip())
	_asset_player.seek(_asset_idle_phase, true)
	_asset_player.speed_scale = 0.0
	_asset_clip = "idle"
	# Undo the idle hand rotation so the weapon rests in its authored upright pose;
	# every later hand rotation then swings the weapon naturally.
	if _asset_hand_bone >= 0:
		_asset_skeleton.force_update_all_bone_transforms()
		_asset_hand_basis_inv = _asset_skeleton.get_bone_global_pose(_asset_hand_bone).basis.orthonormalized().inverse()
	body_root.visible = false
	_asset_near = true
	if str(_c("held", "none")) != "none":
		set_held_weapon(str(_c("held", "none")))

func _has_clip(name: String) -> bool:
	return _asset_player != null and _asset_player.has_animation(name)

func _first_clip() -> String:
	if _asset_player == null:
		return ""
	for name in _asset_player.get_animation_list():
		if _clip_name(name) != "":
			return name
	return ""

func _clip_name(anim_name: String) -> String:
	var n := anim_name.to_lower()
	if n.contains("walk"):
		return "walk"
	if n.contains("run"):
		return "run"
	return ""

## Find the walk pose where both feet sit closest to the ground and pause there for
## idle. A frozen contact pose reads as standing; a frozen mid-swing pose does not.
func _find_idle_phase() -> float:
	var walk := "walk" if _has_clip("walk") else _first_clip()
	if walk == "":
		return 0.0
	var length := _asset_player.get_animation(walk).length
	var l := int(_asset_bone.get("LeftFoot", -1))
	var r := int(_asset_bone.get("RightFoot", -1))
	if l < 0 or r < 0:
		return 0.0
	_asset_player.play(walk)
	var best_t := 0.0
	var best_score := INF
	for i in range(40):
		var t: float = length * float(i) / 40.0
		_asset_player.seek(t, true)
		_asset_skeleton.force_update_all_bone_transforms()
		var ly: float = _asset_skeleton.get_bone_global_pose(l).origin.y
		var ry: float = _asset_skeleton.get_bone_global_pose(r).origin.y
		var score: float = absf(ly - ry) + maxf(ly, ry) * 2.0
		if score < best_score:
			best_score = score
			best_t = t
	return best_t

## The scanned rig's hand bone axes do not match the procedural hand node, so the
## weapon mount cancels the idle hand rotation once and then follows the animated
## hand rotation from there.
func _update_weapon_mount() -> void:
	if _asset_weapon_attach == null or _asset_skeleton == null or _asset_hand_bone < 0:
		return
	var bone_pose: Transform3D = _asset_skeleton.get_bone_global_pose(_asset_hand_bone)
	var bone_basis: Basis = bone_pose.basis.orthonormalized()
	var local_basis: Basis = bone_basis * _asset_hand_basis_inv
	var world_basis: Basis = _asset_skeleton.global_transform.basis.orthonormalized() * local_basis
	var origin: Vector3 = (_asset_skeleton.global_transform * bone_pose).origin
	_asset_weapon_attach.global_transform = Transform3D(world_basis, origin)

## Role gear rides the spine bone so it bobs with the walk cycle instead of
## floating at a fixed height above the root.
func _update_back_mount() -> void:
	if _asset_back_attach == null or _asset_skeleton == null or _asset_spine_bone < 0:
		return
	var bone_pose: Transform3D = _asset_skeleton.get_bone_global_pose(_asset_spine_bone)
	var origin: Vector3 = (_asset_skeleton.global_transform * bone_pose).origin
	_asset_back_attach.global_transform = Transform3D(_asset_skeleton.global_transform.basis.orthonormalized(), origin)

## Profession props. Built in the character's local frame (-Z forward, +Z back)
## so the same mesh works for every scanned body.
func _build_back_prop(kind: String) -> void:
	var a := _asset_back_attach
	if a == null:
		return
	var leather := _mat_leather(_c("prop_color", Color(0.36, 0.24, 0.14)))
	var leather_dark := _mat_leather(Color(0.2, 0.13, 0.08))
	var wood := _mat_leather(_c("prop_wood", Color(0.48, 0.33, 0.18)))
	var metal := _mat_metal(_c("accent", Color(0.72, 0.62, 0.34)))
	var cloth := _mat_cloth(_c("prop_cloth", Color(0.42, 0.36, 0.24)))
	match kind:
		"quiver":
			var q := Node3D.new()
			q.position = Vector3(0.15, -0.04, 0.2)
			q.rotation.z = -0.42
			a.add_child(q)
			_cyl(q, 0.052, 0.044, 0.52, leather, Vector3.ZERO, 14)
			_cyl(q, 0.058, 0.05, 0.05, leather_dark, Vector3(0, 0.22, 0), 14)
			for i in range(3):
				var ax: float = -0.025 + float(i) * 0.024
				_cyl(q, 0.005, 0.005, 0.5, wood, Vector3(ax, 0.2, 0.0), 6)
				var fl: MeshInstance3D = _box(q, Vector3(0.022, 0.075, 0.008), cloth, Vector3(ax, 0.4, 0.0))
				fl.rotation.y = 0.6 + float(i) * 0.4
		"satchel":
			_box(a, Vector3(0.27, 0.23, 0.12), leather, Vector3(0.19, -0.34, 0.14))
			_box(a, Vector3(0.28, 0.1, 0.13), leather_dark, Vector3(0.19, -0.24, 0.14))
			_box(a, Vector3(0.045, 0.045, 0.015), metal, Vector3(0.19, -0.25, 0.207))
			var strap: MeshInstance3D = _box(a, Vector3(0.05, 0.62, 0.022), leather_dark, Vector3(0.07, 0.04, 0.12))
			strap.rotation.z = 0.4
		"apron":
			_box(a, Vector3(0.36, 0.66, 0.022), cloth, Vector3(0, -0.3, -0.15))
			_box(a, Vector3(0.31, 0.05, 0.032), leather_dark, Vector3(0, -0.02, -0.15))
			var st1: MeshInstance3D = _box(a, Vector3(0.045, 0.44, 0.02), leather_dark, Vector3(0.11, 0.2, -0.135))
			st1.rotation.z = -0.16
			var st2: MeshInstance3D = _box(a, Vector3(0.045, 0.44, 0.02), leather_dark, Vector3(-0.11, 0.2, -0.135))
			st2.rotation.z = 0.16
			_box(a, Vector3(0.15, 0.13, 0.04), leather, Vector3(0.09, -0.2, -0.165))
			_box(a, Vector3(0.02, 0.22, 0.02), leather_dark, Vector3(-0.13, -0.25, -0.158))
		"shield":
			var disc: MeshInstance3D = _cyl(a, 0.32, 0.32, 0.045, wood, Vector3(-0.02, -0.03, 0.2), 28)
			disc.rotation.x = PI * 0.5
			var rim_mesh := TorusMesh.new()
			rim_mesh.inner_radius = 0.295
			rim_mesh.outer_radius = 0.335
			rim_mesh.rings = 28
			rim_mesh.ring_segments = 8
			var rim: MeshInstance3D = _add(a, rim_mesh, metal, Vector3(-0.02, -0.03, 0.205))
			rim.rotation.x = PI * 0.5
			_sph(a, 0.062, metal, Vector3(-0.02, -0.03, 0.235), Vector3(1.0, 1.0, 0.55))
			for side in [-1.0, 1.0]:
				var band: MeshInstance3D = _box(a, Vector3(0.6, 0.035, 0.012), leather_dark, Vector3(-0.02, -0.03 + side * 0.17, 0.223))
				band.rotation.z = side * 0.1
		"pack":
			_box(a, Vector3(0.34, 0.4, 0.2), cloth, Vector3(0, -0.06, 0.21))
			_box(a, Vector3(0.3, 0.07, 0.21), leather_dark, Vector3(0, 0.11, 0.215))
			var roll: MeshInstance3D = _cyl(a, 0.085, 0.085, 0.42, leather, Vector3(0, 0.2, 0.23), 14)
			roll.rotation.z = PI * 0.5
			for side in [-1.0, 1.0]:
				_box(a, Vector3(0.045, 0.36, 0.02), leather_dark, Vector3(side * 0.11, 0.0, 0.32))
			_box(a, Vector3(0.14, 0.12, 0.05), leather_dark, Vector3(0.0, -0.16, 0.31))
		"basket":
			_cyl(a, 0.2, 0.145, 0.32, wood, Vector3(0, -0.22, 0.2), 16)
			for i in range(3):
				var band_radius: float = 0.2 - float(i) * 0.018
				_cyl(a, band_radius, band_radius, 0.014, leather_dark, Vector3(0, -0.12 - float(i) * 0.08, 0.2), 16)
			_cyl(a, 0.212, 0.212, 0.03, leather, Vector3(0, -0.065, 0.2), 16)
			_box(a, Vector3(0.045, 0.34, 0.02), leather_dark, Vector3(0.0, 0.02, 0.09))

func _update_asset_lod(delta: float) -> void:
	if _asset_root == null or body_root == null:
		return
	_asset_far_check -= delta
	if _asset_far_check > 0.0:
		return
	_asset_far_check = 0.35
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	var dist: float = cam.global_position.distance_to(global_position)
	var want_near: bool = dist < (ASSET_DETAIL_RANGE + ASSET_DETAIL_RANGE_HYST if _asset_near else ASSET_DETAIL_RANGE)
	if want_near != _asset_near:
		_asset_near = want_near
		_asset_root.visible = want_near
		body_root.visible = not want_near

func _update_asset(delta: float) -> void:
	if _asset_player == null or _asset_skeleton == null or _dead:
		return
	var moving: bool = _move > 0.12 and _target_move > 0.12
	if not moving:
		if _asset_clip != "idle":
			_asset_clip = "idle"
			_asset_player.play("walk" if _has_clip("walk") else _first_clip())
			_asset_player.seek(_asset_idle_phase, true)
			_asset_player.speed_scale = 0.0
	else:
		var want: String = "run" if _move > 1.12 and _has_clip("run") else "walk"
		if _asset_clip != want:
			_asset_clip = want
			_asset_player.play(want, 0.18)
		var rate: float
		if want == "run":
			rate = 0.85 + (_move - 1.0) * 0.5
		else:
			rate = 0.8 + _move * 0.5
		_asset_player.speed_scale = clampf(rate, 0.6, 1.75)
	_asset_player.advance(delta)
	if _asset_near:
		_apply_asset_overlays()
	_update_weapon_mount()
	_update_back_mount()

## Additive pose layer applied after the clip so combat, work and stealth still
## read on the scanned rigs without authoring extra animations.
func _apply_asset_overlays() -> void:
	var idle: float = clampf(1.0 - _move * 2.0, 0.0, 1.0)
	var breathe: float = sin(_time * 1.9) * 0.02 * idle
	_rotate_bone("Spine01", Vector3.RIGHT, breathe)
	_rotate_bone("Head", Vector3.UP, sin(_time * 0.7) * 0.12 * idle)
	_rotate_bone("Head", Vector3.RIGHT, sin(_time * 0.9) * 0.03 - 0.05 * _stealth_pose)
	_rotate_bone("Spine", Vector3.RIGHT, 0.28 * _stealth_pose)
	_rotate_bone("LeftUpLeg", Vector3.RIGHT, -0.5 * _stealth_pose)
	_rotate_bone("RightUpLeg", Vector3.RIGHT, -0.5 * _stealth_pose)
	_rotate_bone("LeftLeg", Vector3.RIGHT, 0.95 * _stealth_pose)
	_rotate_bone("RightLeg", Vector3.RIGHT, 0.95 * _stealth_pose)
	_asset_root.position.y = -0.18 * _stealth_pose
	var work: String = _work_pose if _work_pose != "" and _move < 0.18 and _attack_t < 0.0 else ""
	if work != "":
		_work_clock += get_process_delta_time()
		var swing: float = sin(_work_clock * (5.8 if work == "smith" else 2.6))
		match work:
			"smith":
				_rotate_bone("RightArm", Vector3.RIGHT, -0.9 + maxf(0.0, swing) * 0.8)
				_rotate_bone("RightForeArm", Vector3.RIGHT, -0.6)
			"tend":
				_rotate_bone("RightArm", Vector3.RIGHT, -0.6 + swing * 0.14)
				_rotate_bone("LeftArm", Vector3.RIGHT, -0.45 - swing * 0.1)
			"trade":
				_rotate_bone("RightForeArm", Vector3.RIGHT, -0.5 + swing * 0.1)
				_rotate_bone("LeftForeArm", Vector3.RIGHT, -0.4 - swing * 0.1)
			"track":
				_rotate_bone("RightArm", Vector3.RIGHT, -0.15 + swing * 0.06)
				_rotate_bone("LeftArm", Vector3.RIGHT, -0.18 - swing * 0.06)
	if _attack_t >= 0.0:
		_attack_t += get_process_delta_time()
		var t: float = _attack_t / attack_duration
		var arm_x: float
		if _stealth_attack:
			if t < 0.34:
				arm_x = lerpf(0.0, -1.7, ease(t / 0.34, -2.0))
			elif t < 0.52:
				arm_x = lerpf(-1.7, 0.2, ease((t - 0.34) / 0.18, -1.3))
			else:
				arm_x = lerpf(0.2, 0.0, clampf((t - 0.52) / 0.48, 0.0, 1.0))
		else:
			if t < 0.3:
				arm_x = lerpf(0.0, -2.4, ease(t / 0.3, -2.0))
			elif t < 0.55:
				arm_x = lerpf(-2.4, 0.5, 1.0 - pow(1.0 - (t - 0.3) / 0.25, 2.0))
			else:
				arm_x = lerpf(0.5, 0.0, clampf((t - 0.55) / 0.45, 0.0, 1.0))
		_rotate_bone("RightArm", Vector3.RIGHT, arm_x)
		_rotate_bone("RightForeArm", Vector3.RIGHT, lerpf(-0.9, -0.1, clampf((t - 0.25) / 0.3, 0.0, 1.0)))
		var twist: float = lerpf(0.45, -0.45, clampf((t - 0.15) / 0.4, 0.0, 1.0)) * _attack_side
		_rotate_bone("Spine01", Vector3.UP, twist * (0.35 if _stealth_attack else 1.0))
		if not _impact_sent and t >= 0.42:
			_impact_sent = true
			attack_impact.emit()
		if t >= 1.0:
			_attack_t = -1.0
			_stealth_attack = false
	_flush_bone_rotations()

## Bone axes differ between scanned rigs, so overlays are queued in character
## space and conjugated into each bone's local frame once per frame.
func _rotate_bone(bone: String, axis: Vector3, angle: float) -> void:
	var idx := int(_asset_bone.get(bone, -1))
	if idx < 0 or absf(angle) < 0.0001:
		return
	var delta := Basis(axis.normalized(), angle)
	var current: Basis = _overlay_rot.get(idx, Basis())
	_overlay_rot[idx] = delta * current

func _flush_bone_rotations() -> void:
	for key in _overlay_rot:
		var idx: int = key
		var global_basis: Basis = _asset_skeleton.get_bone_global_pose(idx).basis.orthonormalized()
		var local_delta: Basis = global_basis.inverse() * _overlay_rot[key] * global_basis
		var pose: Quaternion = _asset_skeleton.get_bone_pose_rotation(idx)
		_asset_skeleton.set_bone_pose_rotation(idx, (pose * local_delta.get_rotation_quaternion()).normalized())
	_overlay_rot.clear()

# ---------------------------------------------------------------------------
# Mesh helpers
# ---------------------------------------------------------------------------
func _mat(color: Color, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	m.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
	if metal < 0.4:
		m.rim_enabled = true
		m.rim = 0.09 if rough < 0.7 else 0.045
		m.rim_tint = 0.55 if rough < 0.6 else 0.28
	_mats.append(m)
	return m

func _mat_skin(color: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mat(color, 0.68)
	m.subsurf_scatter_enabled = true
	m.subsurf_scatter_strength = 0.16
	m.subsurf_scatter_skin_mode = true
	m.metallic_specular = 0.32
	m.rim = 0.08
	m.rim_tint = 0.6
	return m

func _mat_hair(color: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mat(color, 0.42)
	m.clearcoat_enabled = true
	m.clearcoat = 0.18
	m.clearcoat_roughness = 0.45
	m.metallic_specular = 0.5
	m.rim = 0.1
	m.rim_tint = 0.45
	return m

func _mat_cloth(color: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mat(color, 0.9)
	m.metallic_specular = 0.28
	return m

func _mat_leather(color: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mat(color, 0.68)
	m.metallic_specular = 0.5
	m.clearcoat_enabled = true
	m.clearcoat = 0.18
	m.clearcoat_roughness = 0.5
	return m

func _mat_metal(color: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mat(color, 0.34, 0.82)
	m.metallic_specular = 0.6
	return m

func _add(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi

func _cyl(parent: Node3D, r_top: float, r_bot: float, h: float, mat: Material, pos: Vector3, segs: int = 12) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.top_radius = r_top
	m.bottom_radius = r_bot
	m.height = h
	m.radial_segments = segs
	m.rings = 2
	return _add(parent, m, mat, pos)

func _sph(parent: Node3D, r: float, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE, hemi: bool = false) -> MeshInstance3D:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r if hemi else r * 2.0
	m.is_hemisphere = hemi
	m.radial_segments = 20
	m.rings = 12
	return _add(parent, m, mat, pos, scl)

func _box(parent: Node3D, size: Vector3, mat: Material, pos: Vector3) -> MeshInstance3D:
	var m := BoxMesh.new()
	m.size = size
	return _add(parent, m, mat, pos)

func _lathe(parent: Node3D, profile: Array, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE, segs: int = 18) -> MeshInstance3D:
	return _add(parent, _lathe_mesh(profile, segs), mat, pos, scl)

func _lock(parent: Node3D, length: float, width: float, thick: float, curve: float, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = _add(parent, _lock_mesh(length, width, thick, curve), mat, pos)
	mi.rotation = rot
	return mi

func _emit_tri(st: SurfaceTool, v0: Vector3, v1: Vector3, v2: Vector3, n0: Vector3, n1: Vector3, n2: Vector3) -> void:
	st.set_normal(n0)
	st.add_vertex(v0)
	st.set_normal(n1)
	st.add_vertex(v1)
	st.set_normal(n2)
	st.add_vertex(v2)

func _lathe_mesh(profile: Array, segs: int = 18) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rings: int = profile.size()
	if rings < 2 or segs < 3:
		return st.commit()
	var points: Array = []
	var normals: Array = []
	for i in range(rings):
		var p: Vector2 = profile[i]
		var prev: Vector2 = profile[maxi(i - 1, 0)]
		var next: Vector2 = profile[mini(i + 1, rings - 1)]
		var tangent: Vector2 = (next - prev).normalized()
		var radial := Vector2(tangent.y, -tangent.x)
		if radial.length_squared() < 0.0001:
			radial = Vector2(1.0, 0.0)
		radial = radial.normalized()
		var row_p := PackedVector3Array()
		var row_n := PackedVector3Array()
		for j in range(segs):
			var a: float = TAU * float(j) / float(segs)
			row_p.append(Vector3(cos(a) * p.x, p.y, sin(a) * p.x))
			row_n.append(Vector3(cos(a) * radial.x, radial.y, sin(a) * radial.x).normalized())
		points.append(row_p)
		normals.append(row_n)
	for i in range(rings - 1):
		for j in range(segs):
			var j2: int = (j + 1) % segs
			var p0: Vector3 = points[i][j]
			var p1: Vector3 = points[i + 1][j]
			var p2: Vector3 = points[i][j2]
			var p3: Vector3 = points[i + 1][j2]
			var n0: Vector3 = normals[i][j]
			var n1: Vector3 = normals[i + 1][j]
			var n2: Vector3 = normals[i][j2]
			var n3: Vector3 = normals[i + 1][j2]
			_emit_tri(st, p0, p1, p2, n0, n1, n2)
			_emit_tri(st, p2, p1, p3, n2, n1, n3)
	return st.commit()

func _lock_mesh(length: float, width: float, thick: float, curve: float, segs: int = 10, rings: int = 7) -> ArrayMesh:
	# A tapered, slightly curved lock of hair with radially smoothed normals.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var points: Array = []
	var normals: Array = []
	for i in range(rings + 1):
		var t: float = 1.0 - float(i) / float(rings)
		var rw: float = width * pow(1.0 - t, 0.7) + 0.0015
		var rt: float = thick * pow(1.0 - t, 0.85) + 0.001
		var y: float = -length * (1.0 - t)
		var z: float = curve * (1.0 - t) * (1.0 - t)
		var row_p := PackedVector3Array()
		var row_n := PackedVector3Array()
		for j in range(segs):
			var a: float = TAU * float(j) / float(segs)
			row_p.append(Vector3(cos(a) * rw, y, sin(a) * rt + z))
			row_n.append(Vector3(cos(a), (1.0 - t) * 0.14, sin(a)).normalized())
		points.append(row_p)
		normals.append(row_n)
	for i in range(rings):
		for j in range(segs):
			var j2: int = (j + 1) % segs
			var p0: Vector3 = points[i][j]
			var p1: Vector3 = points[i + 1][j]
			var p2: Vector3 = points[i][j2]
			var p3: Vector3 = points[i + 1][j2]
			var n0: Vector3 = normals[i][j]
			var n1: Vector3 = normals[i + 1][j]
			var n2: Vector3 = normals[i][j2]
			var n3: Vector3 = normals[i + 1][j2]
			_emit_tri(st, p0, p1, p2, n0, n1, n2)
			_emit_tri(st, p2, p1, p3, n2, n1, n3)
	return st.commit()

func _head_mesh(segs: int = 28, rings: int = 20) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var points: Array = []
	var normals: Array = []
	for i in range(rings + 1):
		var v: float = float(i) / float(rings)
		var lat: float = lerpf(-PI * 0.46, PI * 0.46, v)
		var y: float = sin(lat)
		var r: float = cos(lat)
		var width := 1.0
		var depth := 1.0
		if y < -0.1:
			var k: float = clampf((-y - 0.1) / 0.9, 0.0, 1.0)
			width = lerpf(1.0, 0.58, pow(k, 1.25))
			depth = lerpf(1.0, 0.86, pow(k, 1.1))
		elif y > 0.55:
			width = lerpf(1.0, 0.9, (y - 0.55) / 0.45)
			depth = lerpf(1.0, 0.94, (y - 0.55) / 0.45)
		var row_p := PackedVector3Array()
		var row_n := PackedVector3Array()
		for j in range(segs):
			var a: float = TAU * float(j) / float(segs)
			var x: float = cos(a) * r * width * 0.108
			var z: float = sin(a) * r * depth * 0.118
			var vy: float = y * 0.122
			# Chin and jaw pushed forward, brow and forehead flattened a touch.
			if z < 0.0 and y < -0.22:
				var chin: float = clampf((-y - 0.22) / 0.78, 0.0, 1.0)
				z -= 0.016 * pow(chin, 2.0) * clampf(1.0 - absf(cos(a)) * 0.8, 0.0, 1.0)
			if z < 0.0 and y > 0.18 and y < 0.52:
				z -= 0.004
			row_p.append(Vector3(x, vy, z))
			row_n.append(Vector3(x / 0.108, vy / 0.122, z / 0.118).normalized())
		points.append(row_p)
		normals.append(row_n)
	for i in range(rings):
		for j in range(segs):
			var j2: int = (j + 1) % segs
			var p0: Vector3 = points[i][j]
			var p1: Vector3 = points[i + 1][j]
			var p2: Vector3 = points[i][j2]
			var p3: Vector3 = points[i + 1][j2]
			var n0: Vector3 = normals[i][j]
			var n1: Vector3 = normals[i + 1][j]
			var n2: Vector3 = normals[i][j2]
			var n3: Vector3 = normals[i + 1][j2]
			_emit_tri(st, p0, p1, p2, n0, n1, n2)
			_emit_tri(st, p2, p1, p3, n2, n1, n3)
	# Head UV-less mesh: the lathe is built bottom-up like the body shells.
	return st.commit()

func _cape_mesh(top_width: float, bottom_width: float, length: float, curve: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var cols: int = 10
	var rows: int = 12
	var points: Array = []
	var normals: Array = []
	for i in range(rows + 1):
		var t: float = float(i) / float(rows)
		var w: float = lerpf(top_width, bottom_width, pow(t, 0.85))
		var row_p := PackedVector3Array()
		var row_n := PackedVector3Array()
		for j in range(cols + 1):
			var u: float = float(j) / float(cols)
			var x: float = (u - 0.5) * w
			var y: float = -length * t
			var z: float = 0.012 + curve * pow(t, 1.7) + sin(u * PI * 3.0) * 0.018 * t
			row_p.append(Vector3(x, y, z))
			row_n.append(Vector3(0.0, 0.1 + curve * t, 1.0).normalized())
		points.append(row_p)
		normals.append(row_n)
	for i in range(rows):
		for j in range(cols):
			var p0: Vector3 = points[i][j]
			var p1: Vector3 = points[i + 1][j]
			var p2: Vector3 = points[i][j + 1]
			var p3: Vector3 = points[i + 1][j + 1]
			var n0: Vector3 = normals[i][j]
			var n1: Vector3 = normals[i + 1][j]
			var n2: Vector3 = normals[i][j + 1]
			var n3: Vector3 = normals[i + 1][j + 1]
			_emit_tri(st, p0, p1, p2, n0, n1, n2)
			_emit_tri(st, p2, p1, p3, n2, n1, n3)
	return st.commit()

func _surface_format_key(mesh: Mesh) -> String:
	# SurfaceTool.append_from rejects sources whose attribute layout differs from the
	# ones already queued, so only merge meshes that share the same layout.
	var arrays: Array = mesh.surface_get_arrays(0)
	var parts: Array = []
	for idx in range(Mesh.ARRAY_MAX):
		var attr = arrays[idx]
		if attr != null and attr.size() > 0:
			parts.append(str(idx))
	return "_".join(parts)

func _merge_part(part: Node) -> void:
	if part == null:
		return
	# Group by material *and* vertex format: append_from needs identical formats,
	# so procedural meshes (position+normal only) must not be mixed with spheres.
	var groups: Dictionary = {}
	for child in part.get_children():
		if not (child is MeshInstance3D):
			continue
		var mi := child as MeshInstance3D
		if mi.mesh == null or mi.mesh.get_surface_count() != 1 or mi.material_override == null:
			continue
		var key: String = "%d:%s" % [mi.material_override.get_instance_id(), _surface_format_key(mi.mesh)]
		if not groups.has(key):
			groups[key] = {"mat": mi.material_override, "items": []}
		groups[key]["items"].append(mi)
	for key in groups:
		var items: Array = groups[key]["items"]
		if items.size() < 2:
			continue
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		for child in items:
			var mi := child as MeshInstance3D
			st.append_from(mi.mesh, 0, mi.transform)
		var merged := MeshInstance3D.new()
		merged.name = "MergedDetail"
		merged.mesh = st.commit()
		merged.material_override = groups[key]["mat"]
		for child in items:
			var mi := child as MeshInstance3D
			part.remove_child(mi)
			mi.queue_free()
		part.add_child(merged)

# ---------------------------------------------------------------------------
# Control
# ---------------------------------------------------------------------------
## speed_ratio: 0 = standing, 1 = walking, ~1.5 = running
func set_motion(speed_ratio: float) -> void:
	_target_move = clampf(speed_ratio, 0.0, 2.0)
	if speed_ratio > 0.2:
		_work_pose = ""

## Lightweight role animation layered over the shared character rig.
## Supported poses: smith, tend, trade, track. Empty string returns to idle.
func set_work_pose(pose: String) -> void:
	_work_pose = pose
	if pose == "":
		_work_clock = 0.0

func set_stealth_stance(enabled: bool) -> void:
	_stealth_target = 1.0 if enabled else 0.0

func play_attack(side: float = 1.0, stealth_strike: bool = false) -> void:
	if _dead:
		return
	_attack_t = 0.0
	_attack_side = side
	_stealth_attack = stealth_strike
	_impact_sent = false

func is_attacking() -> bool:
	return _attack_t >= 0.0

func play_death() -> void:
	if _dead:
		return
	_dead = true
	_attack_t = -1.0
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(body_root, "rotation:x", -PI * 0.5, 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_property(body_root, "position:y", 0.12, 0.55)
	if _asset_root != null:
		if _asset_player != null:
			_asset_player.speed_scale = 0.0
		_asset_dead_tween = create_tween()
		_asset_dead_tween.set_parallel(true)
		_asset_dead_tween.tween_property(_asset_root, "rotation:x", PI * 0.5, 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		_asset_dead_tween.tween_property(_asset_root, "position:y", 0.12, 0.55)

func flash(color: Color = Color(1.0, 0.25, 0.2), duration: float = 0.22) -> void:
	if _flash_tween and _flash_tween.is_valid():
		_flash_tween.kill()
		_restore_flash()
	_flash_saved.clear()
	for m in _mats:
		_flash_saved.append([m, m.emission_enabled, m.emission, m.emission_energy_multiplier])
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.6
	_flash_tween = create_tween()
	_flash_tween.tween_method(func(v: float) -> void:
		for entry in _flash_saved:
			var m: StandardMaterial3D = entry[0]
			m.emission_energy_multiplier = v, 1.6, 0.0, duration)
	_flash_tween.tween_callback(_restore_flash)

func _restore_flash() -> void:
	for entry in _flash_saved:
		var m: StandardMaterial3D = entry[0]
		if is_instance_valid(m):
			m.emission_enabled = bool(entry[1])
			m.emission = entry[2]
			m.emission_energy_multiplier = float(entry[3])
	_flash_saved.clear()

## Children look more childlike: bigger head, smaller body.
func set_age(age: float) -> float:
	var s: float = clampf(0.6 + (age - 5.0) * 0.04, 0.6, 1.2)
	scale = Vector3.ONE * s
	if head:
		head.scale = Vector3.ONE * lerpf(1.28, 1.0, clampf((age - 5.0) / 10.0, 0.0, 1.0))
	return s

func _process(delta: float) -> void:
	if body_root == null:
		return
	_time += delta
	_move = lerpf(_move, _target_move, clampf(delta * 10.0, 0.0, 1.0))
	_stealth_pose = lerpf(_stealth_pose, _stealth_target, clampf(delta * 7.0, 0.0, 1.0))
	if _asset_root != null:
		_update_asset_lod(delta)
		_update_asset(delta)
	if _dead:
		return
	_phase += delta * (5.5 + _move * 3.0) * clampf(_move, 0.0, 1.0)
	var s: float = sin(_phase)
	var c: float = cos(_phase)
	var amp: float = clampf(_move, 0.0, 1.5) * 0.55
	leg_l.rotation.x = s * amp + _stealth_pose * 0.26
	leg_r.rotation.x = -s * amp + _stealth_pose * 0.26
	knee_l.rotation.x = maxf(0.0, -c) * amp * 1.3 + _stealth_pose * 0.78
	knee_r.rotation.x = maxf(0.0, c) * amp * 1.3 + _stealth_pose * 0.78
	arm_l.rotation.x = -s * amp * 0.9 - _stealth_pose * 0.28
	elbow_l.rotation.x = -0.25 - absf(amp) * 0.4
	body_root.position.y = -0.16 * _stealth_pose + absf(sin(_phase)) * 0.035 * clampf(_move, 0.0, 1.5)
	torso.rotation.x = 0.14 * _stealth_pose
	torso.rotation.y = -s * 0.07 * _move
	# breathing / idle sway
	var breathe: float = sin(_time * 1.9) * 0.012
	torso.scale = Vector3(1.0 + breathe * 0.5, 1.0 + breathe, 1.0)
	head.rotation.y = sin(_time * 0.7) * 0.12 * (1.0 - clampf(_move, 0.0, 1.0))
	head.rotation.x = sin(_time * 0.9) * 0.03 - 0.07 * _stealth_pose

	var rest_arm: float = (-0.35 if _holds_weapon else 0.0) - 0.12 * _stealth_pose
	arm_r.rotation.x = s * amp * 0.9 * (0.4 if _holds_weapon else 1.0) + rest_arm
	elbow_r.rotation.x = -0.25 - absf(amp) * 0.4 - (0.5 if _holds_weapon else 0.0)
	arm_l.rotation.z = -0.06
	arm_r.rotation.z = 0.06

	# Cloth follows the body with a soft, delayed sway.
	if _cape_root:
		_cape_root.rotation.x = -0.06 - _move * 0.2 + sin(_time * 2.2) * 0.012
		_cape_root.rotation.z = sin(_phase * 0.5) * 0.025 * _move
	if _skirt_root:
		_skirt_root.rotation.x = -0.035 * _move + sin(_phase * 0.45) * 0.018 * _move
		_skirt_root.rotation.z = sin(_phase * 0.5) * 0.03 * _move

	# Blinking keeps the face alive without extra animation assets.
	_blink_timer -= delta
	if _blink_timer <= 0.0:
		_blink_t = 0.0
		_blink_timer = randf_range(2.4, 5.2)
	if _blink_t >= 0.0:
		_blink_t += delta * 9.0
		var k: float = sin(clampf(_blink_t, 0.0, 1.0) * PI)
		if _eye_root:
			_eye_root.scale = Vector3(1.0, lerpf(1.0, 0.06, k), 1.0)
		if _blink_t >= 1.0:
			_blink_t = -1.0
			if _eye_root:
				_eye_root.scale = Vector3.ONE

	# Small, readable occupation loops make village jobs visible at a distance.
	# They only overlay idle poses, so locomotion and combat animation retain priority.
	if _work_pose != "" and _move < 0.18 and _attack_t < 0.0:
		_work_clock += delta
		var work_swing := sin(_work_clock * (5.8 if _work_pose == "smith" else 2.6))
		match _work_pose:
			"smith":
				arm_r.rotation.x = -1.25 + maxf(0.0, work_swing) * 0.95
				elbow_r.rotation.x = -0.85
				torso.rotation.x = 0.08 + maxf(0.0, work_swing) * 0.08
			"tend":
				arm_r.rotation.x = -0.85 + work_swing * 0.16
				arm_l.rotation.x = -0.65 - work_swing * 0.12
				torso.rotation.x = 0.12 + work_swing * 0.035
			"trade":
				arm_r.rotation.x = -0.48 + work_swing * 0.12
				arm_l.rotation.x = -0.42 - work_swing * 0.12
			"track":
				arm_r.rotation.x = -0.18 + work_swing * 0.08
				arm_l.rotation.x = -0.22 - work_swing * 0.08

	if _attack_t >= 0.0 and (_asset_root == null or not _asset_near):
		_attack_t += delta
		var t: float = _attack_t / attack_duration
		var arm_x: float
		if _stealth_attack:
			if t < 0.34:
				arm_x = lerpf(rest_arm, -1.72, ease(t / 0.34, -2.0))
			elif t < 0.52:
				arm_x = lerpf(-1.72, 0.18, ease((t - 0.34) / 0.18, -1.3))
			else:
				arm_x = lerpf(0.18, rest_arm, clampf((t - 0.52) / 0.48, 0.0, 1.0))
		else:
			if t < 0.3:
				arm_x = lerpf(rest_arm, -2.55, ease(t / 0.3, -2.0))
			elif t < 0.55:
				var k: float = (t - 0.3) / 0.25
				arm_x = lerpf(-2.55, 0.55, 1.0 - pow(1.0 - k, 2.0))
			else:
				arm_x = lerpf(0.55, rest_arm, clampf((t - 0.55) / 0.45, 0.0, 1.0))
		arm_r.rotation.x = arm_x
		elbow_r.rotation.x = lerpf(-1.0, -0.15, clampf((t - 0.25) / 0.3, 0.0, 1.0))
		arm_r.rotation.z = 0.06 - _attack_side * 0.5 * (1.0 - absf(t - 0.4) * 2.0 if t < 0.8 else 0.0)
		var twist: float = lerpf(0.5, -0.55, clampf((t - 0.15) / 0.4, 0.0, 1.0)) * _attack_side
		torso.rotation.y = twist * (0.35 if _stealth_attack else 1.0)
		torso.rotation.x = lerpf(0.0, 0.18, clampf((t - 0.3) / 0.25, 0.0, 1.0)) * (1.0 - clampf((t - 0.6) / 0.4, 0.0, 1.0))
		if _stealth_attack:
			torso.rotation.x -= 0.12 * sin(t * PI)
		if not _impact_sent and t >= 0.42:
			_impact_sent = true
			attack_impact.emit()
		if t >= 1.0:
			_attack_t = -1.0
			_stealth_attack = false
