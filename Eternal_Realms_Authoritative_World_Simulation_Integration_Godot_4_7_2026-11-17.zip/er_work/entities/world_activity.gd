# World activities designed around discovery, resource use and practical skill growth.
extends Area3D

var activity_kind: String = "tracking"
var interact_range: float = 3.8
var _cooldown: float = 0.0
var _completed: bool = false
var _active_puzzle: bool = false
var _replaying: bool = false
var _sequence: Array[int] = []
var _step: int = 0
var _clock: float = 0.0

func _ready() -> void:
	add_to_group("interactable")
	add_to_group("world_activity")
	monitoring = false
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + int(global_position.x * 17.0) + int(global_position.z * 31.0)
	for i in range(4):
		_sequence.append(rng.randi_range(1, 4))

func _process(delta: float) -> void:
	_cooldown = maxf(_cooldown - delta, 0.0)
	_clock += delta
	var light := get_node_or_null("ActivityLight") as OmniLight3D
	if light:
		light.light_energy = 0.35 + absf(sin(_clock * 1.6)) * 0.55
	var flame := get_node_or_null("Flame") as MeshInstance3D
	if flame:
		flame.scale = Vector3(1.0 + sin(_clock * 5.0) * 0.08, 1.0 + absf(cos(_clock * 6.0)) * 0.14, 1.0 + sin(_clock * 4.0) * 0.08)
	if (_active_puzzle or _replaying) and GameManager.player and GameManager.player.global_position.distance_to(global_position) > interact_range * 1.5:
		_active_puzzle = false
		_replaying = false
		_step = 0
		EventBus.toast.emit("You step away from the inscription; its sequence resets.", "info")

func can_interact() -> bool:
	if activity_kind == "archaeology":
		return not _completed and not _active_puzzle and not _replaying
	return _cooldown <= 0.0

func get_prompt() -> String:
	match activity_kind:
		"tracking": return "Study the animal tracks"
		"shoreline": return "Gather at the shoreline"
		"campfire": return "Cook at the campfire"
		"archaeology": return "Read the buried inscription"
		"leyline": return "Attune to the leyline"
	return "Explore"

func interact(player: Node3D = null) -> void:
	match activity_kind:
		"tracking": _study_tracks(player)
		"shoreline": _gather_shore()
		"campfire": _cook(player)
		"archaeology": _begin_archaeology()
		"leyline": _attune(player)

func _study_tracks(player: Node3D) -> void:
	_cooldown = 55.0
	PlayerData.add_item("field_notes", 1)
	PlayerData.add_gold(4)
	PlayerData.stats["tracks_studied"] = int(PlayerData.stats.get("tracks_studied", 0)) + 1
	if player and player.get("skills") != null:
		player.skills.train("tracking", 0.8)
		player.skills.train("observation", 0.65)
		player.skills.train("knowledge", 0.28)
		player.skills.train("exploration", 0.18)
	EventBus.toast.emit("Fresh prints reveal a creature's route, size and direction. Field notes added.", "levelup")
	EventBus.activity.emit("Tracked wildlife through the wilderness", "exploration")

func _gather_shore() -> void:
	_cooldown = 48.0
	var item: String = "seaweed"
	var roll: float = randf()
	if roll < 0.12:
		item = "pearl"
	elif roll < 0.46:
		item = "coral_fragment"
	elif roll < 0.7:
		item = "scale_shard"
	PlayerData.add_item(item, 1 if item == "pearl" else randi_range(1, 2))
	PlayerData.stats["gathered"] = int(PlayerData.stats.get("gathered", 0)) + 1
	if GameManager.player and GameManager.player.get("skills") != null:
		GameManager.player.skills.train("marine_lore", 0.4)
		GameManager.player.skills.train("herbalism", 0.16)
		GameManager.player.skills.train("observation", 0.18)
	EventBus.toast.emit("You carefully gather %s from the tide line." % ItemDB.display_name(ItemDB.make(item)), "loot")

func _cook(player: Node3D) -> void:
	if PlayerData.count_item("wood_log") < 1:
		EventBus.toast.emit("The campfire needs one Wood Log for fuel.", "warning")
		return
	var raw_item: String = ""
	var cooked_item: String = ""
	if PlayerData.count_item("fish_bass") > 0:
		raw_item = "fish_bass"
		cooked_item = "cooked_bass"
	elif PlayerData.count_item("fish_trout") > 0:
		raw_item = "fish_trout"
		cooked_item = "cooked_trout"
	elif PlayerData.count_item("fish_mackerel") > 0:
		raw_item = "fish_mackerel"
		cooked_item = "cooked_mackerel"
	elif PlayerData.count_item("fish_minnow") > 0:
		raw_item = "fish_minnow"
		cooked_item = "cooked_trout"
	if raw_item == "":
		EventBus.toast.emit("Bring a fish and a Wood Log to cook a meal here.", "info")
		return
	PlayerData.remove_item("wood_log", 1)
	PlayerData.remove_item(raw_item, 1)
	PlayerData.add_item(cooked_item, 1)
	if player and player.get("skills") != null:
		player.skills.train("cooking", 0.85)
		player.skills.train("knowledge", 0.08, true)
	EventBus.toast.emit("You cook a %s over the campfire." % ItemDB.display_name(ItemDB.make(cooked_item)), "levelup")
	EventBus.activity.emit("Prepared food from your own catch", "crafting")

func _begin_archaeology() -> void:
	if _completed or _active_puzzle or _replaying:
		return
	_step = 0
	_replaying = true
	EventBus.toast.emit("The inscription describes a forgotten expedition. Watch its four marks, then repeat them with keys 1–4.", "info")
	EventBus.activity.emit("Started an archaeological inscription puzzle", "exploration")
	await _show_inscription_sequence()
	if not is_inside_tree() or not _replaying:
		return
	_replaying = false
	if GameManager.player and GameManager.player.global_position.distance_to(global_position) <= interact_range * 1.5:
		_active_puzzle = true
		EventBus.toast.emit("Your turn: repeat the four inscription marks.", "info")

func _show_inscription_sequence() -> void:
	for rune_index in _sequence:
		if not _replaying or not is_inside_tree():
			return
		var rune_node := get_node_or_null("ActivityRune_%d" % rune_index) as Node3D
		if rune_node:
			rune_node.scale = Vector3.ONE * 1.7
		await get_tree().create_timer(0.4).timeout
		if not _replaying or not is_inside_tree():
			return
		if rune_node and is_instance_valid(rune_node):
			rune_node.scale = Vector3.ONE
		await get_tree().create_timer(0.22).timeout

func _unhandled_key_input(event: InputEvent) -> void:
	if not _active_puzzle or _completed or GameManager.input_locked or not event is InputEventKey or not event.pressed or event.echo:
		return
	var pressed: int = -1
	match event.keycode:
		KEY_1: pressed = 1
		KEY_2: pressed = 2
		KEY_3: pressed = 3
		KEY_4: pressed = 4
	if pressed < 0:
		return
	get_viewport().set_input_as_handled()
	if pressed == _sequence[_step]:
		_step += 1
		if _step == _sequence.size():
			_completed = true
			_active_puzzle = false
			PlayerData.add_item("forgotten_essence", 1)
			PlayerData.add_item("field_notes", 2)
			PlayerData.add_gold(65)
			PlayerData.stats["archaeology"] = int(PlayerData.stats.get("archaeology", 0)) + 1
			var player: Node3D = GameManager.player
			if player and player.get("skills") != null:
				player.skills.train("archaeology", 1.6)
				player.skills.train("ancient_lore", 1.4)
				player.skills.train("knowledge", 1.1)
				player.skills.train("wisdom", 0.8)
			EventBus.toast.emit("Expedition record decoded. Forgotten Essence recovered!", "levelup")
		else:
			EventBus.toast.emit("Inscription fragment %d / 4 recovered." % _step, "info")
	else:
		_step = 0
		EventBus.toast.emit("The sequence is lost. Examine the inscription and retry.", "warning")

func _attune(player: Node3D) -> void:
	_cooldown = 65.0
	if player:
		if player.get("spiritual_energy") != null:
			var current: float = float(player.get("spiritual_energy"))
			var maximum: float = float(player.get("max_spiritual_energy"))
			player.set("spiritual_energy", minf(maximum, current + maximum * 0.55))
		if player.get("skills") != null:
			player.skills.train("cultivation", 0.75)
			player.skills.train("spiritual_sense", 0.7)
			player.skills.train("arcane_attunement", 0.55)
			player.skills.train("wisdom", 0.3)
	EventBus.toast.emit("The leyline steadies your breathing and replenishes spiritual energy.", "levelup")
	EventBus.activity.emit("Meditated at a natural spiritual convergence", "cultivation")
