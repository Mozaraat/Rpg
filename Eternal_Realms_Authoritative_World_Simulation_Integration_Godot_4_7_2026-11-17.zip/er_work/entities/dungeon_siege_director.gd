extends Node3D
## Live siege controller: formations, breachable gate, ram, ladders, defenders and player orders.
var faction_id := "labyrinth"
var faction_name := "Forgotten Faction"
var floor_number := 1
var faction_color := Color(0.55, 0.65, 0.82)
var gate_health := 100.0
var gate_max_health := 100.0
var siege_active := false
var siege_phase := "SECURE"
var player_order := "HOLD"
var _phase_time := 0.0
var _battle_time := 0.0
var _gate_root: Node3D
var _gate_body: StaticBody3D
var _gate_mesh: MeshInstance3D
var _ram: Node3D
var _attackers: Array[Node3D] = []
var _defenders: Array[Node3D] = []
var _banner_material: StandardMaterial3D
var _siege_label: Label3D
var _command_label: Label3D

func _ready() -> void:
	_build_gate()
	_build_ladders()
	_build_ram()
	_build_defensive_weapon()
	_build_interaction()
	_update_label()

func _process(delta: float) -> void:
	if not siege_active: return
	_phase_time += delta
	_battle_time += delta
	if siege_phase == "ASSEMBLING" and _phase_time >= 5.0:
		_set_phase("ASSAULT")
	elif siege_phase == "ASSAULT":
		_advance_attackers(delta)
		if _battle_time >= 3.0:
			_battle_time = 0.0
			if player_order == "BREACH" or player_order == "ASSAULT":
				_damage_gate(8.0 if player_order == "BREACH" else 4.0)
			_defensive_volley()
	elif siege_phase == "BREACHED":
		_advance_attackers(delta * 1.5)
		if _phase_time >= 12.0:
			_resolve_siege(true)
	elif siege_phase == "DEFENDING":
		if _phase_time >= 22.0:
			_resolve_siege(false)
	if _gate_root and gate_health > 0.0:
		var target_angle := -1.35 if player_order == "OPEN_GATE" else 0.0
		_gate_root.rotation.y = lerp_angle(_gate_root.rotation.y, target_angle, delta * 1.8)

func _build_gate() -> void:
	_gate_root = Node3D.new()
	_gate_root.name = "BreachableFortressGate"
	_gate_root.position = Vector3(0, 0.0, -1.88)
	add_child(_gate_root)
	_gate_body = StaticBody3D.new()
	_gate_body.name = "GateCollision"
	_gate_root.add_child(_gate_body)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.25, 2.65, 0.34)
	shape_node.shape = shape
	shape_node.position = Vector3(0, 1.32, 0)
	_gate_body.add_child(shape_node)
	_gate_mesh = MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(2.2, 2.6, 0.28)
	_gate_mesh.mesh = mesh
	_gate_mesh.position = Vector3(0, 1.32, 0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = faction_color.darkened(0.42)
	mat.metallic = 0.35
	_gate_mesh.material_override = mat
	_gate_root.add_child(_gate_mesh)
	for x in [-0.72, -0.24, 0.24, 0.72]:
		var brace := MeshInstance3D.new()
		var brace_mesh := BoxMesh.new()
		brace_mesh.size = Vector3(0.1, 2.5, 0.36)
		brace.mesh = brace_mesh
		brace.position = Vector3(x, 1.32, 0)
		brace.material_override = _make_material(Color(0.28, 0.18, 0.11), 0.12)
		_gate_root.add_child(brace)

func _build_ladders() -> void:
	for side in [-1.0, 1.0]:
		var ladder := Node3D.new()
		ladder.name = "SiegeLadder"
		ladder.position = Vector3(side * 3.25, 0, -1.2)
		ladder.rotation.z = -0.12 * side
		add_child(ladder)
		for rail_x in [-0.48, 0.48]:
			var rail := MeshInstance3D.new()
			var rail_mesh := BoxMesh.new()
			rail_mesh.size = Vector3(0.12, 4.4, 0.14)
			rail.mesh = rail_mesh
			rail.position = Vector3(rail_x, 1.9, 0)
			rail.rotation.x = -0.18
			rail.material_override = _make_material(Color(0.32, 0.2, 0.12))
			ladder.add_child(rail)
		for rung in range(9):
			var step := MeshInstance3D.new()
			var step_mesh := BoxMesh.new()
			step_mesh.size = Vector3(1.0, 0.09, 0.13)
			step.mesh = step_mesh
			step.position = Vector3(0, 0.35 + rung * 0.43, -0.03)
			step.material_override = _make_material(Color(0.42, 0.27, 0.15))
			ladder.add_child(step)

func _build_ram() -> void:
	_ram = Node3D.new()
	_ram.name = "BatteringRam"
	_ram.position = Vector3(0, 0.65, 4.5)
	add_child(_ram)
	var beam := MeshInstance3D.new()
	var beam_mesh := CylinderMesh.new()
	beam_mesh.top_radius = 0.28
	beam_mesh.bottom_radius = 0.28
	beam_mesh.height = 3.2
	beam.mesh = beam_mesh
	beam.rotation.z = PI / 2.0
	beam.material_override = _make_material(Color(0.36, 0.22, 0.12))
	_ram.add_child(beam)
	for side in [-1.0, 1.0]:
		var wheel := MeshInstance3D.new()
		var wheel_mesh := TorusMesh.new()
		wheel_mesh.inner_radius = 0.3
		wheel_mesh.outer_radius = 0.43
		wheel.mesh = wheel_mesh
		wheel.position = Vector3(side * 1.05, -0.28, 0)
		wheel.rotation.x = PI / 2.0
		wheel.material_override = _make_material(Color(0.18, 0.14, 0.1))
		_ram.add_child(wheel)
	_ram.visible = false

func _build_defensive_weapon() -> void:
	var weapon := Node3D.new()
	weapon.name = "FortressBallista"
	weapon.position = Vector3(3.9, 3.7, -2.0)
	add_child(weapon)
	var base := MeshInstance3D.new()
	var base_mesh := BoxMesh.new()
	base_mesh.size = Vector3(1.0, 0.22, 0.75)
	base.mesh = base_mesh
	base.material_override = _make_material(Color(0.2, 0.18, 0.16), 0.5)
	weapon.add_child(base)
	var bow := MeshInstance3D.new()
	var bow_mesh := BoxMesh.new()
	bow_mesh.size = Vector3(1.8, 0.12, 0.16)
	bow.mesh = bow_mesh
	bow.position.y = 0.45
	bow.material_override = _make_material(faction_color.lightened(0.2), 0.4)
	weapon.add_child(bow)

func _build_interaction() -> void:
	var area := Area3D.new()
	area.name = "SiegeCommandPoint"
	area.set_script(load("res://entities/dungeon_siege_interaction.gd"))
	area.set("director_path", NodePath(".."))
	area.set("faction_name", faction_name)
	area.position = Vector3(0, 0.2, 5.6)
	area.add_to_group("interactable")
	area.add_to_group("dungeon_discovery")
	area.set_meta("interact_range", 3.8)
	var collision := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 2.0
	collision.shape = sphere
	area.add_child(collision)
	add_child(area)
	var marker := MeshInstance3D.new()
	var orb := SphereMesh.new()
	orb.radius = 0.24
	orb.height = 0.48
	marker.mesh = orb
	marker.position = Vector3(0, 1.7, 5.6)
	marker.material_override = _make_material(Color(1.0, 0.68, 0.2), 0.7)
	add_child(marker)

func begin_siege() -> void:
	if siege_active: return
	siege_active = true
	gate_health = gate_max_health
	player_order = "ASSAULT"
	_gate_mesh.visible = true
	_gate_mesh.scale = Vector3.ONE
	_gate_mesh.position.y = 1.32
	_gate_root.rotation.y = 0.0
	for brace_child in _gate_root.get_children():
		if brace_child is MeshInstance3D: brace_child.visible = true
	for collision_child in _gate_body.get_children():
		if collision_child is CollisionShape3D: collision_child.set_deferred("disabled", false)
	_gate_body.collision_layer = 1
	_ram.visible = true
	_spawn_formation(_attackers, 7, Color(0.76, 0.3, 0.2), Vector3(0, 0.15, 6.2), true)
	_spawn_formation(_defenders, 5, faction_color, Vector3(0, 0.15, -0.1), false)
	_set_phase("ASSEMBLING")
	_record_event("A siege army assembled outside %s" % faction_name)
	EventBus.toast.emit("Siege assembly begun. Choose your command at the siege point.", "combat")

func get_order_prompt() -> String:
	if not siege_active:
		return "Begin siege assembly"
	match player_order:
		"ASSAULT": return "Order battering ram assault"
		"BREACH": return "Order gate breach and swing gate open"
		"OPEN_GATE": return "Call reinforcement wave from headquarters"
		"REINFORCE": return "Attempt commander negotiations"
		"NEGOTIATE": return "Order withdrawal and defensive perimeter"
		"WITHDRAW": return "Confirm army withdrawal"
	return "Direct siege forces"

func issue_player_order() -> void:
	if not siege_active:
		begin_siege()
		return
	match player_order:
		"ASSAULT":
			player_order = "BREACH"
			_ram.visible = true
			_set_phase("ASSAULT")
			EventBus.toast.emit("Order issued: battering ram assault. Gate integrity is under attack.", "combat")
		"BREACH":
			if gate_health > 0.0:
				EventBus.toast.emit("The gate is still holding at %d%% integrity. Keep the ram on target." % roundi(gate_health / gate_max_health * 100.0), "warning")
			else:
				player_order = "OPEN_GATE"
				_gate_root.rotation.y = -1.35
				EventBus.toast.emit("Order issued: swing the breached gate clear for the assault columns.", "combat")
		"OPEN_GATE":
			player_order = "REINFORCE"
			_spawn_formation(_attackers, 3, Color(0.88, 0.68, 0.28), Vector3(0.0, 0.15, -5.2), true)
			EventBus.toast.emit("A reinforcement wave has marched out from the fortress rear command yard.", "levelup")
		"REINFORCE":
			player_order = "NEGOTIATE"
			var campaign: Node = get_node_or_null("/root/DungeonCampaign")
			if campaign and campaign.negotiate_player_truce(faction_id):
				if campaign.has_method("record_siege_result"): campaign.record_siege_result(floor_number, faction_id, "negotiated_truce")
				_end_siege_neutral()
				EventBus.toast.emit("The defenders accept your terms. The siege ends in a negotiated truce.", "levelup")
			else:
				player_order = "WITHDRAW"
				if campaign: campaign.player_action(faction_id, "attack", -2)
				EventBus.toast.emit("The commander refuses negotiations. Your next order can withdraw the army.", "warning")
		"NEGOTIATE":
			player_order = "WITHDRAW"
			_set_phase("DEFENDING")
			EventBus.toast.emit("Order issued: withdraw and hold the siege perimeter.", "info")
		"WITHDRAW":
			_resolve_siege(false)
			EventBus.toast.emit("Your army withdraws. The fortress remains under its current command.", "info")
	_update_label()

func _spawn_formation(target: Array[Node3D], count: int, color: Color, origin: Vector3, attackers: bool) -> void:
	for i in range(count):
		var soldier := Node3D.new()
		soldier.name = "SiegeSoldier_%d" % target.size()
		var body := MeshInstance3D.new()
		var capsule := CapsuleMesh.new()
		capsule.radius = 0.23
		capsule.height = 1.25
		body.mesh = capsule
		body.position.y = 0.65
		body.material_override = _make_material(color, 0.45)
		soldier.add_child(body)
		var head := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.16
		sphere.height = 0.32
		head.mesh = sphere
		head.position.y = 1.38
		head.material_override = _make_material(Color(0.72, 0.56, 0.42))
		soldier.add_child(head)
		var row := int(i / 3)
		var col := (i % 3) - 1
		soldier.position = origin + Vector3(float(col) * 0.72, 0, float(row) * 0.8)
		add_child(soldier)
		target.append(soldier)

func _advance_attackers(delta: float) -> void:
	var target_z := -0.4 if siege_phase == "BREACHED" else 1.0
	for i in range(_attackers.size()):
		var soldier: Node3D = _attackers[i]
		if not is_instance_valid(soldier): continue
		var goal := Vector3(soldier.position.x * 0.35, soldier.position.y, target_z + absf(soldier.position.x) * 0.15)
		if siege_phase == "ASSAULT" and gate_health < 68.0 and i % 3 == 0:
			goal = Vector3(-3.25 if i % 2 == 0 else 3.25, 2.35, -1.5)
		soldier.position = soldier.position.move_toward(goal, delta * (1.1 if player_order == "ASSAULT" else 1.65))
	if _ram.visible:
		_ram.position.z = move_toward(_ram.position.z, -0.7, delta * 0.65)

func _damage_gate(amount: float) -> void:
	if gate_health <= 0.0: return
	gate_health = maxf(0.0, gate_health - amount)
	if _gate_mesh:
		_gate_mesh.scale.y = maxf(0.12, gate_health / gate_max_health)
		_gate_mesh.position.y = 1.32 * maxf(0.12, gate_health / gate_max_health)
	if gate_health <= 0.0:
		_gate_mesh.visible = false
		for brace_child in _gate_root.get_children():
			if brace_child is MeshInstance3D: brace_child.visible = false
		_gate_body.collision_layer = 0
		_gate_body.collision_mask = 0
		for child in _gate_body.get_children():
			if child is CollisionShape3D: child.set_deferred("disabled", true)
		_set_phase("BREACHED")
		_record_event("The fortress gate was breached by a siege ram")
		EventBus.toast.emit("The fortress gate has been smashed open!", "combat")

func _defensive_volley() -> void:
	if _attackers.is_empty(): return
	var target: Node3D = _attackers[randi_range(0, _attackers.size() - 1)]
	if is_instance_valid(target):
		var hits := int(target.get_meta("defensive_hits", 0)) + 1
		target.set_meta("defensive_hits", hits)
		target.scale = Vector3.ONE * (0.82 if hits == 1 else 0.62)
		if hits >= 2:
			_attackers.erase(target)
			target.queue_free()
		var flash := MeshInstance3D.new()
		var bolt := BoxMesh.new()
		bolt.size = Vector3(0.08, 0.08, maxf(0.4, global_position.distance_to(target.global_position)))
		flash.mesh = bolt
		flash.position = (target.position + Vector3(0, 1.1, -1.2)) * 0.5
		flash.material_override = _make_material(Color(1.0, 0.7, 0.28), 1.0)
		add_child(flash)
		get_tree().create_timer(0.22).timeout.connect(func(): if is_instance_valid(flash): flash.queue_free())
	if _attackers.is_empty():
		_resolve_siege(false)

func _end_siege_neutral() -> void:
	siege_active = false
	_ram.visible = false
	_set_phase("TRUCE")
	for soldier in _attackers + _defenders:
		if is_instance_valid(soldier): soldier.queue_free()
	_attackers.clear()
	_defenders.clear()
	player_order = "HOLD"
	_update_label()

func _resolve_siege(attacker_wins: bool) -> void:
	if not siege_active: return
	siege_active = false
	_ram.visible = false
	var campaign: Node = get_node_or_null("/root/DungeonCampaign")
	if attacker_wins:
		_set_phase("CAPTURED")
		if campaign and campaign.has_method("record_siege_result"):
			campaign.record_siege_result(floor_number, faction_id, "attacker_victory")
		if get_parent() and get_parent().has_method("apply_capture"):
			get_parent().apply_capture("PLAYER_EXPEDITION")
		EventBus.toast.emit("Fortress captured! The campaign territory record has changed.", "levelup")
	else:
		_set_phase("DEFENDED")
		if campaign and campaign.has_method("record_siege_result"):
			campaign.record_siege_result(floor_number, faction_id, "defender_victory")
	for soldier in _attackers + _defenders:
		if is_instance_valid(soldier): soldier.queue_free()
	_attackers.clear()
	_defenders.clear()
	if gate_health > 0.0:
		_gate_root.rotation.y = 0.0
		player_order = "HOLD"
		gate_health = gate_max_health
		_gate_mesh.visible = true
		for brace_child in _gate_root.get_children():
			if brace_child is MeshInstance3D: brace_child.visible = true
		_gate_mesh.scale = Vector3.ONE
		_gate_mesh.position.y = 1.32
		for child in _gate_body.get_children():
			if child is CollisionShape3D: child.set_deferred("disabled", false)
			_gate_body.collision_layer = 1
	else:
		player_order = "HOLD"
	_update_label()

func _set_phase(value: String) -> void:
	siege_phase = value
	_phase_time = 0.0
	_update_label()

func _update_label() -> void:
	if not _siege_label:
		_siege_label = Label3D.new()
		_siege_label.font_size = 18
		_siege_label.position = Vector3(0, 4.0, 5.4)
		_siege_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		add_child(_siege_label)
	_siege_label.text = "SIEGE: %s  ·  GATE %d%%" % [siege_phase, roundi(gate_health / gate_max_health * 100.0)]
	_siege_label.modulate = Color(1.0, 0.72, 0.35) if siege_active else Color(0.72, 0.82, 0.9)
	if not _command_label:
		_command_label = Label3D.new()
		_command_label.font_size = 14
		_command_label.position = Vector3(0, 4.55, 5.4)
		_command_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		add_child(_command_label)
	var order_text := "STAND DOWN"
	match player_order:
		"ASSAULT": order_text = "FORM UP / RAM ASSAULT"
		"BREACH": order_text = "FOCUS THE GATE"
		"OPEN_GATE": order_text = "CLEAR THE BREACH"
		"REINFORCE": order_text = "REINFORCEMENTS MARCH"
		"NEGOTIATE": order_text = "SEEK TERMS"
		"WITHDRAW": order_text = "WITHDRAW / HOLD PERIMETER"
	_command_label.text = "COMMANDER'S ORDER: " + order_text
	_command_label.modulate = Color(1.0, 0.84, 0.48) if siege_active else Color(0.65, 0.75, 0.82)

func _record_event(message: String) -> void:
	var campaign: Node = get_node_or_null("/root/DungeonCampaign")
	if campaign and campaign.has_method("record_siege_event"):
		campaign.record_siege_event(faction_id, floor_number, message)

func _make_material(color: Color, metallic: float = 0.2) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metallic
	mat.roughness = 0.72
	return mat
