# Data-driven field monster / boss. Same combat contract as Slime so player attacks work.
extends CharacterBody3D
class_name Monster

enum State { IDLE, INVESTIGATE, CHASE, RETREAT, WINDUP, DEAD, HUNT_PREY }

@export var monster_id: String = "grey_wolf"
@export var display_name: String = "Grey Wolf"
@export var is_boss: bool = false
@export var body_color: Color = Color(0.45, 0.45, 0.5)
@export var damage: float = 12.0
@export var xp_train: float = 0.5
@export var aggro_range: float = 14.0
@export var leash_range: float = 32.0
@export var move_speed: float = 4.2
@export var attack_range: float = 2.0
@export var max_hp: float = 55.0
@export var growth_rank: int = 0  # 0 normal, 1 veteran, 2 alpha-tier

@onready var health: HealthComponent = $HealthComponent
@onready var label: Label3D = $Label3D

const DAMAGE_NUMBER_SCENE = preload("res://ui/damage_number.tscn")

var state: State = State.IDLE
var home: Vector3 = Vector3.ZERO
var _visual: Node3D
var _humanoid_model: CharacterModel
var _humanoid_attack_fired: bool = false
var _facing_offset: float = 0.0
var _eye_socket_mat: StandardMaterial3D
var _eye_glow_mat: StandardMaterial3D
var _body_mat: StandardMaterial3D
var _t: float = 0.0
var _wander_dir: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0
var _attack_cd: float = 0.0
var _windup: float = 0.0
var _moving: float = 0.0
var _roam_timer: float = 0.0
var _rest_timer: float = 0.0
var _roam_target: Vector3 = Vector3.ZERO
var _boss_phase: int = 0
var _pack_alerted: bool = false
var _animated_limbs: Array[Dictionary] = []
var _creature_asset: CreatureAsset
# Scanned CC0 creature bodies replace the primitive assemblies for the field
# bestiary. Heights match the old procedural silhouettes; tints keep the
# dungeon floor palette while giving each species its own hide.
const CREATURE_VISUALS := {
	"grey_wolf": {"slug": "sabertooth-tiger", "height": 1.05, "gait": "quadruped", "tint": Color(0.72, 0.72, 0.76)},
	"alpha_wolf": {"slug": "sabertooth-tiger", "height": 1.2, "gait": "quadruped", "tint": Color(0.56, 0.54, 0.58)},
	"grave_hound": {"slug": "sabertooth-tiger", "height": 1.1, "gait": "quadruped", "tint": Color(0.56, 0.7, 0.52)},
	"frost_lynx": {"slug": "lynx", "height": 0.95, "gait": "quadruped", "tint": Color(0.7, 0.86, 1.0)},
	"cinder_hound": {"slug": "sabertooth-tiger", "height": 1.1, "gait": "quadruped", "tint": Color(0.82, 0.52, 0.42)},
	"boss_packlord": {"slug": "sabertooth-tiger", "height": 1.55, "gait": "quadruped", "tint": Color(0.52, 0.44, 0.42)},
	"spore_moth": {"slug": "butterfly", "norm": "span", "size": 1.6, "gait": "flyer", "lift": 0.85, "flap": 0.6, "tint": Color(0.78, 1.0, 0.7)},
	"shadow_bat": {"slug": "eagle", "height": 1.05, "gait": "flyer", "lift": 0.9, "flap": 0.12, "tint": Color(0.4, 0.38, 0.55)},
	"prism_stalker": {"slug": "gargoyle", "height": 1.6, "gait": "crawler", "roughness": 0.25, "metallic": 0.35, "tint": Color(0.7, 0.95, 1.0), "glow": Color(0.4, 0.9, 1.0), "glow_energy": 0.3},
	"reef_crab": {"slug": "crab", "height": 0.72, "gait": "crawler", "tint": Color(1.0, 0.76, 0.6)},
	"crystal_mimic": {"slug": "mimic-chest", "height": 0.85, "gait": "crawler", "tint": Color(0.68, 0.62, 0.56), "metallic": 0.2},
	"abyss_mantis": {"slug": "horror-monster", "height": 1.8, "gait": "crawler", "tint": Color(0.62, 0.4, 0.78)},
	"ember_wyrm": {"slug": "hydra", "norm": "length", "size": 3.2, "gait": "serpent", "yaw": 1.5708, "tint": Color(1.0, 0.56, 0.36)},
	"tide_serpent": {"slug": "hydra", "norm": "length", "size": 2.6, "gait": "serpent", "yaw": 1.5708, "tint": Color(0.5, 0.86, 0.96)},
	"boss_depth_serpent": {"slug": "hydra", "norm": "length", "size": 3.6, "gait": "serpent", "yaw": 1.5708, "tint": Color(0.42, 0.64, 0.86)},
	"void_jelly": {"slug": "jellyfish", "height": 0.9, "gait": "blob", "lift": 0.3, "tint": Color(0.78, 0.52, 0.96), "glow": Color(0.6, 0.2, 1.0), "glow_energy": 0.35},
	"king_slime": {"slug": "jellyfish", "height": 1.2, "gait": "blob", "lift": 0.15, "tint": Color(0.62, 0.98, 0.66), "glow": Color(0.4, 1.0, 0.5), "glow_energy": 0.2},
	"cave_slime": {"slug": "jellyfish", "height": 0.6, "gait": "blob", "lift": 0.1, "tint": Color(0.7, 0.95, 0.8), "glow": Color(0.4, 1.0, 0.6), "glow_energy": 0.15},
	"boss_gel_guardian": {"slug": "jellyfish", "height": 1.5, "gait": "blob", "lift": 0.2, "tint": Color(0.55, 0.9, 0.6), "glow": Color(0.35, 1.0, 0.45), "glow_energy": 0.3},
	"dungeon_rat": {"slug": "raccoon", "height": 0.55, "gait": "quadruped", "tint": Color(0.7, 0.66, 0.6)},
	"night_wisp": {"slug": "phoenix", "height": 0.95, "gait": "flyer", "lift": 0.7, "flap": 0.25, "tint": Color(0.6, 0.45, 1.0), "glow": Color(0.55, 0.3, 1.0), "glow_energy": 0.4},
	"boss_void_wisp": {"slug": "phoenix", "height": 1.4, "gait": "flyer", "lift": 0.8, "flap": 0.3, "tint": Color(0.55, 0.4, 0.95), "glow": Color(0.5, 0.25, 1.0), "glow_energy": 0.55},
	"boss_void_herald": {"slug": "horror-monster", "height": 2.3, "gait": "crawler", "tint": Color(0.6, 0.38, 0.88)},
	"bone_skitter": {"slug": "human-skeleton", "height": 1.05, "gait": "crawler", "roughness": 0.8, "tint": Color(0.96, 0.95, 0.88)},
	"boss_bone_tyrant": {"slug": "human-skeleton", "height": 2.0, "gait": "crawler", "roughness": 0.7, "tint": Color(0.94, 0.93, 0.86)},
}
var _attack_pose: float = 0.0
var _colossal_step_timer: float = 0.0
var _raid_special_cooldown: float = 7.0
var _raid_special_pending: bool = false
var _raid_special_pattern: String = "ring_slam"
var _raid_attack_count: int = 0
var _raid_exposed_timer: float = 0.0
var _faction_patrol_index: int = 0
var _raid_target_snapshot: Vector3 = Vector3.ZERO
var _raid_telegraph: Node3D = null
var _player_awareness: float = 0.0
var _lost_player_timer: float = 0.0
var _last_known_player_position: Vector3 = Vector3.ZERO
var _investigate_timer: float = 0.0
var _retreat_timer: float = 0.0
var _tactical_timer: float = 0.0
var _flank_sign: float = 1.0
var _retreat_attempted: bool = false
var _last_resisted_element: String = ""
var _elemental_burn_timer: float = 0.0
var _elemental_burn_tick: float = 0.0
var _elemental_burn_damage: float = 0.0
var _elemental_burn_source: Node = null
var _elemental_slow_timer: float = 0.0
var _elemental_slow_factor: float = 1.0
var _elemental_stagger_timer: float = 0.0
var _elemental_push_velocity: Vector3 = Vector3.ZERO
var _elemental_push_timer: float = 0.0
var _faction_target: Node3D = null
var _faction_scan_timer: float = 0.0
var _faction_attack_timer: float = 0.0
var _faction_reinforcement_used: bool = false
var _prey_target: Node3D = null
var _prey_scan_timer: float = 0.0

# Loot: array of {id, chance, min, max}
var loot_table: Array = []
var gold_min: int = 2
var gold_max: int = 10
var quest_tag: String = ""

func _ready() -> void:
	add_to_group("enemy")
	if is_boss:
		add_to_group("boss")
	home = global_position
	_t = randf() * 10.0
	if bool(get_meta("raid_boss", false)):
		_raid_special_cooldown = 6.0 + float(int(get_meta("raid_floor", 1)) % 4) * 0.8
	if growth_rank >= 1:
		max_hp *= 1.35
		damage *= 1.2
		display_name = "Veteran " + display_name
	if growth_rank >= 2:
		max_hp *= 1.25
		damage *= 1.15
		display_name = display_name.replace("Veteran ", "Alpha ")
		is_boss = is_boss or false
	if health:
		health.max_health = max_hp
		health.current_health = max_hp
		health.is_dead = false
	_build_visual()
	_apply_world_scale()
	if health:
		if not health.health_changed.is_connected(_on_health_changed):
			health.health_changed.connect(_on_health_changed)
		if not health.died.is_connected(_on_died):
			health.died.connect(_on_died)
		_on_health_changed(health.current_health, health.max_health)
	_apply_preset_if_needed()

func _apply_world_scale() -> void:
	# Larger beasts read as large creatures in the landscape and receive matching
	# collision and nameplate dimensions instead of being oversized decorations.
	var size_factor := randf_range(0.94, 1.10)
	if monster_id in ["alpha_wolf", "boss_packlord", "rootbound_guardian", "tide_serpent"]:
		size_factor = randf_range(1.35, 1.7)
	if monster_id in ["king_slime", "boss_gel_guardian", "boss_depth_serpent", "boss_bone_tyrant", "boss_ash_duke", "boss_void_herald"]:
		size_factor = randf_range(1.55, 2.0)
	if growth_rank == 1:
		size_factor *= 1.16
	elif growth_rank >= 2:
		size_factor *= 1.38
	if is_boss:
		size_factor *= 1.12
	if _visual:
		_visual.scale *= size_factor
	if size_factor >= 1.5:
		add_to_group("colossal_beast")
		set_meta("colossal_scale", size_factor)
	max_hp *= size_factor
	damage *= sqrt(size_factor)
	if health:
		health.max_health = max_hp
		health.current_health = max_hp
	var collision := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision and collision.shape:
		collision.shape = collision.shape.duplicate()
		if collision.shape is CapsuleShape3D:
			var capsule := collision.shape as CapsuleShape3D
			capsule.radius *= size_factor
			capsule.height *= size_factor
		collision.position.y *= size_factor
	if label:
		label.position.y *= size_factor
	attack_range *= size_factor

func _apply_preset_if_needed() -> void:
	# Only fill loot if empty (presets set by spawner/director)
	if not loot_table.is_empty():
		return
	match monster_id:
		"grey_wolf":
			loot_table = [
				{"id": "wolf_pelt", "chance": 0.7, "min": 1, "max": 1},
				{"id": "wolf_fang", "chance": 0.45, "min": 1, "max": 2},
				{"id": "bone", "chance": 0.35, "min": 1, "max": 2},
			]
			quest_tag = "grey_wolf"
		"bandit":
			loot_table = [
				{"id": "bandit_coin", "chance": 0.8, "min": 1, "max": 3},
				{"id": "iron_ore", "chance": 0.25, "min": 1, "max": 1},
				{"id": "healing_potion", "chance": 0.2, "min": 1, "max": 1},
			]
			quest_tag = "bandit"
		"night_wisp":
			loot_table = [
				{"id": "ectoplasm", "chance": 0.7, "min": 1, "max": 2},
				{"id": "mana_crystal", "chance": 0.25, "min": 1, "max": 1},
			]
			quest_tag = "night_wisp"
		"stone_crawler":
			loot_table = [
				{"id": "chitin", "chance": 0.7, "min": 1, "max": 2},
				{"id": "iron_ore", "chance": 0.3, "min": 1, "max": 2},
			]
			quest_tag = "stone_crawler"
		"king_slime":
			loot_table = [
				{"id": "slime_core", "chance": 1.0, "min": 2, "max": 4},
				{"id": "slime_gel", "chance": 1.0, "min": 3, "max": 6},
				{"id": "royal_slime_gel", "chance": 1.0, "min": 1, "max": 1},
				{"id": "healing_potion", "chance": 0.8, "min": 1, "max": 2},
			]
			quest_tag = "king_slime"
		"alpha_wolf":
			loot_table = [
				{"id": "wolf_pelt", "chance": 1.0, "min": 2, "max": 3},
				{"id": "alpha_fang", "chance": 1.0, "min": 1, "max": 1},
				{"id": "beast_hide", "chance": 0.8, "min": 1, "max": 2},
			]
			quest_tag = "alpha_wolf"
		"bandit_warlord":
			loot_table = [
				{"id": "bandit_coin", "chance": 1.0, "min": 5, "max": 12},
				{"id": "warlord_blade", "chance": 0.55, "min": 1, "max": 1},
				{"id": "captain_badge", "chance": 1.0, "min": 1, "max": 1},
				{"id": "iron_sword", "chance": 0.35, "min": 1, "max": 1},
			]
			quest_tag = "bandit_warlord"
		"tide_serpent":
			loot_table = [
				{"id": "serpent_scale", "chance": 1.0, "min": 2, "max": 4},
				{"id": "pearl", "chance": 0.6, "min": 1, "max": 2},
				{"id": "coral_fragment", "chance": 0.7, "min": 1, "max": 3},
				{"id": "tide_fang", "chance": 0.4, "min": 1, "max": 1},
			]
			quest_tag = "tide_serpent"
		"bronze_sentinel":
			loot_table = [{"id": "iron_ingot", "chance": 0.42, "min": 1, "max": 2}, {"id": "bronze_charter", "chance": 0.06, "min": 1, "max": 1}]
			quest_tag = "bronze_sentinel"
		"spore_moth":
			loot_table = [{"id": "spore_sac", "chance": 0.8, "min": 1, "max": 2}, {"id": "moonpetal", "chance": 0.2, "min": 1, "max": 1}]
			quest_tag = "spore_moth"
		"prism_stalker":
			loot_table = [{"id": "moonstone_ore", "chance": 0.5, "min": 1, "max": 2}, {"id": "prism_heart", "chance": 0.045, "min": 1, "max": 1}]
			quest_tag = "prism_stalker"
		"grave_hound":
			loot_table = [{"id": "dragonbone", "chance": 0.45, "min": 1, "max": 1}, {"id": "wolf_pelt", "chance": 0.55, "min": 1, "max": 2}]
			quest_tag = "grave_hound"
		"ember_wyrm":
			loot_table = [{"id": "dragonbone", "chance": 0.7, "min": 1, "max": 2}, {"id": "ember_insignia", "chance": 0.035, "min": 1, "max": 1}]
			quest_tag = "ember_wyrm"
		"frost_lynx":
			loot_table = [{"id": "wolf_pelt", "chance": 0.75, "min": 1, "max": 2}, {"id": "moonstone_ore", "chance": 0.15, "min": 1, "max": 1}]
			quest_tag = "frost_lynx"
		"reef_crab":
			loot_table = [{"id": "coral_fragment", "chance": 0.85, "min": 1, "max": 3}, {"id": "pearl", "chance": 0.25, "min": 1, "max": 1}, {"id": "scale_shard", "chance": 0.4, "min": 1, "max": 2}]
			quest_tag = "reef_crab"
		"rootbound_guardian":
			loot_table = [{"id": "wood_log", "chance": 0.65, "min": 1, "max": 3}, {"id": "choir_seed", "chance": 0.05, "min": 1, "max": 1}]
			quest_tag = "rootbound_guardian"
		"void_jelly":
			loot_table = [{"id": "void_essence", "chance": 0.8, "min": 1, "max": 2}, {"id": "abyssal_relic", "chance": 0.08, "min": 1, "max": 1}]
			quest_tag = "void_jelly"
		"astral_scribe":
			loot_table = [{"id": "astral_dust", "chance": 0.85, "min": 1, "max": 2}, {"id": "celestial_codex", "chance": 0.025, "min": 1, "max": 1}]
			quest_tag = "astral_scribe"
		_:
			loot_table = [{"id": "bone", "chance": 0.5, "min": 1, "max": 1}]

func _build_visual() -> void:
	_visual = Node3D.new()
	_visual.name = "Visual"
	add_child(_visual)
	_humanoid_model = null
	_creature_asset = null
	_animated_limbs.clear()
	_body_mat = _make_mat(body_color, 0.55, 0.05)
	if is_boss:
		_body_mat.emission_enabled = true
		_body_mat.emission = body_color.lightened(0.25)
		_body_mat.emission_energy_multiplier = 0.55
		_add_boss_aura()
	if _build_asset_creature():
		if is_boss:
			_visual.scale = Vector3.ONE * (1.55 if monster_id == "boss_final_abyss" else 1.28)
		return
	match monster_id:
		"grey_wolf", "alpha_wolf":
			_build_wolf(is_boss or monster_id == "alpha_wolf")
		"grave_hound", "frost_lynx":
			_build_wolf(true)
		"bronze_sentinel", "rootbound_guardian", "astral_scribe":
			_build_humanoid(monster_id != "astral_scribe" or is_boss)
		"spore_moth":
			_build_bat()
		"prism_stalker", "reef_crab":
			_build_crawler(monster_id == "prism_stalker")
		"ember_wyrm":
			_build_serpent()
		"void_jelly":
			_build_slime(true)
		"bandit", "bandit_warlord":
			_build_humanoid(monster_id == "bandit_warlord" or is_boss)
		"night_wisp", "boss_void_wisp":
			_build_wisp()
		"fungal_stalker", "drowned_guard", "rune_stalker", "grave_knight", "ember_shaman":
			_build_humanoid(monster_id == "grave_knight" or monster_id == "ember_shaman")
		"crystal_mimic", "abyss_mantis":
			_build_crawler(monster_id == "crystal_mimic")
		"cinder_hound":
			_build_wolf(true)
		"void_stalker":
			_build_humanoid(true)
		"stone_crawler", "iron_golem_shard":
			_build_humanoid(monster_id == "iron_golem_shard")
		"king_slime", "cave_slime", "boss_gel_guardian":
			_build_slime(monster_id != "cave_slime")
		"tide_serpent", "boss_depth_serpent":
			_build_serpent()
		"dungeon_rat":
			_build_rat()
		"bone_skitter", "boss_bone_tyrant":
			_build_bone(is_boss or monster_id == "boss_bone_tyrant")
		"shadow_bat":
			_build_bat()
		"ash_imp", "boss_ash_duke":
			_build_humanoid(monster_id == "boss_ash_duke" or is_boss)
		"void_mite":
			_build_humanoid(is_boss)
		"boss_void_herald":
			_build_void(is_boss)
		"boss_packlord":
			_build_wolf(true)
		"boss_depth_captain", "boss_iron_warden":
			_build_humanoid(true)
		"boss_shadow_matron":
			_build_matron()
		"boss_echo_king", "boss_final_abyss":
			_build_abyss_lord()
		_:
			_build_generic()
	_facing_offset = _forward_offset()
	_add_eyes()
	_add_species_details()
	if is_boss:
		_visual.scale = Vector3.ONE * (1.55 if monster_id == "boss_final_abyss" else 1.28)

func _build_asset_creature() -> bool:
	var cfg: Dictionary = CREATURE_VISUALS.get(monster_id, {})
	if cfg.is_empty():
		return false
	var node := CreatureAsset.new()
	node.name = "CreatureBody"
	var base_tint: Color = body_color.lerp(Color.WHITE, 0.5)
	var mood: Color = cfg.get("tint", Color.WHITE)
	var tint := Color(base_tint.r * mood.r, base_tint.g * mood.g, base_tint.b * mood.b)
	tint = Color(clampf(tint.r, 0.05, 1.2), clampf(tint.g, 0.05, 1.2), clampf(tint.b, 0.05, 1.2))
	var ok: bool = node.build(str(cfg.get("slug", "")), {
		"size": float(cfg.get("size", cfg.get("height", 1.0))),
		"norm": str(cfg.get("norm", "height")),
		"gait": str(cfg.get("gait", "quadruped")),
		"yaw": float(cfg.get("yaw", PI)),
		"lift": float(cfg.get("lift", 0.0)),
		"flap": float(cfg.get("flap", 0.0)),
		"tint": tint,
		"roughness": float(cfg.get("roughness", -1.0)),
		"metallic": float(cfg.get("metallic", -1.0)),
		"glow": cfg.get("glow", Color(0, 0, 0)),
		"glow_energy": float(cfg.get("glow_energy", 0.0)),
	})
	if not ok:
		node.free()
		return false
	_visual.add_child(node)
	_creature_asset = node
	return true

func _forward_offset() -> float:
	if _creature_asset != null:
		return 0.0
	# Crawlers, wolves, serpents and rats are modelled looking down +X; the rest
	# of the creature family faces +Z. Humanoids use the shared CharacterModel,
	# which faces -Z. The steering code aims local -Z along the velocity.
	if _humanoid_model != null:
		return 0.0
	if monster_id in [
		"grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx", "cinder_hound", "boss_packlord",
		"prism_stalker", "reef_crab", "crystal_mimic", "abyss_mantis", "stone_crawler", "iron_golem_shard",
		"ember_wyrm", "tide_serpent", "boss_depth_serpent", "dungeon_rat",
	]:
		return PI * 0.5
	if monster_id in ["night_wisp", "boss_void_wisp", "void_mite", "void_stalker", "boss_void_herald"]:
		return 0.0
	return PI

func _add_species_details() -> void:
	if _humanoid_model != null or _creature_asset != null:
		return
	var dark_mat := _make_mat(body_color.darkened(0.42), 0.82, 0.12)
	var plate_mat := _make_mat(body_color.lightened(0.2), 0.42, 0.38)
	var glow_mat := _make_mat(body_color.lightened(0.45), 0.18, 0.08)
	glow_mat.emission_enabled = true
	glow_mat.emission = body_color.lightened(0.5)
	glow_mat.emission_energy_multiplier = 1.25
	match monster_id:
		"grey_wolf", "alpha_wolf", "cinder_hound", "boss_packlord":
			# Extra mane spikes and a leather war collar for the pack leaders.
			for i in range(3):
				_add_cone(Vector3(-0.16 + float(i) * 0.15, 0.84, 0.0), 0.04, 0.11 + float(i) * 0.02, dark_mat)
			if monster_id in ["alpha_wolf", "boss_packlord", "cinder_hound"]:
				var collar: MeshInstance3D = _add_cyl(Vector3(0.45, 0.61, 0), 0.235, 0.045, dark_mat)
				collar.rotation.z = PI * 0.5
				_add_sphere(Vector3(0.45, 0.4, 0.0), 0.04, plate_mat)
		"stone_crawler", "iron_golem_shard", "crystal_mimic", "abyss_mantis", "prism_stalker", "reef_crab":
			# Layered carapace plating, crystal growths and species-specific weapon arms.
			for i in range(3):
				var plate := _add_ellipsoid(Vector3(-0.26 + float(i) * 0.2, 0.56 - float(i) * 0.012, 0.0), Vector3(0.19, 0.06, 0.36 - float(i) * 0.04), plate_mat)
				plate.rotation.z = -0.14 if i == 0 else (0.14 if i == 2 else 0.0)
			match monster_id:
				"crystal_mimic", "prism_stalker":
					for i in range(3):
						var shard := _add_cone(Vector3(-0.24 + float(i) * 0.22, 0.66, 0.0), 0.055, 0.34 + float(i) * 0.08, glow_mat)
						shard.rotation.z = (float(i) - 1.0) * 0.22
				"reef_crab":
					for side in [-1.0, 1.0]:
						_add_rod(Vector3(0.42, 0.34, side * 0.26), Vector3(0.78, 0.3, side * 0.42), 0.045, plate_mat)
						var claw := _add_ellipsoid(Vector3(0.86, 0.3, side * 0.46), Vector3(0.14, 0.1, 0.1), plate_mat)
						claw.rotation.z = -0.25
						_add_cone(Vector3(1.0, 0.3, side * 0.5), 0.035, 0.16, dark_mat).rotation.z = -PI * 0.5
				"abyss_mantis":
					for side in [-1.0, 1.0]:
						_add_rod(Vector3(0.34, 0.44, side * 0.2), Vector3(0.7, 0.16, side * 0.42), 0.04, dark_mat)
						var blade := _add_ellipsoid(Vector3(0.84, 0.13, side * 0.48), Vector3(0.24, 0.035, 0.05), plate_mat)
						blade.rotation.y = side * 0.18
						_add_cone(Vector3(1.04, 0.11, side * 0.51), 0.028, 0.2, dark_mat).rotation.z = -PI * 0.5
				_:
					for i in range(4):
						var spike := _add_cone(Vector3(-0.3 + float(i) * 0.16, 0.62, 0.0), 0.04, 0.12, dark_mat)
						spike.rotation.z = (float(i) - 1.5) * 0.16
		"bone_skitter", "boss_bone_tyrant":
			# Jagged spine spurs and an antler crown for the bone tyrant.
			for i in range(4):
				var spur := _add_cone(Vector3(0, 0.86 + float(i) * 0.11, -0.06), 0.035, 0.16 + float(i) * 0.02, plate_mat)
				spur.rotation.x = -0.5
			if monster_id == "boss_bone_tyrant":
				for side in [-1.0, 1.0]:
					_add_rod(Vector3(side * 0.1, 1.4, 0.02), Vector3(side * 0.22, 1.58, -0.02), 0.028, plate_mat)
					_add_rod(Vector3(side * 0.22, 1.58, -0.02), Vector3(side * 0.34, 1.66, 0.1), 0.022, plate_mat)
		"ash_imp", "boss_ash_duke":
			# Shoulder spikes and a molten ember heart; the duke grows a second crown of horns.
			for side in [-1.0, 1.0]:
				var spike := _add_cone(Vector3(side * 0.24, 0.96, 0.0), 0.055, 0.24, plate_mat)
				spike.rotation.z = side * 0.55
				if monster_id == "boss_ash_duke":
					_add_rod(Vector3(side * 0.1, 1.19, 0.02), Vector3(side * 0.18, 1.42, 0.06), 0.032, dark_mat)
			_add_sphere(Vector3(0, 0.72, 0.17), 0.075, glow_mat)
		"void_mite", "void_stalker", "boss_void_herald", "boss_final_abyss":
			# Floating orbit shards and luminous core.
			for i in range(6):
				var a: float = TAU * float(i) / 6.0
				var shard := _add_cyl(Vector3(cos(a) * 0.55, 0.72 + sin(a * 2.0) * 0.18, sin(a) * 0.55), 0.045, 0.3, glow_mat)
				shard.rotation.z = cos(a) * 0.65
			_add_sphere(Vector3(0, 0.72, 0.25), 0.13, glow_mat)
		"dungeon_rat":
			_add_sphere(Vector3(0.46, 0.29, 0.055), 0.045, dark_mat)
			_add_sphere(Vector3(0.46, 0.29, -0.055), 0.045, dark_mat)
		"night_wisp", "boss_void_wisp":
			for i in range(3):
				var ring := MeshInstance3D.new()
				var torus := TorusMesh.new()
				torus.inner_radius = 0.35 + float(i) * 0.12
				torus.outer_radius = 0.39 + float(i) * 0.12
				ring.mesh = torus
				ring.material_override = glow_mat
				ring.position.y = 0.72
				ring.rotation = Vector3(0.6 + float(i) * 0.45, 0, float(i) * 0.8)
				_visual.add_child(ring)
		"boss_depth_captain", "boss_iron_warden", "grave_knight", "drowned_guard", "rune_stalker":
			# Shoulder pauldrons, chest crest and heavier gauntlets.
			for side in [-1.0, 1.0]:
				_add_sphere(Vector3(side * 0.36, 1.02, 0), 0.19, plate_mat)
				_add_box(Vector3(side * 0.39, 0.62, 0.08), Vector3(0.16, 0.2, 0.18), dark_mat)
			_add_box(Vector3(0, 0.98, 0.27), Vector3(0.22, 0.26, 0.08), glow_mat)
		"boss_shadow_matron", "boss_echo_king":
			# Crown points and layered spectral mantle.
			for i in range(5):
				var a: float = TAU * float(i) / 5.0
				var point := _add_cyl(Vector3(cos(a) * 0.25, 2.02, sin(a) * 0.25), 0.045, 0.42, glow_mat)
				point.rotation.z = cos(a) * 0.55
			_add_box(Vector3(0, 0.55, -0.24), Vector3(1.0, 0.7, 0.12), dark_mat)

		"bronze_sentinel":
			_add_box(Vector3(0, 0.92, 0.27), Vector3(0.58, 0.55, 0.14), plate_mat)
			_add_sphere(Vector3(0, 1.48, 0.0), 0.24, glow_mat)
			for side in [-1.0, 1.0]:
				var shoulder := _add_box(Vector3(side * 0.38, 1.04, 0), Vector3(0.34, 0.25, 0.42), plate_mat)
		"spore_moth":
			var wing_mat := _make_mat(body_color.lightened(0.35), 0.32, 0.0)
			wing_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			wing_mat.albedo_color = Color(wing_mat.albedo_color.r, wing_mat.albedo_color.g, wing_mat.albedo_color.b, 0.82)
			wing_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
			wing_mat.emission_enabled = true
			wing_mat.emission = body_color.lightened(0.4)
			wing_mat.emission_energy_multiplier = 0.7
			for side in [-1.0, 1.0]:
				var pivot := Node3D.new()
				pivot.position = Vector3(0, 0.84, 0.02)
				_visual.add_child(pivot)
				var wing := _add_ellipsoid(Vector3(side * 0.46, 0.05, -0.16), Vector3(0.46, 0.035, 0.4), wing_mat, pivot)
				wing.rotation.z = side * 0.22
				var spot := _add_sphere(Vector3(side * 0.44, 0.11, -0.3), 0.12, glow_mat, pivot)
				spot.scale = Vector3(1.0, 0.14, 1.0)
				_register_limb(pivot, 0.0)
			for i in range(3):
				_add_sphere(Vector3(-0.3 + float(i) * 0.3, 0.55, 0.35), 0.07, glow_mat)
		"prism_stalker":
			for i in range(5):
				var crystal := _add_cyl(Vector3(-0.38 + float(i) * 0.19, 0.98 + (0.12 if i % 2 == 0 else 0.0), 0.0), 0.065, 0.55, glow_mat)
				crystal.rotation.z = 0.25 if i % 2 == 0 else -0.25
		"grave_hound", "frost_lynx":
			for i in range(3):
				var mane: MeshInstance3D = _add_ellipsoid(Vector3(0.38 + float(i) * 0.05, 0.76 + float(i) * 0.035, 0.0), Vector3(0.09, 0.16, 0.08), glow_mat if monster_id == "frost_lynx" else plate_mat)
				mane.rotation.z = -0.3
			if monster_id == "frost_lynx":
				for side in [-1.0, 1.0]:
					var shard: MeshInstance3D = _add_cone(Vector3(0.15, 0.86, side * 0.18), 0.045, 0.28, glow_mat)
					shard.rotation.z = side * 0.2
		"ember_wyrm":
			for i in range(5):
				var dorsal := _add_cone(Vector3(0.34 - float(i) * 0.26, 0.5 - float(i) * 0.015, 0), 0.045, 0.2 + float(i) * 0.015, glow_mat)
				dorsal.rotation.x = -0.35
		"tide_serpent", "boss_depth_serpent":
			for i in range(4):
				var fin := _add_ellipsoid(Vector3(0.3 - float(i) * 0.3, 0.5 - float(i) * 0.02, 0), Vector3(0.12, 0.13 + float(i) * 0.02, 0.02), glow_mat)
				fin.rotation.z = 0.2
			for side in [-1.0, 1.0]:
				var side_fin := _add_ellipsoid(Vector3(0.44, 0.4, side * 0.22), Vector3(0.16, 0.05, 0.12), glow_mat)
				side_fin.rotation.y = side * 0.5
		"reef_crab":
			for side in [-1.0, 1.0]:
				var claw := _add_ellipsoid(Vector3(side * 0.78, 0.4, -0.1), Vector3(0.28, 0.23, 0.3), plate_mat)
				_register_limb(claw, PI if side < 0.0 else 0.0)
				for leg_i in range(3):
					var leg := _add_cyl(Vector3(side * (0.45 + float(leg_i) * 0.12), 0.28, -0.35 + float(leg_i) * 0.35), 0.035, 0.6, dark_mat)
					leg.rotation.z = side * 0.8
					_register_limb(leg, float(leg_i) * PI * 0.5)
		"rootbound_guardian":
			for side in [-1.0, 1.0]:
				var root_arm := _add_cyl(Vector3(side * 0.48, 0.78, 0), 0.06, 1.0, dark_mat)
				root_arm.rotation.z = side * 0.52
				_register_limb(root_arm, PI if side < 0.0 else 0.0)
			for i in range(4):
				_add_cyl(Vector3(-0.24 + float(i) * 0.16, 1.25, -0.1), 0.05, 0.65, glow_mat)
		"void_jelly":
			for i in range(6):
				var tentacle := _add_cyl(Vector3(-0.36 + float(i) * 0.14, 0.24, 0.05), 0.035, 0.72, glow_mat)
				tentacle.rotation.z = (float(i) - 2.5) * 0.12
				_register_limb(tentacle, float(i) * 0.6)
		"astral_scribe":
			for i in range(3):
				var ring := MeshInstance3D.new(); var ring_mesh := TorusMesh.new(); ring_mesh.inner_radius = 0.42 + float(i) * 0.12; ring_mesh.outer_radius = ring_mesh.inner_radius + 0.035; ring.mesh = ring_mesh; ring.material_override = glow_mat; ring.position.y = 0.92; ring.rotation = Vector3(0.5 + float(i) * 0.4, 0, 0); _visual.add_child(ring)
			_add_sphere(Vector3(0, 1.55, 0.1), 0.11, glow_mat)



func _make_mat(col: Color, rough: float, metal: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	m.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
	if metal < 0.5:
		m.rim_enabled = true
		m.rim = 0.09 if rough < 0.7 else 0.05
		m.rim_tint = 0.45 if rough < 0.6 else 0.25
	return m

func _add_mesh(mesh: Mesh, pos: Vector3, mat: Material = null, scale_v: Vector3 = Vector3.ONE, parent: Node3D = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat if mat else _body_mat
	mi.position = pos
	mi.scale = scale_v
	if parent:
		parent.add_child(mi)
	else:
		_visual.add_child(mi)
	return mi

func _register_limb(node: Node3D, phase: float) -> Node3D:
	# Limb pivots are plain Node3Ds: child meshes are laid out in the pivot's local
	# space, so the pivot itself is the joint. Driving its rotation keeps the joint
	# exactly where the body was built instead of depending on a skin bind pose.
	_animated_limbs.append({"node": node, "base": node.rotation, "phase": phase})
	return node

func _add_ellipsoid(pos: Vector3, scale_v: Vector3, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radial_segments = 20
	mesh.rings = 12
	return _add_mesh(mesh, pos, mat, scale_v, parent)

func _add_sphere(pos: Vector3, r: float, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 20
	sm.rings = 12
	return _add_mesh(sm, pos, mat, Vector3.ONE, parent)

func _add_box(pos: Vector3, size: Vector3, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	return _add_mesh(bm, pos, mat, Vector3.ONE, parent)

func _add_capsule(pos: Vector3, r: float, h: float, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var cm := CapsuleMesh.new()
	cm.radius = r
	cm.height = h
	cm.radial_segments = 16
	cm.rings = 6
	return _add_mesh(cm, pos, mat, Vector3.ONE, parent)

func _add_cyl(pos: Vector3, r: float, h: float, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r * 1.1
	cm.height = h
	cm.radial_segments = 16
	return _add_mesh(cm, pos, mat, Vector3.ONE, parent)

func _add_cone(pos: Vector3, r: float, h: float, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = 0.002
	cm.bottom_radius = r
	cm.height = h
	cm.radial_segments = 12
	return _add_mesh(cm, pos, mat, Vector3.ONE, parent)

func _add_rod(a: Vector3, b: Vector3, r: float, mat: Material = null, parent: Node3D = null) -> MeshInstance3D:
	var delta: Vector3 = b - a
	var mi: MeshInstance3D = _add_cyl((a + b) * 0.5, r, maxf(delta.length(), 0.01), mat, parent)
	if delta.length_squared() > 0.0001:
		mi.quaternion = Quaternion(Vector3.UP, delta.normalized())
	return mi

func _wing_mesh(span: float, chord: float, sag: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var root := Vector3.ZERO
	var elbow := Vector3(span * 0.42, -sag * 0.35, -chord * 0.08)
	var tip := Vector3(span, -sag, -chord * 0.12)
	var mid := Vector3(span * 0.66, -sag * 0.75, -chord * 0.62)
	var back := Vector3(span * 0.18, -sag * 0.2, -chord * 0.48)
	for tri in [[root, elbow, tip], [root, tip, mid], [root, mid, back]]:
		for vertex in tri:
			st.set_normal(Vector3.UP)
			st.add_vertex(vertex)
	return st.commit()

func _add_boss_aura() -> void:
	var light := OmniLight3D.new()
	light.light_color = body_color.lightened(0.3)
	light.light_energy = 1.4
	light.omni_range = 5.0
	light.position = Vector3(0, 1.2, 0)
	_visual.add_child(light)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.55
	tm.outer_radius = 0.7
	ring.mesh = tm
	var rm := _make_mat(body_color.lightened(0.4), 0.3, 0.2)
	rm.emission_enabled = true
	rm.emission = body_color
	rm.emission_energy_multiplier = 1.2
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.albedo_color = Color(body_color.r, body_color.g, body_color.b, 0.45)
	ring.material_override = rm
	ring.position = Vector3(0, 0.15, 0)
	ring.name = "BossRing"
	_visual.add_child(ring)

func _add_eyes() -> void:
	if _humanoid_model != null or _creature_asset != null:
		return
	# Default forward eyes; individual builds may already have custom eyes.
	if _visual.get_node_or_null("EyeL") != null:
		return
	if monster_id in ["night_wisp", "boss_void_wisp", "boss_echo_king", "boss_final_abyss"]:
		return
	var eye_col := _eye_color()
	var glow_mat := _make_mat(eye_col, 0.18, 0.0)
	glow_mat.emission_enabled = true
	glow_mat.emission = eye_col.lightened(0.2)
	glow_mat.emission_energy_multiplier = 2.4
	_eye_socket_mat = _make_mat(Color(0.035, 0.025, 0.025), 0.65, 0.0)
	_eye_glow_mat = glow_mat
	match monster_id:
		"grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx", "cinder_hound", "boss_packlord":
			_eye_pair(Vector3(0.735, 0.735, 0.0), 0.026, 0.083, Vector3(0, 0, 1), Vector3(1, 0, 0))
		"prism_stalker", "reef_crab", "crystal_mimic", "abyss_mantis", "stone_crawler", "iron_golem_shard":
			_eye_pair(Vector3(0.6, 0.44, 0.0), 0.023, 0.078, Vector3(0, 0, 1), Vector3(1, 0, 0))
		"ember_wyrm", "tide_serpent", "boss_depth_serpent":
			_eye_pair(Vector3(0.7, 0.5, 0.0), 0.027, 0.105, Vector3(0, 0, 1), Vector3(1, 0, 0))
		"dungeon_rat":
			_eye_pair(Vector3(0.4, 0.38, 0.0), 0.016, 0.07, Vector3(0, 0, 1), Vector3(1, 0, 0))
		"bone_skitter", "boss_bone_tyrant":
			_eye_pair(Vector3(0, 1.26, 0.2), 0.027, 0.07, Vector3(1, 0, 0), Vector3(0, 0, 1))
		"shadow_bat":
			_eye_pair(Vector3(0, 0.83, 0.2), 0.025, 0.062, Vector3(1, 0, 0), Vector3(0, 0, 1))
		"spore_moth":
			_eye_pair(Vector3(0, 0.88, 0.16), 0.024, 0.06, Vector3(1, 0, 0), Vector3(0, 0, 1))
		"ash_imp", "boss_ash_duke":
			_eye_pair(Vector3(0, 1.04, 0.19), 0.022, 0.062, Vector3(1, 0, 0), Vector3(0, 0, 1))
		"king_slime", "cave_slime", "boss_gel_guardian", "void_jelly":
			var big: bool = monster_id in ["king_slime", "boss_gel_guardian", "void_jelly"]
			var r: float = 0.9 if big else 0.45
			_eye_pair(Vector3(0, r * 0.95, r * 0.9), 0.034 if big else 0.027, 0.13 if big else 0.1, Vector3(1, 0, 0), Vector3(0, 0, 1))
		"void_mite", "boss_void_herald":
			_eye_pair(Vector3(0, 0.62, 0.35), 0.024, 0.085, Vector3(1, 0, 0), Vector3(0, 0, 1))
		_:
			_eye_pair(Vector3(0, 1.02, 0.2), 0.026, 0.072, Vector3(1, 0, 0), Vector3(0, 0, 1))

func _eye_pair(center: Vector3, radius: float, spread: float, lateral: Vector3, forward: Vector3) -> void:
	var catch_mat := _make_mat(Color(1, 1, 1), 0.08, 0.0)
	catch_mat.emission_enabled = true
	catch_mat.emission = Color(1, 1, 1)
	catch_mat.emission_energy_multiplier = 1.2
	for side in [-1.0, 1.0]:
		var p: Vector3 = center + lateral * side * spread
		var socket: MeshInstance3D = _add_sphere(p - forward * radius * 0.55, radius * 1.45, _eye_socket_mat)
		socket.name = "EyeSocket"
		var eye: MeshInstance3D = _add_sphere(p, radius, _eye_glow_mat)
		eye.name = "EyeL" if side < 0.0 else "EyeR"
		_add_sphere(p + forward * radius * 0.78 + Vector3(0, radius * 0.32, 0), radius * 0.28, catch_mat)

func _eye_color() -> Color:
	match monster_id:
		"grey_wolf", "alpha_wolf", "boss_packlord", "cinder_hound", "grave_hound":
			return Color(1.0, 0.42, 0.12)
		"frost_lynx":
			return Color(0.45, 0.82, 1.0)
		"prism_stalker", "crystal_mimic":
			return Color(0.45, 0.95, 0.95)
		"reef_crab", "stone_crawler":
			return Color(0.85, 0.72, 0.25)
		"abyss_mantis", "iron_golem_shard":
			return Color(0.95, 0.3, 0.2)
		"ember_wyrm", "tide_serpent", "boss_depth_serpent":
			return Color(1.0, 0.58, 0.15) if monster_id == "ember_wyrm" else Color(0.35, 0.85, 1.0)
		"dungeon_rat":
			return Color(1.0, 0.22, 0.18)
		"bone_skitter", "boss_bone_tyrant":
			return Color(0.55, 1.0, 0.5)
		"shadow_bat", "spore_moth":
			return Color(0.7, 0.45, 1.0) if monster_id == "shadow_bat" else Color(0.65, 0.95, 0.35)
		"ash_imp", "boss_ash_duke":
			return Color(1.0, 0.38, 0.1)
		"king_slime", "cave_slime", "boss_gel_guardian":
			return Color(0.55, 1.0, 0.6)
		"void_jelly", "void_mite", "void_stalker", "boss_void_herald":
			return Color(0.7, 0.4, 1.0)
		_:
			return Color(1.0, 0.7, 0.25)

func _build_wolf(elite: bool) -> void:
	# A layered, muscular quadruped: fur masses, a raised mane, articulated legs
	# with claws and a proper muzzle instead of a single blocky body.
	_body_mat.roughness = 0.82
	var fur_dark := _make_mat(body_color.darkened(0.3), 0.86, 0.0)
	var fur_light := _make_mat(body_color.lightened(0.16), 0.8, 0.0)
	var nose_mat := _make_mat(Color(0.045, 0.038, 0.035), 0.32, 0.08)
	var fang_mat := _make_mat(Color(0.94, 0.92, 0.82), 0.28, 0.1)
	var claw_mat := _make_mat(Color(0.15, 0.13, 0.11), 0.42, 0.08)
	# Torso: chest, barrel and haunches.
	_add_ellipsoid(Vector3(0.24, 0.56, 0), Vector3(0.34, 0.33, 0.41))
	_add_ellipsoid(Vector3(-0.03, 0.52, 0), Vector3(0.39, 0.3, 0.45))
	_add_ellipsoid(Vector3(-0.34, 0.5, 0), Vector3(0.29, 0.31, 0.35), fur_dark)
	_add_ellipsoid(Vector3(0.05, 0.38, 0), Vector3(0.33, 0.09, 0.29), fur_light)
	# Neck and wedge-shaped head.
	_add_ellipsoid(Vector3(0.47, 0.65, 0), Vector3(0.23, 0.23, 0.25), fur_dark)
	_add_ellipsoid(Vector3(0.63, 0.69, 0), Vector3(0.21, 0.19, 0.2))
	_add_ellipsoid(Vector3(0.78, 0.625, 0), Vector3(0.2, 0.115, 0.135), fur_light)
	_add_ellipsoid(Vector3(0.75, 0.565, 0), Vector3(0.15, 0.055, 0.1), fur_dark)
	_add_ellipsoid(Vector3(0.965, 0.64, 0), Vector3(0.042, 0.034, 0.046), nose_mat)
	for side in [-1.0, 1.0]:
		var fang: MeshInstance3D = _add_cone(Vector3(0.875, 0.55, side * 0.052), 0.018, 0.075, fang_mat)
		fang.rotation.x = PI
		# Tall ears with a darker inner cup.
		var ear: MeshInstance3D = _add_cone(Vector3(0.56, 0.86, side * 0.135), 0.062, 0.22, fur_dark)
		ear.rotation.z = side * 0.16
		var inner: MeshInstance3D = _add_cone(Vector3(0.573, 0.855, side * 0.138), 0.038, 0.15, fur_light)
		inner.rotation.z = side * 0.16
	# Raised neck ruff and a dorsal mane.
	for i in range(7):
		var a: float = TAU * float(i) / 7.0
		var ruff_pos := Vector3(0.43 + cos(a) * 0.03, 0.66 + cos(a) * 0.16, sin(a) * 0.23)
		var tuft: MeshInstance3D = _add_ellipsoid(ruff_pos, Vector3(0.09, 0.13, 0.075), fur_dark)
		tuft.rotation.x = sin(a) * 0.4
	for i in range(5):
		var x: float = 0.34 - float(i) * 0.14
		var spike: MeshInstance3D = _add_cone(Vector3(x, 0.78, 0.0), 0.05, 0.13 + float(i % 2) * 0.05, fur_dark)
		spike.rotation.z = (float(i) - 2.0) * 0.12
	# Four articulated legs with paws and claws.
	for front in [0.34, -0.31]:
		for side in [-1.0, 1.0]:
			var pivot := Node3D.new()
			pivot.position = Vector3(front, 0.52, side * 0.18)
			_visual.add_child(pivot)
			_add_ellipsoid(Vector3(0, -0.02, 0), Vector3(0.115, 0.15, 0.1), fur_dark, pivot)
			_add_capsule(Vector3(0, -0.24, 0), 0.052, 0.42, _body_mat, pivot)
			_add_sphere(Vector3(0, -0.43, 0), 0.055, fur_dark, pivot)
			_add_ellipsoid(Vector3(0.035, -0.445, -0.005), Vector3(0.08, 0.045, 0.075), fur_dark, pivot)
			for toe in range(3):
				var claw: MeshInstance3D = _add_cone(Vector3(0.105, -0.465, -0.04 + float(toe) * 0.04), 0.015, 0.05, claw_mat, pivot)
				claw.rotation.z = -PI * 0.5
			var phase: float = 0.0 if ((front > 0.0 and side < 0.0) or (front < 0.0 and side > 0.0)) else PI
			_register_limb(pivot, phase)
	# Tail as a chain of fur masses on its own pivot.
	var tail := Node3D.new()
	tail.position = Vector3(-0.55, 0.62, 0)
	_visual.add_child(tail)
	for i in range(5):
		var t: float = float(i)
		_add_ellipsoid(Vector3(-0.1 - t * 0.16, 0.02 * t * t, 0.0), Vector3(0.12 - t * 0.016, 0.1 - t * 0.013, 0.08 - t * 0.009), fur_dark if i % 2 == 0 else _body_mat, tail)
	_add_ellipsoid(Vector3(-0.92, 0.12, 0), Vector3(0.055, 0.05, 0.045), fur_light, tail)
	_register_limb(tail, 2.2)
	if elite:
		# Alpha mantle: heavier shoulders and a scarred plate across the brow.
		_add_ellipsoid(Vector3(0.25, 0.73, 0), Vector3(0.28, 0.07, 0.31), fur_dark)
		_add_ellipsoid(Vector3(0.55, 0.81, 0), Vector3(0.12, 0.035, 0.1), _make_mat(Color(0.5, 0.38, 0.24), 0.5, 0.2))

func _build_humanoid(elite: bool) -> void:
	# Humanoid enemies share the same detailed rig as the player and villagers,
	# so bandits, knights and bosses no longer read as stacked capsules.
	var model := CharacterModel.new()
	model.name = "CharacterModel"
	_visual.add_child(model)
	model.build(_humanoid_look(elite))
	if elite:
		model.scale = Vector3.ONE * 1.035
	_humanoid_model = model

func _humanoid_look(elite: bool) -> Dictionary:
	var look: Dictionary = {
		"asset": "viking",
		"skin": CharacterModel.SKIN_TONES[randi_range(1, 3)],
		"hair": Color(0.16, 0.11, 0.08),
		"hair_style": ["short", "wild", "long", "bun"][randi_range(0, 3)],
		"shirt": Color(0.29, 0.23, 0.17),
		"pants": Color(0.17, 0.15, 0.13),
		"boots": Color(0.12, 0.09, 0.07),
		"accent": Color(0.52, 0.4, 0.22),
		"eye": CharacterModel.EYE_TONES[randi_range(0, 3)],
		"held": "sword",
		"frame": "male",
	}
	match monster_id:
		"bandit", "bandit_warlord":
			var warlord: bool = monster_id == "bandit_warlord" or elite
			look["asset"] = "viking" if warlord else "pirate"
			look["shirt"] = Color(0.32, 0.24, 0.17)
			look["pants"] = Color(0.16, 0.14, 0.12)
			look["accent"] = Color(0.58, 0.44, 0.22)
			look["held"] = "axe" if warlord else "sword"
			if warlord:
				look["bulk"] = 1.2
				look["armour"] = true
				look["cape"] = true
				look["cape_color"] = Color(0.25, 0.13, 0.1)
				look["helm"] = "open"
				look["eye"] = Color(0.9, 0.32, 0.14)
		"grave_knight":
			look["asset"] = "armored-knight"
			look["skin"] = Color(0.62, 0.66, 0.68)
			look["hair"] = Color(0.2, 0.22, 0.24)
			look["shirt"] = Color(0.2, 0.23, 0.26)
			look["pants"] = Color(0.12, 0.13, 0.15)
			look["boots"] = Color(0.09, 0.1, 0.11)
			look["accent"] = Color(0.48, 0.52, 0.58)
			look["armour"] = true
			look["helm"] = "knight"
			look["cape"] = true
			look["cape_color"] = Color(0.12, 0.14, 0.18)
			look["held"] = "sword"
			look["eye"] = Color(0.42, 0.78, 1.0)
			look["bulk"] = 1.12
		"drowned_guard":
			look["asset"] = "stylized-zombie"
			look["skin"] = Color(0.55, 0.68, 0.62)
			look["hair"] = Color(0.12, 0.18, 0.15)
			look["shirt"] = Color(0.22, 0.32, 0.3)
			look["pants"] = Color(0.14, 0.2, 0.19)
			look["boots"] = Color(0.1, 0.13, 0.12)
			look["accent"] = Color(0.4, 0.5, 0.45)
			look["armour"] = true
			look["helm"] = "open"
			look["cape"] = true
			look["cape_color"] = Color(0.12, 0.24, 0.22)
			look["held"] = "spear"
			look["eye"] = Color(0.35, 0.9, 0.85)
			look["bulk"] = 1.1
			look["beard"] = "short"
		"rune_stalker":
			look["asset"] = "witch"
			look["skin"] = Color(0.6, 0.58, 0.68)
			look["hair"] = Color(0.1, 0.1, 0.14)
			look["robe"] = true
			look["helm"] = "hood"
			look["shirt"] = Color(0.18, 0.2, 0.38)
			look["pants"] = Color(0.12, 0.12, 0.18)
			look["accent"] = Color(0.35, 0.8, 0.95)
			look["held"] = "staff"
			look["eye"] = Color(0.35, 0.85, 1.0)
			look["frame"] = "female"
		"ember_shaman":
			look["asset"] = "wizard"
			look["skin"] = Color(0.5, 0.38, 0.3)
			look["hair"] = Color(0.25, 0.15, 0.1)
			look["robe"] = true
			look["helm"] = "hood"
			look["shirt"] = Color(0.35, 0.16, 0.12)
			look["pants"] = Color(0.16, 0.1, 0.08)
			look["accent"] = Color(1.0, 0.55, 0.2)
			look["held"] = "orb_staff"
			look["eye"] = Color(1.0, 0.48, 0.12)
			look["beard"] = "long"
			look["beard_color"] = Color(0.28, 0.2, 0.16)
		"fungal_stalker":
			look["asset"] = "orc"
			look["skin"] = Color(0.55, 0.6, 0.4)
			look["hair"] = Color(0.3, 0.36, 0.2)
			look["hair_style"] = "bald"
			look["shirt"] = Color(0.35, 0.4, 0.25)
			look["pants"] = Color(0.24, 0.27, 0.17)
			look["boots"] = Color(0.18, 0.2, 0.13)
			look["accent"] = Color(0.55, 0.65, 0.3)
			look["horns"] = "antlers"
			look["eye"] = Color(0.85, 0.9, 0.35)
			look["bulk"] = 1.08
			look["held"] = "none"
		"bronze_sentinel":
			look["asset"] = "stone-golem"
			look["skin"] = Color(0.48, 0.42, 0.32)
			look["hair_style"] = "bald"
			look["shirt"] = Color(0.3, 0.24, 0.16)
			look["pants"] = Color(0.2, 0.17, 0.13)
			look["boots"] = Color(0.16, 0.13, 0.1)
			look["accent"] = Color(0.78, 0.58, 0.28)
			look["armour"] = true
			look["helm"] = "knight"
			look["cape"] = true
			look["cape_color"] = Color(0.32, 0.22, 0.12)
			look["held"] = "spear"
			look["bulk"] = 1.3
			look["eye"] = Color(1.0, 0.72, 0.25)
			look["frame"] = "male"
		"rootbound_guardian":
			look["asset"] = "troll"
			look["skin"] = Color(0.38, 0.29, 0.19)
			look["hair"] = Color(0.28, 0.4, 0.18)
			look["hair_style"] = "wild"
			look["shirt"] = Color(0.3, 0.24, 0.15)
			look["pants"] = Color(0.2, 0.18, 0.12)
			look["boots"] = Color(0.16, 0.14, 0.1)
			look["accent"] = Color(0.52, 0.62, 0.25)
			look["armour"] = true
			look["helm"] = "crown"
			look["horns"] = "antlers"
			look["cape"] = true
			look["cape_color"] = Color(0.2, 0.3, 0.14)
			look["held"] = "hammer"
			look["eye"] = Color(0.75, 0.92, 0.35)
			look["bulk"] = 1.28
		"ash_imp", "void_mite":
			var void_touched: bool = monster_id == "void_mite"
			look["asset"] = "goblin"
			look["asset_tint"] = Color(0.72, 0.6, 1.0) if void_touched else Color(1.0, 0.68, 0.52)
			look["skin"] = Color(0.4, 0.34, 0.52) if void_touched else Color(0.42, 0.48, 0.3)
			look["hair"] = Color(0.1, 0.08, 0.06)
			look["hair_style"] = "bald"
			look["shirt"] = Color(0.26, 0.18, 0.36) if void_touched else Color(0.32, 0.2, 0.12)
			look["pants"] = Color(0.17, 0.13, 0.24) if void_touched else Color(0.18, 0.13, 0.09)
			look["boots"] = Color(0.1, 0.08, 0.06)
			look["accent"] = Color(0.72, 0.48, 1.0) if void_touched else Color(1.0, 0.5, 0.18)
			look["held"] = "none" if void_touched else "sword"
			look["eye"] = Color(0.75, 0.42, 1.0) if void_touched else Color(1.0, 0.45, 0.12)
			look["horns"] = "demon"
			look["scale"] = 0.7 if void_touched else 0.95
			look["bulk"] = 0.92
			look["frame"] = "male"
		"boss_ash_duke":
			look["asset"] = "troll"
			look["asset_tint"] = Color(0.95, 0.62, 0.46)
			look["skin"] = Color(0.4, 0.3, 0.24)
			look["hair"] = Color(0.16, 0.1, 0.08)
			look["hair_style"] = "wild"
			look["shirt"] = Color(0.28, 0.15, 0.1)
			look["pants"] = Color(0.16, 0.1, 0.08)
			look["boots"] = Color(0.12, 0.08, 0.06)
			look["accent"] = Color(1.0, 0.52, 0.18)
			look["armour"] = true
			look["helm"] = "open"
			look["cape"] = true
			look["cape_color"] = Color(0.3, 0.1, 0.08)
			look["held"] = "axe"
			look["eye"] = Color(1.0, 0.4, 0.12)
			look["horns"] = "demon"
			look["scale"] = 1.05
			look["bulk"] = 1.18
		"void_stalker":
			look["asset"] = "troll"
			look["asset_tint"] = Color(0.68, 0.55, 0.95)
			look["skin"] = Color(0.36, 0.32, 0.46)
			look["hair"] = Color(0.1, 0.08, 0.14)
			look["hair_style"] = "wild"
			look["shirt"] = Color(0.18, 0.14, 0.28)
			look["pants"] = Color(0.12, 0.1, 0.2)
			look["boots"] = Color(0.09, 0.08, 0.14)
			look["accent"] = Color(0.62, 0.4, 0.95)
			look["armour"] = true
			look["helm"] = "hood"
			look["cape"] = true
			look["cape_color"] = Color(0.14, 0.1, 0.26)
			look["held"] = "none"
			look["eye"] = Color(0.72, 0.4, 1.0)
			look["horns"] = "demon"
			look["scale"] = 0.92
			look["bulk"] = 1.05
		"stone_crawler", "iron_golem_shard":
			var iron: bool = monster_id == "iron_golem_shard"
			look["asset"] = "stone-golem"
			look["asset_tint"] = Color(0.74, 0.8, 0.9) if iron else Color(0.82, 0.78, 0.68)
			look["skin"] = Color(0.5, 0.48, 0.42)
			look["hair_style"] = "bald"
			look["shirt"] = Color(0.3, 0.28, 0.24)
			look["pants"] = Color(0.22, 0.21, 0.19)
			look["boots"] = Color(0.18, 0.17, 0.16)
			look["accent"] = Color(0.8, 0.86, 0.94) if iron else Color(0.56, 0.62, 0.4)
			look["held"] = "hammer" if iron else "none"
			look["eye"] = Color(1.0, 0.55, 0.2) if iron else Color(0.95, 0.75, 0.3)
			look["scale"] = 0.85 if iron else 0.7
			look["bulk"] = 1.15 if iron else 1.05
			look["frame"] = "male"
		"astral_scribe":
			look["asset"] = "elf"
			look["skin"] = Color(0.7, 0.68, 0.78)
			look["hair"] = Color(0.86, 0.88, 0.96)
			look["hair_style"] = "long"
			look["robe"] = true
			look["helm"] = "hood"
			look["shirt"] = Color(0.2, 0.24, 0.5)
			look["pants"] = Color(0.14, 0.16, 0.28)
			look["accent"] = Color(0.9, 0.78, 0.38)
			look["held"] = "orb_staff"
			look["eye"] = Color(0.45, 0.85, 1.0)
			look["frame"] = "female"
			look["cape"] = true
			look["cape_color"] = Color(0.16, 0.2, 0.4)
		"boss_depth_captain":
			look["asset"] = "pirate"
			look["skin"] = Color(0.55, 0.66, 0.62)
			look["hair"] = Color(0.15, 0.2, 0.18)
			look["shirt"] = Color(0.18, 0.28, 0.3)
			look["pants"] = Color(0.1, 0.16, 0.18)
			look["accent"] = Color(0.58, 0.72, 0.68)
			look["armour"] = true
			look["helm"] = "open"
			look["cape"] = true
			look["cape_color"] = Color(0.1, 0.22, 0.24)
			look["held"] = "spear"
			look["eye"] = Color(0.35, 0.95, 0.9)
			look["bulk"] = 1.3
			look["beard"] = "short"
		"boss_iron_warden":
			look["asset"] = "armored-knight"
			look["skin"] = Color(0.42, 0.38, 0.34)
			look["hair_style"] = "bald"
			look["shirt"] = Color(0.24, 0.23, 0.24)
			look["pants"] = Color(0.16, 0.15, 0.16)
			look["accent"] = Color(0.6, 0.6, 0.64)
			look["armour"] = true
			look["helm"] = "knight"
			look["cape"] = true
			look["cape_color"] = Color(0.3, 0.1, 0.1)
			look["held"] = "hammer"
			look["eye"] = Color(1.0, 0.28, 0.15)
			look["bulk"] = 1.42
		"boss_shadow_matron":
			look["skin"] = Color(0.56, 0.46, 0.62)
			look["hair"] = Color(0.14, 0.1, 0.18)
			look["hair_style"] = "long"
			look["robe"] = true
			look["helm"] = "hood"
			look["shirt"] = Color(0.2, 0.1, 0.3)
			look["pants"] = Color(0.12, 0.08, 0.16)
			look["accent"] = Color(0.72, 0.42, 0.95)
			look["cape"] = true
			look["cape_color"] = Color(0.12, 0.06, 0.18)
			look["horns"] = "demon"
			look["eye"] = Color(0.85, 0.35, 1.0)
			look["frame"] = "female"
			look["held"] = "staff"
			look["bulk"] = 1.08
		"boss_echo_king", "boss_final_abyss":
			look["skin"] = Color(0.5, 0.46, 0.58) if monster_id == "boss_echo_king" else Color(0.36, 0.28, 0.44)
			look["hair"] = Color(0.82, 0.84, 0.9) if monster_id == "boss_echo_king" else Color(0.08, 0.06, 0.1)
			look["hair_style"] = "long"
			look["shirt"] = Color(0.34, 0.36, 0.44) if monster_id == "boss_echo_king" else Color(0.16, 0.08, 0.24)
			look["pants"] = Color(0.18, 0.18, 0.24) if monster_id == "boss_echo_king" else Color(0.08, 0.05, 0.12)
			look["accent"] = Color(0.78, 0.82, 0.9) if monster_id == "boss_echo_king" else Color(0.85, 0.25, 0.95)
			look["armour"] = true
			look["helm"] = "crown"
			look["horns"] = "antlers" if monster_id == "boss_echo_king" else "demon"
			look["cape"] = true
			look["cape_color"] = Color(0.16, 0.16, 0.22) if monster_id == "boss_echo_king" else Color(0.12, 0.03, 0.18)
			look["held"] = "sword"
			look["eye"] = Color(0.45, 0.9, 1.0) if monster_id == "boss_echo_king" else Color(1.0, 0.3, 0.9)
			look["bulk"] = 1.34 if monster_id == "boss_echo_king" else 1.5
	if elite:
		look["bulk"] = maxf(1.1, float(look.get("bulk", 1.0)))
		if not bool(look.get("robe", false)) and not bool(look.get("dress", false)):
			look["armour"] = true
		look["cape"] = true
	return look

func _build_wisp() -> void:
	_body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_body_mat.albedo_color = Color(body_color.r, body_color.g, body_color.b, 0.38)
	_body_mat.emission_enabled = true
	_body_mat.emission = body_color
	_body_mat.emission_energy_multiplier = 1.5
	_body_mat.roughness = 0.22
	# Layered shroud with a trailing veil.
	_add_ellipsoid(Vector3(0, 0.72, 0), Vector3(0.34, 0.46, 0.34))
	_add_ellipsoid(Vector3(0, 1.06, 0), Vector3(0.22, 0.25, 0.22))
	_add_ellipsoid(Vector3(-0.14, 0.5, 0.05), Vector3(0.14, 0.22, 0.12))
	for i in range(3):
		var trail := _add_ellipsoid(Vector3(-0.18 + float(i) * 0.18, 0.24 - float(i) * 0.02, 0.1), Vector3(0.075, 0.15, 0.06))
		trail.rotation.z = (float(i) - 1.0) * 0.2
	var core := _make_mat(Color(1, 1, 1), 0.1, 0.0)
	core.emission_enabled = true
	core.emission = Color(0.85, 0.93, 1.0)
	core.emission_energy_multiplier = 3.0
	_add_sphere(Vector3(0, 0.8, 0), 0.1, core)
	var halo := _make_mat(body_color.lightened(0.35), 0.2, 0.0)
	halo.emission_enabled = true
	halo.emission = body_color
	halo.emission_energy_multiplier = 1.1
	var ring := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.32
	torus.outer_radius = 0.35
	ring.mesh = torus
	ring.material_override = halo
	ring.position.y = 0.86
	ring.rotation.x = 0.9
	_visual.add_child(ring)
	var light := OmniLight3D.new()
	light.light_color = body_color
	light.light_energy = 2.0
	light.omni_range = 4.0
	light.position = Vector3(0, 0.8, 0)
	_visual.add_child(light)

func _build_crawler(iron: bool) -> void:
	if iron:
		_body_mat.metallic = 0.75
		_body_mat.roughness = 0.35
	var shell := _make_mat(body_color.darkened(0.15), 0.4 if iron else 0.58, 0.75 if iron else 0.12)
	var dark := _make_mat(body_color.darkened(0.45), 0.65, 0.18)
	var under := _make_mat(body_color.darkened(0.32), 0.82, 0.0)
	# Abdomen, thorax and wedge-shaped head.
	_add_ellipsoid(Vector3(-0.14, 0.36, 0.0), Vector3(0.44, 0.26, 0.48), _body_mat)
	_add_ellipsoid(Vector3(0.28, 0.36, 0.0), Vector3(0.27, 0.22, 0.3), shell)
	_add_ellipsoid(Vector3(0.54, 0.36, 0.0), Vector3(0.18, 0.15, 0.19), shell)
	_add_ellipsoid(Vector3(0.64, 0.31, 0.0), Vector3(0.13, 0.09, 0.13), dark)
	# Segmented dorsal carapace.
	for i in range(4):
		var plate := _add_ellipsoid(Vector3(-0.3 + float(i) * 0.18, 0.55 - float(i) * 0.01, 0.0), Vector3(0.19, 0.065, 0.34 - float(i) * 0.045), shell)
		plate.rotation.z = (float(i) - 1.5) * 0.05
	# Mandibles and feelers.
	for side in [-1.0, 1.0]:
		_add_rod(Vector3(0.66, 0.3, side * 0.06), Vector3(0.86, 0.24, side * 0.12), 0.02, dark)
		_add_cone(Vector3(0.9, 0.23, side * 0.13), 0.028, 0.1, dark).rotation.z = -PI * 0.5
		_add_rod(Vector3(0.58, 0.47, side * 0.04), Vector3(0.8, 0.64, side * 0.1), 0.012, dark)
	# Six articulated legs with upper/lower segments and a clawed foot.
	for i in range(6):
		var a: float = float(i) * TAU / 6.0
		var dir := Vector3(cos(a), 0.0, sin(a))
		var pivot := Node3D.new()
		pivot.position = Vector3(dir.x * 0.3, 0.36, dir.z * 0.36)
		_visual.add_child(pivot)
		_add_rod(Vector3.ZERO, Vector3(dir.x * 0.18, -0.1, dir.z * 0.18), 0.045, under, pivot)
		_add_rod(Vector3(dir.x * 0.18, -0.1, dir.z * 0.18), Vector3(dir.x * 0.3, -0.3, dir.z * 0.3), 0.03, under, pivot)
		var foot := _add_ellipsoid(Vector3(dir.x * 0.31, -0.32, dir.z * 0.31), Vector3(0.07, 0.03, 0.06), dark, pivot)
		foot.rotation.y = a
		_register_limb(pivot, float(i) * PI / 3.0)

func _build_slime(big: bool) -> void:
	_body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_body_mat.albedo_color = Color(body_color.r, body_color.g, body_color.b, 0.62)
	_body_mat.emission_enabled = true
	_body_mat.emission = body_color
	_body_mat.emission_energy_multiplier = 0.65
	_body_mat.roughness = 0.1
	_body_mat.metallic_specular = 0.7
	var r: float = 0.9 if big else 0.45
	var body_y: float = r * 0.84
	# Irregular gelatinous mass with secondary lobes and a drip.
	_add_ellipsoid(Vector3(0, body_y, 0), Vector3(r * 1.05, r * 0.82, r * 1.0))
	_add_ellipsoid(Vector3(r * 0.34, body_y * 0.55, r * 0.08), Vector3(r * 0.48, r * 0.4, r * 0.5))
	_add_ellipsoid(Vector3(-r * 0.42, body_y * 0.4, -r * 0.1), Vector3(r * 0.32, r * 0.3, r * 0.35))
	_add_ellipsoid(Vector3(r * 0.12, body_y * 1.15, -r * 0.18), Vector3(r * 0.32, r * 0.26, r * 0.3))
	_add_ellipsoid(Vector3(-r * 0.55, r * 0.15, r * 0.1), Vector3(r * 0.12, r * 0.12, r * 0.12))
	# Suspended luminous core.
	var core := _make_mat(body_color.lightened(0.45), 0.08, 0.0)
	core.emission_enabled = true
	core.emission = body_color.lightened(0.55)
	core.emission_energy_multiplier = 1.4
	_add_ellipsoid(Vector3(0, body_y * 0.9, r * 0.16), Vector3(r * 0.3, r * 0.26, r * 0.24), core)
	var bubble := _make_mat(body_color.lightened(0.55), 0.05, 0.0)
	bubble.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bubble.albedo_color = Color(body_color.r, body_color.g, body_color.b, 0.45)
	bubble.emission_enabled = true
	bubble.emission = body_color.lightened(0.4)
	bubble.emission_energy_multiplier = 0.5
	for i in range(6):
		var ang: float = TAU * float(i) / 6.0
		_add_sphere(Vector3(cos(ang) * r * 0.52, body_y + sin(ang * 2.0) * r * 0.3, sin(ang) * r * 0.4 + r * 0.1), r * 0.075, bubble)
	var gloss := _make_mat(Color(1, 1, 1), 0.05, 0.0)
	gloss.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	gloss.albedo_color = Color(1, 1, 1, 0.3)
	gloss.emission_enabled = true
	gloss.emission = Color(1, 1, 1)
	gloss.emission_energy_multiplier = 0.25
	_add_ellipsoid(Vector3(-r * 0.24, body_y + r * 0.56, r * 0.62), Vector3(r * 0.16, r * 0.06, r * 0.08), gloss)

func _build_serpent() -> void:
	var belly := _make_mat(body_color.lightened(0.25), 0.55, 0.0)
	var dark := _make_mat(body_color.darkened(0.4), 0.6, 0.1)
	var fin_mat := _make_mat(body_color.lightened(0.3), 0.4, 0.0)
	fin_mat.emission_enabled = true
	fin_mat.emission = body_color.lightened(0.25)
	fin_mat.emission_energy_multiplier = 0.5
	var tooth := _make_mat(Color(0.93, 0.9, 0.82), 0.4, 0.0)
	# Undulating segmented body with belly scutes.
	for i in range(8):
		var t: float = float(i) / 7.0
		var radius: float = lerpf(0.23, 0.055, t)
		var seg := Vector3(0.5 - t * 1.55, 0.3 + sin(t * PI) * 0.05 - t * 0.02, sin(t * PI * 1.4) * 0.14)
		_add_ellipsoid(seg, Vector3(radius, radius * 0.92, radius * 1.06))
		if i < 6:
			_add_ellipsoid(seg + Vector3(0, -radius * 0.55, 0), Vector3(radius * 0.8, 0.026, radius * 0.68), belly)
	# Head, brow ridges and jaw.
	_add_ellipsoid(Vector3(0.65, 0.44, 0.0), Vector3(0.25, 0.2, 0.22))
	_add_ellipsoid(Vector3(0.88, 0.4, 0.0), Vector3(0.17, 0.1, 0.13), _body_mat)
	_add_ellipsoid(Vector3(0.84, 0.31, 0.0), Vector3(0.15, 0.05, 0.1), dark)
	for side in [-1.0, 1.0]:
		_add_ellipsoid(Vector3(0.7, 0.55, side * 0.1), Vector3(0.1, 0.035, 0.05), dark)
		for i in range(3):
			_add_cone(Vector3(0.84 + float(i) * 0.045, 0.34, side * 0.06), 0.012, 0.05, tooth).rotation.x = PI
	# Dorsal spines.
	for i in range(5):
		var x: float = 0.35 - float(i) * 0.26
		var spine := _add_cone(Vector3(x, 0.55 - float(i) * 0.03, sin(float(i) * 0.7) * 0.1), 0.045, 0.17 - float(i) * 0.015, fin_mat)
		spine.rotation.x = -0.35

func _build_rat() -> void:
	var dark := _make_mat(body_color.darkened(0.42), 0.7, 0.0)
	var fur_hi := _make_mat(body_color.lightened(0.12), 0.85, 0.0)
	var pink := _make_mat(Color(0.82, 0.55, 0.52), 0.55, 0.0)
	var whisker := _make_mat(Color(0.85, 0.82, 0.76), 0.6, 0.0)
	# Body, neck, head and tapered snout.
	_add_ellipsoid(Vector3(0, 0.27, 0.0), Vector3(0.26, 0.18, 0.34))
	_add_ellipsoid(Vector3(0.2, 0.31, 0.0), Vector3(0.17, 0.155, 0.19), fur_hi)
	_add_ellipsoid(Vector3(0.34, 0.34, 0.0), Vector3(0.16, 0.135, 0.16))
	_add_ellipsoid(Vector3(0.46, 0.3, 0.0), Vector3(0.14, 0.08, 0.095), fur_hi)
	_add_sphere(Vector3(0.57, 0.3, 0.0), 0.028, pink)
	# Large ears with inner cups.
	for side in [-1.0, 1.0]:
		var ear := _add_ellipsoid(Vector3(0.29, 0.5, side * 0.13), Vector3(0.075, 0.11, 0.025), dark)
		ear.rotation.z = -0.25
		ear.rotation.x = side * 0.18
		var inner := _add_ellipsoid(Vector3(0.29, 0.5, side * 0.145), Vector3(0.045, 0.075, 0.012), pink)
		inner.rotation.z = -0.25
	# Whiskers.
	for side in [-1.0, 1.0]:
		for i in range(3):
			_add_rod(Vector3(0.52, 0.3 + float(i - 1) * 0.015, side * 0.05), Vector3(0.72, 0.32 + float(i - 1) * 0.055, side * 0.18), 0.004, whisker)
	# Four legs.
	for x in [0.18, -0.16]:
		for z in [-0.17, 0.17]:
			var pivot := Node3D.new()
			pivot.position = Vector3(x, 0.24, z)
			_visual.add_child(pivot)
			_add_rod(Vector3.ZERO, Vector3(z * 0.1, -0.12, z * 0.03), 0.04, dark, pivot)
			_add_rod(Vector3(z * 0.1, -0.12, z * 0.03), Vector3(z * 0.04, -0.22, z * 0.07), 0.03, dark, pivot)
			_add_ellipsoid(Vector3(z * 0.04, -0.23, z * 0.08), Vector3(0.05, 0.025, 0.07), pink, pivot)
			_register_limb(pivot, 0.0 if (x > 0.0) == (z > 0.0) else PI)
	# Long segmented tail.
	var tail := Node3D.new()
	tail.position = Vector3(-0.28, 0.27, 0.0)
	_visual.add_child(tail)
	var prev := Vector3.ZERO
	for i in range(4):
		var next := Vector3(-0.16 - float(i) * 0.03, -0.03 + float(i) * 0.015, sin(float(i) * 1.4) * 0.09)
		_add_rod(prev, next, 0.035 - float(i) * 0.006, pink if i == 3 else dark, tail)
		prev = next
	_register_limb(tail, 2.6)

func _build_bone(elite: bool) -> void:
	var bone := _make_mat(Color(0.9, 0.88, 0.8), 0.45, 0.04)
	var bone_dark := _make_mat(Color(0.7, 0.68, 0.6), 0.6, 0.03)
	_body_mat = bone
	# Pelvis and spine.
	_add_ellipsoid(Vector3(0, 0.55, 0.0), Vector3(0.2, 0.11, 0.13), bone)
	_add_rod(Vector3(0, 0.55, 0.02), Vector3(0, 1.16, 0.05), 0.042, bone)
	for i in range(5):
		_add_sphere(Vector3(0, 0.62 + float(i) * 0.1, 0.03), 0.058, bone_dark)
	# Rib cage.
	for i in range(5):
		var y: float = 1.02 - float(i) * 0.07
		for side in [-1.0, 1.0]:
			_add_rod(Vector3(0, y, 0.04), Vector3(side * 0.22, y - 0.03, 0.07), 0.026, bone)
			_add_rod(Vector3(side * 0.22, y - 0.03, 0.07), Vector3(side * 0.15, y - 0.14, 0.16), 0.022, bone)
	_add_rod(Vector3(0, 0.88, 0.17), Vector3(0, 1.02, 0.15), 0.025, bone_dark)
	# Skull with brow ridge, jaw, teeth and dark sockets.
	_add_ellipsoid(Vector3(0, 1.27, 0.06), Vector3(0.17, 0.18, 0.2), bone)
	_add_ellipsoid(Vector3(0, 1.19, 0.15), Vector3(0.14, 0.065, 0.12), bone)
	_add_ellipsoid(Vector3(0, 1.36, 0.06), Vector3(0.15, 0.05, 0.16), bone_dark)
	var socket := _make_mat(Color(0.03, 0.03, 0.03), 0.9, 0.0)
	for side in [-1.0, 1.0]:
		_add_sphere(Vector3(side * 0.075, 1.29, 0.19), 0.048, socket)
		for i in range(3):
			_add_cone(Vector3(side * (0.04 + float(i) * 0.035), 1.13, 0.2), 0.012, 0.055, bone).rotation.x = PI
	# Shoulder blades, arms, legs.
	for side in [-1.0, 1.0]:
		_add_ellipsoid(Vector3(side * 0.19, 1.02, 0.02), Vector3(0.1, 0.12, 0.03), bone_dark)
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.27, 1.0, 0.04)
		_visual.add_child(arm)
		_add_rod(Vector3.ZERO, Vector3(side * 0.06, -0.24, 0.05), 0.035, bone, arm)
		_add_rod(Vector3(side * 0.06, -0.24, 0.05), Vector3(side * 0.08, -0.46, 0.14), 0.028, bone, arm)
		_add_sphere(Vector3(side * 0.08, -0.48, 0.15), 0.05, bone, arm)
		for i in range(3):
			_add_cone(Vector3(side * (0.04 + float(i) * 0.03), -0.54, 0.18 + float(i) * 0.02), 0.012, 0.08, bone_dark, arm).rotation.z = -side * 0.3
		_register_limb(arm, PI if side < 0.0 else 0.0)
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.12, 0.54, 0.02)
		_visual.add_child(leg)
		_add_rod(Vector3.ZERO, Vector3(side * 0.04, -0.22, 0.04), 0.045, bone, leg)
		_add_rod(Vector3(side * 0.04, -0.22, 0.04), Vector3(side * 0.02, -0.46, 0.12), 0.034, bone, leg)
		_add_rod(Vector3(side * 0.02, -0.46, 0.12), Vector3(side * 0.02, -0.5, 0.26), 0.026, bone_dark, leg)
		_register_limb(leg, PI if side > 0.0 else 0.0)
	if elite:
		_add_box(Vector3(0, 1.5, 0.06), Vector3(0.32, 0.1, 0.32), bone_dark)
		_body_mat.emission_enabled = true
		_body_mat.emission = Color(0.6, 0.9, 0.5)
		_body_mat.emission_energy_multiplier = 0.4

func _build_bat() -> void:
	if monster_id == "spore_moth":
		_build_moth()
		return
	var dark := _make_mat(body_color.darkened(0.42), 0.6, 0.0)
	var fur := _make_mat(body_color.darkened(0.1), 0.86, 0.0)
	var wing_col := body_color.darkened(0.2)
	var membrane := _make_mat(Color(wing_col.r, wing_col.g, wing_col.b, 0.88), 0.5, 0.0)
	membrane.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	membrane.cull_mode = BaseMaterial3D.CULL_DISABLED
	var tooth := _make_mat(Color(0.95, 0.92, 0.85), 0.35, 0.0)
	# Torso, chest tuft and head.
	_add_ellipsoid(Vector3(0, 0.64, 0.0), Vector3(0.2, 0.24, 0.18), fur)
	_add_ellipsoid(Vector3(0, 0.6, 0.1), Vector3(0.13, 0.16, 0.1), _make_mat(body_color.lightened(0.15), 0.9, 0.0))
	_add_ellipsoid(Vector3(0, 0.83, 0.1), Vector3(0.14, 0.12, 0.13), fur)
	_add_ellipsoid(Vector3(0, 0.78, 0.23), Vector3(0.08, 0.06, 0.08), dark)
	# Ears with inner cups and fangs.
	for side in [-1.0, 1.0]:
		var ear := _add_ellipsoid(Vector3(side * 0.09, 0.96, 0.07), Vector3(0.06, 0.11, 0.025), fur)
		ear.rotation.z = side * 0.28
		ear.rotation.x = -0.2
		var cup := _add_ellipsoid(Vector3(side * 0.09, 0.96, 0.085), Vector3(0.035, 0.075, 0.012), dark)
		cup.rotation.z = side * 0.28
		cup.rotation.x = -0.2
		_add_cone(Vector3(side * 0.04, 0.73, 0.25), 0.012, 0.06, tooth).rotation.x = PI
	# Broad membrane wings with arm ribs.
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.16, 0.74, 0.02)
		_visual.add_child(pivot)
		var wing_root := Node3D.new()
		wing_root.scale.x = side
		pivot.add_child(wing_root)
		_add_mesh(_wing_mesh(0.74, 0.42, 0.1), Vector3.ZERO, membrane, Vector3.ONE, wing_root)
		_add_rod(Vector3.ZERO, Vector3(0.31, -0.035, -0.035), 0.018, dark, wing_root)
		_add_rod(Vector3(0.31, -0.035, -0.035), Vector3(0.74, -0.1, -0.05), 0.014, dark, wing_root)
		_add_rod(Vector3(0.31, -0.035, -0.035), Vector3(0.49, -0.075, -0.26), 0.011, dark, wing_root)
		_add_sphere(Vector3(0.74, -0.1, -0.05), 0.025, dark, wing_root)
		_register_limb(pivot, 0.0)
	# Tiny clawed feet and a tail.
	for side in [-1.0, 1.0]:
		_add_rod(Vector3(side * 0.1, 0.45, 0.0), Vector3(side * 0.12, 0.12, 0.04), 0.028, dark)
		for i in range(3):
			_add_cone(Vector3(side * (0.09 + float(i) * 0.03), 0.07, 0.08), 0.012, 0.07, dark)
	_add_rod(Vector3(0, 0.6, -0.17), Vector3(0.04, 0.5, -0.4), 0.02, dark)

func _build_moth() -> void:
	var fur := _make_mat(body_color.lightened(0.15), 0.95, 0.0)
	var fuzz := _make_mat(body_color.lightened(0.35), 0.95, 0.0)
	var dark := _make_mat(body_color.darkened(0.45), 0.8, 0.0)
	# Plump fuzzy thorax and banded abdomen.
	_add_ellipsoid(Vector3(0, 0.68, 0.02), Vector3(0.2, 0.22, 0.24), fur)
	for i in range(3):
		_add_ellipsoid(Vector3(0, 0.6 - float(i) * 0.06, -0.18 - float(i) * 0.11), Vector3(0.15 - float(i) * 0.03, 0.12 - float(i) * 0.02, 0.12), fuzz if i % 2 == 0 else fur)
	_add_ellipsoid(Vector3(0, 0.85, 0.12), Vector3(0.13, 0.12, 0.12), fur)
	for side in [-1.0, 1.0]:
		_add_rod(Vector3(side * 0.05, 0.93, 0.16), Vector3(side * 0.14, 1.06, 0.25), 0.01, dark)
		_add_sphere(Vector3(side * 0.14, 1.07, 0.26), 0.028, fuzz)
		for i in range(3):
			var leg := Vector3(side * (0.08 + float(i) * 0.06), 0.55 - float(i) * 0.02, 0.05 + float(i) * 0.06)
			_add_rod(leg, leg + Vector3(side * 0.06, -0.32, 0.02), 0.018, dark)
	# Fluffy collar.
	for i in range(5):
		var ang: float = PI * (0.2 + 0.15 * float(i))
		_add_sphere(Vector3(cos(ang) * 0.19, 0.82 + sin(ang) * 0.03, 0.02), 0.06, fuzz)

func _build_imp(elite: bool) -> void:
	var skin := _make_mat(body_color.darkened(0.08), 0.62, 0.05)
	var dark := _make_mat(Color(0.13, 0.09, 0.09), 0.55, 0.12)
	var horn_mat := _make_mat(Color(0.2, 0.16, 0.14), 0.42, 0.2)
	var membrane := _make_mat(Color(body_color.r * 0.5, body_color.g * 0.35, body_color.b * 0.4, 0.85), 0.6, 0.0)
	membrane.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	membrane.cull_mode = BaseMaterial3D.CULL_DISABLED
	# Torso, chest and shoulders.
	_add_ellipsoid(Vector3(0, 0.58, 0.0), Vector3(0.17, 0.16, 0.15), skin)
	_add_ellipsoid(Vector3(0, 0.78, 0.0), Vector3(0.22, 0.24, 0.16), skin)
	_add_ellipsoid(Vector3(0, 0.84, 0.02), Vector3(0.19, 0.14, 0.14), skin)
	for side in [-1.0, 1.0]:
		_add_sphere(Vector3(side * 0.2, 0.9, 0.02), 0.09, skin)
	# Head, muzzle and pointed ears.
	_add_sphere(Vector3(0, 1.04, 0.02), 0.17, skin)
	_add_ellipsoid(Vector3(0, 1.0, 0.15), Vector3(0.1, 0.07, 0.08), skin)
	_add_ellipsoid(Vector3(0, 0.96, 0.16), Vector3(0.08, 0.035, 0.06), dark)
	for side in [-1.0, 1.0]:
		var ear := _add_cone(Vector3(side * 0.17, 1.16, 0.0), 0.055, 0.22, skin)
		ear.rotation.z = side * 0.55
		# Curved horns in two segments.
		_add_rod(Vector3(side * 0.1, 1.15, 0.02), Vector3(side * 0.16, 1.33, -0.03), 0.032, horn_mat)
		_add_rod(Vector3(side * 0.16, 1.33, -0.03), Vector3(side * 0.23, 1.41, -0.1), 0.022, horn_mat)
	# Arms with claws.
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.22, 0.88, 0.02)
		_visual.add_child(arm)
		_add_rod(Vector3.ZERO, Vector3(side * 0.08, -0.22, 0.04), 0.05, skin, arm)
		_add_rod(Vector3(side * 0.08, -0.22, 0.04), Vector3(side * 0.1, -0.42, 0.12), 0.04, skin, arm)
		_add_sphere(Vector3(side * 0.1, -0.44, 0.13), 0.06, skin, arm)
		for i in range(3):
			_add_cone(Vector3(side * (0.06 + float(i) * 0.03), -0.5, 0.15 + float(i) * 0.02), 0.014, 0.09, dark, arm).rotation.z = -side * 0.25
		_register_limb(arm, PI if side < 0.0 else 0.0)
	# Hooved legs.
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.13, 0.5, 0.0)
		_visual.add_child(leg)
		_add_rod(Vector3.ZERO, Vector3(side * 0.03, -0.22, 0.02), 0.06, skin, leg)
		_add_rod(Vector3(side * 0.03, -0.22, 0.02), Vector3(side * 0.02, -0.42, 0.06), 0.045, skin, leg)
		_add_box(Vector3(side * 0.02, -0.47, 0.1), Vector3(0.1, 0.08, 0.16), dark, leg)
		_register_limb(leg, 0.0 if side > 0.0 else PI)
	# Small bat wings and a spade-tipped tail.
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.14, 0.9, -0.06)
		_visual.add_child(pivot)
		var wing_root := Node3D.new()
		wing_root.scale.x = side
		pivot.add_child(wing_root)
		_add_mesh(_wing_mesh(0.46, 0.28, 0.04), Vector3.ZERO, membrane, Vector3.ONE, wing_root)
		_add_rod(Vector3.ZERO, Vector3(0.2, -0.01, -0.02), 0.014, horn_mat, wing_root)
		_add_rod(Vector3(0.2, -0.01, -0.02), Vector3(0.46, -0.04, -0.03), 0.01, horn_mat, wing_root)
	var tail := Node3D.new()
	tail.position = Vector3(0, 0.55, -0.14)
	_visual.add_child(tail)
	_add_rod(Vector3.ZERO, Vector3(0, -0.1, -0.28), 0.032, skin, tail)
	_add_rod(Vector3(0, -0.1, -0.28), Vector3(0, -0.02, -0.5), 0.024, skin, tail)
	var spade := _add_cone(Vector3(0, -0.02, -0.58), 0.07, 0.14, dark, tail)
	spade.rotation.x = PI
	_register_limb(tail, 2.4)
	if elite:
		skin.emission_enabled = true
		skin.emission = Color(1.0, 0.4, 0.1)
		skin.emission_energy_multiplier = 0.8
		var fl := OmniLight3D.new()
		fl.light_color = Color(1.0, 0.45, 0.15)
		fl.light_energy = 1.5
		fl.omni_range = 4.0
		fl.position = Vector3(0, 1.0, 0)
		_visual.add_child(fl)

func _build_void(elite: bool) -> void:
	_body_mat.emission_enabled = true
	_body_mat.emission = body_color
	_body_mat.emission_energy_multiplier = 0.9
	_body_mat.roughness = 0.18
	var shell := _make_mat(Color(0.07, 0.035, 0.12), 0.35, 0.25)
	shell.emission_enabled = true
	shell.emission = body_color.darkened(0.25)
	shell.emission_energy_multiplier = 0.5
	# Unstable void mass with a dark lower shell and drifting tendrils.
	_add_ellipsoid(Vector3(0, 0.6, 0.0), Vector3(0.4, 0.44, 0.36))
	_add_ellipsoid(Vector3(0, 0.3, 0.0), Vector3(0.24, 0.2, 0.22), shell)
	var core := _make_mat(Color(0.92, 0.84, 1.0), 0.1, 0.0)
	core.emission_enabled = true
	core.emission = Color(0.78, 0.55, 1.0)
	core.emission_energy_multiplier = 2.2
	_add_sphere(Vector3(0, 0.62, 0.2), 0.11, core)
	for i in range(4):
		var a: float = TAU * float(i) / 4.0 + 0.4
		_add_rod(Vector3(cos(a) * 0.12, 0.3, sin(a) * 0.1), Vector3(cos(a) * 0.24, 0.03, sin(a) * 0.2), 0.03, shell)
	if elite and not is_boss:
		_add_boss_aura()

func _build_matron() -> void:
	_build_humanoid(true)
	if _humanoid_model:
		_humanoid_model.scale = Vector3.ONE * 1.14

func _build_abyss_lord() -> void:
	_build_humanoid(true)
	if _humanoid_model:
		_humanoid_model.scale = Vector3.ONE * 1.24

func _build_generic() -> void:
	var dark := _make_mat(body_color.darkened(0.4), 0.7, 0.05)
	_add_ellipsoid(Vector3(0, 0.55, 0.0), Vector3(0.28, 0.34, 0.24))
	_add_ellipsoid(Vector3(0, 0.95, 0.06), Vector3(0.22, 0.2, 0.2))
	_add_ellipsoid(Vector3(0, 0.9, 0.22), Vector3(0.12, 0.1, 0.1), dark)
	for side in [-1.0, 1.0]:
		_add_ellipsoid(Vector3(side * 0.12, 1.12, 0.02), Vector3(0.06, 0.1, 0.03), dark)
		_add_rod(Vector3(side * 0.14, 0.4, 0.0), Vector3(side * 0.16, 0.05, 0.04), 0.05, dark)
	_add_rod(Vector3(0, 0.5, -0.2), Vector3(0, 0.35, -0.48), 0.05, dark)

func _add_quad_body(w: float, h: float, d: float) -> void:
	_add_box(Vector3(0, h * 0.5, 0), Vector3(w, h, d))

func _add_capsule_body(r: float, h: float) -> void:
	_add_capsule(Vector3(0, h * 0.5, 0), r, h)

func _physics_process(delta: float) -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		return
	if state == State.DEAD:
		return
	_t += delta
	_process_elemental_status(delta)
	_raid_exposed_timer = maxf(_raid_exposed_timer - delta, 0.0)
	_elemental_stagger_timer = maxf(_elemental_stagger_timer - delta, 0.0)
	if _visual:
		var moving_now: float = clampf(Vector2(velocity.x, velocity.z).length() / maxf(move_speed, 0.1), 0.0, 1.0)
		if _humanoid_model and is_instance_valid(_humanoid_model):
			_humanoid_model.set_motion(moving_now * 1.15)
			if state == State.WINDUP:
				if not _humanoid_attack_fired:
					_humanoid_model.attack_duration = maxf(0.34, _windup + 0.14)
					_humanoid_model.play_attack(1.0, false)
					_humanoid_attack_fired = true
			else:
				_humanoid_attack_fired = false
		var idle_breath: float = sin(_t * 2.0) * 0.018
		var gait_rate: float = 9.0
		if monster_id in ["grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx", "cinder_hound"]: gait_rate = 12.5
		elif monster_id in ["tide_serpent", "boss_depth_serpent", "void_jelly"]: gait_rate = 5.5
		elif monster_id in ["stone_crawler", "iron_golem_shard", "bronze_sentinel", "boss_iron_warden"]: gait_rate = 6.0
		if _creature_asset != null:
			_visual.position.y = idle_breath * 0.6
			_creature_asset.tick(delta, moving_now, gait_rate)
		else:
			_visual.position.y = sin(_t * (2.2 if is_boss else 3.0)) * (0.045 if is_boss else 0.025) + idle_breath
		var combat_locomotion: bool = state in [State.CHASE, State.INVESTIGATE, State.RETREAT, State.HUNT_PREY]
		var target_pose: float = -0.28 if state == State.WINDUP else (0.12 if combat_locomotion and moving_now > 0.35 else 0.0)
		_attack_pose = lerpf(_attack_pose, target_pose, clampf(delta * (10.0 if state == State.WINDUP else 5.0), 0.0, 1.0))
		_visual.rotation.x = _attack_pose
		for limb_data in _animated_limbs:
			var limb := limb_data["node"] as Node3D
			if limb == null or not is_instance_valid(limb):
				continue
			var phase: float = float(limb_data["phase"])
			var swing: float = sin(_t * gait_rate + phase) * 0.48 * moving_now
			var windup_swing: float = (0.72 if phase < PI else -0.72) if state == State.WINDUP else 0.0
			var idle_motion: float = sin(_t * 1.8 + phase) * 0.025 * (1.0 - moving_now)
			var base: Vector3 = limb_data["base"]
			limb.rotation = base + Vector3(swing + windup_swing + idle_motion, 0.0, 0.0)
		var ring: Node3D = _visual.get_node_or_null("BossRing") as Node3D
		if ring:
			ring.rotation.y += delta * 1.5

	_attack_cd = maxf(_attack_cd - delta, 0.0)
	_raid_special_cooldown = maxf(_raid_special_cooldown - delta, 0.0)
	if is_boss and health and health.max_health > 0.0:
		var hp_ratio: float = health.current_health / health.max_health
		var raid_boss: bool = bool(get_meta("raid_boss", false))
		var next_phase: int = 0
		if raid_boss:
			next_phase = 3 if hp_ratio <= 0.25 else (2 if hp_ratio <= 0.50 else (1 if hp_ratio <= 0.75 else 0))
		else:
			next_phase = 2 if hp_ratio <= 0.25 else (1 if hp_ratio <= 0.60 else 0)
		if next_phase > _boss_phase:
			_boss_phase = next_phase
			if raid_boss:
				damage *= 1.12 if next_phase == 1 else (1.16 if next_phase == 2 else 1.22)
				move_speed *= 1.07 if next_phase < 3 else 1.12
				attack_range += 0.45 if next_phase < 3 else 0.7
				if _boss_phase == 1:
					EventBus.toast.emit("%s enters Phase II — new raid attacks awaken!" % display_name, "warning")
				elif _boss_phase == 2:
					EventBus.toast.emit("%s enters Phase III — the sanctum begins to break!" % display_name, "warning")
				else:
					EventBus.toast.emit("%s enters its final phase! Survive the onslaught!" % display_name, "warning")
			else:
				damage *= 1.22 if next_phase == 1 else 1.28
				move_speed *= 1.18
				attack_range += 0.45
				if _boss_phase == 1:
					EventBus.toast.emit("%s enrages — its attacks now carry a shockwave!" % display_name, "warning")
				else:
					EventBus.toast.emit("%s enters its final phase! Keep moving!" % display_name, "warning")
			if _body_mat:
				_body_mat.emission_energy_multiplier = 1.0 + 0.25 * float(_boss_phase)
			if raid_boss and next_phase >= 2:
				_summon_raid_reinforcements(next_phase)

	var player: Node3D = GameManager.player
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		var nearest_distance: float = INF
		for player_variant in get_tree().get_nodes_in_group("player"):
			var candidate := player_variant as Node3D
			if not is_instance_valid(candidate):
				continue
			var candidate_distance: float = global_position.distance_to(candidate.global_position)
			if candidate_distance < nearest_distance and candidate_distance <= leash_range * 1.5:
				nearest_distance = candidate_distance
				player = candidate
	# Monsters can threaten isolated travellers and NPCs, but settlement
	# defenders should not be dragged out of their protected home radius.
	var nearest_npc: Node3D = null
	var nearest_npc_distance := aggro_range * 1.35
	for npc_variant in get_tree().get_nodes_in_group("npc"):
		var npc := npc_variant as Node3D
		if not is_instance_valid(npc) or bool(npc.get_meta("is_child", false)):
			continue
		var npc_health: Variant = npc.get("health")
		if npc_health != null and bool(npc_health.get("is_dead")):
			continue
		if _near_settlement_protection(npc.global_position):
			continue
		var npc_distance := global_position.distance_to(npc.global_position)
		if npc_distance < nearest_npc_distance:
			nearest_npc_distance = npc_distance
			nearest_npc = npc
	if nearest_npc != null and (player == null or not is_instance_valid(player) or global_position.distance_to(player.global_position) > nearest_npc_distance):
		player = nearest_npc
	var player_alive: bool = false
	if player != null and is_instance_valid(player):
		var ph: Variant = player.get("health")
		if ph == null:
			player_alive = true
		elif not bool(ph.get("is_dead")):
			player_alive = true
	# A negotiated faction ceasefire is respected by its local defenders as well
	# as by the offline territory simulation. Rival factions remain hostile.
	if player_alive and has_meta("dungeon_faction_id"):
		var campaign: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
		if campaign and campaign.has_method("faction_status"):
			var diplomacy: Dictionary = campaign.faction_status(str(get_meta("dungeon_faction_id", "")))
			if int(diplomacy.get("player_truce_until", 0)) > int(Time.get_unix_time_from_system()):
				player_alive = false
	# Autonomous dungeon warfare: rival civilizations and rescued allies select
	# nearby hostile units independently of the player.
	if _process_faction_warfare(delta):
		return
	var to_player: Vector3 = Vector3.ZERO
	var dist: float = 999.0
	if player_alive:
		to_player = player.global_position - global_position
		to_player.y = 0.0
		dist = to_player.length()
	# Leash
	if home.distance_to(global_position) > leash_range and state != State.WINDUP:
		state = State.IDLE
		var home_dir: Vector3 = home - global_position
		home_dir.y = 0.0
		velocity.x = home_dir.normalized().x * _effective_move_speed() * 0.8
		velocity.z = home_dir.normalized().z * _effective_move_speed() * 0.8
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
		move_and_slide()
		return
	match state:
		State.IDLE:
			# Free living: rest, roam within territory, occasional home drift
			_rest_timer = maxf(_rest_timer - delta, 0.0)
			if _rest_timer > 0.0:
				velocity.x = 0.0
				velocity.z = 0.0
			else:
				_roam_timer -= delta
				if _roam_timer <= 0.0:
					var patrol_route: Array = get_meta("faction_patrol_route", [])
					if patrol_route.size() > 1:
						_roam_timer = 1.4
						if global_position.distance_to(_roam_target) < 1.8 or _roam_target == Vector3.ZERO:
							_roam_target = patrol_route[_faction_patrol_index % patrol_route.size()]
							_faction_patrol_index += 1
					else:
						_roam_timer = randf_range(3.0, 8.0)
						if randf() < 0.25:
							_rest_timer = randf_range(2.0, 5.0)
						else:
							var ang: float = randf() * TAU
							var rad: float = randf_range(4.0, minf(leash_range * 0.55, 18.0))
							_roam_target = home + Vector3(cos(ang) * rad, 0, sin(ang) * rad)
							# Slow territory drift so packs shift over time
							if randf() < 0.08 and not is_boss:
								home = home.lerp(_roam_target, 0.15)
				var to_roam: Vector3 = _roam_target - global_position
				to_roam.y = 0.0
				if to_roam.length() > 1.2:
					var rd: Vector3 = to_roam.normalized()
					velocity.x = rd.x * _effective_move_speed() * 0.4
					velocity.z = rd.z * _effective_move_speed() * 0.4
				else:
					velocity.x = 0.0
					velocity.z = 0.0
			var detection_range: float = aggro_range
			if player_alive and player.has_method("get_stealth_detection_multiplier"):
				detection_range *= float(player.get_stealth_detection_multiplier())
			var has_visual_contact: bool = player_alive and dist < detection_range and _can_spot_player(player)
			# Hearing is independent of line of sight: sprinting carries through
			# corridors, while crouched movement is deliberately difficult to hear.
			var stealth_noise_factor: float = 0.38 if player_alive and _target_flag(player, "is_stealthed") else 1.0
			var hearing_skill: float = 1.0
			if player_alive and player.has_method("get_stealth_detection_multiplier"):
				hearing_skill = clampf(float(player.get_stealth_detection_multiplier()), 0.35, 1.0)
			var running_noise: bool = player_alive and _target_flag(player, "is_running") and dist < aggro_range * 1.35 * stealth_noise_factor * hearing_skill
			var movement_noise: bool = player_alive and Vector2(player.velocity.x, player.velocity.z).length() > 5.8 and dist < aggro_range * 1.02 * stealth_noise_factor * hearing_skill
			if has_visual_contact:
				_last_known_player_position = player.global_position
				var noise_factor: float = 1.35 if running_noise else (0.48 if _target_flag(player, "is_stealthed") else 1.0)
				var proximity_factor: float = 1.65 if dist < 4.5 else 1.0
				_player_awareness = minf(1.35, _player_awareness + delta * noise_factor * proximity_factor)
			elif running_noise or movement_noise:
				# Sound can be heard around corners, but it only reveals an approximate last-known position.
				_last_known_player_position = player.global_position
				_player_awareness = minf(1.0, _player_awareness + delta * (0.58 if running_noise else 0.34))
			else:
				_player_awareness = maxf(0.0, _player_awareness - delta * 0.28)
			if _player_awareness >= 1.0:
				state = State.CHASE if has_visual_contact else State.INVESTIGATE
				_investigate_timer = 4.6
				_lost_player_timer = 0.0
				_alert_pack(player)
			elif monster_id in ["grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx", "cinder_hound"]:
				_prey_scan_timer -= delta
				if _prey_scan_timer <= 0.0:
					_prey_scan_timer = 1.8
					var nearest_prey: Node3D = null
					var nearest_prey_distance := 9.5
					for animal in get_tree().get_nodes_in_group("critter"):
						if not is_instance_valid(animal) or not animal is Node3D:
							continue
						if str(animal.get("kind")) not in ["rabbit", "deer", "boar", "chicken"]:
							continue
						var prey_distance := global_position.distance_to((animal as Node3D).global_position)
						if prey_distance < nearest_prey_distance:
							nearest_prey_distance = prey_distance
							nearest_prey = animal as Node3D
					if nearest_prey != null:
						_prey_target = nearest_prey
						state = State.HUNT_PREY
					else:
						var nearest_track: Node3D = null
						var track_distance := 18.0
						for track_variant in get_tree().get_nodes_in_group("wildlife_track"):
							var track := track_variant as Node3D
							if not is_instance_valid(track) or str(track.get_meta("prey_kind", "")) not in ["rabbit", "deer", "boar", "chicken"]: continue
							var age_ms := Time.get_ticks_msec() - int(track.get_meta("track_time", 0))
							if age_ms > 90000: continue
							var d := global_position.distance_to(track.global_position)
							if d < track_distance:
								track_distance = d
								nearest_track = track
						if nearest_track != null:
							var track_direction: Vector3 = nearest_track.get_meta("track_direction", Vector3.ZERO)
							_last_known_player_position = nearest_track.global_position + track_direction * 3.0
							_investigate_timer = 5.0
							set_meta("following_wildlife_track", true)
							state = State.INVESTIGATE
		State.HUNT_PREY:
			if player_alive and dist <= aggro_range and _can_spot_player(player):
				_prey_target = null
				state = State.CHASE
			elif not is_instance_valid(_prey_target) or global_position.distance_to(home) > leash_range:
				_prey_target = null
				state = State.IDLE
			else:
				var to_prey := _prey_target.global_position - global_position
				to_prey.y = 0.0
				var prey_distance := to_prey.length()
				if prey_distance > 1.35:
					var prey_direction := to_prey.normalized()
					velocity.x = prey_direction.x * _effective_move_speed() * 0.9
					velocity.z = prey_direction.z * _effective_move_speed() * 0.9
					rotation.y = lerp_angle(rotation.y, atan2(-prey_direction.x, -prey_direction.z), clampf(delta * 7.0, 0.0, 1.0))
				else:
					velocity.x = 0.0
					velocity.z = 0.0
					_attack_cd = maxf(_attack_cd - delta, 0.0)
					if _attack_cd <= 0.0:
						if _prey_target.has_method("become_carcass"):
							_prey_target.become_carcass()
						_prey_target = null
						_attack_cd = 4.5
						state = State.IDLE
						if _body_mat:
							VFX.burst(self, global_position + Vector3(0, 0.6, 0), body_color, 7, 2.2, 0.04)
		State.INVESTIGATE:
			_investigate_timer = maxf(_investigate_timer - delta, 0.0)
			var investigate_target: Vector3 = _last_known_player_position - global_position
			investigate_target.y = 0.0
			if player_alive and dist <= aggro_range and _can_spot_player(player):
				state = State.CHASE
				_lost_player_timer = 0.0
			elif _investigate_timer <= 0.0 or home.distance_to(global_position) > leash_range:
				state = State.IDLE
				_player_awareness = 0.0
			else:
				if investigate_target.length() > 1.25:
					var investigate_dir: Vector3 = investigate_target.normalized()
					velocity.x = investigate_dir.x * _effective_move_speed() * 0.72
					velocity.z = investigate_dir.z * _effective_move_speed() * 0.72
				else:
					velocity.x = move_toward(velocity.x, 0.0, move_speed * delta)
					velocity.z = move_toward(velocity.z, 0.0, move_speed * delta)
					if bool(get_meta("following_wildlife_track", false)):
						set_meta("following_wildlife_track", false)
						var found_prey: Node3D = null
						var found_distance := 13.0
						for animal_variant in get_tree().get_nodes_in_group("critter"):
							var animal := animal_variant as Node3D
							if not is_instance_valid(animal) or str(animal.get("kind")) not in ["rabbit", "deer", "boar", "chicken"]: continue
							var d := global_position.distance_to(animal.global_position)
							if d < found_distance:
								found_distance = d
								found_prey = animal
						if found_prey != null:
							_prey_target = found_prey
							state = State.HUNT_PREY
						else:
							state = State.IDLE
		State.CHASE:
			if player_alive:
				_alert_pack(player)
			var can_detect_player: bool = player_alive and dist <= aggro_range * (float(player.get_stealth_detection_multiplier()) if player.has_method("get_stealth_detection_multiplier") else 1.0) and _can_spot_player(player)
			if can_detect_player:
				_lost_player_timer = 0.0
				_last_known_player_position = player.global_position
			else:
				_lost_player_timer += delta
			if not player_alive or dist > leash_range:
				state = State.IDLE
				_player_awareness = 0.0
			elif _lost_player_timer > 0.95:
				state = State.INVESTIGATE
				_investigate_timer = 4.6
			elif _elemental_stagger_timer > 0.0:
				velocity.x = move_toward(velocity.x, 0.0, move_speed * 8.0 * delta)
				velocity.z = move_toward(velocity.z, 0.0, move_speed * 8.0 * delta)
			elif _should_retreat() and not _retreat_attempted:
				_retreat_attempted = true
				_retreat_timer = randf_range(1.8, 2.8)
				state = State.RETREAT
				EventBus.activity.emit("%s breaks formation to retreat" % display_name, "combat")
			elif is_boss and bool(get_meta("raid_boss", false)) and _raid_special_cooldown <= 0.0 and dist <= 27.0:
				_begin_raid_special(player)
				state = State.WINDUP
				_windup = maxf(1.05 - float(_boss_phase) * 0.12, 0.72)
				velocity.x = 0.0
				velocity.z = 0.0
			elif dist <= attack_range and _attack_cd <= 0.0:
				state = State.WINDUP
				_windup = 0.45 if not is_boss else 0.55
				velocity.x = 0.0
				velocity.z = 0.0
			else:
				var dir: Vector3 = to_player.normalized()
				var speed_value: float = _effective_move_speed()
				if _uses_flanking_tactics() and dist > attack_range * 1.15 and dist < 12.0:
					_tactical_timer -= delta
					if _tactical_timer <= 0.0:
						_tactical_timer = randf_range(1.2, 2.4)
						_flank_sign *= -1.0
					var lateral: Vector3 = Vector3(-dir.z, 0.0, dir.x) * _flank_sign
					var approach: Vector3 = (dir + lateral * 0.32).normalized()
					velocity.x = approach.x * speed_value
					velocity.z = approach.z * speed_value
				else:
					velocity.x = dir.x * speed_value
					velocity.z = dir.z * speed_value
		State.RETREAT:
			_retreat_timer = maxf(_retreat_timer - delta, 0.0)
			if not player_alive or dist > leash_range or _retreat_timer <= 0.0:
				state = State.CHASE if player_alive and dist <= aggro_range else State.IDLE
			else:
				var away: Vector3 = -to_player.normalized()
				velocity.x = away.x * _effective_move_speed() * 1.15
				velocity.z = away.z * _effective_move_speed() * 1.15
		State.WINDUP:
			_windup -= delta
			velocity.x = 0.0
			velocity.z = 0.0
			if _windup <= 0.0:
				if _raid_special_pending:
					_resolve_raid_special(player_alive, player)
				else:
					if player_alive and player.has_method("take_damage"):
						var hit_radius: float = attack_range * 1.35
						if is_boss and _boss_phase >= 1:
							hit_radius += 2.0 if _boss_phase == 1 else 3.0
						if dist < hit_radius and _has_clear_attack_path(player):
							var impact_damage: float = damage * (1.0 if dist <= attack_range * 1.15 else (0.62 if is_boss else 0.0))
							if impact_damage > 0.0:
								player.take_damage(impact_damage, self)
								if player.has_method("apply_knockback"):
									player.apply_knockback(to_player.normalized() * (10.0 if is_boss and _boss_phase >= 2 else (8.0 if is_boss else 5.5)))
							VFX.burst(self, global_position + Vector3(0, 0.8, 0), body_color, 14 if is_boss else 10, 4.0, 0.06)
							if is_boss and _boss_phase >= 1:
								VFX.impact_ring(get_parent(), global_position + Vector3(0, 0.12, 0), body_color, 1.8 if _boss_phase == 1 else 2.6)
							if is_in_group("colossal_beast"):
								VFX.impact_ring(get_parent(), global_position + Vector3(0, 0.08, 0), Color(0.48, 0.39, 0.28), 3.8)
								VFX.burst(self, global_position + Vector3(0, 0.25, 0), Color(0.52, 0.45, 0.34), 22, 5.5, 0.12)
								for reactive in get_tree().get_nodes_in_group("wind_reactive"):
									if is_instance_valid(reactive) and reactive.global_position.distance_to(global_position) < 18.0 and reactive.has_method("shake_from_beast"):
										reactive.shake_from_beast(global_position)
				_attack_pose = 0.38
				_attack_cd = 1.1 if not is_boss else 1.4
				state = State.CHASE
	if _elemental_push_timer > 0.0:
		_elemental_push_timer = maxf(_elemental_push_timer - delta, 0.0)
		velocity.x += _elemental_push_velocity.x * minf(delta * 7.0, 1.0)
		velocity.z += _elemental_push_velocity.z * minf(delta * 7.0, 1.0)
		_elemental_push_velocity = _elemental_push_velocity.move_toward(Vector3.ZERO, delta * 18.0)
	else:
		_elemental_push_velocity = Vector3.ZERO
	if not is_on_floor():
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	_moving = lerpf(_moving, clampf(Vector2(velocity.x, velocity.z).length() / move_speed, 0.0, 1.0), clampf(delta * 6.0, 0.0, 1.0))
	if is_in_group("colossal_beast") and _moving > 0.35:
		_colossal_step_timer -= delta
		if _colossal_step_timer <= 0.0:
			_colossal_step_timer = 1.15
			var foot_pos := global_position + Vector3(randf_range(-0.8, 0.8), 0.12, randf_range(-0.8, 0.8))
			VFX.burst(get_parent(), foot_pos, Color(0.43, 0.37, 0.29), 9, 2.6, 0.16)
			for reactive in get_tree().get_nodes_in_group("wind_reactive"):
				if is_instance_valid(reactive) and reactive.global_position.distance_to(global_position) < 15.0 and reactive.has_method("shake_from_beast"):
					reactive.shake_from_beast(global_position)
	if _visual and Vector2(velocity.x, velocity.z).length() > 0.15:
		_visual.rotation.y = lerp_angle(_visual.rotation.y, atan2(-velocity.x, -velocity.z) + _facing_offset, clampf(delta * 8.0, 0.0, 1.0))




func _process_faction_warfare(delta: float) -> bool:
	var territory_faction_id: String = str(get_meta("territory_faction_id", ""))
	var is_territorial_fighter: bool = territory_faction_id != ""
	if not is_territorial_fighter and not has_meta("dungeon_faction") and not bool(get_meta("dungeon_ally", false)):
		return false
	if is_boss or state == State.DEAD:
		return false
	_faction_scan_timer -= delta
	if _faction_scan_timer <= 0.0 or _faction_target == null or not is_instance_valid(_faction_target) or (_faction_target is Monster and (_faction_target as Monster).state == State.DEAD):
		_faction_scan_timer = randf_range(0.35, 0.65)
		_faction_target = null
		var own_faction := str(get_meta("dungeon_faction", "PLAYER_ALLY" if bool(get_meta("dungeon_ally", false)) else ""))
		for candidate in get_tree().get_nodes_in_group("enemy"):
			if candidate == self or not is_instance_valid(candidate) or not candidate is Monster:
				continue
			var hostile: bool = false
			if is_territorial_fighter:
				if str(candidate.get_meta("ecology_region", "")) != str(get_meta("ecology_region", "")):
					continue
				var other_territory_faction: String = str(candidate.get_meta("territory_faction_id", ""))
				hostile = other_territory_faction != "" and other_territory_faction != territory_faction_id
			else:
				if int(candidate.get_meta("dungeon_floor", -999)) != int(get_meta("dungeon_floor", -998)):
					continue
				var other_faction := str(candidate.get_meta("dungeon_faction", ""))
				hostile = (bool(get_meta("dungeon_ally", false)) and other_faction != "PLAYER_ALLY") or (other_faction != "" and other_faction != own_faction)
				var campaign: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
				var own_id := str(get_meta("dungeon_faction_id", ""))
				var other_id := str(candidate.get_meta("dungeon_faction_id", ""))
				if campaign and own_id != "" and other_id != "":
					var diplomacy: Dictionary = campaign.faction_status(own_id)
					if str(diplomacy.get("alliance", "")) == other_id:
						hostile = false
			if hostile and global_position.distance_to(candidate.global_position) < 25.0:
				if _faction_target == null or global_position.distance_to(candidate.global_position) < global_position.distance_to(_faction_target.global_position):
					_faction_target = candidate
	if _faction_target == null:
		return false
	var offset := _faction_target.global_position - global_position
	offset.y = 0.0
	var distance := offset.length()
	if distance > 22.0:
		_faction_target = null
		return false
	if distance > attack_range * 0.9:
		var direction := offset.normalized()
		velocity.x = direction.x * _effective_move_speed() * 0.82
		velocity.z = direction.z * _effective_move_speed() * 0.82
	else:
		velocity.x = move_toward(velocity.x, 0.0, move_speed * delta * 5.0)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * delta * 5.0)
		_faction_attack_timer -= delta
		if _faction_attack_timer <= 0.0 and _has_clear_attack_path(_faction_target):
			_faction_attack_timer = 1.25 if not is_boss else 1.6
			if _faction_target.has_method("take_damage"):
				_faction_target.call("take_damage", damage * (0.72 if bool(get_meta("dungeon_ally", false)) else 0.58), self)
			VFX.burst(self, global_position + Vector3.UP * 0.8, body_color, 7, 2.5, 0.05)
	if not is_on_floor():
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	return true

func recruit_as_dungeon_ally(floor_index: int) -> void:
	set_meta("dungeon_ally", true)
	set_meta("dungeon_floor", floor_index)
	set_meta("dungeon_faction", "PLAYER_ALLY")
	set_meta("pack_role", "rescued_companion")
	display_name = "Rescued %s" % display_name
	if label:
		label.text = "ALLY  •  " + display_name
		label.modulate = Color(0.35, 1.0, 0.68)
	state = State.IDLE

func _summon_faction_reinforcements() -> void:
	var packed: PackedScene = load("res://scenes/monster.tscn")
	if packed == null or get_parent() == null:
		return
	var faction := str(get_meta("dungeon_faction", "Forgotten Faction"))
	for i in range(2):
		var guard := packed.instantiate() as Monster
		if guard == null:
			continue
		guard.monster_id = "bronze_sentinel" if i == 0 else "rune_stalker"
		guard.display_name = faction + " Reinforcement"
		guard.max_hp = maxf(30.0, max_hp * 0.22)
		guard.damage = damage * 0.52
		guard.body_color = body_color.lightened(0.18)
		guard.set_meta("dungeon_floor", int(get_meta("dungeon_floor", 0)))
		guard.set_meta("dungeon_faction", faction)
		guard.set_meta("dungeon_tactic", str(get_meta("dungeon_tactic", "guarded_advance")))
		guard.set_meta("dungeon_resistances", get_meta("dungeon_resistances", {}))
		guard.set_meta("pack_id", str(get_meta("pack_id", "commander")))
		get_parent().add_child(guard)
		guard.global_position = global_position + Vector3(float(i * 2 - 1) * 2.2, 0.35, -2.0)
		guard.home = guard.global_position
	EventBus.toast.emit("%s calls its reserve guards into the battle!" % display_name, "warning")

func _summon_raid_reinforcements(phase_number: int) -> void:
	var add_scene: PackedScene = load("res://scenes/monster.tscn")
	if add_scene == null or get_parent() == null:
		return
	var faction: String = str(get_meta("dungeon_faction", "Depthless"))
	var floor_i: int = int(get_meta("dungeon_floor", 0))
	var pack_id: String = "raid_reinforcement_%d_%d" % [floor_i, phase_number]
	var add_count: int = 2 if phase_number == 2 else 3
	for i in range(add_count):
		var ally: Monster = add_scene.instantiate() as Monster
		if ally == null:
			continue
		ally.monster_id = "bronze_sentinel" if i % 2 == 0 else "rune_stalker"
		ally.display_name = "%s Reinforcement" % faction
		ally.is_boss = false
		ally.max_hp = maxf(24.0, max_hp * (0.13 if phase_number == 2 else 0.17))
		ally.damage = damage * 0.42
		ally.body_color = body_color.lightened(0.22)
		ally.move_speed = move_speed * 1.08
		ally.aggro_range = 24.0
		ally.attack_range = 2.2
		ally.leash_range = 44.0
		ally.set_meta("dungeon_floor", floor_i)
		ally.set_meta("dungeon_faction", faction)
		ally.set_meta("dungeon_tactic", str(get_meta("dungeon_tactic", "guarded_advance")))
		ally.set_meta("dungeon_resistances", get_meta("dungeon_resistances", {}))
		ally.set_meta("pack_id", pack_id)
		ally.set_meta("pack_role", "guard")
		get_parent().add_child(ally)
		ally.global_position = global_position + Vector3(cos(float(i) * TAU / float(add_count)) * 5.0, 0.35, sin(float(i) * TAU / float(add_count)) * 5.0)
		ally.home = ally.global_position
	EventBus.toast.emit("%s calls in %d faction reinforcements!" % [display_name, add_count], "warning")

func get_boss_phase() -> int:
	return _boss_phase


func _begin_raid_special(target: Node3D) -> void:
	_raid_special_pending = true
	_raid_target_snapshot = target.global_position
	var patterns: Array[String] = ["ring_slam", "void_lance", "cross_burst", "inner_blast"]
	var signature: String = str(get_meta("dungeon_signature_pattern", ""))
	var base_index: int = int(get_meta("raid_pattern_index", 0))
	_raid_special_pattern = signature if signature != "" and (_raid_attack_count % 2 == 0 or _boss_phase >= 2) else patterns[(base_index + _raid_attack_count) % patterns.size()]
	_clear_raid_telegraph()
	var warning := Node3D.new()
	warning.name = "RaidBossAttackTelegraph"
	get_parent().add_child(warning)
	warning.global_position = global_position + Vector3(0, 0.12, 0)
	_raid_telegraph = warning
	var danger := Color(1.0, 0.22, 0.10).lerp(body_color, 0.28)
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(danger.r, danger.g, danger.b, 0.58)
	material.emission_enabled = true
	material.emission = danger
	material.emission_energy_multiplier = 2.0
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.render_priority = 0
	match _raid_special_pattern:
		"ring_slam":
			var ring := MeshInstance3D.new()
			var torus := TorusMesh.new()
			torus.inner_radius = 0.91
			torus.outer_radius = 1.0
			torus.rings = 48
			torus.ring_segments = 12
			ring.mesh = torus
			ring.material_override = material
			ring.scale = Vector3(15.0, 1.0, 15.0)
			warning.add_child(ring)
		"void_lance":
			var direction: Vector3 = _raid_target_snapshot - global_position
			direction.y = 0.0
			direction = direction.normalized()
			var lane := MeshInstance3D.new()
			var lane_mesh := BoxMesh.new()
			lane_mesh.size = Vector3(5.6, 0.08, 27.0)
			lane.mesh = lane_mesh
			lane.material_override = material
			lane.position = direction * 13.5
			lane.rotation.y = atan2(-direction.x, -direction.z)
			warning.add_child(lane)
		"cross_burst":
			for axis in range(2):
				var lane := MeshInstance3D.new()
				var lane_mesh := BoxMesh.new()
				lane_mesh.size = Vector3(4.6, 0.08, 25.0) if axis == 0 else Vector3(25.0, 0.08, 4.6)
				lane.mesh = lane_mesh
				lane.material_override = material
				warning.add_child(lane)
		"inner_blast":
			var ring := MeshInstance3D.new()
			var torus := TorusMesh.new()
			torus.inner_radius = 0.9
			torus.outer_radius = 1.0
			ring.mesh = torus
			ring.material_override = material
			ring.scale = Vector3(10.0, 1.0, 10.0)
			warning.add_child(ring)
		"bronze_lance", "void_fold":
			var lane := MeshInstance3D.new(); var lane_mesh := BoxMesh.new(); lane_mesh.size = Vector3(7.0, 0.1, 30.0); lane.mesh = lane_mesh; lane.material_override = material
			var direction: Vector3 = _raid_target_snapshot - global_position; direction.y = 0.0; direction = direction.normalized()
			lane.position = direction * 15.0; lane.rotation.y = atan2(-direction.x, -direction.z); warning.add_child(lane)
		"spore_cloud", "grave_pulse", "frost_ring", "tide_surge":
			var ring := MeshInstance3D.new(); var torus := TorusMesh.new(); torus.inner_radius = 0.9; torus.outer_radius = 1.0; ring.mesh = torus; ring.material_override = material
			ring.scale = Vector3(13.0, 1.0, 13.0); warning.add_child(ring)
		"prism_split", "astral_orbit":
			for axis in range(4):
				var ray := MeshInstance3D.new(); var ray_mesh := BoxMesh.new(); ray_mesh.size = Vector3(3.2, 0.1, 24.0); ray.mesh = ray_mesh; ray.material_override = material
				ray.rotation.y = float(axis) * PI * 0.25; warning.add_child(ray)
		"ash_cone":
			var cone := MeshInstance3D.new(); var cone_mesh := CylinderMesh.new(); cone_mesh.top_radius = 9.0; cone_mesh.bottom_radius = 1.0; cone_mesh.height = 0.12; cone.mesh = cone_mesh; cone.material_override = material
			var forward: Vector3 = (_raid_target_snapshot - global_position).normalized(); cone.position = forward * 7.0; cone.rotation.x = PI * 0.5; cone.rotation.y = atan2(-forward.x, -forward.z); warning.add_child(cone)
		"root_snare":
			var snare := MeshInstance3D.new(); var snare_mesh := BoxMesh.new(); snare_mesh.size = Vector3(14.0, 0.1, 14.0); snare.mesh = snare_mesh; snare.material_override = material; warning.add_child(snare)
	# Add a high-contrast outer silhouette to every shape. These unshaded edges
	# remain readable under lantern bloom, fog and bright elemental environments.
	var edge_material := StandardMaterial3D.new()
	edge_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	edge_material.albedo_color = Color(1.0, 0.92, 0.64, 0.96)
	edge_material.emission_enabled = true
	edge_material.emission = Color(1.0, 0.28, 0.08)
	edge_material.emission_energy_multiplier = 2.7
	edge_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	edge_material.render_priority = 1
	var warning_shapes: Array[Node] = warning.get_children()
	for shape_node in warning_shapes:
		if shape_node is MeshInstance3D:
			var edge_shape := (shape_node as MeshInstance3D).duplicate() as MeshInstance3D
			edge_shape.name = "TelegraphHighContrastEdge"
			edge_shape.material_override = edge_material
			edge_shape.scale = edge_shape.scale * Vector3(1.045, 1.15, 1.045)
			warning.add_child(edge_shape)
	EventBus.toast.emit("RAID WARNING — %s prepares %s! Move now!" % [display_name, _raid_special_pattern.replace("_", " ").to_upper()], "warning")

func _target_flag(target: Node, property_name: String) -> bool:
	# Monsters can lock onto NPCs as well as the player, and only the player
	# carries stealth flags, so a missing property must not be read blindly.
	if target == null or not is_instance_valid(target):
		return false
	if not (property_name in target):
		return false
	return bool(target.get(property_name))

func _resolve_raid_special(player_alive: bool, target: Node3D) -> void:
	var hit: bool = false
	if player_alive and target != null and is_instance_valid(target):
		var flat_delta: Vector3 = target.global_position - global_position
		flat_delta.y = 0.0
		var distance: float = flat_delta.length()
		match _raid_special_pattern:
			"ring_slam":
				hit = distance >= 4.8 and distance <= 15.8
			"void_lance":
				var direction := _raid_target_snapshot - global_position
				direction.y = 0.0
				var raid_axis := Vector2(direction.x, direction.z).normalized()
				var to_target := Vector2(flat_delta.x, flat_delta.z)
				var forward: float = to_target.dot(raid_axis)
				var lateral: float = absf(raid_axis.cross(to_target))
				hit = forward >= 1.2 and forward <= 27.0 and lateral <= 2.8
			"cross_burst":
				hit = distance <= 17.0 and (absf(flat_delta.x) <= 2.6 or absf(flat_delta.z) <= 2.6)
			"inner_blast":
				hit = distance <= 10.5
			"bronze_lance", "void_fold":
				var direction: Vector3 = _raid_target_snapshot - global_position; direction.y = 0.0; var axis := Vector2(direction.x, direction.z).normalized(); var point := Vector2(flat_delta.x, flat_delta.z)
				hit = point.dot(axis) >= 0.0 and point.dot(axis) <= 30.0 and absf(axis.cross(point)) <= 3.5
			"spore_cloud", "grave_pulse", "frost_ring", "tide_surge":
				hit = distance >= 3.5 and distance <= 14.0
			"prism_split", "astral_orbit":
				hit = distance <= 25.0 and (absf(flat_delta.x) <= 2.1 or absf(flat_delta.z) <= 2.1 or absf(absf(flat_delta.x) - absf(flat_delta.z)) <= 2.8)
			"ash_cone":
				var forward: Vector3 = _raid_target_snapshot - global_position; forward.y = 0.0; var axis := Vector2(forward.x, forward.z).normalized(); var point := Vector2(flat_delta.x, flat_delta.z)
				hit = point.dot(axis) >= 0.0 and point.dot(axis) <= 19.0 and absf(axis.cross(point)) <= point.length() * 0.62
			"root_snare":
				hit = absf(flat_delta.x) <= 7.0 and absf(flat_delta.z) <= 7.0
		if hit and _has_clear_attack_path(target) and target.has_method("take_damage"):
			var special_damage: float = damage * (1.42 + float(_boss_phase) * 0.16)
			target.take_damage(special_damage, self)
			if target.has_method("apply_knockback"):
				target.apply_knockback(flat_delta.normalized() * (12.0 + float(_boss_phase) * 2.0))
			VFX.impact_ring(get_parent(), global_position + Vector3(0, 0.16, 0), body_color.lightened(0.2), 10.0 if _raid_special_pattern != "inner_blast" else 7.0)
			VFX.burst(get_parent(), global_position + Vector3(0, 0.8, 0), body_color, 34, 10.0, 0.1)
		elif player_alive:
			EventBus.toast.emit("You avoided the raid strike! %s is exposed — punish the recovery!" % display_name, "levelup")
			if is_boss:
				_raid_exposed_timer = 4.0
	_raid_special_pending = false
	_raid_attack_count += 1
	_raid_special_cooldown = maxf(10.5 - float(_boss_phase) * 1.15, 6.5)
	_clear_raid_telegraph()

func _clear_raid_telegraph() -> void:
	if _raid_telegraph != null and is_instance_valid(_raid_telegraph):
		_raid_telegraph.queue_free()
	_raid_telegraph = null

func _should_retreat() -> bool:
	if is_boss or monster_id not in ["bandit", "bandit_warlord", "spore_moth", "night_wisp", "astral_scribe", "ember_shaman"]:
		return false
	if health == null or health.max_health <= 0.0:
		return false
	return health.current_health / health.max_health <= 0.28 and randf() < 0.012

func _uses_flanking_tactics() -> bool:
	return monster_id in ["grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx", "bandit", "bandit_warlord", "prism_stalker", "fungal_stalker"] or has_meta("pack_id")

func get_elemental_resistance(element: String) -> float:
	# Positive values resist damage; negative values mark an elemental weakness.
	var resistances: Dictionary = {
		"ember_wyrm":{"fire":0.72,"water":-0.38,"ice":-0.42},
		"cinder_hound":{"fire":0.48,"water":-0.18,"ice":-0.22},
		"frost_lynx":{"ice":0.72,"fire":-0.42},
		"tide_serpent":{"water":0.68,"ice":0.24,"lightning":-0.22},
		"reef_crab":{"water":0.52,"earth":0.22,"lightning":-0.30},
		"stone_crawler":{"earth":0.62,"lightning":-0.18,"wind":0.18},
		"bronze_sentinel":{"earth":0.44,"lightning":-0.32,"fire":0.18},
		"iron_golem_shard":{"earth":0.56,"lightning":-0.35,"wind":0.2},
		"rootbound_guardian":{"earth":0.46,"water":0.18,"fire":-0.28},
		"spore_moth":{"wind":-0.26,"fire":0.24,"ice":0.12},
		"void_jelly":{"void":0.4,"lightning":-0.22,"fire":0.12},
		"night_wisp":{"lightning":0.3,"earth":-0.22,"ice":0.16},
		"prism_stalker":{"lightning":0.34,"wind":-0.18,"earth":0.2},
		"grave_hound":{"ice":0.18,"fire":-0.18},
		"astral_scribe":{"lightning":0.24,"wind":0.18,"earth":-0.12}
	}
	var species: Dictionary = resistances.get(monster_id, {})
	var base_resistance: float = float(species.get(element, 0.0))
	var faction_resistances: Variant = get_meta("dungeon_resistances", {})
	if faction_resistances is Dictionary and (faction_resistances as Dictionary).has(element):
		base_resistance = clampf(base_resistance + float((faction_resistances as Dictionary)[element]), -0.55, 0.82)
	return clampf(base_resistance, -0.55, 0.82)

func _effective_move_speed() -> float:
	return move_speed * clampf(_elemental_slow_factor, 0.35, 1.0)

func _near_settlement_protection(position: Vector3) -> bool:
	var point := Vector2(position.x, position.z)
	return point.distance_to(TerrainNoise.VILLAGE_CENTER) < 68.0 or point.distance_to(TerrainNoise.SPIRE_CENTER) < 68.0

func _can_spot_player(target: Node3D) -> bool:
	if target == null or not is_instance_valid(target) or not _has_clear_attack_path(target):
		return false
	var to_target: Vector3 = target.global_position - global_position
	to_target.y = 0.0
	if to_target.length_squared() < 0.01:
		return true
	var facing: Node3D = _visual if _visual and is_instance_valid(_visual) else self
	var forward: Vector3 = -facing.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.01:
		return true
	# Close movement is difficult to miss; distant targets must be in a broad
	# forward arc. Solid geometry still blocks sight through dungeon walls.
	return to_target.length() < 3.5 or forward.normalized().dot(to_target.normalized()) > -0.18

func apply_elemental_status(element: String, source: Node = null, power: float = 1.0) -> void:
	var resistance: float = get_elemental_resistance(element)
	_last_resisted_element = element
	if resistance >= 0.65:
		VFX.burst(self, global_position + Vector3.UP * 0.8, body_color.lightened(0.35), 5, 1.8, 0.04)
		if resistance >= 0.75:
			EventBus.toast.emit("%s resists %s" % [display_name, element.capitalize()], "info")
	var adjusted_power: float = power * clampf(1.0 - resistance, 0.18, 1.5)
	power = adjusted_power
	match element:
		"fire":
			_elemental_burn_timer = maxf(_elemental_burn_timer, 3.2)
			_elemental_burn_tick = minf(_elemental_burn_tick, 0.35) if _elemental_burn_tick > 0.0 else 0.35
			_elemental_burn_damage = maxf(_elemental_burn_damage, 2.2 * power)
			_elemental_burn_source = source
			VFX.burst(self, global_position + Vector3.UP * 0.9, Color(1.0, 0.32, 0.08), 8, 2.5, 0.05)
		"ice":
			_elemental_slow_timer = maxf(_elemental_slow_timer, 2.8 + power * 0.35)
			_elemental_slow_factor = minf(_elemental_slow_factor, clampf(0.58 - power * 0.025, 0.34, 0.58))
			if power >= 2.2:
				_elemental_stagger_timer = maxf(_elemental_stagger_timer, 0.48)
				if state == State.WINDUP:
					state = State.CHASE
					_raid_special_pending = false
					_clear_raid_telegraph()
			VFX.burst(self, global_position + Vector3.UP * 0.8, Color(0.55, 0.88, 1.0), 12, 2.8, 0.05)
		"wind":
			if source is Node3D:
				var away: Vector3 = global_position - (source as Node3D).global_position
				away.y = 0.0
				if away.length_squared() > 0.01:
					_elemental_push_velocity += away.normalized() * (5.0 + power * 2.0)
					_elemental_push_timer = maxf(_elemental_push_timer, 0.32)
			VFX.burst(self, global_position + Vector3.UP * 0.65, Color(0.55, 0.95, 0.76), 10, 3.2, 0.045)
		"earth":
			_elemental_stagger_timer = maxf(_elemental_stagger_timer, 0.65 + power * 0.18)
			_rest_timer = maxf(_rest_timer, 0.72 + power * 0.2)
			velocity.x = 0.0
			velocity.z = 0.0
			if state == State.WINDUP:
				state = State.CHASE
				_raid_special_pending = false
				_clear_raid_telegraph()
			VFX.impact_ring(get_parent(), global_position + Vector3.UP * 0.08, Color(0.72, 0.54, 0.31), 1.6)
		"lightning":
			_elemental_stagger_timer = maxf(_elemental_stagger_timer, 0.28 + power * 0.08)
			if state == State.WINDUP:
				state = State.CHASE
				_raid_special_pending = false
				_clear_raid_telegraph()
			VFX.burst(self, global_position + Vector3.UP, Color(0.98, 0.88, 0.25), 14, 4.0, 0.04)
		"water":
			_elemental_slow_timer = maxf(_elemental_slow_timer, 1.25)
			_elemental_slow_factor = minf(_elemental_slow_factor, 0.82)
			VFX.burst(self, global_position + Vector3.UP * 0.6, Color(0.2, 0.66, 1.0), 8, 2.4, 0.05)

func _process_elemental_status(delta: float) -> void:
	if _elemental_burn_timer > 0.0:
		_elemental_burn_timer = maxf(_elemental_burn_timer - delta, 0.0)
		_elemental_burn_tick -= delta
		if _elemental_burn_tick <= 0.0 and health and state != State.DEAD:
			_elemental_burn_tick = 0.85
			take_damage(_elemental_burn_damage, _elemental_burn_source, false)
	if _elemental_slow_timer > 0.0:
		_elemental_slow_timer = maxf(_elemental_slow_timer - delta, 0.0)
		if _elemental_slow_timer <= 0.0:
			_elemental_slow_factor = 1.0

func _has_clear_attack_path(target: Node3D) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var from: Vector3 = global_position + Vector3.UP * 0.8
	var to: Vector3 = target.global_position + Vector3.UP * 0.9
	var query := PhysicsRayQueryParameters3D.create(from, to, Constants.LAYER_WORLD, [get_rid()])
	query.collide_with_areas = false
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or hit.get("collider") == target

func _alert_pack(player: Node3D) -> void:
	if _pack_alerted or is_boss or not has_meta("pack_id"):
		return
	_pack_alerted = true
	var pack_id: String = str(get_meta("pack_id"))
	for ally in get_tree().get_nodes_in_group("enemy"):
		if ally == self or not is_instance_valid(ally) or not ally.has_meta("pack_id"):
			continue
		if str(ally.get_meta("pack_id")) == pack_id and ally is Monster and ally.state == State.IDLE:
			# Packmates converge on the last known position first, then acquire
			# visual contact before committing to a direct chase.
			ally._last_known_player_position = player.global_position
			ally._investigate_timer = 5.5
			ally._player_awareness = 1.0
			ally.state = State.INVESTIGATE
			ally._pack_alerted = true
	EventBus.activity.emit("A dungeon hunting pack has been alerted", "combat")

func take_damage(amount: float, source: Node = null, crit: bool = false) -> void:
	_apply_damage(amount, source, crit, "")

func take_elemental_damage(amount: float, source: Node = null, element: String = "fire", crit: bool = false) -> void:
	_apply_damage(amount, source, crit, element)

func _apply_damage(amount: float, source: Node, crit: bool, element: String) -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		return # Online damage is resolved by the server's combat authority.
	if state == State.DEAD or health == null:
		return
	var effective_amount: float = amount
	if is_boss and _raid_exposed_timer > 0.0:
		effective_amount *= 1.6
	if element != "":
		var resistance: float = get_elemental_resistance(element)
		effective_amount *= clampf(1.0 - resistance, 0.22, 1.5)
		_last_resisted_element = element
		_record_elemental_observation(element, resistance, source)
		if resistance >= 0.65 and randf() < 0.18:
			EventBus.toast.emit("%s shrugs off part of the %s force" % [display_name, element], "info")
	health.take_damage(effective_amount, source)
	if bool(get_meta("faction_commander", false)) and not _faction_reinforcement_used and health.current_health <= health.max_health * 0.48:
		_faction_reinforcement_used = true
		_summon_faction_reinforcements()
	var dn: DamageNumber = DAMAGE_NUMBER_SCENE.instantiate()
	get_tree().current_scene.add_child(dn)
	dn.global_position = global_position + Vector3(0, 2.0 if is_boss else 1.6, 0)
	dn.setup(effective_amount, crit)
	VFX.burst(self, global_position + Vector3(0, 0.7, 0), body_color.lightened(0.25), 12, 4.5, 0.05)
	if source is Node3D and state != State.DEAD:
		var away: Vector3 = global_position - (source as Node3D).global_position
		away.y = 0.0
		if away.length() > 0.01:
			velocity += away.normalized() * (3.0 if is_boss else 4.5)
		state = State.CHASE
	EventBus.entity_damaged.emit(self, effective_amount, source)

func _record_elemental_observation(element: String, resistance: float, source: Node) -> void:
	if absf(resistance) < 0.18:
		return
	var all_value: Variant = PlayerData.stats.get("bestiary_elemental_notes", {})
	var all_notes: Dictionary = all_value.duplicate(true) if all_value is Dictionary else {}
	var species_value: Variant = all_notes.get(monster_id, {})
	var species_notes: Dictionary = species_value.duplicate(true) if species_value is Dictionary else {}
	if species_notes.has(element):
		return
	var finding: String = "resists" if resistance > 0.0 else "is vulnerable to"
	species_notes[element] = {"finding":finding, "strength":absf(resistance)}
	all_notes[monster_id] = species_notes
	PlayerData.stats["bestiary_elemental_notes"] = all_notes
	if source != null and is_instance_valid(source):
		var skill_value: Variant = source.get("skills")
		if skill_value is SkillSystem:
			(skill_value as SkillSystem).train("monster_lore", 0.24, true)
			(skill_value as SkillSystem).train("observation", 0.12, true)
	EventBus.activity.emit("Bestiary insight: %s %s %s" % [display_name, finding, element], "exploration")
	EventBus.toast.emit("Bestiary updated: %s %s %s" % [display_name, finding, element], "discovery")

func apply_rare_variant(variant_name: String, tint: Color, unique_drop: String) -> void:
	set_meta("rare_encounter", true)
	set_meta("rare_variant_drop", unique_drop)
	display_name = variant_name
	body_color = tint
	if _body_mat:
		_body_mat.albedo_color = tint
	if label:
		label.text = "✦ " + variant_name
		label.modulate = Color(0.95, 0.78, 1.0)
	if _visual:
		_visual.scale *= 1.12

func _on_health_changed(current: float, maximum: float) -> void:
	if label:
		var prefix: String = "RAID GUARDIAN  •  " if bool(get_meta("raid_boss", false)) else ("Boss " if is_boss else "")
		label.text = "%s%s  %d/%d" % [prefix, display_name, int(ceil(current)), int(maximum)]
		label.modulate = Color(0.75, 0.9, 1.0).lerp(Color(1.0, 0.35, 0.3), 1.0 - clampf(current / maxf(maximum, 1.0), 0.0, 1.0))
		if is_boss:
			label.modulate = Color(1.0, 0.75, 0.3).lerp(Color(1.0, 0.25, 0.2), 1.0 - clampf(current / maxf(maximum, 1.0), 0.0, 1.0))

func _on_died(source: Node) -> void:
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		_clear_raid_telegraph()
		state = State.DEAD
		remove_from_group("enemy")
		if is_in_group("boss"):
			remove_from_group("boss")
		var client_col: Node = get_node_or_null("CollisionShape3D")
		if client_col:
			client_col.set_deferred("disabled", true)
		if label:
			label.visible = false
		return
	if has_meta("mmo_world_entity_id") and MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.broadcast_world_monster_despawn(self)
	_clear_raid_telegraph()
	state = State.DEAD
	remove_from_group("enemy")
	if is_in_group("boss"):
		remove_from_group("boss")
	var col: Node = get_node_or_null("CollisionShape3D")
	if col:
		col.set_deferred("disabled", true)
	EventBus.entity_died.emit(self)
	WorldLifeSimulation.record_monster_killed(self)
	# Feed real autonomous battlefield casualties into the persistent campaign ledger.
	var campaign: Node = get_tree().get_root().get_node_or_null("DungeonCampaign")
	if campaign and source is Monster:
		var attacker_id := str(source.get_meta("dungeon_faction_id", ""))
		var defender_id := str(get_meta("dungeon_faction_id", ""))
		if attacker_id != "" and defender_id != "" and attacker_id != defender_id:
			campaign.record_battle(int(get_meta("dungeon_floor", 0)) + 1, attacker_id, defender_id, "leader_defeated" if bool(get_meta("faction_commander", false)) else "battle")
		elif attacker_id != "" and bool(get_meta("dungeon_ally", false)):
			campaign.player_action(attacker_id, "aid", 2)
	if campaign and bool(get_meta("faction_commander", false)):
		var own_id := str(get_meta("dungeon_faction_id", ""))
		if own_id != "":
			var status: Dictionary = campaign.faction_status(own_id)
			status["leader_alive"] = false
			status["leader_guard"] = 0
			campaign.campaign[own_id] = status
	VFX.burst(get_parent(), global_position + Vector3(0, 0.6, 0), body_color, 28 if is_boss else 18, 7.0, 0.1)
	PlayerData.stats["kills"] = int(PlayerData.stats.get("kills", 0)) + 1
	var sg: Node = get_tree().get_first_node_in_group("settlement_growth")
	if sg and sg.has_method("add_progress"):
		sg.add_progress("elyndor", 1.5 if not is_boss else 12.0)

	if quest_tag != "":
		PlayerData.notify("kill", quest_tag, 1)
		if MMORPGNetwork.is_online() and multiplayer.is_server():
			MMORPGNetwork.server_record_quest_event_for_active_peer("kill", quest_tag)
	if is_boss:
		GuildSystem.add_renown(25, "Defeated %s" % display_name)
		PlayerData.notify("kill", "boss", 1)
		EventBus.toast.emit("%s defeated!" % display_name, "levelup")
		EventBus.activity.emit("Boss defeated: %s" % display_name, "combat")
	if source and source.get("skills") != null:
		# Weapon mastery is trained by successful weapon impacts on the player.
		# Awarding sword XP on every kill incorrectly trained sword users regardless
		# of their equipped weapon, and bosses were awarding it twice.
		if monster_id in ["dungeon_rat", "bone_skitter", "cave_slime", "shadow_bat", "stone_crawler", "ash_imp", "void_mite", "iron_golem_shard", "night_wisp", "fungal_stalker", "crystal_mimic", "cinder_hound", "drowned_guard", "rune_stalker", "abyss_mantis", "grave_knight", "ember_shaman", "void_stalker", "bronze_sentinel", "spore_moth", "prism_stalker", "grave_hound", "ember_wyrm", "frost_lynx", "reef_crab", "rootbound_guardian", "void_jelly", "astral_scribe"] or monster_id.begins_with("boss_"):
			source.skills.train("monster_lore", 0.35 if not is_boss else 1.5)
			if is_boss:
				source.skills.train("dungeon_delving", 0.8)
	# Loot via shared table + chance of ground drop
	var dungeon_floor: int = int(get_meta("dungeon_floor", -1))
	var table: LootTable = LootTable.dungeon_boss_for_floor(dungeon_floor) if is_boss and dungeon_floor >= 0 else LootTable.for_monster(monster_id)
	var luck: float = 0.02 * float(growth_rank)
	# Delving and arcane knowledge improve discovery quality without guaranteeing rare drops.
	if source and source.get("skills") != null:
		luck += minf(source.skills.get_value("dungeon_delving") * 0.0015, 0.12)
		luck += minf(source.skills.get_value("arcane_attunement") * 0.0008, 0.06)
		luck += minf(source.skills.get_value("wisdom") * 0.00045, 0.045)
		luck += minf(source.skills.get_value("knowledge") * 0.00065, 0.065)
		luck += minf(source.skills.get_value("ancient_lore") * 0.0008, 0.08)
		luck += source.skills.trait_bonus("loot_luck")
	var drops: Array = table.roll(luck)
	if bool(get_meta("world_boss", false)):
		var legendary_id: String = str(get_meta("legendary_reward_id", ""))
		if legendary_id != "" and ItemDB.has_item(legendary_id):
			drops.append({"id":legendary_id,"count":1})
		WorldLifeSimulation.record_world_boss_defeated(self)
		EventBus.toast.emit("Legendary territory relic recovered!", "levelup")
	if bool(get_meta("rare_encounter", false)):
		var rare_items: Array[String] = ["forgotten_essence", "runebound_core", "abyssal_relic"]
		var rare_id: String = rare_items[randi_range(0, rare_items.size() - 1)]
		drops.append({"id": rare_id, "count": 1})
		var variant_drop: String = str(get_meta("rare_variant_drop", ""))
		if variant_drop != "" and ItemDB.has_item(variant_drop):
			drops.append({"id": variant_drop, "count": 1})
		if randf() < 0.22:
			drops.append({"id": "eclipse_edge" if randf() < 0.5 else "warden_heartplate", "count": 1})
		EventBus.toast.emit("Rare monster defeated! A unique relic dropped.", "levelup")
	var gold_reward: int = table.roll_gold() if table.gold_max > 0 else randi_range(gold_min, gold_max)
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.grant_gold_to_combat_peer(gold_reward)
	else:
		PlayerData.add_gold(gold_reward)
	var parent_n: Node = get_parent()
	var loot_grade: int = clampi(int(maxi(dungeon_floor, 0) / 25), 0, 5) if dungeon_floor >= 0 else 0
	if source and source.get("skills") != null and dungeon_floor >= 0:
		loot_grade = clampi(loot_grade + int(source.skills.get_value("knowledge") / 45.0) + int(source.skills.get_value("ancient_lore") / 35.0), 0, 5)
	for d in drops:
		var iid2: String = str(d["id"])
		var cnt2: int = int(d["count"])
		# In the shared world, every drop is a server-spawned world object so all
		# nearby players see the same loot and the server arbitrates the pickup.
		if MMORPGNetwork.is_online() and multiplayer.is_server() and parent_n:
			LootDrop.spawn_at(parent_n, global_position, iid2, cnt2)
		elif not is_boss and randf() < 0.4 and parent_n:
			LootDrop.spawn_at(parent_n, global_position, iid2, cnt2)
		else:
			PlayerData.add_item(iid2, cnt2, loot_grade)
	# Affinity / rep
	var rep: Node = get_tree().get_first_node_in_group("reputation")
	if rep:
		if monster_id in ["bandit", "bandit_warlord"]:
			rep.add_rep("bandits", -1 if not is_boss else -5)
			rep.add_rep("elyndor", 1 if not is_boss else 3)
		elif is_boss:
			rep.add_rep("elyndor", 4)
			rep.add_rep("wilderness", 2)
	if label:
		label.visible = false
	var tw: Tween = create_tween()
	if _visual:
		var fall_angle: float = -1.1 if monster_id in ["grey_wolf", "alpha_wolf", "grave_hound", "frost_lynx"] else 0.9
		tw.set_parallel(true)
		tw.tween_property(_visual, "rotation:z", fall_angle, 0.28).set_ease(Tween.EASE_IN)
		tw.tween_property(_visual, "position:y", -0.35, 0.32).set_ease(Tween.EASE_IN)
		tw.tween_property(_visual, "scale", Vector3(1.15, 0.08, 1.15), 0.38).set_ease(Tween.EASE_IN)
		tw.set_parallel(false)
	tw.tween_callback(queue_free)
