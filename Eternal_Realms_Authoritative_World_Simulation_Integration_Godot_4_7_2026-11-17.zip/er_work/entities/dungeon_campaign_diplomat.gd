extends Area3D
## Parley interaction at an occupied fortress.
var faction_id := "labyrinth"
var faction_name := "Forgotten Faction"
var floor_number := 1
func _ready() -> void:
	add_to_group("interactable")
	add_to_group("dungeon_discovery")
	set_meta("interact_range", 3.8)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 2.0
	collision.shape = shape
	add_child(collision)
	monitoring = true
	collision_layer = Constants.LAYER_WORLD
	collision_mask = 0
func can_interact() -> bool:
	return true
func get_prompt() -> String:
	return "Parley with %s commander" % faction_name
func interact(_player: Node3D = null) -> void:
	var campaign: Node = get_node_or_null("/root/DungeonCampaign")
	if campaign == null: return
	var rep := int(PlayerData.stats.get("culture_rep_" + faction_id, 0))
	if rep >= 8 and campaign.negotiate_player_truce(faction_id):
		EventBus.toast.emit("Parley accepted: %s agrees to a temporary ceasefire." % faction_name, "levelup")
	else:
		campaign.player_action(faction_id, "aid", 3)
		EventBus.toast.emit("You offer supplies to %s. Build reputation to secure a truce." % faction_name, "info")
	EventBus.activity.emit("Parley with %s — reputation %d" % [faction_name, rep], "world")
