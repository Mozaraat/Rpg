# Slime - a bouncy gelatinous enemy with simple wander / chase / attack AI
extends CharacterBody3D
class_name Slime

enum State { IDLE, CHASE, WINDUP, DEAD }

@export var slime_color: Color = Color(0.32, 0.85, 0.42)
@export var damage: float = 8.0
@export var xp_reward: float = 25.0
@export var aggro_range: float = 11.0
@export var leash_range: float = 28.0

@onready var health: HealthComponent = $HealthComponent
@onready var label: Label3D = $Label3D

const DAMAGE_NUMBER_SCENE = preload("res://ui/damage_number.tscn")

var state: State = State.IDLE
var home: Vector3 = Vector3.ZERO
var _visual: Node3D
var _body_mat: StandardMaterial3D
var _t: float = 0.0
var _wander_dir: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0
var _attack_cd: float = 0.0
var _windup: float = 0.0
var _moving: float = 0.0
var _visual_size: float = 1.0

func _ready() -> void:
	add_to_group("enemy")
	home = global_position
	_t = randf() * 10.0
	_build_visual()
	_visual_size = randf_range(0.82, 1.42)
	var body_collision := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if body_collision and body_collision.shape:
		body_collision.shape = body_collision.shape.duplicate()
		if body_collision.shape is CapsuleShape3D:
			var capsule := body_collision.shape as CapsuleShape3D
			capsule.radius *= _visual_size
			capsule.height *= _visual_size
		body_collision.position.y *= _visual_size
	var nameplate := get_node_or_null("Label3D") as Label3D
	if nameplate:
		nameplate.position.y *= _visual_size
	health.max_health *= _visual_size
	health.current_health = health.max_health
	health.health_changed.connect(_on_health_changed)
	health.died.connect(_on_died)
	_on_health_changed(health.current_health, health.max_health)

func _build_visual() -> void:
	_visual = Node3D.new()
	_visual.name = "Visual"
	add_child(_visual)
	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = Color(slime_color.r, slime_color.g, slime_color.b, 0.62)
	_body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_body_mat.roughness = 0.06
	_body_mat.metallic = 0.0
	_body_mat.rim_enabled = true
	_body_mat.rim = 0.7
	_body_mat.rim_tint = 0.4
	_body_mat.emission_enabled = true
	_body_mat.emission = slime_color
	_body_mat.emission_energy_multiplier = 0.25
	var body := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.55
	sm.height = 1.0
	sm.radial_segments = 24
	sm.rings = 14
	body.mesh = sm
	body.material_override = _body_mat
	body.position = Vector3(0, 0.42, 0)
	body.scale = Vector3(1.0, 0.85, 1.0)
	body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_visual.add_child(body)

	var core_mat := StandardMaterial3D.new()
	core_mat.albedo_color = slime_color.darkened(0.55)
	core_mat.roughness = 0.5
	var core := MeshInstance3D.new()
	var cm := SphereMesh.new()
	cm.radius = 0.2
	cm.height = 0.4
	core.mesh = cm
	core.material_override = core_mat
	core.position = Vector3(0, 0.3, 0.05)
	_visual.add_child(core)

	var white := StandardMaterial3D.new()
	white.albedo_color = Color(1, 1, 1)
	white.roughness = 0.3
	var black := StandardMaterial3D.new()
	black.albedo_color = Color(0.03, 0.03, 0.04)
	for side in [-1.0, 1.0]:
		var e := MeshInstance3D.new()
		var em := SphereMesh.new()
		em.radius = 0.09
		em.height = 0.18
		e.mesh = em
		e.material_override = white
		e.position = Vector3(side * 0.2, 0.52, -0.42)
		e.scale = Vector3(1, 1.15, 0.6)
		_visual.add_child(e)
		var p := MeshInstance3D.new()
		var pm := SphereMesh.new()
		pm.radius = 0.05
		pm.height = 0.1
		p.mesh = pm
		p.material_override = black
		p.position = Vector3(side * 0.2, 0.51, -0.47)
		_visual.add_child(p)
	label.position.y = 1.55

func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return
	_t += delta
	_attack_cd = maxf(_attack_cd - delta, 0.0)
	if not is_on_floor():
		velocity.y -= PhysicalWorldSystem.STANDARD_GRAVITY * delta
	if global_position.y < -40.0:
		global_position = home + Vector3(0, 2, 0)
		velocity = Vector3.ZERO

	var player: Node3D = GameManager.player
	var player_alive: bool = player != null and not (player.get("health") != null and player.health.is_dead)
	var to_player := Vector3.ZERO
	var dist: float = 999.0
	if player_alive:
		to_player = player.global_position - global_position
		to_player.y = 0.0
		dist = to_player.length()

	var wish := Vector3.ZERO
	var speed: float = 0.0
	match state:
		State.IDLE:
			_wander_timer -= delta
			if _wander_timer <= 0.0:
				_wander_timer = randf_range(1.5, 3.5)
				var to_home: Vector3 = home - global_position
				to_home.y = 0.0
				if to_home.length() > 8.0:
					_wander_dir = to_home.normalized()
				elif randf() < 0.45:
					_wander_dir = Vector3.ZERO
				else:
					var a: float = randf() * TAU
					_wander_dir = Vector3(cos(a), 0, sin(a))
			wish = _wander_dir
			speed = 1.1
			if dist < aggro_range:
				state = State.CHASE
		State.CHASE:
			if dist > leash_range or not player_alive:
				state = State.IDLE
			elif dist < 1.7 and _attack_cd <= 0.0:
				state = State.WINDUP
				_windup = 0.5
			else:
				wish = to_player.normalized() if dist > 1.3 else Vector3.ZERO
				speed = 3.3
		State.WINDUP:
			_windup -= delta
			if player_alive:
				wish = Vector3.ZERO
			if _windup <= 0.0:
				if player_alive and dist < 2.3 and player.has_method("take_damage"):
					player.take_damage(damage, self)
					if player.has_method("apply_knockback"):
						player.apply_knockback(to_player.normalized() * 6.0)
					VFX.burst(self, global_position + Vector3(0, 0.6, 0) + to_player.normalized() * 0.9, slime_color, 8, 3.0, 0.05)
				_attack_cd = 1.3
				state = State.CHASE

	velocity.x = lerpf(velocity.x, wish.x * speed, clampf(delta * 8.0, 0.0, 1.0))
	velocity.z = lerpf(velocity.z, wish.z * speed, clampf(delta * 8.0, 0.0, 1.0))
	move_and_slide()
	_moving = lerpf(_moving, clampf(Vector2(velocity.x, velocity.z).length() / 3.0, 0.0, 1.0), clampf(delta * 6.0, 0.0, 1.0))

	var look: Vector3 = to_player if state != State.IDLE and dist < 900.0 else Vector3(velocity.x, 0, velocity.z)
	if look.length() > 0.1:
		_visual.rotation.y = lerp_angle(_visual.rotation.y, atan2(-look.x, -look.z), clampf(delta * 8.0, 0.0, 1.0))
	_animate(delta)

func _animate(_delta: float) -> void:
	var idle: float = sin(_t * 2.6) * 0.04
	var hop: float = absf(sin(_t * 6.5)) * _moving
	var sq: float = 1.0 + idle - hop * 0.18
	var hop_y: float = hop * 0.28
	if state == State.WINDUP:
		var k: float = 1.0 - clampf(_windup / 0.5, 0.0, 1.0)
		sq = 1.0 - 0.35 * sin(k * PI * 0.5)
		hop_y = 0.0
		_body_mat.emission_energy_multiplier = lerpf(0.25, 1.6, k)
	else:
		_body_mat.emission_energy_multiplier = lerpf(_body_mat.emission_energy_multiplier, 0.25, 0.2)
	_visual.scale = Vector3(1.0 / sqrt(sq), sq, 1.0 / sqrt(sq)) * _visual_size
	_visual.position.y = hop_y

func take_damage(amount: float, source: Node = null, crit: bool = false) -> void:
	if state == State.DEAD:
		return
	health.take_damage(amount, source)
	var dn: DamageNumber = DAMAGE_NUMBER_SCENE.instantiate()
	get_tree().current_scene.add_child(dn)
	dn.global_position = global_position + Vector3(0, 1.8 * _visual_size, 0)
	dn.setup(amount, crit)
	VFX.burst(self, global_position + Vector3(0, 0.6, 0), slime_color.lightened(0.3), 10, 4.0, 0.05)
	_body_mat.emission_energy_multiplier = 2.5
	if source is Node3D and state != State.DEAD:
		var away: Vector3 = global_position - (source as Node3D).global_position
		away.y = 0.0
		velocity += away.normalized() * 4.5
		velocity.y = 3.0
		state = State.CHASE
	EventBus.entity_damaged.emit(self, amount, source)

func _on_health_changed(current: float, maximum: float) -> void:
	if label:
		label.text = "Slime  %d/%d" % [int(ceil(current)), int(maximum)]
		label.modulate = Color(0.6, 1.0, 0.6).lerp(Color(1.0, 0.35, 0.3), 1.0 - clampf(current / maximum, 0.0, 1.0))

func _on_died(source: Node) -> void:
	state = State.DEAD
	remove_from_group("enemy")
	$CollisionShape3D.set_deferred("disabled", true)
	EventBus.entity_died.emit(self)
	VFX.burst(get_parent(), global_position + Vector3(0, 0.5, 0), slime_color, 26, 6.0, 0.08)
	# Rewards: skill training, loot, quest progress
	PlayerData.stats["kills"] = int(PlayerData.stats["kills"]) + 1
	var sg = get_tree().get_first_node_in_group("settlement_growth")
	if sg and sg.has_method("add_progress"):
		sg.add_progress("elyndor", 1.0)

	PlayerData.notify("kill", "slime", 1)
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.server_record_quest_event_for_active_peer("kill", "slime")
	if source and source.get("skills") != null:
		source.skills.train("swordsmanship", 0.4)
	var table: LootTable = LootTable.slime()
	var gold_reward := table.roll_gold()
	if MMORPGNetwork.is_online() and multiplayer.is_server():
		MMORPGNetwork.grant_gold_to_combat_peer(gold_reward)
	else:
		PlayerData.add_gold(gold_reward)
	for d in table.roll():
		if MMORPGNetwork.is_online() and multiplayer.is_server():
			LootDrop.spawn_at(get_parent(), global_position, str(d["id"]), int(d["count"]))
		elif randf() < 0.35:
			LootDrop.spawn_at(get_parent(), global_position, str(d["id"]), int(d["count"]))
		else:
			PlayerData.add_item(str(d["id"]), int(d["count"]))
	label.visible = false
	var tw: Tween = create_tween()
	tw.tween_property(_visual, "scale", Vector3(1.5, 0.05, 1.5), 0.3).set_ease(Tween.EASE_IN)
	tw.tween_callback(queue_free)
