extends Area3D
var opened: bool = false
func can_interact() -> bool: return not opened
func get_prompt() -> String: return "Open forgotten cache" if not opened else "Empty cache"
func interact(player: Node3D = null) -> void:
	if opened: return
	opened = true
	var floor_i: int = int(get_meta("floor", 0))
	var dungeon = get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.mark_discovery(floor_i, "cache")
	var wisdom: float = player.skills.get_value("wisdom") if player and player.get("skills") != null else 0.0
	var knowledge: float = player.skills.get_value("knowledge") if player and player.get("skills") != null else 0.0
	var lore: float = player.skills.get_value("ancient_lore") if player and player.get("skills") != null else 0.0
	var band: int = int(floor_i / 10)
	var rewards_by_band: Array = [
		["bone", "chitin", "ectoplasm", "iron_ore", "healing_potion"],
		["spore_sac", "moonpetal", "chitin", "mana_crystal", "healing_potion"],
		["prism_shard", "mana_crystal", "moonstone_ore", "rune_fragment"],
		["rune_fragment", "forgotten_essence", "iron_ore", "mana_crystal"],
		["cinder_core", "dragonbone", "forgotten_essence", "mana_crystal"],
		["moonstone_ore", "ancient_scale", "mana_crystal", "rune_fragment"],
		["drowned_sigil", "serpent_scale", "pearl", "ancient_scale"],
		["voidsilk", "abyssal_chitin", "runebound_core", "heart_of_depths"],
		["abyssal_relic", "runebound_core", "heart_of_depths", "forgotten_essence"],
		["heart_of_depths", "abyssal_relic", "runebound_core", "ancient_scale"]
	]
	var band_rewards: Array = rewards_by_band[mini(band, rewards_by_band.size() - 1)]
	var item_id: String = str(band_rewards[randi_range(0, band_rewards.size() - 1)])
	var rare_chance: float = clampf(0.035 + float(floor_i) * 0.001 + knowledge * 0.0008 + lore * 0.0015 + wisdom * 0.0005, 0.035, 0.28)
	if randf() < rare_chance:
		var rare_pool: Array[String] = ["forgotten_essence", "runebound_core", "abyssal_relic", "heart_of_depths"]
		item_id = rare_pool[mini(band, rare_pool.size() - 1)]
	var amount: int = 1 + int(floor_i / 20) if item_id in ["bone", "chitin", "ectoplasm", "iron_ore", "spore_sac"] else 1

	var item_grade: int = clampi(int(floor_i / 25) + int((knowledge + lore) / 35.0), 0, 5)
	PlayerData.add_item(item_id, amount, item_grade)
	PlayerData.add_gold(randi_range(8, 18) + floor_i * 2)
	if player and player.get("skills") != null:
		player.skills.train("dungeon_delving", 1.1)
		player.skills.train("exploration", 0.55)
		player.skills.train("knowledge", 0.45)
		player.skills.train("wisdom", 0.25)
		player.skills.train("observation", 0.35)
	EventBus.toast.emit("Forgotten cache discovered!", "levelup")
	EventBus.activity.emit("Found a hidden dungeon cache", "loot")
	for child in get_children():
		if child is OmniLight3D: child.queue_free()
		if child is MeshInstance3D: child.visible = false
