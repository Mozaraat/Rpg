extends Area3D

var solved: bool = false
var _sequence: Array[int] = []
var _step: int = 0
var _active: bool = false

func _ready() -> void:
	var floor_i: int = int(get_meta("floor", 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = int(GameManager.world_seed) + floor_i * 1877 + 41
	for i in range(3):
		_sequence.append(rng.randi_range(1, 4))

func can_interact() -> bool:
	return not solved

func get_prompt() -> String:
	return "Solve runic sequence (1-4)" if not solved else "Secret passage opened"

func interact(player: Node3D = null) -> void:
	if solved:
		return
	_active = true
	var hint: String = ""
	for rune in _sequence: hint += str(rune) + " "
	EventBus.toast.emit("Runic puzzle: press %s in order (1-4)." % hint.strip_edges(), "info")

func _unhandled_key_input(event: InputEvent) -> void:
	if solved or not _active or not event is InputEventKey or not event.pressed or event.echo:
		return
	var pressed: int = -1
	match event.keycode:
		KEY_1: pressed = 1
		KEY_2: pressed = 2
		KEY_3: pressed = 3
		KEY_4: pressed = 4
	if pressed < 0: return
	if pressed == _sequence[_step]:
		_step += 1
		if _step < _sequence.size():
			EventBus.toast.emit("Rune accepted: %d / 3" % _step, "info")
			return
		_complete_puzzle()
	else:
		_step = 0
		EventBus.toast.emit("Wrong rune. The sequence resets.", "warning")

func _complete_puzzle() -> void:
	if solved:
		return
	solved = true
	var floor_i: int = int(get_meta("floor", 0))
	var alcove: Node3D = get_meta("hidden_alcove_node", null) as Node3D
	if alcove and is_instance_valid(alcove):
		var alcove_transform: Transform3D = alcove.global_transform
		alcove.reparent(get_parent())
		alcove.global_transform = alcove_transform
		alcove.visible = true
		VFX.burst(get_parent(), global_position + Vector3(0, 1.0, -3.0), Color(0.55, 0.32, 1.0), 30, 6.0, 0.08)
	var dungeon = get_tree().get_first_node_in_group("dungeon")
	if dungeon and dungeon.has_method("mark_discovery"):
		dungeon.mark_discovery(floor_i, "secret")
	var player: Node3D = GameManager.player
	var reward: String = "rune_fragment" if floor_i < 30 else "mana_crystal"
	PlayerData.add_item(reward, 1 + int(floor_i / 35))
	PlayerData.add_gold(20 + floor_i * 3)
	PlayerData.add_item("forgotten_essence" if floor_i >= 40 else "rune_fragment", 1 + int(floor_i / 30))
	if player and player.get("skills") != null:
		player.skills.train("dungeon_delving", 2.0)
		player.skills.train("arcane_attunement", 0.8)
		player.skills.train("exploration", 1.0)
		player.skills.train("knowledge", 1.2)
		player.skills.train("wisdom", 0.9)
		player.skills.train("observation", 0.8)
		player.skills.train("ancient_lore", 1.1)
		CultivationDiscovery.record_clue("runic_secret_%d" % floor_i, "A sealed runic chamber", "The lock's construction reveals a pattern beyond ordinary enchantment.")
		# Solving the runic lock exposes an old combat lesson. The lesson is
		# matched to the player's practiced weapon rather than granting a class.
		var practiced: Array[String] = ["swordsmanship", "dagger_mastery", "axe_mastery", "spear_mastery", "blunt_mastery", "archery"]
		var best_skill: String = ""
		var best_value: float = 0.0
		for sid in practiced:
			var value: float = player.skills.get_value(sid)
			if value > best_value:
				best_value = value
				best_skill = sid
		var lesson_by_skill: Dictionary = {"swordsmanship":"cleave", "dagger_mastery":"shadow_flurry", "axe_mastery":"sundering_chop", "spear_mastery":"piercing_thrust", "blunt_mastery":"groundbreaker", "archery":"piercing_shot"}
		if best_skill != "" and best_value >= 3.0:
			player.skills.discover_technique(str(lesson_by_skill.get(best_skill, "")), "technique etched behind the runic seal")
	EventBus.toast.emit("Runic seal solved! A hidden cache has been revealed.", "levelup")
	EventBus.activity.emit("Solved an ancient dungeon puzzle", "exploration")
	visible = false
	set_deferred("monitoring", false)
	_active = false
