# Eternal Realms — Threaded Biome Ecology Pass

## Implemented

- Added a dedicated `RegionalEcologyWorker` (`RefCounted`) and a single reusable `Thread` in `LivingEcosystem`.
- The worker receives a deep-copied dictionary snapshot and returns a new snapshot. It does not access `SceneTree`, Nodes, rendering, physics, Resources, or live mutable game state. Main-thread polling applies completed results and persists them.
- Authoritative regional ecology can continue while the server is in the playing state even when there is no local player. Visual-only effects remain gated behind a local player.
- Added 32 regional fauna definitions with biome compatibility, carrying capacity, reproduction rate, lifespan, baseline strength, and predator/prey relationships.
- Regional fauna now cover ocean, beach, plains, forest, hills, mountain, snow, swamp, desert, autumn woodland, volcanic, rainforest, jungle, taiga, tundra, savanna, and Mediterranean biomes.
- Added coarse world-grid ecology cells across the authored world envelope, in addition to named region anchors. Unloaded cells continue to simulate as population cohorts.
- Added seasonal migration between compatible biome regions, predator pressure, maturation, senescence, hunting pressure, and a regional wildlife-pressure score.
- Legacy saved generic deer/boar/wolf cohorts are migrated to the new regional species identifiers without discarding their counts.
- Hunting carcasses are queued as regional harvest pressure and applied after the worker returns, avoiding races with the worker snapshot.
- Active visible wildlife gains age and a species-specific physical-strength value as it matures. `Critter.get_combat_strength()` exposes that value for combat/AI integration.
- Active visible populations can reproduce and create juveniles, with a strict juvenile cap. Their scale and strength grow as they mature.
- Wildlife spawn density now responds to regional population pressure. Unmanaged populations can produce denser local encounters; hunting pressure reduces regional cohorts over subsequent ticks.
- Added capped ambient fish schools around loaded water using the existing `MarineFish` entity. Long-term fish counts remain part of regional ecology.
- Expanded the visible wildlife species table so land biomes spawn their matching fauna.

## Geography preserved

The existing terrain classifier already distinguishes foothills/hills, mountain terrain, and high cold snow/ice peaks by elevation and climate. Existing Ironback and Frostveil uplift profiles create ridge chains, massif peaks, passes, and approach trails. This pass preserves that terrain logic rather than replacing it with random mountain placement.

## Important boundaries

- Regional fauna are still aggregate population cohorts, not individually persistent animal records across server restarts.
- The visible wildlife system remains deliberately capped around loaded players; it does not instantiate every animal in every region.
- Several fauna currently share the existing procedural critter body archetypes and colour/scale variations; fully bespoke models, animations, and species-specific combat abilities remain a visual/gameplay pass.
- Aquatic regional species are simulated, while the current ambient-water renderer spawns fish schools. Marine mammals and large ocean predators do not yet have bespoke visible entities.
- `get_combat_strength()` exposes maturity strength, but all combat damage/armor systems have not yet been wired to consume it.
- The regional worker is threaded. Hydrology's shallow-water solver and terrain mesh/collision updates remain on their existing main-thread paths; moving those requires separate immutable worker snapshots and main-thread result application.
- Wildlife pressure is exposed to the habitat director and increases local encounter density. Full settlement crop loss, livestock attacks, and regional predator raids are not yet wired to the pressure value.

## Validation

- ZIP integrity and source-level delimiter checks are performed for this pass.
- No Godot 4.7 executable or GDScript linter is available in this environment. Engine parsing, scene startup, threaded runtime behaviour, multiplayer replication, and live PostgreSQL persistence therefore remain unverified and must be tested in Godot 4.7.
