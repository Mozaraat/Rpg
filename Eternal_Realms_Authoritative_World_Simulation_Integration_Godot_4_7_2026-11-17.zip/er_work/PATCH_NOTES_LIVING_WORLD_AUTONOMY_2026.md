# Living World Autonomy Pass — 2026

## Changes

- Merchant NPCs now build a visible physical stall with timber counter, striped canopy, displayed goods and sign. The stall opens from 07:00 until 18:30 game time and folds out of view outside business hours or while the merchant sleeps.
- Trade caravans now have visible moving cart-and-cargo models that follow the same route positions used by the existing caravan simulation and map markers. They are removed when the journey completes. Farmers and merchants can visibly carry small crates during their work routines.
- Hunter job routines now leave temporary, visible tracking prints and a snare with a creature trigger. When wildlife enters it, the animal becomes a visible carcass, the hunter returns toward its home area, and Elyndor receives a small settlement-growth contribution.
- Predatory field monsters (wolves, hounds and lynx) can select nearby rabbit, deer, boar and chicken wildlife as prey while idle. They pursue within their home territory; a caught animal becomes a visible carcass. Player detection interrupts hunting so normal combat remains responsive.
- Dungeon civilization remnants now include more room-level evidence: exposed ancient clockwork gears and collapsed masonry, alongside existing banners, archive furniture, offerings and ancestor reliefs.

## Preservation

- Existing NPC schedules, business inventory persistence, settlement growth, caravan route progression, monster combat and dungeon generation remain the source systems.
- The additions are local scene visuals and bounded AI behaviour; they do not create a parallel economy, quest system or multiplayer authority model.
- Monster prey selection runs in the existing monster physics loop and only on the authoritative simulation side when online.

## Validation limits

- Archive integrity and static resource-path checks are performed after packaging.
- Godot 4.7 editor parsing, scene import, runtime AI, navigation/collision, multiplayer replication and performance profiling require an actual Godot 4.7 run and are not claimed as verified here.
