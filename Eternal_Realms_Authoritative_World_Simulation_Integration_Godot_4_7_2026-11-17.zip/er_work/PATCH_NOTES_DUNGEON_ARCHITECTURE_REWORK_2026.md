# Eternal Realms — 2026 Dungeon Architecture Rework

## Visual and spatial changes

- Added a civilization heart monument to the central hall of every floor. Each of the ten ten-floor cultures receives a distinct focal structure: Gilded Concord oath obelisk, Verdant Choir root-heart, Prism Enclave crystal shrine, Sepulchral Court royal tomb, Cinder Dominion forge core, Glacial Monastery mirror shrine, Thalassian tidal sanctuary, Worldroot nexus, Starless menhir and Astral Archive orrery.
- Added concentric floor inlays, radial sigils and a readable civilization title around the central landmark.
- Replaced the former stacked-cube column dressing with tapered octagonal columns, moulded bases, necks and capitals.
- Added segmented vaulted ribs over the central hall and final guardian chamber to create a stronger sense of architectural scale.
- Added selected civilization passage frames to punctuate longer routes without replacing or altering the maze's underlying links.
- Added a dedicated guardian arena with floor seals, radial marks, four perimeter pylons and a focused local light. The boss now spawns in the centre of that arena; the descent gate remains on the approach side.
- Raised the dungeon's ambient fill slightly and shifted it toward the civilization's stone palette so wall, floor and architectural surfaces remain more readable while preserving the individual glow colour.

## Dungeon map

- Reworked the floor map with a framed dark-stone panel, distinct start and boss chamber tints, a highlighted central hall, readable open passages, thicker sealed-wall lines and a clearer player marker.

## Gameplay preservation

- Kept the 100-floor structure, seeded maze generation, existing maze links, floor boss/death gate logic, floor content, discoveries, hazards, caches, shrines, checkpoints and civilization trial systems.
- The boss spawn was moved from the goal cell into the centre of the existing final 2×2 chamber footprint to align with the new arena dressing. The descent portal stays in its existing goal-cell location.
- No new collision walls were added across traversable routes. The set-piece additions are visual dressing; existing wall and floor collision foundations remain the authoritative navigation boundaries.

## Validation performed

- ZIP CRC/integrity check.
- Fixed `res://` resource reference scan.
- Duplicate global `class_name` scan.
- Delimiter/string balance checks on the modified GDScript files.
- Indentation check on modified scripts.

## Not verified in this environment

- Godot 4.6 is not installed here. The project has not been imported, parsed by the Godot engine, rendered or play-tested in-engine.
- Light balance, shader/material appearance, camera framing, collision feel, boss movement around arena dressing and performance need in-game QA.
