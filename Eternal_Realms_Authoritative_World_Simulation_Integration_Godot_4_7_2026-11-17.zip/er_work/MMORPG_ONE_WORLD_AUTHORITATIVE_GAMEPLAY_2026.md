# Eternal Realms — One-World Authoritative Multiplayer Gameplay

## World policy

Eternal Realms is designed as **one persistent logical game world**. The network handshake uses the fixed world identity `eternal-realms-one-world`; clients do not select a shard, realm copy, channel or parallel world. Every connected player joins the same authoritative world state and can encounter the same players, NPCs, monsters, loot and party members.

The current prototype runs one ENet authoritative world process (UDP 24560, prototype connection cap 128). It does not create instanced world copies. A future production deployment may distribute backend services or stream regions across coordinated compute processes, but those processes must continue to serve the same world identity and shared simulation; they must not become separate player populations or duplicate world instances.

## Implemented in this milestone

- Persistent local character identity (`user://mmorpg_identity.json`) with a stable character ID and display name.
- Server-side character snapshot storage, loaded on re-entry and periodically updated. Snapshots include position, health, skill values, cultivation state, inventory, equipment and currency.
- Single-world identity handshake and rejection of clients attempting to join a different world identity; duplicate simultaneous character IDs are rejected.
- Server-validated movement proposals with speed/distance bounds and replicated remote player transforms.
- Remote player avatars now use the project's procedural `CharacterModel` instead of a placeholder capsule. Their position and movement animation are replicated.
- Client melee and elemental combat requests are resolved against server-side enemy entities with server-side range, facing, cooldown and damage bounds. Enemy health/death is replicated to clients.
- Cultivation intent is checked by the server against accepted player position and stillness. Spiritual-energy regeneration and periodic cultivation rewards are issued by the server.
- Server-controlled health for remote players, including enemy damage and server-side passive recovery.
- Server-side NPC/monster movement snapshots; clients suspend NPC/monster physics AI and display the server's snapshots.
- Monster loot is spawned by the server as shared world loot. Pickup requests are distance-checked and item/currency grants are sent by the server.
- Multiplayer party creation, invitations, acceptance, leave and party-state broadcast, with a five-member party limit.
- Dedicated server command-line startup (`-- --server`) enters the main world scene without a local player avatar.

## Test instructions

1. Run one instance as the dedicated server using Godot 4.7.2 headless mode and user arguments `--server`.
2. Run clients and connect to the server's address on UDP port `24560` (or host from one normal client for a local LAN test).
3. All clients must use the same project build and therefore the same fixed world identity.
4. Confirm player nameplates/models, movement, enemy health changes, shared loot pickup, cultivation and party invitations.

For local testing, host on one game instance and join `127.0.0.1:24560` from another. Internet access requires a reachable server address and UDP port configuration.

## Important prototype boundaries

- This is not yet a production MMO account/authentication service. Character IDs are locally generated identifiers, not secure account credentials; production needs authenticated accounts, secure sessions and server-issued identity tokens.
- Character snapshots currently use server-local JSON files through the existing persistence adapter. Production needs a transactional database, backups, schema migration and crash-safe write strategy.
- Character snapshots are client-submitted and server-owned by identity, but their progression fields are not yet fully reconstructed from authoritative server-side character objects. Anti-cheat validation and server-side inventory/equipment/progression ownership remain required.
- World NPC/monster snapshots currently resolve entities by matching scene NodePaths. Production entity replication needs stable server-issued entity IDs, interest management, spawn/despawn replication and region-aware relevance filtering.
- Combat is a first server-resolution pass: melee/elemental hits are checked against server-side enemy positions and cooldown/range bounds, but full weapon/technique simulation, projectile simulation, status effects, PvP rules, latency compensation and exploit-resistant stat calculation remain future work.
- NPC movement is server-driven for clients, but NPC dialogue, trading, quests, gathering, faction diplomacy and all world interactions still need server RPC validation and persistence.
- Parties are authoritative for the current session but not yet persisted across restarts. Party loot rules, raid groups, guilds and cross-region social systems are future work.
- The prototype cap of 128 is a configuration limit, not a measured capacity claim. No concurrency or load test has been run.

## Production architecture direction

Keep one public world identity and one shared economy/history. Use an authoritative world simulation with coordinated region ownership and service processes only when load requires it. Do not solve scaling by creating separate copies of Elyndor or separate player populations. Persist player, NPC, faction, territory, dungeon, market and event state centrally; use interest management to replicate only nearby/relevant entities to each client.
