# Dynamic Exploration, Settlement Safety and NPC Society — Godot 4.7

## Implemented

- Increased the overworld slime spawner's minimum distance from Elyndor and the Arcane Spire; removed the special near-player initial spawn so it cannot bypass settlement protection.
- Added a settlement protection radius to monster target selection. Monsters now prefer isolated NPCs and travellers outside protected settlement areas rather than dragging ordinary residents into nearby wilderness combat.
- Added health to NPCs and server-authoritative damage handling.
- Armed professions (guards, soldiers, rangers, hunters, adventurers and mercenaries) defend themselves against nearby hostile entities. Unarmed civilians flee. Civilians who survive repeated attacks can transition into the adventurer profession, receive a changed appearance and persist that profession.
- NPC casualties are recorded in the living-world state.
- Added persistent NPC life records, autonomous marriage formation between eligible nearby adults, household records and child births over in-world days.
- Children are created as visible NPC residents, saved in household records and replicated to connected players with late-join snapshots.
- Added persistent family dialogue that can report a resident's partner and children.
- Wildlife leaves temporary physical tracks. Predatory monsters can inspect fresh tracks, investigate their direction and then acquire nearby prey.
- Cave entrances are no longer globally advertised. Their markers and names reveal only when a player approaches, with a nearby environmental clue.

## Important design boundaries

- The current family simulation is a first persistent society layer. It does not yet model full courtship dialogue, consent/compatibility preferences, pregnancy stages, child schooling, inheritance, aging into adult NPCs, or a complete family housing/economy simulation.
- Child residents currently remain children; age is recorded and advances by in-world days, but age-based adult conversion and new career paths for grown children are not yet implemented.
- NPC adventurer progression is a first combat-survival pathway. It does not yet provide a complete adventurer guild, contracts, parties, equipment loadouts, tactical formations or expedition progression.
- Monsters are restricted from selecting NPCs inside the configured settlement protection radius. This is not yet a full regional monster-density director or a guarantee against every separately scripted boss/faction encounter.
- Wildlife tracks are local visual evidence and predators can follow fresh tracks in the same simulation instance. Track persistence across server restarts is not implemented.
- Dynamic child NPC replication and late-join snapshots are implemented through the existing world-entity replication path; live multi-client testing remains outstanding.

## Validation

- Static delimiter scan: no findings in modified scripts.
- Duplicate top-level GDScript function scan: no findings in modified scripts.
- Literal `res://` reference scan and ZIP integrity are checked in the build report.
- Godot 4.7 executable was not available, so engine parsing, scene launch, combat behaviour and multiplayer runtime have not been verified in-engine.
