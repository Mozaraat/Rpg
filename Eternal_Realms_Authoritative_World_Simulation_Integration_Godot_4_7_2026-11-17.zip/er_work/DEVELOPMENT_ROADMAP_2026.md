# Eternal Realms — 2026 Development Roadmap

## Product direction

Eternal Realms is being developed as a systemic open-world action RPG and life simulation. The goal is not a larger checklist of disconnected features. The goal is a world where exploration, combat, professions, settlements, cultivation, wildlife, crafting and dungeon progression continuously affect one another.

The current project is a playable foundation with many systems already present. It is not yet a finished AAA production. The roadmap below defines the order in which the foundation should be turned into a coherent, polished game.

## Production pillars

1. **World that makes sense** — A readable world atlas with landmasses, watersheds, mountain chains, biome transitions, settlements, roads and landmarks. Shared terrain data must drive rendering, navigation, resource placement, wildlife habitat and discovery. Finish one benchmark region before expanding the world.
2. **Believable environmental presentation** — Authored terrain silhouettes, grounded props, correct scale, slope-aware placement and consistent materials. Rivers need connected source-to-mouth paths, lakes real shorelines, and waterfalls a visible source, falling sheet and plunge pool. Lighting, atmosphere and weather must remain readable and performant.
3. **Living ecology** — Species defined by habitat, activity window, diet, threat response and resource drops. Build predator/prey interactions, territory, population recovery and seasonal variation. Hunting and gathering should leave readable traces in the world.
4. **People and settlements** — Named NPCs with schedules, work roles, relationships, needs and memory of meaningful player actions. Settlement prosperity should respond to supplies, safety, trade, quests and regional threats.
5. **Hands-on professions and combat** — Fishing, hunting, gathering, cooking, smithing, alchemy and cultivation as skill-based activities. Material quality and tool choice should matter. Weapon choice stays open while practice and mastery create build identity. Combat must respect line of sight, collision, telegraphs, stagger and defence.
6. **Exploration-to-dungeon progression** — Exploration reveals resources, routes, lore, hazards and preparation opportunities. Regional quests unlock knowledge and access. Dungeon floors introduce distinct cultures, mechanics, enemies, hazards and rewards that feed back into the world.

## Milestone sequence

### M1 — Stable foundation and project health
- Resolve parser errors, missing resources, invalid node paths and broken autoload dependencies.
- Add repeatable static checks and a documented in-engine smoke-test route.
- Preserve a known-good archive after each verified milestone.

### M2 — Elyndor Heartlands vertical slice
- Polish one connected region from village to forest, basin, foothills and dungeon approach.
- Complete its exploration, hunting, gathering, fishing, crafting, NPC, quest and combat loop.
- Validate save/load, collision, navigation and progression in Godot.
- Use the Field Journal to communicate regional progress and expedition readiness.

### M3 — Combat and creature intelligence
- Improve enemy archetypes, telegraphs, group behaviour, line-of-sight and hit validation.
- Distinguish huntable fauna from hostile monsters.
- Balance encounters around player choices, not one mandatory weapon or skill rotation.

### M4 — Settlement simulation and economy
- Connect NPC schedules, local production, supply, services, regional danger and settlement growth.
- Add trade and crafting demand loops with meaningful material sinks.
- Ensure quest and settlement state survive save/load.

### M5 — World scale and regional expansion
- Expand to additional continents only after M2 passes its quality gate.
- Reuse the same environmental, ecological, interaction and quest standards.
- Keep each region visually and culturally distinct while preserving shared system rules.

### M6 — Dungeon civilizations and endgame
- Develop floor groups as distinct architectural and mechanical civilizations.
- Add boss mechanics, puzzles, environmental hazards, lore and rewards that change play.
- Test floor transitions, checkpoints, death/recovery and return-to-world progression.

### M7 — Production polish
- Profile CPU/GPU, memory, draw calls, streaming and save performance.
- Improve accessibility, input remapping, settings, UI scale and controller support.
- Add QA passes for edge cases, save migration and long-session stability.

## Quality gates

A milestone is not complete merely because scripts or assets were added.

- **Static gate:** no duplicate global classes/functions, no broken resource references, no parser errors.
- **Runtime gate:** project imports and launches in the target Godot version with no recurring runtime errors.
- **Gameplay gate:** the complete feature loop can be played from start to finish and behaves correctly after save/load.
- **Visual gate:** in-game movement confirms grounded geometry, coherent composition, readable effects and consistent art direction.
- **Performance gate:** representative scenes meet agreed frame-time and memory targets on target hardware.
- **Regression gate:** combat, inventory, quests, professions, swimming/fishing and dungeon systems still work.

## Current milestone status

- Existing combat, inventory, quests, professions, cultivation, settlement and dungeon foundations retained.
- Elyndor regional director and field journal system are present.
- This follow-up adds a dedicated in-game Field Journal tab (`L`) with regional counters, milestone status, discovered regions and per-item activity records.
- Static source and resource-reference checks have been run for this archive.
- Godot 4.7.2 is not installed in the build environment. Engine import, parser validation, rendering, physics and end-to-end gameplay remain unverified and are not claimed as complete.

## November 2026 — Mortal-first dual progression

Cultivation is now specified as an ultra-rare, earned discovery rather than a character-creation option or guaranteed level unlock. The first implementation adds clue collection, recognition eligibility, separate comprehension/willpower checks, a compatibility check, legitimate method recording, and locked-state UI. Traditional RPG progression remains available to every character. See `DESIGN_PILLARS_DUAL_PROGRESSION_DISCOVERY.md` and `PATCH_NOTES_RARE_CULTIVATION_DISCOVERY_GODOT_4_7_2026.md`.

Remaining work: author bespoke master/inheritance trials; complete authoritative remote-player discovery validation; deepen mortal endgame and verify every cultivation reward path.
