# EventBus - Decoupled communication between systems
# Real Coder: Prefer signals over direct references
extends Node

# Player events
signal player_aged(new_age: float, old_age: float)
signal player_died(cause: String)
signal player_leveled_skill(skill_name: String, new_level: int)

# World events
signal chunk_loaded(chunk_pos: Vector2i)
signal biome_changed(new_biome: String)
signal day_night_changed(is_day: bool)

# Combat events
signal entity_damaged(target: Node, amount: float, source: Node)
signal entity_died(entity: Node)

# Interaction
signal interaction_available(interactable: Node)
signal interaction_cleared()
signal interaction_started(interactable: Node)

# UI feedback ("Game saved", "Sword Lv.2!" ...)
signal toast(text: String, kind: String)

# Activity log lines (loot, skills, quests...) shown bottom-right like an MMO chat feed
signal activity(text: String, kind: String)
signal zone_entered(zone_name: String, first_time: bool)
