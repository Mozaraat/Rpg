# GameManager - Central state and lifecycle
extends Node

enum GameState { MENU, PLAYING, PAUSED, DEAD }

var current_state: GameState = GameState.MENU
var player: CharacterBody3D = null
var world_seed: int = 42
var pending_load_game: bool = false
var pending_new_game_save: bool = false

# Time system (for aging)
var game_time_seconds: float = 0.0
var time_scale: float = 1.0  # 1 real second = 1 game second at scale 1

# UI panels (dialogue, skills...) take a "lock" so the player stops moving/attacking
var _ui_locks: int = 0
var input_locked: bool:
	get:
		return _ui_locks > 0 or current_state == GameState.DEAD

func _ready() -> void:
	print("[GameManager] Initialized - Eternal Realms Foundation")
	current_state = GameState.PLAYING

func _process(delta: float) -> void:
	if current_state == GameState.PLAYING:
		game_time_seconds += delta * time_scale

func register_player(p: CharacterBody3D) -> void:
	player = p
	_ui_locks = 0
	current_state = GameState.PLAYING
	print("[GameManager] Player registered")

func push_ui_lock() -> void:
	_ui_locks += 1

func pop_ui_lock() -> void:
	_ui_locks = maxi(_ui_locks - 1, 0)

func set_dead() -> void:
	current_state = GameState.DEAD

func get_game_time_years() -> float:
	# Rough conversion for prototyping. Tune later.
	# 1 real second = 0.0001 game years -> ~1 real hour = 0.36 game years
	return game_time_seconds * 0.0001
