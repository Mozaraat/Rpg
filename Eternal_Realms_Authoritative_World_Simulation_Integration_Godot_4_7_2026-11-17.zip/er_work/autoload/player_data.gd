# PlayerData - everything the player owns and has done: inventory, equipment, gold,
# quests, titles, discovered zones. (An autoload, so no class_name.)
extends Node

signal inventory_changed
signal equipment_changed
signal gold_changed(gold: int)
signal quests_changed
signal title_changed

const SLOT_COUNT: int = 28

var slots: Array = []
var equipment: Dictionary = {"weapon": {}, "armor": {}}
var gold: int = 0
var authoritative_item_instance_ids: Dictionary = {} # inventory slot -> server UUID; never synthesized locally
var _last_network_heal_request_at: float = -1.0
var quests: Dictionary = {}          # id -> {"state": "active"|"done", "progress": [int]}
var titles: Array = []
var active_title: String = ""
var zones: Array = []
var stats: Dictionary = {"kills": 0, "crafted": 0, "gathered": 0, "archaeology": 0, "tracks_studied": 0, "marine_observations": 0, "starter_farm_pack": true}

func _ready() -> void:
	reset_new_game()

func _is_production_remote_client() -> bool:
	var deployment_guard: Node = get_node_or_null("/root/WorldDeploymentGuard")
	var network: Node = get_node_or_null("/root/MMORPGNetwork")
	if not is_instance_valid(deployment_guard) or not is_instance_valid(network):
		return false
	return bool(deployment_guard.call("is_production_session")) and bool(network.call("is_online")) and not multiplayer.is_server()

func apply_authoritative_inventory_snapshot(snapshot: Dictionary) -> void:
	var incoming: Variant = snapshot.get("items", [])
	if not incoming is Array:
		return
	slots = []
	for _index in range(SLOT_COUNT):
		slots.append({})
	authoritative_item_instance_ids.clear()
	var item_by_instance: Dictionary = {}
	for row_variant in incoming:
		if not row_variant is Dictionary:
			continue
		var row: Dictionary = row_variant
		var item_id := str(row.get("item_definition_id", ""))
		if not ItemDB.has_item(item_id):
			continue
		var item_state: Dictionary = row.get("item_state", {}) if row.get("item_state", {}) is Dictionary else {}
		var instance := ItemDB.make(item_id, int(row.get("quantity", 1)), int(item_state.get("grade", 0)), float(item_state.get("durability", -1.0)))
		var slot_value: Variant = row.get("slot_index")
		if slot_value != null and int(slot_value) >= 0 and int(slot_value) < SLOT_COUNT:
			slots[int(slot_value)] = instance
			authoritative_item_instance_ids[int(slot_value)] = str(row.get("item_instance_id", ""))
		item_by_instance[str(row.get("item_instance_id", ""))] = instance
	var gear: Dictionary = {"weapon": {}, "armor": {}}
	for equipment_row in snapshot.get("equipment", []):
		if not equipment_row is Dictionary:
			continue
		var slot_id := str(equipment_row.get("slot_id", ""))
		var instance_id := str(equipment_row.get("item_instance_id", ""))
		if gear.has(slot_id) and item_by_instance.has(instance_id):
			gear[slot_id] = item_by_instance[instance_id].duplicate(true)
	equipment = gear
	gold = maxi(0, int(snapshot.get("gold", gold)))
	inventory_changed.emit()
	equipment_changed.emit()
	gold_changed.emit(gold)

func reset_new_game() -> void:
	slots = []
	for i in range(SLOT_COUNT):
		slots.append({})
	authoritative_item_instance_ids.clear()
	equipment = {"weapon": ItemDB.make("rusty_sword"), "armor": ItemDB.make("cloth_tunic")}
	gold = 25
	quests = {}
	titles = []
	active_title = ""
	zones = []
	stats = {"kills": 0, "crafted": 0, "gathered": 0, "archaeology": 0, "tracks_studied": 0, "marine_observations": 0, "starter_farm_pack": true}
	add_item("healing_potion", 2)
	add_item("fishing_rod", 1)
	add_item("wheat_seed", 6)
	add_item("carrot_seed", 4)
	add_item("berry_seed", 3)
	add_item("hay", 5)
	add_item("wood_log", 12)
	inventory_changed.emit()
	equipment_changed.emit()
	gold_changed.emit(gold)
	quests_changed.emit()
	title_changed.emit()

# ---------------------------------------------------------------------------
# Inventory
# ---------------------------------------------------------------------------
func item_at(i: int) -> Dictionary:
	if i < 0 or i >= slots.size():
		return {}
	return slots[i]

func count_item(id: String) -> int:
	var n: int = 0
	for s in slots:
		if not s.is_empty() and s["id"] == id:
			n += int(s["count"])
	return n

func free_slots() -> int:
	var n: int = 0
	for s in slots:
		if s.is_empty():
			n += 1
	return n

## Adds items. Returns how many could NOT be added (inventory full).
func add_item(id: String, count: int = 1, grade: int = 0, dur: float = -1.0, silent: bool = false) -> int:
	if _is_production_remote_client():
		return count
	if not ItemDB.has_item(id) or count <= 0:
		return count
	grade = clampi(grade, 0, ItemDB.GRADES.size() - 1)
	var remaining: int = count
	var stack_max: int = ItemDB.max_stack(id)
	if stack_max > 1:
		for s in slots:
			if remaining <= 0:
				break
			if not s.is_empty() and s["id"] == id and int(s["grade"]) == grade and int(s["count"]) < stack_max:
				var add: int = mini(stack_max - int(s["count"]), remaining)
				s["count"] = int(s["count"]) + add
				remaining -= add
	for i in range(slots.size()):
		if remaining <= 0:
			break
		if slots[i].is_empty():
			if stack_max > 1:
				var put: int = mini(stack_max, remaining)
				slots[i] = ItemDB.make(id, put, grade)
				remaining -= put
			else:
				slots[i] = ItemDB.make(id, 1, grade, dur)
				remaining -= 1
	var added: int = count - remaining
	if added > 0:
		inventory_changed.emit()
		if not silent:
			var inst: Dictionary = ItemDB.make(id, added, grade)
			EventBus.activity.emit("Received: %s%s" % [ItemDB.display_name(inst), (" x%d" % added) if added > 1 else ""], "loot")
		notify("collect", id, added)
		quests_changed.emit()
	if remaining > 0:
		EventBus.toast.emit("Inventory full!", "info")
	return remaining

func remove_item(id: String, count: int = 1) -> bool:
	if _is_production_remote_client():
		return false
	if count <= 0:
		return false
	if count_item(id) < count:
		return false
	var left: int = count
	for i in range(slots.size()):
		if left <= 0:
			break
		if not slots[i].is_empty() and slots[i]["id"] == id:
			var take: int = mini(int(slots[i]["count"]), left)
			slots[i]["count"] = int(slots[i]["count"]) - take
			left -= take
			if int(slots[i]["count"]) <= 0:
				slots[i] = {}
	inventory_changed.emit()
	return true

func discard_slot(i: int) -> void:
	if _is_production_remote_client():
		return
	if i >= 0 and i < slots.size() and not slots[i].is_empty():
		slots[i] = {}
		inventory_changed.emit()

# ---------------------------------------------------------------------------
# Equipment
# ---------------------------------------------------------------------------
func equip_from_slot(i: int) -> void:
	var it: Dictionary = item_at(i)
	if it.is_empty():
		return
	var t: String = ItemDB.def(it["id"]).get("type", "")
	if t != "weapon" and t != "armor":
		return
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and not multiplayer.is_server():
		var instance_id := str(it.get("item_instance_id", ""))
		if instance_id.is_empty():
			return
		MMORPGNetwork.request_equipment_change(t, instance_id)
		return
	var old: Dictionary = equipment[t]
	equipment[t] = it
	slots[i] = old
	inventory_changed.emit()
	equipment_changed.emit()
	EventBus.activity.emit("Equipped %s" % ItemDB.display_name(it), "info")

func unequip(slot: String) -> void:
	if not equipment.has(slot) or equipment[slot].is_empty():
		return
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online() and not multiplayer.is_server():
		MMORPGNetwork.request_equipment_change(slot, "")
		return
	var it: Dictionary = equipment[slot]
	for i in range(slots.size()):
		if slots[i].is_empty():
			slots[i] = it
			equipment[slot] = {}
			inventory_changed.emit()
			equipment_changed.emit()
			return
	EventBus.toast.emit("Inventory full!", "info")

func weapon_damage() -> float:
	var value: float = ItemDB.weapon_damage(equipment["weapon"])
	# Legendary Eclipse Edge stores a small damage bonus in its abyssal resonance.
	if str(equipment["weapon"].get("id", "")) == "eclipse_edge":
		value *= 1.15
	return value

func armor_value() -> float:
	var value: float = ItemDB.armor_value(equipment["armor"])
	# Warden Heartplate reinforces its wearer when taking a direct hit.
	if str(equipment["armor"].get("id", "")) == "warden_heartplate":
		value *= 1.20
	return value

func wear(slot: String, amount: float) -> void:
	var it: Dictionary = equipment.get(slot, {})
	if it.is_empty() or amount <= 0.0:
		return
	var before: float = float(it["dur"])
	it["dur"] = maxf(before - amount, 0.0)
	if before > 0.0 and it["dur"] <= 0.0:
		EventBus.toast.emit("Your %s broke! Repair it at a forge." % ItemDB.display_name(it), "info")
	equipment_changed.emit()

func use_item(i: int) -> bool:
	if _is_production_remote_client():
		return false
	var it: Dictionary = item_at(i)
	if it.is_empty() or ItemDB.def(it["id"]).get("type", "") != "consumable":
		return false
	var player: Node = GameManager.player
	if player == null or not player.has_node("HealthComponent"):
		return false
	var hc: HealthComponent = player.get_node("HealthComponent")
	if hc.is_dead:
		return false
	if hc.current_health >= hc.max_health and ItemDB.def(it["id"]).has("heal"):
		EventBus.toast.emit("Already at full health", "info")
		return false
	var healing: float = float(ItemDB.def(it["id"]).get("heal", 0.0))
	var remote_heal_request: bool = MMORPGNetwork.is_online() and not multiplayer.is_server() and healing > 0.0
	if remote_heal_request:
		var now: float = Time.get_ticks_msec() / 1000.0
		if now - _last_network_heal_request_at < 0.65:
			EventBus.toast.emit("Your healing is still settling. Try again in a moment.", "info")
			return false
		_last_network_heal_request_at = now
	var skill_system: Node = player.get_node_or_null("SkillSystem")
	if skill_system and skill_system.has_method("trait_bonus"):
		healing *= 1.0 + float(skill_system.trait_bonus("healing"))
	if MMORPGNetwork.is_online() and not multiplayer.is_server():
		MMORPGNetwork.request_health_heal(str(it["id"]), healing)
	else:
		hc.heal(healing)
	EventBus.activity.emit("Used %s" % ItemDB.display_name(it), "info")
	remove_item(it["id"], 1)
	return true

func use_first_potion() -> bool:
	for i in range(slots.size()):
		if not slots[i].is_empty() and slots[i]["id"] == "healing_potion":
			return use_item(i)
	EventBus.toast.emit("No healing potions", "info")
	return false

# ---------------------------------------------------------------------------
# Gold
# ---------------------------------------------------------------------------
func add_gold(n: int) -> void:
	if _is_production_remote_client():
		return
	gold += n
	gold_changed.emit(gold)
	if n > 0:
		EventBus.activity.emit("+%d gold" % n, "loot")

func spend_gold(n: int) -> bool:
	if _is_production_remote_client():
		return false
	if n <= 0:
		return false
	if gold < n:
		return false
	gold -= n
	gold_changed.emit(gold)
	return true

# ---------------------------------------------------------------------------
# Titles
# ---------------------------------------------------------------------------
func grant_title(t: String) -> void:
	if titles.has(t):
		return
	titles.append(t)
	EventBus.toast.emit("Title earned: %s" % t, "levelup")
	if active_title == "":
		active_title = t
	title_changed.emit()

func set_title(t: String) -> void:
	if t == "" or titles.has(t):
		active_title = t
		title_changed.emit()

func title_bonus(key: String) -> float:
	if active_title == "":
		return 0.0
	return float(QuestDB.TITLES.get(active_title, {}).get(key, 0.0))

# ---------------------------------------------------------------------------
# Quests
# ---------------------------------------------------------------------------
func quest_state(id: String) -> String:
	if not quests.has(id) or not (quests[id] is Dictionary):
		return "none"
	return str(quests[id].get("state", "none"))

func can_accept(id: String) -> bool:
	if not QuestDB.QUESTS.has(id) or quest_state(id) != "none":
		return false
	for p in QuestDB.QUESTS[id].get("prereq", []):
		if quest_state(p) != "done":
			return false
	return true

func objective_progress(id: String, i: int) -> int:
	if not QuestDB.QUESTS.has(id) or not quests.has(id):
		return 0
	var objectives: Array = QuestDB.QUESTS[id].get("objectives", [])
	var progress: Array = quests[id].get("progress", [])
	if i < 0 or i >= objectives.size() or i >= progress.size():
		return 0
	var need: int = int(objectives[i].get("count", 0))
	return clampi(int(progress[i]), 0, need)

func is_ready(id: String) -> bool:
	if not QuestDB.QUESTS.has(id) or quest_state(id) != "active":
		return false
	var objs: Array = QuestDB.QUESTS[id]["objectives"]
	for i in range(objs.size()):
		if objective_progress(id, i) < int(objs[i]["count"]):
			return false
	return true

func accept_quest(id: String) -> void:
	if not can_accept(id):
		return
	var objs: Array = QuestDB.QUESTS[id]["objectives"]
	var prog: Array = []
	for o in objs:
		var start: int = 0
		if o["type"] == "collect":
			start = mini(count_item(o["target"]), int(o["count"]))   # items you already carry count
		prog.append(start)
	quests[id] = {"state": "active", "progress": prog}
	EventBus.toast.emit("Quest accepted: %s" % QuestDB.QUESTS[id]["title"], "info")
	EventBus.activity.emit("Quest accepted: %s" % QuestDB.QUESTS[id]["title"], "quest")
	quests_changed.emit()

func apply_authoritative_quest_snapshot(rows: Array) -> void:
	var next_quests: Dictionary = {}
	for row_variant in rows:
		if not row_variant is Dictionary: continue
		var row: Dictionary = row_variant
		var quest_id := str(row.get("quest_id", ""))
		if not QuestDB.QUESTS.has(quest_id): continue
		var definition: Dictionary = QuestDB.QUESTS[quest_id]
		var progress: Array = []
		for objective in definition.get("objectives", []): progress.append(0)
		var saved_progress: Dictionary = row.get("objective_progress", {}) if row.get("objective_progress", {}) is Dictionary else {}
		for index in range(progress.size()):
			progress[index] = int(saved_progress.get(str(index), saved_progress.get(index, 0)))
		var quest_state: Dictionary = row.get("quest_state", {}) if row.get("quest_state", {}) is Dictionary else {}
		var status := str(quest_state.get("status", "active"))
		next_quests[quest_id] = {"state": "done" if status == "completed" else "active", "progress": progress}
	quests = next_quests
	quests_changed.emit()

func mark_quest_accepted_authoritatively(id: String) -> void:
	if not QuestDB.QUESTS.has(id): return
	if quest_state(id) == "done": return
	if not quests.has(id):
		var progress: Array = []
		for objective in QuestDB.QUESTS[id].get("objectives", []): progress.append(0)
		quests[id] = {"state": "active", "progress": progress}
	quests_changed.emit()

func mark_quest_completed_authoritatively(id: String) -> void:
	if not QuestDB.QUESTS.has(id): return
	var objectives: Array = QuestDB.QUESTS[id].get("objectives", [])
	var progress: Array = []
	for objective in objectives: progress.append(int(objective.get("count", 1)))
	quests[id] = {"state": "done", "progress": progress}
	quests_changed.emit()

func complete_quest(id: String) -> void:
	if WorldDeploymentGuard.is_production_session() and MMORPGNetwork.is_online():
		mark_quest_completed_authoritatively(id)
		return
	if not is_ready(id):
		return
	quests[id]["state"] = "done"
	var q: Dictionary = QuestDB.QUESTS[id]
	var r: Dictionary = q["rewards"]
	if _is_production_remote_client():
		# The central transaction has already committed the reward. This is only a
		# local quest-journal mirror; never mint client-side gold or inventory here.
		EventBus.toast.emit("Quest complete: %s" % q["title"], "levelup")
		EventBus.activity.emit("Quest complete: %s" % q["title"], "quest")
		quests_changed.emit()
		return
	EventBus.toast.emit("Quest complete: %s" % q["title"], "levelup")
	EventBus.activity.emit("Quest complete: %s" % q["title"], "quest")
	if r.get("gold", 0) > 0:
		add_gold(int(r["gold"]))
	for it in r.get("items", []):
		add_item(it["id"], int(it.get("count", 1)), int(it.get("grade", 0)))
	var player: Node = GameManager.player
	if player and player.get("skills") != null:
		for sid in r.get("skills", {}).keys():
			player.skills.train(sid, float(r["skills"][sid]))
	if r.has("title"):
		grant_title(str(r["title"]))
	var reputation: Node = get_tree().get_first_node_in_group("reputation")
	if reputation and reputation.has_method("add_rep"):
		var rep_rewards: Dictionary = r.get("reputation", {})
		for faction in rep_rewards.keys():
			reputation.add_rep(str(faction), int(rep_rewards[faction]))
	if reputation and reputation.has_method("add_affinity"):
		reputation.add_affinity(str(q.get("giver", "")), 3)
	quests_changed.emit()

## Called by game systems: ("kill","slime"), ("craft","iron_sword"), ("talk","Elara"), ("visit","Arcane Spire"), ("collect", id)
func notify(kind: String, key: String, amount: int = 1) -> void:
	if kind.strip_edges() == "" or key.strip_edges() == "" or amount <= 0:
		return
	var changed: bool = false
	for id in quests.keys():
		if not QuestDB.QUESTS.has(id) or quests[id].get("state", "") != "active":
			continue
		var objs: Array = QuestDB.QUESTS[id]["objectives"]
		for i in range(objs.size()):
			var o: Dictionary = objs[i]
			if o["type"] == kind and o["target"] == key:
				var before: int = int(quests[id]["progress"][i])
				if before >= int(o["count"]):
					continue
				quests[id]["progress"][i] = mini(before + amount, int(o["count"]))
				changed = true
				EventBus.activity.emit("%s: %d/%d" % [o["text"], objective_progress(id, i), int(o["count"])], "quest")
				if is_ready(id):
					EventBus.toast.emit("Quest ready to turn in: %s" % QuestDB.QUESTS[id]["title"], "info")
	if changed:
		quests_changed.emit()

## What can this NPC do for the player right now? -> {"kind": "turn_in"|"offer"|"progress"|"none", "quest": id}
func npc_quest_status(npc_name: String) -> Dictionary:
	for id in quests.keys():
		if QuestDB.QUESTS.has(id) and quests[id].get("state", "") == "active" and QuestDB.QUESTS[id].get("turn_in", "") == npc_name and is_ready(id):
			return {"kind": "turn_in", "quest": id}
	for id in QuestDB.QUESTS.keys():
		if QuestDB.QUESTS[id]["giver"] == npc_name and can_accept(id):
			return {"kind": "offer", "quest": id}
	for id in quests.keys():
		if QuestDB.QUESTS.has(id) and quests[id].get("state", "") == "active" and (QuestDB.QUESTS[id].get("giver", "") == npc_name or QuestDB.QUESTS[id].get("turn_in", "") == npc_name):
			return {"kind": "progress", "quest": id}
	return {"kind": "none", "quest": ""}

func active_quest_ids() -> Array:
	var out: Array = []
	for id in quests.keys():
		if quests[id]["state"] == "active":
			out.append(id)
	return out

# ---------------------------------------------------------------------------
# Zones
# ---------------------------------------------------------------------------
func discover_zone(zone: String) -> bool:
	if zones.has(zone):
		return false
	zones.append(zone)
	notify("visit", zone, 1)
	return true

# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
func to_dict() -> Dictionary:
	return {
		"slots": slots, "equipment": equipment, "gold": gold, "quests": quests,
		"titles": titles, "active_title": active_title, "zones": zones, "stats": stats,
	}

func _clean_item(d: Variant) -> Dictionary:
	if typeof(d) != TYPE_DICTIONARY or d.is_empty() or not ItemDB.has_item(str(d.get("id", ""))):
		return {}
	var count: int = int(d.get("count", 1))
	if count <= 0:
		return {}
	var item_id: String = str(d["id"])
	var max_dur: float = ItemDB.max_durability(ItemDB.make(item_id))
	var saved_dur: float = maxf(float(d.get("dur", max_dur)), 0.0)
	if ItemDB.is_gear(item_id):
		saved_dur = minf(saved_dur, max_dur)
	return {"id": item_id, "count": 1 if ItemDB.is_gear(item_id) else count, "grade": clampi(int(d.get("grade", 0)), 0, 5), "dur": saved_dur}

func from_dict(d: Dictionary) -> void:
	slots = []
	var source_slots: Variant = d.get("slots", [])
	var src: Array = source_slots if source_slots is Array else []
	for i in range(SLOT_COUNT):
		slots.append(_clean_item(src[i]) if i < src.size() else {})
	var equipment_value: Variant = d.get("equipment", {})
	var eq: Dictionary = equipment_value if equipment_value is Dictionary else {}
	equipment = {"weapon": _clean_item(eq.get("weapon", {})), "armor": _clean_item(eq.get("armor", {}))}
	gold = maxi(int(d.get("gold", 0)), 0)
	quests = {}
	var quests_value: Variant = d.get("quests", {})
	var qd: Dictionary = quests_value if quests_value is Dictionary else {}
	for id in qd.keys():
		if QuestDB.QUESTS.has(id) and qd[id] is Dictionary:
			var prog: Array = []
			var source_value: Variant = qd[id].get("progress", [])
			var source_progress: Array = source_value if source_value is Array else []
			var objective_count: int = QuestDB.QUESTS[id]["objectives"].size()
			for i in range(objective_count):
				var raw_value: int = int(source_progress[i]) if i < source_progress.size() else 0
				var required: int = int(QuestDB.QUESTS[id]["objectives"][i]["count"])
				prog.append(clampi(raw_value, 0, required))
			var quest_status: String = str(qd[id].get("state", "active"))
			if quest_status not in ["active", "done"]:
				quest_status = "active"
			quests[id] = {"state": quest_status, "progress": prog}
	titles = []
	var saved_titles: Variant = d.get("titles", [])
	if not (saved_titles is Array):
		saved_titles = []
	for t in saved_titles:
		titles.append(str(t))
	active_title = str(d.get("active_title", ""))
	zones = []
	var saved_zones: Variant = d.get("zones", [])
	if not (saved_zones is Array):
		saved_zones = []
	for z in saved_zones:
		zones.append(str(z))
	var stats_value: Variant = d.get("stats", {})
	var st: Dictionary = stats_value if stats_value is Dictionary else {}
	stats = st.duplicate(true)
	for key in ["kills", "crafted", "gathered", "archaeology", "tracks_studied", "marine_observations"]:
		stats[key] = int(stats.get(key, 0))
	inventory_changed.emit()
	equipment_changed.emit()
	gold_changed.emit(gold)
	quests_changed.emit()
	title_changed.emit()
