extends Node

signal network_status_changed(message: String)
signal peer_count_changed(count: int)
signal world_roster_changed(roster: Dictionary)
signal party_invite_received(party_id: String, leader_name: String)
signal trade_invitation_received(trade_id: String, initiator_name: String)
signal trade_status_changed(trade_id: String, message: String, success: bool)
signal sect_economy_result_received(payload: Dictionary, success: bool, error_message: String)

const DEFAULT_PORT: int = 24560
const MAX_CLIENTS: int = 128
const SINGLE_WORLD_ID: String = "eternal-realms-one-world"
const CHARACTER_DIR: String = "user://mmorpg_characters"
const AVATAR_SCENE: PackedScene = preload("res://networking/network_avatar.tscn")
const MONSTER_SCENE: PackedScene = preload("res://scenes/monster.tscn")
const NPC_SCENE: PackedScene = preload("res://scenes/npc.tscn")
const SERVER_MOVE_SPEED_LIMIT: float = 18.0

var world_root: Node3D = null
var remote_avatars: Dictionary = {}
var pending_remote_avatars: Dictionary = {}
var pending_local_spawn: Vector3 = Vector3.ZERO
var has_pending_local_spawn: bool = false
var accepted_positions: Dictionary = {}
var accepted_times: Dictionary = {}
var last_publish_time: float = 0.0
var status_message: String = "Offline single-player"
var server_mode: bool = false
var dedicated_mode: bool = false
var local_character_id: String = ""
var local_character_name: String = ""
var peer_characters: Dictionary = {}
var world_roster: Dictionary = {}
var pending_party_invite_id: String = ""
var combat_cooldowns: Dictionary = {}
var _interaction_request_at: Dictionary = {}
var _peer_heal_request_at: Dictionary = {}
var cultivation_states: Dictionary = {}
var cultivation_request_times: Dictionary = {}
var party_records: Dictionary = {}
var active_trade_sessions: Dictionary = {}
var _last_fishing_request_at: Dictionary = {}
var peer_party: Dictionary = {}
var _snapshot_clock: float = 0.0
var _entity_sync_clock: float = 0.0
var _client_shared_world_revision: int = -1
var _loot_sequence: int = 0
var active_combat_peer: int = 0
var _peer_regen_clock: float = 0.0
var peer_health: Dictionary = {}
var _network_notice_clock: float = 0.0
var character_db_revisions: Dictionary = {}
var character_persistence_in_flight: Dictionary = {}
var character_pending_snapshots: Dictionary = {}
var peer_last_snapshots: Dictionary = {}
var pending_identity_peers: Dictionary = {}

func _ready() -> void:
	_load_local_identity()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	_process_command_line()

func _process(delta: float) -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_entity_sync_clock += delta
		if _entity_sync_clock >= 0.25:
			_entity_sync_clock = 0.0
			_broadcast_world_entities()
		if not dedicated_mode:
			_snapshot_clock += delta
			if _snapshot_clock >= 30.0:
				_snapshot_clock = 0.0
				_store_character_snapshot(local_character_id, _build_character_snapshot())
		_peer_regen_clock += delta
		if _peer_regen_clock >= 1.0:
			_peer_regen_clock = 0.0
			_regenerate_remote_players()
	else:
		_snapshot_clock += delta
		if _snapshot_clock >= 30.0:
			_snapshot_clock = 0.0
			submit_character_snapshot(_build_character_snapshot())

func _load_local_identity() -> void:
	var path := "user://mmorpg_identity.json"
	var data: Dictionary = {}
	if FileAccess.file_exists(path):
		var file := FileAccess.open(path, FileAccess.READ)
		if file:
			var parsed: Variant = JSON.parse_string(file.get_as_text())
			file.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				data = parsed
	local_character_id = str(data.get("character_id", ""))
	if local_character_id == "":
		local_character_id = "ER-%s-%08X" % [str(OS.get_unique_id()).substr(0, 6), randi()]
	local_character_name = str(data.get("display_name", ""))
	if local_character_name == "":
		local_character_name = "Wanderer %04d" % randi_range(1000, 9999)
	var save := FileAccess.open(path, FileAccess.WRITE)
	if save:
		save.store_string(JSON.stringify({"character_id": local_character_id, "display_name": local_character_name}, "\t"))
		save.close()

func _build_character_snapshot() -> Dictionary:
	var snapshot: Dictionary = {"character_id": local_character_id, "display_name": local_character_name, "saved_at": Time.get_unix_time_from_system(), "game_time_seconds": GameManager.game_time_seconds}
	var player := world_root.get_node_or_null("Player") as Node3D if world_root else null
	if is_instance_valid(player):
		snapshot["position"] = [player.global_position.x, player.global_position.y, player.global_position.z]
		var health_node: Node = player.get("health")
		if health_node:
			snapshot["health"] = float(health_node.get("current_health"))
			snapshot["max_health"] = float(health_node.get("max_health"))
		snapshot["spiritual_energy"] = clampf(float(player.get("spiritual_energy")), 0.0, 3000.0)
		snapshot["max_spiritual_energy"] = clampf(float(player.get("max_spiritual_energy")), 1.0, 3000.0)
		var skills_node: Node = player.get("skills")
		if skills_node:
			if skills_node.has_method("to_dict"):
				snapshot["skills"] = skills_node.call("to_dict")
			else:
				var skill_values: Variant = skills_node.get("values")
				if skill_values is Dictionary:
					snapshot["skills"] = skill_values.duplicate(true)
			var saved_cultivation: Variant = skills_node.get("cultivation_state")
			if saved_cultivation is Dictionary:
				snapshot["cultivation_state"] = saved_cultivation.duplicate(true)
	snapshot["inventory"] = PlayerData.slots.duplicate(true)
	snapshot["equipment"] = PlayerData.equipment.duplicate(true)
	snapshot["gold"] = PlayerData.gold
	var discovery_state: Variant = PlayerData.stats.get("cultivation_discovery", {})
	if discovery_state is Dictionary:
		snapshot["cultivation_discovery"] = discovery_state.duplicate(true)
	return snapshot

func _process_command_line() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	for arg in args:
		if arg == "--server":
			call_deferred("start_dedicated_server")
		elif arg.begins_with("--connect="):
			var address: String = arg.trim_prefix("--connect=")
			call_deferred("join_server", address, DEFAULT_PORT)

func set_world_root(root: Node3D) -> void:
	world_root = root
	if has_pending_local_spawn:
		_apply_local_spawn(pending_local_spawn)
		has_pending_local_spawn = false
	for pending_id in pending_remote_avatars.keys():
		_spawn_remote_avatar_local(int(pending_id), pending_remote_avatars[pending_id])
	pending_remote_avatars.clear()
	if multiplayer.has_multiplayer_peer() and multiplayer.is_server():
		for peer_variant in multiplayer.get_peers():
			var peer_id: int = int(peer_variant)
			_spawn_avatar_for_all(peer_id, accepted_positions.get(peer_id, Vector3.ZERO))

func start_host(port: int = DEFAULT_PORT) -> Error:
	if WorldDeploymentGuard.production_client_mode:
		_set_status("Production clients must connect to the single authoritative Elyndor server; they cannot host another world.")
		return ERR_UNAUTHORIZED
	if WorldDeploymentGuard.production_mode and not WorldDeploymentGuard.can_start_production_server():
		_set_status("Production hosting blocked: acquire the global Elyndor lease first.")
		return ERR_UNAUTHORIZED
	_leave_existing_peer()
	dedicated_mode = false
	var peer := ENetMultiplayerPeer.new()
	var result: Error = peer.create_server(port, MAX_CLIENTS)
	if result != OK:
		var failure_message: String = "Host failed: %s" % error_string(result)
		_set_status(failure_message)
		_notify_network_local(failure_message, "warning")
		return result
	multiplayer.multiplayer_peer = peer
	server_mode = true
	var local_player: Node3D = null
	if world_root != null:
		local_player = world_root.get_node_or_null("Player") as Node3D
	var host_position: Vector3 = local_player.global_position if is_instance_valid(local_player) else Vector3.ZERO
	accepted_positions[1] = host_position
	accepted_times[1] = Time.get_ticks_msec() / 1000.0
	if is_instance_valid(local_player):
		var host_health: Node = local_player.get("health")
		if host_health:
			var host_max_health: float = clampf(float(host_health.get("max_health")), 1.0, 100000.0)
			peer_health[1] = {"current": clampf(float(host_health.get("current_health")), 0.0, host_max_health), "maximum": host_max_health}
		var host_skills: Node = local_player.get("skills")
		var host_cultivation_skill: float = float(host_skills.call("get_value", "cultivation")) if host_skills else 0.0
		var host_max_qi: float = clampf(float(local_player.get("max_spiritual_energy")), 1.0, 3000.0)
		var host_qi: float = clampf(float(local_player.get("spiritual_energy")), 0.0, host_max_qi)
		cultivation_states[1] = {"qi": host_qi, "maximum_qi": host_max_qi, "base_capacity": maxf(1.0, host_max_qi - host_cultivation_skill * 0.45), "cultivation_skill": host_cultivation_skill, "xp": 0.0, "last": Time.get_ticks_msec() / 1000.0, "origin": host_position, "active": false, "accum": 0.0}
	_set_status("Hosting the One World on UDP %d" % port)
	_notify_network_local("Hosting the One World", "success")
	_broadcast_world_roster()
	_refresh_peer_count()
	return OK

func start_dedicated_server(port: int = DEFAULT_PORT) -> Error:
	if WorldDeploymentGuard.production_client_mode:
		_set_status("A production client cannot start a world server.")
		return ERR_UNAUTHORIZED
	if WorldDeploymentGuard.production_mode:
		var lease_acquired: bool = await WorldDeploymentGuard.acquire_global_lease()
		if not lease_acquired:
			_set_status("Dedicated server blocked: global Elyndor lease unavailable.")
			return ERR_UNAUTHORIZED
		var world_hydrated: bool = await MMORPGWorldState.hydrate_central_world_entities()
		if not world_hydrated:
			_set_status("Dedicated server blocked: persistent world could not be restored from PostgreSQL.")
			push_error("[MMORPG] Refusing to host from stale local world state: %s" % MMORPGWorldState.central_hydration_error)
			await WorldDeploymentGuard.release_global_lease()
			return ERR_CANT_CONNECT
	var result: Error = start_host(port)
	if result != OK and WorldDeploymentGuard.production_mode:
		await WorldDeploymentGuard.release_global_lease()
	if result == OK:
		server_mode = true
		dedicated_mode = true
		_broadcast_world_roster()
		_refresh_peer_count()
		print("[MMORPG] Dedicated One World server listening on UDP %d" % port)
		call_deferred("_enter_dedicated_world")
	return result

func _enter_dedicated_world() -> void:
	if get_tree().current_scene == null or get_tree().current_scene.scene_file_path != "res://scenes/main.tscn":
		get_tree().change_scene_to_file("res://scenes/main.tscn")

func join_server(address: String, port: int = DEFAULT_PORT) -> Error:
	if address.strip_edges().is_empty():
		_set_status("Enter a server address")
		_notify_network_local("Enter a server address before joining.", "warning")
		return ERR_INVALID_PARAMETER
	_leave_existing_peer()
	var peer := ENetMultiplayerPeer.new()
	var result: Error = peer.create_client(address.strip_edges(), port)
	if result != OK:
		var failure_message: String = "Connection failed to start: %s" % error_string(result)
		_set_status(failure_message)
		_notify_network_local(failure_message, "warning")
		return result
	multiplayer.multiplayer_peer = peer
	server_mode = false
	_set_status("Connecting to %s:%d…" % [address, port])
	_notify_network_local("Connecting to One World…", "info")
	return OK

func stop_network() -> void:
	var was_online: bool = is_online()
	_leave_existing_peer()
	if WorldDeploymentGuard.production_mode and WorldDeploymentGuard.lease_active:
		WorldDeploymentGuard.release_global_lease()
	server_mode = false
	dedicated_mode = false
	_set_status("Offline single-player")
	_refresh_peer_count()
	if was_online:
		_notify_network_local("Disconnected. Offline single-player is ready.", "info")

func _reset_after_network_failure(message: String, kind: String = "warning") -> void:
	_leave_existing_peer()
	server_mode = false
	dedicated_mode = false
	_set_status(message)
	_notify_network_local(message, kind)
	_refresh_peer_count()

func _notify_network_local(message: String, kind: String = "info") -> void:
	if is_instance_valid(EventBus):
		EventBus.toast.emit(message, kind)

func _broadcast_network_notice(message: String, kind: String = "info") -> void:
	if is_online() and multiplayer.is_server():
		rpc("receive_network_notice", message, kind)
	else:
		_notify_network_local(message, kind)

@rpc("authority", "call_local", "reliable")
func receive_network_notice(message: String, kind: String = "info") -> void:
	_notify_network_local(message, kind)

func _leave_existing_peer() -> void:
	if multiplayer.has_multiplayer_peer():
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	pending_remote_avatars.clear()
	for avatar in remote_avatars.values():
		if is_instance_valid(avatar):
			avatar.queue_free()
	remote_avatars.clear()
	accepted_positions.clear()
	accepted_times.clear()
	peer_characters.clear()
	pending_identity_peers.clear()
	world_roster.clear()
	pending_party_invite_id = ""
	combat_cooldowns.clear()
	cultivation_states.clear()
	cultivation_request_times.clear()
	party_records.clear()
	peer_party.clear()
	peer_health.clear()
	_interaction_request_at.clear()
	_peer_heal_request_at.clear()

func is_online() -> bool:
	return multiplayer.has_multiplayer_peer() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer)

func is_authority() -> bool:
	return not is_online() or multiplayer.is_server()

func _on_peer_connected(peer_id: int) -> void:
	if not multiplayer.is_server():
		return
	rpc_id(peer_id, "request_client_identity")
	var host_player: Node3D = null
	if world_root != null:
		host_player = world_root.get_node_or_null("Player") as Node3D
	var host_origin: Vector3 = host_player.global_position if is_instance_valid(host_player) else Vector3.ZERO
	var spawn_position: Vector3 = host_origin + Vector3(float((peer_id % 4) * 2), 0.0, float((peer_id % 3) * 2))
	accepted_positions[peer_id] = spawn_position
	accepted_times.erase(peer_id)
	_spawn_avatar_for_all(peer_id, spawn_position)
	rpc_id(peer_id, "assign_local_spawn", peer_id, spawn_position)
	var host_position: Vector3 = accepted_positions.get(1, Vector3.ZERO)
	if not dedicated_mode:
		rpc_id(peer_id, "spawn_remote_avatar", 1, host_position)
		rpc_id(peer_id, "set_remote_avatar_name", 1, local_character_name)
	for existing_variant in multiplayer.get_peers():
		var existing_id: int = int(existing_variant)
		if existing_id == peer_id:
			continue
		var existing_position: Vector3 = accepted_positions.get(existing_id, Vector3.ZERO)
		rpc_id(peer_id, "spawn_remote_avatar", existing_id, existing_position)
	send_world_monsters_to_peer(peer_id)
	send_world_npcs_to_peer(peer_id)
	_refresh_peer_count()
	_set_status("Player %d joined" % peer_id)

func _on_peer_disconnected(peer_id: int) -> void:
	if multiplayer.is_server():
		var identity: Dictionary = peer_characters.get(peer_id, {})
		var departing_name: String = str(identity.get("display_name", "Cultivator %d" % peer_id))
		if not identity.is_empty():
			var character_id: String = str(identity.get("character_id", ""))
			var display_name: String = departing_name
			var saved: Dictionary = peer_last_snapshots.get(peer_id, {}).duplicate(true)
			if saved.is_empty() and not WorldDeploymentGuard.production_mode:
				saved = _load_character_snapshot(character_id)
			saved["character_id"] = character_id
			saved["display_name"] = display_name
			saved["last_seen"] = Time.get_unix_time_from_system()
			var last_position: Vector3 = accepted_positions.get(peer_id, Vector3.ZERO)
			saved["position"] = [last_position.x, last_position.y, last_position.z]
			var health_state: Dictionary = peer_health.get(peer_id, {"current": 100.0, "maximum": 100.0})
			var safe_max_health: float = clampf(float(health_state.get("maximum", 100.0)), 1.0, 100000.0)
			saved["health"] = clampf(float(health_state.get("current", safe_max_health)), 0.0, safe_max_health)
			saved["max_health"] = safe_max_health
			var cultivation_record: Dictionary = cultivation_states.get(peer_id, {"qi": 30.0, "maximum_qi": 30.0, "base_capacity": 30.0, "cultivation_skill": 0.0, "xp": 0.0})
			var maximum_qi: float = clampf(float(cultivation_record.get("maximum_qi", 30.0)), 1.0, 3000.0)
			saved["spiritual_energy"] = clampf(float(cultivation_record.get("qi", maximum_qi)), 0.0, maximum_qi)
			saved["max_spiritual_energy"] = maximum_qi
			saved["server_cultivation"] = {"qi": saved["spiritual_energy"], "maximum_qi": maximum_qi, "base_capacity": clampf(float(cultivation_record.get("base_capacity", maximum_qi)), 1.0, 3000.0), "cultivation_skill": maxf(0.0, float(cultivation_record.get("cultivation_skill", 0.0))), "xp": maxf(0.0, float(cultivation_record.get("xp", 0.0)))}
			_store_character_snapshot(character_id, saved)
		_server_leave_party(peer_id)
		var dungeon := get_tree().get_first_node_in_group("dungeon")
		if dungeon:
			dungeon._peer_floors.erase(peer_id)
			dungeon._travel_times.erase(peer_id)
		pending_identity_peers.erase(peer_id)
		peer_characters.erase(peer_id)
		peer_last_snapshots.erase(peer_id)
		peer_health.erase(peer_id)
		cultivation_states.erase(peer_id)
		cultivation_request_times.erase(peer_id)
		combat_cooldowns.erase(peer_id)
		_interaction_request_at.erase(peer_id)
		_peer_heal_request_at.erase(peer_id)
		accepted_positions.erase(peer_id)
		accepted_times.erase(peer_id)
		rpc("despawn_remote_avatar", peer_id)
		_broadcast_world_roster()
		_broadcast_network_notice("%s left the One World" % departing_name, "info")
	accepted_positions.erase(peer_id)
	accepted_times.erase(peer_id)
	_refresh_peer_count()
	_set_status("Player %d left" % peer_id)

func _on_connected_to_server() -> void:
	_set_status("Connected to Eternal Realms — One World")
	_notify_network_local("Connected to the One World", "success")
	_refresh_peer_count()

func _on_connection_failed() -> void:
	_reset_after_network_failure("Connection failed. Check the address and try again.", "warning")

func _on_server_disconnected() -> void:
	_reset_after_network_failure("Server connection lost. You are now offline.", "warning")

func _spawn_avatar_for_all(peer_id: int, spawn_position: Vector3) -> void:
	rpc("spawn_remote_avatar", peer_id, spawn_position)

@rpc("authority", "reliable")
func assign_local_spawn(peer_id: int, spawn_position: Vector3) -> void:
	if peer_id != multiplayer.get_unique_id():
		return
	if world_root == null:
		pending_local_spawn = spawn_position
		has_pending_local_spawn = true
		return
	_apply_local_spawn(spawn_position)

func _apply_local_spawn(spawn_position: Vector3) -> void:
	if world_root == null:
		return
	var local_player: Node3D = world_root.get_node_or_null("Player") as Node3D
	if is_instance_valid(local_player):
		local_player.global_position = spawn_position
		if local_player is CharacterBody3D:
			(local_player as CharacterBody3D).velocity = Vector3.ZERO

@rpc("authority", "call_local", "reliable")
func spawn_remote_avatar(peer_id: int, spawn_position: Vector3) -> void:
	if peer_id == multiplayer.get_unique_id() or remote_avatars.has(peer_id):
		return
	if world_root == null:
		pending_remote_avatars[peer_id] = spawn_position
		return
	_spawn_remote_avatar_local(peer_id, spawn_position)

func _spawn_remote_avatar_local(peer_id: int, spawn_position: Vector3) -> void:
	if peer_id == multiplayer.get_unique_id() or remote_avatars.has(peer_id) or world_root == null:
		return
	var avatar := AVATAR_SCENE.instantiate() as MMORPGNetworkAvatar
	avatar.name = "RemoteCultivator_%d" % peer_id
	avatar.configure(peer_id)
	world_root.add_child(avatar)
	avatar.global_position = spawn_position
	remote_avatars[peer_id] = avatar
	avatar.apply_network_state(spawn_position, 0.0)

@rpc("authority", "call_local", "reliable")
func set_remote_avatar_name(peer_id: int, display_name: String) -> void:
	var avatar: Node = remote_avatars.get(peer_id)
	if is_instance_valid(avatar) and avatar.has_method("configure"):
		avatar.configure(peer_id, display_name)

@rpc("authority", "call_local", "reliable")
func despawn_remote_avatar(peer_id: int) -> void:
	var avatar: Node = remote_avatars.get(peer_id)
	if is_instance_valid(avatar):
		avatar.queue_free()
	remote_avatars.erase(peer_id)

func publish_local_player(world_position: Vector3, yaw: float) -> void:
	if not is_online():
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - last_publish_time < 0.05:
		return
	last_publish_time = now
	var local_id: int = multiplayer.get_unique_id()
	if multiplayer.is_server():
		_accept_player_transform(local_id, world_position, yaw)
	else:
		rpc_id(1, "submit_player_transform", world_position, yaw)

@rpc("any_peer", "unreliable")
func submit_player_transform(world_position: Vector3, yaw: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id: int = multiplayer.get_remote_sender_id()
	_accept_player_transform(sender_id, world_position, yaw)

func _accept_player_transform(peer_id: int, world_position: Vector3, yaw: float) -> void:
	var now: float = Time.get_ticks_msec() / 1000.0
	var previous: Vector3 = accepted_positions.get(peer_id, world_position)
	var previous_time: float = float(accepted_times.get(peer_id, now))
	var elapsed: float = maxf(now - previous_time, 0.01)
	var allowed_distance: float = SERVER_MOVE_SPEED_LIMIT * elapsed + 2.0
	if accepted_times.has(peer_id) and previous.distance_to(world_position) > allowed_distance:
		return
	if not accepted_times.has(peer_id) and previous.distance_to(world_position) > 150.0:
		return
	accepted_positions[peer_id] = world_position
	accepted_times[peer_id] = now
	rpc("apply_remote_player_transform", peer_id, world_position, yaw)

@rpc("authority", "call_local", "unreliable")
func apply_remote_player_transform(peer_id: int, world_position: Vector3, yaw: float) -> void:
	var avatar: Node = remote_avatars.get(peer_id)
	if is_instance_valid(avatar) and avatar.has_method("apply_network_state"):
		avatar.apply_network_state(world_position, yaw)

@rpc("authority", "reliable")
func request_client_identity() -> void:
	if multiplayer.is_server():
		return
	rpc_id(1, "register_character_identity", SINGLE_WORLD_ID, local_character_id, local_character_name, CentralBackend.pending_join_ticket)

@rpc("any_peer", "reliable")
func register_character_identity(world_id: String, character_id: String, display_name: String, join_ticket: String = "") -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if peer_characters.has(sender) or pending_identity_peers.has(sender):
		return
	if world_id != SINGLE_WORLD_ID or character_id.strip_edges().is_empty():
		rpc_id(sender, "reject_world_connection", "This server hosts a different world identity.")
		return
	pending_identity_peers[sender] = true
	var safe_id: String = character_id.validate_filename()
	var authoritative_name: String = display_name.substr(0, 24)
	var snapshot: Dictionary = {}
	if WorldDeploymentGuard.production_mode:
		var uuid_pattern := RegEx.new()
		uuid_pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$")
		if uuid_pattern.search(character_id) == null:
			pending_identity_peers.erase(sender)
			rpc_id(sender, "reject_world_connection", "Production characters must be selected from a verified account.")
			return
		var ticket_result: Dictionary = await CentralBackend.consume_join_ticket(join_ticket)
		if not bool(ticket_result.get("ok", false)):
			pending_identity_peers.erase(sender)
			rpc_id(sender, "reject_world_connection", "Account verification failed. Please sign in and select your character again.")
			return
		var ticket_body: Dictionary = ticket_result.get("body", {})
		if str(ticket_body.get("character_id", "")) != character_id:
			pending_identity_peers.erase(sender)
			rpc_id(sender, "reject_world_connection", "The account ticket does not match this character.")
			return
		authoritative_name = str(ticket_body.get("display_name", "Wanderer"))
		var stored_state: Variant = ticket_body.get("character_state", {})
		if stored_state is Dictionary:
			snapshot = stored_state.duplicate(true)
		character_db_revisions[safe_id] = int(ticket_body.get("revision", 0))
	else:
		snapshot = _load_character_snapshot(safe_id)
	var initial_inventory: Dictionary = {}
	if WorldDeploymentGuard.production_mode:
		var inventory_result: Dictionary = await CentralBackend.server_get_inventory(safe_id)
		if not bool(inventory_result.get("ok", false)):
			pending_identity_peers.erase(sender)
			rpc_id(sender, "reject_world_connection", "Could not load your authoritative inventory. Please reconnect.")
			return
		initial_inventory = inventory_result.get("body", {})
	for connected_peer in peer_characters.keys():
		if int(connected_peer) != sender and str(peer_characters[connected_peer].get("character_id", "")) == safe_id:
			pending_identity_peers.erase(sender)
			rpc_id(sender, "reject_world_connection", "That character is already online in this world.")
			return
	pending_identity_peers.erase(sender)
	peer_characters[sender] = {"character_id": safe_id, "display_name": authoritative_name}
	var saved_max_health: float = clampf(float(snapshot.get("max_health", 100.0)), 1.0, 100000.0)
	var saved_health: float = clampf(float(snapshot.get("health", saved_max_health)), 0.0, saved_max_health)
	peer_health[sender] = {"current": saved_health, "maximum": saved_max_health, "last_damage": Time.get_ticks_msec() / 1000.0}
	var saved_cultivation: Variant = snapshot.get("server_cultivation", {})
	var cultivation_record: Dictionary = saved_cultivation.duplicate(true) if saved_cultivation is Dictionary else {}
	var skills_snapshot: Variant = snapshot.get("skills", {})
	var legacy_cultivation_skill: float = float(skills_snapshot.get("cultivation", 0.0)) if skills_snapshot is Dictionary else 0.0
	var cultivation_skill: float = maxf(0.0, float(cultivation_record.get("cultivation_skill", legacy_cultivation_skill)))
	var max_qi: float = clampf(float(cultivation_record.get("maximum_qi", snapshot.get("max_spiritual_energy", 30.0))), 1.0, 3000.0)
	var base_capacity: float = clampf(float(cultivation_record.get("base_capacity", maxf(1.0, max_qi - cultivation_skill * 0.45))), 1.0, 3000.0)
	max_qi = clampf(base_capacity + cultivation_skill * 0.45, 1.0, 3000.0)
	var qi: float = clampf(float(cultivation_record.get("qi", snapshot.get("spiritual_energy", max_qi))), 0.0, max_qi)
	cultivation_states[sender] = {"qi": qi, "maximum_qi": max_qi, "base_capacity": base_capacity, "cultivation_skill": cultivation_skill, "xp": maxf(0.0, float(cultivation_record.get("xp", 0.0))), "last": Time.get_ticks_msec() / 1000.0, "origin": accepted_positions.get(sender, Vector3.ZERO), "active": false, "accum": 0.0}
	snapshot["spiritual_energy"] = qi
	snapshot["max_spiritual_energy"] = max_qi
	snapshot["server_cultivation"] = {"qi": qi, "maximum_qi": max_qi, "base_capacity": base_capacity, "cultivation_skill": cultivation_skill, "xp": maxf(0.0, float(cultivation_record.get("xp", 0.0)))}
	_set_snapshot_skill_value(snapshot, "cultivation", cultivation_skill)
	if snapshot.has("position") and snapshot.get("position") is Array and snapshot.get("position", []).size() == 3:
		var saved_position := Vector3(float(snapshot.get("position", [0.0, 0.0, 0.0])[0]), float(snapshot.get("position", [0.0, 0.0, 0.0])[1]), float(snapshot.get("position", [0.0, 0.0, 0.0])[2]))
		if saved_position.length() < 100000.0:
			accepted_positions[sender] = saved_position
			rpc_id(sender, "assign_local_spawn", sender, saved_position)
			rpc("apply_remote_player_transform", sender, saved_position, 0.0)
	rpc_id(sender, "accept_character_identity", safe_id, authoritative_name, snapshot)
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	if dungeon:
		dungeon.synchronize_peer(sender)
	if WorldDeploymentGuard.production_mode:
		rpc_id(sender, "apply_authoritative_inventory", initial_inventory)
		await sync_authoritative_quests_to_peer(sender, safe_id)
	var underwater: Node = get_tree().get_first_node_in_group("underwater_exploration")
	if underwater and underwater.has_method("send_snapshot_to_peer"):
		underwater.call("send_snapshot_to_peer", sender)
	var life_simulation: Node = get_tree().root.get_node_or_null("WorldLifeSimulation")
	if life_simulation and life_simulation.has_method("send_snapshot_to_peer"):
		life_simulation.call("send_snapshot_to_peer", sender)
	send_world_monsters_to_peer(sender)
	MMORPGWorldState.send_snapshot_to_peer(sender)
	rpc("set_remote_avatar_name", sender, str(peer_characters[sender].get("display_name", "Wanderer")))
	_broadcast_world_roster()
	var joined_name: String = str(peer_characters[sender].get("display_name", "Wanderer"))
	_set_status("%s entered the One World" % joined_name)
	_broadcast_network_notice("%s joined the One World" % joined_name, "success")

@rpc("authority", "reliable")
func reject_world_connection(reason: String) -> void:
	_reset_after_network_failure("World connection rejected: %s" % reason, "warning")

@rpc("authority", "reliable")
func accept_character_identity(character_id: String, display_name: String, snapshot: Dictionary) -> void:
	local_character_id = character_id
	local_character_name = display_name
	if not snapshot.is_empty():
		_apply_character_snapshot(snapshot)
	_set_status("Welcome, %s — connected to the shared world" % display_name)
	_notify_network_local("Welcome to the One World, %s" % display_name, "success")
	submit_character_snapshot(_build_character_snapshot())

func _apply_character_snapshot(snapshot: Dictionary) -> void:
	GameManager.game_time_seconds = maxf(GameManager.game_time_seconds, float(snapshot.get("game_time_seconds", 0.0)))
	var discovery_value: Variant = snapshot.get("cultivation_discovery", null)
	if discovery_value is Dictionary:
		PlayerData.stats["cultivation_discovery"] = discovery_value.duplicate(true)
	var inventory_value: Variant = snapshot.get("inventory", null)
	if inventory_value is Array:
		PlayerData.slots = inventory_value.duplicate(true)
	var equipment_value: Variant = snapshot.get("equipment", null)
	if equipment_value is Dictionary:
		PlayerData.equipment = equipment_value.duplicate(true)
	if snapshot.has("gold"):
		PlayerData.gold = maxi(0, int(snapshot.get("gold", 0)))
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	if player:
		var health_node: Node = player.get("health")
		if health_node:
			var maximum: float = clampf(float(snapshot.get("max_health", health_node.get("max_health"))), 1.0, 100000.0)
			var current: float = clampf(float(snapshot.get("health", health_node.get("current_health"))), 0.0, maximum)
			health_node.set("max_health", maximum)
			health_node.set("current_health", current)
			health_node.set("is_dead", current <= 0.0)
			if health_node.has_signal("health_changed"):
				health_node.health_changed.emit(current, maximum)
			if current <= 0.0 and health_node.has_signal("died"):
				health_node.died.emit(null)
		player.set("max_spiritual_energy", clampf(float(snapshot.get("max_spiritual_energy", player.get("max_spiritual_energy"))), 1.0, 3000.0))
		player.set("spiritual_energy", clampf(float(snapshot.get("spiritual_energy", player.get("spiritual_energy"))), 0.0, float(player.get("max_spiritual_energy"))))
		var skills_node: Node = player.get("skills")
		var skills_value: Variant = snapshot.get("skills", null)
		if skills_node and skills_value is Dictionary:
			if skills_node.has_method("from_dict"):
				skills_node.call("from_dict", skills_value.duplicate(true))
			else:
				var skill_values: Variant = skills_value.get("values", skills_value)
				if skill_values is Dictionary:
					skills_node.set("values", skill_values.duplicate(true))
		var saved_cultivation: Variant = snapshot.get("cultivation_state", null)
		if skills_node and saved_cultivation is Dictionary:
			var merged_cultivation: Dictionary = {}
			var existing_cultivation: Variant = skills_node.get("cultivation_state")
			if existing_cultivation is Dictionary:
				merged_cultivation = existing_cultivation.duplicate(true)
			for state_key in saved_cultivation.keys():
				merged_cultivation[state_key] = saved_cultivation[state_key]
			skills_node.set("cultivation_state", merged_cultivation)
	PlayerData.inventory_changed.emit()
	PlayerData.equipment_changed.emit()
	PlayerData.gold_changed.emit(PlayerData.gold)

func submit_character_snapshot(snapshot: Dictionary) -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_store_character_snapshot(local_character_id, snapshot)
	else:
		rpc_id(1, "receive_character_snapshot", snapshot)

@rpc("any_peer", "reliable")
func receive_character_snapshot(snapshot: Dictionary) -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender):
		return
	var identity: Dictionary = peer_characters.get(sender, {})
	var character_id: String = str(identity.get("character_id", ""))
	if character_id.is_empty():
		return
	# Identity, health and max health are server-owned even while inventory/skill snapshots
	# are still migrating toward fully server-authoritative character data.
	var safe_snapshot: Dictionary = snapshot.duplicate(true)
	var health_state: Dictionary = peer_health.get(sender, {"current": 100.0, "maximum": 100.0})
	safe_snapshot["character_id"] = character_id
	safe_snapshot["display_name"] = str(identity.get("display_name", "Wanderer"))
	var accepted_position: Vector3 = accepted_positions.get(sender, Vector3.ZERO)
	safe_snapshot["position"] = [accepted_position.x, accepted_position.y, accepted_position.z]
	safe_snapshot["health"] = clampf(float(health_state.get("current", 100.0)), 0.0, 100000.0)
	safe_snapshot["max_health"] = clampf(float(health_state.get("maximum", 100.0)), 1.0, 100000.0)
	var cultivation_record: Dictionary = cultivation_states.get(sender, {"qi": 30.0, "maximum_qi": 30.0, "base_capacity": 30.0, "cultivation_skill": 0.0, "xp": 0.0})
	var maximum_qi: float = clampf(float(cultivation_record.get("maximum_qi", 30.0)), 1.0, 3000.0)
	safe_snapshot["spiritual_energy"] = clampf(float(cultivation_record.get("qi", maximum_qi)), 0.0, maximum_qi)
	safe_snapshot["max_spiritual_energy"] = maximum_qi
	var authoritative_cultivation_skill: float = maxf(0.0, float(cultivation_record.get("cultivation_skill", 0.0)))
	safe_snapshot["server_cultivation"] = {"qi": safe_snapshot["spiritual_energy"], "maximum_qi": maximum_qi, "base_capacity": clampf(float(cultivation_record.get("base_capacity", maximum_qi)), 1.0, 3000.0), "cultivation_skill": authoritative_cultivation_skill, "xp": maxf(0.0, float(cultivation_record.get("xp", 0.0)))}
	_set_snapshot_skill_value(safe_snapshot, "cultivation", authoritative_cultivation_skill)	
	peer_last_snapshots[sender] = safe_snapshot.duplicate(true)
	_store_character_snapshot(character_id, safe_snapshot)

func _set_snapshot_skill_value(snapshot: Dictionary, skill_id: String, value: float) -> void:
	var skills_value: Variant = snapshot.get("skills", {})
	if not skills_value is Dictionary:
		return
	var skills_record: Dictionary = skills_value.duplicate(true)
	var nested_values: Variant = skills_record.get("values", null)
	if nested_values is Dictionary:
		var values: Dictionary = nested_values.duplicate(true)
		values[skill_id] = value
		skills_record["values"] = values
	else:
		skills_record[skill_id] = value
	snapshot["skills"] = skills_record

func _store_character_snapshot(character_id: String, snapshot: Dictionary) -> void:
	if character_id.is_empty():
		return
	if WorldDeploymentGuard.production_mode:
		if not character_db_revisions.has(character_id):
			return
		var authoritative_state: Dictionary = snapshot.duplicate(true)
		# Inventory/equipment/currency are stored only through transactional backend endpoints.
		authoritative_state.erase("inventory")
		authoritative_state.erase("equipment")
		authoritative_state.erase("gold")
		# Skill/technique discovery and practice are progression state, not inventory ledger data.
		if character_persistence_in_flight.has(character_id):
			character_pending_snapshots[character_id] = authoritative_state
			return
		# A fresh snapshot supersedes any queued snapshot left after a failed request.
		character_pending_snapshots.erase(character_id)
		character_persistence_in_flight[character_id] = true
		_persist_character_snapshot(character_id, int(character_db_revisions[character_id]), authoritative_state)
		return
	MMORPGWorldState.save_character_snapshot(character_id, snapshot)

func _persist_character_snapshot(character_id: String, revision: int, snapshot: Dictionary) -> void:
	var result: Dictionary = await CentralBackend.server_save_character(character_id, revision, snapshot)
	character_persistence_in_flight.erase(character_id)
	if bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		character_db_revisions[character_id] = int(body.get("revision", revision + 1))
		if character_pending_snapshots.has(character_id):
			var pending: Dictionary = character_pending_snapshots[character_id]
			character_pending_snapshots.erase(character_id)
			_store_character_snapshot(character_id, pending)
	else:
		push_error("[MMORPGNetwork] Central character save failed for %s: %s" % [character_id, str(result.get("error", result.get("body", {})))])

func _load_character_snapshot(character_id: String) -> Dictionary:
	var path: String = CHARACTER_DIR.path_join(character_id.validate_filename() + ".json")
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	return (parsed as Dictionary).get("snapshot", {}) as Dictionary

func request_validated_interaction(target: Node3D, action: String, detail_id: String = "") -> void:
	if not is_online() or multiplayer.is_server() or not is_instance_valid(target):
		return
	rpc_id(1, "server_validate_interaction", target.get_path(), action, detail_id)

@rpc("any_peer", "reliable")
func server_validate_interaction(target_path: NodePath, action: String, detail_id: String = "") -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if sender == 1 or not peer_characters.has(sender):
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - float(_interaction_request_at.get(sender, -1.0)) < 0.35:
		return
	_interaction_request_at[sender] = now
	var target: Node = get_tree().root.get_node_or_null(target_path)
	if not is_instance_valid(target) or not target is Node3D or not target.has_method("can_interact"):
		rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, false, "That interaction is no longer available.")
		return
	if not bool(target.call("can_interact")):
		rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, false, "That interaction is no longer available.")
		return
	var accepted_position: Vector3 = accepted_positions.get(sender, Vector3(1.0e9, 0.0, 1.0e9))
	var max_range: float = float(target.get_meta("interact_range", 3.6))
	if target is NPC:
		max_range = float((target as NPC).interact_range)
	max_range = clampf(max_range, 1.5, 6.0)
	if accepted_position.distance_to((target as Node3D).global_position) > max_range + 0.75:
		rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, false, "Move closer before interacting.")
		return
	var approved: bool = false
	match action:
		"npc_talk":
			approved = target is NPC
		"quest_turn_in":
			if target is NPC and QuestDB.QUESTS.has(detail_id):
				var quest_record: Variant = QuestDB.QUESTS.get(detail_id, {})
				approved = quest_record is Dictionary and str(quest_record.get("turn_in", "")) == str((target as NPC).npc_name)
		"quest_accept":
			if target is NPC and QuestDB.QUESTS.has(detail_id):
				var offer_record: Variant = QuestDB.QUESTS.get(detail_id, {})
				approved = offer_record is Dictionary and str(offer_record.get("giver", "")) == str((target as NPC).npc_name)
		"shop_open":
			if target is NPC:
				var merchant_name := str((target as NPC).npc_name)
				approved = StationPanel.SHOPS.has(merchant_name) or not LivingWorldSystem.business_id_for_owner(merchant_name).is_empty()
		"faction_merchant":
			var target_script: Script = target.get_script() as Script
			approved = target_script != null and target_script.resource_path == "res://entities/dungeon_faction_encounter.gd" and str(target.get("encounter_type")) == "merchant" and not bool(target.get("resolved"))
	if not approved:
		rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, false, "The server rejected that interaction.")
		return
	# All production quest state changes are committed by the backend before the
	# client is told that the interaction succeeded.
	if WorldDeploymentGuard.production_mode:
		var identity: Dictionary = peer_characters.get(sender, {})
		var character_id: String = str(identity.get("character_id", ""))
		if character_id.is_empty():
			rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, false, "Character identity is unavailable.")
			return
		if target is NPC:
			var npc: NPC = target as NPC
			call_deferred("_persist_quest_objective_event", character_id, "talk", npc.npc_name)
			var interaction_kind := "dialogue"
			if action == "quest_turn_in" or action == "quest_accept":
				call_deferred("_complete_server_quest_action", sender, target_path, action, detail_id, character_id, npc.npc_name)
				return
			elif action == "shop_open":
				interaction_kind = "merchant_opened"
				call_deferred("_send_authoritative_merchant_stock", sender, npc.npc_name)
			call_deferred("_persist_npc_interaction", character_id, npc.npc_name, interaction_kind, {"detail_id": detail_id})
	rpc_id(sender, "receive_interaction_validation", target_path, action, detail_id, true, "")

func _send_authoritative_merchant_stock(peer_id: int, npc_name: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured(): return
	var merchant_id := merchant_uuid_for_npc(npc_name)
	var business: Dictionary = LivingWorldSystem.get_business_record_for_owner(npc_name)
	var result: Dictionary = await CentralBackend.server_get_merchant_stock(merchant_id)
	if not business.is_empty() and not bool(business.get("backend_provisioned", false)) and bool(result.get("ok", false)):
		var stock_body: Dictionary = result.get("body", {})
		var catalog_record: Variant = stock_body.get("merchant", null)
		if catalog_record is Dictionary:
			LivingWorldSystem.mark_business_backend_provisioned(npc_name)
		elif catalog_record == null or not catalog_record is Dictionary:
			var initial_stock: Array = []
			var local_stock: Dictionary = business.get("stock", {})
			for item_id in local_stock:
				if not ItemDB.has_item(str(item_id)): continue
				initial_stock.append({
					"item_definition_id":str(item_id),
					"quantity":int(local_stock[item_id]),
					"unit_price":maxi(1, int(ceil(float(ItemDB.buy_value(str(item_id))) * 1.25)))
				})
			if not initial_stock.is_empty():
				var provisioned: Dictionary = await CentralBackend.server_provision_merchant(merchant_id, str(business.get("name", npc_name)), str(business.get("region_id", "elyndor")), initial_stock)
				if bool(provisioned.get("ok", false)):
					LivingWorldSystem.mark_business_backend_provisioned(npc_name)
					result = await CentralBackend.server_get_merchant_stock(merchant_id)
				else:
					push_warning("Could not provision generated merchant %s in the central ledger." % npc_name)
	if not bool(result.get("ok", false)):
		if peer_id > 1: rpc_id(peer_id, "receive_authoritative_merchant_stock", [])
		return
	var body: Dictionary = result.get("body", {})
	var stock_rows: Array = body.get("stock", [])
	if peer_id > 1:
		rpc_id(peer_id, "receive_authoritative_merchant_stock", stock_rows)
	else:
		var panel := get_tree().get_first_node_in_group("station_panel")
		if panel and panel.has_method("apply_authoritative_merchant_stock"):
			panel.call("apply_authoritative_merchant_stock", stock_rows)

@rpc("authority", "reliable")
func receive_authoritative_merchant_stock(stock_rows: Array) -> void:
	var panel := get_tree().get_first_node_in_group("station_panel")
	if panel and panel.has_method("apply_authoritative_merchant_stock"):
		panel.call("apply_authoritative_merchant_stock", stock_rows)

func commit_local_quest_action(npc: NPC, action: String, quest_id: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode or not is_instance_valid(npc) or not QuestDB.QUESTS.has(quest_id): return
	var character_id := str(local_character_id)
	if character_id.is_empty():
		_notify_network_local("The authoritative character identity is unavailable.", "warning")
		return
	var expected_npc := str(QuestDB.QUESTS[quest_id].get("giver", "")) if action == "quest_accept" else str(QuestDB.QUESTS[quest_id].get("turn_in", ""))
	if expected_npc != npc.npc_name or not is_instance_valid(GameManager.player) or (GameManager.player as Node3D).global_position.distance_to(npc.global_position) > npc.interact_range + 0.75:
		_notify_network_local("Move closer to the correct quest giver.", "warning")
		return
	_complete_server_quest_action(1, npc.get_path(), action, quest_id, character_id, npc.npc_name)

func _complete_server_quest_action(peer_id: int, target_path: NodePath, action: String, quest_id: String, character_id: String, npc_name: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured():
		rpc_id(peer_id, "receive_interaction_validation", target_path, action, quest_id, false, "Authoritative quest service is unavailable.")
		return
	var key := _stable_world_uuid("quest-action:%s:%s:%s" % [character_id, quest_id, action])
	var result: Dictionary
	if action == "quest_accept":
		result = await CentralBackend.server_accept_quest(character_id, quest_id, key)
	else:
		result = await CentralBackend.server_complete_quest(character_id, quest_id, npc_name, key)
	if not bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		var reason := str(body.get("detail", result.get("error", "Quest transaction was rejected.")))
		rpc_id(peer_id, "receive_interaction_validation", target_path, action, quest_id, false, reason)
		return
	if action == "quest_turn_in":
		var response_body: Dictionary = result.get("body", {})
		var reward_payload: Dictionary = response_body.get("result", {}) if response_body.get("result", {}) is Dictionary else {}
		if peer_id > 1: rpc_id(peer_id, "receive_authoritative_quest_reward", reward_payload)
		else: _apply_authoritative_quest_reward(reward_payload)
		await sync_authoritative_inventory_to_peer(peer_id, character_id)
	await sync_authoritative_quests_to_peer(peer_id, character_id)
	if peer_id == 1:
		var local_target: Node = get_tree().root.get_node_or_null(target_path)
		if is_instance_valid(local_target) and local_target.has_method("on_server_interaction_validated"):
			local_target.call("on_server_interaction_validated", action, quest_id)
	else:
		rpc_id(peer_id, "receive_interaction_validation", target_path, action, quest_id, true, "")

func sync_authoritative_quests_to_peer(peer_id: int, character_id: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured(): return
	if peer_id > 1 and not peer_characters.has(peer_id): return
	var result: Dictionary = await CentralBackend.server_get_quests(character_id)
	if not bool(result.get("ok", false)): return
	var rows: Array = result.get("body", {}).get("quests", [])
	if peer_id == 1:
		PlayerData.apply_authoritative_quest_snapshot(rows)
	else:
		rpc_id(peer_id, "apply_authoritative_quest_snapshot", rows)

@rpc("authority", "reliable")
func apply_authoritative_quest_snapshot(rows: Array) -> void:
	if multiplayer.is_server(): return
	PlayerData.apply_authoritative_quest_snapshot(rows)

func sync_authoritative_quests_for_character(character_id: String) -> void:
	if local_character_id == character_id:
		await sync_authoritative_quests_to_peer(1, character_id)
	for peer_id in peer_characters.keys():
		if str(peer_characters[peer_id].get("character_id", "")) == character_id:
			await sync_authoritative_quests_to_peer(int(peer_id), character_id)

@rpc("authority", "reliable")
func receive_authoritative_quest_reward(payload: Dictionary) -> void:
	if multiplayer.is_server(): return
	_apply_authoritative_quest_reward(payload)

func _apply_authoritative_quest_reward(payload: Dictionary) -> void:
	var player: Node = GameManager.player
	var skills_node: Node = player.get("skills") if player else null
	var skill_rewards: Dictionary = payload.get("skills", {}) if payload.get("skills", {}) is Dictionary else {}
	if skills_node:
		for skill_id in skill_rewards.keys():
			skills_node.call("train", str(skill_id), float(skill_rewards[skill_id]), true)
	var title := str(payload.get("title", ""))
	if title != "": PlayerData.grant_title(title)
	var reputation: Node = get_tree().get_first_node_in_group("reputation")
	if reputation and reputation.has_method("add_rep"):
		var rep_rewards: Dictionary = payload.get("reputation", {}) if payload.get("reputation", {}) is Dictionary else {}
		for faction in rep_rewards.keys(): reputation.add_rep(str(faction), int(rep_rewards[faction]))
	if reputation and reputation.has_method("add_affinity"):
		reputation.add_affinity(str(payload.get("giver", "")), 3)

func request_authoritative_merchant_stock(npc_name: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured(): return
	if multiplayer.is_server():
		_send_authoritative_merchant_stock(1, npc_name)

func record_local_quest_event(objective_type: String, target_id: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode or local_character_id.is_empty(): return
	call_deferred("_persist_quest_objective_event", local_character_id, objective_type, target_id)

func request_zone_discovery(zone_name: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	if multiplayer.is_server():
		var character_id := str(local_character_id)
		if not character_id.is_empty(): _persist_quest_objective_event(character_id, "visit", zone_name)
	else:
		rpc_id(1, "server_request_zone_discovery", zone_name)

@rpc("any_peer", "reliable")
func server_request_zone_discovery(zone_name: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode: return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender): return
	var accepted: Vector3 = accepted_positions.get(sender, Vector3(1.0e9, 0.0, 1.0e9))
	var validated := false
	for zone in QuestDB.ZONES:
		if str(zone.get("name", "")) == zone_name:
			var center: Vector2 = zone.get("pos", Vector2.ZERO)
			var radius := float(zone.get("radius", 0.0))
			validated = Vector2(accepted.x, accepted.z).distance_to(center) <= radius + 2.0
			break
	if not validated: return
	var character_id := str(peer_characters[sender].get("character_id", ""))
	var objective_name := "Ironback Range" if zone_name == "Ironback Mountains" else zone_name
	if not character_id.is_empty():
		call_deferred("_persist_quest_objective_event", character_id, "visit", objective_name)

func server_record_quest_event_for_active_peer(objective_type: String, target_id: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured():
		return
	var peer_id := active_combat_peer
	if peer_id <= 0 or (peer_id > 1 and not peer_characters.has(peer_id)):
		return
	var identity: Dictionary = peer_characters.get(peer_id, {})
	var character_id := local_character_id if peer_id == 1 else str(identity.get("character_id", ""))
	if character_id.is_empty():
		return
	call_deferred("_persist_quest_objective_event", character_id, objective_type, target_id)

func _persist_quest_objective_event(character_id: String, objective_type: String, target_id: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured():
		return
	var key := _stable_world_uuid("quest-event:%s:%s:%s:%d" % [character_id, objective_type, target_id, Time.get_ticks_usec()])
	var result: Dictionary = await CentralBackend.server_record_quest_objective(character_id, objective_type, target_id, key)
	if not bool(result.get("ok", false)):
		push_warning("Authoritative quest progress failed: %s" % str(result.get("error", result.get("status", "unknown"))))
	else:
		var response_body: Dictionary = result.get("body", {})
		var event_result: Dictionary = response_body.get("result", {}) if response_body.get("result", {}) is Dictionary else {}
		if not event_result.get("quest_ids", []).is_empty():
			await sync_authoritative_quests_for_character(character_id)

func _stable_world_uuid(value: String) -> String:
	var digest: String = value.sha256_text().substr(0, 32)
	return "%s-%s-%s-%s-%s" % [digest.substr(0, 8), digest.substr(8, 4), digest.substr(12, 4), digest.substr(16, 4), digest.substr(20, 12)]

func _persist_npc_interaction(character_id: String, npc_name: String, interaction_kind: String, payload: Dictionary) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured():
		return
	var npc_id := _stable_world_uuid("%s:npc:%s" % [SINGLE_WORLD_ID, npc_name])
	var result: Dictionary = await CentralBackend.server_record_npc_interaction(character_id, npc_id, "elyndor_heartlands", interaction_kind, payload, _stable_world_uuid("%s:%s:%s:%d" % [character_id, npc_name, interaction_kind, Time.get_ticks_usec()]))
	if not bool(result.get("ok", false)):
		push_warning("NPC interaction persistence failed: %s" % str(result.get("error", result.get("status", "unknown"))))

func persist_world_boss_state(boss_id: String, region_id: String, state: Dictionary) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured() or not multiplayer.is_server():
		return
	var stable_id := _stable_world_uuid("%s:boss:%s" % [SINGLE_WORLD_ID, boss_id])
	var revision := 0
	var existing: Dictionary = await CentralBackend.server_load_bosses()
	if bool(existing.get("ok", false)):
		var body: Dictionary = existing.get("body", {})
		for row_variant in body.get("bosses", []):
			if row_variant is Dictionary and str(row_variant.get("boss_id", "")) == stable_id:
				revision = int(row_variant.get("revision", 0))
				break
	var result: Dictionary = await CentralBackend.server_save_boss_encounter(stable_id, region_id, boss_id, revision, state)
	if not bool(result.get("ok", false)):
		push_warning("World boss persistence failed for %s: %s" % [boss_id, str(result.get("error", result.get("status", "unknown")))])


func sync_authoritative_inventory_to_peer(peer_id: int, character_id: String) -> void:
	if not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured():
		return
	if peer_id > 1 and not peer_characters.has(peer_id):
		return
	if peer_id == 1 and character_id != local_character_id and not peer_characters.has(1):
		return
	var result: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(result.get("ok", false)):
		push_warning("Inventory sync failed for peer %d" % peer_id)
		return
	var body: Dictionary = result.get("body", {})
	if peer_id == 1:
		apply_authoritative_inventory(body)
	else:
		rpc_id(peer_id, "apply_authoritative_inventory", body)


@rpc("authority", "reliable")
func receive_interaction_validation(target_path: NodePath, action: String, detail_id: String, approved: bool, reason: String = "") -> void:
	if not approved:
		_notify_network_local(reason if reason != "" else "The interaction was rejected by the server.", "warning")
		return
	var target: Node = get_tree().root.get_node_or_null(target_path)
	if is_instance_valid(target) and target.has_method("on_server_interaction_validated"):
		target.call("on_server_interaction_validated", action, detail_id)
	else:
		_notify_network_local("That interaction could not be completed.", "warning")

func request_combat_action(origin: Vector3, forward: Vector3, reach: float, requested_damage: float, skill_id: String = "") -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_server_resolve_combat(1, origin, forward, reach, requested_damage, skill_id)
	else:
		rpc_id(1, "server_combat_action", origin, forward, reach, requested_damage, skill_id)

@rpc("any_peer", "unreliable")
func server_combat_action(origin: Vector3, forward: Vector3, reach: float, requested_damage: float, skill_id: String = "") -> void:
	if not multiplayer.is_server():
		return
	_server_resolve_combat(multiplayer.get_remote_sender_id(), origin, forward, reach, requested_damage, skill_id)

func request_elemental_spell(origin: Vector3, forward: Vector3, reach: float, requested_damage: float, energy_cost: float, affinity_skill: String) -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_server_resolve_elemental_spell(1, origin, forward, reach, requested_damage, energy_cost, affinity_skill)
	else:
		rpc_id(1, "server_elemental_spell_action", origin, forward, reach, requested_damage, energy_cost, affinity_skill)

@rpc("any_peer", "unreliable")
func server_elemental_spell_action(origin: Vector3, forward: Vector3, reach: float, requested_damage: float, energy_cost: float, affinity_skill: String) -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	_server_resolve_elemental_spell(sender, origin, forward, reach, requested_damage, energy_cost, affinity_skill)

func _server_resolve_elemental_spell(peer_id: int, origin: Vector3, forward: Vector3, reach: float, requested_damage: float, energy_cost: float, affinity_skill: String) -> void:
	if peer_id != 1 and not peer_characters.has(peer_id):
		return
	if accepted_positions.get(peer_id, origin).distance_to(origin) > 4.0:
		return
	if not SkillSystem.ELEMENT_SKILLS.values().has(affinity_skill):
		return
	var state: Dictionary = cultivation_states.get(peer_id, {"qi": 30.0, "maximum_qi": 30.0, "xp": 0.0, "last": Time.get_ticks_msec() / 1000.0, "origin": origin, "active": false, "accum": 0.0})
	var safe_cost: float = clampf(energy_cost, 1.0, 30.0)
	var qi: float = clampf(float(state.get("qi", 30.0)), 0.0, float(state.get("maximum_qi", 30.0)))
	var maximum_qi: float = clampf(float(state.get("maximum_qi", 30.0)), 1.0, 3000.0)
	if qi < safe_cost:
		return
	state["maximum_qi"] = maximum_qi
	state["qi"] = qi - safe_cost
	cultivation_states[peer_id] = state
	# Elemental magic is part of ordinary RPG progression; it does not grant cultivation.
	if peer_id == 1 and CultivationDiscovery.is_cultivation_unlocked():
		state = _apply_server_cultivation_training(peer_id, 0.045)
	_server_resolve_combat(peer_id, origin, forward, reach, requested_damage)
	if peer_id == 1:
		var host_player: Node = world_root.get_node_or_null("Player") if world_root else null
		if host_player:
			host_player.set("spiritual_energy", float(state.get("qi", 0.0)))
			host_player.set("max_spiritual_energy", float(state.get("maximum_qi", maximum_qi)))
			var host_skills: Node = host_player.get("skills")
			if host_skills:
				host_skills.call("train", "elemental_magic", 0.16, true)
				host_skills.call("train", affinity_skill, 0.22, true)
				if CultivationDiscovery.is_cultivation_unlocked():
					host_skills.call("train", "cultivation", 0.045, true)
	else:
		rpc_id(peer_id, "apply_cultivation_state", float(state.get("qi", 0.0)), float(state.get("maximum_qi", maximum_qi)))
		rpc_id(peer_id, "apply_elemental_training", affinity_skill)

func _server_resolve_combat(peer_id: int, origin: Vector3, forward: Vector3, reach: float, requested_damage: float, skill_id: String = "") -> void:
	if peer_id != 1 and not peer_characters.has(peer_id):
		return
	var accepted: Vector3 = accepted_positions.get(peer_id, origin)
	if accepted.distance_to(origin) > 4.0:
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - float(combat_cooldowns.get(peer_id, 0.0)) < 0.28:
		return
	combat_cooldowns[peer_id] = now
	var safe_reach: float = clampf(reach, 1.0, 24.0)
	var safe_damage: float = clampf(requested_damage, 1.0, 220.0)
	var direction: Vector3 = forward.normalized()
	var best_target: Node3D = null
	var best_distance: float = safe_reach + 0.1
	for enemy_variant in get_tree().get_nodes_in_group("enemy"):
		var enemy := enemy_variant as Node3D
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var offset: Vector3 = enemy.global_position - accepted
		offset.y = 0.0
		var distance: float = offset.length()
		if distance > safe_reach or distance > best_distance:
			continue
		if distance > 0.75 and direction.dot(offset.normalized()) < 0.18:
			continue
		best_target = enemy
		best_distance = distance
	if best_target == null:
		return
	active_combat_peer = peer_id
	best_target.call("take_damage", safe_damage, null)
	active_combat_peer = 0
	var health_node: Node = best_target.get_node_or_null("HealthComponent")
	if health_node:
		rpc("apply_authoritative_enemy_health", NodePath(str(best_target.get_path())), float(health_node.get("current_health")), float(health_node.get("max_health")), bool(health_node.get("is_dead")), str(best_target.get_meta("mmo_world_entity_id", "")))
	if peer_id != 1 and skill_id != "" and skill_id.length() <= 48:
		rpc_id(peer_id, "apply_combat_training", skill_id, 0.12)

@rpc("authority", "reliable")
func apply_elemental_training(affinity_skill: String) -> void:
	if not SkillSystem.ELEMENT_SKILLS.values().has(affinity_skill):
		return
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	var skills_node: Node = player.get("skills") if player else null
	if skills_node:
		skills_node.call("train", "elemental_magic", 0.16, true)
		skills_node.call("train", affinity_skill, 0.22, true)
		skills_node.call("train", "cultivation", 0.045, true)

@rpc("authority", "reliable")
func apply_combat_training(skill_id: String, amount: float) -> void:
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	var skills_node: Node = player.get("skills") if player else null
	if skills_node and skill_id.length() <= 48:
		skills_node.call("train", skill_id, clampf(amount, 0.0, 0.25), true)

@rpc("authority", "call_local", "reliable")
func apply_authoritative_enemy_health(target_path: NodePath, current: float, maximum: float, dead: bool, entity_id: String = "") -> void:
	if multiplayer.is_server():
		return
	var target: Node = null
	if entity_id != "":
		for candidate in get_tree().get_nodes_in_group("enemy"):
			if str(candidate.get_meta("mmo_world_entity_id", "")) == entity_id:
				target = candidate
				break
	if target == null:
		target = get_tree().root.get_node_or_null(target_path)
	if target == null:
		return
	var health_node: Node = target.get_node_or_null("HealthComponent")
	if health_node == null:
		return
	health_node.set("max_health", maximum)
	if dead and not bool(health_node.get("is_dead")):
		health_node.call("take_damage", float(health_node.get("current_health")) + 1.0, null)
	else:
		health_node.set("current_health", current)
		health_node.health_changed.emit(current, maximum)

func submit_cultivation_intent(origin: Vector3, active: bool) -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_server_cultivation_intent(1, origin, active)
	else:
		rpc_id(1, "server_cultivation_intent", origin, active)

@rpc("any_peer", "unreliable")
func server_cultivation_intent(origin: Vector3, active: bool) -> void:
	if multiplayer.is_server():
		_server_cultivation_intent(multiplayer.get_remote_sender_id(), origin, active)

func _apply_server_cultivation_training(peer_id: int, amount: float) -> Dictionary:
	var state: Dictionary = cultivation_states.get(peer_id, {"qi": 30.0, "maximum_qi": 30.0, "base_capacity": 30.0, "cultivation_skill": 0.0, "xp": 0.0, "last": Time.get_ticks_msec() / 1000.0, "origin": Vector3.ZERO, "active": false, "accum": 0.0})
	var old_skill: float = maxf(0.0, float(state.get("cultivation_skill", 0.0)))
	var safe_amount: float = clampf(amount, 0.0, 1.0)
	var gained: float = safe_amount / (1.0 + old_skill * 0.012)
	var new_skill: float = old_skill + gained
	var base_capacity: float = clampf(float(state.get("base_capacity", 30.0)), 1.0, 3000.0)
	state["cultivation_skill"] = new_skill
	state["base_capacity"] = base_capacity
	state["maximum_qi"] = clampf(base_capacity + new_skill * 0.45, 1.0, 3000.0)
	state["qi"] = clampf(float(state.get("qi", 30.0)), 0.0, float(state["maximum_qi"]))
	state["xp"] = maxf(0.0, float(state.get("xp", 0.0))) + gained
	cultivation_states[peer_id] = state
	return state

func _server_cultivation_intent(peer_id: int, origin: Vector3, active: bool) -> void:
	if peer_id != 1 and not peer_characters.has(peer_id):
		return
	# Until discovery records are persisted and validated by the central backend,
	# remote clients cannot self-authorise cultivation by sending an intent RPC.
	if peer_id != 1 or not CultivationDiscovery.is_cultivation_unlocked():
		return
	var accepted: Vector3 = accepted_positions.get(peer_id, origin)
	if accepted.distance_to(origin) > 3.0:
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	var previous_request: float = float(cultivation_request_times.get(peer_id, 0.0))
	if now - previous_request < 0.05:
		return
	cultivation_request_times[peer_id] = now
	var state: Dictionary = cultivation_states.get(peer_id, {"qi": 30.0, "maximum_qi": 30.0, "base_capacity": 30.0, "cultivation_skill": 0.0, "xp": 0.0, "last": now, "origin": origin, "active": false, "accum": 0.0})
	var elapsed: float = clampf(now - float(state.get("last", now)), 0.0, 1.0)
	var previous_origin: Vector3 = state.get("origin", accepted)
	var still: bool = accepted.distance_to(previous_origin) < 0.65
	if active and still:
		var maximum_qi: float = clampf(float(state.get("maximum_qi", 30.0)), 1.0, 3000.0)
		state["maximum_qi"] = maximum_qi
		state["qi"] = minf(maximum_qi, float(state.get("qi", 30.0)) + 1.8 * elapsed)
		state["accum"] = float(state.get("accum", 0.0)) + elapsed
		if float(state.get("accum", 0.0)) >= 2.5:
			state["accum"] = fmod(float(state.get("accum", 0.0)), 2.5)
			cultivation_states[peer_id] = state
			var accumulated_time: float = float(state.get("accum", 0.0))
			state = _apply_server_cultivation_training(peer_id, 0.12)
			state["accum"] = accumulated_time
			if peer_id == 1:
				var host_player: Node = world_root.get_node_or_null("Player") if world_root else null
				if host_player and host_player.get("skills"):
					host_player.get("skills").call("train", "cultivation", 0.12, true)
			else:
				rpc_id(peer_id, "apply_cultivation_reward", 0.12)
	else:
		state["accum"] = 0.0
	state["last"] = now
	state["origin"] = accepted
	state["active"] = active and still
	cultivation_states[peer_id] = state
	if peer_id == 1:
		var player: Node = world_root.get_node_or_null("Player") if world_root else null
		if player:
			player.set("max_spiritual_energy", float(state.get("maximum_qi", 30.0)))
			player.set("spiritual_energy", float(state.get("qi", 30.0)))
	else:
		rpc_id(peer_id, "apply_cultivation_state", float(state.get("qi", 30.0)), float(state.get("maximum_qi", 30.0)))

@rpc("authority", "reliable")
func apply_cultivation_state(qi: float, maximum_qi: float = 30.0) -> void:
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	if player:
		var safe_maximum: float = clampf(maximum_qi, 1.0, 3000.0)
		player.set("max_spiritual_energy", safe_maximum)
		player.set("spiritual_energy", clampf(qi, 0.0, safe_maximum))

@rpc("authority", "reliable")
func apply_cultivation_reward(amount: float) -> void:
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	var skills_node: Node = player.get("skills") if player else null
	if skills_node:
		skills_node.call("train", "cultivation", amount, true)

func request_health_heal(item_id: String, amount: float) -> void:
	if not is_online() or multiplayer.is_server() or item_id.is_empty():
		return
	rpc_id(1, "server_request_health_heal", item_id, clampf(amount, 0.0, 60.0))

@rpc("any_peer", "reliable")
func server_request_health_heal(item_id: String, amount: float) -> void:
	if not multiplayer.is_server() or not ItemDB.has_item(item_id):
		return
	var item_definition: Dictionary = ItemDB.def(item_id)
	if str(item_definition.get("type", "")) != "consumable" or not item_definition.has("heal"):
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender) or not peer_health.has(sender):
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - float(_peer_heal_request_at.get(sender, -1.0)) < 0.65:
		return
	var state: Dictionary = peer_health.get(sender, {"current": 100.0, "maximum": 100.0})
	var maximum: float = clampf(float(state.get("maximum", 100.0)), 1.0, 100000.0)
	var current: float = clampf(float(state.get("current", maximum)), 0.0, maximum)
	var safe_heal: float = clampf(amount, 0.0, minf(60.0, float(item_definition.get("heal", 0.0)) * 1.25))
	if current <= 0.0 or safe_heal <= 0.0 or current >= maximum:
		return
	state["maximum"] = maximum
	state["current"] = minf(maximum, current + safe_heal)
	peer_health[sender] = state
	_peer_heal_request_at[sender] = now
	rpc_id(sender, "receive_server_health", float(state.get("current", current)), maximum)

func _regenerate_remote_players() -> void:
	for peer_variant in peer_health.keys():
		var peer_id: int = int(peer_variant)
		var state: Dictionary = peer_health[peer_id]
		var current: float = clampf(float(state.get("current", 100.0)), 0.0, 100000.0)
		var maximum: float = clampf(float(state.get("maximum", 100.0)), 1.0, 100000.0)
		var now: float = Time.get_ticks_msec() / 1000.0
		if current <= 0.0 or current >= maximum or now - float(state.get("last_damage", 0.0)) < 6.0:
			continue
		state["maximum"] = maximum
		state["current"] = minf(maximum, current + 2.0)
		peer_health[peer_id] = state
		rpc_id(peer_id, "receive_server_health", float(state.get("current", current)), maximum)

func apply_damage_to_peer(peer_id: int, amount: float) -> void:
	if not multiplayer.is_server() or amount <= 0.0:
		return
	if peer_id == 1:
		var host_player: Node = world_root.get_node_or_null("Player") if world_root else null
		if host_player and host_player.has_method("take_damage"):
			host_player.call("take_damage", amount, null)
		return
	if not peer_characters.has(peer_id) or not peer_health.has(peer_id):
		return
	var state: Dictionary = peer_health.get(peer_id, {"current": 100.0, "maximum": 100.0})
	var maximum: float = clampf(float(state.get("maximum", 100.0)), 1.0, 100000.0)
	state["maximum"] = maximum
	state["current"] = maxf(float(state.get("current", maximum)) - clampf(amount, 0.0, 500.0), 0.0)
	state["last_damage"] = Time.get_ticks_msec() / 1000.0
	peer_health[peer_id] = state
	rpc_id(peer_id, "receive_server_health", float(state.get("current", 0.0)), maximum)

func request_respawn() -> void:
	if multiplayer.is_server():
		_server_respawn(1)
	else:
		rpc_id(1, "server_request_respawn")

@rpc("any_peer", "reliable")
func server_request_respawn() -> void:
	if multiplayer.is_server():
		_server_respawn(multiplayer.get_remote_sender_id())

func _server_respawn(peer: int) -> void:
	if WorldDeploymentGuard.production_mode:
		if peer == 1:
			_notify_network_local("Respawn requires an authoritative death-penalty transaction on the production backend.", "warning")
		else:
			rpc_id(peer, "receive_network_notice", "Production respawn is not available until death penalties are backed by a server transaction.", "warning")
		return
	var snapshot: Dictionary = peer_last_snapshots.get(peer, {}).duplicate(true)
	if peer == 1:
		if not is_instance_valid(GameManager.player) or not GameManager.player.health.is_dead:
			return
		snapshot = _build_character_snapshot()
	elif not peer_characters.has(peer) or float(peer_health.get(peer, {}).get("current", 1.0)) > 0.0:
		return
	if peer != 1:
		var gold := maxi(0, int(snapshot.get("gold", 0)))
		snapshot["gold"] = gold - int(ceil(gold * 0.05))
		var equipment: Dictionary = snapshot.get("equipment", {}).duplicate(true)
		for item: Dictionary in equipment.values():
			if not item.is_empty():
				item["dur"] = maxf(0.0, float(item.get("dur", 0.0)) - ItemDB.max_durability(item) * 0.10)
		snapshot["equipment"] = equipment
	var spawn := Constants.SPAWN_XZ
	var terrain := TerrainNoise.new(GameManager.world_seed)
	var destination := Vector3(spawn.x, terrain.get_height(spawn.x, spawn.y) + 0.4, spawn.y)
	var maximum := float(peer_health.get(peer, {}).get("maximum", snapshot.get("max_health", 100.0)))
	peer_health[peer] = {"current": maximum * 0.5, "maximum": maximum, "last_damage": Time.get_ticks_msec() / 1000.0}
	accepted_positions[peer] = destination
	accepted_times[peer] = Time.get_ticks_msec() / 1000.0
	snapshot["health"] = maximum * 0.5
	snapshot["max_health"] = maximum
	snapshot["position"] = [destination.x, destination.y, destination.z]
	peer_last_snapshots[peer] = snapshot
	_store_character_snapshot(str(peer_characters.get(peer, {}).get("character_id", local_character_id)), snapshot)
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	if dungeon:
		dungeon._peer_floors.erase(peer)
	if peer == 1:
		receive_respawn(destination, snapshot)
	else:
		rpc_id(peer, "receive_respawn", destination, snapshot)

@rpc("authority", "reliable")
func receive_respawn(destination: Vector3, snapshot: Dictionary) -> void:
	_apply_character_snapshot(snapshot)
	var dungeon := get_tree().get_first_node_in_group("dungeon_active")
	if dungeon:
		dungeon.receive_dungeon_travel(-1, destination, dungeon._cleared_floors)
	var environment := get_tree().get_first_node_in_group("environment_world")
	if environment:
		environment.restore_from_save({"inside_cave": -1})
	if is_instance_valid(GameManager.player):
		GameManager.player.complete_respawn(destination)

@rpc("authority", "reliable")
func receive_server_health(current: float, maximum: float) -> void:
	var player: Node = world_root.get_node_or_null("Player") if world_root else null
	if player and player.get("health"):
		var health_node: Node = player.get("health")
		var safe_maximum: float = clampf(maximum, 1.0, 100000.0)
		var safe_current: float = clampf(current, 0.0, safe_maximum)
		health_node.set("max_health", safe_maximum)
		health_node.set("current_health", safe_current)
		if safe_current > 0.0:
			health_node.set("is_dead", false)
		elif not bool(health_node.get("is_dead")):
			health_node.set("is_dead", true)
			if health_node.has_signal("died"):
				health_node.died.emit(null)
		if health_node.has_signal("health_changed"):
			health_node.health_changed.emit(safe_current, safe_maximum)

## Shared dynamic residents (for example, children born into NPC households).
func broadcast_world_npc_spawn(npc: Node) -> void:
	if not is_online() or not multiplayer.is_server() or npc == null or not npc is Node3D:
		return
	if not npc.has_meta("mmo_world_entity_id"):
		npc.set_meta("mmo_world_entity_id", "world-npc-%08X" % absi(str(npc.get("npc_name")).hash()))
	var node := npc as Node3D
	var payload := {"id":str(npc.get_meta("mmo_world_entity_id")), "name":str(npc.get("npc_name")), "role":str(npc.get("role")), "position":[node.global_position.x, node.global_position.y, node.global_position.z]}
	rpc("spawn_world_npc_replica", payload)

func send_world_npcs_to_peer(peer_id: int) -> void:
	if not is_online() or not multiplayer.is_server() or peer_id <= 1:
		return
	for npc in get_tree().get_nodes_in_group("mmo_world_npc"):
		if not is_instance_valid(npc) or not npc.has_meta("mmo_world_entity_id"):
			continue
		var node := npc as Node3D
		if node == null: continue
		var payload := {"id":str(npc.get_meta("mmo_world_entity_id")), "name":str(npc.get("npc_name")), "role":str(npc.get("role")), "position":[node.global_position.x, node.global_position.y, node.global_position.z]}
		rpc_id(peer_id, "spawn_world_npc_replica", payload)

@rpc("authority", "reliable")
func spawn_world_npc_replica(payload: Dictionary) -> void:
	if multiplayer.is_server(): return
	var entity_id := str(payload.get("id", ""))
	if entity_id.is_empty(): return
	for existing in get_tree().get_nodes_in_group("mmo_world_npc"):
		if str(existing.get_meta("mmo_world_entity_id", "")) == entity_id: return
	var npc := NPC_SCENE.instantiate()
	npc.set("npc_name", str(payload.get("name", "Villager")))
	npc.set("role", str(payload.get("role", "villager")))
	npc.set_meta("mmo_world_entity_id", entity_id)
	npc.set_meta("network_remote_replica", true)
	var pos: Array = payload.get("position", [0.0, 0.0, 0.0])
	if pos.size() == 3: (npc as Node3D).position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
	var parent: Node = world_root if is_instance_valid(world_root) else get_tree().current_scene
	if parent: parent.add_child(npc)

## Creates a stable shared identity for dynamically spawned world monsters and
## publishes their presentation/combat profile to every connected player.
func broadcast_world_monster_spawn(monster: Node) -> void:
	if not is_online() or not multiplayer.is_server() or monster == null:
		return
	if not monster.has_meta("mmo_world_entity_id"):
		monster.set_meta("mmo_world_entity_id", "world-beast-%d-%08X" % [Time.get_ticks_msec(), randi()])
	var payload: Dictionary = _build_world_monster_payload(monster)
	if not payload.is_empty():
		rpc("spawn_world_monster_replica", payload)

## Full revisioned world-state replication provides a common recovery baseline.
## Feature systems may continue sending optimized snapshots for their local runtime state.
func broadcast_shared_world_state() -> void:
	if not is_online() or not multiplayer.is_server():
		return
	var snapshot: Dictionary = MMORPGWorldState.world_state.duplicate(true)
	for peer_variant in multiplayer.get_peers():
		var peer_id := int(peer_variant)
		if peer_characters.has(peer_id):
			rpc_id(peer_id, "apply_shared_world_state", snapshot, MMORPGWorldState.revision)

func send_shared_world_state_to_peer(peer_id: int) -> void:
	if not is_online() or not multiplayer.is_server() or not peer_characters.has(peer_id):
		return
	rpc_id(peer_id, "apply_shared_world_state", MMORPGWorldState.world_state.duplicate(true), MMORPGWorldState.revision)

@rpc("authority", "reliable")
func apply_shared_world_state(snapshot: Dictionary, state_revision: int) -> void:
	if not is_online() or multiplayer.is_server() or state_revision < _client_shared_world_revision:
		return
	_client_shared_world_revision = state_revision
	MMORPGWorldState.world_state = snapshot.duplicate(true)
	MMORPGWorldState.revision = state_revision
	MMORPGWorldState._last_replicated_revision = state_revision
	MMORPGWorldState._replication_dirty = false

func send_world_monsters_to_peer(peer_id: int) -> void:
	if not is_online() or not multiplayer.is_server() or peer_id <= 1:
		return
	for monster in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(monster) or not monster.has_meta("mmo_world_entity_id"):
			continue
		var health_node: Node = monster.get_node_or_null("HealthComponent")
		if health_node and bool(health_node.get("is_dead")):
			continue
		var payload: Dictionary = _build_world_monster_payload(monster)
		if not payload.is_empty():
			rpc_id(peer_id, "spawn_world_monster_replica", payload)

func _build_world_monster_payload(monster: Node) -> Dictionary:
	if monster == null or not monster.has_meta("mmo_world_entity_id"):
		return {}
	var world_monster: Node3D = monster as Node3D
	if world_monster == null:
		return {}
	var tint_value: Variant = monster.get("body_color")
	var tint: Color = tint_value if typeof(tint_value) == TYPE_COLOR else Color(0.45, 0.48, 0.42)
	var position: Vector3 = world_monster.global_position
	var entity_meta: Dictionary = {}
	for key in ["dungeon_floor", "floor_boss", "raid_boss", "raid_floor", "dungeon_signature_pattern", "world_boss", "world_boss_id", "world_boss_region", "legendary_reward_id", "ecology_apex", "ecology_spawn", "ecology_region", "territory_faction_id", "pack_id"]:
		if monster.has_meta(key):
			entity_meta[key] = monster.get_meta(key)
	return {
		"id":str(monster.get_meta("mmo_world_entity_id")),
		"monster_id":str(monster.get("monster_id")),
		"display_name":str(monster.get("display_name")),
		"is_boss":bool(monster.get("is_boss")),
		"body_color":[tint.r, tint.g, tint.b, tint.a],
		"damage":float(monster.get("damage")),
		"xp_train":float(monster.get("xp_train")),
		"aggro_range":float(monster.get("aggro_range")),
		"leash_range":float(monster.get("leash_range")),
		"move_speed":float(monster.get("move_speed")),
		"attack_range":float(monster.get("attack_range")),
		"max_hp":float(monster.get("max_hp")),
		"growth_rank":int(monster.get("growth_rank")),
		"gold_min":int(monster.get("gold_min")),
		"gold_max":int(monster.get("gold_max")),
		"position":[position.x, position.y, position.z],
		"scale":[world_monster.scale.x, world_monster.scale.y, world_monster.scale.z],
		"meta":entity_meta
	}

func broadcast_world_monster_despawn(monster: Node) -> void:
	if not is_online() or not multiplayer.is_server() or monster == null:
		return
	var entity_id: String = str(monster.get_meta("mmo_world_entity_id", ""))
	if entity_id != "":
		rpc("despawn_world_monster_replica", entity_id)

@rpc("authority", "reliable")
func despawn_world_monster_replica(entity_id: String) -> void:
	if multiplayer.is_server() or entity_id.is_empty():
		return
	for monster in get_tree().get_nodes_in_group("enemy"):
		if str(monster.get_meta("mmo_world_entity_id", "")) != entity_id:
			continue
		var health_node: Node = monster.get_node_or_null("HealthComponent")
		if health_node and not bool(health_node.get("is_dead")):
			health_node.call("take_damage", float(health_node.get("current_health")) + 1.0, null)
		get_tree().create_timer(4.0).timeout.connect(func() -> void:
			if is_instance_valid(monster):
				monster.queue_free()
		)
		return

@rpc("authority", "reliable")
func spawn_world_monster_replica(payload: Dictionary) -> void:
	if multiplayer.is_server():
		return
	var entity_id: String = str(payload.get("id", ""))
	if entity_id.is_empty():
		return
	for existing in get_tree().get_nodes_in_group("enemy"):
		if str(existing.get_meta("mmo_world_entity_id", "")) == entity_id:
			return
	var director: Node = get_tree().get_first_node_in_group("boss_director")
	if director == null:
		return
	var monster: Node = MONSTER_SCENE.instantiate()
	monster.set("monster_id", str(payload.get("monster_id", "grey_wolf")))
	monster.set("display_name", str(payload.get("display_name", "Wandering Beast")))
	monster.set("is_boss", bool(payload.get("is_boss", false)))
	var tint: Array = payload.get("body_color", [0.45, 0.48, 0.42, 1.0])
	if tint.size() >= 3:
		monster.set("body_color", Color(float(tint[0]), float(tint[1]), float(tint[2]), float(tint[3]) if tint.size() > 3 else 1.0))
	for property_name in ["damage", "xp_train", "aggro_range", "leash_range", "move_speed", "attack_range", "max_hp", "growth_rank", "gold_min", "gold_max"]:
		if payload.has(property_name):
			monster.set(property_name, payload[property_name])
	monster.set_meta("mmo_world_entity_id", entity_id)
	monster.set_meta("network_remote_replica", true)
	var meta_value: Variant = payload.get("meta", {})
	if meta_value is Dictionary:
		for key in meta_value.keys():
			monster.set_meta(str(key), meta_value[key])
	var remote_monster: Node3D = monster as Node3D
	if remote_monster == null:
		return
	var pos: Array = payload.get("position", [0.0, 1.0, 0.0])
	if pos.size() == 3:
		remote_monster.position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
	var scale_value: Array = payload.get("scale", [1.0, 1.0, 1.0])
	if scale_value.size() == 3:
		remote_monster.scale = Vector3(float(scale_value[0]), float(scale_value[1]), float(scale_value[2]))
	director.add_child(remote_monster)
	refresh_dungeon_replica_visibility()

func refresh_dungeon_replica_visibility() -> void:
	var dungeon := get_tree().get_first_node_in_group("dungeon")
	for monster in get_tree().get_nodes_in_group("enemy"):
		if bool(monster.get_meta("network_remote_replica", false)) and monster.has_meta("dungeon_floor"):
			monster.visible = dungeon != null and dungeon.inside and dungeon.current_floor == int(monster.get_meta("dungeon_floor"))

func _broadcast_world_entities() -> void:
	var states: Array[Dictionary] = []
	var nodes: Array = get_tree().get_nodes_in_group("mmo_world_npc") + get_tree().get_nodes_in_group("enemy")
	for node_variant in nodes:
		var node := node_variant as Node3D
		if not is_instance_valid(node):
			continue
		var entry: Dictionary = {"path": str(node.get_path()), "p": [node.global_position.x, node.global_position.y, node.global_position.z], "r": node.rotation.y}
		if node.is_in_group("mmo_world_npc"):
			entry["role"] = str(node.get("role"))
		var world_entity_id: String = str(node.get_meta("mmo_world_entity_id", ""))
		if world_entity_id != "":
			entry["id"] = world_entity_id
		var health_node: Node = node.get_node_or_null("HealthComponent")
		if health_node:
			entry["hp"] = float(health_node.get("current_health"))
			entry["max_hp"] = float(health_node.get("max_health"))
			entry["dead"] = bool(health_node.get("is_dead"))
		states.append(entry)
	rpc("apply_world_entity_snapshot", states)

@rpc("authority", "unreliable")
func apply_world_entity_snapshot(states: Array) -> void:
	if multiplayer.is_server():
		return
	for entry_variant in states:
		if typeof(entry_variant) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = entry_variant
		var node: Node3D = null
		var entity_id: String = str(entry.get("id", ""))
		if entity_id != "":
			for candidate in get_tree().get_nodes_in_group("enemy") + get_tree().get_nodes_in_group("mmo_world_npc"):
				if str(candidate.get_meta("mmo_world_entity_id", "")) == entity_id:
					node = candidate as Node3D
					break
		if node == null:
			node = get_tree().root.get_node_or_null(NodePath(str(entry.get("path", "")))) as Node3D
		if not is_instance_valid(node):
			continue
		if entry.has("role") and node.has_method("apply_network_role"):
			node.call("apply_network_role", str(entry.get("role", "villager")))
		var pos: Array = entry.get("p", [])
		if pos.size() == 3:
			node.global_position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
		node.rotation.y = float(entry.get("r", node.rotation.y))
		if entry.has("hp"):
			var health_node: Node = node.get_node_or_null("HealthComponent")
			if health_node:
				health_node.set("max_health", float(entry.get("max_hp", health_node.get("max_health"))))
				var dead: bool = bool(entry.get("dead", false))
				if dead and not bool(health_node.get("is_dead")):
					health_node.call("take_damage", float(health_node.get("current_health")) + 1.0, null)
				elif not dead:
					health_node.set("current_health", float(entry.get("hp", health_node.get("current_health"))))
					health_node.health_changed.emit(health_node.get("current_health"), health_node.get("max_health"))

@rpc("any_peer", "reliable")
func server_create_party() -> void:
	if multiplayer.is_server():
		create_server_party(multiplayer.get_remote_sender_id())

func create_server_party(leader_peer: int) -> String:
	if not multiplayer.is_server():
		return ""
	if peer_party.has(leader_peer):
		return str(peer_party[leader_peer])
	var party_id: String = "WORLD-PARTY-%d" % randi()
	party_records[party_id] = {"leader": leader_peer, "members": [leader_peer], "invites": []}
	peer_party[leader_peer] = party_id
	_broadcast_party(party_id)
	return party_id

func invite_to_party(target_peer: int) -> void:
	if not is_online():
		return
	if multiplayer.is_server():
		_server_invite_to_party(1, target_peer)
	else:
		rpc_id(1, "server_invite_to_party", target_peer)

@rpc("any_peer", "reliable")
func server_invite_to_party(target_peer: int) -> void:
	if multiplayer.is_server():
		_server_invite_to_party(multiplayer.get_remote_sender_id(), target_peer)

func _server_invite_to_party(sender: int, target: int) -> void:
	if sender != 1 and not peer_characters.has(sender):
		return
	var party_id: String = str(peer_party.get(sender, ""))
	if party_id == "":
		party_id = create_server_party(sender)
	if not party_records.has(party_id) or not multiplayer.get_peers().has(target):
		return
	var record: Dictionary = party_records[party_id]
	if record.get("members", []).size() >= PartySystem.MAX_PARTY_SIZE or target == sender:
		return
	if not record.get("invites", []).has(target):
		var party_invites: Array = record.get("invites", []).duplicate()
		party_invites.append(target)
		record["invites"] = party_invites
	party_records[party_id] = record
	rpc_id(target, "receive_party_invite", party_id, str(peer_characters.get(sender, {}).get("display_name", "Cultivator")))

@rpc("authority", "reliable")
func receive_party_invite(party_id: String, leader_name: String) -> void:
	pending_party_invite_id = party_id
	party_invite_received.emit(party_id, leader_name)
	_set_status("Party invitation from %s" % leader_name)

func accept_party_invite(party_id: String) -> void:
	if is_online() and not multiplayer.is_server():
		rpc_id(1, "server_accept_party_invite", party_id)

@rpc("any_peer", "reliable")
func server_accept_party_invite(party_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if not party_records.has(party_id):
		return
	var record: Dictionary = party_records[party_id]
	if not record.get("invites", []).has(sender) or record.get("members", []).size() >= PartySystem.MAX_PARTY_SIZE:
		return
	if peer_party.has(sender):
		return
	var party_invites: Array = record.get("invites", []).duplicate()
	party_invites.erase(sender)
	record["invites"] = party_invites
	var party_members: Array = record.get("members", []).duplicate()
	party_members.append(sender)
	record["members"] = party_members
	party_records[party_id] = record
	peer_party[sender] = party_id
	_broadcast_party(party_id)

func leave_server_party() -> void:
	if is_online() and not multiplayer.is_server():
		rpc_id(1, "server_leave_party")
	elif multiplayer.is_server():
		_server_leave_party(1)

@rpc("any_peer", "reliable")
func server_leave_party() -> void:
	if multiplayer.is_server():
		_server_leave_party(multiplayer.get_remote_sender_id())

func _server_leave_party(peer_id: int) -> void:
	var party_id: String = str(peer_party.get(peer_id, ""))
	if party_id == "" or not party_records.has(party_id):
		return
	var record: Dictionary = party_records[party_id]
	var party_members: Array = record.get("members", []).duplicate()
	party_members.erase(peer_id)
	record["members"] = party_members
	peer_party.erase(peer_id)
	if record.get("members", []).is_empty():
		party_records.erase(party_id)
	else:
		if int(record.get("leader", 1)) == peer_id:
			record["leader"] = int(record.get("members", [1])[0])
		party_records[party_id] = record
		_broadcast_party(party_id)

func _broadcast_world_roster() -> void:
	if not multiplayer.is_server():
		return
	var roster: Dictionary = {}
	if not dedicated_mode:
		roster[1] = local_character_name
	for peer_id in peer_characters.keys():
		roster[int(peer_id)] = str(peer_characters[peer_id].get("display_name", "Wanderer"))
	rpc("apply_world_roster", roster)

@rpc("authority", "call_local", "reliable")
func apply_world_roster(roster: Dictionary) -> void:
	world_roster = roster.duplicate(true)
	world_roster_changed.emit(world_roster)
	_refresh_peer_count()

func get_world_roster_text() -> String:
	if world_roster.is_empty():
		return "World roster: waiting for server"
	var peer_ids: Array = world_roster.keys()
	peer_ids.sort()
	var lines: PackedStringArray = ["Players in this world:"]
	for peer_id in peer_ids:
		lines.append("#%d  %s" % [int(peer_id), str(world_roster[peer_id])])
	return "\n".join(lines)

func _broadcast_party(party_id: String) -> void:
	if not party_records.has(party_id):
		return
	var record: Dictionary = party_records[party_id]
	var names: Array[String] = []
	for member in record.get("members", []):
		if int(member) == 1 and not dedicated_mode:
			names.append(local_character_name)
		else:
			var member_identity: Dictionary = peer_characters.get(int(member), {"display_name": "Cultivator %d" % int(member)})
			names.append(str(member_identity.get("display_name", "Cultivator %d" % int(member))))
	var payload: Dictionary = {"party_id": party_id, "leader": int(record.get("leader", 1)), "members": record.get("members", []).duplicate(), "names": names}
	rpc("apply_party_state", payload)

@rpc("authority", "call_local", "reliable")
func apply_party_state(payload: Dictionary) -> void:
	var party: Node = get_node_or_null("/root/PartySystem")
	if party:
		party.apply_network_party(payload)

func grant_gold_to_combat_peer(amount: int) -> void:
	if not multiplayer.is_server() or amount <= 0:
		return
	if WorldDeploymentGuard.production_mode:
		var character_id: String = local_character_id if active_combat_peer == 1 else str(peer_characters.get(active_combat_peer, {}).get("character_id", ""))
		if character_id.is_empty():
			return
		var event_key := "combat-gold:%s:%d:%d" % [character_id, Time.get_ticks_usec(), amount]
		_commit_shared_currency(active_combat_peer, character_id, amount, "monster_reward", event_key)
		return
	if active_combat_peer == 0 or active_combat_peer == 1:
		PlayerData.add_gold(amount)
	else:
		rpc_id(active_combat_peer, "grant_shared_gold", amount)

@rpc("authority", "reliable")
func grant_shared_gold(amount: int) -> void:
	PlayerData.add_gold(amount)
	submit_character_snapshot(_build_character_snapshot())

func spawn_shared_loot(position: Vector3, item_id: String, count: int) -> void:
	if not multiplayer.is_server() or not ItemDB.has_item(item_id):
		return
	_loot_sequence += 1
	var uid: String = "%s-%d-%d" % [SINGLE_WORLD_ID, Time.get_ticks_msec(), _loot_sequence]
	rpc("create_shared_loot", uid, position, item_id, count)

@rpc("authority", "call_local", "reliable")
func create_shared_loot(uid: String, position: Vector3, item_id: String, count: int) -> void:
	if not ItemDB.has_item(item_id) or world_root == null:
		return
	for existing in get_tree().get_nodes_in_group("loot_drop"):
		if str(existing.get("network_uid")) == uid:
			return
	var drop := LootDrop.new()
	drop.item_id = item_id
	drop.count = maxi(count, 1)
	drop.network_uid = uid
	world_root.add_child(drop)
	drop.global_position = position + Vector3(randf_range(-0.4, 0.4), 0.2, randf_range(-0.4, 0.4))

func request_loot_pickup(uid: String) -> void:
	if not is_online() or uid.is_empty():
		return
	if multiplayer.is_server():
		server_collect_loot(uid, 1)
	else:
		rpc_id(1, "server_request_loot_pickup", uid)

@rpc("any_peer", "reliable")
func server_request_loot_pickup(uid: String) -> void:
	if multiplayer.is_server():
		server_collect_loot(uid, multiplayer.get_remote_sender_id())

func server_collect_loot(uid: String, peer_id: int) -> void:
	if not multiplayer.is_server() or uid.is_empty():
		return
	if peer_id != 1 and not peer_characters.has(peer_id):
		return
	var drop: Node3D = null
	for candidate in get_tree().get_nodes_in_group("loot_drop"):
		if str(candidate.get("network_uid")) == uid:
			drop = candidate as Node3D
			break
	if not is_instance_valid(drop):
		return
	var player_position: Vector3 = accepted_positions.get(peer_id, Vector3.ZERO)
	if peer_id == 1 and world_root:
		var host_player: Node3D = world_root.get_node_or_null("Player") as Node3D
		if is_instance_valid(host_player):
			player_position = host_player.global_position
	if player_position.distance_to(drop.global_position) > 3.5:
		return
	var item_id: String = str(drop.get("item_id"))
	var count: int = int(drop.get("count"))
	if WorldDeploymentGuard.production_mode:
		var character_id: String = local_character_id if peer_id == 1 else str(peer_characters.get(peer_id, {}).get("character_id", ""))
		if character_id.is_empty():
			return
		_commit_shared_loot(uid, peer_id, character_id, item_id, count)
		return
	rpc("despawn_shared_loot", uid)
	if peer_id == 1:
		PlayerData.add_item(item_id, count)
	else:
		rpc_id(peer_id, "grant_shared_loot", item_id, count)

@rpc("authority", "call_local", "reliable")
func despawn_shared_loot(uid: String) -> void:
	for candidate in get_tree().get_nodes_in_group("loot_drop"):
		if str(candidate.get("network_uid")) == uid:
			candidate.queue_free()

@rpc("authority", "reliable")
func grant_shared_loot(item_id: String, count: int) -> void:
	PlayerData.add_item(item_id, count)
	submit_character_snapshot(_build_character_snapshot())


func request_sect_treasury(organization_id: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	if multiplayer.is_server():
		_load_sect_treasury(1, organization_id)
	else:
		rpc_id(1, "server_request_sect_treasury", organization_id)

@rpc("any_peer", "reliable")
func server_request_sect_treasury(organization_id: String) -> void:
	if multiplayer.is_server() and WorldDeploymentGuard.production_mode:
		_load_sect_treasury(multiplayer.get_remote_sender_id(), organization_id)

func _load_sect_treasury(peer_id: int, organization_id: String) -> void:
	var character_id := local_character_id if peer_id == 1 else str(peer_characters.get(peer_id, {}).get("character_id", ""))
	if character_id.is_empty(): return
	var result: Dictionary = await CentralBackend.server_get_organization_treasury(organization_id, character_id)
	if peer_id == 1:
		EventBus.toast.emit("Treasury balance: %s gold" % str(result.get("body", {}).get("balance", 0)) if bool(result.get("ok", false)) else str(result.get("error", "Treasury unavailable")), "info")
	else:
		rpc_id(peer_id, "receive_sect_economy_result", result.get("body", {}), bool(result.get("ok", false)), str(result.get("error", "")))

func request_set_sect_tax(organization_id: String, territory_id: String, tax_basis_points: int, enabled: bool = true) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	if multiplayer.is_server():
		_set_sect_tax(1, organization_id, territory_id, tax_basis_points, enabled)
	else:
		rpc_id(1, "server_request_set_sect_tax", organization_id, territory_id, tax_basis_points, enabled)

@rpc("any_peer", "reliable")
func server_request_set_sect_tax(organization_id: String, territory_id: String, tax_basis_points: int, enabled: bool) -> void:
	if multiplayer.is_server() and WorldDeploymentGuard.production_mode:
		_set_sect_tax(multiplayer.get_remote_sender_id(), organization_id, territory_id, tax_basis_points, enabled)

func _set_sect_tax(peer_id: int, organization_id: String, territory_id: String, tax_basis_points: int, enabled: bool) -> void:
	var character_id := local_character_id if peer_id == 1 else str(peer_characters.get(peer_id, {}).get("character_id", ""))
	if character_id.is_empty() or tax_basis_points < 0 or tax_basis_points > 2500: return
	var result: Dictionary = await CentralBackend.server_set_territory_tax_policy(territory_id, organization_id, character_id, tax_basis_points, enabled)
	if peer_id == 1:
		EventBus.toast.emit("Territory tax policy updated." if bool(result.get("ok", false)) else str(result.get("error", "Tax policy rejected")), "success" if bool(result.get("ok", false)) else "warning")
	else:
		rpc_id(peer_id, "receive_sect_economy_result", result.get("body", {}), bool(result.get("ok", false)), str(result.get("error", "")))

@rpc("authority", "reliable")
func receive_sect_economy_result(payload: Dictionary, success: bool, error_message: String) -> void:
	sect_economy_result_received.emit(payload, success, error_message)
	if success:
		EventBus.toast.emit("Sect treasury: %s gold" % str(payload.get("balance", "updated")), "success")
	else:
		EventBus.toast.emit("Sect economy: %s" % error_message, "warning")

func request_regional_economy(region_id: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session() or region_id.strip_edges().is_empty(): return
	if multiplayer.is_server():
		_load_regional_economy(1, region_id)
	else:
		rpc_id(1, "server_request_regional_economy", region_id)

@rpc("any_peer", "reliable")
func server_request_regional_economy(region_id: String) -> void:
	if multiplayer.is_server() and WorldDeploymentGuard.production_mode:
		_load_regional_economy(multiplayer.get_remote_sender_id(), region_id)

func _load_regional_economy(peer_id: int, region_id: String) -> void:
	var result: Dictionary = await CentralBackend.server_get_regional_economy(region_id)
	if peer_id == 1:
		EventBus.toast.emit("Regional market data loaded." if bool(result.get("ok", false)) else str(result.get("error", "Regional data unavailable")), "info")
	else:
		rpc_id(peer_id, "receive_sect_economy_result", result.get("body", {}), bool(result.get("ok", false)), str(result.get("error", "")))

func request_register_player_sect(sect_id: String, sect_name: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session():
		return
	if multiplayer.is_server():
		_register_player_sect(1, sect_id, sect_name)
	else:
		rpc_id(1, "server_request_register_player_sect", sect_id, sect_name)

@rpc("any_peer", "reliable")
func server_request_register_player_sect(sect_id: String, sect_name: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	_register_player_sect(multiplayer.get_remote_sender_id(), sect_id, sect_name)

func _register_player_sect(peer_id: int, sect_id: String, sect_name: String) -> void:
	var character_id := local_character_id if peer_id == 1 else str(peer_characters.get(peer_id, {}).get("character_id", ""))
	if character_id.is_empty() or not sect_id.begins_with("player_sect_") or sect_name.strip_edges().length() < 3:
		return
	var organization_id := _stable_world_uuid("sect-organization:%s" % sect_id)
	var result: Dictionary = await CentralBackend.server_provision_organization(organization_id, sect_name.strip_edges(), character_id)
	var ok := bool(result.get("ok", false))
	var message := "Your sect is now registered with the shared treasury ledger." if ok else "Sect registration failed: %s" % str(result.get("error", "backend unavailable"))
	if peer_id == 1:
		EventBus.toast.emit(message, "success" if ok else "warning")
	else:
		rpc_id(peer_id, "receive_trade_status", "", message, ok)

func request_player_trade(target_peer_id: int) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session() or target_peer_id <= 1:
		return
	if multiplayer.is_server():
		_open_player_trade(1, target_peer_id)
	else:
		rpc_id(1, "server_request_player_trade", target_peer_id)

@rpc("any_peer", "reliable")
func server_request_player_trade(target_peer_id: int) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 1 or not peer_characters.has(sender) or target_peer_id <= 1 or not peer_characters.has(target_peer_id):
		return
	_open_player_trade(sender, target_peer_id)

func _open_player_trade(initiator_peer: int, target_peer: int) -> void:
	if not multiplayer.is_server() or not peer_characters.has(initiator_peer) or not peer_characters.has(target_peer): return
	var p1: Vector3 = accepted_positions.get(initiator_peer, Vector3(1.0e9, 0.0, 1.0e9))
	var p2: Vector3 = accepted_positions.get(target_peer, Vector3.ZERO)
	if p1.distance_to(p2) > 6.0: return
	var initiator_character := str(peer_characters[initiator_peer].get("character_id", ""))
	var target_character := str(peer_characters[target_peer].get("character_id", ""))
	var result: Dictionary = await CentralBackend.server_open_trade(initiator_character, target_character)
	if not bool(result.get("ok", false)): return
	var trade_id := str(result.get("body", {}).get("trade_id", ""))
	if trade_id.is_empty(): return
	active_trade_sessions[trade_id] = {"initiator_peer": initiator_peer, "target_peer": target_peer, "initiator_character": initiator_character, "target_character": target_character, "offers": {}, "confirmed": {}, "offer_details": {}}
	var initiator_name := str(peer_characters[initiator_peer].get("display_name", "Cultivator"))
	if initiator_peer > 1: rpc_id(initiator_peer, "receive_trade_status", trade_id, "Invitation sent", true)
	else: trade_status_changed.emit(trade_id, "Invitation sent to %s." % str(peer_characters[target_peer].get("display_name", "player")), true)
	if target_peer > 1: rpc_id(target_peer, "receive_trade_invitation", trade_id, initiator_name)

@rpc("authority", "reliable")
func receive_trade_invitation(trade_id: String, initiator_name: String) -> void:
	trade_invitation_received.emit(trade_id, initiator_name)
	EventBus.toast.emit("Trade invitation from %s." % initiator_name, "info")

@rpc("authority", "reliable")
func receive_trade_status(trade_id: String, message: String, success: bool) -> void:
	trade_status_changed.emit(trade_id, message, success)
	EventBus.toast.emit(message, "success" if success else "warning")

func request_accept_trade(trade_id: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	if multiplayer.is_server():
		_accept_player_trade(1, trade_id)
	else:
		rpc_id(1, "server_request_accept_trade", trade_id)

@rpc("any_peer", "reliable")
func server_request_accept_trade(trade_id: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode: return
	_accept_player_trade(multiplayer.get_remote_sender_id(), trade_id)

func _accept_player_trade(peer_id: int, trade_id: String) -> void:
	if not active_trade_sessions.has(trade_id): return
	var session: Dictionary = active_trade_sessions[trade_id]
	if int(session.get("target_peer", 0)) != peer_id: return
	var a: Vector3 = accepted_positions.get(int(session.initiator_peer), Vector3(1.0e9, 0.0, 1.0e9))
	var b: Vector3 = accepted_positions.get(int(session.target_peer), Vector3.ZERO)
	if a.distance_to(b) > 6.0: return
	var result: Dictionary = await CentralBackend.server_accept_trade(trade_id, str(session.target_character))
	if not bool(result.get("ok", false)):
		if peer_id > 1: rpc_id(peer_id, "receive_trade_status", trade_id, "Trade invitation expired or unavailable.", false)
		return
	if peer_id > 1: rpc_id(peer_id, "receive_trade_status", trade_id, "Trade accepted. Both players can submit an offer.", true)
	if int(session.initiator_peer) > 1: rpc_id(int(session.initiator_peer), "receive_trade_status", trade_id, "Trade accepted. Both players can submit an offer.", true)

func request_submit_trade_offer(trade_id: String, item_instance_ids: Array, gold_offer: int, confirmed: bool) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	if multiplayer.is_server():
		_submit_player_trade_offer(1, trade_id, item_instance_ids, gold_offer, confirmed)
	else:
		rpc_id(1, "server_request_submit_trade_offer", trade_id, item_instance_ids, gold_offer, confirmed)

@rpc("any_peer", "reliable")
func server_request_submit_trade_offer(trade_id: String, item_instance_ids: Array, gold_offer: int, confirmed: bool) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode: return
	_submit_player_trade_offer(multiplayer.get_remote_sender_id(), trade_id, item_instance_ids, gold_offer, confirmed)

func _submit_player_trade_offer(peer_id: int, trade_id: String, item_instance_ids: Array, gold_offer: int, confirmed: bool) -> void:
	if not active_trade_sessions.has(trade_id) or gold_offer < 0 or item_instance_ids.size() > 28: return
	var session: Dictionary = active_trade_sessions[trade_id]
	var initiator_peer := int(session.get("initiator_peer", 0))
	var target_peer := int(session.get("target_peer", 0))
	if not peer_characters.has(initiator_peer) or not peer_characters.has(target_peer):
		active_trade_sessions.erase(trade_id)
		return
	var p1: Vector3 = accepted_positions.get(initiator_peer, Vector3(1.0e9, 0.0, 1.0e9))
	var p2: Vector3 = accepted_positions.get(target_peer, Vector3.ZERO)
	if p1.distance_to(p2) > 6.0: return
	var character_id := ""
	var participant_key := ""
	var other_key := ""
	if peer_id == int(session.initiator_peer):
		character_id = str(session.initiator_character); participant_key = "initiator"; other_key = "target"
	elif peer_id == int(session.target_peer):
		character_id = str(session.target_character); participant_key = "target"; other_key = "initiator"
	else: return
	var fingerprint_parts := PackedStringArray()
	for item_id in item_instance_ids: fingerprint_parts.append(str(item_id))
	var fingerprint := ",".join(fingerprint_parts) + ":" + str(gold_offer)
	var offers: Dictionary = session.get("offers", {})
	var confirmed_map: Dictionary = session.get("confirmed", {})
	var offer_details: Dictionary = session.get("offer_details", {})
	if str(offers.get(participant_key, "")) != fingerprint:
		confirmed_map[other_key] = false
		if offer_details.has(other_key):
			var other_offer: Dictionary = offer_details[other_key]
			other_offer["confirmed"] = false
			offer_details[other_key] = other_offer
	offers[participant_key] = fingerprint
	confirmed_map[participant_key] = confirmed
	offer_details[participant_key] = {"item_count": item_instance_ids.size(), "gold": gold_offer, "confirmed": confirmed}
	var result: Dictionary = await CentralBackend.server_submit_trade_offer(trade_id, character_id, item_instance_ids, gold_offer, confirmed)
	if not bool(result.get("ok", false)):
		if peer_id > 1: rpc_id(peer_id, "receive_trade_status", trade_id, "Trade offer rejected by the central inventory ledger.", false)
		return
	session["offers"] = offers
	session["confirmed"] = confirmed_map
	session["offer_details"] = offer_details
	active_trade_sessions[trade_id] = session
	var offer_summary := {"initiator": offer_details.get("initiator", {}), "target": offer_details.get("target", {})}
	for participant in [int(session.initiator_peer), int(session.target_peer)]:
		if participant > 1:
			rpc_id(participant, "receive_trade_offer_summary", trade_id, offer_summary)
	if confirmed_map.get("initiator", false) and confirmed_map.get("target", false):
		var commit_key := _stable_world_uuid("trade-commit:%s" % trade_id)
		var commit: Dictionary = await CentralBackend.server_commit_trade({"trade_id": trade_id, "idempotency_key": commit_key})
		if not bool(commit.get("ok", false)):
			for participant in [int(session.initiator_peer), int(session.target_peer)]:
				if participant > 1: rpc_id(participant, "receive_trade_status", trade_id, "Trade commit failed. No items or currency were transferred.", false)
			return
		await sync_authoritative_inventory_to_peer(int(session.initiator_peer), str(session.initiator_character))
		await sync_authoritative_inventory_to_peer(int(session.target_peer), str(session.target_character))
		await sync_authoritative_quests_to_peer(int(session.initiator_peer), str(session.initiator_character))
		await sync_authoritative_quests_to_peer(int(session.target_peer), str(session.target_character))
		for participant in [int(session.initiator_peer), int(session.target_peer)]:
			if participant > 1: rpc_id(participant, "receive_trade_status", trade_id, "Trade completed. Both inventories are synchronised.", true)
		active_trade_sessions.erase(trade_id)

@rpc("authority", "reliable")
func receive_trade_offer_summary(trade_id: String, summary: Dictionary) -> void:
	var offer_a: Dictionary = summary.get("initiator", {})
	var offer_b: Dictionary = summary.get("target", {})
	trade_status_changed.emit(trade_id, "Initiator: %d items / %d gold (%s). Other player: %d items / %d gold (%s)." % [int(offer_a.get("item_count", 0)), int(offer_a.get("gold", 0)), "confirmed" if bool(offer_a.get("confirmed", false)) else "pending", int(offer_b.get("item_count", 0)), int(offer_b.get("gold", 0)), "confirmed" if bool(offer_b.get("confirmed", false)) else "pending"], true)

func restock_shared_merchants() -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode or not CentralBackend.is_configured(): return
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for business_id in LivingWorldSystem.businesses:
		var business: Dictionary = LivingWorldSystem.businesses[business_id]
		if bool(business.get("closed", false)): continue
		var owner := str(business.get("owner", ""))
		if owner.is_empty(): continue
		if not LivingWorldSystem.BUSINESS_SEEDS.has(business_id) and not bool(business.get("backend_provisioned", false)):
			continue
		var seed_stock: Dictionary = business.get("stock", {})
		var lines: Array = []
		for item_id in seed_stock:
			lines.append({"item_definition_id": str(item_id), "quantity_add": rng.randi_range(1, 3), "stock_cap": 30})
		if lines.is_empty(): continue
		var key := _stable_world_uuid("merchant-restock:%s:%d:%s" % [owner, int(Time.get_unix_time_from_system() / 90.0), str(business_id)])
		var result: Dictionary = await CentralBackend.server_restock_merchant(merchant_uuid_for_npc(owner), lines, key)
		if not bool(result.get("ok", false)):
			push_warning("Shared merchant restock failed for %s" % owner)

func request_authoritative_fishing_catch() -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session(): return
	var request_key := _stable_world_uuid("fishing-catch:%s:%d" % [local_character_id, Time.get_ticks_usec()])
	if multiplayer.is_server():
		_commit_authoritative_fishing_catch(1, local_character_id, request_key)
	else:
		rpc_id(1, "server_request_authoritative_fishing_catch", request_key)

@rpc("any_peer", "reliable")
func server_request_authoritative_fishing_catch(request_key: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode: return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender): return
	_commit_authoritative_fishing_catch(sender, str(peer_characters[sender].get("character_id", "")), request_key)

func _commit_authoritative_fishing_catch(peer_id: int, character_id: String, request_key: String) -> void:
	if character_id.is_empty() or not CentralBackend.is_configured(): return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_last_fishing_request_at.get(peer_id, -999.0)) < 8.0: return
	var position: Vector3 = accepted_positions.get(peer_id, Vector3.ZERO)
	var terrain := TerrainNoise.new(GameManager.world_seed)
	if terrain.get_height(position.x, position.z) > TideSystem.current_level + 3.0: return
	var inventory: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(inventory.get("ok", false)): return
	var inventory_body: Dictionary = inventory.get("body", {})
	var has_rod := false
	for row in inventory_body.get("items", []) + inventory_body.get("equipment", []):
		if row is Dictionary and str(row.get("item_definition_id", "")) == "fishing_rod": has_rod = true
	if not has_rod: return
	_last_fishing_request_at[peer_id] = now
	var ocean := position.x > 30.0 and position.z > -35.0
	var item_id := "fish_trout"
	var best: MarineFish = null
	var best_distance := 14.0
	for creature in get_tree().get_nodes_in_group("marine_life"):
		if creature is MarineFish:
			var distance: float = position.distance_to((creature as Node3D).global_position)
			if distance < best_distance:
				best_distance = distance
				best = creature
	if best:
		item_id = best.try_catch(0.0)
	elif ocean:
		var roll := randf()
		if roll < 0.045: item_id = "fish_angler"
		elif roll < 0.10: item_id = "fish_glowfin"
		elif roll < 0.22: item_id = "fish_swordfish"
		elif roll < 0.43: item_id = "fish_mackerel"
		elif roll < 0.58: item_id = "fish_parrotfish"
		elif roll < 0.70: item_id = "fish_sunfish"
		elif roll < 0.80: item_id = "fish_puffer"
		elif roll < 0.88: item_id = "pearl" if randf() < 0.2 else "coral_fragment"
		elif roll < 0.96: item_id = "seaweed"
		else: item_id = "scale_shard"
	else:
		var roll := randf()
		if roll < 0.08: item_id = "fish_koi"
		elif roll < 0.20: item_id = "fish_bass"
		elif roll < 0.52: item_id = "fish_trout"
		elif roll < 0.68: item_id = "fish_minnow"
		elif roll < 0.82: item_id = "seaweed"
		else: item_id = "scale_shard"
	if not ItemDB.has_item(item_id): return
	var grant: Dictionary = await CentralBackend.server_grant_item(character_id, item_id, 1, request_key)
	if not bool(grant.get("ok", false)): return
	var quest_key := _stable_world_uuid("fishing-quest:%s:%s" % [character_id, request_key])
	await CentralBackend.server_record_quest_objective(character_id, "collect", item_id, quest_key)
	if ElyndorRegionLife and ElyndorRegionLife.has_method("record_fishing"):
		ElyndorRegionLife.record_fishing(item_id)
	await sync_authoritative_inventory_to_peer(peer_id, character_id)
	await sync_authoritative_quests_to_peer(peer_id, character_id)
	if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", true, "You landed %s." % ItemDB.display_name(ItemDB.make(item_id)))

func request_authoritative_craft(recipe_id: String) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session() or not RecipeDB.RECIPES.has(recipe_id):
		return
	var request_key := _stable_world_uuid("craft-request:%s:%s:%d" % [local_character_id, recipe_id, Time.get_ticks_usec()])
	if multiplayer.is_server():
		_commit_authoritative_craft(1, local_character_id, recipe_id, request_key)
	else:
		rpc_id(1, "server_request_authoritative_craft", recipe_id, request_key)

@rpc("any_peer", "reliable")
func server_request_authoritative_craft(recipe_id: String, request_key: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode or not RecipeDB.RECIPES.has(recipe_id):
		return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender): return
	var character_id := str(peer_characters[sender].get("character_id", ""))
	if character_id.is_empty(): return
	_commit_authoritative_craft(sender, character_id, recipe_id, request_key)

func _commit_authoritative_craft(peer_id: int, character_id: String, recipe_id: String, request_key: String) -> void:
	var recipe: Dictionary = RecipeDB.RECIPES.get(recipe_id, {})
	var result: Dictionary = await CentralBackend.server_craft_item(character_id, recipe_id, 1, request_key)
	if not bool(result.get("ok", false)):
		var error_body: Dictionary = result.get("body", {})
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, str(error_body.get("detail", "Crafting materials are insufficient.")))
		return
	await sync_authoritative_inventory_to_peer(peer_id, character_id)
	await sync_authoritative_quests_to_peer(peer_id, character_id)
	if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", true, "Crafting committed. Materials and output updated by the central ledger.")

func merchant_uuid_for_npc(npc_name: String) -> String:
	return _stable_world_uuid("%s:merchant:%s" % [SINGLE_WORLD_ID, npc_name])

func _merchant_sells_item(npc_name: String, item_definition_id: String) -> bool:
	if StationPanel.SHOPS.has(npc_name) and item_definition_id in StationPanel.SHOPS[npc_name]:
		return true
	var business_id := LivingWorldSystem.business_id_for_owner(npc_name)
	return not business_id.is_empty() and LivingWorldSystem.get_business_stock(business_id).has(item_definition_id)

func _is_known_merchant(npc_name: String) -> bool:
	return StationPanel.SHOPS.has(npc_name) or not LivingWorldSystem.business_id_for_owner(npc_name).is_empty()

func request_merchant_purchase(npc_name: String, item_definition_id: String, quantity: int = 1) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session():
		return
	var request_key := _stable_world_uuid("merchant-buy-request:%s:%s:%s:%d:%d" % [local_character_id, npc_name, item_definition_id, quantity, Time.get_ticks_usec()])
	if multiplayer.is_server():
		_commit_merchant_purchase(1, local_character_id, npc_name, item_definition_id, quantity, request_key)
	else:
		rpc_id(1, "server_request_merchant_purchase", npc_name, item_definition_id, quantity, request_key)

@rpc("any_peer", "reliable")
func server_request_merchant_purchase(npc_name: String, item_definition_id: String, quantity: int, request_key: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender):
		return
	var character_id := str(peer_characters[sender].get("character_id", ""))
	if character_id.is_empty() or not _peer_near_merchant(sender, npc_name) or not _merchant_sells_item(npc_name, item_definition_id) or quantity < 1 or quantity > 99:
		rpc_id(sender, "receive_merchant_transaction_result", false, "The merchant transaction was rejected.")
		return
	_commit_merchant_purchase(sender, character_id, npc_name, item_definition_id, quantity, request_key)

func _peer_near_merchant(peer_id: int, npc_name: String) -> bool:
	var accepted: Vector3 = accepted_positions.get(peer_id, Vector3(1.0e9, 0.0, 1.0e9))
	if peer_id == 1 and is_instance_valid(GameManager.player):
		accepted = (GameManager.player as Node3D).global_position
	for npc_variant in get_tree().get_nodes_in_group("npc"):
		if npc_variant is NPC and str(npc_variant.npc_name) == npc_name and accepted.distance_to((npc_variant as NPC).global_position) <= (npc_variant as NPC).interact_range + 1.0:
			return true
	return false

func _commit_merchant_purchase(peer_id: int, character_id: String, npc_name: String, item_definition_id: String, quantity: int, idempotency_key: String) -> void:
	if not _merchant_sells_item(npc_name, item_definition_id) or not _peer_near_merchant(peer_id, npc_name):
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, "The merchant is out of reach or does not sell that item.")
		return
	if not CentralBackend.is_configured():
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, "The central economy is unavailable.")
		return
	var result: Dictionary = await CentralBackend.server_merchant_purchase(character_id, merchant_uuid_for_npc(npc_name), item_definition_id, quantity, idempotency_key)
	if not bool(result.get("ok", false)):
		var body: Dictionary = result.get("body", {})
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, str(body.get("detail", "Purchase rejected by the central merchant ledger.")))
		return
	await sync_authoritative_inventory_to_peer(peer_id, character_id)
	await sync_authoritative_quests_to_peer(peer_id, character_id)
	_record_regional_merchant_purchase(npc_name, item_definition_id, quantity)
	await _send_authoritative_merchant_stock(peer_id, npc_name)
	if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", true, "Purchase committed to Elyndor's shared economy.")

func _record_regional_merchant_purchase(npc_name: String, item_definition_id: String, quantity: int) -> void:
	if not MMORPGNetwork.is_authority() or quantity <= 0:
		return
	var commodity_by_item := {
		"fish_mackerel":"food", "bread":"food", "grain":"food", "healing_potion":"herbs",
		"mana_potion":"herbs", "wood_log":"timber", "iron_ore":"ore", "iron_ingot":"ore"
	}
	var commodity: String = str(commodity_by_item.get(item_definition_id, ""))
	if commodity.is_empty():
		return
	for npc_variant in get_tree().get_nodes_in_group("npc"):
		if npc_variant is NPC and str(npc_variant.npc_name) == npc_name:
			var npc := npc_variant as NPC
			var region_id: String = WorldLifeSimulation.region_id_at(npc.global_position.x, npc.global_position.z)
			if region_id != "":
				WorldLifeSimulation.record_market_sale(region_id, commodity, float(quantity))
			var business_id: String = LivingWorldSystem.business_id_for_owner(npc_name)
			if business_id != "":
				LivingWorldSystem.record_purchase(business_id, item_definition_id, quantity)
			return

func request_merchant_sale(npc_name: String, item_instance_id: String, quantity: int = 1) -> void:
	if not is_online() or not WorldDeploymentGuard.is_production_session() or item_instance_id.is_empty():
		return
	var request_key := _stable_world_uuid("merchant-sell-request:%s:%s:%d:%d" % [local_character_id, item_instance_id, quantity, Time.get_ticks_usec()])
	if multiplayer.is_server():
		_commit_merchant_sale(1, local_character_id, npc_name, item_instance_id, quantity, request_key)
	else:
		rpc_id(1, "server_request_merchant_sale", npc_name, item_instance_id, quantity, request_key)

@rpc("any_peer", "reliable")
func server_request_merchant_sale(npc_name: String, item_instance_id: String, quantity: int, request_key: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender): return
	var character_id := str(peer_characters[sender].get("character_id", ""))
	if character_id.is_empty() or not _peer_near_merchant(sender, npc_name) or not _is_known_merchant(npc_name) or quantity < 1 or quantity > 999:
		rpc_id(sender, "receive_merchant_transaction_result", false, "The merchant transaction was rejected.")
		return
	_commit_merchant_sale(sender, character_id, npc_name, item_instance_id, quantity, request_key)

func _commit_merchant_sale(peer_id: int, character_id: String, npc_name: String, item_instance_id: String, quantity: int, idempotency_key: String) -> void:
	if not _is_known_merchant(npc_name) or not _peer_near_merchant(peer_id, npc_name):
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, "The merchant is out of reach.")
		return
	var inventory: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(inventory.get("ok", false)): return
	var body: Dictionary = inventory.get("body", {})
	var definition_id := ""
	var item_state: Dictionary = {}
	for row_variant in body.get("items", []):
		if row_variant is Dictionary and str(row_variant.get("item_instance_id", "")) == item_instance_id:
			definition_id = str(row_variant.get("item_definition_id", ""))
			item_state = row_variant.get("item_state", {}) if row_variant.get("item_state", {}) is Dictionary else {}
			break
	if definition_id.is_empty() or not ItemDB.has_item(definition_id):
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, "That item is not in your server inventory.")
		return
	var instance := ItemDB.make(definition_id, quantity, int(item_state.get("grade", 0)), float(item_state.get("dur", -1.0)))
	var unit_price := maxi(1, ItemDB.sell_value(instance))
	var result: Dictionary = await CentralBackend.server_merchant_sell(character_id, merchant_uuid_for_npc(npc_name), item_instance_id, quantity, unit_price, idempotency_key)
	if not bool(result.get("ok", false)):
		var error_body: Dictionary = result.get("body", {})
		if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", false, str(error_body.get("detail", "Sale rejected by the central merchant ledger.")))
		return
	await sync_authoritative_inventory_to_peer(peer_id, character_id)
	await _send_authoritative_merchant_stock(peer_id, npc_name)
	if peer_id > 1: rpc_id(peer_id, "receive_merchant_transaction_result", true, "Sale committed to Elyndor's shared economy.")

@rpc("authority", "reliable")
func receive_merchant_transaction_result(success: bool, message: String) -> void:
	EventBus.toast.emit(message, "success" if success else "warning")
	var panel := get_tree().get_first_node_in_group("station_panel")
	if panel and panel.get("is_open"):
		panel.call_deferred("_refresh")

func request_equipment_change(slot_id: String, item_instance_id: String) -> void:
	if not is_online() or multiplayer.is_server():
		return
	var request_key := "equip:%d:%s" % [Time.get_ticks_usec(), item_instance_id]
	rpc_id(1, "server_request_equipment_change", slot_id, item_instance_id, request_key)

@rpc("any_peer", "reliable")
func server_request_equipment_change(slot_id: String, item_instance_id: String, idempotency_key: String) -> void:
	if not multiplayer.is_server() or not WorldDeploymentGuard.production_mode:
		return
	var sender := multiplayer.get_remote_sender_id()
	if not peer_characters.has(sender) or not ["weapon", "armor"].has(slot_id):
		return
	var character_id := str(peer_characters[sender].get("character_id", ""))
	_commit_equipment_change(sender, character_id, slot_id, item_instance_id, idempotency_key)

func _commit_equipment_change(peer_id: int, character_id: String, slot_id: String, item_instance_id: String, idempotency_key: String) -> void:
	if not item_instance_id.is_empty():
		var current_inventory: Dictionary = await CentralBackend.server_get_inventory(character_id)
		if not bool(current_inventory.get("ok", false)):
			return
		var inventory_body: Dictionary = current_inventory.get("body", {})
		var item_definition := ""
		for item_variant in inventory_body.get("items", []):
			if item_variant is Dictionary and str(item_variant.get("item_instance_id", "")) == item_instance_id:
				item_definition = str(item_variant.get("item_definition_id", ""))
				break
		if item_definition.is_empty() or str(ItemDB.def(item_definition).get("type", "")) != slot_id:
			return
	var result: Dictionary = await CentralBackend.server_change_equipment(character_id, slot_id, item_instance_id, idempotency_key)
	if not bool(result.get("ok", false)):
		push_warning("[MMORPGNetwork] Equipment transaction rejected: %s" % str(result.get("error", result.get("body", {}))))
		return
	var inventory_result: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(inventory_result.get("ok", false)):
		push_error("[MMORPGNetwork] Equipment committed but inventory refresh failed.")
		return
	rpc_id(peer_id, "apply_authoritative_inventory", inventory_result.get("body", {}))

func _commit_shared_loot(uid: String, peer_id: int, character_id: String, item_id: String, count: int) -> void:
	var idempotency_key := "loot:%s:%s" % [uid, character_id]
	var grant_result: Dictionary = await CentralBackend.server_grant_item(character_id, item_id, count, idempotency_key)
	if not bool(grant_result.get("ok", false)):
		push_error("[MMORPGNetwork] Database loot grant failed; shared drop remains available: %s" % str(grant_result.get("error", grant_result.get("body", {}))))
		return
	var quest_key := _stable_world_uuid("quest-loot:%s:%s" % [character_id, uid])
	var quest_event: Dictionary = await CentralBackend.server_record_quest_objective(character_id, "collect", item_id, quest_key, "*", count)
	var quest_event_body: Dictionary = quest_event.get("body", {})
	var quest_event_result: Dictionary = quest_event_body.get("result", {}) if quest_event_body.get("result", {}) is Dictionary else {}
	if not quest_event_result.get("quest_ids", []).is_empty():
		await sync_authoritative_quests_to_peer(peer_id, character_id)
	var inventory_result: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(inventory_result.get("ok", false)):
		push_error("[MMORPGNetwork] Loot committed but inventory refresh failed; retrying pickup will safely replay the same transaction.")
		return
	rpc("despawn_shared_loot", uid)
	var inventory_body: Dictionary = inventory_result.get("body", {})
	if peer_id == 1:
		apply_authoritative_inventory(inventory_body)
	else:
		rpc_id(peer_id, "apply_authoritative_inventory", inventory_body)

func _commit_shared_currency(peer_id: int, character_id: String, amount: int, reason: String, idempotency_key: String) -> void:
	var result: Dictionary = await CentralBackend.server_change_currency(character_id, amount, reason, idempotency_key)
	if not bool(result.get("ok", false)):
		push_error("[MMORPGNetwork] Database currency transaction failed: %s" % str(result.get("error", result.get("body", {}))))
		return
	var inventory_result: Dictionary = await CentralBackend.server_get_inventory(character_id)
	if not bool(inventory_result.get("ok", false)):
		push_error("[MMORPGNetwork] Currency committed but balance refresh failed.")
		return
	var inventory_body: Dictionary = inventory_result.get("body", {})
	if peer_id == 1:
		apply_authoritative_inventory(inventory_body)
	else:
		rpc_id(peer_id, "apply_authoritative_inventory", inventory_body)

@rpc("authority", "call_local", "reliable")
func apply_authoritative_inventory(payload: Dictionary) -> void:
	var next_slots: Array = []
	for _slot in range(PlayerData.SLOT_COUNT):
		next_slots.append({})
	var next_item_ids: Dictionary = {}
	var item_by_instance: Dictionary = {}
	for item_variant in payload.get("items", []):
		if not item_variant is Dictionary:
			continue
		var item: Dictionary = item_variant.duplicate(true)
		var slot_value: Variant = item.get("slot_index", null)
		var slot_index := int(slot_value) if slot_value != null else -1
		var saved_item_state: Dictionary = item.get("item_state", {}) if item.get("item_state", {}) is Dictionary else {}
		var item_id := str(item.get("item_definition_id", ""))
		var item_grade := clampi(int(saved_item_state.get("grade", 0)), 0, ItemDB.GRADES.size() - 1)
		var item_state: Dictionary = ItemDB.make(item_id, int(item.get("quantity", 1)), item_grade, float(saved_item_state.get("dur", -1.0)))
		for state_key in saved_item_state.keys():
			item_state[state_key] = saved_item_state[state_key]
		item_state["id"] = item_id
		item_state["count"] = int(item.get("quantity", 1))
		item_state["item_instance_id"] = str(item.get("item_instance_id", ""))
		if slot_index >= 0 and slot_index < next_slots.size():
			next_slots[slot_index] = item_state
			next_item_ids[slot_index] = str(item.get("item_instance_id", ""))
		item_by_instance[str(item.get("item_instance_id", ""))] = item_state
	PlayerData.slots = next_slots
	PlayerData.authoritative_item_instance_ids = next_item_ids
	var next_equipment: Dictionary = {"weapon": {}, "armor": {}}
	for equipment_variant in payload.get("equipment", []):
		if not equipment_variant is Dictionary:
			continue
		var equipment: Dictionary = equipment_variant
		var slot_id := str(equipment.get("slot_id", ""))
		var instance_id := str(equipment.get("item_instance_id", ""))
		if next_equipment.has(slot_id) and item_by_instance.has(instance_id):
			next_equipment[slot_id] = item_by_instance[instance_id].duplicate(true)
	PlayerData.equipment = next_equipment
	PlayerData.gold = maxi(0, int(payload.get("gold", 0)))
	PlayerData.inventory_changed.emit()
	PlayerData.equipment_changed.emit()
	PlayerData.gold_changed.emit(PlayerData.gold)

func _set_status(message: String) -> void:
	status_message = message
	network_status_changed.emit(message)
	print("[MMORPG] ", message)

func get_online_player_count() -> int:
	if not is_online():
		return 0
	if multiplayer.is_server():
		return peer_characters.size() + (0 if dedicated_mode else 1)
	if not world_roster.is_empty():
		return world_roster.size()
	# A connected client is not counted as a confirmed world member until the
	# authoritative roster arrives from the server.
	return 0

func _refresh_peer_count() -> void:
	peer_count_changed.emit(get_online_player_count())
