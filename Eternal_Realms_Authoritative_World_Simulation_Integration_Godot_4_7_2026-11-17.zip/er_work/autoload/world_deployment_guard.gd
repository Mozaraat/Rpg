extends Node
## Global deployment lease guard.
## Production servers must acquire a lease from the central control plane before hosting.
## The API must implement atomic compare-and-set lease ownership in its database.

signal lease_status_changed(active: bool, message: String)

const WORLD_ID: String = "eternal-realms-one-world"
const LEASE_DURATION_SECONDS: int = 90
const RENEW_INTERVAL_SECONDS: float = 25.0

var production_mode: bool = false
var production_client_mode: bool = false
var lease_active: bool = false
var lease_id: String = ""
var server_instance_id: String = ""
var api_base_url: String = ""
var api_token: String = ""
var _renew_clock: float = 0.0
var _request_in_flight: bool = false

func _ready() -> void:
	production_mode = OS.get_environment("ER_PRODUCTION_SERVER") == "1"
	production_client_mode = OS.get_environment("ER_PRODUCTION_CLIENT") == "1"
	api_base_url = OS.get_environment("ER_CONTROL_PLANE_URL").strip_edges().trim_suffix("/")
	api_token = OS.get_environment("ER_CONTROL_PLANE_TOKEN")
	server_instance_id = OS.get_environment("ER_SERVER_INSTANCE_ID").strip_edges()
	if server_instance_id.is_empty():
		server_instance_id = "%s-%s" % [OS.get_name().validate_filename(), str(OS.get_process_id())]

func is_production_session() -> bool:
	return production_mode or production_client_mode

func _process(delta: float) -> void:
	if not production_mode or not lease_active or _request_in_flight:
		return
	_renew_clock += delta
	if _renew_clock >= RENEW_INTERVAL_SECONDS:
		_renew_clock = 0.0
		renew_global_lease()

func acquire_global_lease() -> bool:
	if not production_mode:
		return true
	if not _configuration_valid():
		push_error("[WorldDeploymentGuard] Production server blocked: configure HTTPS control-plane URL, token and instance ID.")
		lease_status_changed.emit(false, "Production server blocked: global world lease is not configured.")
		return false
	var response: Dictionary = await _post_json("/v1/world/lease/acquire", {
		"world_id": WORLD_ID,
		"server_instance_id": server_instance_id,
		"lease_duration_seconds": LEASE_DURATION_SECONDS
	})
	if not bool(response.get("ok", false)):
		push_error("[WorldDeploymentGuard] Global world lease acquisition failed.")
		lease_status_changed.emit(false, "Could not acquire the global Elyndor lease.")
		return false
	var body: Dictionary = response.get("body", {})
	if str(body.get("world_id", "")) != WORLD_ID or str(body.get("server_instance_id", "")) != server_instance_id:
		push_error("[WorldDeploymentGuard] Control plane returned mismatched lease ownership.")
		return false
	lease_id = str(body.get("lease_id", ""))
	if lease_id.is_empty():
		push_error("[WorldDeploymentGuard] Control plane returned no lease ID.")
		return false
	lease_active = true
	_renew_clock = 0.0
	lease_status_changed.emit(true, "Global Elyndor lease acquired.")
	return true

func renew_global_lease() -> void:
	if not production_mode or not lease_active or lease_id.is_empty() or _request_in_flight:
		return
	var response: Dictionary = await _post_json("/v1/world/lease/renew", {
		"world_id": WORLD_ID,
		"server_instance_id": server_instance_id,
		"lease_id": lease_id,
		"lease_duration_seconds": LEASE_DURATION_SECONDS
	})
	if not bool(response.get("ok", false)):
		lease_active = false
		lease_status_changed.emit(false, "Global Elyndor lease lost; authoritative server is shutting down.")
		push_error("[WorldDeploymentGuard] Lease renewal failed. Stopping to prevent a duplicate world.")
		if is_instance_valid(MMORPGNetwork) and MMORPGNetwork.is_online() and multiplayer.is_server():
			MMORPGNetwork.stop_network()
		return
	lease_status_changed.emit(true, "Global Elyndor lease renewed.")

func release_global_lease() -> void:
	if not production_mode or not lease_active or lease_id.is_empty():
		return
	var old_lease_id: String = lease_id
	lease_active = false
	lease_id = ""
	await _post_json("/v1/world/lease/release", {
		"world_id": WORLD_ID,
		"server_instance_id": server_instance_id,
		"lease_id": old_lease_id
	})
	lease_status_changed.emit(false, "Global Elyndor lease released.")

func can_start_production_server() -> bool:
	return not production_client_mode and (not production_mode or lease_active)

func _configuration_valid() -> bool:
	return api_base_url.begins_with("https://") and not api_token.is_empty() and not server_instance_id.is_empty()

func _post_json(path: String, payload: Dictionary) -> Dictionary:
	if _request_in_flight:
		return {"ok": false, "error": "request_in_flight"}
	_request_in_flight = true
	var http := HTTPRequest.new()
	add_child(http)
	http.timeout = 8.0
	var headers := PackedStringArray([
		"Content-Type: application/json",
		"Authorization: Bearer " + api_token
	])
	var error: Error = http.request(api_base_url + path, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if error != OK:
		http.queue_free()
		_request_in_flight = false
		return {"ok": false, "error": error_string(error)}
	var result: Array = await http.request_completed
	http.queue_free()
	_request_in_flight = false
	var response_code: int = int(result[1])
	var response_text: String = (result[3] as PackedByteArray).get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(response_text)
	if response_code < 200 or response_code >= 300 or typeof(parsed) != TYPE_DICTIONARY:
		return {"ok": false, "status": response_code, "error": response_text.substr(0, 256)}
	return {"ok": true, "body": parsed as Dictionary}
