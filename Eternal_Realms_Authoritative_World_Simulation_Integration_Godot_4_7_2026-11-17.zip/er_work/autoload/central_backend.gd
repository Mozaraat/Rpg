extends Node
## HTTPS client for the central Elyndor backend.
## Access/refresh tokens are passed by callers and are never persisted by this autoload.

var base_url: String = ""
var service_token: String = ""
var pending_join_ticket: String = ""
var production_mode: bool = false

func _ready() -> void:
	production_mode = OS.get_environment("ER_PRODUCTION_SERVER") == "1"
	base_url = OS.get_environment("ER_BACKEND_URL").strip_edges().trim_suffix("/")
	if base_url.is_empty():
		base_url = OS.get_environment("ER_CONTROL_PLANE_URL").strip_edges().trim_suffix("/")
	service_token = OS.get_environment("ER_CONTROL_PLANE_TOKEN")

func is_configured() -> bool:
	return base_url.begins_with("https://") and not service_token.is_empty()

func request_json(method: int, path: String, payload: Dictionary = {}, bearer_token: String = "") -> Dictionary:
	if base_url.is_empty() or (production_mode and not base_url.begins_with("https://")):
		return {"ok": false, "error": "Central backend HTTPS URL is not configured."}
	var http := HTTPRequest.new()
	add_child(http)
	http.timeout = 12.0
	var headers := PackedStringArray(["Content-Type: application/json"])
	if not bearer_token.is_empty():
		headers.append("Authorization: Bearer " + bearer_token)
	var body := "" if method == HTTPClient.METHOD_GET else JSON.stringify(payload)
	var request_error: Error = http.request(base_url + path, headers, method, body)
	if request_error != OK:
		http.queue_free()
		return {"ok": false, "error": error_string(request_error)}
	var result: Array = await http.request_completed
	http.queue_free()
	var status_code := int(result[1])
	var response_text := (result[3] as PackedByteArray).get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(response_text)
	if typeof(parsed) != TYPE_DICTIONARY:
		return {"ok": false, "status": status_code, "error": "Backend returned an invalid response."}
	return {"ok": status_code >= 200 and status_code < 300, "status": status_code, "body": parsed}

func register_account(email: String, password: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/auth/register", {"email": email, "password": password})

func login(email: String, password: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/auth/login", {"email": email, "password": password})

func refresh_session(refresh_token: String) -> Dictionary:
	var http := HTTPRequest.new()
	add_child(http)
	http.timeout = 12.0
	var headers := PackedStringArray(["X-Refresh-Token: " + refresh_token])
	var err := http.request(base_url + "/v1/auth/refresh", headers, HTTPClient.METHOD_POST, "")
	if err != OK:
		http.queue_free()
		return {"ok": false, "error": error_string(err)}
	var result: Array = await http.request_completed
	http.queue_free()
	var status := int(result[1])
	var parsed: Variant = JSON.parse_string((result[3] as PackedByteArray).get_string_from_utf8())
	return {"ok": status >= 200 and status < 300 and parsed is Dictionary, "status": status, "body": parsed if parsed is Dictionary else {}}

func list_characters(access_token: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/characters", {}, access_token)

func create_character(access_token: String, display_name: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters", {"display_name": display_name}, access_token)

func get_character(access_token: String, character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/characters/" + character_id.uri_encode(), {}, access_token)

func save_character(access_token: String, character_id: String, revision: int, state: Dictionary) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/characters/" + character_id.uri_encode(), {"revision": revision, "state": state}, access_token)

func get_inventory(access_token: String, character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/characters/" + character_id.uri_encode() + "/inventory", {}, access_token)

func move_inventory(access_token: String, character_id: String, item_id: String, slot: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters/" + character_id.uri_encode() + "/inventory/move", {"item_instance_id": item_id, "destination_slot": slot, "idempotency_key": idempotency_key}, access_token)

func change_equipment(access_token: String, character_id: String, slot_id: String, item_id: String, idempotency_key: String) -> Dictionary:
	var item_value: Variant = item_id if not item_id.is_empty() else null
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters/" + character_id.uri_encode() + "/equipment", {"slot_id": slot_id, "item_instance_id": item_value, "idempotency_key": idempotency_key}, access_token)

func server_get_character(character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/characters/" + character_id.uri_encode(), {}, service_token)

func server_save_character(character_id: String, revision: int, state: Dictionary) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/characters/" + character_id.uri_encode(), {"character_id": character_id, "revision": revision, "state": state}, service_token)

func server_grant_item(character_id: String, definition_id: String, quantity: int, idempotency_key: String, item_state: Dictionary = {}) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/inventory/grant", {"character_id": character_id, "item_definition_id": definition_id, "quantity": quantity, "item_state": item_state, "idempotency_key": idempotency_key}, service_token)

func server_change_currency(character_id: String, amount: int, reason: String, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/currency/change", {"character_id": character_id, "amount": amount, "reason": reason, "idempotency_key": idempotency_key}, service_token)

func create_join_ticket(access_token: String, character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters/" + character_id.uri_encode() + "/join-ticket", {}, access_token)

func consume_join_ticket(join_ticket: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/characters/consume-join-ticket", {"join_ticket": join_ticket}, service_token)

func prepare_character_connection(access_token: String, character_id: String) -> Dictionary:
	var character_result := await get_character(access_token, character_id)
	if not bool(character_result.get("ok", false)):
		return character_result
	var ticket_result := await create_join_ticket(access_token, character_id)
	if not bool(ticket_result.get("ok", false)):
		return ticket_result
	var character_data: Dictionary = character_result.get("body", {})
	var ticket_data: Dictionary = ticket_result.get("body", {})
	pending_join_ticket = str(ticket_data.get("join_ticket", ""))
	if pending_join_ticket.is_empty():
		return {"ok": false, "error": "Backend did not issue a join ticket."}
	MMORPGNetwork.local_character_id = character_id
	MMORPGNetwork.local_character_name = str(character_data.get("display_name", "Wanderer"))
	return {"ok": true, "character": character_data}

func server_get_quests(character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/characters/" + character_id.uri_encode() + "/quests", {}, service_token)

func server_get_inventory(character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/characters/" + character_id.uri_encode() + "/inventory", {}, service_token)

func server_change_equipment(character_id: String, slot_id: String, item_id: String, idempotency_key: String) -> Dictionary:
	var item_value: Variant = item_id if not item_id.is_empty() else null
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/equipment/change", {"character_id": character_id, "slot_id": slot_id, "item_instance_id": item_value, "idempotency_key": idempotency_key}, service_token)

func logout(access_token: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/auth/logout", {}, access_token)

func consume_inventory(access_token: String, character_id: String, item_id: String, quantity: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters/" + character_id.uri_encode() + "/inventory/consume", {"item_instance_id": item_id, "quantity": quantity, "idempotency_key": idempotency_key}, access_token)

func craft_item(access_token: String, character_id: String, recipe_id: String, quantity: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/characters/" + character_id.uri_encode() + "/craft", {"recipe_id": recipe_id, "quantity": quantity, "idempotency_key": idempotency_key}, access_token)

func server_accept_quest(character_id: String, quest_id: String, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/quests/accept", {"character_id": character_id, "quest_id": quest_id, "idempotency_key": idempotency_key}, service_token)

func server_record_quest_objective(character_id: String, objective_type: String, target_id: String, idempotency_key: String, quest_id: String = "*", amount: int = 1) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/quests/objective-event", {"character_id": character_id, "quest_id": quest_id, "objective_type": objective_type, "target_id": target_id, "amount": amount, "idempotency_key": idempotency_key}, service_token)

func server_complete_quest(character_id: String, quest_id: String, npc_name: String, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/quests/turn-in", {"character_id": character_id, "quest_id": quest_id, "npc_name": npc_name, "idempotency_key": idempotency_key}, service_token)

func server_provision_merchant(merchant_id: String, merchant_name: String, region_id: String, stock: Array) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/merchants/provision", {"merchant_id": merchant_id, "merchant_name": merchant_name, "region_id": region_id, "stock": stock}, service_token)

func server_restock_merchant(merchant_id: String, items: Array, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/merchant/restock", {"merchant_id": merchant_id, "items": items, "idempotency_key": idempotency_key}, service_token)

func server_merchant_sell(character_id: String, merchant_id: String, item_instance_id: String, quantity: int, unit_price: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/merchant/sell", {"character_id": character_id, "merchant_id": merchant_id, "item_instance_id": item_instance_id, "quantity": quantity, "unit_price": unit_price, "idempotency_key": idempotency_key}, service_token)

func server_save_territory_snapshot(territories: Array) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/territories/bulk", {"territories": territories}, service_token)

func server_load_territories() -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/territories", {}, service_token)

func server_load_populations() -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/world/populations", {}, service_token)

func server_load_bosses() -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/world/bosses", {}, service_token)

func server_open_trade(initiator_character_id: String, target_character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/trades/open", {"initiator_character_id": initiator_character_id, "target_character_id": target_character_id}, service_token)

func server_accept_trade(trade_id: String, target_character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/trades/accept", {"trade_id": trade_id, "target_character_id": target_character_id}, service_token)

func server_submit_trade_offer(trade_id: String, character_id: String, item_ids: Array, gold: int, confirmed: bool) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/trades/offer", {"trade_id": trade_id, "actor_character_id": character_id, "item_ids": item_ids, "gold": gold, "confirmed": confirmed}, service_token)

func server_commit_trade(payload: Dictionary) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/trades/commit", payload, service_token)

func server_save_quest_state(character_id: String, quest_id: String, quest_state: Dictionary, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/quests/state", {"character_id": character_id, "quest_id": quest_id, "quest_state": quest_state, "idempotency_key": idempotency_key}, service_token)

func server_save_world_entity(entity_id: String, entity_kind: String, region_id: String, revision: int, entity_state: Dictionary, idempotency_key: String = "") -> Dictionary:
	var payload := {"entity_id": entity_id, "entity_kind": entity_kind, "region_id": region_id, "revision": revision, "entity_state": entity_state}
	var effective_key := idempotency_key
	if effective_key.is_empty():
		effective_key = (entity_id + ":" + str(revision) + ":" + JSON.stringify(entity_state)).sha256_text()
	payload["idempotency_key"] = effective_key
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/world/entities/" + entity_id.uri_encode(), payload, service_token)

func server_load_world_entities(entity_kind: String = "", region_id: String = "") -> Dictionary:
	var query := ""
	if not entity_kind.is_empty(): query = "?entity_kind=" + entity_kind.uri_encode()
	if not region_id.is_empty(): query += ("&" if not query.is_empty() else "?") + "region_id=" + region_id.uri_encode()
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/world/entities" + query, {}, service_token)

func server_load_region_entities(region_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/world/regions/" + region_id.uri_encode() + "/entities", {}, service_token)

func server_craft_item(character_id: String, recipe_id: String, quantity: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/crafting/craft", {"character_id": character_id, "recipe_id": recipe_id, "quantity": quantity, "idempotency_key": idempotency_key}, service_token)

func server_merchant_purchase(character_id: String, merchant_id: String, item_definition_id: String, quantity: int, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/merchant/purchase", {"character_id": character_id, "merchant_id": merchant_id, "item_definition_id": item_definition_id, "quantity": quantity, "idempotency_key": idempotency_key}, service_token)

func server_record_npc_interaction(character_id: String, npc_id: String, region_id: String, interaction_type: String, payload: Dictionary, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/npc/interactions", {"character_id": character_id, "npc_id": npc_id, "region_id": region_id, "interaction_type": interaction_type, "payload": payload, "idempotency_key": idempotency_key}, service_token)

func server_save_population_snapshot(populations: Array) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/world/populations/bulk", {"populations": populations}, service_token)

func server_save_monster_population(region_id: String, species_id: String, revision: int, population_state: Dictionary) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/world/populations", {"region_id": region_id, "species_id": species_id, "revision": revision, "population_state": population_state}, service_token)

func server_save_boss_encounter(boss_id: String, region_id: String, boss_definition_id: String, revision: int, encounter_state: Dictionary) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/world/bosses/" + boss_id.uri_encode(), {"boss_id": boss_id, "region_id": region_id, "boss_definition_id": boss_definition_id, "revision": revision, "encounter_state": encounter_state}, service_token)

func get_character_quests(access_token: String, character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/characters/" + character_id.uri_encode() + "/quests", {}, access_token)

func server_get_merchant_stock(merchant_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/merchants/" + merchant_id.uri_encode() + "/stock", {}, service_token)

func get_merchant_stock(access_token: String, merchant_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/merchants/" + merchant_id.uri_encode() + "/stock", {}, access_token)

func server_set_territory_tax_policy(territory_id: String, organization_id: String, actor_character_id: String, tax_basis_points: int, enabled: bool) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/territories/tax-policy", {"territory_id": territory_id, "organization_id": organization_id, "actor_character_id": actor_character_id, "tax_basis_points": tax_basis_points, "enabled": enabled}, service_token)

func server_assess_territory_tax(territory_id: String, gross_amount: int, reason: String, source_ref: String, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/territories/assess-tax", {"territory_id": territory_id, "gross_amount": gross_amount, "reason": reason, "source_ref": source_ref, "idempotency_key": idempotency_key}, service_token)

func server_record_regional_economy_event(region_id: String, territory_id: String, commodity_id: String, quantity_delta: int, unit_value: int, event_type: String, idempotency_key: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/v1/internal/regional-economy/events", {"region_id": region_id, "territory_id": territory_id if not territory_id.is_empty() else null, "commodity_id": commodity_id, "quantity_delta": quantity_delta, "unit_value": unit_value, "event_type": event_type, "idempotency_key": idempotency_key}, service_token)

func server_get_organization_treasury(organization_id: String, actor_character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/organizations/" + organization_id.uri_encode() + "/treasury?actor_character_id=" + actor_character_id.uri_encode(), {}, service_token)

func server_get_regional_economy(region_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_GET, "/v1/internal/regional-economy/" + region_id.uri_encode(), {}, service_token)

func server_provision_organization(organization_id: String, organization_name: String, leader_character_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_PUT, "/v1/internal/organizations/provision", {"organization_id": organization_id, "name": organization_name, "organization_type": "sect", "leader_character_id": leader_character_id}, service_token)
