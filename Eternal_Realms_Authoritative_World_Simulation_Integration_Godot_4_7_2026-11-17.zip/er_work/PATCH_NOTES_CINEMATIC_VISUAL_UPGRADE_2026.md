# Cinematic Visual & VFX Upgrade — Godot 4.7

## Direction
The opening game remains a grounded exploration RPG: readable landscapes, villages, ruins, wildlife, dungeons and physical combat lead the experience. Cultivation is intentionally not presented as the player's expected starting identity. Rare visual language is reserved for discoveries, relics, masters and ancient inheritances so those moments feel extraordinary.

## Changes in this pass
- Kept `DayNightCycle` as the owner of the live sky, time-of-day and weather-facing environment. `VisualQualityDirector` now delegates to it instead of replacing its procedural sky/environment.
- Added sparse ambient pollen/dust motes around the player during daylight, with quality-aware emission and no shadow casting.
- Added directional weapon-contact particle sweeps and a restrained ground dust burst for technique impacts. Existing authored blade arcs and combat rules remain intact.
- Added persistent short-lived projectile trails for arrows, elemental shots and spell projectiles.
- Removed a duplicate `add_child(mesh_instance)` call in projectile visual construction, which attempted to parent the same node twice.
- Existing biome terrain, foliage wind shaders, day/night cycle, streaming chunks, dungeons, settlements, combat and network systems remain in place.

## Art direction
- Ordinary exploration: natural material response, warm/cool time-of-day lighting, wind, subtle airborne particles and restrained combat feedback.
- Ancient discoveries: stronger colour accents, focused light, distinct relic silhouettes and more elaborate one-shot VFX, used sparingly.
- Cultivation should feel like a remarkable new layer discovered later, not a constant magical overlay on the starting RPG.

## Validation
- ZIP integrity and project resource-path checks are performed during packaging.
- Godot 4.7 editor import, GDScript parse, shader compilation and GPU performance testing require the Godot 4.7 executable and target hardware; they are not claimed as passed here.
