# World Presentation, Boss Encounters & Event Expansion

This pass extends the existing procedural systems rather than replacing them.

## Character presentation
- Added layered shoulder pieces, a chest harness, travel pouch and optional cape details to the procedural humanoid model.
- Existing locomotion, attack and death animation routines remain intact; the new details follow the character rig hierarchy.

## Regional world identity
- Added lightweight region-specific landmark dressing to streamed terrain chunks:
  - Ironback Mountains: weathered stone/crystal-like spires.
  - Mirror Pond/coastal reaches: driftwood forms.
  - Whispering Woods: dark standing growths.
  - Arcane Spire region: softly emissive blue crystal formations.
- Landmarks are seeded from the chunk RNG and built with the chunk, so they remain stable when streamed out and back in.

## Monster and boss encounters
- Bosses now gain a shockwave radius after their first health threshold and a stronger final-phase impact radius/knockback at low health.
- Phase transitions are announced clearly; the final phase gains stronger emissive feedback.
- The HUD now displays a live boss name and health bar while a boss is active.
- Existing monster pack-alert behaviour and readable wind-up states are preserved.

## Living world events and quests
- Events now respond to the region the player is exploring: mountain stonefalls, coastal high tides, old-growth hunts and Arcane Spire surges can occur in their respective regions.
- Added two quest chains/objectives for the regional threats: The Mountain's Wake and The Tide Below.
- Tidewalker title now contributes its fishing bonus to fishing luck. Also corrected fishing luck accumulation so seasonal, skill and equipment bonuses stack rather than one replacing another.

## Audio
- Environmental ambience now crossfades between region/night/boss/dungeon beds instead of stopping one loop instantly and starting the next.

## Validation
- Static delimiter checks passed for all changed GDScript files.
- Static `res://` reference scan and ZIP integrity check are run for the delivered archive.
- Godot runtime/editor validation is not available in this environment, so the game has not been launched or play-tested here.
