# Eternal Realms — Dungeon Depths & Commandable Armies Expansion

## Battlefield command and unit roles
- Added player-issued army orders while a physical sect battle is active: `G` advance, `H` hold, `J` regroup on the player, `1` balanced formation, `2` archer line, `3` charge, and `4` defensive formation.
- Allied and opposing armies now include infantry, archers, spellcasters and cavalry with different attack ranges, health and damage profiles. Cavalry move and strike harder; ranged units can engage from distance.
- Fortification walls and the gate now have collision bodies. Destroyed wall sections lose collision; the gate collision is removed when breached, allowing the player and troops to enter the castle. Siege pressure advances while the player is in the battle area, so the encounter can be witnessed and influenced.
- At the gate, press `E` while using a defensive/hold order to reinforce it, or while using an attack order to strike and breach it personally.
- Siege ladders are physically represented beside the siege engines, alongside the existing ram and catapult visuals.

## Commanders
- The two battlefield commanders now carry named identities, personalities, cultivation realms and signature techniques.
- Shen Rui is a disciplined Core Formation tactician who rallies allies with Azure Sword Array.
- Yan Huo is a fierce, protective Nascent Soul commander who supports allies with Phoenix Reversal.
- Their existing team-specific effects remain: coordinated attack tempo for Shen Rui and battlefield recovery for Yan Huo.

## Captures and settlement ownership
- Breaching the gate records a persistent settlement ownership entry in `sect_state.settlement_ownership` and marks the active war as won.
- The captured sect campus receives the occupying faction's banner colour and an occupation marker in the live world.
- Settlement construction reads saved ownership and rebuilds captured compounds with the victor's colour identity, banner and occupation label on subsequent world creation.

## Dungeon expansion
- Added two additional dynamic dungeon events to the existing event rotation: Spirit Tide restores spiritual energy when the player has the relevant energy properties; Ancient Warden spawns a significantly stronger named guardian encounter.
- Dungeon entry now records the named civilization district and floor in the activity feed, reinforcing the ten civilization bands across the 100-floor descent.
- Existing floors, maze generation, bosses, caches, secrets, shrines, spirit veins, civilization trials and expedition checkpoints are retained.

## Controls
- `G`: allied army advance
- `H`: allied army hold
- `J`: regroup on player
- `1`: balanced formation
- `2`: archer line / hold
- `3`: charge
- `4`: defensive formation
- `E`: existing interaction and battlefield civilian rescue; at the castle gate, reinforce while holding/defending or strike while attacking

## Validation and limitations
- Static source scan: 105 GDScript files; no duplicate top-level function declarations, delimiter mismatches or missing literal `res://` paths found.
- ZIP integrity checked after packaging.
- Godot 4.6 is not installed in this environment. Engine parsing, scene startup, physics, AI balance, visual appearance, save/load and in-game playtesting have not been runtime-verified.
- This is an expanded simulation/presentation layer. Army selection by mouse, precise move-to-ground orders, full skeletal combat animation, pathfinding through destructible castle geometry, full settlement architectural rebuild kits, and multiplayer command synchronization remain future work.
